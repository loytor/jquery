<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Administrator
 * Date: 13-7-11
 * Time: 下午1:40
 * To change this template use File | Settings | File Templates.
 * @property Model_user_authority $model_user_authority
 * @property Model_action_record $model_action_record
 */
class MY_Controller extends CI_Controller
{
	const CUR_PAGE = 1;

	public $pageSize = 10;
	public $queryString; //分页传递的参数
	public $urlSegment = 3; //URL第几段为分页参数
	public $pageQueryString = false; //是否开启url问号方式分页
	public $requestConfig;
	public $route;
	public $token;

	public function __construct() {
		parent::__construct();

		$this->load->library('User');
		//$this->config->load('request');
		//$this->requestConfig = $this->config->item('request');
		$url2 = $this->uri->segment(2);
		if (empty($url2)) {
			$url2 = 'index';
		}
        $controller = $this->router->fetch_class();
        $method = $this->router->fetch_method();
        if (empty(User::$user_id) && $controller != 'auth' && $method != 'login') {
            redirect_return('/auth/login');
        }
		//判断权限
		if(!$this->has_authority())
		{
			$this->show_message(FALSE, '您没有该权限', base_url());
		}

		$this->route = '/' . $this->uri->segment(1) . '/' . $url2;
		//$config = !empty($this->requestConfig[$this->route]) ? $this->requestConfig[$this->route] : array();
		//if (isset($config[0]) && $config[0] && empty(User::$user_id)) {
		//	redirect_return('/auth/login');
		//}

		//if (!empty($config[1])) {
			$toenData = array('user_id' => User::$user_id, 'time' => time());
			$this->load->library('encrypt');
			$this->token = $this->encrypt->encode(serialize($toenData));
		//}
	}

	protected function show_message($success, $message, $redirect, $back = 0) {
		if ($this->input->is_ajax_request()) {
			$data = array(
				'success'	=> $success ? 1 : 0,
				'message'	=> strip_tags($message),
			);
			header('Content-type: application/json');
			echo json_encode($data);
		} else {
			$tpl_data = array(
				'message'	=> $message,
				'redirect'	=> $redirect,
				'back'      => $back
			);
			$this->twig->display('show_message', $tpl_data);
		}
		exit;
	}

    /**
     * @param $totalNum
     * @param string $url
     * @return string
     */
    protected function pages($totalNum,$url = '')
	{
		$pagination_config = array(
			'base_url'		=> $url ? $url : $this->route . $this->queryString,
			'total_rows'	=> $totalNum,
			'per_page'		=> $this->pageSize,
			'uri_segment'	=> $this->urlSegment,
			'page_query_string' => $this->pageQueryString,
		);
		$this->load->library('pagination');
		$this->pagination->initialize($pagination_config);
		return $this->pagination->create_links();
	}

	public function _check_image($image) {
		if ($image) {
			if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
				$this->form_validation->set_message('_check_image', '图片地址格式错误');
				return FALSE;
			}
		}
		return TRUE;
	}

	public function get_article_url($article) {
		if ($article['url']) {
			$url = $article['url'];
		} else if ($article['type'] == 'contact') {
			$url = full_url('/article_contact/view/'.$article['id'], 'w');
		} else {
			$url = full_url('/article/view/'.$article['id'], 'w');
		}
		return $url;
	}

	public function has_authority_bak($key)
	{
		//权限值
		$this->config->load('authority');
		$conf_authority = $this->config->item('authority');
		//如果需要判断权限
		if(isset($conf_authority[$key]))
		{
			//获取用户权限
			$this->load->model('model_user_authority');
			$user_authority = $this->model_user_authority->get_row(array('user_id'=>User::$user_id));

			if(isset($user_authority['authority']) && $user_authority['authority'] & $conf_authority[$key][0])
			{
				return TRUE;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return TRUE;
		}
	}

    public function has_authority()
    {
        $this->load->model('model_user_auth');
        $this->load->model('model_app');

        $segment = $this->uri->segment_array();
        if (!$segment) {
            return TRUE;
        }

        if (substr($segment[1], 0, 7) == 'reserve') {
            if (in_array($segment[2], array('add', 'edit', 'delete', 'detail', 'cancel', 'confirm','setSort', 'export'))) {
                $method = $segment[3];
            } else {
                $method = $segment[2];
            }
            $app = $this->model_app->get_row(array('module' => 'reserve', 'method' => $method));
        } else {
            $app = $this->model_app->get_row(array('module' => $segment[1]));
            if (!$app) {
                return TRUE;
            }
        }

        if ($this->model_user_auth->get_row(array('user_id' => User::$user_id, 'app_id' => $app['id']))) {
            return TRUE;
        } else {
            return FALSE;
        }
    }


	/**
	 * 判断提交是否正确(判断来源地址和当前地址是否一致，保证提交的来源)
	 * @return bool
	 */
	protected function submitCheck() {
		if($_SERVER['REQUEST_METHOD'] == 'POST') {
			if(empty($_SERVER['HTTP_REFERER']) || preg_replace('/https?:\/\/([^\:\/]+).*/i', "\\1", $_SERVER['HTTP_REFERER']) == preg_replace('/([^\:]+).*/', "\\1", $_SERVER['HTTP_HOST']) ) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	/**
	 * @param $data
	 * @return object
	 * 记录操作行为
	 */
	public function action_record($data)
	{
		$scope = isset($data['scope']) ? $data['scope'] : 0;
		$type = isset($data['type']) ? $data['type'] : 0;
		$sub_type = isset($data['sub_type']) ? $data['sub_type'] : 0;
		$memo = isset($data['memo']) ? $data['memo'] : '';
		$data_json = isset($data['data_json']) ? $data['data_json'] : '';
		$uid =  isset($data['uid']) ? $data['uid'] : 0;
		$value = isset($data['value']) ? $data['value'] : '';
		$wid = User::$user_id;
		if($wid)
		{
			$this->load->model('model_action_record');
			$this->model_action_record->wid = $wid;
			$this->model_action_record->uid = $uid;
			$this->model_action_record->scope = $scope;
			$this->model_action_record->type = $type;
			$this->model_action_record->sub_type = $sub_type;
			$this->model_action_record->value = $value;
			$this->model_action_record->memo = $memo;
			$this->model_action_record->data_json = $data_json;
			$this->model_action_record->action_time = time();
			$this->model_action_record->ip = ip2long($_SERVER['REMOTE_ADDR']);
			$this->model_action_record->browser_agent = $_SERVER['HTTP_USER_AGENT'];
			$this->model_action_record->add();
		}
	}

	/**
	 * @param $title
	 * @param $des
	 * @param $fields
	 * @param $list
	 * 导出Excel
	 */
    public function excel_export($title, $des, $fields, $list)
    {
    	ini_set('memory_limit','1000M');
    
        $this->load->library('PHPExcel');
        $this->load->library('PHPExcel/IOFactory'); 
		
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getProperties()->setTitle($title)->setDescription($des);

        $objPHPExcel->setActiveSheetIndex(0);

        $col = 0;
        foreach ($fields as $field)
        {
            $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col, 1, $field);
            $col++;
        }

        $results = array();
        foreach($list as $key=>$item) {
            $tmp['#'] = $key+1;
            foreach($item as $k=>$v)
            {
                if(isset($fields[$k]))
                {
                    $tmp[$fields[$k]] = $v;
                }
            }
            $results[] = $tmp;
        }
        $row = 2;
        foreach($results as $data)
        {
            $col = 0;
            foreach ($fields as $field)
            {
                $objPHPExcel->getActiveSheet()->setCellValueExplicitByColumnAndRow($col, $row, $data[$field],PHPExcel_Cell_DataType::TYPE_STRING);
                $col++;
            }

            $row++;
        }

        $objPHPExcel->setActiveSheetIndex(0);

        $objWriter = IOFactory::createWriter($objPHPExcel, 'Excel2007');

        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="'.$title.'_'.date('Ymd').'.xlsx"');
        header('Cache-Control: max-age=0');

        $objWriter->save('php://output');
    }

	public function has_reserve_auth($type)
	{
		if(!$this->has_authority('reserve/'.$type)){
			$this->show_message(FALSE, '您没有该权限', base_url());
		}
	}

    //验证国内，国外手机号码
    public function valid_mobile($mobile)
    {
        $this->load->model('user_model');
        $user = $this->user_model->where(array('id'=>User::$user_id))->find();
        if($user['country'] != '中国') {
            if(preg_match("/^\d+$/", $mobile)) {
                return TRUE;
            } else {
                return FALSE;
            }
        } else {
            if(preg_match("/^(13[0-9]|14[0-9]|15[0-9]|18[0-9]|17[0-9])\d{8}$/", $mobile)) {
                return TRUE;
            } else {
                return FALSE;
            }
        }
    }

    //验证国内，国外电话号码
    public function valid_phone($phoneNumber)
    {
        $this->load->model('user_model');
        $user = $this->user_model->where(array('id'=>User::$user_id))->find();
        if($user['country'] != '中国') {
            if(preg_match("/^\d+$/", $phoneNumber)) {
                return TRUE;
            } else {
                return FALSE;
            }
        } else {
            if (preg_match("/^(13[0-9]{1}[0-9]{8}$|147[0-9]{8}$|15[0-9]{1}[0-9]{8}$|18[0-9]{1}[0-9]{8})|((\d{7,8})|(\d{4}|\d{3})-(\d{7,8})|(\d{4}|\d{3})-(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1})|(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1}))$/", $phoneNumber)){
                return TRUE;
            } else {
                return FALSE;
            }
        }
    }

    public function response($data = NULL, $http_code = 200)
    {
        $output = $this->output->set_content_type('application/json')
            ->set_status_header($http_code)
            ->set_output(json_encode($data))
            ->get_output();
        exit($output);
    }

    protected function response_error($error_code, $error, $http_code = 200)
    {
        $this->response(array(
            'error' => array(
                'code' => $error_code,
                'message' => $error
            )
        ), $http_code);
    }

    private $sms_server = 'http://sms.service.bama555.com';
    /**
     * 通过短信服务器发送短信
     */
    public function send_msg($source_id, $mobile, $content, $type="bama555")
    {
        $this->load->library('rest', array(
            'server' => $this->sms_server
        ));
        $send = $this->rest->get('send_msg',array(
            'source_id' => $source_id,
            'mobile' => $mobile,
            'content' => $content,
            'type' => $type
        ));
        return json_decode($send, TRUE);
        //$this->rest->debug();
    }
}