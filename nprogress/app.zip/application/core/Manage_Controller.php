<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Manage_Controller extends WB_Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * 初始视图数据
     */
    protected function _init_view()
    {
        parent::_init_view();
        $this->_left_menu();
    }

    private function _left_menu()
    {
        $class = $this->router->fetch_class();
        $method = $this->router->fetch_method();
        $curr_key = $class . '/' . $method;

        $this->data['left_menu'] = array(
            'enroll_record/index' => '签到管理'
        );
        $left_menu_actives = array(
            'enroll_record/index' => 'enroll_record/index',
            'enroll_record/mark'  => 'enroll_record/index'
        );
        $this->data['left_menu_active'] = isset($left_menu_actives[$curr_key]) ? $left_menu_actives[$curr_key] : '';
    }

    /**
     * 分页
     *
     * @param $total_rows
     * @param array $config
     * @return array
     */
    protected function _pager($total_rows, $config = array())
    {
        $this->load->library('pagination');
        $default_config['base_url'] = site_url($this->uri->uri_string().'?');
        $default_config['total_rows'] = $total_rows;
        $default_config['per_page'] = 10;
        $default_config['num_links'] = 10;
        $default_config['use_page_numbers'] = TRUE;
        $default_config['first_tag_open'] = $default_config['last_tag_open'] = $default_config['next_tag_open'] = $default_config['prev_tag_open'] = $default_config['num_tag_open'] = ' ';
        $default_config['first_tag_close'] = $default_config['last_tag_close'] = $default_config['next_tag_close'] = $default_config['prev_tag_close'] = $default_config['num_tag_close'] = ' ';
        $default_config['cur_tag_open'] = '<span class="current">';
        $default_config['cur_tag_close'] = '</span>';
        $default_config['first_link'] = '1';
        $default_config['first_tag_close'] = '<span class="separator">...</span>';
        $default_config['last_tag_open'] = '<span class="separator">...</span>';
        $default_config['last_link'] = '尾页';
        $default_config['prev_link'] = '上一页';
        $default_config['next_link'] = '下一页';
        $default_config['page_query_string'] = TRUE;
        $default_config['query_string_segment'] = 'page';
        $config = array_merge($default_config, $config);
        $this->pagination->initialize($config);
        $links = $this->pagination->create_links_wb();
        $cur_page = $this->pagination->cur_page ? $this->pagination->cur_page : 1;
        $limit_offset = ($cur_page - 1) * $config['per_page'];
        return array(
            'links' => $links,
            'limit' => array('value' => $config['per_page'], 'offset' => $limit_offset),
        );
    }

    protected function show_message($success, $message, $redirect = '') {
        if ($this->input->is_ajax_request()) {
            $data = array(
                'success'   => $success ? 1 : 0,
                'message'   => strip_tags($message),
            );
            header('Content-type: application/json');
            echo json_encode($data);
        } else {
            $tpl_data = array(
                'message'   => $message,
                'redirect'  => $redirect
            );
            $this->load->view('show_message', $tpl_data);
        }
    }

    /**
     * @param $title
     * @param $des
     * @param $fields
     * @param $list
     * 导出Excel
     */
    public function excel_export($title, $des, $fields, $list)
    {
        $this->load->library('PHPExcel');
        $this->load->library('PHPExcel/IOFactory');

        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getProperties()->setTitle($title)->setDescription($des);

        $objPHPExcel->setActiveSheetIndex(0);

        $col = 0;
        foreach ($fields as $field)
        {
            $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col, 1, $field);
            $col++;
        }

        $results = array();
        foreach($list as $key=>$item) {
            $tmp['#'] = $key+1;
            foreach($item as $k=>$v)
            {
                if(isset($fields[$k]))
                {
                    $tmp[$fields[$k]] = $v;
                }
            }
            $results[] = $tmp;
        }
        $row = 2;
        foreach($results as $data)
        {
            $col = 0;
            foreach ($fields as $field)
            {
                $objPHPExcel->getActiveSheet()->setCellValueExplicitByColumnAndRow($col, $row, $data[$field],PHPExcel_Cell_DataType::TYPE_STRING);
                $col++;
            }

            $row++;
        }

        $objPHPExcel->setActiveSheetIndex(0);

        $objWriter = IOFactory::createWriter($objPHPExcel, 'Excel5');

        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="'.$title.'_'.date('Ymd').'.xls"');
        header('Cache-Control: max-age=0');

        $objWriter->save('php://output');
    }

}
