<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Administrator
 * Date: 13-7-11
 * Time: 下午1:40
 * To change this template use File | Settings | File Templates.
 * @property Model_user_authority $model_user_authority
 * @property Model_action_record $model_action_record
 */
class MY_Controller extends CI_Controller
{
	const CUR_PAGE = 1;

	public $pageSize = 8;
	public $queryString; //分页传递的参数
	public $urlSegment = 3; //URL第几段为分页参数
	public $pageQueryString = false; //是否开启url问号方式分页
	public $requestConfig;
	public $route;
	public $token;

	public function __construct() {
		parent::__construct();

		$this->load->library('User');
		$this->config->load('request');
		$this->requestConfig = $this->config->item('request');
		$url2 = $this->uri->segment(2);
		if (empty($url2)) {
			$url2 = 'index';
		}
		//判断权限
		if(!$this->has_authority($this->uri->segment(1)))
		{
			$this->show_message(FALSE, '您没有该权限', base_url());
		}

		$this->route = '/' . $this->uri->segment(1) . '/' . $url2;
		$config = !empty($this->requestConfig[$this->route]) ? $this->requestConfig[$this->route] : array();
		if (!$config) {
			redirect_return('/auth/login');
		}
		else {
			if ($config[0] && empty(User::$user_id)) {
				redirect_return('/auth/login');
			}

		}
		if (!empty($config[1])) {
			$toenData = array('user_id' => User::$user_id, 'time' => time());
			$this->load->library('encrypt');
			$this->token = $this->encrypt->encode(serialize($toenData));
		}
	}

	protected function show_message($success, $message, $redirect, $back = 0) {
		if ($this->input->is_ajax_request()) {
			$data = array(
				'success'	=> $success ? 1 : 0,
				'message'	=> strip_tags($message),
			);
			header('Content-type: application/json');
			echo json_encode($data);
		} else {
			$tpl_data = array(
				'message'	=> $message,
				'redirect'	=> $redirect,
				'back'      => $back
			);
			$this->twig->display('show_message', $tpl_data);
		}
		exit;
	}

	/**
	 * @param int $totalNum
	 * @return string
	 */
	protected function pages($totalNum)
	{
		$pagination_config = array(
			'base_url'		=> $this->route . $this->queryString,
			'total_rows'	=> $totalNum,
			'per_page'		=> $this->pageSize,
			'uri_segment'	=> $this->urlSegment,
			'page_query_string' => $this->pageQueryString,
		);
		$this->load->library('pagination');
		$this->pagination->initialize($pagination_config);
		return $this->pagination->create_links();
	}

	public function _check_image($image) {
		if ($image) {
			if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
				$this->form_validation->set_message('_check_image', '图片地址格式错误');
				return FALSE;
			}
		}
		return TRUE;
	}

	public function get_article_url($article) {
		if ($article['url']) {
			$url = $article['url'];
		} else if ($article['type'] == 'contact') {
			$url = full_url('/article_contact/view/'.$article['id'], 'w');
		} else {
			$url = full_url('/article/view/'.$article['id'], 'w');
		}
		return $url;
	}

	public function has_authority($key)
	{
		//权限值
		$this->config->load('authority');
		$conf_authority = $this->config->item('authority');
		//如果需要判断权限
		if(isset($conf_authority[$key]))
		{
			//获取用户权限
			$this->load->model('model_user_authority');
			$user_authority = $this->model_user_authority->get_row(array('user_id'=>User::$user_id));

			if(isset($user_authority['authority']) && $user_authority['authority'] & $conf_authority[$key][0])
			{
				return TRUE;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return TRUE;
		}
	}


	/**
	 * 判断提交是否正确(判断来源地址和当前地址是否一致，保证提交的来源)
	 * @return bool
	 */
	protected function submitCheck() {
		if($_SERVER['REQUEST_METHOD'] == 'POST') {
			if(empty($_SERVER['HTTP_REFERER']) || preg_replace('/https?:\/\/([^\:\/]+).*/i', "\\1", $_SERVER['HTTP_REFERER']) == preg_replace('/([^\:]+).*/', "\\1", $_SERVER['HTTP_HOST']) ) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	/**
	 * @param $data
	 * @return object
	 * 记录操作行为
	 */
	public function action_record($data)
	{
		$scope = isset($data['scope']) ? $data['scope'] : 0;
		$type = isset($data['type']) ? $data['type'] : 0;
		$sub_type = isset($data['sub_type']) ? $data['sub_type'] : 0;
		$memo = isset($data['memo']) ? $data['memo'] : '';
		$data_json = isset($data['data_json']) ? $data['data_json'] : '';
		$uid =  isset($data['uid']) ? $data['uid'] : 0;
		$value = isset($data['value']) ? $data['value'] : '';
		$wid = User::$user_id;
		if($wid)
		{
			$this->load->model('model_action_record');
			$this->model_action_record->wid = $wid;
			$this->model_action_record->uid = $uid;
			$this->model_action_record->scope = $scope;
			$this->model_action_record->type = $type;
			$this->model_action_record->sub_type = $sub_type;
			$this->model_action_record->value = $value;
			$this->model_action_record->memo = $memo;
			$this->model_action_record->data_json = $data_json;
			$this->model_action_record->action_time = time();
			$this->model_action_record->ip = ip2long($_SERVER['REMOTE_ADDR']);
			$this->model_action_record->browser_agent = $_SERVER['HTTP_USER_AGENT'];
			$this->model_action_record->add();
		}
	}

	/**
	 * @param $title
	 * @param $des
	 * @param $fields
	 * @param $list
	 * 导出Excel
	 */
	public function excel_export($title, $des, $fields, $list)
	{
		$this->load->library('PHPExcel');
		$this->load->library('PHPExcel/IOFactory');

		$objPHPExcel = new PHPExcel();
		$objPHPExcel->getProperties()->setTitle($title)->setDescription($des);

		$objPHPExcel->setActiveSheetIndex(0);

		$col = 0;
		foreach ($fields as $field)
		{
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col, 1, $field);
			$col++;
		}

		$results = array();
		foreach($list as $key=>$item) {
			$tmp['#'] = $key+1;
			foreach($item as $k=>$v)
			{
				if(isset($fields[$k]))
				{
					$tmp[$fields[$k]] = $v;
				}
			}
			$results[] = $tmp;
		}
		$row = 2;
		foreach($results as $data)
		{
			$col = 0;
			foreach ($fields as $field)
			{
				$objPHPExcel->getActiveSheet()->setCellValueExplicitByColumnAndRow($col, $row, $data[$field],PHPExcel_Cell_DataType::TYPE_STRING);
				$col++;
			}

			$row++;
		}

		$objPHPExcel->setActiveSheetIndex(0);

		$objWriter = IOFactory::createWriter($objPHPExcel, 'Excel5');

		header('Content-Type: application/vnd.ms-excel');
		header('Content-Disposition: attachment;filename="'.$title.'_'.date('Ymd').'.xls"');
		header('Cache-Control: max-age=0');

		$objWriter->save('php://output');
	}

	public function has_reserve_auth($type)
	{
		if(!$this->has_authority('reserve/'.$type)){
			$this->show_message(FALSE, '您没有该权限', base_url());
		}
	}
}