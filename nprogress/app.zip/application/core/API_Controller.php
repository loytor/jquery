<?php
/**
 * Created by PhpStorm.
 * User: along
 * Date: 14-7-11
 * Time: 上午9:47
 */

class API_Controller extends CI_Controller {

    protected $userIp = '';
    protected $type = '';

    public function __construct()
    {
        parent::__construct();
        $this->userIp = $this->input->ip_address();
        //判断访问来源ip
        $this->load->config('api');
        if(!in_array($this->userIp,$this->config->item('allow_ips')))
        {
            exit($this->ajax_return(array('ret'=>8888,'msg'=>'ip已禁止访问','ip'=>$this->userIp)));
        }
        //类型判断
        $type = $this->input->get('type',true);
        if($type && !in_array($type,$this->config->item('allow_type')))
        {
            exit($this->ajax_return(array('ret'=>-2,'msg'=>'非法类型')));
        }
        $this->type = $type ? $type : 'wechat';
    }

    /**
     * ajax返回数据
     */
    protected function ajax_return($data, $type='json')
    {
        if(strtoupper($type)=='JSON') {
            echo $this->output->set_content_type('application/json')->set_output(json_encode($data))->get_output();
        }else{
            // TODO 增加其它格式
        }
        exit;
    }
}