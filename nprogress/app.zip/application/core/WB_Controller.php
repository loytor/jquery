<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Created by JetBrains PhpStorm.
 * User: andery
 * Date: 13-10-18
 * Time: 下午2:38
 * 所有控制器基类
 */

class WB_Controller extends CI_Controller {
    //是否自动加载模型
    protected $auto_load_model = FALSE;
    //模型名称
    protected $model_name = NULL;
    //模型对象
    protected $model = NULL;
    //页面路径
    protected $dcm = NULL;
    //视图数据
    protected $data = array();

    public function __construct()
    {
        parent::__construct();
        $this->dcm = $this->router->fetch_directory() . $this->router->fetch_class() . '/' . $this->router->fetch_method();
        $this->cm = $this->router->fetch_class() . '/' . $this->router->fetch_method();

        //加载系统配置文件
        //TODO

        //自动加载相对应的数据模型
        if ($this->auto_load_model) {
            $model_name = $this->model_name ? $this->model_name . '_model' : $this->router->fetch_class() . '_model';
            $this->load->model($model_name);
            $this->model = $this->$model_name;
        }

        $this->_init_view(); //初始视图
    }

    protected function _init_view(){
        //TODO
    }

    protected function _upload($field, $config = array())
    {
        $default_config['allowed_types'] = $this->setting['attachment']['allow_type'];
        $default_config['max_size'] = $this->setting['attachment']['max_size'];
        $config = array_merge($default_config, $config);
        $attachment_path = $this->setting['attachment']['path'];
        $config['upload_path'] = element('upload_path', $config) ? $attachment_path . $config['upload_path'] : $attachment_path;
        if (!is_dir($config['upload_path']) && !mkdir($config['upload_path'], 0777, TRUE)) {
            return FALSE;
        }
        $this->load->library('upload', $config);
        if ($this->upload->do_upload($field)) {
            return $this->upload->data();
        } else {
            return FALSE;
        }
    }

    /**
     * ajax返回数据
     */
    protected function ajax_return($data, $type='json')
    {
        if(strtoupper($type)=='JSON') {
            echo $this->output->set_content_type('application/json')->set_output(json_encode($data))->get_output();
        }else{
            // TODO 增加其它格式
        }
        exit;
    }

    public function captcha()
    {
        $this->load->helper('captcha');
        $cap = create_captcha(array(
            'img_path' => './data/captcha/',
            'img_url' => base_url().'data/captcha/',
            'img_width' => 80,
            'img_height' => 30
        ));
        $this->session->set_userdata('captcha', strtolower($cap['word']));
        echo $cap['image'];
    }

    public function check_captcha($input)
    {
        if ($this->session->userdata('captcha') == $input) {
            return TRUE;
        } else {
            $this->form_validation->set_message('check_captcha', '%s 不正确');
            return FALSE;
        }
    }

    /**
     * _remap实现前置后置操作
     * @param $method
     * @param array $params
     */
    public function _remap($method, $params = array())
    {
        if (method_exists($this, $method)) {
            if (method_exists($this, '_before_'.$method)) {
                if (call_user_func_array(array($this, '_before_'.$method), $params) === FALSE) {
                    return FALSE;
                }
            }
            call_user_func_array(array($this, $method), $params);
            if (method_exists($this, '_after_'.$method)) {
                if (call_user_func_array(array($this, '_after_'.$method), $params) === FALSE) {
                    return FALSE;
                }
            }
        } else {
            show_404();
        }
    }

    protected $app_key = '5318162aac6f0086';
    protected $app_secret = '0c28536510e0b0b429750f478222d549';

    //删除图片服务器上的图片
    public function rest_remove($img_path)
    {
        $this->load->library('rest', array(
            'server' => "http://".IMAGE_SERVER."/api",
            'app_key' => $this->app_key,
            'secret_key' => $this->app_secret,
        ));

        $data = array(
            'img_path' => ltrim($img_path, '/')
        );

        $this->rest->delete('upload/img', $data);
    }
}