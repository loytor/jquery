<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Created by JetBrains PhpStorm.
 * User: andery
 * Date: 13-10-23
 * Time: 下午4:27
 * 商家后台基类
 * @property User_model $user_model
 * @property CI_Router $router
 * ·@property Model_action_record $model_action_record
 */

class C_Controller extends WB_Controller {

    const INTERFACE_BASE_URL = 'http://interface.bama555.com/';

    public function __construct()
    {
        parent::__construct();
        $this->load->model('user_model');
        if (!$this->session->userdata('user_id')) {
            redirect('/auth/login');
        }
        $this->site_info = $this->user_model->find($this->session->userdata('user_id'));
        $tokenData = array('user_id' => $this->session->userdata('user_id'), 'time' => time());
        $this->load->library('encrypt');
        $this->data['token'] = $this->encrypt->encode(serialize($tokenData));
    }

    /**
     * 初始视图数据
     */
    protected function _init_view()
    {
        parent::_init_view();
        $this->_left_menu();
    }

    private function _left_menu()
    {
        $class = $this->router->fetch_class();
        $method = $this->router->fetch_method();
        switch ($class) {
            case 'reserve':
            case 'reserve_order':
            case 'reserve_store':
            case 'reserve_category':
            case 'reserve_stuff':
            case 'reserve_form' :
                $type = $this->uri->rsegment(3);
                $this->data['left_menu'] = array(
                    'reserve/'.$type => '基本配置',
                    'reserve_store/'.$type => '门店列表',
                    'reserve_form/'.$type => '自定义预定表单项',
                );
                $this->data['left_menu_active'] = $class . '/' . $type;
            break;
            case 'game':
                $type = $this->input->get('type');
                $this->data['left_menu'] = array(
                    'game/index' => '游戏列表',
                    'game/add?type=1' => '大转盘',
                    'game/add?type=2' => '水果达人',
                    'game/add?type=3' => '刮刮乐',
                    'game/add?type=4' => '砸金蛋',
                );
                $this->data['left_menu_active'] = $class . '/' . $method . ($type ? '?type=' . $type : '');
            break;
            default:
                $curr_key = $class . '/' . $method;
                $this->load->config('app_nav');
                $nav_list = $this->config->item('left_nav');
                $show_list = array();
                foreach ($nav_list as $key => $val) {
                    if (array_key_exists($curr_key, $val)) {
                        foreach ($nav_list[$key] as $_key => $_val) {
                            if ($_val['display'] == 1) {
                                $show_list[$_key] = $_val['text'];
                            }
                        }
                        break;
                    }
                }
                if (!$show_list) {
                    return '';
                }
                $this->data['left_menu'] = $show_list;
                $this->data['left_menu_active'] = $curr_key;
            break;
        }
    }

    /**
     * 分页
     *
     * @param $total_rows
     * @param array $config
     * @return array
     */
    protected function _pager($total_rows, $config = array())
    {
        $this->load->library('pagination');
        $default_config['base_url'] = site_url($this->uri->uri_string().'?');
        $default_config['total_rows'] = $total_rows;
        $default_config['per_page'] = 10;
        $default_config['num_links'] = 10;
        $default_config['use_page_numbers'] = TRUE;
        $default_config['first_tag_open'] = $default_config['last_tag_open'] = $default_config['next_tag_open'] = $default_config['prev_tag_open'] = $default_config['num_tag_open'] = ' ';
        $default_config['first_tag_close'] = $default_config['last_tag_close'] = $default_config['next_tag_close'] = $default_config['prev_tag_close'] = $default_config['num_tag_close'] = ' ';
        $default_config['cur_tag_open'] = '<span class="current">';
        $default_config['cur_tag_close'] = '</span>';
        $default_config['first_link'] = '1';
        $default_config['first_tag_close'] = '<span class="separator">...</span>';
        $default_config['last_tag_open'] = '<span class="separator">...</span>';
        $default_config['last_link'] = '尾页';
        $default_config['prev_link'] = '上一页';
        $default_config['next_link'] = '下一页';
        $default_config['page_query_string'] = TRUE;
        $default_config['query_string_segment'] = 'page';
        $config = array_merge($default_config, $config);
        $this->pagination->initialize($config);
        $links = $this->pagination->create_links_wb();
        $cur_page = $this->pagination->cur_page ? $this->pagination->cur_page : 1;
        $limit_offset = ($cur_page - 1) * $config['per_page'];
        return array(
            'links' => $links,
            'limit' => array('value' => $config['per_page'], 'offset' => $limit_offset),
        );
    }
    
    protected function show_message($success, $message, $redirect = '') {
        if ($this->input->is_ajax_request()) {
            $data = array(
                'success'   => $success ? 1 : 0,
                'message'   => strip_tags($message),
            );
            header('Content-type: application/json');
            echo json_encode($data);
        } else {
            $tpl_data = array(
                'message'   => $message,
                'redirect'  => $redirect
            );
            $this->load->view('show_message', $tpl_data);
        }
    }

    /**
     * @param $title
     * @param $des
     * @param $fields
     * @param $list
     * 导出Excel
     */
    public function excel_export($title, $des, $fields, $list)
    {
        $this->load->library('PHPExcel');
        $this->load->library('PHPExcel/IOFactory');

        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getProperties()->setTitle($title)->setDescription($des);

        $objPHPExcel->setActiveSheetIndex(0);

        $col = 0;
        foreach ($fields as $field)
        {
            $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col, 1, $field);
            $col++;
        }

        $results = array();
        foreach($list as $key=>$item) {
            $tmp['#'] = $key+1;
            foreach($item as $k=>$v)
            {
                if(isset($fields[$k]))
                {
                    $tmp[$fields[$k]] = $v;
                }
            }
            $results[] = $tmp;
        }
        $row = 2;
        foreach($results as $data)
        {
            $col = 0;
            foreach ($fields as $field)
            {
                $objPHPExcel->getActiveSheet()->setCellValueExplicitByColumnAndRow($col, $row, $data[$field],PHPExcel_Cell_DataType::TYPE_STRING);
                $col++;
            }

            $row++;
        }

        $objPHPExcel->setActiveSheetIndex(0);

        $objWriter = IOFactory::createWriter($objPHPExcel, 'Excel2007');

        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="'.$title.'_'.date('Ymd').'.xlsx"');
        header('Cache-Control: max-age=0');

        $objWriter->save('php://output');
    }

    /**
     * 读取Excel
     * @param $file_path
     * @return array
     */
    public function excel_import($file_path)
    {
        $this->load->library('PHPExcel');
        $this->load->library('PHPExcel/IOFactory');

        $objPHPExcel = new PHPExcel();

        $phpexcel = IOFactory::load($file_path);

        $data = array();
        $currentSheet = $phpexcel->getSheet(0);
        /**取得最大的列号*/
        $allColumn = $currentSheet->getHighestColumn();
        /**取得一共有多少行*/
        $allRow = $currentSheet->getHighestRow();
        /**从第二行开始输出，因为excel表中第一行为列名*/
        for($currentRow = 2;$currentRow <= $allRow;$currentRow++){
            $data[$currentRow - 2] = array();
            /**从第A列开始输出*/
            for($currentColumn= 'A';$currentColumn<= $allColumn; $currentColumn++){
                //$val = $currentSheet->getCellByColumnAndRow(ord($currentColumn) - 65,$currentRow)->getValue();/**ord()将字符转为十进制数*/
                //$data[$currentRow][] = $val;
                $cell = $currentSheet->getCellByColumnAndRow(ord($currentColumn) - 65,$currentRow);
                $value = $cell->getValue();
                if($cell->getDataType() == PHPExcel_Cell_DataType::TYPE_NUMERIC){
                    $cellstyleformat = $cell->getParent()->getStyle( $cell->getCoordinate() )->getNumberFormat();
                    $formatcode = $cellstyleformat->getFormatCode();
                    if (PHPExcel_Shared_Date::isDateTimeFormatCode($formatcode)) {
                        $value = gmdate("Y-m-d H:i:s", PHPExcel_Shared_Date::ExcelToPHP($value));
                    }else{
                        $value = PHPExcel_Style_NumberFormat::toFormattedString($value,$formatcode);
                    }
                }
                $data[$currentRow - 2][] = $value;
            }
        }

        return $data;

    }

    /**
     * @param $data
     * @return object
     * 记录操作行为
     */
    public function action_record($data)
    {
        $scope = isset($data['scope']) ? $data['scope'] : 0;
        $type = isset($data['type']) ? $data['type'] : 0;
        $sub_type = isset($data['sub_type']) ? $data['sub_type'] : 0;
        $memo = isset($data['memo']) ? $data['memo'] : '';
        $data_json = isset($data['data_json']) ? $data['data_json'] : '';
        $uid =  isset($data['uid']) ? $data['uid'] : 0;
        $value = isset($data['value']) ? $data['value'] : '';
        $wid = $this->site_info['id'];
        if($wid)
        {
            $this->load->model('action_record_model');
            $data['wid'] = $wid;
            $data['uid'] = $uid;
            $data['scope'] = $scope;
            $data['type'] = $type;
            $data['sub_type'] = $sub_type;
            $data['value'] = $value;
            $data['memo'] = $memo;
            $data['data_json'] = $data_json;
            $data['action_time'] = time();
            $data['ip'] = ip2long($_SERVER['REMOTE_ADDR']);
            $data['browser_agent'] = $_SERVER['HTTP_USER_AGENT'];
            $this->action_record_model->add($data);
        }
    }

    /**
     * 获取回复的业务类型
     */
    public function get_btype() {
        $this->load->model('user_auth_model');
        $files = get_dir_files(APPPATH.'libraries/Appcall');
        $btype = array();
        foreach($files as $_file) {
            $item = array();
            $item['value'] = $class = basename($_file, '.'.pathinfo($_file)['extension']);
            include_once(APPPATH.'libraries/Appcall/'.$_file);
            $c = new $class();
            $item['title'] = $c->get_name();
            if(isset($class::$controller) && isset($class::$method)) {
                $row = $this->user_auth_model->join('app', 'app.id = user_auth.app_id')->where(array('user_auth.user_id'=>$this->site_info['id'], 'app.status'=>1, 'app.controller'=>$class::$controller, 'app.method'=>$class::$method))->find();
                if($row) {
                    $item['sort'] = $row['sort'];
                    $btype[] = $item;
                }
            } else {
                $item['sort'] = -1;
                $btype[] = $item;
            }
        }
        usort($btype, function($item_a, $item_b){
            if ($item_a['sort'] == $item_b['sort']) return 0;
            return ($item_a['sort'] < $item_b['sort']) ? -1 : 1;
        });
        return $btype;
    }

    public function create_url($url)
    {
        if (stripos($url, 'http://') === FALSE) {
            if ($this->site_info['all_domain']) {
                $url = $this->site_info['all_domain'] . '/' .trim($url, '/');
            } else {
                $url = 'http://'.$this->site_info['domain'] . BASE_DOMAIN . '/' .trim($url, '/');
            }
        }
        return $url;
    }
    
    //生成二维码  $model 0 不覆盖原图
    public function createQRcode($content,$id,$type,$model=0)
    {
        $id = abs(intval($id));
        $sid = sprintf("%09d", $id);
        $dir1 = substr($sid, 0, 3);
        $dir2 = substr($sid, 3, 2);
        $dir3 = substr($sid, 5, 4);
        
        $image_path = 'http://'.IMAGE_SERVER.'/data/images/'.$this->site_info['id'].'/'.$dir1 . '/' . $dir2 . '/' . $dir3.'/'.$type.'_'.$id.'.png';
        if( $this->img_exits($image_path) ){//不存在
            $this->load->library('Qrcode_make');
            if( !is_dir(FCPATH.'images/temp') ){
                mkdir(FCPATH.'images/temp',0777,true);
            }
            $native_img = FCPATH.'images/temp/'.$type.'_'.$id.'.png';
            $this->qrcode_make->make($content,$native_img);
            $image_path = $this->rest_upload($native_img,'images/'.$this->site_info['id'].'/'.$dir1 . '/' . $dir2 . '/' . $dir3.'/',$type.'_'.$id.'.png');
        }else{
            if( $model ){//覆盖原来的二维码
                $this->load->library('Qrcode_make');
                if( !is_dir(FCPATH.'images/temp') ){
                    mkdir(FCPATH.'images/temp',0777,true);
                }
                $native_img = FCPATH.'images/temp/'.$type.'_'.$id.'.png';
                $this->qrcode_make->make($content,$native_img);
                $image_path = $this->rest_upload($native_img,'images/'.$this->site_info['id'].'/'.$dir1 . '/' . $dir2 . '/' . $dir3.'/',$type.'_'.$id.'.png');
            }
        }
        
        return $image_path;
    }
    
    /**
     * 上传到图片服务器,并返回图片相对路径
     */
    public function rest_upload($full_path,$upload_path='',$image_path='')
    {
        $this->load->library('rest', array(
            'server' => "http://".IMAGE_SERVER."/api",
            'app_key' => '5318162aac6f0086',
            'secret_key' => '0c28536510e0b0b429750f478222d549',
        ));

        $data = array(
            'img' => '@'.$full_path,
            'upload_path' => $upload_path,
            'img_name'  => $image_path
        );
        $result = $this->rest->post('upload/img', $data);
        @unlink($full_path);
        //$this->rest->debug();
        if(isset($result['error'])) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => $result['error']));
            exit;
        } else {
            return $result['img'];
        }
    }
    
    public function img_exits($url)
    {
        $ch = curl_init();
        $timeout = 3;
        curl_setopt ($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 1);
        curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        $contents = curl_exec($ch);
        if (preg_match("/404/", $contents)){
            return true;
        }else{
            return false;
        }
    }

    /**
     * @name 获取接口
     * @param string $summary 摘要
     * @return array
     */
    protected function check_interface($summary = '')
    {
        if($this->site_info['interface_site_id'])
        {
            return array('site_id'=>$this->site_info['interface_site_id'],'interface_api'=>self::INTERFACE_BASE_URL.'wechat/'.$this->site_info['interface_site_id']);
        }
        else
        {
            $add_site_Url = self::INTERFACE_BASE_URL.'data/config_site';
            $postData = array(
                'source'=>$this->site_info['username'],
                'token'=>$this->site_info['token'],
                'default_api'=>full_url('/api/'.$this->site_info['username'], 'w'),
                'gh_id'=>'',
                'summary'=>$summary
            );

            $this->load->library('curl');
            $result = $this->curl->post($add_site_Url,$postData);

            if($result)
            {
                $result = json_decode($result,true);
                if($result['ret'] == 0)
                {
                    //更新interface_site_id
                    $this->user_model->where(array('username'=>$this->site_info['username']))->edit(array('interface_site_id'=>$result['data']['site_id']));
                    return array('site_id'=>$result['data']['site_id'],'interface_api'=>$result['data']['interface_api']);
                }
                else
                {
                    return $result['msg'];
                }
            }
        }
    }

    /**
     * @name 提交interface站点接口
     * @param $postdata
     * @return mixed
     */
    protected function check_interface_api($postdata)
    {
        $interface_api_url = self::INTERFACE_BASE_URL.'data/config_api';
        $this->load->library('curl');
        $result = $this->curl->post($interface_api_url,$postdata);

        if($result)
        {
            $result = json_decode($result,true);
            return $result;
        }
    }
    
    
    /**
     * @name 打印小票
     * @param $printer_name
     * @param $printer_secret
     * @param $content
     * @param string $type 默认文本=text，二维码=qrcode 都打印=twin
     * @return mixed
     */
    public function print_ticket($printer_info, $content, $type='text', $qr_content='')
    {
        $url = 'http://printer.bama555.com/execute';
        $params['printer'] = $printer_info['printer_name'];
        $params['secret'] = $printer_info['printer_secret'];
        $params['printer_type'] = isset( $printer_info['dayinji_type'] ) ? $printer_info['dayinji_type'] : 1;
        $params['content'] = $content;
        $params['type'] = $type;
        if( $type=='twin' ){
            $params['qr_content'] = $qr_content;
        }
        $this->load->library('curl');
        $result = $this->curl->post($url, $params);
        $result = json_decode($result, true);
        return $result;
    }

    /**
     * 查询又没开通小助手
     */
    public function check_assistant($site_id)
    {
        $this->load->library('rest', array(
            'server' => "http://weizhushou.bama555.com/api/",
            'app_key' => '5318162aac6f0086',
            'secret_key' => '0c28536510e0b0b429750f478222d549',
        ));

        $res = $this->rest->get('helper', array('source_id'=>$site_id));
        if($res['ret']>0 ){
            return false;
        }
        $assistant = $res['data'];
        return $assistant;
    }
	
	//大数据量的csv导出
	public function excel_flush_export( $fields, $list, $title)
    {
        set_time_limit(0);
        ini_set ('memory_limit', '1024M');
        $csv_file = $title.'_'.date('Ymd').'.csv';
        // 输出Excel文件头
        header('Content-Type: application/vnd.ms-excel;charset=gbk');
        header('Content-Disposition: attachment;filename='.$csv_file);
        header('Cache-Control: max-age=0');

        // PHP文件句柄，php://output 表示直接输出到浏览器
        $fp = fopen('php://output', 'a');

        // 输出Excel列头信息
        foreach ($fields as $k => $v) {
            // CSV的Excel支持GBK编码，一定要转换，否则乱码
            $fields[$k] = mb_convert_encoding($v, 'gbk', 'utf-8');    //iconv('utf-8', 'gbk', $v);
        }

        // 写入列头
        fputcsv($fp, $fields);

        // 计数器
        $cnt = 0;
        // 每隔$limit行，刷新一下输出buffer，节约资源
        $limit = 100000;

        // 逐行取出数据，节约内存
        foreach($list as $lv) {
            $cnt ++;
            if ($limit == $cnt) { //刷新一下输出buffer，防止由于数据过多造成问题
                ob_flush();
                flush();
                $cnt = 0;
            }

            foreach ($lv as $ik => $iv) {
                $iv = str_replace("\n", "", str_replace("\r", "", $iv));
                //$iv = htmlspecialchars($iv);
                //$row[$ik] = iconv('utf-8', 'gbk', $iv);
                $row[$ik] = mb_convert_encoding($iv, 'gbk', 'utf-8');
            }
            fputcsv($fp, $row);
        }
    }
}