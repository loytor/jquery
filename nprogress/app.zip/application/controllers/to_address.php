<?php
/**
 * Created by JetBrains PhpStorm.
 * User: llj
 * Date: 13-10-22
 * Time: 上午10:03
 * To change this template use File | Settings | File Templates.
 * @property Model_article $model_article
 * @property Model_address $model_address
 */
class To_address extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('model_article');
		$this->load->model('model_address');
	}

	public function index()
	{
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$contacts = $this->model_article->get_all(array('type'=>'contact'), '', '');
		foreach($contacts as $contact)
		{
			$content = $contact['content'] ? json_decode($contact['content'], TRUE) : array();
			//print_r($content);
			$address = $this->model_address->get_all(array('wid'=>$contact['user_id']));
			$b = true;
			if($address)
			{
				foreach($address as $ad)
				{
					if($ad['id'] < 1735)
					{
						$b = false;
					}
				}
			}
			if(!$address || $b)
			{
				foreach($content as $item)
				{
					$data_set['wid'] = $contact['user_id'];
					$data_set['name'] = (isset($item['name']) && $item['name']) ? mb_substr($item['name'], 0, 31) : mb_substr($contact['title'], 0, 31);

					if($contact['image'])
					{
						$imageItem['src'] = $contact['image'];
						$imageItem['title'] = '';
						$image[0] = $imageItem;
						$data_set['image'] = json_encode($image);
					}
					else
					{
						$data_set['image'] = '';
					}
					$data_set['address'] = isset($item['address']) ? $item['address'] : '';
					$data_set['lng'] = isset($item['lng']) ? $item['lng'] : '';
					$data_set['lat'] = isset($item['lat']) ? $item['lat'] : '';
					$data_set['tel'] = (isset($item['tels']) && $item['tels']) ? implode(',', $item['tels']) : '';
					$data_set['status'] = 0;

					$this->model_address->add($data_set);
				}
			}
		}
	}
}