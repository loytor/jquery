<?php
/**
 * Created by PhpStorm.
 * User: llj
 * Date: 13-12-12
 * Time: 上午10:57
 * @property Mcard_model $mcard_model
 * @property Mcard_level_model $mcard_level_model
 * @property Model_member_card $model_member_card
 * @property Model_user $model_user
 * @property Model_member_user_card $model_member_user_card
 * @property Mcard_member_model $mcard_member_model
 * @property Model_account $model_account
 */
class Convert_mcard extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    public function to_mcard()
    {
        $this->load->model('mcard_level_model');
        $this->load->model('mcard_model');
        $this->load->model('model_member_card');
        $this->load->model('model_user');
        $member_card_list = $this->model_member_card->get_all(array());
        //print_r($member_card_list);
        $i = 0;
        $j = 0;
        foreach($member_card_list as $mc) {
            $new_mc = $this->mcard_model->where(array('site_id'=>$mc['wid']))->find();
            //如果不存在则添加到新的会员卡表
            $mcard_id = $new_mc['id'];
            if(!$new_mc) {
                $add_data['site_id'] = $mc['wid'];
                $add_data['title'] = $mc['name'];
                $add_data['icon'] = $mc['image'];
                $add_data['prefix'] = $mc['prefix'];
                $add_data['instruction'] = $mc['instruction'];
                $add_data['dt_add'] = $mc['dt_add'];
                if($mcard_id = $this->mcard_model->add($add_data)){
                    $i++;
                }
            }

            //将交易密码导入到user表
            $user = $this->model_user->get_row(array('id'=>$mc['wid']));
            if(!$user['trading_pwd']) {
                if($this->model_user->update(array('id'=>$mc['wid']), array('trading_pwd'=>$mc['password']))){
                    $j++;
                }
            }

            //将logo,background导入到默认等级的信息
            $background = 'default';
            $c_background = '';
            if($mc['background']) {
                if(strpos($mc['background'], 'assets/img/vipcard/vip-bg')) {
                    $background = substr($mc['background'], -6, 2);
                }elseif(strpos($mc['background'], 'assets/img/card_bg_default.png')) {
                    $background = 'default';
                }else{
                    $c_background = $mc['background'];
                }
            }
            $mcard_level = $this->mcard_level_model->where(array('site_id'=>$mc['wid'], 'mcard_id'=>$mcard_id, 'basic'=>1))->find();
            if(!$mcard_level) {
                $data = array();
                $data['site_id'] = $mc['wid'];
                $data['mcard_id'] = $mcard_id;
                $data['title'] = $mc['name'];
                $data['validday'] = 0;
                $data['conditions'] = 2;
                $data['enabled'] = 1;
                $data['tpl'] = 'default';
                $data['logo'] = $mc['logo'];
                $data['background'] = $background;
                $data['c_background'] = $c_background;
                $data['status'] = 1;
                $data['dt_add'] = $mc['dt_add'];
                $data['basic'] = 1;
                $data['minpoints'] = 0;
                $data['maxpoints'] = 999999999;
                $this->mcard_level_model->add($data);
            } else {
                $data = array();
                !$mcard_level['logo'] && $data['logo'] = $mc['logo'];
                !$mcard_level['background'] && $data['background'] = $background;
                !$mcard_level['c_background'] && $data['c_background'] = $c_background;
                if($data){
                    $this->mcard_level_model->where(array('site_id'=>$mc['wid'], 'mcard_id'=>$mcard_id, 'basic'=>1))->edit($data);
                }
            }

            //将老的消费送积分导入到新的里去
            $credit_rule = json_decode($mc['creditrule'], TRUE);
            $this->load->library('Mongo_db');
            $credit_setting = $this->mongo_db->where(array('site_id'=>$mc['wid']))->get_one('credit');
            if(!$credit_setting && $credit_rule) {
                $data = array();
                $data['site_id'] = $mc['wid'];
                $data['on'] = 1;
                $data['instruction'] = '';
                $data['consume_rules'] = array();
                foreach($credit_rule as $cr) {
                    $item = array();
                    $item['money'] = $cr['money'];
                    $item['credit'] = $cr['credit'];
                    $item['accumulate'] = '0';
                    $data['consume_rules'][] = $item;
                }

                $this->mongo_db->insert('credit', $data);
            }
        }
        echo 'total:'.$i.',mcard info success<br>';
        echo 'total:'.$j.',trading_pwd convert success<br>';
    }

    //member_user_card to mcard_member
    public function to_mcard_member($page = 1)
    {
        $this->load->model('model_member_user_card');
        $this->load->model('mcard_member_model');
        $this->load->model('mcard_model');
        $this->load->model('model_account');
        $muc = $this->model_member_user_card->get_all(array(), 5000, $page);
        foreach($muc as $row) {
            $mcard = $this->mcard_model->where(array('site_id'=>$row['wid']))->find();
            if($mcard) {
                $mcard_member = $this->mcard_member_model->where(array('site_id'=>$row['wid'], 'mcard_id'=>$mcard['id'], 'uid'=>$row['uid']))->find();
                if(!$mcard_member) {
                    $data = array();
                    $data['site_id'] = $row['wid'];
                    $data['mcard_id'] = $mcard['id'];
                    $data['uid'] = $row['uid'];
                    $data['card_num'] = $row['cardNum'];
                    $data['level_id'] = 0;
                    $data['get_time'] = $row['inputtime'];
                    $this->mcard_member_model->add($data);
                }
            }

            $account = $this->model_account->get_row(array('id'=>$row['uid'], 'wid'=>$row['wid']));
            if($account) {
                $this->model_account->update(array('id'=>$row['uid'], 'wid'=>$row['wid']), array('money'=>$row['money'], 'credit'=>$row['credit'], 'level_credit'=>$row['credit']));
            }
        }
        echo $page.' success';
        //$this->show_message(TRUE, '第'.$page.'批完成', '/convert_mcard/to_mcard_member/'.$page+1);
    }

    //导入payment, payment_log表site_id
    public function payment()
    {
        $this->load->model('payment_model');
        $this->load->model('payment_log_model');
        $this->load->model('model_mall');

        $payment_list = $this->payment_model->find_all();
        foreach($payment_list as $pl) {
            $site_id = $this->model_mall->get_one(array('id'=>$pl['mall_id']), 'wid');
            if($site_id) {
                $this->payment_model->where(array('id'=>$pl['id']))->edit(array('site_id'=>$site_id));
            }
        }

        $payment_log_list = $this->payment_log_model->find_all();
        foreach($payment_log_list as $plog) {
            $site_id = $this->model_mall->get_one(array('id'=>$plog['mall_id']), 'wid');
            if($site_id) {
                $this->payment_log_model->where(array('id'=>$plog['id']))->edit(array('site_id'=>$site_id));
            }
        }
    }

    /**
     * 转化老的消费记录
     */
    public function money_record()
    {
        $start = $this->input->get('start');
        $offset = $this->input->get('offset');
        $this->load->model('action_record_model');
        $action_record = $this->action_record_model->select('action_record.*, account.name as name')->join('account', 'account.id = action_record.uid')->where(array('scope'=>1))->order_by('action_time', 'asc')->limit($offset, $start)->find_all();
        $this->load->model('money_record_model');
        $i = 0;
        foreach($action_record as $ar) {
            $data = array();
            $data['site_id'] = $ar['wid'];
            $data['mid'] = $ar['uid'];
            $data['username'] = $ar['name'];
            $data['money'] = $ar['value'];
            if(($ar['type'] == 0 && $ar['sub_type'] == 1) || ($ar['type'] == 1 && $ar['sub_type'] == 0)) {
                $data['money'] = -$ar['value'];
            }

            if($ar['type'] == 0 && $ar['sub_type'] == 0) {
                $data['remark'] = '商家充值'.$ar['value'].'元';
            } elseif ($ar['type'] == 0 && $ar['sub_type'] == 1) {
                $data['remark'] = '商家扣款'.$ar['value'].'元';
            } elseif ($ar['type'] == 1 && $ar['sub_type'] == 0) {
                $data['remark'] = '消费'.$ar['value'].'元';
            } elseif ($ar['type'] == 2 && $ar['sub_type'] == 0) {
                $data['remark'] = $ar['memo'];
            }

            $data['dt_record'] = $ar['action_time'];
            if($this->money_record_model->add($data)){
                $i++;
            }
        }
        echo 'success:'.$i;
    }

    /**
     * 转化老的积分纪录
     */
    public function credit_record()
    {
        $start = $this->input->get('start');
        $offset = $this->input->get('offset');
        $this->load->model('action_record_model');
        $action_record = $this->action_record_model->select('action_record.*, account.name as name')->join('account', 'account.id = action_record.uid')->where(array('scope'=>2))->order_by('action_time', 'asc')->limit($offset, $start)->find_all();
        $this->load->model('credit_record_model');
        $i = 0;
        foreach($action_record as $ar) {
            $data = array();
            $data['site_id'] = $ar['wid'];
            $data['mid'] = $ar['uid'];
            $data['username'] = $ar['name'];
            $data['credit'] = $ar['value'];
            if(($ar['type'] == 0 && $ar['sub_type'] == 2) || ($ar['type'] == 1 && $ar['sub_type'] == 0)) {
                $data['credit'] = -$ar['value'];
            }

            if($ar['type'] == 0 && $ar['sub_type'] == 0) {
                $data['remark'] = '商家增加'.$ar['value'].'分';
            } elseif ($ar['type'] == 0 && $ar['sub_type'] == 1) {
                $data['remark'] = '转发增加'.$ar['value'].'分';
            } elseif ($ar['type'] == 0 && $ar['sub_type'] == 2) {
                $data['remark'] = '消费增加'.$ar['value'].'分';
            } elseif ($ar['type'] == 0 && $ar['sub_type'] == 3) {
                $data['remark'] = '问卷增加'.$ar['value'].'分';
            } elseif ($ar['type'] == 0 && $ar['sub_type'] == 4) {
                $data['remark'] = '闯关增加'.$ar['value'].'分';
            } elseif ($ar['type'] == 1 && $ar['sub_type'] == 0) {
                $data['remark'] = '换券减少'.$ar['value'].'分';
            } else {
                $data['remark'] = $ar['memo'];
            }

            $data['dt_record'] = $ar['action_time'];
            if($this->credit_record_model->add($data)){
                $i++;
            }
        }
        echo 'success:'.$i;
    }
}