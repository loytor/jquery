<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Administrator
 * Date: 13-9-28
 * Time: 下午11:22
 * To change this template use File | Settings | File Templates.
 * @property Model_user_authority $model_user_authority
 * @property Model_user_auth $model_user_auth
 * @property Model_user $model_user
 * @property Model_agent $model_agent
 */
defined('BASEPATH') OR exit('No direct script access allowed');

class Test extends CI_Controller {

	private $default_auth_arr = array(
		1,
		14,
		18,
		21,
		//22,
		26,
		28,
		29,
		30,
		31
	);

	private $new_auth_arr = array(
		'wedding_invitation'		=>	array(1, '微信喜帖', 0, 23),
		'caipiao'                   =>  array(2, '彩票', 0, 19),
		'member_card'               =>  array(4, '会员卡', 1, 2),
		'invitation'                =>  array(8, '请柬', 0, 20),
		//'game'                      =>  array(16, '互动游戏', 1),
		'autocard'                  =>  array(32, '4S车主关怀系统', 1, 3),
		'reserve/room'              =>  array(64, '酒店订房', 1, 4),
		'reserve/ktv'               =>  array(128, 'KTV预订', 1, 5),
		'reserve/drive'             =>  array(256, '预约试驾', 1, 6),
		'reserve/restaurant'        =>  array(512, '外卖预订', 1, 7),
		'groupon'                   =>  array(1024, '团购', 1, 13),
		'reserve/book'              =>  array(2048, '图书预订', 1, 9),
		'reserve/cosmetician'       =>  array(4096, '美容预约', 1, 10),
		'reserve/maintenance'       =>  array(8192, '汽车保养预约', 1, 11),
		'reserve/course'            =>  array(16384, '课程预约', 1, 12),
		'reserve/table'             =>  array(32768, '餐厅预订（堂食版）', 1, 8),
		'mall'                      =>  array(65536, '微店铺', 1, 27),
	);

	public function __construct()
	{
        //exit('test');
		parent::__construct();
	}

	public function index()
	{
		phpinfo();
	}

	/**
	 * 用户权限转换
	 */
	public function user_auth()
	{
        exit;
		$this->load->model('model_user_auth');

		$this->load->model('model_user_authority');

		$old_user_auths = $this->db->select('user.*, user_authority.admin_id as ua_admin_id, user_authority.agent_id as ua_agent_id, user_authority.authority')->join('user_authority', 'user.id = user_authority.user_id', 'left')->limit(1000,2000)->get('user')->result_array();
		//print_r($arr);
		//exit;

		//$old_user_auths = $this->model_user_authority->get_all(array(), '', '');
        $i = 0;
		foreach($old_user_auths as $old_ua)
		{
			//添加默认的用户权限
			foreach($this->default_auth_arr as $app_id)
			{
				$data_set['user_id'] = $old_ua['id'];
				$data_set['agent_id'] = $old_ua['ua_agent_id'] ? $old_ua['ua_agent_id'] : $old_ua['agent_id'];
				$data_set['admin_id'] = $old_ua['ua_admin_id'] ? $old_ua['ua_admin_id'] : $old_ua['admin_id'];
				$data_set['app_id'] = $app_id;
				$data_set['display'] = 1;
                if ($this->model_user_auth->get_row(array('user_id' => $old_ua['id'], 'app_id' => $app_id))) {
                    continue;
                }
				$this->model_user_auth->add($data_set);
			}

			//添加自定义的用户权限
			foreach($this->new_auth_arr as $na)
			{
				if( ($na[0] <= $old_ua['authority'])  && ($na[0] & $old_ua['authority']))
				{
					$data_set2['user_id'] = $old_ua['id'];
					$data_set2['agent_id'] = $old_ua['ua_agent_id'] ? $old_ua['ua_agent_id'] : $old_ua['agent_id'];
					$data_set2['admin_id'] = $old_ua['ua_admin_id'] ? $old_ua['ua_admin_id'] : $old_ua['admin_id'];
					$data_set2['app_id'] = $na[3];
					$data_set2['display'] = 1;
					$data_set2['auth_code'] = $na[1];
					$data_set2['auth_value'] = $na[0];
                    if ($this->model_user_auth->get_row(array('user_id' => $old_ua['id'], 'app_id' => $na[3]))) {
                        continue;
                    }
					$this->model_user_auth->add($data_set2);
				}
			}
            $i++;
            echo $old_ua['username'] . '------ok!<br/>';
		}
        echo 'total:'.$i.',success';
	}

	/**
	 * 代理商权限转换
	 */
	public function agent_auth()
	{
        exit;
		$this->load->model('model_agent_auth');

		$this->load->model('model_agent_authority');


		$old_agent_auths = $this->db->select('agent.*, agent_authority.admin_id as a_admin_id, agent_authority.parent_agent_id as a_parent_agent_id, agent_authority.authority')->join('agent_authority', 'agent.id = agent_authority.agent_id', 'left')->get('agent')->result_array();
		//print_r($old_agent_auths);
		//exit;

		//$old_agent_auths = $this->model_agent_authority->get_all(array(), '', '');
        $i = 0;
		foreach($old_agent_auths as $old_aa)
		{
			//添加默认的代理商权限
			foreach($this->default_auth_arr as $app_id)
			{
				$data_set['agent_id'] = $old_aa['id'];
				$data_set['parent_agent_id'] = $old_aa['a_parent_agent_id'] ? $old_aa['a_parent_agent_id'] : $old_aa['agent_id'];
				$data_set['admin_id'] = $old_aa['a_admin_id'] ? $old_aa['a_admin_id'] : $old_aa['admin_id'];
				$data_set['app_id'] = $app_id;
				$data_set['display'] = 1;
				$this->model_agent_auth->add($data_set);
			}

			//添加自定义的用户权限
			foreach($this->new_auth_arr as $na)
			{
				if( ($na[0] <= $old_aa['authority'])  && ($na[0] & $old_aa['authority']))
				{
					$data_set2['agent_id'] = $old_aa['id'];
					$data_set2['parent_agent_id'] = $old_aa['a_parent_agent_id'] ? $old_aa['a_parent_agent_id'] : $old_aa['agent_id'];
					$data_set2['admin_id'] = $old_aa['a_admin_id'] ? $old_aa['a_admin_id'] : $old_aa['admin_id'];
					$data_set2['app_id'] = $na[3];
					$data_set2['display'] = 1;
					$data_set2['auth_code'] = $na[1];
					$data_set2['auth_value'] = $na[0];
					$this->model_agent_auth->add($data_set2);
				}
			}
            $i++;
            echo $old_aa['username'] . '------ok!<br/>';
		}
        echo 'total:'.$i.',success';
	}

    public function item_branch()
    {
        exit;
        $all = $this->db->get_where('item_branch')->result_array();
        $i = 0;
        foreach($all as $item)
        {
            $row = $this->db->get_where('address', 'id = '.$item['address_id'])->row_array();
            $wid = $row['wid'];
            $this->db->where(array('item_id'=>$item['item_id'], 'address_id'=>$item['address_id']));
            $this->db->update('item_branch', array('wid'=>$wid));
            $i++;
            echo $item['item_id'].', '.$item['address_id']. '---------ok</br>';
        }
        echo 'total:'.$i.',success';
        //print_r($all);
    }

    /**
     * 将welcome表移到mongodb
     */
    public function welcome()
    {
        exit;
        $this->load->library('Mongo_db');
        $this->load->model('welcome_model');
        $welcome = $this->welcome_model->find_all();
        $i = 0;
        foreach($welcome as $k => &$w) {
            $w['content'] = json_decode($w['content'], TRUE);
            if($w['content'] && is_array($w['content'])) {
                foreach($w['content'] as &$wc) {
                    $wc['id'] = new MongoId();
                }
            }
            $w['site_id'] = $w['user_id'];
            $w['dt_add'] = strtotime($w['dt_add']);
            $w['dt_update'] = strtotime($w['dt_update']);
            unset($w['user_id']);
            unset($w['id']);
            if($this->mongo_db->insert('welcome', $w)){
                $i++;
            }
        }
        echo 'total:'.$i.',success';
    }

    public function reply($per_page='', $page='')
    {
        exit;
        $this->load->library('Mongo_db');
        $this->load->model('model_reply');
        $this->load->model('vipcard_model');
        $replys = $this->model_reply->get_all(array(), $per_page, $page);
        $i = 0;
        foreach($replys as $_reply) {
            $data = array();
            $data['site_id'] = $_reply['user_id'];
            $data['dt_add'] = strtotime($_reply['dt_add']);
            $data['dt_update'] = strtotime($_reply['dt_update']);
            $data['count_match'] = (int)$_reply['count_match'];
            if($_reply['keyword'] == '__default__') { //默认回复
                $data['default'] = 1;
                if($_reply['type'] == 'article') {
                    $content = json_decode($_reply['content'], TRUE);
                    $content = $content ? $content : array();
                    foreach($content as $con) {
                        if($con) {
                            $item_data = array();
                            $item_data['id'] = (string)new MongoId();
                            $item_data['title'] = $con['title'];
                            $item_data['rank'] = $con['rank'];
                            $item_data['image'] = $con['image'];
                            isset($con['description']) && $item_data['desc'] = $con['description'];
                            if( isset($con['url']) && $con['url'] ) {
                                $item_data['url'] = $con['url'];
                                $item_data['type'] = 'Link';
                            } else {
                                $item_data['ref_id'] = $con['id'];
                                $item_data['url'] = '/detail?id='.$con['id'];
                                $item_data['type'] = 'Article';
                            }
                            $data['content'][$item_data['id']] = $item_data;
                        } else {
                            $data['content'] = array();
                        }
                    }

                    $data['type'] = 'article';
                } else {
                    $data['type'] = 'text';
                    $data['content'] = $_reply['content'];
                }
                $data['keyword'] = array('默认');
                if($this->mongo_db->insert('reply', $data)){
                    $i++;
                }
            } elseif ($_reply['type'] == '') { //文字版
                $data['type'] = 'text';
                $data['keyword'] = explode(',', $_reply['keyword']);
                $data['content'] = $_reply['content'];
                if($this->mongo_db->insert('reply', $data)){
                    $i++;
                }
            } elseif ($_reply['type'] == 'article' || $_reply['type'] == 'cate') {
                $content = json_decode($_reply['content'], TRUE);
                $content = $content ? $content : array();
                $data['content'] = array();
                foreach($content as $con) {
                    if($con) {
                        $item_data = array();
                        $item_data['id'] = (string)new MongoId();
                        $item_data['title'] = $con['title'];
                        $item_data['rank'] = $con['rank'];
                        $item_data['image'] = $con['image'];
                        isset($con['description']) && $item_data['desc'] = $con['description'];
                        if( isset($con['url']) && $con['url'] ) {
                            $item_data['url'] = $con['url'];
                            $item_data['type'] = 'Link';
                        } else {
                            $item_data['ref_id'] = $con['id'];
                            $item_data['url'] = '/detail?id='.$con['id'];
                            $item_data['type'] = 'Article';
                        }
                        $data['content'][$item_data['id']] = $item_data;
                    } else {
                        $data['content'] = array();
                    }
                }

                $data['type'] = 'article';
                $data['keyword'] = explode(',', $_reply['keyword']);
                if($this->mongo_db->insert('reply', $data)){
                    $i++;
                }
            } elseif ($_reply['type'] == 'vipcard') { //老会员卡
                $content = json_decode($_reply['content'], TRUE);
                if(is_array($content)) {
                    $vipcard_id = $content[0];
                } else {
                    $vipcard_id = $_reply['content'];
                }
                $data['type'] = 'article';
                $data['keyword'] = explode(',', $_reply['keyword']);
                $vipcard = $this->vipcard_model->where(array('id'=>$vipcard_id, 'user_id'=>$_reply['user_id']))->find();
                if($vipcard) {
                    $item_data = array();
                    $item_data['id'] = (string)new MongoId();
                    $item_data['title'] = $vipcard['name'];
                    $item_data['image'] = $vipcard['image'];
                    $item_data['rank'] = 0;
                    $item_data['ref_id'] = $vipcard['id'];
                    $item_data['url'] = '/vipcard/view/'.$vipcard['id'];
                    $item_data['type'] = 'Vipcard';
                    $item_data['desc'] = $vipcard['welcome_msg'];
                    $data['content'][$item_data['id']] = $item_data;
                } else {
                    $data['content'] = array();
                }
                if($this->mongo_db->insert('reply', $data)){
                    $i++;
                }
            } elseif ($_reply['type'] == 'marketing_vote_text') { //微信投票
                $content = json_decode($_reply['content'], TRUE);
                $con = is_array($content) ? $content[0] : array();
                if($con && isset($con['id'])) {
                    $data['content'] = $con['id'];
                } else {
                    $data['content'] = array();
                }
                $data['type'] = 'text_vote';
                $data['keyword'] = explode(',', $_reply['keyword']);
                if($this->mongo_db->insert('reply', $data)){
                    $i++;
                }
            } elseif ($_reply['type'] == 'marketing') {
                $content = json_decode($_reply['content'], TRUE);
                $data['content'] = $content;
                $data['type'] = 'marketing';
                $data['keyword'] = explode(',', $_reply['keyword']);
                if($this->mongo_db->insert('reply', $data)){
                    $i++;
                }
            } elseif ($_reply['type'] == 'game') {
                $content = json_decode($_reply['content'], TRUE);
                $content = $content ? $content : array();
                foreach($content as $con) {
                    if($con) {
                        $item_data = array();
                        $item_data['id'] = (string)new MongoId();
                        $item_data['title'] = $con['title'];
                        $item_data['rank'] = $con['rank'];
                        $item_data['image'] = isset($con['image_start']) ? $con['image_start'] : '';
                        $item_data['type'] = 'Game';
                        $item_data['ref_id'] = $con['id'];
                        $item_data['url'] = '/game?id='.$con['id'];
                        isset($con['desc']) && $item_data['desc'] = $con['desc'];
                        $data['content'][$item_data['id']] = $item_data;
                    } else {
                        $data['content'] = array();
                    }
                }
                $data['type'] = 'article';
                $data['keyword'] = explode(',', $_reply['keyword']);
                if($this->mongo_db->insert('reply', $data)){
                    $i++;
                }
            } elseif ($_reply['type'] == 'music') {
                $content = json_decode($_reply['content'], TRUE);
                if($content){
                    $item_data = array();
                    $item_data['title'] = $content['title'];
                    $item_data['musicurl'] = $content['musicurl'];
                    $item_data['HQmusicurl'] = isset($content['HQmusicurl']) ? $content['HQmusicurl'] : $content['musicurl'];
                    $item_data['description'] = $content['description'];
                    $data['content'] = $item_data;
                } else {
                    $data['content'] = '';
                }

                $data['type'] = 'music';
                $data['keyword'] = explode(',', $_reply['keyword']);
                if($this->mongo_db->insert('reply', $data)){
                    $i++;
                }
            } elseif ($_reply['type'] == 'forward') {
                $content = json_decode($_reply['content'], TRUE);
                if($content){
                    $item_data = array();
                    $item_data['id'] = (string)new MongoId();
                    $item_data['title'] = $content['title'];
                    $item_data['image'] = $content['image'];
                    $item_data['url'] = $content['url'];
                    $item_data['rank'] = $content['rank'];
                    $item_data['type'] = 'Forward';
                    $item_data['ref_id'] = $content['id'];
                    $data['content'][$item_data['id']] = $item_data;
                } else {
                    $data['content'] = '';
                }

                $data['type'] = 'article';
                $data['keyword'] = explode(',', $_reply['keyword']);
                if($this->mongo_db->insert('reply', $data)){
                    $i++;
                }
            } elseif ($_reply['type'] == 'emigrated') {
                $content = json_decode($_reply['content'], TRUE);
                if($content){
                    $item_data = array();
                    $item_data['id'] = (string)new MongoId();
                    $item_data['title'] = $content['title'];
                    $item_data['image'] = isset($content['image']) ? $content['image'] : '';
                    $url_arr = explode('/', $content['url']);
                    if($url_arr){
                        $item_data['url'] = $url_arr[(count($url_arr)-1)];
                    } else {
                        $item_data['url'] = '';
                    }

                    $item_data['rank'] = $content['rank'];
                    $item_data['type'] = 'Forward';
                    $item_data['ref_id'] = $content['id'];
                    $data['content'][$item_data['id']] = $item_data;
                } else {
                    $data['content'] = '';
                }

                $data['type'] = 'article';
                $data['keyword'] = explode(',', $_reply['keyword']);
                if($this->mongo_db->insert('reply', $data)){
                    $i++;
                }
            }
        }
        echo 'total:'.$i.',success';
    }
}