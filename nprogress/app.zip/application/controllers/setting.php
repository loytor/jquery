<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Class Setting
 * @property Model_user $model_user
 * @property Model_welcome $model_welcome
 * @property Model_cate $model_cate
 * @property Model_scrollinfo $model_scrollinfo
 * @property Model_assist $model_assist
 */
class Setting extends CI_Controller {

	public function __construct() {
		parent::__construct();
	}

	public function index() {
		$this->load->model('model_user');
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}

		$user = $this->model_user->get_row($logged_user_id);
		if ( !$user ) {
			redirect_return('/auth/login');
		}
		if($this->input->post('domain'))
		{
			if($user['domain'] != $this->input->post('domain'))
			{
				$this->form_validation->set_message('is_unique', '二级域名已经被使用，请重新设置');
				$this->form_validation->set_rules('domain', '二级域名', 'trim|required|min_length[4]|max_length[35]|alpha_dash|is_unique[user.domain]');
			}
			else
			{
				$this->form_validation->set_rules('domain', '二级域名', 'trim|required|min_length[4]|max_length[35]|alpha_dash');
			}
		}
		//$this->form_validation->set_rules('mp_username', '公众帐号', 'trim|required');
        $this->form_validation->set_rules('logo', '企业LOGO', 'trim');
		if($this->form_validation->run())
		{
			$where['id'] = $logged_user_id;
			if($this->input->post('domain'))
			{
				$data_set['domain'] = strtolower($this->form_validation->set_value('domain'));
				$data_set['has_domain'] = 1;
				$where['has_domain'] = 0;
			}
			$data_set['logo'] = $this->input->post('logo');
            $data_set['logo2'] = $this->input->post('logo2');
            $data_set['code'] = $_POST['code']; //增加代码的设置

			//$data_set['mp_username'] = $this->form_validation->set_value('mp_username');
			//$data_set['web_name'] = $this->input->post('web_name');

            //$data_set['mp_account'] = trim($this->input->post('mp_account'));
            //$data_set['mp_password'] = trim($this->input->post('mp_password'));
            //验证用户名密码
            //TODO

			//$data_set['auto_attention'] = trim($this->input->post('auto_attention'));
            //$data_set['all_domain'] = trim($this->input->post('all_domain'), '/');
			/*$data_set['appid'] = $this->input->post('appid');
			$data_set['appsecret'] = $this->input->post('appsecret');
			$is_service = intval($this->input->post('is_service')) ;
			if( $is_service==1||$is_service==2 ){
			    $data_set['is_service'] = $is_service;
			    if( $is_service==2 ){
			        $data_set['appid'] = $data_set['appsecret'] = '';
			    }
			    if( $is_service==1 ){
			        if( $data_set['appid']=='' ){
			            $this->show_message(FALSE, 'appid必须填写', '/setting');
			        }
			        if( $data_set['appsecret']=='' ){
                        $this->show_message(FALSE, 'appsecret必须填写', '/setting');
                    }
			    }
			}*/

			if($this->model_user->update($where, $data_set))
			{
				$this->show_message(TRUE, '保存成功', '/setting');
			}
			else
			{
				$this->show_message(FALSE, '保存失败', '/setting');
			}
		}
		else
		{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/setting');
			}
		}

        $user['en_mp_password'] = str_pad('', mb_strlen($user['mp_password']), '*');
        $user['qrcode'] = 'http://open.weixin.qq.com/qr/code/?username='.$user['mp_username'];
        $tpl_data['user'] = $user;
        //获取行业分类
        $this->load->model('trade_cate_model');
        $cate = $this->trade_cate_model->get_trade_cate_list_by_cid(3);
        $tpl_data['cateStr'] = isset($cate['parent']) ? $cate['parent']['name'].'&nbsp;&nbsp;----&nbsp;&nbsp;'.$cate['name'] : $cate['name'];
		//$tpl_data['api_url'] = full_url('/api/'.$user['username'], 'w');
		//$tpl_data['api_token'] = $user['token'];
		$tpl_data['cur_nav'] = 'setting';

		$this->load->library('encrypt');
		$token_data = array('user_id' => $logged_user_id, 'time' => time());
		$tpl_data['token'] = $this->encrypt->encode(serialize($token_data));

		$this->twig->display('setting/index', $tpl_data);
	}

	public function welcome() {
		$this->load->model('model_welcome');
		$this->load->model('model_cate');
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
        
		$welcome = $this->model_welcome->get_row(array('user_id' => $logged_user_id));
		if ($welcome) {
		    $tpl_data['item_arr'] = json_decode($welcome['content'], TRUE);
		    $tpl_data['text'] = $welcome['text'];
            $tpl_data['type'] = $welcome['type'];
		}
		if ($this->input->post()) {
		    $type = $this->input->post('type');
            $data_set['user_id'] = $logged_user_id;
            if($type == 'article') {
    			$item_arr = array();
    			$_items = $this->input->post('items');
                
    			if (is_array($_items) AND ! empty($_items)) {
					foreach ($_items as $_item) {
						if ( ! isset($_item['image'])) continue;
						if ( ! isset($_item['title']) OR empty($_item['title'])) continue;
						if ( ! isset($_item['rank'])) continue;

						if(isset($_item['marketing_id']) && $_item['marketing_id']) {
							$item_arr[] = array(
        						'image'	=> $_item['image'],
        						'title' => $_item['title'],
        						'marketing_id'	=> $_item['marketing_id'],
                                'marketing_type'	=> $_item['marketing_type'],
        						'rank'	=> empty($_item['rank']) ? 99999 : intval($_item['rank']),
        					);
                        }
						elseif(isset($_item['vipcard_id']) && $_item['vipcard_id']) {
							$item_arr[] = array(
									'image'	=> $_item['image'],
									'title' => $_item['title'],
									'rurl'  => $_item['rurl'],
									'vipcard_id' => $_item['vipcard_id'],
									'rank'	=> empty($_item['rank']) ? 99999 : intval($_item['rank']),
							);
						}
						elseif (isset($_item['game_id']) && $_item['game_id']) {
							$item_arr[] = array(
								'image'	=> $_item['image'],
								'title' => $_item['title'],
								'game_id'	=> $_item['game_id'],
								'game_type'	=> $_item['game_type'],
								'rank'	=> empty($_item['rank']) ? 99999 : intval($_item['rank']),
							);
						}
						else {
							$item_arr[] = array(
								'image'	=> $_item['image'],
								'title' => $_item['title'],
								'url'	=> $_item['url'],
								'rurl'  => $_item['rurl'],
								'rank'	=> empty($_item['rank']) ? 99 : intval($_item['rank']),
							);
						}
					}
                    
                    function cmp($item_a, $item_b) {
						if ($item_a['rank'] == $item_b['rank'])
							return 0;
						return ($item_a['rank'] < $item_b['rank']) ? -1 : 1;
					}
                    usort($item_arr, "cmp");
                    
				}
				//默认
                $is_default = $this->input->post('article_default');

                if($item_arr){
                    $data_set['content'] = json_encode($item_arr);
                }else{
                    $data_set['content'] = '';
                }
                
                if($is_default == '1'){
                    $data_set['type'] = 1;
                }
            }
            else {
                $data_set['text'] = $this->input->post('content');
                $is_default = $this->input->post('text_default');
                if($is_default == '1' && !$data_set['text']) {
                    $this->show_message(FALSE, '欢迎信息内容不能为空', '/setting/welcome');
                    exit;
                }
                if($is_default == 1) {
                    $data_set['type'] = 2;
                }
            }
            
			if ($welcome) {
				$this->model_welcome->update($welcome['id'], $data_set);
			}
			else {
				$this->model_welcome->add($data_set);
			}
			$this->show_message(TRUE, '设置成功', '/setting/welcome');
		}
		$cate_arr = array();
		$_cate_arr = $this->model_cate->get_all(array('user_id' => $logged_user_id), 100, 1);
		foreach ($_cate_arr as $_cate) {
			$_cate['url'] = full_url('/article/index/'.$_cate['id'], 'w');
			$_cate['image_preview'] = image_url($_cate['image'], 80, 80);
			$cate_arr[$_cate['id']] = $_cate;
		}
		$tpl_data['cate_arr'] = $cate_arr;

		$tpl_data['home_url'] = full_url('',$this->session->userdata('domain'));
		$this->load->library('encrypt');
		$token_data = array('user_id' => $logged_user_id, 'time' => time());
		$tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
		$tpl_data['cur_nav'] = 'setting';
		$this->twig->display('setting/welcome', $tpl_data);
	}
    
    public function scrollinfo(){
        $logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
        $this->load->model('model_scrollinfo');
        $scrollinfo = $this->model_scrollinfo->get_row(array('user_id' => $logged_user_id));
        
        $tpl_data['scroll_arr'] = array();
		if ($scrollinfo) {
			$tpl_data['scroll_arr'] = json_decode($scrollinfo['content'], TRUE);
		}
        
		if ($this->input->post()) {
            $item_arr = array();
            $_items = $this->input->post('items');
           
			if (is_array($_items) AND ! empty($_items)) {
				foreach ($_items as $_item) {
					
					if ( ! isset($_item['title']) OR empty($_item['title'])) continue;
					
                    $item_arr[] = array(
						'title' => xs_substr($_item['title'],0,20),
						'url'	=> $_item['url'],
						'rank'	=> empty($_item['rank']) ? 999 : intval($_item['rank']),
					);
				}
                function cmp($item_a, $item_b) {
    				if ($item_a['rank'] == $item_b['rank']) return 0;
    				return ($item_a['rank'] < $item_b['rank']) ? -1 : 1;
    			}
    			usort($item_arr, "cmp");
    			$data_set['user_id'] = $logged_user_id;    
			}
			if($item_arr){
                $data_set['content'] = json_encode($item_arr);
			}else{
                $data_set['content'] = '';
			}
			
			if ($scrollinfo) {
				$this->model_scrollinfo->update($scrollinfo['id'], $data_set);
			} else {
				$this->model_scrollinfo->add($data_set);
			}
            
            $this->show_message(TRUE, '设置成功', '/setting/scrollinfo');
		}
        
        $this->twig->display('setting/scrollinfo', $tpl_data);
    }

    public function share()
    {
        $logged_user_id = logged_user_id();
        if ( ! $logged_user_id) {
            redirect_return('/auth/login');
        }
        $this->load->model('model_app_config');
        if ($this->input->post()) {
            $base_config['sendurl'] = $this->input->post('sendurl');
            $base_config['scope'] = $this->input->post('scope');
            $data_set['config'] = json_encode($base_config);
            if (!$this->model_app_config->get_row(array('user_id'=>$logged_user_id, 'type'=>'share'))) {
                if($this->model_app_config->add(array(
                    'user_id'=>$logged_user_id,
                    'type'=>'share',
                    'config' => $data_set['config'],
                ))){
                    $this->show_message(TRUE, '保存设置成功', '/setting/share');
                } else {
                    $this->show_message(FALSE, '保存设置失败', '/setting/share');
                }
            } else {
                if($this->model_app_config->update(array('user_id'=>$logged_user_id, 'type'=>'share'), $data_set)){
                    $this->show_message(TRUE, '保存设置成功', '/setting/share');
                } else {
                    $this->show_message(FALSE, '保存设置失败', '/setting/share');
                }
            }

        }

        $config = $this->model_app_config->get_row(array('user_id'=>$logged_user_id, 'type'=>'share'));
        $tpl_data['config'] = json_decode($config['config'], TRUE);

        $this->twig->display('setting/share', $tpl_data);
    }

    public function tools()
    {
        //$tpl_data[''] =
        $this->twig->display('setting/tools');
    }
    
/*    public function assist(){
        $logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
        $this->load->model('model_assist');
        $assist_arr = $this->model_assist->get_row(array('user_id' => $logged_user_id));
        
        $tpl_data['assist_arr'] = array();
		if ($assist_arr) {
			$tpl_data['assist_arr'] = json_decode($assist_arr['content'], TRUE);
            //判断当前已经入库多少个，最多4个
            //$tpl_data['lestnum'] = 4-count($tpl_data['assist_arr']);
		}
        if ($this->input->post()) {
            
            $item_arr = array();
            $_items = $this->input->post('assist_setting');
           
			if (is_array($_items) AND ! empty($_items)) {
				foreach ($_items as $_item) {
					
					if ( ! isset($_item['title']) OR empty($_item['title'])) continue;
					
                    $item_arr[] = array(
						'title' => xs_substr($_item['title'],0,15),
						'type'	=> $_item['type'],
						'rank'	=> empty($_item['rank']) ? 999 : intval($_item['rank']),
                        'content' => trim($_item['content']),
					);
				}
                function cmp($item_a, $item_b) {
    				if ($item_a['rank'] == $item_b['rank']) return 0;
    				return ($item_a['rank'] < $item_b['rank']) ? -1 : 1;
    			}
    			usort($item_arr, "cmp");
    			$data_set['user_id'] = $logged_user_id;    
			}
			if($item_arr){
                $data_set['content'] = json_encode($item_arr);
			}else{
                $data_set['content'] = '';
			}
            
            if ($assist_arr) {
				$this->model_assist->update($assist_arr['id'], $data_set);
			} else {
				$this->model_assist->add($data_set);
			}
            
            $this->show_message(TRUE, '设置成功', '/setting/assist');
        }
        
        $tpl_data['cur_nav'] = 'cate';
        $this->twig->display('setting/assist', $tpl_data);
    }*/

	private function show_message($success, $message, $redirect) {
		if ($this->input->is_ajax_request()) {
			$data = array(
				'success'	=> $success ? 1 : 0,
				'message'	=> strip_tags($message),
			);
			header('Content-type: application/json');
			echo json_encode($data);
		} else {
			$tpl_data = array(
				'message'	=> $message,
				'redirect'	=> $redirect,
			);
			$this->twig->display('show_message', $tpl_data);
		}
		exit;
	}

}