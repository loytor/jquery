<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('model_user');
		$this->load->model('config_model');
	}

	public function login() {
        if (isset($_SERVER['HTTP_ORIGIN']) ) {
            $this->config->load('allow_origin');
            $http_origin = parse_url($_SERVER['HTTP_ORIGIN']);
            if (!in_array($http_origin['host'], $this->config->item('allow_origin')) && $_SERVER['HTTP_HOST'] != $http_origin['host']) {
                $this->show_message(FALSE, '登陆地址非法', current_url());
            }
        }

		$this->load->library('form_validation');
		$this->load->helper('form');
		$this->form_validation->set_rules('username', '用户名', 'trim|required|max_length[30]|alpha_dash|strtolower');
		$this->form_validation->set_rules('password', '密码', 'trim|required');
		if ($this->form_validation->run()) {
			$username = $this->form_validation->set_value('username');
			$password = md5($this->form_validation->set_value('password'));
			$remember = $this->input->post('remember');
			
			$user = $this->model_user->get_row(array('username' => $username));
			if ( ! $user) {
				$this->show_message(FALSE, '用户名不存在', current_url());
			}
			if($user['is_active'] == 0)
			{
				$this->show_message(FALSE, '对不起，该账号已被禁用，请联系代理商', current_url());
			}
			if ($user['password'] != $password) {
				$this->show_message(FALSE, '密码不正确', current_url());
			}
			
			//判断帐号是否过期
			$expire = strtotime($user['dt_expire']);
			if($expire && ($expire - time() < 0)){
                $this->load->model('free_trial_model');
                $free_trial = $this->free_trial_model->where(array('username'=>$user['username']))->find();

                if($user['free_trial'] == 1 && $free_trial['status'] == 0) {
                    $fdata['user'] = $user;
                    $fdata['free_trial'] = $free_trial;
                    $this->load->model('trade_cate_model');
                    $fdata['trade_cate_list'] = $this->trade_cate_model->get_trade_cate_list_by_level();
                    return $this->load->view('home/free_trial', $fdata);
                } else {
                    $this->show_message(FALSE, '您的帐号已过期', current_url());
                }
			}

			$sess_arr = array(
					'user_id'	=> $user['id'],
					'username'	=> $user['username'],
					'company'	=> $user['company'],
					'domain'    => $user['domain'],
					);
			
			if($expire){
				$sess_arr['expire'] = $user['dt_expire'];
			}
			
			$this->session->set_userdata($sess_arr);
			$data_set['ip'] = $this->input->ip_address();
			$data_set['dt_login'] = date('Y-m-d H:i:s');
			$this->model_user->update($user['id'], $data_set);

			//记住帐号
			if($remember == 1) {
				setcookie('username', $user['username']);
			}else{
				setcookie('username', '');
			}

            //检测密码强度
            if( !$this->testPassword($this->form_validation->set_value('password')) ){
                return $this->show_message(TRUE, '您的密码过于简单，为了您的账号安全，请重新设置密码', '/auth/password');
            }

            redirect_return('/', $_SERVER['HTTP_REFERER']);

			//$this->show_message(TRUE, '登录成功', auto_redirect('/', TRUE));
		} else {
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, current_url());
			}
		}

		$cookie_username = isset($_COOKIE['username']) ? $_COOKIE['username'] : '';
		if($cookie_username){
			$data['remember'] = 1;
			$data['username'] = $cookie_username;
			
		}else{
			$data['remember'] = 0;
			$data['username'] = '';
		}
		$list = $this->config_model->where(array('name'=>'huanding'))->find();
        if( $list ){
            $list['value'] = json_decode($list['value'],true);
        }else{
            $list['value'][] = 'http://image.bama555.com/data/201405/15/2d3e1732875475c57da33fbc90b1a78f_616_466.jpg';
        }
        
		if(!$list['value'])
        {
        	$list['value'][] = 'http://image.bama555.com/data/201405/15/2d3e1732875475c57da33fbc90b1a78f_616_466.jpg';
        }
        
        $data['list'] = $list;

		$this->load->view('home/login', $data);
	}

	public function logout() {
		$this->session->unset_userdata(array(
			'user_id'	=> '',
			'username'	=> '',
			'company'	=> '',
		));

		$this->session->sess_destroy();
        auto_redirect('/auth/login');
	}
    public function password(){
        $logged_user_id = logged_user_id();
        
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
        
        $this->load->library('form_validation');
        $this->form_validation->set_rules('old_password', '原密码', 'trim|required');
        $this->form_validation->set_rules('password', '密码', 'trim|required');
        $this->form_validation->set_rules('re_password', '重复密码', 'trim|required|matches[password]');
        
        if ($this->form_validation->run()) {
            $old_password = md5($this->form_validation->set_value('old_password'));
            $password = $this->form_validation->set_value('password');

            $user = $this->model_user->get_row(array('id' => $logged_user_id));
            if ( ! $user) {
                $this->show_message(FALSE, '用户名不存在', current_url());
            }
            if($user['is_active'] == 0)
            {
                $this->show_message(FALSE, '对不起，该账号已被禁用，请联系代理商', current_url());
            }
            if ($user['password'] != $old_password) {
                $this->show_message(FALSE, '原密码不正确', current_url());
            }

            if ($password) {
                //检测密码强度
                if( !$this->testPassword($this->form_validation->set_value('password')) ){
                    return $this->show_message(FALSE, '密码最少6位，必须包括字母和数字', '/auth/password');
                }
                $data_set['password'] = md5($password);
            }
            
            $data_set['ip'] = $this->input->ip_address();
            $this->model_user->update($logged_user_id, $data_set);

            $this->session->set_userdata(array(
    			'user_id'	=> '',
    			'username'	=> '',
    			'company'	=> '',
    		));
    		$this->session->sess_destroy();

            if($this->has_wbmall($logged_user_id)) {
                $user = $this->model_user->get_row(array('id'=>$logged_user_id));
                $this->sync_update_shop($user['username'], $user);
            }

            $this->show_message(TRUE, '更新成功', '/auth/login');
			
        }else {
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/auth/password');
			}
		}
        
        $this->twig->display('auth/password');
    }

	private function show_message($success, $message, $redirect) {
		if ($this->input->is_ajax_request()) {
			$data = array(
				'success'	=> $success ? 1 : 0,
				'message'	=> strip_tags($message),
			);
			header('Content-type: application/json');
			echo json_encode($data);
		} else {
			$tpl_data = array(
				'message'	=> $message,
				'redirect'	=> $redirect,
			);
			$this->twig->display('show_message', $tpl_data);
		}
		exit;
	}


/*    private $app_key = '53328aa2666a3098';
    private $shop_domain = 'http://wbmall.weiba.com/';*/

        private $app_key = '5332d36aa7409081';
        private $shop_domain = 'http://wbmall.69juzi.com/';

/*        private $app_key = '5332d3ad9f722021';
        private $shop_domain = 'http://wbmall.bama555.com/';*/

    public function has_wbmall($user_id)
    {
        $this->load->model('user_auth_model');
        $results = $this->user_auth_model->join('wb_app', 'wb_app.id = user_auth.app_id', 'left')->where(array('user_id'=>$user_id))->find_all();
        foreach($results as $row) {
            if(isset($row['module']) && $row['module'] == 'wbmall') {
                return TRUE;
            }
        }
        return FALSE;
    }

    public function sync_update_shop($username, $data)
    {
        $url = $this->shop_domain."api/shop/update_from_agent";
        $params['app_key'] = $this->app_key;
        $params['username'] = $username;
        isset($data['dt_expire']) && $params['dt_expire'] = strtotime($data['dt_expire']);
        isset($data['enabled']) && $params['enabled'] = $data['enabled'];
        isset($data['password']) && $params['password'] = $data['password'];//加密后

        $this->load->library('curl');
        $this->curl->post($url, $params);
    }

    /**
     * @检测密码强度
     * @param str 密码
     * @return int
     */
    function testPassword($str)
    {
        $score = 0;
        if(strlen($str) < 6){
            return false;
        }
        if(!preg_match("/[0-9]+/",$str)){
            return false;
        }
        if(!preg_match("/[a-zA-Z]+/",$str)){
            return false;
        }
        return true;
    }

    /**
     * 免费试用用户申请正式
     */
    public function apply_official()
    {
        if($this->input->is_ajax_request()) {
            $this->load->library('wbcurl');
            $res = $this->wbcurl->simple_post(ADMIN_API_URL.'api/free_trial/apply_official', $this->input->post());
            //$this->wbcurl->debug();
            echo $res;
        } else {
            $user_id = logged_user_id();
            $this->load->model('user_model');
            $fdata['user'] = $user = $this->user_model->where(array('id'=>$user_id))->find();

            $this->load->model('free_trial_model');
            $fdata['free_trial'] = $this->free_trial_model->where(array('username'=>$user['username']))->find();

            $this->load->model('trade_cate_model');
            $fdata['trade_cate_list'] = $this->trade_cate_model->get_trade_cate_list_by_level();

            return $this->load->view('home/free_trial', $fdata);
        }
    }
}