<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Marketing_fruit extends CI_Controller {
	private $rewards = array('4'=>'四等奖', 
							'5'=>'五等奖', 
							'6'=>'六等奖', 
							'7'=>'七等奖', 
							'8'=>'八等奖', 
							'9'=>'九等奖', 
							'10'=>'十等奖');

	private $reward_icons = array(
							'4' => '<i class="ic-fruit-1"></i><i class="ic-fruit-2"></i><i class="ic-fruit-2"></i>',
							'5' => '<i class="ic-fruit-1"></i><i class="ic-fruit-5"></i><i class="ic-fruit-5"></i>',
							'6' => '<i class="ic-fruit-9"></i><i class="ic-fruit-3"></i><i class="ic-fruit-3"></i>',
							'7' => '<i class="ic-fruit-3"></i><i class="ic-fruit-4"></i><i class="ic-fruit-4"></i>',
							'8' => '<i class="ic-fruit-4"></i><i class="ic-fruit-5"></i><i class="ic-fruit-5"></i>',
							'9' => '<i class="ic-fruit-9"></i><i class="ic-fruit-8"></i><i class="ic-fruit-3"></i>',
							'10' => '<i class="ic-fruit-4"></i><i class="ic-fruit-5"></i><i class="ic-fruit-6"></i>');
	
	public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('model_marketing_fruit');
		$this->load->model('model_marketing');
        $this->load->model('model_cate');
        $this->load->model('model_cate_lists');
        $this->load->model('model_marketing_fruit_sncode');
	}	

	public function index(){
	
	}
	
	public function add(){
        $this->show_message(FALSE, '旧版水果达人游戏已关闭新增，请使用新的水果达人游戏', '/game/add?type=2');
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
	
		$cate_arr = array();
		$_cate_arr = $this->model_cate->get_all(array('user_id' => $logged_user_id), 500, 1);
		foreach ($_cate_arr as $_cate) {
			$cate_arr[$_cate['id']] = $_cate;
		}
		$tpl_data['cate_arr'] = $cate_arr;
		$tpl_data['instruction'] = '亲，请点击进入水果达人活动页面，祝您好运哦！';
		$tpl_data['image_start'] = site_url().'assets/img/fruit-game-start.jpg';
		$tpl_data['image_end'] = site_url().'assets/img/fruit-game-end.jpg';
	
		$this->load->library('form_validation');
        
        $this->form_validation->set_rules('cate_id', '栏目', 'trim');
	
		$this->form_validation->set_rules('image_start', '活动开始封面图片', 'trim|callback__check_image');
		$this->form_validation->set_rules('image_end', '活动结束封面图片', 'trim|callback__check_image');
	
		$this->form_validation->set_rules('title', '标题', 'trim|required|max_length[255]|htmlspecialchars');
		$this->form_validation->set_rules('description', '活动描述', 'trim|max_length[255]|htmlspecialchars');
		$this->form_validation->set_rules('instruction', '活动说明', 'trim');
		$this->form_validation->set_rules('dt_start', '活动开始时间', 'trim|required|htmlspecialchars');
		$this->form_validation->set_rules('dt_end', '活动结束时间', 'trim|required|htmlspecialchars');
	
		if ($this->form_validation->run()) {
			$cate_id = $this->form_validation->set_value('cate_id');
			if ($cate_id AND ! isset($cate_arr[$cate_id])) {
				$this->show_message(FALSE, '栏目不存在', '/marketing_fruit/add');
			}
			$reward = $this->input->post('reward');
			foreach($reward as &$_prize)
			{
				if(empty($_prize['name']))
				{
					$this->show_message(TRUE, '请完整填写游戏奖品名称！', '',1);
				}
				$_prize['rate'] = is_numeric($_prize['rate']) ? $_prize['rate'] : 0;

				$_prize['number'] = (is_numeric($_prize['number']) && $_prize['number']>0) ? $_prize['number'] : 0;
			}
			$data_set['user_id'] = $logged_user_id;
			$data_set['title'] = $this->form_validation->set_value('title');
			$data_set['cate_id'] = $cate_id;
			$data_set['description'] = $this->form_validation->set_value('description');
			$data_set['dt_start'] = $this->form_validation->set_value('dt_start');
			$data_set['dt_end'] = $this->form_validation->set_value('dt_end');
	
			//判断时间
			if(strtotime($data_set['dt_start']) > time()){
				$data_set['status'] = '未开始';
			}elseif(strtotime($data_set['dt_end']) < time()){
				$data_set['status'] = '已结束';
			}else{
				$data_set['status'] = '已开始';
			}
			$data_set['type'] = 'fruit';
	
			$add_data_set['marketing_id'] = $this->model_marketing->add($data_set);
		    //栏目表count_marketing +1, cate_lists增加记录
            if ($cate_id) {
            	$this->model_cate->count_step($cate_id, 'count_marketing', 1);
            	$data_cate_lists['user_id'] = $logged_user_id;
            	$data_cate_lists['cate_id'] = $cate_id;
            	$data_cate_lists['type'] = 'fruit';
            	$data_cate_lists['lists_id'] = $add_data_set['marketing_id'];
            	$data_cate_lists['rank'] = 9999;
            	$this->model_cate_lists->add($data_cate_lists);
            }
	
			//基础表添加成功 处理附加表
			if($add_data_set['marketing_id']){	
				//处理奖项

				if($reward){
					$reward_data = $rule_data = array();
	
					foreach($reward as $k => $v){
						$v['number'] = $v['number']>1000 ? 1000 : $v['number'];
						$reward_data[$k]['title'] = $v['name'];
						$reward_data[$k]['type'] = $k;
						$reward_data[$k]['number'] = $v['number'];
						$reward_data[$k]['rate'] = $v['rate'];
	
						//自动生成sn码
						if($v['number']>1){
							for($j=0;$j<$v['number'];$j++){
								$v['marketing_id'] = $add_data_set['marketing_id'];
								$v['reward_cate'] = $v['name'];
								$v['reward_type'] = $k;
								$rule_data[] = $v;
							}
						}else{
							$v['marketing_id'] = $add_data_set['marketing_id'];
							$v['reward_cate'] = $v['name'];
							$v['reward_type'] = $k;
							$rule_data[] = $v;	
						}
					}	
					$add_data_set['reward'] = serialize($reward_data);	
				}
	
				//处理规则
				$rule = $this->input->post('rule');
				$rules = $this->input->post('rules');
				$rules[$rule]['type'] = $rule;
	
				$add_data_set['rule'] = serialize($rules[$rule]);
	
				$add_data_set['instruction'] = $this->form_validation->set_value('instruction');
				$add_data_set['image_start'] = $this->input->post('image_start');
				$add_data_set['image_end'] = $this->input->post('image_end');
	
				$add_data_set['displaywinner'] = $this->input->post('displaywinner');
				$add_data_set['wintips'] = $this->input->post('wintips');
				$add_data_set['failtips'] = $this->input->post('failtips');
				$add_data_set['endtitle'] = $this->input->post('endtitle');
				$add_data_set['verification'] = serialize($this->input->post('verification'));
	
				//附加表添加成功，自动生成中奖码
				if($this->model_marketing_fruit->add($add_data_set)){
					
					if($rule_data){
	
						$sncode_data = array();
						foreach($rule_data as $v){
							$sncode_data['marketing_id'] = $v['marketing_id'];
							$sncode_data['reward_cate'] = $v['reward_cate'];
							$sncode_data['reward_status'] = 0;
							$sncode_data['reward_type'] = $v['reward_type'];
							$this->model_marketing_fruit_sncode->add($sncode_data);
						}
					}
					//加一个默认的自定义回复
					$reply_data_set['keyword'] = '水果达人';
					$marketing_arr = array(
							array('id'=>$add_data_set['marketing_id'],
									'type'=>$data_set['type'],
									'title'=>$data_set['title'],
									'description'=>$data_set['description'],
									'image_start'=>$add_data_set['image_start'],
									'rank'=>99999)
					);
					$reply_data_set['content'] = json_encode($marketing_arr);
					$reply_data_set['type'] = 'marketing';
					$reply_data_set['user_id'] = $logged_user_id;
	
					$this->load->model('model_reply');
	
					$reply_id = $this->model_reply->add($reply_data_set);
					if ($reply_id AND ! empty($marketing_arr)) {
						$this->model_reply->marketing_add($reply_id, $marketing_arr[0]['id'], $marketing_arr[0]['rank']);
					}
	
					$this->show_message(TRUE, '活动添加成功', '/marketing');
				}
			}
	
		}else{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/marketing_fruit/add');
			}
		}
		$this->load->library('encrypt');
		$token_data = array('user_id' => $logged_user_id, 'time' => time());
		$tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
		$tpl_data['cur_nav'] = 'marketing';
		$this->twig->display('marketing_fruit/add', $tpl_data);
	}
	
	
    public function update($marketing_id = '') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
        $marketing = $this->model_marketing->get_marketing($marketing_id,'fruit');
        
		if ( ! $marketing || $marketing['user_id'] != $logged_user_id) {
			$this->show_message(FALSE, '找不到该活动', '/marketing');
		}
		$marketing['rule'] = unserialize($marketing['rule']);
		$marketing['verification'] = unserialize($marketing['verification']);
		//如果活动还未开始，可以修改奖项设置
		if(strtotime($marketing['dt_start']) > time()){
			$marketing['status'] = '未开始';
		}elseif(strtotime($marketing['dt_end']) < time()){
			$marketing['status'] = '已结束';
		}else{
			$marketing['status'] = '已开始';
		}
		$tpl_data['marketing'] = $marketing;

		$tpl_data['rewards'] = $this->rewards;
		$tpl_data['reward_icons'] = $this->reward_icons;
		$tpl_data['reward_cates'] = unserialize($marketing['reward']);
		
		$cate_arr = array();
		$_cate_arr = $this->model_cate->get_all(array('user_id' => $logged_user_id), 500, 1);
		foreach ($_cate_arr as $_cate) {
			$cate_arr[$_cate['id']] = $_cate;
		}
		$tpl_data['cate_arr'] = $cate_arr;
        
        $tpl_data['image_start_preview'] = image_url($marketing['image_start'], 640, 320);
        $tpl_data['image_end_preview'] = image_url($marketing['image_end'], 640, 320);
				
		$this->load->library('form_validation');
		
        $this->form_validation->set_rules('cate_id', '栏目', 'trim');
        
        $this->form_validation->set_rules('image_start', '活动开始封面图片', 'trim|callback__check_image');
        $this->form_validation->set_rules('image_end', '活动结束封面图片', 'trim|callback__check_image');
        
        $this->form_validation->set_rules('title', '标题', 'trim|required|max_length[255]|htmlspecialchars');
        $this->form_validation->set_rules('description', '活动描述', 'trim|required|max_length[255]|htmlspecialchars');
        $this->form_validation->set_rules('instruction', '活动说明', 'trim');
        if($marketing['status']  == '未开始'){
        	$this->form_validation->set_rules('dt_start', '活动开始时间', 'trim|required|htmlspecialchars');
        }
        $this->form_validation->set_rules('dt_end', '活动结束时间', 'trim|required|htmlspecialchars');
		
		if ($this->form_validation->run()) {
			$cate_id = $this->form_validation->set_value('cate_id');
			if ($cate_id AND ! isset($cate_arr[$cate_id])) {
				$this->show_message(FALSE, '栏目不存在', '/marketing_fruit/update/'.$marketing_id);
			}
            
            $data_set['title'] = $this->form_validation->set_value('title');
            $data_set['cate_id'] = $cate_id;
            $data_set['description'] = $this->form_validation->set_value('description');
		    if($marketing['status'] == '未开始'){
            	$data_set['dt_start'] = $this->form_validation->set_value('dt_start');
            }else{
            	$data_set['dt_start'] = $marketing['dt_start'];
            }
			$data_set['dt_end'] = $this->form_validation->set_value('dt_end');
            
            //判断时间
            if(strtotime($data_set['dt_start']) > time()){
                $data_set['status'] = '未开始';
            }elseif(strtotime($data_set['dt_end']) < time()){
                $data_set['status'] = '已结束';
            }else{
                $data_set['status'] = '已开始';
            }            
                
            if($this->model_marketing->update($marketing_id, $data_set)){
            	if ($marketing['cate_id'] != $cate_id) {
            		if ($cate_id) {
            			$this->model_cate->count_step($cate_id, 'count_marketing', 1);
            			$data_cate_lists['user_id'] = $logged_user_id;
            			$data_cate_lists['cate_id'] = $cate_id;
            			$data_cate_lists['type'] = 'fruit';
            			$data_cate_lists['lists_id'] = $marketing_id;
            			$data_cate_lists['rank'] = 9999;
            			$this->model_cate_lists->add($data_cate_lists);
            		}
            		if ($marketing['cate_id']) {
            			$this->model_cate->count_step($marketing['cate_id'], 'count_marketing', -1);
            			$del_data_cate_lists['user_id'] = $logged_user_id;
            			$del_data_cate_lists['cate_id'] = $marketing['cate_id'];
            			$del_data_cate_lists['type'] = 'fruit';
            			$del_data_cate_lists['lists_id'] = $marketing_id;
            			$this->model_cate_lists->delete($del_data_cate_lists);
            		}
            	}                
                //更新附加表
                $reward = $this->input->post('reward');//处理奖项
                if($reward){
                	//活动未开始，修改中奖码管理表，先删除再添加
                	if( $marketing['status'] == '未开始'){
                		 
                		$reward_data = $rule_data = array();
                		 
                		foreach($reward as $k => $v){
			                $v['number'] = $v['number']>1000 ? 1000 : $v['number'];
                			$reward_data[$k]['title'] = $v['name'];
                			$reward_data[$k]['type'] = $k;
                			$reward_data[$k]['number'] = $v['number'];
                			$reward_data[$k]['rate'] = $v['rate'];
                			 
                			//自动生成sn码
                			if($v['number']>1){
                				for($j=0;$j<$v['number'];$j++){
                					$v['marketing_id'] = $marketing_id;
                					$v['reward_cate'] = $v['name'];
                					$v['reward_type'] = $k;
                					$rule_data[] = $v;
                				}
                			}else{
                				$v['marketing_id'] = $marketing_id;
                				$v['reward_cate'] = $v['name'];
                				$v['reward_type'] = $k;
                				$rule_data[] = $v;
                				 
                			}
                		}
                		 
                		$add_data_set['reward'] = serialize($reward_data);
                
                		if($rule_data){
                			if($this->model_marketing_fruit_sncode->delete(array('marketing_id'=>$marketing_id))){
                				$sncode_data = array();
                				foreach($rule_data as $v){
                					$sncode_data['marketing_id'] = $v['marketing_id'];
                					$sncode_data['reward_cate'] = $v['reward_cate'];
                					$sncode_data['reward_status'] = 0;
                					$sncode_data['reward_type'] = $v['reward_type'];
                					$this->model_marketing_fruit_sncode->add($sncode_data);
                				}
                			}
                		}
                	}else{
                		$reward_data = array();
                		$rule_data = array();
                		foreach($reward as $k => $v){
			                $v['number'] = (isset($v['number'])) ? $v['number'] : $tpl_data['reward_cates'][$k]['number'];
			                $v['number'] = $v['number']>1000 ? 1000 : $v['number'];
                			$reward_data[$k]['title'] = (isset($v['name'])) ? $v['name'] : $tpl_data['reward_cates'][$k]['title'];
                			$reward_data[$k]['type'] = $k;
                			$reward_data[$k]['number'] = $v['number'];
                			$reward_data[$k]['rate'] = $v['rate'];
                			if(!isset($tpl_data['reward_cates'][$k])){
                				//自动生成sn码
                				if($v['number']>1){
                					for($j=0;$j<$v['number'];$j++){
                						$v['marketing_id'] = $marketing_id;
                						$v['reward_cate'] = $v['name'];
                						$v['reward_type'] = $k;
                						$rule_data[] = $v;
                					}
                				}else{
                					$v['marketing_id'] = $marketing_id;
                					$v['reward_cate'] = $v['name'];
                					$v['reward_type'] = $k;
                					$rule_data[] = $v;                					 
                				}                				
                			}
                		}
                		$add_data_set['reward'] = serialize($reward_data);

                		if($rule_data){
                			foreach($rule_data as $v){
                				$sncode_data['marketing_id'] = $v['marketing_id'];
                				$sncode_data['reward_cate'] = $v['reward_cate'];
                				$sncode_data['reward_status'] = 0;
                				$sncode_data['reward_type'] = $v['reward_type'];
                				$this->model_marketing_fruit_sncode->add($sncode_data);
                			}
                		}                		
                	}
                }
                
                //处理规则
                $rule = $this->input->post('rule');
                $rules = $this->input->post('rules');
    			$rules[$rule]['type'] = $rule;
                $add_data_set['rule'] = serialize($rules[$rule]);
                
                $add_data_set['instruction'] = $this->form_validation->set_value('instruction');
                $add_data_set['image_start'] = $this->input->post('image_start');
                $add_data_set['image_end'] = $this->input->post('image_end');
                
                $add_data_set['displaywinner'] = $this->input->post('displaywinner');
                $add_data_set['wintips'] = $this->input->post('wintips');
                $add_data_set['failtips'] = $this->input->post('failtips');
                $add_data_set['endtitle'] = $this->input->post('endtitle');
                $add_data_set['verification'] = serialize($this->input->post('verification'));
                
                $this->model_marketing_fruit->update(array('marketing_id'=>$marketing_id),$add_data_set);
                
                $this->show_message(TRUE, '更新成功', '/marketing');
            }
		} else {
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/makketing_fruit/update/'.$marketing_id);
			}
		}
		$this->load->library('encrypt');
		$token_data = array('user_id' => $logged_user_id, 'time' => time());
		$tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
		$tpl_data['cur_nav'] = 'marketing';
		$this->twig->display('marketing_fruit/update', $tpl_data);
	}
	
	public function _check_image($image) {
		if ($image) {
			if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
				$this->form_validation->set_message('_check_image', '图片地址格式错误');
				return FALSE;
			}
		}
		return TRUE;
	}
	
	private function show_message($success, $message, $redirect) {
		if ($this->input->is_ajax_request()) {
			$data = array(
					'success'	=> $success ? 1 : 0,
					'message'	=> strip_tags($message),
			);
			header('Content-type: application/json');
			echo json_encode($data);
		} else {
			$tpl_data = array(
					'message'	=> $message,
					'redirect'	=> $redirect,
			);
			$this->twig->display('show_message', $tpl_data);
		}
		exit;
	}
}