<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Wedding_invitation extends MY_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('model_wedding_invitation');
		$this->load->model('model_app_config');
		$this->load->config('baidu');
        exit("微喜帖正在升级");
	}

	public function index() {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$where_set = array('user_id' => $logged_user_id);
		$this->load->library('pagination');
		$pagination_config = array(
				'base_url'		=> '/wedding_invitation/index/',
				'total_rows'	=> $this->model_wedding_invitation->total_rows($where_set),
				'per_page'		=> 8,
				'uri_segment'	=> 3,
		);
		$this->pagination->initialize($pagination_config);
		$tpl_data['pagination'] = $this->pagination->create_links();
		$wedding_invitation_arr = $this->model_wedding_invitation->get_all($where_set, $pagination_config['per_page'], intval($this->uri->segment($pagination_config['uri_segment'], 1)), 'dt_update', 'desc');

		//读取喜帖相关配置
		$app_config = $this->model_app_config->get_row(array('type'=>'wedding', 'user_id'=>$logged_user_id));
		$config = json_decode($app_config['config'], TRUE);
		if(!isset($config['image'])){
			$config['image'] = c_image_url('/assets/wedding/images/wedding.jpg');
		}
		if(!isset($config['description'])){
			$config['description'] = '';
		}
		if(!isset($config['qrcode'])){
			$config['qrcode'] = '';
		}
		if(!isset($config['mp_name'])){
			$config['mp_name'] = '';
		}
		if(!isset($config['case_id'])){
			$config['case_id'] = '';
		}

		$tpl_data['config'] = $config;

		$this->load->library('form_validation');
		$this->load->helper('form');
		$this->form_validation->set_rules('config[image]', '图片', 'trim');
		$this->form_validation->set_rules('config[qrcode]', '二维码', 'trim|required');
		$this->form_validation->set_rules('config[mp_name]', '公众号', 'trim|required');
		$this->form_validation->set_rules('config[case_id]', '案例喜帖ID', 'trim|callback_case_check');
		if ($this->form_validation->run()) {
			$conf = $this->input->post('config');
			if(isset($conf['case_id']) && $conf['case_id']){
				$conf['case_id'] = str_replace('，', ',', $conf['case_id']);
				$conf['case_id'] = str_replace(' ', '', $conf['case_id']);
			}
			$data_set['config'] = json_encode($conf);
			if($app_config){//更新
				$this->model_app_config->update(array('type'=>'wedding', 'user_id'=>$logged_user_id), $data_set);
			}else{//添加
				$data_set['type'] = 'wedding';
				$data_set['user_id'] = $logged_user_id;
				$this->model_app_config->add($data_set);
			}
			$this->show_message(TRUE, '配置保存成功', '/wedding_invitation');
		}else{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/wedding_invitation');
			}
		}
		$this->load->library('encrypt');
		$token_data = array('user_id' => $logged_user_id, 'time' => time());
		$tpl_data['token'] = $this->encrypt->encode(serialize($token_data));

		$tpl_data['wedding_invitation_arr'] = $wedding_invitation_arr;
		$tpl_data['viewUrl'] = site_url('album');
		$this->twig->display('wedding_invitation/index', $tpl_data);
	}

	public function add() {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}

		$this->load->library('form_validation');
		$this->load->helper('form');
		$this->form_validation->set_rules('token', '密码', 'trim|required|max_length[10]|htmlspecialchars');
		$this->form_validation->set_rules('groom_name', '新郎名字', 'trim|required|max_length[20]|htmlspecialchars');
		$this->form_validation->set_rules('bride_name', '新娘名字', 'trim|required|max_length[20]|htmlspecialchars');
		//$this->form_validation->set_rules('video_url', '视频链接', 'trim|htmlspecialchars');

		if ($this->form_validation->run()) {
			$data_set['user_id'] = $logged_user_id;
			$data_set['token'] = $this->form_validation->set_value('token');
			$data_set['cover_type'] = $this->input->post('cover_type');
			$data_set['groom_name'] = $this->form_validation->set_value('groom_name');
			$data_set['bride_name'] = $this->form_validation->set_value('bride_name');
			$data_set['cover_img'] = $this->input->post('cover_img');
			$data_set['thumb'] = $this->input->post('cover_img');//封面图作为头像图
			$data_set['music'] = $this->input->post('music');
			//$data_set['video_url'] = $this->form_validation->set_value('video_url');
			$video_url = preg_replace('/(width=(?:(?:[\'|"])?[^\s]+(?:[\'|"])?)+)/i', 'width="100%"', $this->input->post('video_url'));
			$video_url = preg_replace('/(height=(?:(?:[\'|"])?[^\s]+(?:[\'|"])?)+)/i', 'height="100%"', $video_url);
			$data_set['video_url'] = $video_url;
			$data_set['photo'] = json_encode($this->input->post('photo'));
			$data_set['declarations'] = $this->input->post('declarations');
			if($this->input->post('date')){
				$data_set['date'] = $this->input->post('date');
			}
			$data_set['address'] = $this->input->post('address');
			$data_set['lat'] = $this->input->post('lat');
			$data_set['lng'] = $this->input->post('lng');
			$data_set['telephone'] = $this->input->post('telephone');

			$this->model_wedding_invitation->add($data_set);
			$this->show_message(TRUE, '添加成功', '/wedding_invitation');
		} else {
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/wedding_invitation/add');
			}
		}
		$this->load->library('encrypt');
		$token_data = array('user_id' => $logged_user_id, 'time' => time());
		$tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
		$tpl_data['ak'] = $this->config->item('baidu_token');
		$this->config->load('music');
		$tpl_data['music_arr'] = $this->config->item('music');
		$tpl_data['cur_nav'] = 'marketing';
		$this->twig->display('wedding_invitation/add', $tpl_data);
	}

	public function update($wedding_invitation_id = '') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$wedding_invitation = $this->model_wedding_invitation->get_row(array('id' => $wedding_invitation_id, 'user_id' => $logged_user_id));
		if ( ! $wedding_invitation) {
			$this->show_message(FALSE, '找不到该喜帖', '/wedding_invitation');
		}

		$wedding_invitation['photo_arr'] = json_decode($wedding_invitation['photo'], TRUE);
		$wedding_invitation['date'] = ($wedding_invitation['date'] == '0000-00-00 00:00:00') ? '' : $wedding_invitation['date'];
		$tpl_data['wedding_invitation'] = $wedding_invitation;

		$this->load->library('form_validation');
		$this->load->helper('form');
		$this->form_validation->set_rules('token', '密码', 'trim|required|max_length[10]|htmlspecialchars');
		$this->form_validation->set_rules('groom_name', '新郎名字', 'trim|required|max_length[20]|htmlspecialchars');
		$this->form_validation->set_rules('bride_name', '新娘名字', 'trim|required|max_length[20]|htmlspecialchars');
		//$this->form_validation->set_rules('video_url', '视频链接', 'trim|htmlspecialchars');

		if ($this->form_validation->run()) {
			$data_set['token'] = $this->form_validation->set_value('token');
			$data_set['cover_type'] = $this->input->post('cover_type');
			$data_set['groom_name'] = $this->form_validation->set_value('groom_name');
			$data_set['bride_name'] = $this->form_validation->set_value('bride_name');
			$data_set['cover_img'] = $this->input->post('cover_img');
			$data_set['thumb'] = $this->input->post('cover_img');//封面图作为头像图
			$data_set['music'] = $this->input->post('music');
			//$data_set['video_url'] = $this->form_validation->set_value('video_url');
			$video_url = preg_replace('/(width=(?:(?:[\'|"])?[^\s]+(?:[\'|"])?)+)/i', 'width="100%"', $this->input->post('video_url'));
			$video_url = preg_replace('/(height=(?:(?:[\'|"])?[^\s]+(?:[\'|"])?)+)/i', 'height="100%"', $video_url);
			$data_set['video_url'] = $video_url;
			$data_set['photo'] = json_encode($this->input->post('photo'));
			$data_set['declarations'] = $this->input->post('declarations');
			if($this->input->post('date')){
				$data_set['date'] = $this->input->post('date');
			}
			$data_set['address'] = $this->input->post('address');
			$data_set['lat'] = $this->input->post('lat');
			$data_set['lng'] = $this->input->post('lng');
			$data_set['telephone'] = $this->input->post('telephone');

			$this->model_wedding_invitation->update($wedding_invitation_id, $data_set);
			$this->show_message(TRUE, '更新成功', '/wedding_invitation');
		} else {
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/wedding_invitation/update/'.$wedding_invitation_id);
			}
		}
		$this->load->library('encrypt');
		$token_data = array('user_id' => $logged_user_id, 'time' => time());
		$tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
		$tpl_data['ak'] = $this->config->item('baidu_token');
		$this->config->load('music');
		$tpl_data['music_arr'] = $this->config->item('music');		
		$tpl_data['cur_nav'] = 'marketing';
		$this->twig->display('wedding_invitation/update', $tpl_data);		
	}

	public function delete($wedding_invitation_id = '') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$wedding_invitation = $this->model_wedding_invitation->get_row(array('id' => $wedding_invitation_id, 'user_id' => $logged_user_id));
		if ( ! $wedding_invitation) {
			$this->show_message(FALSE, '找不到该喜帖', '/wedding_invitation');
		}

		if($this->model_wedding_invitation->delete(array('id' => $wedding_invitation_id))){
			$this->load->model('model_wedding_joinbless');
			$this->model_wedding_joinbless->delete(array('wedding_invitation_id'=>$wedding_invitation_id));
		}
		$this->show_message(TRUE, '删除成功', '/wedding_invitation');
	}

	public function unbind($wedding_invitation_id = '') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$wedding_invitation = $this->model_wedding_invitation->get_row(array('id' => $wedding_invitation_id, 'user_id' => $logged_user_id));
		if ( ! $wedding_invitation) {
			$this->show_message(FALSE, '找不到该喜帖', '/wedding_invitation');
		}

		if($this->model_wedding_invitation->update(array('id' => $wedding_invitation_id), array('weixin_open_id'=>''))){
			$this->show_message(TRUE, '解除绑定成功', '/wedding_invitation');
		}else{
			$this->show_message(FALSE, '解除绑定失败', '/wedding_invitation');
		}
	}

	public function details($wedding_invitation_id = '') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$wedding_invitation = $this->model_wedding_invitation->get_row(array('id' => $wedding_invitation_id, 'user_id' => $logged_user_id));
		if ( ! $wedding_invitation) {
			$this->show_message(FALSE, '找不到该喜帖', '/wedding_invitation');
		}

		//读取喜帖相关配置
		$app_config = $this->model_app_config->get_row(array('type'=>'wedding', 'user_id'=>$logged_user_id));
		$config = json_decode($app_config['config'], TRUE);

		$tpl_data['config'] = $config;
		$tpl_data['wedding_invitation'] = $wedding_invitation;

        $tpl_data['viewUrl'] = site_url('xitie');
        
		$this->twig->display('wedding_invitation/details', $tpl_data);
	}
	
	public function case_check($str) {
		$str = str_replace('，', ',', $str);	
		$arr = explode(',', $str);
		if(count($arr) > 3){
			$this->form_validation->set_message('case_check', '%s不能超过3个');
			return FALSE;
		}
		return TRUE;
	}
}