<?php
/**
 * Created by JetBrains PhpStorm.
 * User: llj
 * Date: 13-10-10
 * Time: 下午5:11
 * To change this template use File | Settings | File Templates.
 * @property Model_cate $model_cate
 * @property Model_contact $model_contact
 * @property Model_address $model_address
 * @property Model_contact_address $model_contact_address
 */
class Contact extends MY_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('model_cate');
		$this->load->model('model_contact');
		$this->load->model('model_address');
		$this->load->model('model_contact_address');
		$this->load->model('model_cate_lists');
	}

	public function index()
	{
		//获取所有栏目
		$cate_arr = array();
		$_cate_arr = $this->model_cate->get_all(array('user_id' => User::$user_id));
		foreach ($_cate_arr as $_cate) {
			$cate_arr[$_cate['id']] = $_cate;
		}
		$tpl_data['cate_arr'] = $cate_arr;

		$title = $this->input->get_post('title');
		$cate_id = $this->input->get_post('cate_id');

		$tpl_data['title'] = $title ? $title : '';
		$cate_id = $cate_id ? $cate_id : '_';
		$tpl_data['cate_id'] = $cate_id;

		$page = (int)$this->input->get('per_page');
		$page = $page ? $page : self::CUR_PAGE;
		$this->pageQueryString = true;

		$where_set = array('wid'=>User::$user_id);
		//用于过滤查找
		$qs = array();
		if($title)
		{
			$where_set['title'] = 'like:'.$title;
			$qs[] = 'title='.$title;
		}
		if($cate_id != '_')
		{
			$where_set['cate_id'] = $cate_id;
			$qs[] = 'cate_id='.$cate_id;
		}

		$queryStr = implode('&', $qs);
		$this->queryString = '?' . $queryStr;

		$list = $this->model_contact->get_all($where_set, $this->pageSize, $page, 'rank', 'asc');
		foreach($list as &$row)
		{
			$row['cate_name'] = isset($cate_arr[$row['cate_id']]['cate_name']) ? $cate_arr[$row['cate_id']]['cate_name'] : '';
		}
		$tpl_data['list'] = $list;

		$tpl_data['per_page'] = $this->pageSize;
		$tpl_data['page'] = $page;
		$tpl_data['pagination'] = $this->pages($this->model_contact->total_rows($where_set));

		$tpl_data['cur_nav'] = 'address';
		$this->twig->display('contact/index', $tpl_data);
	}

	public function add()
	{
		//获取联系我们模版
		$this->load->config('tpl');
		$contact_tpl_arr = $this->config->item('contact_tpl_arr');
		$tpl_data['tpl_lists'] = $contact_tpl_arr;
		$tpl_data['preview_path'] = $this->config->item('preview_path');

		//获取所有栏目
		$cate_arr = array();
		$_cate_arr = $this->model_cate->get_all(array('user_id' => User::$user_id));
		foreach ($_cate_arr as $_cate) {
			$cate_arr[$_cate['id']] = $_cate;
		}
		$tpl_data['cate_arr'] = $cate_arr;

		$address = $this->model_address->get_all(array('wid'=>User::$user_id, 'status'=>0), '', '');
		$tpl_data['address'] = $address;

		$this->form_validation->set_rules('cate_id', '栏目', 'trim');
		$this->form_validation->set_rules('title', '标题', 'trim|required|max_length[32]|htmlspecialchars');
		if ($this->form_validation->run()) {
			$addressArr = $this->input->post('address');

			$this->model_contact->wid = User::$user_id;
			$cate_id = $this->form_validation->set_value('cate_id');
			$this->model_contact->cate_id = $cate_id;
			$this->model_contact->title = $this->form_validation->set_value('title');
			$this->model_contact->image = $this->input->post('image');
			$this->model_contact->tpl = $this->input->post('tpl');
			$this->model_contact->rank = (int)$this->input->post('rank');
			$contact_id = $this->model_contact->add(array(), TRUE);
			if($contact_id)
			{
				if($addressArr)
				{
					foreach($addressArr as $ad_id)
					{
						$this->model_contact_address->wid = User::$user_id;
						$this->model_contact_address->contact_id = $contact_id;
						$this->model_contact_address->address_id = $ad_id;
						$this->model_contact_address->add();
					}
				}

				//归档
				if ($cate_id) {
					$data_cate_lists['user_id'] = User::$user_id;
					$data_cate_lists['cate_id'] = $cate_id;
					$data_cate_lists['type'] = 'contact';
					$data_cate_lists['lists_id'] = $contact_id;
					$data_cate_lists['rank'] = 9999;
					$this->model_cate_lists->add($data_cate_lists);
				}

				$this->show_message(TRUE, '添加联系我们成功', '/contact');
			}
			else
			{
				$this->show_message(FALSE, '添加联系我们失败', '/contact');
			}
		}
		else
		{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/contact');
			}
		}

		$tpl_data['token'] = $this->token;
		$tpl_data['cur_nav'] = 'address';
		$this->twig->display('contact/add', $tpl_data);
	}

	public function edit($id)
	{
		$contact = $this->model_contact->get_row(array('id'=>$id));
		if(!$contact)
		{
			$this->show_message(FALSE, '该联系我们不存在', '/contact');
		}

		$this->form_validation->set_rules('cate_id', '栏目', 'trim');
		$this->form_validation->set_rules('title', '标题', 'trim|required|max_length[32]|htmlspecialchars');
		if ($this->form_validation->run()) {
			$addressArr = $this->input->post('address');

			$data_set['wid'] = User::$user_id;
			$cate_id = $this->form_validation->set_value('cate_id');
			$data_set['cate_id'] = $cate_id;
			$data_set['title'] = $this->form_validation->set_value('title');
			$data_set['image'] = $this->input->post('image');
			$data_set['tpl'] = $this->input->post('tpl');
			$data_set['rank'] = (int)$this->input->post('rank');

			if($this->model_contact->update(array('wid'=>User::$user_id, 'id'=>$id), $data_set))
			{
				//先删除联系我们地址关联表相关记录
				$this->model_contact_address->delete(array('wid'=>User::$user_id, 'contact_id'=>$id));
				if($addressArr)
				{
					foreach($addressArr as $ad_id)
					{
						$this->model_contact_address->wid = User::$user_id;
						$this->model_contact_address->contact_id = $id;
						$this->model_contact_address->address_id = $ad_id;
						$this->model_contact_address->add();
					}
				}

				//更新归档
				if ($contact['cate_id'] != $cate_id) {
					if ($cate_id) {
						$data_cate_lists['user_id'] = User::$user_id;
						$data_cate_lists['cate_id'] = $cate_id;
						$data_cate_lists['type'] = 'contact';
						$data_cate_lists['lists_id'] = $id;
						$data_cate_lists['rank'] = 9999;
						$this->model_cate_lists->add($data_cate_lists);
					}
					if ($contact['cate_id']) {
						$del_data_cate_lists['user_id'] = User::$user_id;
						$del_data_cate_lists['cate_id'] = $contact['cate_id'];
						$del_data_cate_lists['type'] = 'contact';
						$del_data_cate_lists['lists_id'] = $contact['id'];
						$this->model_cate_lists->delete($del_data_cate_lists);
					}
				}

				$this->show_message(TRUE, '编辑联系我们成功', '/contact');
			}
			else
			{
				$this->show_message(FALSE, '编辑联系我们失败', '/contact/edit/'.$id);
			}
		}
		else
		{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/contact');
			}
		}

		//获取联系我们模版
		$this->load->config('tpl');
		$contact_tpl_arr = $this->config->item('contact_tpl_arr');
		$tpl_data['tpl_lists'] = $contact_tpl_arr;
		$tpl_data['preview_path'] = $this->config->item('preview_path');

		//获取所有栏目
		$cate_arr = array();
		$_cate_arr = $this->model_cate->get_all(array('user_id' => User::$user_id));
		foreach ($_cate_arr as $_cate) {
			$cate_arr[$_cate['id']] = $_cate;
		}
		$tpl_data['cate_arr'] = $cate_arr;

		$address = $this->model_address->get_all(array('wid'=>User::$user_id,'status'=>0), '', '');
		$contact_address = $this->model_contact_address->get_all(array('wid'=>User::$user_id, 'contact_id'=>$id), '', '');
		$selected_ad_ids = array();
		foreach($contact_address as $ca)
		{
			$selected_ad_ids[] = $ca['address_id'];
		}

		$selected_address = array();
		$unselect_address = array();
		foreach($address as $ad)
		{
			if(in_array($ad['id'], $selected_ad_ids))
			{
				$selected_address[] = $ad;
			}
			elseif($ad['status'] == 0)
			{
				$unselect_address[] = $ad;
			}
		}
		$tpl_data['selected_address'] = $selected_address;
		$tpl_data['unselect_address'] = $unselect_address;

		$tpl_data['contact'] = $contact;
        $domain = $this->session->userdata('domain');
        $url = $domain ? "http://".$domain.BASE_DOMAIN."/contact?id=".$id : '';
        $tpl_data['url'] = $url;
		$tpl_data['token'] = $this->token;
		$tpl_data['cur_nav'] = 'address';
		$this->twig->display('contact/edit', $tpl_data);
	}

	public function delete($id)
	{
		$contact = $this->model_contact->get_row(array('id'=>$id, 'wid'=>User::$user_id));
		if(!$contact)
		{
			$this->show_message(FALSE, '该联系我们不存在', '/contact');
		}
		if($this->model_contact->delete(array('id'=>$id, 'wid'=>User::$user_id)))
		{
			//删除关联表数据
			$this->model_contact_address->delete(array('wid'=>User::$user_id, 'contact_id'=>$id));

			$this->show_message(TRUE, '删除联系我们成功', '/contact');
		}
		else
		{
			$this->show_message(FALSE, '删除联系我们失败', '/contact');
		}
	}

	public function filter($id='')
	{
		//获取已经选中的地址ID
		$selected_ad_ids = array();
		if($id)
		{
			$contact_address = $this->model_contact_address->get_all(array('wid'=>User::$user_id, 'contact_id'=>$id), '', '');
			if($contact_address)
			{
				foreach($contact_address as $ca)
				{
					$selected_ad_ids[] = $ca['address_id'];
				}
			}
		}

		$name = $this->input->get_post('name');
		$prov = $this->input->get_post('prov');
		$city= $this->input->get_post('city');
		$dist= $this->input->get_post('dist');
		$checked_address = $this->input->get_post('checked_address');

		$tpl_data['name'] = $name ? $name : '';
		$tpl_data['prov'] = $prov ? $prov : '';
		$tpl_data['city'] = $city ? $city : '';
		$tpl_data['dist'] = $dist ? $dist : '';
		$checked_address = $checked_address ? $checked_address : array();

		$where = array('wid'=>User::$user_id, 'status'=>0);
		//用于过滤查找
		$qs = array();
		if($name)
		{
			$where['name'] = 'like:'.$name;
			$qs[] = 'name='.$name;
		}
		if($prov)
		{
			$where['prov'] = 'like:'.$prov;
			$qs[] = 'prov='.$prov;
		}
		if($city)
		{
			$where['city'] = 'like:'.$city;
			$qs[] = 'city='.$city;
		}
		if($dist)
		{
			$where['dist'] = 'like:'.$dist;
			$qs[] = 'dist='.$dist;
		}

		$address = $this->model_address->get_all($where, '', '');
		$selected_address = array();
		$unselect_address = array();
		foreach($address as &$row)
		{
			$row['image'] = json_decode($row['image'], TRUE);
			if(in_array($row['id'], $checked_address))
			{
				$selected_address[] = $row;
			}
			elseif(in_array($row['id'], $selected_ad_ids))
			{
				$selected_address[] = $row;
			}
			else
			{
				$unselect_address[] = $row;
			}
		}
		$tpl_data['selected_address'] = $selected_address;
		$tpl_data['unselect_address'] = $unselect_address;

		$this->twig->display('contact/address_table', $tpl_data);
	}
}