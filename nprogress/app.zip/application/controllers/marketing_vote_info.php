<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Marketing_vote_info extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('model_marketing_vote_info');
		$this->load->model('model_marketing_vote');
	}
	
	public function manager($marketing_id = '', $current_page=1) {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}

		$marketing_info = $this->model_marketing_vote->get_row(array('marketing_id'=>$marketing_id));
		$vote_setting = unserialize($marketing_info['vote_setting']);
		$marketing_info = $this->model_marketing_vote->get_row(array('marketing_id'=>$marketing_id));
		$vote_setting = unserialize($marketing_info['vote_setting']);
		$vote_result_arr = array();
		$vote_result_arr = $this->model_marketing_vote_info->get_vote_result(array('marketing_id'=>$marketing_id), '', '', 'choice');

		foreach($vote_setting as &$vs){
			foreach($vote_result_arr as $vr){
				if($vr['choice'] == $vs['choice']){
					$vs = $vr;
				}
			}
			if(!isset($vs['count'])){
				$vs['count'] = 0;
			}
		}
		$vote_result_arr = $vote_setting;

		$this->load->library('pagination');
		$per_page = 8;
		$pagination_config = array(
			'base_url'		=> '/marketing_vote_info/manager/'.$marketing_id,
			'total_rows'	=> count($vote_result_arr),
			'per_page'		=> $per_page,
			'uri_segment'	=> 4,
		);
		$this->pagination->initialize($pagination_config);
		$tpl_data['pagination'] = $this->pagination->create_links();

		$tpl_data['vote_result_arr'] = array_slice($vote_result_arr, (intval($this->uri->segment($pagination_config['uri_segment'], 1))-1)*$per_page, $pagination_config['per_page']);

		$tpl_data['cur_nav'] = 'marketing';
		$this->twig->display('marketing_vote_info/index', $tpl_data);
	}

    public function fake()
    {
        $id = $this->input->get('id');
        !$id && exit('id是必须的');
        $choice = $this->input->get('choice');
        $content = $this->input->get('content');
        $num = $this->input->get('num');

        //读取已有的票数
        $cnum = $this->model_marketing_vote_info->total_rows(array('marketing_id'=>$id, 'choice'=>$choice));
        $rnum = $num - $cnum;

        $n = 0;
        for($i=0; $i<$rnum; $i++) {
            $data['marketing_id'] = $id;
            $data['choice'] = $choice;
            $data['content'] = $content ? $content : '';
            $data['weixin_open_id'] = str_pad('oYFzSt', 28, $i+$cnum);
            $data['dt_add'] = date('Y-m-d H:i:s', time());
            if($this->model_marketing_vote_info->add($data)){
                $n++;
            }
        }
        echo 'success:'.$n;
    }
}