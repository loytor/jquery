<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Class Marketing_coupon
 * @property Model_marketing_coupon $model_marketing_coupon
 * @property Model_marketing $model_marketing
 * @property Model_cate $model_cate
 * @property Model_cate_lists $model_cate_lists
 * @property Model_reply $model_reply
 * @property Model_welcome $model_welcome
 */
class Marketing_coupon extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('model_marketing_coupon');
		$this->load->model('model_marketing');
	}

	public function index(){
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}

		$where_set = array('user_id' => $logged_user_id, 'type'=>'coupon');
		$this->load->library('pagination');
		$pagination_config = array(
			'base_url'		=> '/marketing_coupon/index/',
			'total_rows'	=> $this->model_marketing->total_rows($where_set),
			'per_page'		=> 8,
			'uri_segment'	=> 3,
		);
		$this->pagination->initialize($pagination_config);
		$tpl_data['pagination'] = $this->pagination->create_links();

		$coupon_arr = $this->model_marketing->get_all($where_set, $pagination_config['per_page'], intval($this->uri->segment($pagination_config['uri_segment'], 1)), 'dt_update', 'desc');
		$tpl_data['coupon_arr'] = $coupon_arr;

		$this->twig->display('marketing_coupon/index', $tpl_data);
	}

	public function add() {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$this->load->library('form_validation');
		$this->form_validation->set_rules('title', '优惠活动名称', 'trim|required|max_length[15]|htmlspecialchars');
		$this->form_validation->set_rules('instruction', '优惠详情', 'trim|required');
		if($this->input->post('type') == 1){
			$this->form_validation->set_rules('usenums', '使用次数', 'integer|required');
		}
		$this->form_validation->set_rules('dt_start', '活动有效期开始时间', 'trim|required|htmlspecialchars');
		$this->form_validation->set_rules('dt_end', '活动有效期结束时间', 'trim|required|htmlspecialchars');

		if ($this->form_validation->run()) {
			$data_set['user_id'] = $logged_user_id;
			$data_set['title'] = $this->form_validation->set_value('title');

			$data_set['dt_start'] = $this->form_validation->set_value('dt_start');
			$data_set['dt_end'] = $this->form_validation->set_value('dt_end');

			//判断时间
			if(strtotime($data_set['dt_start']) > time()){
				$data_set['status'] = '未开始';
			}elseif(strtotime($data_set['dt_end']) < time()){
				$data_set['status'] = '已结束';
			}else{
				$data_set['status'] = '已开始';
			}
			$data_set['type'] = 'coupon';

			$add_data_set['marketing_id'] = $this->model_marketing->add($data_set);

			//基础表添加成功 处理附加表
			if($add_data_set['marketing_id']){
				$add_data_set['type'] = $this->input->post('type');
				//处理规则
				$rule = $this->input->post('rule');
				if($add_data_set['type'] == 1){//验证型

					if(!isset($rule['veron'])){
						$rule['veron'] = 0;
						$rule['vercode'] = '';
					}
					$add_data_set['usenums'] = $this->form_validation->set_value('usenums');
					$add_data_set['codeinfo'] = '';
				}elseif($add_data_set['type'] == 2){//出示型
					$rule['vercode'] = '';
					$rule['veron'] = 0;
					$add_data_set['codeinfo'] = '';
				}elseif($add_data_set['type'] == 3){//发放型
					$rule['vercode'] = '';
					$rule['veron'] = 0;
					$add_data_set['usenums'] = 1;
					$add_data_set['codeinfo'] = $this->input->post('codeinfo');
				}
				$add_data_set['rule'] = serialize($rule);

				$add_data_set['rank'] = $this->input->post('rank');
				$add_data_set['instruction'] = $this->form_validation->set_value('instruction');

				$this->model_marketing_coupon->add($add_data_set);
				$this->show_message(TRUE, '优惠券添加成功', '/marketing_coupon');
			}
		}else{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/marketing_coupon/add');
			}
		}
		$tpl_data['cur_nav'] = 'marketing';
		$this->twig->display('/marketing_coupon/add', $tpl_data);
	}

	public function update($marketing_id=''){
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$marketing = $this->model_marketing->get_marketing($marketing_id,'coupon');

		if ( ! $marketing || $marketing['user_id'] != $logged_user_id) {
			$this->show_message(FALSE, '该优惠券不存在', '/marketing_coupon');
		}
		$marketing['rule'] = unserialize($marketing['rule']);

		$tpl_data['marketing'] = $marketing;

		$this->load->library('form_validation');
		$this->form_validation->set_rules('title', '优惠活动名称', 'trim|required|max_length[15]|htmlspecialchars');
		$this->form_validation->set_rules('instruction', '优惠详情', 'trim|required');
		if($this->input->post('type') == 1){
			$this->form_validation->set_rules('usenums', '使用次数', 'integer|required');
		}
		$this->form_validation->set_rules('dt_start', '活动有效期开始时间', 'trim|required|htmlspecialchars');
		$this->form_validation->set_rules('dt_end', '活动有效期结束时间', 'trim|required|htmlspecialchars');

		if ($this->form_validation->run()) {
			$data_set['dt_start'] = $this->form_validation->set_value('dt_start');
			$data_set['dt_end'] = $this->form_validation->set_value('dt_end');
			$data_set['title'] = $this->form_validation->set_value('title');
			//判断时间
			if(strtotime($data_set['dt_start']) > time()){
				$data_set['status'] = '未开始';
			}elseif(strtotime($data_set['dt_end']) < time()){
				$data_set['status'] = '已结束';
			}else{
				$data_set['status'] = '已开始';
			}
			if($this->model_marketing->update(array('id'=>$marketing_id,'user_id'=>$logged_user_id), $data_set)){
				//处理规则
				$rule = $this->input->post('rule');

				$update_data_set['type'] = $this->input->post('type');
				if($update_data_set['type'] == 1){//验证型

					if(!isset($rule['veron'])){
						$rule['veron'] = 0;
						$rule['vercode'] = '';
					}
					$update_data_set['usenums'] = $this->form_validation->set_value('usenums');
					$update_data_set['codeinfo'] = '';
				}elseif($update_data_set['type'] == 2){//出示型
					$rule['vercode'] = '';
					$rule['veron'] = 0;
					$update_data_set['codeinfo'] = '';
				}elseif($update_data_set['type'] == 3){//发放型
					$rule['vercode'] = '';
					$rule['veron'] = 0;
					$update_data_set['usenums'] = 1;
					$update_data_set['codeinfo'] = $this->input->post('codeinfo');
				}

				$update_data_set['rule'] = serialize($rule);

				$update_data_set['rank'] = $this->input->post('rank');
				$update_data_set['instruction'] = $this->form_validation->set_value('instruction');

				$this->model_marketing_coupon->update(array('marketing_id'=>$marketing_id),$update_data_set);

				$this->show_message(TRUE, '更新成功', '/marketing_coupon');
			}

		}else {
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/marketing_coupon/update/'.$marketing_id);
			}
		}
		$tpl_data['cur_nav'] = 'marketing';
		$this->twig->display('marketing_coupon/update', $tpl_data);
	}

	public function stop($marketing_id='') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}

		$data_set['status'] = '已结束';
		$data_set['dt_end'] = date('Y-m-d H:i:s');
		$marketing = $this->model_marketing->get_row(array('id' => $marketing_id, 'user_id' => $logged_user_id));
		if($marketing){
			if($this->model_marketing->update($marketing_id, $data_set)){
				$this->show_message(TRUE, '终止成功', '/marketing_coupon');
			}else{
				$this->show_message(FALSE, '终止失败', '/marketing_coupon');
			}
		}else{
			$this->show_message(TRUE, '不存在该优惠券', '/marketing_coupon');
		}
	}

	public function delete($marketing_id='') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}

		//判断是否是自己发布的
		$marketing = $this->model_marketing->get_row(array('id' => $marketing_id, 'user_id' => $logged_user_id));
		if($marketing){
			if($this->model_marketing->delete($marketing_id)){
				//cate表count_marketing -1, cate_lists表删除
				$this->load->model('model_cate');
				$this->load->model('model_cate_lists');
				if ($marketing['cate_id']) {
					$this->model_cate->count_step($marketing['cate_id'], 'count_marketing', -1);
					$del_data_cate_lists['user_id'] = $logged_user_id;
					$del_data_cate_lists['cate_id'] = $marketing['cate_id'];
					$del_data_cate_lists['type'] = str_replace('marketing_', '', $marketing['type']);
					$del_data_cate_lists['lists_id'] = $marketing_id;
					$this->model_cate_lists->delete($del_data_cate_lists);
				}

				//删除优惠券附加信息
				$this->load->model('model_marketing_coupon');
				$this->model_marketing_coupon->delete(array('marketing_id'=>$marketing_id));

/*				//删除对应的自定义回复
				$this->load->model('model_reply');
				$reply_list = $this->model_reply->reply_list_by_marketing($marketing_id);
				foreach($reply_list as $reply){
					$marketing_arr = json_decode($reply['content']);
					foreach($marketing_arr as $key=>$marketing){
						if($marketing->id == $marketing_id){
							unset($marketing_arr[$key]);
						}
					}
					$content = json_encode($marketing_arr);
					if(count($marketing_arr) > 0){
						$this->model_reply->update($reply['id'], array('content'=>$content));
					}else{
						$this->model_reply->delete($reply['id']);
					}
					$this->model_reply->marketing_delete($reply['id'], $marketing_id);
				}
				//删除对应的welcome
				$this->load->model('model_welcome');
				$welcome = $this->model_welcome->get_row(array('user_id' => $logged_user_id));
				if($welcome){
					$content = json_decode($welcome['content']);
					if($content){
						foreach($content as $k=>$c){
							if(isset($c->marketing_id) && $c->marketing_id == $marketing_id){
								unset($content[$k]);
							}
						}
					}
					$content = json_encode($content);
					$this->model_welcome->update($welcome['id'], array('content'=>$content));
				}*/
				$this->show_message(TRUE, '删除成功', '/marketing_coupon');
			}else{
				$this->show_message(FALSE, '删除失败', '/marketing_coupon');
			}
		}else{
			$this->show_message(FALSE, '非法操作', '/marketing_coupon');
		}
	}

	private function show_message($success, $message, $redirect) {
		if ($this->input->is_ajax_request()) {
			$data = array(
					'success'	=> $success ? 1 : 0,
					'message'	=> strip_tags($message),
			);
			header('Content-type: application/json');
			echo json_encode($data);
		} else {
			$tpl_data = array(
					'message'	=> $message,
					'redirect'	=> $redirect,
			);
			$this->twig->display('show_message', $tpl_data);
		}
		exit;
	}
    
}
