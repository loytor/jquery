<?php
/**
 * Created by PhpStorm.
 * User: llj
 * Date: 14-1-5
 * Time: 上午10:51
 * @property Scene_lottery_model $scene_lottery_model
 * @property Scene_lottery_rotate_model $scene_lottery_rotate_model
 * @property Scene_lottery_record_model $scene_lottery_record_model
 */
class Lottery extends Scene_Controller
{
    private $rotate_status = array(
        -1 => '已结束',
        0 => '未开始',
        1 => '进行中'
    );

    public function index()
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '抽奖功能还未开通', '/u/scene');
            return FALSE;
        }

        $this->load->model('scene_lottery_model');
        $lottery = $this->scene_lottery_model->where(array('scene_id'=>$this->scene['id']))->find();
        if($this->input->post()) {
            $this->form_validation->set_rules('title', '标题', 'required|trim|htmlspecialchars');
            if($this->form_validation->run()) {
                $data['title'] = $this->form_validation->set_value('title');

                if($lottery) {
                    if($this->scene_lottery_model->where(array('scene_id'=>$lottery['scene_id'], 'id'=>$lottery['id']))->edit($data)) {
                        $this->show_message(TRUE, '保存成功', '/u/lottery');
                        return FALSE;
                    } else {
                        $this->show_message(FALSE, '保存失败', '');
                        return FALSE;
                    }
                } else {
                    $data['scene_id'] = $this->scene['id'];
                    $data['dt_add'] = time();
                    $lottery_id = $this->scene_lottery_model->add($data);
                    if($lottery_id) {
                        $this->show_message(TRUE, '保存成功', '/u/lottery');
                        return FALSE;
                    } else {
                        $this->show_message(FALSE, '保存失败', '');
                        return FALSE;
                    }
                }
            } else {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        } else {
            $this->data['lottery'] = $lottery ? $lottery : array();

            $this->load->library('encrypt');
            $token_data = array('user_id' => $this->scene['site_id'], 'time' => time());
            $this->data['token'] = $this->encrypt->encode(serialize($token_data));
            $this->load->view($this->dcm, $this->data);
        }
    }

    /**
     * 游戏轮次设置
     */
/*    public function rotate()
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '抽奖功能还未开通', '/u/scene');
            return FALSE;
        }

        $this->load->model('scene_lottery_model');
        $lottery = $this->scene_lottery_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$lottery) {
            $this->show_message(FALSE, '抽奖还未设置', '/u/lottery');
            return FALSE;
        }

        $this->load->model('scene_lottery_rotate_model');
        $total_rows = $this->scene_lottery_rotate_model->where(array('lottery_id'=>$lottery['id']))->count();
        $pager = $this->_pager($total_rows);
        $list = $this->scene_lottery_rotate_model->where(array('lottery_id'=>$lottery['id']))->order_by('round desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->find_all();

        $this->data['list'] = $list ? $list : array();
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->data['rotate_status'] = $this->rotate_status;
        $this->load->view($this->dcm, $this->data);
    }*/

/*    public function rotate_add()
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '抽奖功能还未开通', '/u/scene');
            return FALSE;
        }

        $this->load->model('scene_lottery_model');
        $lottery = $this->scene_lottery_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$lottery) {
            $this->show_message(FALSE, '抽奖还未设置', '/u/lottery');
            return FALSE;
        }

        $this->load->model('scene_lottery_rotate_model');
        if($this->input->post()) {
            $this->form_validation->set_rules('pnum', '中奖人数', 'required|trim|is_natural_no_zero');
            if($this->form_validation->run()) {
                $data = array();
                $data['lottery_id'] = $lottery['id'];
                $data['round'] = $this->input->post('round');
                $data['status'] = 0;
                $data['pnum'] = $this->form_validation->set_value('pnum');
                $data['sequence'] = $this->input->post('sequence');
                $data['duplication'] = $this->input->post('duplication');

                $pmobile = $this->input->post('pmobile');
                if(!$this->check_mobile($pmobile)) {
                    $this->show_message(FALSE, '手机好格式不正确', '');
                    return FALSE;
                }
                $pmobile = $pmobile ? $pmobile : array();
                $data['pmobile'] = json_encode($pmobile);

                if($this->scene_lottery_rotate_model->add($data)) {
                    $this->show_message(TRUE, '添加成功', '/u/lottery/rotate');
                    return FALSE;
                } else {
                    $this->show_message(FALSE, '添加失败', '');
                    return FALSE;
                }
            } else {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        } else {
            $this->data['round'] = $this->scene_lottery_rotate_model->where(array('lottery_id'=>$lottery['id']))->count();
            $this->load->view($this->dcm, $this->data);
        }
    }*/

/*    public function rotate_edit($id='')
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '抽奖功能还未开通', '/u/scene');
            return FALSE;
        }

        $this->load->model('scene_lottery_model');
        $lottery = $this->scene_lottery_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$lottery) {
            $this->show_message(FALSE, '抽奖还未设置', '/u/lottery');
            return FALSE;
        }

        $this->load->model('scene_lottery_rotate_model');
        if($this->input->post()) {
            $this->form_validation->set_rules('pnum', '中奖人数', 'required|trim|is_natural_no_zero');
            if($this->form_validation->run()) {
                $data = array();
                $data['round'] = $this->input->post('round');
                $data['status'] = 0;
                $data['pnum'] = $this->form_validation->set_value('pnum');
                $data['sequence'] = $this->input->post('sequence');
                $data['duplication'] = $this->input->post('duplication');

                $pmobile = $this->input->post('pmobile');
                if(!$this->check_mobile($pmobile)) {
                    $this->show_message(FALSE, '手机好格式不正确', '');
                    return FALSE;
                }
                $pmobile = $pmobile ? $pmobile : array();
                $data['pmobile'] = json_encode($pmobile);

                if($this->scene_lottery_rotate_model->where(array('id'=>$id, 'lottery_id'=>$lottery['id']))->edit($data)) {
                    $this->show_message(TRUE, '编辑成功', '/u/lottery/rotate');
                    return FALSE;
                } else {
                    $this->show_message(FALSE, '编辑失败', '');
                    return FALSE;
                }
            } else {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        } else {
            $rotate = $this->scene_lottery_rotate_model->where(array('id'=>$id, 'lottery_id'=>$lottery['id']))->find();
            if(!$rotate) {
                $this->show_message(FALSE, '该轮次不存在', '/u/lottery/rotate');
                return FALSE;
            }
            $rotate['pmobile'] = json_decode($rotate['pmobile'], TRUE);
            $this->data['rotate'] = $rotate;
            $this->load->view($this->dcm, $this->data);
        }
    }*/

/*    public function rotate_delete($id='')
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '抽奖功能还未开通', '/u/scene');
            return FALSE;
        }

        $this->load->model('scene_lottery_model');
        $lottery = $this->scene_lottery_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$lottery) {
            $this->show_message(FALSE, '抽奖还未设置', '/u/lottery');
            return FALSE;
        }

        $this->load->model('scene_lottery_rotate_model');
        $rotate = $this->scene_lottery_rotate_model->where(array('id'=>$id, 'lottery_id'=>$lottery['id']))->find();
        if(!$rotate) {
            $this->show_message(FALSE, '该轮次不存在', '/u/lottery/rotate');
            return FALSE;
        }

        if($this->scene_lottery_rotate_model->where(array('id'=>$id, 'lottery_id'=>$lottery['id']))->delete()) {
            $this->scene_lottery_rotate_model->where(array('lottery_id'=>$lottery['id'], 'round >'=>$rotate['round']))->set_dec('round');
            $this->show_message(TRUE, '删除成功', '/u/lottery/rotate');
            return FALSE;
        } else {
            $this->show_message(FALSE, '删除失败', '/u/lottery/rotate');
            return FALSE;
        }
    }*/

    /**
     * @param string $id
     * 重置
     */
    /*public function rotate_reset($id='')
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '抽奖功能还未开通', '/u/scene');
            return FALSE;
        }

        $this->load->model('scene_lottery_model');
        $lottery = $this->scene_lottery_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$lottery) {
            $this->show_message(FALSE, '抽奖还未设置', '/u/lottery');
            return FALSE;
        }

        $this->load->model('scene_lottery_rotate_model');
        $rotate = $this->scene_lottery_rotate_model->where(array('id'=>$id, 'lottery_id'=>$lottery['id']))->find();
        if(!$rotate) {
            $this->show_message(FALSE, '该轮次不存在', '/u/lottery/rotate');
            return FALSE;
        }

        if($this->scene_lottery_rotate_model->where(array('id'=>$id, 'lottery_id'=>$lottery['id']))->edit(array('status'=>0))){
            //清空抽奖的记录
            $this->load->model('scene_lottery_record_model');
            $this->scene_lottery_record_model->where(array('rotate_id'=>$id, 'lottery_id'=>$lottery['id']))->delete();

            $this->show_message(TRUE, '重置成功', '/u/lottery/rotate');
            return FALSE;
        } else {
            $this->show_message(FALSE, '重置失败', '/u/lottery/rotate');
            return FALSE;
        }
    }*/

/*    public function record($rotate_id='')
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '抽奖功能还未开通', '/u/scene');
            return FALSE;
        }

        $this->load->model('scene_lottery_model');
        $lottery = $this->scene_lottery_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$lottery) {
            $this->show_message(FALSE, '抽奖功能还未设置', '');
            return FALSE;
        }

        $this->data['record_list'] = array();

        $this->load->model('scene_lottery_rotate_model');
        $lottery_rotate = $this->scene_lottery_rotate_model->where(array('lottery_id'=>$lottery['id']))->find_all();
        $this->data['lottery_rotate'] = $lottery_rotate ? $lottery_rotate : array();

        if($rotate_id) {

        } elseif($lottery_rotate) {
            $rotate_id = $lottery_rotate[0]['id'];
        } else {
            $rotate_id = 0;
        }

        //中奖记录
        $record_list = array();
        $rotate = $this->scene_lottery_rotate_model->where(array('id'=>$rotate_id))->find();
        if($rotate) {
            $pnum = $rotate['pnum'];
            $this->load->model('scene_lottery_record_model');
            $this->load->model('scene_member_model');
            $where['lottery_id'] = $lottery['id'];
            $where['rotate_id'] = $rotate_id;
            $record_list = $this->scene_lottery_record_model->order_by('dt_record','DESC')->limit($pnum)->where($where)->find_all();
            foreach ($record_list as $key=>$val) {
                $record_list[$key]['mobile'] = $this->scene_member_model->where(array('mid'=>$val['mid']))->get_field('mobile');
            }
        }
        $this->data['record_list'] = $record_list ? $record_list : array();

        $this->data['rotate'] = $rotate;
        $this->load->view($this->dcm, $this->data);
    }

    public function export($rotate_id='')
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '抽奖功能还未开通', '/u/scene');
            return FALSE;
        }

        $this->load->model('scene_lottery_model');
        $lottery = $this->scene_lottery_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$lottery) {
            $this->show_message(FALSE, '抽奖还未设置', '/u/lottery');
            return FALSE;
        }

        $this->load->model('scene_lottery_rotate_model');
        $rotate = $this->scene_lottery_rotate_model->where(array('id'=>$rotate_id))->find();
        if(!$rotate) {
            $this->show_message(FALSE, '没有该轮次', '/u/lottery/record');
            return FALSE;
        }

        $pnum = $rotate['pnum'];
        $this->load->model('scene_lottery_record_model');
        $where['lottery_id'] = $lottery['id'];
        $where['rotate_id'] = $rotate_id;
        $list = $this->scene_lottery_record_model->order_by('dt_record','DESC')->limit($pnum)->where($where)->find_all();

        $round_title = '第'.$rotate['round'].'轮';
        if($list)
        {
            foreach($list as $key=> $item)
            {
                $record_list[$key]['nick_name'] = $item['nick_name'];
                $record_list[$key]['dt_record'] = date('Y-m-d H:i:s', $item['dt_record']);
            }

            $fields = array(
                '#'=>'#',
                'nick_name'=>'昵称',
                'dt_record'=>'时间'
            );
            $this->excel_export('微现场抽奖'.$round_title.'中奖记录', '微现场抽奖'.$round_title.'中奖记录', $fields, $record_list);
        }
        else
        {
            $this->show_message(FALSE, $round_title.'尚无中奖记录可导出', '');
        }
    }*/

    public function record($dt_record='')
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '抽奖功能还未开通', '/u/scene');
            return FALSE;
        }
        $this->load->model('scene_lottery_model');
        $lottery = $this->scene_lottery_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$lottery) {
            $this->show_message(FALSE, '抽奖还未设置', '/u/lottery');
            return FALSE;
        }
        $this->load->model('scene_member_model');
        $this->data['record_list'] = array();
        $this->load->model('scene_lottery_record_model');
        $where['lottery_id'] = $lottery['id'];
        $this->load->model('scene_lottery_rotate_model');
        $new_where = array(
            'scene_lottery_record.lottery_id' => $lottery['id'],
            'scene_member.scene_id' => $this->scene['id']);
        if($dt_record){
            $new_where['scene_lottery_record.rotate_id'] = $dt_record;
        }else{
            $new_where['scene_lottery_record.rotate_id'] = $dt_record = 1;
        }
        //查询轮次
        $this->data['rotate'] = array();
        $rotate = $this->scene_lottery_rotate_model->select('id,lottery_id,round,')->where($where)->find_all();
        //$dts = $this->scene_lottery_record_model->select('dt_record')->where($where)->order_by('dt_record','ASC')->group_by('dt_record')->find_all();

        /*if($dt_record) {
            $where['dt_record'] = $cur_dt = $dt_record;
        } elseif($dts) {
            $where['dt_record'] = $cur_dt = $dts[0]['dt_record'];
        } else {
            $where['dt_record'] = -1;
        }*/
        $total_rows = $this->scene_lottery_record_model->order_by('dt_record','ASC')->where('rotate_id ='.$dt_record)->count();

        $pager = $this->_pager($total_rows);
        $record_list = $this->scene_lottery_record_model->select('scene_lottery_record.*,scene_member.dt_join')
            ->join('scene_member','scene_lottery_record.mid = scene_member.mid','left')
            ->where($new_where)
            ->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->find_all();
        //echo $this->db->last_query();exit;
        //$record_list = $this->scene_lottery_record_model->order_by('dt_record','ASC')->where($where)->limit($pager['limit']['value'], $pager['limit']['offset'])->find_all();
        $this->data['record_list'] = $record_list ? $record_list : array();
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        //根据ID查询当前是第几轮
        $round = $this->scene_lottery_rotate_model->select('id,round')->where("id = $dt_record ")->find();
        $this->data['round'] = $round;
       // $this->data['cur_dt'] = $cur_dt;

        $this->data['dts'] = $dt_record;
        $this->data['rotate'] = $rotate;
        //print_r($this->data);
        $this->load->view($this->dcm, $this->data);
    }

    public function export($dt_record='')
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '抽奖功能还未开通', '/u/scene');
            return FALSE;
        }

        $this->load->model('scene_lottery_model');
        $lottery = $this->scene_lottery_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$lottery) {
            $this->show_message(FALSE, '抽奖还未设置', '/u/lottery');
            return FALSE;
        }

        $this->load->model('scene_lottery_record_model');
        $where['lottery_id'] = $lottery['id'];
        $dts = $this->scene_lottery_record_model->select('dt_record')->where($where)->order_by('dt_record','ASC')->group_by('dt_record')->find_all();

        /*$cur_dt = 0;*/
        if($dt_record) {
            $where['rotate_id'] = $dt_record;
        } else {
            $where['rotate_id'] = 1;
        }

        $record_list = $this->scene_lottery_record_model->order_by('dt_record','ASC')->where($where)->find_all();
        $record_list = $record_list ? $record_list : array();
        if($record_list)
        {
            $fields = array(
                '#'=>'#',
                'nick_name'=>'昵称'
            );

            $this->excel_export('抽奖记录('.$dt_record.')', '抽奖记录('.$dt_record.')', $fields, $record_list);
        }
        else
        {
            $this->show_message(FALSE, '尚无抽奖记录可导出', '');
        }
    }

    /**
     * @param string $dt_record
     * @return bool
     * 删除记录
     */
    public function record_delete($dt_record='')
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '抽奖功能还未开通', '/u/scene');
            return FALSE;
        }

        $this->load->model('scene_lottery_model');
        $lottery = $this->scene_lottery_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$lottery) {
            $this->show_message(FALSE, '抽奖还未设置', '/u/lottery');
            return FALSE;
        }

        $this->load->model('scene_lottery_record_model');
        if($this->scene_lottery_record_model->where(array('lottery_id'=>$lottery['id'], 'rotate_id'=>$dt_record))->delete()) {
            $this->show_message(TRUE, '删除成功', '/u/lottery/record');
            return FALSE;
        } else {
            $this->show_message(TRUE, '删除失败', '/u/lottery/record');
            return FALSE;
        }
    }

    /**
     * 判断中奖人数格式
     */
    private function check_pnum($pnums)
    {
        foreach($pnums as $pnum) {
            if(!$this->form_validation->is_natural($pnum)) {
                return FALSE;
            }
        }
        return TRUE;
    }

    /**
     * 判断手机格式
     */
    private function check_mobile($mobiles)
    {
        if($mobiles) {
            foreach($mobiles as $mobile) {
                if(!valid_mobile($mobile)) {
                    return FALSE;
                }
            }
        }
        return TRUE;
    }

    private function check_func()
    {
        $this->load->model('scene_model');
        $scene = $this->scene_model->where(array('id'=>$this->scene['id']))->find();
        $func = json_decode($scene['func'], TRUE);
        if($func && isset($func['lottery']) && $func['lottery']) {
            return TRUE;
        }
        return FALSE;
    }
}