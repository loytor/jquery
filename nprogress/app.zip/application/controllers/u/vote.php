<?php
/**
 * Created by PhpStorm.
 * User: 111
 * Date: 14-5-8
 * Time: 下午4:48
 */
class Vote extends Scene_Controller
{
    private $rotate_status = array(
        -1 => '已结束',
        0 => '未开始',
        1 => '进行中'
    );

    public function index()
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '投票功能还未开通', '/u/scene');
            return FALSE;
        }

        $this->load->model('scene_vote_model');
        $vote = $this->scene_vote_model->where(array('scene_id'=>$this->scene['id']))->find();
        if($this->input->post()) {
            $this->form_validation->set_rules('title', '标题', 'required|trim|htmlspecialchars');
            if($this->form_validation->run()) {
                $data['title'] = $this->form_validation->set_value('title');
                $data['show_cvote'] = $this->input->post('show_cvote');

                if($vote) {
                    if($this->scene_vote_model->where(array('scene_id'=>$vote['scene_id'], 'id'=>$vote['id']))->edit($data)) {
                        $this->show_message(TRUE, '保存成功', '/u/vote');
                        return FALSE;
                    } else {
                        $this->show_message(FALSE, '保存失败', '');
                        return FALSE;
                    }
                } else {
                    $data['scene_id'] = $this->scene['id'];
                    $data['dt_add'] = time();
                    $vote_id = $this->scene_vote_model->add($data);
                    if($vote_id) {
                        $this->show_message(TRUE, '保存成功', '/u/vote');
                        return FALSE;
                    } else {
                        $this->show_message(FALSE, '保存失败', '');
                        return FALSE;
                    }
                }
            } else {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        } else {
            $this->data['vote'] = $vote ? $vote : array();

            $this->load->library('encrypt');
            $token_data = array('user_id' => $this->scene['site_id'], 'time' => time());
            $this->data['token'] = $this->encrypt->encode(serialize($token_data));
            $this->load->view($this->dcm, $this->data);
        }
    }

    public function rotate()
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '投票功能还未开通', '/u/scene');
            return FALSE;
        }
        $this->load->model('scene_vote_model');
        $vote = $this->scene_vote_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$vote) {
            $this->show_message(FALSE, '投票还未设置', '/u/vote');
            return FALSE;
        }

        $this->load->model('scene_vote_rotate_model');
        $total_rows = $this->scene_vote_rotate_model->where(array('vote_id'=>$vote['id']))->count();
        $pager = $this->_pager($total_rows);
        $list = $this->scene_vote_rotate_model->where(array('vote_id'=>$vote['id']))->order_by('dt_start desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->find_all();

        $this->data['list'] = $list ? $list : array();
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->data['rotate_status'] = $this->rotate_status;
        $this->load->view($this->dcm, $this->data);
    }

    public function rotate_add()
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '投票功能还未开通', '/u/scene');
            return FALSE;
        }
        $this->load->model('scene_vote_model');
        $vote = $this->scene_vote_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$vote) {
            $this->show_message(FALSE, '投票还未设置', '/u/vote');
            return FALSE;
        }

        $this->load->model('scene_vote_rotate_model');
        if($this->input->post()) {
            $this->form_validation->set_rules('title', '标题', 'required|trim|htmlspecialchars|max_length[200]');
            $this->form_validation->set_rules('climit', '每人可投票次数', 'required|trim|is_natural');
            $this->form_validation->set_rules('style', '手机端样式', 'required|integer');
            $this->form_validation->set_rules('rule[from]', '投票规则', 'required|integer');
            $this->form_validation->set_rules('rule[to]', '投票规则', 'required|integer');
            if($this->form_validation->run()) {
                $data = array();
                $data['vote_id'] = $vote['id'];
                $data['title'] = $this->form_validation->set_value('title');
                $data['climit'] = $this->input->post('climit_type') == 0 ? 0 : $this->form_validation->set_value('climit');
                $data['style'] = $this->form_validation->set_value('style');
                $data['rule'] = json_encode($this->input->post('rule'));
                $data['memo'] = $this->input->post('memo');
                $data['status'] = 0;
                $data['dt_add'] = time();

                if($this->scene_vote_rotate_model->add($data)) {
                    $this->show_message(TRUE, '添加成功', '/u/vote/rotate');
                    return FALSE;
                } else {
                    $this->show_message(FALSE, '添加失败', '');
                    return FALSE;
                }
            } else {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        } else {
            $this->load->view($this->dcm, $this->data);
        }
    }

    public function rotate_edit($id='')
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '投票功能还未开通', '/u/scene');
            return FALSE;
        }
        $this->load->model('scene_vote_model');
        $vote = $this->scene_vote_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$vote) {
            $this->show_message(FALSE, '投票还未设置', '/u/shake');
            return FALSE;
        }

        $this->load->model('scene_vote_rotate_model');
        if($this->input->post()) {
            $this->form_validation->set_rules('title', '标题', 'required|trim|htmlspecialchars|max_length[200]');
            $this->form_validation->set_rules('climit', '每人可投票次数', 'required|trim|is_natural');
            $this->form_validation->set_rules('style', '手机端样式', 'required|integer');
            $this->form_validation->set_rules('rule[from]', '投票规则', 'required|integer');
            $this->form_validation->set_rules('rule[to]', '投票规则', 'required|integer');
            if($this->form_validation->run()) {
                $data = array();
                $data['title'] = $this->form_validation->set_value('title');
                $data['climit'] = $this->form_validation->set_value('climit');
                $data['style'] = $this->form_validation->set_value('style');
                $data['rule'] = json_encode($this->input->post('rule'));
                $data['memo'] = $this->input->post('memo');

                if($this->scene_vote_rotate_model->where(array('id'=>$id, 'vote_id'=>$vote['id']))->edit($data)) {
                    $this->show_message(TRUE, '编辑成功', '/u/vote/rotate');
                    return FALSE;
                } else {
                    $this->show_message(FALSE, '编辑失败', '');
                    return FALSE;
                }
            } else {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        } else {
            $rotate = $this->scene_vote_rotate_model->where(array('id'=>$id, 'vote_id'=>$vote['id']))->find();
            if(!$rotate) {
                $this->show_message(FALSE, '该投票轮次不存在', '/u/vote/rotate');
                return FALSE;
            }
            $rotate['rule'] = json_decode($rotate['rule'], TRUE);
            $this->data['rotate'] = $rotate;
            $this->load->view($this->dcm, $this->data);
        }
    }

    public function rotate_delete($id='')
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '投票功能还未开通', '/u/scene');
            return FALSE;
        }
        $this->load->model('scene_vote_model');
        $vote = $this->scene_vote_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$vote) {
            $this->show_message(FALSE, '投票还未设置', '/u/vote');
            return FALSE;
        }

        $this->load->model('scene_vote_rotate_model');
        $rotate = $this->scene_vote_rotate_model->where(array('id'=>$id, 'vote_id'=>$vote['id']))->find();
        if(!$rotate) {
            $this->show_message(FALSE, '该投票轮次不存在', '/u/vote/rotate');
            return FALSE;
        }

        if($this->scene_vote_rotate_model->where(array('id'=>$id, 'vote_id'=>$vote['id']))->delete()) {
            //删除该轮次下的选项
            $this->load->model('scene_vote_item_model');
            $this->scene_vote_item_model->where(array('rotate_id'=>$id))->delete();

            //删除该轮次下的投票记录
            $this->load->model('scene_vote_item_record_model');
            $this->scene_vote_item_record_model->where(array('rotate_id'=>$id))->delete();
            $this->show_message(TRUE, '删除成功', '/u/vote/rotate');
            return FALSE;
        } else {
            $this->show_message(FALSE, '删除失败', '/u/vote/rotate');
            return FALSE;
        }
    }

    /**
     * 查看投票结果
     */
    public function rotate_result($id)
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '投票功能还未开通', '/u/scene');
            return FALSE;
        }
        $this->load->model('scene_vote_model');
        $vote = $this->scene_vote_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$vote) {
            $this->show_message(FALSE, '投票还未设置', '/u/vote');
            return FALSE;
        }

        $this->load->model('scene_vote_rotate_model');
        $rotate = $this->scene_vote_rotate_model->where(array('id'=>$id, 'vote_id'=>$vote['id']))->find();
        if(!$rotate) {
            $this->show_message(FALSE, '该投票轮次不存在', '/u/vote/rotate');
            return FALSE;
        }

        $this->load->model('scene_vote_item_record_model');
        $rs = $this->scene_vote_item_record_model->where(array('rotate_id'=>$id))->find_all();
        if(!$rs) {
            $pager = $this->_pager(0);
            $items = array();
        } else {
            $this->load->model('scene_vote_item_model');
            $total_rows = $this->scene_vote_item_model->where(array('rotate_id'=>$id, 'vote_id'=>$vote['id']))->count();
            $pager = $this->_pager($total_rows);
            $items = $this->scene_vote_item_model->where(array('rotate_id'=>$id, 'vote_id'=>$vote['id']))->limit($pager['limit']['value'], $pager['limit']['offset'])->find_all();
            if($items) {
                foreach($items as &$_item) {
                    $records = $this->scene_vote_item_record_model->where(array('item_id'=>$_item['id']))->find_all();
                    $cvote = 0; //票数
                    foreach($records as $_record) {
                        $cvote += $_record['cvote'];
                    }
                    $_item['cvote'] = $cvote;
                    $_item['img'] = image_full_url($_item['img']);
                }
                usort($items, function($a, $b){
                    if ($a['cvote'] == $b['cvote']) {
                        if($a['code'] == $b['code']) {
                            return 0;
                        } else {
                            return ($a['code'] < $b['code']) ? -1 : 1;
                        }
                    }
                    return ($a['cvote'] > $b['cvote']) ? -1 : 1;
                });
                $latest_item['cvote'] = 0;
                $latest_item['rank'] = 0;
                foreach($items as $key=>&$_item) {
                    if($_item['cvote'] == $latest_item['cvote']) {
                        $_item['rank'] = $latest_item['rank'] ? $latest_item['rank'] : 1;
                    } else {
                        $_item['rank'] = $key+1;
                    }
                    $latest_item = $_item;
                }
            }
        }

        $this->data['record_list'] = $items ? $items : array();
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->data['rotate'] = $rotate;
        $this->load->view($this->dcm, $this->data);
    }

    /**
     * 投票结果详情
     */
    public function rotate_result_detail($item_id='')
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '投票功能还未开通', '/u/scene');
            return FALSE;
        }
        $this->load->model('scene_vote_model');
        $vote = $this->scene_vote_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$vote) {
            $this->show_message(FALSE, '投票还未设置', '/u/vote');
            return FALSE;
        }
        $this->load->model('scene_vote_item_model');
        $item = $this->scene_vote_item_model->where(array('id'=>$item_id))->find();
        if(!$item) {
            $this->show_message(FALSE, '投票选项不存在', '/u/vote/rotate_result/'.$item['rotate_id']);
            return FALSE;
        }

        $this->data['item'] = $item;

        $this->load->model('scene_vote_item_record_model');
        $total_rows = $this->scene_vote_item_record_model->where(array('item_id'=>$item_id, 'vote_id'=>$vote['id']))->count();
        $pager = $this->_pager($total_rows);
        $item_records = $this->scene_vote_item_record_model->where(array('item_id'=>$item_id, 'vote_id'=>$vote['id']))->order_by('cvote desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->find_all();
        $this->data['item_records'] = $item_records ? $item_records : array();
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->load->view($this->dcm, $this->data);
    }

    public function export_result($id)
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '投票功能还未开通', '/u/scene');
            return FALSE;
        }
        $this->load->model('scene_vote_model');
        $vote = $this->scene_vote_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$vote) {
            $this->show_message(FALSE, '投票还未设置', '/u/vote');
            return FALSE;
        }

        $this->load->model('scene_vote_rotate_model');
        $rotate = $this->scene_vote_rotate_model->where(array('id'=>$id, 'vote_id'=>$vote['id']))->find();
        if(!$rotate) {
            $this->show_message(FALSE, '该投票轮次不存在', '/u/vote/rotate');
            return FALSE;
        }

        $this->load->model('scene_vote_item_model');
        $items = $this->scene_vote_item_model->where(array('rotate_id'=>$id, 'vote_id'=>$vote['id']))->find_all();
        if($items) {
            $this->load->model('scene_vote_item_record_model');
            foreach($items as &$_item) {
                $records = $this->scene_vote_item_record_model->where(array('item_id'=>$_item['id']))->find_all();
                $cvote = 0; //票数
                foreach($records as $_record) {
                    $cvote += $_record['cvote'];
                }
                $_item['cvote'] = $cvote;
            }
            usort($items, function($a, $b){
                if ($a['cvote'] == $b['cvote']) {
                    return 0;
                }
                return ($a['cvote'] > $b['cvote']) ? -1 : 1;
            });

            $rule = json_decode($rotate['rule'], TRUE);

            $latest_item['cvote'] = 0;
            $latest_item['rank'] = 0;
            foreach($items as $key => &$_it) {
                if($_it['cvote'] == $latest_item['cvote']) {
                    $_it['rank'] = $latest_item['rank'] ? $latest_item['rank'] : 1;
                } else {
                    $_it['rank'] = $key+1;
                }
                $_it['rank_name'] = '第'.$_it['rank'].'名';
                if($key < $rule['to']) {
                    $_it['status'] = '晋级';
                } else {
                    $_it['status'] = '未晋级';
                }
                $latest_item = $_it;
            }

            $fields = array(
                '#'=>'#',
                'code' => '编号',
                'title' => '名称',
                'cvote' => '票数',
                'rank_name' => '排名',
                'status' => '状态'
            );
            $this->excel_export('微现场投票记录('.$rotate['title'].')', '微现场投票记录('.$rotate['title'].')', $fields, $items);
        } else {
            $this->show_message(FALSE, '尚无投票记录可导出', '');
        }

        $this->load->view($this->dcm, $this->data);
    }

    /**
     * 删除该轮投票记录
     */
    public function rotate_result_delete($rotate_id)
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '投票功能还未开通', '/u/scene');
            return FALSE;
        }
        $this->load->model('scene_vote_model');
        $vote = $this->scene_vote_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$vote) {
            $this->show_message(FALSE, '投票还未设置', '/u/vote');
            return FALSE;
        }

        $this->load->model('scene_vote_rotate_model');
        $rotate = $this->scene_vote_rotate_model->where(array('id'=>$rotate_id, 'vote_id'=>$vote['id']))->find();
        if(!$rotate) {
            $this->show_message(FALSE, '该投票轮次不存在', '/u/vote/rotate');
            return FALSE;
        }

        $this->load->model('scene_vote_item_record_model');
        if($this->scene_vote_item_record_model->where(array('rotate_id'=>$rotate_id, 'vote_id'=>$vote['id']))->delete()) {
            $this->show_message(TRUE, '删除成功', '/u/vote/rotate_result/'.$rotate_id);
            return FALSE;
        } else {
            $this->show_message(TRUE, '删除失败', '/u/vote/rotate_result/'.$rotate_id);
            return FALSE;
        }
    }

    /**
     * 投票选项设置
     */
    public function item($rotate_id='')
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '投票功能还未开通', '/u/scene');
            return FALSE;
        }
        $this->load->model('scene_vote_model');
        $vote = $this->scene_vote_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$vote) {
            $this->show_message(FALSE, '投票还未设置', '/u/shake');
            return FALSE;
        }

        $this->load->model('scene_vote_rotate_model');
        $rotate = $this->scene_vote_rotate_model->where(array('id'=>$rotate_id, 'vote_id'=>$vote['id']))->find();
        if(!$rotate) {
            $this->show_message(FALSE, '该投票轮次不存在', '/u/vote/rotate');
            return FALSE;
        }

        $rotate['rule'] = json_decode($rotate['rule'], TRUE);
        $this->data['rotate'] = $rotate;

        $this->load->model('scene_vote_item_model');
        $total_rows = $this->scene_vote_item_model->where(array('rotate_id'=>$rotate_id, 'vote_id'=>$vote['id']))->count();
        $pager = $this->_pager($total_rows);
        $list = $this->scene_vote_item_model->where(array('rotate_id'=>$rotate_id))->order_by('id asc')->limit($pager['limit']['value'], $pager['limit']['offset'])->find_all();

        $this->data['list'] = $list ? $list : array();
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->load->view($this->dcm, $this->data);
    }

    /**
     * 添加投票选项
     */
    public function item_add($rotate_id='')
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '投票功能还未开通', '/u/scene');
            return FALSE;
        }
        $this->load->model('scene_vote_model');
        $vote = $this->scene_vote_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$vote) {
            $this->show_message(FALSE, '投票还未设置', '/u/vote');
            return FALSE;
        }

        $this->load->model('scene_vote_rotate_model');
        $rotate = $this->scene_vote_rotate_model->where(array('id'=>$rotate_id, 'vote_id'=>$vote['id']))->find();
        if(!$rotate) {
            $this->show_message(FALSE, '该投票轮次不存在', '/u/vote/rotate');
            return FALSE;
        }

        $rule = json_decode($rotate['rule'], TRUE);

        $this->load->model('scene_vote_item_model');
        $count = $this->scene_vote_item_model->where(array('rotate_id'=>$rotate_id, 'vote_id'=>$vote['id']))->count();
        if($count >= intval($rule['from'])) {
            $this->show_message(FALSE, '根据您设置的投票规则, 投票选项最多只有'.$rule['from'].'项', '/u/vote/item/'.$rotate_id);
            return FALSE;
        }

        if($this->input->post()) {
            $this->form_validation->set_rules('code', '编号', 'required|trim|htmlspecialchars|max_length[100]');
            $this->form_validation->set_rules('title', '名称', 'required|trim|htmlspecialchars|max_length[200]');
            $this->form_validation->set_rules('img', '图片', 'required|trim|callback_check_image');
            $this->form_validation->set_rules('listorder', '排序', 'trim|is_natural');
            if($this->form_validation->run()) {
                $data = array();
                $data['vote_id'] = $vote['id'];
                $data['rotate_id'] = $rotate_id;
                $data['code'] = $this->form_validation->set_value('code');
                $data['title'] = $this->form_validation->set_value('title');
                $data['img'] = $this->form_validation->set_value('img');
                $data['memo'] = $this->input->post('memo');
                $data['listorder'] = $this->form_validation->set_value('listorder');

                if($this->scene_vote_item_model->add($data)) {
                    $this->show_message(TRUE, '添加成功', '/u/vote/item/'.$rotate_id);
                    return FALSE;
                } else {
                    $this->show_message(FALSE, '添加失败', '');
                    return FALSE;
                }
            } else {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        } else {
            $this->load->library('encrypt');
            $token_data = array('user_id' => $this->scene['site_id'], 'time' => time());
            $this->data['token'] = $this->encrypt->encode(serialize($token_data));
            $this->data['rotate_id'] = $rotate_id;
            $this->load->view($this->dcm, $this->data);
        }
    }

    /**
     * @param string $rotate_id
     * 编辑投票选项
     */
    public function item_edit($item_id='')
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '投票功能还未开通', '/u/scene');
            return FALSE;
        }
        $this->load->model('scene_vote_model');
        $vote = $this->scene_vote_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$vote) {
            $this->show_message(FALSE, '投票还未设置', '/u/vote');
            return FALSE;
        }

        $this->load->model('scene_vote_item_model');
        $item = $this->scene_vote_item_model->where(array('id'=>$item_id, 'vote_id'=>$vote['id']))->find();
        if(!$item) {
            $this->show_message(FALSE, '该投票选项不存在', '/u/vote/item');
            return FALSE;
        }

        if($this->input->post()) {
            $this->form_validation->set_rules('code', '编号', 'required|trim|htmlspecialchars|max_length[100]');
            $this->form_validation->set_rules('title', '名称', 'required|trim|htmlspecialchars|max_length[200]');
            $this->form_validation->set_rules('img', '图片', 'required|trim|callback_check_image');
            $this->form_validation->set_rules('listorder', '排序', 'trim|is_natural');
            if($this->form_validation->run()) {
                $data = array();
                $data['code'] = $this->form_validation->set_value('code');
                $data['title'] = $this->form_validation->set_value('title');
                $data['img'] = $this->form_validation->set_value('img');
                $data['memo'] = $this->input->post('memo');
                $data['listorder'] = $this->form_validation->set_value('listorder');

                if($this->scene_vote_item_model->where(array('vote_id'=>$vote['id'], 'id'=>$item_id))->edit($data)) {
                    $this->show_message(TRUE, '编辑成功', '/u/vote/item/'.$item['rotate_id']);
                    return FALSE;
                } else {
                    $this->show_message(FALSE, '编辑失败', '');
                    return FALSE;
                }
            } else {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        } else {
            $this->load->library('encrypt');
            $token_data = array('user_id' => $this->scene['site_id'], 'time' => time());
            $this->data['token'] = $this->encrypt->encode(serialize($token_data));
            $this->data['item'] = $item;
            $this->load->view($this->dcm, $this->data);
        }
    }

    public function item_delete($item_id='')
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '投票功能还未开通', '/u/scene');
            return FALSE;
        }
        $this->load->model('scene_vote_model');
        $vote = $this->scene_vote_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$vote) {
            $this->show_message(FALSE, '投票还未设置', '/u/vote');
            return FALSE;
        }

        $this->load->model('scene_vote_item_model');
        $item = $this->scene_vote_item_model->where(array('id'=>$item_id, 'vote_id'=>$vote['id']))->find();
        if(!$item) {
            $this->show_message(FALSE, '该投票选项不存在', '/u/vote/item');
            return FALSE;
        }

        if($this->scene_vote_item_model->where(array('id'=>$item_id, 'vote_id'=>$vote['id']))->delete()) {
            $this->rest_remove($item['img']);
            $this->show_message(TRUE, '删除成功', '/u/vote/item/'.$item['rotate_id']);
            return FALSE;
        } else {
            $this->show_message(FALSE, '删除失败', '/u/vote/item/'.$item['rotate_id']);
            return FALSE;
        }
    }


    private function check_func()
    {
        $this->load->model('scene_model');
        $scene = $this->scene_model->where(array('id'=>$this->scene['id']))->find();
        $func = json_decode($scene['func'], TRUE);
        if($func && isset($func['vote']) && $func['vote']) {
            return TRUE;
        }
        return FALSE;
    }
}