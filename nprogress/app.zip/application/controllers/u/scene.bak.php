<?php
/**
 * Created by PhpStorm.
 * User: andery
 * Date: 14-1-5
 * Time: 上午9:27
 */

class Scene extends Scene_Controller
{
    protected $mongo_table = 'scene_fields';

    public function index()
    {
        if($this->input->post()) {
            /*$this->form_validation->set_rules('title', '标题', 'required|trim|max_length[20]|htmlspecialchars');*/
            /*$this->form_validation->set_rules('code', '活动关键词', 'required|trim|max_length[30]|callback_code_check['.$this->scene['code'].']');*/
            $this->form_validation->set_rules('top_title', '顶部标题', 'required|trim|htmlspecialchars|callback_top_title_check');
            $this->form_validation->set_rules('bg_type', '背景图片', 'required');
            if($this->input->post('auto_join') == 1) {
                $this->form_validation->set_rules('auto_time', '自动报名限制时间', 'trim|is_natural_no_zero');
            }
            if($this->form_validation->run()) {
                $data = array();
                /*$data['title'] = $this->form_validation->set_value('title');*/
                /*$data['code'] = $this->form_validation->set_value('code');*/
                $data['top_title'] = $this->form_validation->set_value('top_title');
                $data['bg_type'] = $this->form_validation->set_value('bg_type');
                $data['custom_bg_img'] = $this->input->post('custom_bg_img');
                $data['article_img'] = $this->input->post('article_img');
                $data['top_img'] = $this->input->post('top_img');
                $data['bottom_img'] = $this->input->post('bottom_img');
                $data['top_font_size'] = $this->input->post('top_font_size');
                $data['chistory'] = $this->input->post('chistory');
                $navbar = array('wall'=>0, 'lottery'=>0, 'lottery_free'=>0, 'shake'=>0, 'shake_free'=>0);
                $post_navbar = $this->input->post('navbar') ? $this->input->post('navbar') : array();
                $navbar = array_merge($navbar, $post_navbar);
                $data['navbar'] = json_encode($navbar);
                $data['auto_join'] = $this->input->post('auto_join');
                if($data['auto_join'] == 1) {
                    $data['auto_time'] = $this->form_validation->set_value('auto_time');
                } else {
                    $data['auto_time'] = 0;
                }
                $data['condition'] = $this->input->post('condition');
                $this->load->model('scene_model');
                if($this->scene_model->where(array('site_id'=>$this->scene['site_id'], 'id'=>$this->scene['id']))->edit($data)) {
                    $scene = $this->scene_model->find($this->scene['id']);
                    $this->session->set_userdata('scene', $scene);
                    $this->show_message(TRUE, '保存成功', '/u/scene');
                    return FALSE;
                } else {
                    $this->show_message(FALSE, '保存失败', '');
                    return FALSE;
                }
            } else {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        } else {
            $this->load->library('encrypt');
            $token_data = array('user_id' => $this->scene['site_id'], 'time' => time());
            $this->data['token'] = $this->encrypt->encode(serialize($token_data));
            $this->data['scene'] = $this->scene;
            $this->data['scene_func'] = json_decode($this->data['scene']['func'], true);
            $this->data['scene_navbar'] = json_decode($this->data['scene']['navbar'], true);
            $this->site_info = $this->user_model->find($this->scene['site_id']);
            $this->data['scene_url'] = $this->site_info['all_domain'] ? $this->site_info['all_domain'].'/activity/' : "http://".$this->site_info['domain'].BASE_DOMAIN.'/activity/';


            $this->load->library('Mongo_db');
            $this->load->config('fields');
            $normal_field_types = $this->config->item('normal_field_types');
            $custom_field_types = $this->config->item('custom_field_types');

            $fieldList = $this->mongo_db->where(array('site_id'=>$this->scene['site_id'],'scene_id'=>(int)$this->scene['id'],'status'=>1))
                ->order_by(array('sort', 'DESC'))
                ->get($this->mongo_table);
            foreach($fieldList as &$item)
            {
                $item['name'] = isset($normal_field_types[$item['name']]) ? $normal_field_types[$item['name']] : $custom_field_types[$item['name']];
            }
            $this->data['fieldList'] = $fieldList;
            $this->data['normal_field_types'] = $normal_field_types;
            $this->data['custom_field_types'] = $custom_field_types;

            $this->load->view($this->dcm, $this->data);
        }
    }

    public function diy()
    {
        $this->load->model('scene_model');
        if ($this->input->post()) {
            $diy_css = $this->input->post('diy_css');
            $this->scene_model->where(array('site_id'=>$this->scene['site_id'], 'id'=>$this->scene['id']))->edit(array('diy_css'=>$diy_css));
            $this->show_message(TRUE, '保存成功', '/u/scene/diy');
            return FALSE;
        } else {
            $this->data['diy_css'] = $this->scene_model->get_field('diy_css', array('where'=>array('site_id'=>$this->scene['site_id'], 'id'=>$this->scene['id'])));
            $this->load->view($this->dcm, $this->data);
        }
    }

    public function signin($scene_id='')
    {

        $this->check_scene();

        $this->load->model('scene_model');
        if ($this->input->post()) {
            $passwd = $this->input->post('passwd');
            $scene = $this->scene_model->where(array('id' => $scene_id, 'password' => md5($passwd)))->find();
            if ($scene) {
                $this->session->set_userdata('scene', $scene);
                redirect('u/scene/index/'.$scene_id);
            } else {
                redirect('u/scene/signin/'.$scene_id);
            }
        } else {
            $this->data['scene'] = $this->scene_model->find($scene_id);
            if (!$this->data['scene']) {
                echo '该微现场不存在！';exit;
            }
            $this->load->view($this->dcm, $this->data);
        }
    }

    public function top_title_check($str)
    {
        $str = htmlspecialchars_decode($str);
        $res = TRUE;
        if($str){
            $tp_arr = explode(PHP_EOL, $str);
            foreach($tp_arr as $tp) {
                if(mb_strlen($tp) > 20) {
                    $this->form_validation->set_message('top_title_check', '%s每条不能超过20字');
                    $res = FALSE;
                }
            }
        } else {
            $this->form_validation->set_message('top_title_check', '%s不能为空');
            $res = FALSE;
        }
        return $res;
    }

    private function check_scene()
    {
        $this->load->model('scene_model');
        $scene_id = $this->input->get('scene_id');
        $scene = $this->scene_model->find($scene_id);
        if(!$scene) {
            echo '该微现场不存在！';exit;
        }
    }

    public function code_check($code, $cur_code='')
    {
        $this->load->model('scene_model');
        $where['site_id'] = $this->scene['site_id'];
        $where['code'] = $code;
        $cur_code && $where['code != '] = $cur_code;
        $scene = $this->scene_model->where($where)->find();
        if($scene) {
            $this->form_validation->set_message('code_check', '%s不能重复');
            return FALSE;
        }
        return TRUE;
    }

    public function logout()
    {
        $this->session->unset_userdata('scene');
    }


    /**
     * @name ajax请求相关参数设置
     * @param string $id
     */
    public function params($id = '')
    {
        $this->load->library('Mongo_db');
        if($id) {
            $field = $this->mongo_db->where(array("_id"=>new MongoId("$id"), 'site_id'=>$this->scene['site_id']))->get_one($this->mongo_table);
            if(!$field) {
                $this->show_message(FALSE, '没有该字段', 1);
            }
            $this->data['field'] = $field;
        }
        $type = $this->input->post('type');
        $this->data['type'] = $type;
        return $this->load->view('c/common/params', $this->data);
    }

    public function field_submit()
    {
        $this->load->library('Mongo_db');

        //如果是编辑
        $_id = $this->input->post('_id');
        if($_id)
        {
            $field = $this->mongo_db->where(array("_id"=>new MongoId("$_id"), 'site_id'=>$this->scene['site_id']))->get_one($this->mongo_table);
            if(!$field) {
                $this->ajax_return(array('error'=>1,'msg'=>'该内容不存在'));
            }
        }
        if ($this->input->post())
        {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('name', '字段类型', 'trim|required');
            $this->form_validation->set_rules('value', '字段名称', 'trim|required');
            if ( $this->form_validation->run() )
            {
                $data = $this->input->post('data');
                if(isset($data['setting']) && isset($data['setting']['options'])) {
                    $data['setting']['options'] = explode(PHP_EOL, $data['setting']['options']);
                    if(isset($data['setting']) && isset($data['setting']['defaultvalue']) && $data['setting']['defaultvalue']) {
                        if(!in_array($data['setting']['defaultvalue'], $data['setting']['options'])) {
                            $this->ajax_return(array('error'=>1,'msg'=>'默认值必须是选项里的值'));
                        }
                    }
                }
                $data['name'] = $this->form_validation->set_value('name');
                $data['value'] = $this->form_validation->set_value('value');
                $data['must'] = (int)$this->input->post('must');

                $data['sort'] = (int)$this->input->post('sort');
                $data['type'] = $this->input->post('type');

                $data['site_id'] = $this->scene['site_id'];
                $data['status'] = 1;

                $success = 0;

                $data['scene_id'] = (int)$this->scene['id'];
                //导出字段 (此处排除status，为了ex_key不重复)
                $count = $this->mongo_db->where(array('scene_id'=>(int)$this->scene['id'],'site_id'=>$this->scene['site_id'],'type'=>$data['type']))->count($this->mongo_table);
                $num = $count+1;
                $data['ex_key'] = $data['type'].$num;

                if(isset($field) && $field)
                {
                    if($this->mongo_db->where(array("_id"=>new MongoId($_id)))->set($data)->update($this->mongo_table))
                    {
                        $success = 1;
                    }
                }
                else
                {
                    if($result = $this->mongo_db->insert($this->mongo_table, $data)) {
                        $success = 1;
                    }
                    $_id = (string)new MongoId($result);
                }

                if($success == 1) {
                    $this->load->config('fields');
                    $normal_field_types = $this->config->item('normal_field_types');
                    $custom_field_types = $this->config->item('custom_field_types');
                    $data['name'] = isset($normal_field_types[$data['type']]) ? $normal_field_types[$data['type']] : $custom_field_types[$data['type']];
                    $data['must'] = $data['must'] ? '是' : '否';
                    $data['_id'] = $_id;
                    $this->ajax_return(array('error'=>0,'data'=>$data));
                } else {
                    $this->ajax_return(array('error'=>1,'msg'=>'添加失败'));
                }
            }
            else
            {
                $errors = validation_errors();
                if ($errors) {
                    $this->ajax_return(array('error'=>1,'msg'=>'未填写完整!'));
                }
            }
        }
    }

    public function field_edit($id = '')
    {
        $this->load->library('Mongo_db');
        if($id) {
            $field = $this->mongo_db->where(array("_id"=>new MongoId($id), 'site_id'=>$this->scene['site_id']))->get_one($this->mongo_table);
            $this->data['field'] = $field;
        }
        $this->load->config('fields');
        $this->data['normal_field_types'] = $this->config->item('normal_field_types');
        $this->data['custom_field_types'] = $this->config->item('custom_field_types');
        return $this->load->view($this->dcm, $this->data);
    }

    public function field_del(){
        $_id = $this->input->post('_id');
        if($_id)
        {
            $this->load->library('Mongo_db');
            $field = $this->mongo_db->where(array("_id"=>new MongoId("$_id"), 'site_id'=>$this->scene['site_id']))->get_one($this->mongo_table);
            if(!$field) {
                $this->ajax_return(array('error'=>1,'msg'=>'该内容不存在'));
            }
            if($this->mongo_db->where(array("_id"=>new MongoId("$_id")))->set(array('status'=>0))->update($this->mongo_table)) {
                $this->ajax_return(array('error'=>0,'msg'=>'成功'));
            } else {
                $this->ajax_return(array('error'=>1,'msg'=>'失败'));
            }
        }
        else
        {
            $this->ajax_return(array('error'=>1,'msg'=>'非法提交'));
        }
    }

    public function stat()
    {
        $this->load->model('scene_member_model');

        $where = array('scene_id'=>$this->scene['id']);

        $total = $this->scene_member_model->where($where)->count();

        $query_arr = array();
        $query_string = implode('&', $query_arr);
        $pager = $this->_pager($total, array('base_url' => site_url($this->uri->uri_string().'?').$query_string));
        $list = array();
        if($total > 0)
        {
            $list = $this->scene_member_model->where($where)->order_by('id','desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->find_all();
        }

        $this->data['list'] = $list ? $list : array();
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->load->view($this->dcm, $this->data);
    }

    public function export()
    {
        $this->load->model('scene_member_model');

        $where = array('scene_id'=>$this->scene['id']);

        $limit_to = $this->input->get('limit_to') ? $this->input->get('limit_to') : 100 ;
        $limit_from = $this->input->get('limit_from') ? $this->input->get('limit_from') : 0;;

        $list = $this->scene_member_model->where($where)->order_by('id','desc')->limit($limit_to, $limit_from)->find_all();
        $record_list = array();
        if($list)
        {
            foreach($list as $key=> $item)
            {
                $record_list[$key]['nick_name'] = $item['nick_name'];

                $content_str = '';
                if($item['fields']){
                    $content = json_decode($item['fields'],true);
                    if($content){
                        foreach($content as $_item){
                            $content_str .= $_item['name'].'：'.$_item['value']."\r\n";
                        }
                    }
                }
                $record_list[$key]['content'] = $content_str;

                $record_list[$key]['dt_join'] = date('Y-m-d H:i:s', $item['dt_join']);
            }

            $fields = array(
                '#'=>'#',
                'nick_name'=>'昵称',
                'content' => '个人信息',
                'dt_join' => '时间',
            );
            $this->excel_export('微现场用户统计', '微现场用户统计', $fields, $record_list);
        }
        else
        {
            $this->show_message(FALSE, '尚无记录可导出', '');
        }
    }
} 