<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Enroll_record extends Manage_Controller
{
    protected $enroll = array();
    protected $method = '';
    
    public function __construct()
    {
        parent::__construct();
        $this->check_enroll();
        $this->method = $this->router->fetch_method();
        
        $this->check_login();
    }
    
    public function index()
    {
        if( $this->input->get('export') ){
            $this->export();exit;
        }
        
        $this->load->model('enroll_record_model');
        $where = "enroll_id = ".$this->enroll['id'];
        
        $search_url = site_url($this->uri->uri_string().'?');
        $search_url .= '&enroll_id='.$this->enroll['id'];
        
        $search['start_time'] = trim($this->input->get('start_time'));
        $search['end_time'] = trim($this->input->get('end_time'));
        $search['mobile'] = trim($this->input->get('mobile'));
        $search['status'] = trim($this->input->get('status'));
        //时间
        if( $search['start_time']&&( strtotime($search['start_time']) ) ){
            $where .= " AND add_time >= ".strtotime($search['start_time']);
            $search_url .= '&start_time='.$search['start_time']; 
        }
        if( $search['end_time']&&( strtotime($search['end_time']) ) ){
            $where .= " AND add_time <= ".strtotime($search['end_time']);
            $search_url .= '&end_time='.$search['end_time'];
        }
        if( $search['mobile'] ){
            $where .= " AND mobile LIKE '%".$search['mobile']."%' ";
            $search_url .= '&mobile='.$search['mobile'];
        }
        if( $search['status'] ){
            $search_url .= '&status='.$search['status'];
            if( $search['status']==1 ){//已签到
                $where .= " AND is_registration = 1";
            }
            if( $search['status']==2 ){//未签到
                $where .= " AND is_registration = 0";
            }
        }
        
        $total_rows = $this->enroll_record_model->where($where)->count();
        $pager = $this->_pager($total_rows,array('per_page'=>15,'base_url'=>$search_url));
        
        
        $list = $this->enroll_record_model->where($where)
            ->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->order_by('id desc')->find_all();
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        
        $this->data['search'] = $search;
        
        $this->data['enroll'] = array(
            'id' => $this->enroll['id'],
            'title' => $this->enroll['title'],
            'regist_method' => json_decode($this->enroll['regist_method'],true)
        );
        
        $this->load->view($this->dcm, $this->data);
    }
    
    //导出
    public function export()
    {
        $this->load->model('enroll_record_model');
        $where = "enroll_id = ".$this->enroll['id'];
        
        $search_url = site_url($this->uri->uri_string().'?');
        $search_url .= '&enroll_id='.$this->enroll['id'];
        
        $search['start_time'] = trim($this->input->get('start_time'));
        $search['end_time'] = trim($this->input->get('end_time'));
        $search['mobile'] = trim($this->input->get('mobile'));
        $search['status'] = trim($this->input->get('status'));
        //时间
        if( $search['start_time']&&( strtotime($search['start_time']) ) ){
            $where .= " AND add_time >= ".strtotime($search['start_time']);
            $search_url .= '&start_time='.$search['start_time']; 
        }
        if( $search['end_time']&&( strtotime($search['end_time']) ) ){
            $where .= " AND add_time <= ".strtotime($search['end_time']);
            $search_url .= '&end_time='.$search['end_time'];
        }
        if( $search['mobile'] ){
            $where .= " AND mobile LIKE '%".$search['mobile']."%' ";
            $search_url .= '&mobile='.$search['mobile'];
        }
        if( $search['status'] ){
            $search_url .= '&status='.$search['status'];
            if( $search['status']==1 ){//已签到
                $where .= " AND is_registration = 1";
            }
            if( $search['status']==2 ){//未签到
                $where .= " AND is_registration = 0";
            }
        }
        $list = $this->enroll_record_model->where($where)
            ->order_by('id desc')->find_all();
        if( $list ){
            $exportData = array();

            /***导出内容编辑***/
            $fields = array(
                '#'=>'#',
                'mobile'=>'手机号码',
                'content' => '报名详情'
            );
            foreach($list as $k => $_list){
                $exportData[$k]['mobile'] = $_list['mobile'];
                $exportData[$k]['code'] = $_list['code'];
                if($_list['content']){
                    $content = json_decode($_list['content'],true);
                    $content_str = '';
                    foreach($content as $_item){
                        if(!isset($_item['value'])){
                            $_item['value'] = '';
                        }
                        $content_str .= (isset($_item['name']) ? $_item['name'] : 'name').'：'.$_item['value']."\r\n";
                    }
                    $exportData[$k]['content'] = $content_str;
                }else{
                    $exportData[$k]['content'] = '';
                }
                $exportData[$k]['add_time'] = date('Y-m-d H:i:s',$_list['add_time']);
                $exportData[$k]['registration_time'] = $_list['registration_time'] ? date('Y-m-d H:i:s',$_list['registration_time']) : '';
                $exportData[$k]['remark'] = $_list['remark'];
                $exportData[$k]['is_registration'] = '';
                if( $_list['is_registration']==0 ){
                    $exportData[$k]['is_registration'] = '未签到';
                }else if( $_list['is_registration']==1 ){
                    $exportData[$k]['is_registration'] = '已签到';
                }
                
            }
            /***导出内容编辑***/
            
            $fields['add_time'] = '报名时间';
            $fields['is_registration'] = '签到状态';
            $fields['registration_time'] = '签到时间';
            $fields['remark'] = '备注';
            $this->excel_export('报名统计列表', '报名统计列表', $fields, $exportData);
        }
    }
    
    /**
     * @name 查看报名者详情
     * @param $id
     * @return bool
     */
    public function staView($id = '')
    {
        $this->load->model('enroll_record_model');
        $record = $this->enroll_record_model->where(array('id'=>$id,'enroll_id'=>$this->enroll['id']))->find();
        
        $this->data['enroll'] = $this->enroll;
        $record['content'] = $record['content'] ? json_decode($record['content'],true) : '';
        if( $this->input->post() ){
            $remark = trim($this->input->post('remark',true));
            if( mb_strlen($remark)>200 ){
                return $this->show_message(FALSE, '备注请不要超过200个字');
            }
            if( $this->enroll_record_model->where(array('id'=>$id,'enroll_id'=>$this->enroll['id']))->edit(array('remark'=>$remark)) ){
                return $this->show_message(TRUE, '保存成功','/u/enroll_record?enroll_id='.$this->enroll['id']);
            }else{
                return $this->show_message(FALSE, '保存失败');
            }
        }
        
        $this->data['info'] = $record;
        $this->load->view($this->dcm, $this->data);
    }
    
    public function signin()
    {   
        $this->load->model('enroll_model');
        if ($this->input->post()) {
            $passwd = $this->input->post('passwd');
            if( $passwd==$this->enroll['manage_password'] ){
                $this->session->set_userdata('enroll_info', array(
                    'id' => $this->enroll['id']
                ));
                redirect('u/enroll_record/index?enroll_id='.$this->enroll['id']);
            }else{
                return $this->show_message(FALSE, '密码错误，请重新输入');
            }
        } else {
            $this->data['enroll_title'] = $this->enroll['title'];
            $this->load->view($this->dcm, $this->data);
        }
    }
    
    private function check_login()
    {
        if( !$this->session->userdata('enroll_info') ){
            if( $this->method!='signin' ){
                redirect('u/enroll_record/signin?enroll_id='.$this->enroll['id']);
            }
        }else{
            $enroll_info = $this->session->userdata('enroll_info');
            if( $this->enroll['id']!=$enroll_info['id'] ){
                $this->session->unset_userdata('enroll_info');
                redirect('u/enroll_record/signin?enroll_id='.$this->enroll['id']);
            }
        }
    }
    
    private function check_enroll()
    {
        $this->load->model('enroll_model');
        $enroll_id = $this->input->get('enroll_id');
        !$enroll_id && exit('非法访问');
        $enroll = $this->enroll_model->where(array())->find($enroll_id);
        if(!$enroll) {
            echo '该微报名不存在！';exit;
        }
        if( $enroll['requir_regist']!=1 ){
            echo '该微报名没有签到！';exit;
        }
        $this->enroll = $enroll;
    }
    
}
