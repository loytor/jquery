<?php
/**
 * Created by PhpStorm.
 * User: 111
 * Date: 14-6-21
 * Time: 上午11:42
 */

class Wedding extends Manage_Controller
{
    protected $wedding = array();
    protected $method = '';

    public function __construct()
    {
        parent::__construct();
        $this->method = $this->router->fetch_method();
        if( $this->method!='signin' ){
            $this->check_login();
        }
    }

    public function index()
    {
        $wedding = $this->wedding;
        if( $this->input->post() ){
            $this->form_validation->set_rules('groom_name', '新郎名字', 'trim|required|max_length[30]');
            $this->form_validation->set_rules('bride_name', '新娘名字', 'trim|required|max_length[30]');
            $this->form_validation->set_rules('wedding_title', '喜帖标题', 'trim|max_length[30]');
            $this->form_validation->set_rules('wedding_img', '首页图片', 'trim|max_length[255]|callback__check_image');
            $this->form_validation->set_rules('tpl', '喜帖模版', 'trim|max_length[30]');
            $this->form_validation->set_rules('background_img', '封面图片', 'trim|max_length[255]|callback__check_image');
            $this->form_validation->set_rules('share_img', '分享图标', 'trim|max_length[255]|callback__check_image');
            $this->form_validation->set_rules('share_intro', '分享描述', 'trim|max_length[200]');
            $this->form_validation->set_rules('video', '视频', 'trim|max_length[65500]|htmlspecialchars');
            $this->form_validation->set_rules('dt_name', '宴会时间名称', 'trim|max_length[50]');
            $this->form_validation->set_rules('dt_day', '宴会时间', 'trim|max_length[100]');
            $this->form_validation->set_rules('address_name', '宴会地点名称', 'trim|max_length[50]');
            $this->form_validation->set_rules('address', '宴会地点', 'trim|max_length[100]');
            $this->form_validation->set_rules('tele_name', '联系我们名称', 'trim|max_length[50]');
            $this->form_validation->set_rules('tele', '联系我们', 'trim|max_length[100]');
            $this->form_validation->set_rules('declarations', '新人寄语', 'trim|max_length[65500]|htmlspecialchars');
            if ( $this->form_validation->run() ){
                $save_data['groom_name'] = $this->form_validation->set_value('groom_name');
                $save_data['bride_name'] = $this->form_validation->set_value('bride_name');
                $save_data['wedding_title'] = $this->form_validation->set_value('wedding_title');
                $save_data['wedding_img'] = $this->form_validation->set_value('wedding_img');
                $save_data['tpl'] = $this->form_validation->set_value('tpl');

                //背景音乐
                $music_is_sys = $this->input->post('music_is_sys');
                if( $music_is_sys ){
                    $music = $this->input->post('music_sys');
                }else{
                    $music = $this->input->post('music');
                }
                $save_data['music'] = $music;
                $save_data['music_is_sys'] = $music_is_sys ? 1 : 0;

                $save_data['background_img'] = $this->form_validation->set_value('background_img');
                $save_data['share_img'] = $this->form_validation->set_value('share_img');
                $save_data['share_intro'] = $this->form_validation->set_value('share_intro');
                $save_data['video'] = $this->form_validation->set_value('video');
                $save_data['declarations'] = $this->form_validation->set_value('declarations');

                //相册
                $album_img = $this->input->post('album_img');
                if( $album_img ){
                    $save_data['album_img'] = json_encode($album_img);
                }
                $save_data['dt_name'] = $this->form_validation->set_value('dt_name');
                $save_data['dt_day'] = $this->form_validation->set_value('dt_day');

                //地址
                $save_data['address_name'] = $this->form_validation->set_value('address_name');
                $save_data['address'] = $this->form_validation->set_value('address');
                $lat = $this->input->post('lat');
                $lng = $this->input->post('lng');
                $save_data['lat'] = $lat;
                $save_data['lng'] = $lng;

                //接待电话
                $save_data['tele_name'] = $this->form_validation->set_value('tele_name');
                $save_data['tele'] = $this->form_validation->set_value('tele');

                $save_data['dt_update'] = time();
                if( $this->wedding_list_model->where(array('id'=>$wedding['id']))->edit($save_data) ){
                    return $this->show_message(TRUE, '修改成功', '/u/wedding');
                }else{
                    return $this->show_message(FALSE, '修改失败', '');
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    return $this->show_message(FALSE, $errors, '');
                }
            }
        }else{
            $wedding['album_img'] = json_decode($wedding['album_img'], TRUE);
            $this->data['info'] = $wedding;

            //获取模版
            $this->load->config('tpl');
            $config_tpl = $this->config->item('wedding_tpl');
            $this->data['wedding_tpl'] = $config_tpl;

            $this->config->load('music');
            $this->data['music_arr'] = $this->config->item('music');

            $this->data['music_base_url'] = 'http://image'.BASE_DOMAIN.'/data';

            $this->load->view($this->dcm, $this->data);
        }
    }

    //祝福墙
    public function benison()
    {
        $wedding = $this->wedding;
        $this->load->model('wedding_benison_model');
        $where['wedding_id'] = $wedding['id'];
        $search_url = site_url($this->uri->uri_string().'?');
        $total_rows = $this->wedding_benison_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$search_url));
        $list = $this->wedding_benison_model
            ->select('id,img,benison,dt_add,status')
            ->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->order_by('id desc')->where($where)->find_all();

        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->data['list'] = $list;
        $this->data['info'] = $wedding;
        $this->load->view($this->dcm,$this->data);
    }

    //屏蔽祝福
    public function benison_status($id='')
    {
        $wedding = $this->wedding;
        $this->load->model('wedding_benison_model');
        $benison = $this->wedding_benison_model->where(array('id'=>$id,'wedding_id'=>$wedding['id']))->find();
        if( !$benison ){
            return $this->show_message(FALSE, '非法请求', '/u/wedding/benison');
        }
        $status = $benison['status'] ? 0 : 1;
        if( $this->wedding_benison_model->where(array('id'=>$benison['id']))->edit(array('status'=>$status)) ){
            return $this->show_message(TRUE, '修改成功', '/u/wedding/benison');
        }else{
            return $this->show_message(FALSE, '修改失败', '');
        }
    }

    //删除祝福
    public function benison_delete($id='')
    {
        $wedding = $this->wedding;
        $this->load->model('wedding_benison_model');
        $benison = $this->wedding_benison_model->where(array('id'=>$id,'wedding_id'=>$wedding['id']))->find();
        if( !$benison ){
            return $this->show_message(FALSE, '非法请求', '/u/wedding/benison');
        }
        if( $this->wedding_benison_model->where(array('id'=>$benison['id']))->delete() ){
            return $this->show_message(TRUE, '删除成功', '/u/wedding/benison');
        }else{
            return $this->show_message(FALSE, '修改失败', '');
        }
    }

    //统计
    public function joinbless($id='')
    {
        $wedding = $this->wedding;

        $this->load->model('wedding_joinbless_model');
        $where['wedding_id'] = $wedding['id'];
        $search_url = site_url($this->uri->uri_string().'?');
        $total_rows = $this->wedding_joinbless_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$search_url));
        $list = $this->wedding_joinbless_model
            ->select('id,name,mobile,dt_add,has_car,nums')
            ->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->order_by('id desc')->where($where)->find_all();

        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->data['list'] = $list;
        $this->data['info'] = $wedding;

        //带车的人数
        $has_car_num = $this->wedding_joinbless_model
            ->where(array('wedding_id'=>$wedding['id'],'has_car'=>1))
            ->count();
        $this->data['has_car_num'] = $has_car_num;

        $tongji = $this->wedding_joinbless_model->where(array('wedding_id'=>$wedding['id']))->sum('nums');
        $this->data['total_rows'] = $tongji;

        $this->load->view($this->dcm,$this->data);
    }

    //统计导出
    public function joinbless_export($id='')
    {
        $wedding = $this->wedding;

        $this->load->model('wedding_joinbless_model');
        $where['wedding_id'] = $wedding['id'];
        $list = $this->wedding_joinbless_model
            ->select('id,name,mobile,dt_add,has_car,nums')
            ->order_by('id desc')->where($where)->find_all();
        if( $list ){
            $fields = array(
                '#'=>'#',
                'name' => '姓名',
                'mobile' => '电话',
                'nums' => '赴宴人数',
                'has_car' => '车辆'
            );
            foreach( $list as &$val ){
                $val['has_car'] = $val['has_car'] ? '带车' : '不带车';
            }
            $this->excel_export('赴宴统计', '赴宴统计', $fields, $list);
        }
    }

    public function signin()
    {
        $this->load->model('wedding_list_model');
        if ($this->input->post()) {
            $code = trim($this->input->post('code'));
            if( !$code ){
                return $this->show_message(FALSE, '请输入喜帖码');
            }
            $where['status'] = 0;
            $where['code'] = $code;
            $wedding = $this->wedding_list_model->where($where)->find();
            if( !$wedding ){
                return $this->show_message(FALSE, '喜帖码错误');
            }
            $this->session->set_userdata('wedding_info', array(
                'id' => $wedding['id']
            ));
            redirect('/u/wedding');

        } else {
            $this->load->view($this->dcm, $this->data);
        }
    }

    public function logout()
    {
        $this->session->unset_userdata('wedding_info');
        redirect('/u/wedding/signin');
    }

    private function check_login()
    {
        if( !$this->session->userdata('wedding_info') ){
            if( $this->method!='signin' ){
                redirect('/u/wedding/signin');
            }
        }else{
            $this->load->model('wedding_list_model');
            $wedding_info = $this->session->userdata('wedding_info');
            $where['status'] = 0;
            $where['id'] = $wedding_info['id'];
            $wedding = $this->wedding_list_model->where($where)->find();
            if( !$wedding ){
                $this->session->unset_userdata('enroll_info');
                redirect('/u/wedding/signin');
            }
            $this->wedding = $wedding;

            $this->load->model('user_model');
            $site_info = $this->user_model->select('country')->where(array('id'=>$wedding['site_id']))->find();
            $this->data['country'] = $site_info['country'];

            $tokenData = array('user_id' => $wedding['site_id'], 'time' => time());
            $this->load->library('encrypt');
            $this->data['token'] = $this->encrypt->encode(serialize($tokenData));
        }
    }

    //检查图片格式
    public function _check_image($image) {
        if ($image) {
            if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
                $this->form_validation->set_message('_check_image', '图片地址格式错误');
                return FALSE;
            }
        }
        return TRUE;
    }

}