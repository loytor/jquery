<?php
/**
 * Created by PhpStorm.
 * User: 111
 * Date: 14-1-6
 * Time: 下午3:11
 * @property Scene_shake_model $scene_shake_model
 * @property Scene_shake_rotate_model $scene_shake_rotate_model
 * @property Scene_shake_progress_model $scene_shake_progress_model
 */
class Shake extends Scene_Controller
{
    private $rotate_status = array(
        -1 => '已结束',
        0 => '未开始',
        1 => '进行中'
    );

    public function index()
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '摇一摇功能还未开通', '/u/scene');
            return FALSE;
        }

        $this->load->model('scene_shake_model');
        $shake = $this->scene_shake_model->where(array('scene_id'=>$this->scene['id']))->find();
        if($this->input->post()) {
            $this->form_validation->set_rules('title', '标题', 'required|trim|htmlspecialchars');
            $this->form_validation->set_rules('countdown', '游戏时间', 'required|trim|integer|greater_than[19]|less_than[300]');
            //$this->form_validation->set_rules('type', '玩法设置', 'required');
            if($this->input->post('filter_parter') == 1) {
                $this->form_validation->set_rules('filter_cparter', '过滤中奖人名次', 'trim|is_natural_no_zero');
            }
            if($this->form_validation->run()) {
                $data = array();
                $data['title'] = $this->form_validation->set_value('title');
                //$data['img'] = $this->input->post('img');
                $data['type'] = $this->input->post('type');
                $data['shake_line'] = $this->input->post('shake_line');
                $data['slogan'] = $this->input->post('slogan');
                $data['voice'] = $this->input->post('voice');
                $data['ready_time'] = $this->input->post('ready_time');
                $data['countdown'] = $this->input->post('countdown');
                $data['rank_link'] = json_encode($this->input->post('rank_link'));
                $data['filter_parter'] = $this->input->post('filter_parter');
                if($data['filter_parter'] == 1) {
                    $data['filter_cparter'] = $this->form_validation->set_value('filter_cparter');
                } else {
                    $data['filter_cparter'] = 0;
                }
                //$this->load->model('scene_shake_rotate_model');
                if($shake) {
                    if($this->scene_shake_model->where(array('scene_id'=>$shake['scene_id'], 'id'=>$shake['id']))->edit($data)) {
                        $this->show_message(TRUE, '保存成功', '/u/shake');
                        return FALSE;
                    } else {
                        $this->show_message(FALSE, '保存失败', '');
                        return FALSE;
                    }
                } else {
                    $data['scene_id'] = $this->scene['id'];
                    $data['dt_add'] = time();
                    $shake_id = $this->scene_shake_model->add($data);
                    if($shake_id) {
                        $this->show_message(TRUE, '保存成功', '/u/shake');
                        return FALSE;
                    } else {
                        $this->show_message(FALSE, '保存失败', '');
                        return FALSE;
                    }
                }
            } else {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        } else {
            $this->data['shake'] = $shake ? $shake : array();

            $this->load->library('encrypt');
            $token_data = array('user_id' => $this->scene['site_id'], 'time' => time());
            $this->data['token'] = $this->encrypt->encode(serialize($token_data));
            $this->load->view($this->dcm, $this->data);
        }
    }

    /**
     * 游戏轮次设置
     */
/*    public function rotate()
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '摇一摇功能还未开通', '/u/scene');
            return FALSE;
        }
        $this->load->model('scene_shake_model');
        $shake = $this->scene_shake_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$shake) {
            $this->show_message(FALSE, '摇一摇还未设置', '/u/shake');
            return FALSE;
        }

        $this->load->model('scene_shake_rotate_model');
        $total_rows = $this->scene_shake_rotate_model->where(array('shake_id'=>$shake['id']))->count();
        $pager = $this->_pager($total_rows);
        $list = $this->scene_shake_rotate_model->where(array('shake_id'=>$shake['id']))->order_by('round desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->find_all();

        $this->data['list'] = $list ? $list : array();
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->data['rotate_status'] = $this->rotate_status;
        $this->load->view($this->dcm, $this->data);
    }

    public function rotate_add()
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '摇一摇功能还未开通', '/u/scene');
            return FALSE;
        }
        $this->load->model('scene_shake_model');
        $shake = $this->scene_shake_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$shake) {
            $this->show_message(FALSE, '摇一摇还未设置', '/u/shake');
            return FALSE;
        }

        $this->load->model('scene_shake_rotate_model');
        if($this->input->post()) {
            $this->form_validation->set_rules('countdown', '游戏时间', 'required|trim|integer|greater_than[19]|less_than[121]');
            $this->form_validation->set_rules('pnum', '中奖人数', 'required|trim|is_natural_no_zero');
            if($this->form_validation->run()) {
                $data = array();
                $data['shake_id'] = $shake['id'];
                $data['round'] = $this->input->post('round');
                $data['status'] = 0;
                $data['countdown'] = $this->form_validation->set_value('countdown');
                $data['pnum'] = $this->form_validation->set_value('pnum');

                $rank = $this->input->post('rank');
                $mobile = $this->input->post('mobile');
                if(!$this->check_rank($rank)) {
                    $this->show_message(FALSE, '名次必须是大于0的整数', '');
                    return FALSE;
                }
                if(!$this->check_mobile($mobile)) {
                    $this->show_message(FALSE, '手机好格式不正确', '');
                    return FALSE;
                }
                $foreordain = array();
                if($rank){
                    foreach($rank as $k=>$rk) {
                        $foreordain[$k]['rank'] = $rk;
                        $foreordain[$k]['mobile'] = $mobile[$k];
                    }
                }
                $data['foreordain'] = json_encode($foreordain);

                if($this->scene_shake_rotate_model->add($data)) {
                    $this->show_message(TRUE, '添加成功', '/u/shake/rotate');
                    return FALSE;
                } else {
                    $this->show_message(FALSE, '添加失败', '');
                    return FALSE;
                }
            } else {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        } else {
            $this->data['round'] = $this->scene_shake_rotate_model->where(array('shake_id'=>$shake['id']))->count();
            $this->load->view($this->dcm, $this->data);
        }
    }

    public function rotate_edit($id='')
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '摇一摇功能还未开通', '/u/scene');
            return FALSE;
        }
        $this->load->model('scene_shake_model');
        $shake = $this->scene_shake_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$shake) {
            $this->show_message(FALSE, '摇一摇还未设置', '/u/shake');
            return FALSE;
        }

        $this->load->model('scene_shake_rotate_model');
        if($this->input->post()) {
            $this->form_validation->set_rules('countdown', '游戏时间', 'required|trim|integer|greater_than[19]|less_than[121]');
            $this->form_validation->set_rules('pnum', '中奖人数', 'required|trim|is_natural_no_zero');
            if($this->form_validation->run()) {
                $data = array();
                $data['round'] = $this->input->post('round');
                $data['status'] = 0;
                $data['countdown'] = $this->form_validation->set_value('countdown');
                $data['pnum'] = $this->form_validation->set_value('pnum');

                $rank = $this->input->post('rank');
                $mobile = $this->input->post('mobile');
                if(!$this->check_rank($rank)) {
                    $this->show_message(FALSE, '名次必须是大于0的整数', '');
                    return FALSE;
                }
                if(!$this->check_mobile($mobile)) {
                    $this->show_message(FALSE, '手机好格式不正确', '');
                    return FALSE;
                }
                $foreordain = array();
                if($rank){
                    foreach($rank as $k=>$rk) {
                        $foreordain[$k]['rank'] = $rk;
                        $foreordain[$k]['mobile'] = $mobile[$k];
                    }
                }
                $data['foreordain'] = json_encode($foreordain);

                if($this->scene_shake_rotate_model->where(array('id'=>$id, 'shake_id'=>$shake['id']))->edit($data)) {
                    $this->show_message(TRUE, '编辑成功', '/u/shake/rotate');
                    return FALSE;
                } else {
                    $this->show_message(FALSE, '编辑失败', '');
                    return FALSE;
                }
            } else {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        } else {
            $rotate = $this->scene_shake_rotate_model->where(array('id'=>$id, 'shake_id'=>$shake['id']))->find();
            if(!$rotate) {
                $this->show_message(FALSE, '该轮次不存在', '/u/shake/rotate');
                return FALSE;
            }
            $rotate['foreordain'] = json_decode($rotate['foreordain'], TRUE);
            $this->data['rotate'] = $rotate;
            $this->load->view($this->dcm, $this->data);
        }
    }

    public function rotate_delete($id='')
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '摇一摇功能还未开通', '/u/scene');
            return FALSE;
        }
        $this->load->model('scene_shake_model');
        $shake = $this->scene_shake_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$shake) {
            $this->show_message(FALSE, '摇一摇还未设置', '/u/shake');
            return FALSE;
        }

        $this->load->model('scene_shake_rotate_model');
        $rotate = $this->scene_shake_rotate_model->where(array('id'=>$id, 'shake_id'=>$shake['id']))->find();
        if(!$rotate) {
            $this->show_message(FALSE, '该轮次不存在', '/u/shake/rotate');
            return FALSE;
        }

        if($this->scene_shake_rotate_model->where(array('id'=>$id, 'shake_id'=>$shake['id']))->delete()) {
            $this->scene_shake_rotate_model->where(array('shake_id'=>$shake['id'], 'round >'=>$rotate['round']))->set_dec('round');
            $this->show_message(TRUE, '删除成功', '/u/shake/rotate');
            return FALSE;
        } else {
            $this->show_message(FALSE, '删除失败', '/u/shake/rotate');
            return FALSE;
        }
    }*/

    /**
     * @param string $id
     * 重置
     */
    /*public function rotate_reset($id='')
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '摇一摇功能还未开通', '/u/scene');
            return FALSE;
        }
        $this->load->model('scene_shake_model');
        $shake = $this->scene_shake_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$shake) {
            $this->show_message(FALSE, '摇一摇还未设置', '/u/shake');
            return FALSE;
        }

        $this->load->model('scene_shake_rotate_model');
        $rotate = $this->scene_shake_rotate_model->where(array('id'=>$id, 'shake_id'=>$shake['id']))->find();
        if(!$rotate) {
            $this->show_message(FALSE, '该轮次不存在', '/u/shake/rotate');
            return FALSE;
        }

        if($this->scene_shake_rotate_model->where(array('id'=>$id, 'shake_id'=>$shake['id']))->edit(array('status'=>0))){
            //清空摇一摇的记录
            $this->load->model('scene_shake_progress_model');
            $this->scene_shake_progress_model->where(array('rotate_id'=>$id, 'shake_id'=>$shake['id']))->delete();

            $this->show_message(TRUE, '重置成功', '/u/shake/rotate');
            return FALSE;
        } else {
            $this->show_message(FALSE, '重置失败', '/u/shake/rotate');
            return FALSE;
        }
    }*/

/*    public function record($rotate_id='')
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '摇一摇功能还未开通', '/u/scene');
            return FALSE;
        }
        $this->load->model('scene_shake_model');
        $shake = $this->scene_shake_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$shake) {
            $this->show_message(FALSE, '摇一摇还未设置', '');
            return FALSE;
        }

        $this->data['record_list'] = array();

        $this->load->model('scene_shake_rotate_model');
        $shake_rotate = $this->scene_shake_rotate_model->where(array('shake_id'=>$shake['id']))->order_by('round asc')->find_all();
        $this->data['shake_rotate'] = $shake_rotate ? $shake_rotate : array();

        if($rotate_id) {

        } elseif($shake_rotate) {
            $rotate_id = $shake_rotate[0]['id'];
        } else {
            $rotate_id = 0;
        }

        $record_list = array();
        $rotate = $this->scene_shake_rotate_model->where(array('id'=>$rotate_id))->find();
        if($rotate) {
            $pnum = $rotate['pnum'];
            $this->load->model('scene_shake_progress_model');
            $this->load->model('scene_member_model');
            $where['shake_id'] = $shake['id'];
            $where['rotate_id'] = $rotate_id;
            $record_list = $this->scene_shake_progress_model->order_by('progress','DESC')->limit($pnum)->where($where)->find_all();
            foreach ($record_list as $key=>$val) {
                $record_list[$key]['mobile'] = $this->scene_member_model->where(array('mid'=>$val['mid']))->get_field('mobile');
            }
        }
        $this->data['record_list'] = $record_list ? $record_list : array();

        $this->data['rotate'] = $rotate;
        $this->load->view($this->dcm, $this->data);
    }*/

/*    public function export($rotate_id='')
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '摇一摇功能还未开通', '/u/scene');
            return FALSE;
        }
        $this->load->model('scene_shake_model');
        $shake = $this->scene_shake_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$shake) {
            $this->show_message(FALSE, '摇一摇还未设置', '/u/shake');
            return FALSE;
        }

        $this->load->model('scene_shake_rotate_model');
        $rotate = $this->scene_shake_rotate_model->where(array('id'=>$rotate_id))->find();
        if(!$rotate) {
            $this->show_message(FALSE, '没有该轮次', '/u/shake/record');
            return FALSE;
        }

        $pnum = $rotate['pnum'];
        $this->load->model('scene_shake_progress_model');
        $where['shake_id'] = $shake['id'];
        $where['rotate_id'] = $rotate_id;
        $list = $this->scene_shake_progress_model->order_by('progress','DESC')->limit($pnum)->where($where)->find_all();

        $round_title = '第'.$rotate['round'].'轮';
        if($list)
        {
            foreach($list as $key=> $item)
            {
                $record_list[$key]['nick_name'] = $item['nick_name'];
                $record_list[$key]['rank'] = $key+1;
            }

            $fields = array(
                'rank'=>'名次',
                'nick_name'=>'昵称'
            );
            $this->excel_export('微现场摇一摇'.$round_title.'中奖记录', '微现场摇一摇'.$round_title.'中奖记录', $fields, $record_list);
        }
        else
        {
            $this->show_message(FALSE, $round_title.'尚无中奖记录可导出', '');
        }
    }*/

    public function record($dt_record='')
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '摇一摇功能还未开通', '/u/scene');
            return FALSE;
        }

        $this->load->model('scene_shake_model');
        $shake = $this->scene_shake_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$shake) {
            $this->show_message(FALSE, '摇一摇还未设置', '/u/shake');
            return FALSE;
        }
        $this->load->model('scene_member_model');
        $this->data['record_list'] = array();
        $this->load->model('scene_shake_record_model');
        $this->load->model('scene_shake_rotate_model');
        $where['shake_id'] = $shake['id'];
        //$dts = $this->scene_shake_record_model->select('dt_record')->where($where)->order_by('dt_record','ASC')->group_by('dt_record')->find_all();
        $new_where = array(
            'scene_shake_record.shake_id' => $shake['id'],
            'scene_member.scene_id' => $this->scene['id']);
        if($dt_record){
            $new_where['scene_shake_record.rotate_id'] = $dt_record;
        }else{
            $new_where['scene_shake_record.rotate_id'] = $dt_record = 1;
        }
        //查询轮次
        $this->data['rotate'] = array();
        $rotate = $this->scene_shake_rotate_model->select('id,shake_id,round')->where($where)->find_all();
       /* $cur_dt = '';
        if($dt_record) {
            $where['dt_record'] = $cur_dt = $dt_record;
        } elseif($dts) {
            $where['dt_record'] = $cur_dt = $dts[0]['dt_record'];
        } else {
            $where['dt_record'] = -1;
        }*/

        $total_rows = $this->scene_shake_record_model->order_by('progress','DESC')->where('rotate_id ='.$dt_record)->count();
        $pager = $this->_pager($total_rows);
        //$record_list = $this->scene_shake_record_model->order_by('progress','DESC')->where($where)->limit($pager['limit']['value'], $pager['limit']['offset'])->find_all();
        $record_list = $this->scene_shake_record_model->select('scene_shake_record.*,scene_member.dt_join')
            ->join('scene_member','scene_shake_record.mid = scene_member.mid','left')
            ->where($new_where)
            ->order_by('progress','desc')
            ->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->find_all();
        $this->data['record_list'] = $record_list ? $record_list : array();
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        //根据ID查询当前是第几轮
        $round = $this->scene_shake_rotate_model->select('id,round')->where("id = $dt_record ")->find();
        $this->data['round'] = $round;
        //$this->data['cur_dt'] = $cur_dt;
        $this->data['rotate'] = $rotate;
        $this->data['dts'] = $dt_record;
        $this->load->view($this->dcm, $this->data);
    }

    public function export($dt_record='')
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '摇一摇功能还未开通', '/u/scene');
            return FALSE;
        }

        $this->load->model('scene_shake_model');
        $shake = $this->scene_shake_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$shake) {
            $this->show_message(FALSE, '摇一摇还未设置', '/u/shake');
            return FALSE;
        }

        $this->load->model('scene_shake_record_model');
        $where['shake_id'] = $shake['id'];
        $dts = $this->scene_shake_record_model->select('dt_record')->where($where)->order_by('dt_record','ASC')->group_by('dt_record')->find_all();

        /*$cur_dt = 0;
          if($dt_record) {
               $where['dt_record'] = $cur_dt = $dt_record;
             } elseif($dts) {
               $where['dt_record'] = $cur_dt = $dts[0]['dt_record'];
             } else {
               $where['dt_record'] = -1;
        }*/
        if($dt_record) {
            $where['rotate_id'] = $dt_record;
        } else {
            $where['rotate_id'] = 1;
        }
        $record_list = $this->scene_shake_record_model->order_by('progress','DESC')->where($where)->find_all();
        $record_list = $record_list ? $record_list : array();
        if($record_list)
        {
            $list = array();
            foreach($record_list as $key=>$item)
            {
                $list[$key]['nick_name'] = $item['nick_name'];
                $list[$key]['rank'] = $key+1;
            }

            $fields = array(
                '#'=>'#',
                'rank'=>'名次',
                'nick_name'=>'昵称'
            );

            $this->excel_export('摇一摇记录('.$dt_record.')', '摇一摇记录('.$dt_record.')', $fields, $list);
        }
        else
        {
            $this->show_message(FALSE, '尚无摇一摇记录可导出', '');
        }
    }

    /**
     * @param string $dt_record
     * @return bool
     * 删除记录
     */
    public function record_delete($dt_record='')
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '摇一摇功能还未开通', '/u/scene');
            return FALSE;
        }

        $this->load->model('scene_shake_model');
        $shake = $this->scene_shake_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$shake) {
            $this->show_message(FALSE, '摇一摇还未设置', '/u/shake');
            return FALSE;
        }

        $this->load->model('scene_shake_record_model');
        if($this->scene_shake_record_model->where(array('shake_id'=>$shake['id'], 'rotate_id'=>$dt_record))->delete()) {
            //删除对应的中奖人过滤表记录
            $this->load->model('scene_shake_parter_filter_model');
            //$this->scene_shake_parter_filter_model->where(array('shake_id'=>$shake['id'], 'rotate_id'=>$dt_record))->delete();

            $this->show_message(TRUE, '删除成功', '/u/shake/record');
            return FALSE;
        } else {
            $this->show_message(TRUE, '删除失败', '/u/shake/record');
            return FALSE;
        }
    }

    /**
     * 判断排名格式
     */
    private function check_rank($ranks)
    {
        if($ranks){
            foreach($ranks as $rank) {
                if(!$this->form_validation->is_natural_no_zero($rank)) {
                    return FALSE;
                }
            }
        }
        return TRUE;
    }

    /**
     * 判断手机格式
     */
    private function check_mobile($mobiles)
    {
        if($mobiles){
            foreach($mobiles as $mobile) {
                if(!valid_mobile($mobile)) {
                    return FALSE;
                }
            }
        }
        return TRUE;
    }

    public function upload_voice(){
        $this->load->library('encrypt');
        $token = trim($this->input->get_post('token', TRUE));
        $token_decoded = $this->encrypt->decode($token);
        if ( ! $token_decoded) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => '请通过正常途径上传'));
            exit;
        }
        $token_data = unserialize($token_decoded);
        if ( ! isset($token_data['time']) OR ! isset($token_data['user_id']) OR (time() - $token_data['time']) > 3600) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => '请通过正常途径上传'));
            exit;
        }
        $upload_config = array(
            'upload_path'	=> FCPATH.'images/'.$token_data['user_id'].'/'.date('Ym').'/',
            'allowed_types'	=> 'mp3',
            'max_size'		=> 1024 * 10,
            'encrypt_name'     => TRUE
        );
        $this->load->library('upload', $upload_config);

        if(!is_dir($upload_config['upload_path'])){
            mkdir($upload_config['upload_path'], 0777, TRUE);
        }

        if ( ! $this->upload->do_upload('userfile')) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => $this->upload->display_errors('', '')));
            exit;
        } else {
            $mp3 = $this->upload->data();
            $filePath = $mp3['full_path'];

            $mp3_url = str_replace(str_replace(DIRECTORY_SEPARATOR, '/', FCPATH), '/', $filePath);
            echo json_encode(array(
                'success'     => 1,
                'mp3'         => image_url($mp3_url)
            ));
            exit;
        }
    }

    private function check_func()
    {
        $this->load->model('scene_model');
        $scene = $this->scene_model->where(array('id'=>$this->scene['id']))->find();
        $func = json_decode($scene['func'], TRUE);
        if($func && isset($func['shake']) && $func['shake']) {
            return TRUE;
        }
        return FALSE;
    }
}