<?php
/**
 * Created by PhpStorm.
 * User: 111
 * Date: 14-5-8
 * Time: 下午4:48
 */
class Pairup extends Scene_Controller
{
    public function index()
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '对对碰功能还未开通', '/u/scene');
            return FALSE;
        }

        $this->load->model('scene_pairup_model');
        $pairup = $this->scene_pairup_model->where(array('scene_id'=>$this->scene['id']))->find();
        if($this->input->post()) {
            $this->form_validation->set_rules('title', '标题', 'required|trim|htmlspecialchars');
            if($this->form_validation->run()) {
                $data['title'] = $this->form_validation->set_value('title');

                if($pairup) {
                    if($this->scene_pairup_model->where(array('scene_id'=>$pairup['scene_id'], 'id'=>$pairup['id']))->edit($data)) {
                        $this->show_message(TRUE, '保存成功', '/u/pairup');
                        return FALSE;
                    } else {
                        $this->show_message(FALSE, '保存失败', '');
                        return FALSE;
                    }
                } else {
                    $data['scene_id'] = $this->scene['id'];
                    $data['dt_add'] = time();
                    $pairup_id = $this->scene_pairup_model->add($data);
                    if($pairup_id) {
                        $this->show_message(TRUE, '保存成功', '/u/pairup');
                        return FALSE;
                    } else {
                        $this->show_message(FALSE, '保存失败', '');
                        return FALSE;
                    }
                }
            } else {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        } else {
            $this->data['pairup'] = $pairup ? $pairup : array();

            $this->load->library('encrypt');
            $token_data = array('user_id' => $this->scene['site_id'], 'time' => time());
            $this->data['token'] = $this->encrypt->encode(serialize($token_data));
            $this->load->view($this->dcm, $this->data);
        }
    }

    public function record($dt_record='')
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '对对碰功能还未开通', '/u/scene');
            return FALSE;
        }

        $this->load->model('scene_pairup_model');
        $pairup = $this->scene_pairup_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$pairup) {
            $this->show_message(FALSE, '对对碰还未设置', '/u/pairup');
            return FALSE;
        }
        $this->load->model('scene_member_model');
        $this->data['record_list'] = array();
        $this->load->model('scene_pairup_record_model');
        $this->load->model('scene_pairup_rotate_model');
        $where['pairup_id'] = $pairup['id'];

        $new_where = array(
            'scene_pairup_record.pairup_id' => $pairup['id']
        );
        if($dt_record){
            $new_where['scene_pairup_record.rotate_id'] = $dt_record;
        }else{
            $new_where['scene_pairup_record.rotate_id'] = $dt_record = 1;
        }
        //查询轮次
        $this->data['rotate'] = array();
        $rotate = $this->scene_pairup_rotate_model->select('id,pairup_id,round')->where($where)->find_all();
        //$dts = $this->scene_pairup_record_model->select('dt_record')->where($where)->order_by('dt_record','ASC')->group_by('dt_record')->find_all();

        /*$cur_dt = '';
        if($dt_record) {
            $where['dt_record'] = $cur_dt = $dt_record;
        } elseif($dts) {
            $where['dt_record'] = $cur_dt = $dts[0]['dt_record'];
        } else {
            $where['dt_record'] = -1;
        }*/
        $total_rows = $this->scene_pairup_record_model->order_by('dt_record','ASC')->where('rotate_id ='.$dt_record)->count();
        $pager = $this->_pager($total_rows);
        //$record_list = $this->scene_pairup_record_model->order_by('dt_record','ASC')->where($where)->limit($pager['limit']['value'], $pager['limit']['offset'])->find_all();
        $record_list = $this->scene_pairup_record_model->select('scene_pairup_record.*')
            ->where($new_where)
            ->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->find_all();
        //查询加入时间
        if(count($record_list) > 0){
            foreach($record_list as $k => $v){
                $b_join = $this->scene_member_model->select('dt_join')->where('scene_id ='.$this->scene['id'] and 'mid ='.$v['mid'])->find();
                $g_join = $this->scene_member_model->select('dt_join')->where('scene_id ='.$this->scene['id'] and 'mid ='.$v['mid2'])->find();
                $record_list['$k']['b_join'] = $b_join[$k]['dt_join'];
                $record_list['$k']['g_join'] = $g_join[$k]['dt_join'];
            }
        }
        $this->data['record_list'] = $record_list ? $record_list : array();
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->data['rotate'] = $rotate;
        //根据ID查询当前是第几轮
        $round = $this->scene_pairup_rotate_model->select('id,round')->where("id = $dt_record ")->find();
        $this->data['round'] = $round;
        //$this->data['cur_dt'] = $cur_dt;

        $this->data['dts'] = $dt_record;
        $this->load->view($this->dcm, $this->data);
    }

    public function export($dt_record='')
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '对对碰功能还未开通', '/u/scene');
            return FALSE;
        }

        $this->load->model('scene_pairup_model');
        $pairup = $this->scene_pairup_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$pairup) {
            $this->show_message(FALSE, '对对碰还未设置', '/u/pairup');
            return FALSE;
        }

        $this->load->model('scene_pairup_record_model');
        $where['pairup_id'] = $pairup['id'];
        $dts = $this->scene_pairup_record_model->select('dt_record')->where($where)->order_by('dt_record','ASC')->group_by('dt_record')->find_all();

        /*$cur_dt = 0;
        if($dt_record) {
            $where['dt_record'] = $cur_dt = $dt_record;
        } elseif($dts) {
            $where['dt_record'] = $cur_dt = $dts[0]['dt_record'];
        } else {
            $where['dt_record'] = -1;
        }*/
        if($dt_record) {
            $where['rotate_id'] = $dt_record;
        } else {
            $where['rotate_id'] = 1;
        }
        $record_list = $this->scene_pairup_record_model->order_by('dt_record','ASC')->where($where)->find_all();
        $record_list = $record_list ? $record_list : array();
        if($record_list)
        {
            $list = array();
            $merge_cell = array();
            $cell_key = 1;
            $col = 'A';
            foreach($record_list as $key=>$item)
            {
                $list_item = array();
                $list_item['#'] = $key+1;
                $list_item['nick_name'] = $item['nick_name'];
                array_push($list, $list_item);
                $cell_key++;
                $c1 = $col.$cell_key;

                $list_item = array();
                $list_item['#'] = $key+1;
                $list_item['nick_name'] = $item['nick_name2'];
                array_push($list, $list_item);
                $cell_key++;
                $c2 = $col.$cell_key;
                $merge_cell[] = $c1.':'.$c2;
            }

            $fields = array(
                '#'=>'#',
                //'avatar'=>'头像',
                'nick_name'=>'昵称'
            );

            $this->excel_export('对对碰记录('.$dt_record.')', '对对碰记录('.$dt_record.')', $fields, $list, $merge_cell);
        }
        else
        {
            $this->show_message(FALSE, '尚无对对碰记录可导出', '');
        }
    }

    /**
     * @param string $dt_record
     * @return bool
     * 删除记录
     */
    public function record_delete($dt_record='')
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '对对碰功能还未开通', '/u/scene');
            return FALSE;
        }

        $this->load->model('scene_pairup_model');
        $pairup = $this->scene_pairup_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$pairup) {
            $this->show_message(FALSE, '对对碰还未设置', '/u/pairup');
            return FALSE;
        }

        $this->load->model('scene_pairup_record_model');
        if($this->scene_pairup_record_model->where(array('pairup_id'=>$pairup['id'], 'rotate_id'=>$dt_record))->delete()) {
            $this->show_message(TRUE, '删除成功', '/u/pairup/record');
            return FALSE;
        } else {
            $this->show_message(TRUE, '删除失败', '/u/pairup/record');
            return FALSE;
        }
    }

    /**
     * 判断中奖人数格式
     */
    private function check_pnum($pnums)
    {
        foreach($pnums as $pnum) {
            if(!$this->form_validation->is_natural($pnum)) {
                return FALSE;
            }
        }
        return TRUE;
    }

    /**
     * 判断手机格式
     */
    private function check_mobile($mobiles)
    {
        if($mobiles) {
            foreach($mobiles as $mobile) {
                if(!valid_mobile($mobile)) {
                    return FALSE;
                }
            }
        }
        return TRUE;
    }

    private function check_func()
    {
        $this->load->model('scene_model');
        $scene = $this->scene_model->where(array('id'=>$this->scene['id']))->find();
        $func = json_decode($scene['func'], TRUE);
        if($func && isset($func['pairup']) && $func['pairup']) {
            return TRUE;
        }
        return FALSE;
    }
}