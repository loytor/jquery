<?php
/**
 * Created by PhpStorm.
 * User: andery
 * Date: 14-1-5
 * Time: 上午9:27
 */

class Wall extends Scene_Controller
{
    private $msg_status = array(
        -1 => '未通过',
        0  => '已通过',
        1  => '未审核'
    );

    public function index()
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '上墙功能还未开通', '/u/scene');
            return FALSE;
        }
        $this->load->model('scene_wall_model');
        if ($this->input->post()) {
            $title = $this->input->post('title');
            $show_style = $this->input->post('show_style');
            $show_type = $this->input->post('show_type');
            $re_time = (int)$this->input->post('re_time');
            if($re_time < 3) {
                $this->show_message(FALSE, '刷新时间至少3秒', '/u/scene');
                return FALSE;
            }
            $is_check = $this->input->post('is_check');
            $def_msg = $this->input->post('def_msg');
            $chistory = $this->input->post('chistory');
            $wall_info = $this->scene_wall_model->where(array('scene_id'=>$this->scene['id']))->find();
            if ($wall_info) {
                $this->scene_wall_model->where(array('scene_id'=>$this->scene['id']))->edit(array(
                    'title'=>$title,
                    'show_style'=>$show_style,
                    'show_type'=>$show_type,
                    're_time'=>$re_time,
                    'is_check'=>$is_check,
                    'def_msg'=>$def_msg,
                    'chistory'=>$chistory
                ));
            } else {
                $this->scene_wall_model->add(array(
                    'scene_id' => $this->scene['id'],
                    'title' => $title,
                    'show_style' => $show_style,
                    'show_type' => $show_type,
                    're_time' => $re_time,
                    'is_check' => $is_check,
                    'def_msg' => $def_msg,
                    'chistory'=>$chistory,
                    'dt_add' => time()
                ));
            }
            $this->show_message(TRUE, '编辑成功', '/u/wall');
            return FALSE;
        } else {
            $wall = $this->scene_wall_model->where(array('scene_id'=>$this->scene['id']))->find();
            $this->data['wall'] = $wall;
            $this->load->view($this->dcm, $this->data);
        }
    }

    public function check()
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '上墙功能还未开通', '/u/scene');
            return FALSE;
        }
        $this->load->model('scene_wall_model');
        $wall = $this->scene_wall_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$wall) {
            $this->show_message(FALSE, '该上墙还未设置', '/u/scene');
            return FALSE;
        }

        $this->load->model('scene_wall_msg_model');
        $list = $this->scene_wall_msg_model->where(array('wall_id'=>$wall['id'], 'status'=>1))->order_by('id', 'desc')->find_all();

        $this->data['list'] = $list ? $list : array();
        $this->load->view($this->dcm, $this->data);
    }

    /**
     * 消息统计
     */
    public function stat()
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '上墙功能还未开通', '/u/scene');
            return FALSE;
        }
        $this->load->model('scene_wall_model');
        $wall = $this->scene_wall_model->where(array('scene_id'=>$this->scene['id']))->find();
        $this->data['list'] = array();
        $this->data['page'] = '';
        $this->data['search'] = array();
        $this->data['count'] = 0;
        $this->data['pass_count'] = 0;
        $this->data['prevent_count'] = 0;
        $this->data['unaudit_count'] = 0;
        if($wall) {
            $this->data['search'] = $params = $this->input->get();
            $query_arr = array();
            $where = array();
            $where['wall_id'] = $wall['id'];
            $params && isset($params['status']) && $params['status'] != 'all' && $where['status'] = $params['status'];
            $order_time = 'desc';
            if($params && isset($params['time_sort']) && $params['time_sort']) {
                $order_time = $params['time_sort'];
            }
            foreach($params as $k=>$p) {
                if($k != 'page') {
                    $query_arr[] = $k.'='.$p;
                }
            }

            //消息记录
            $this->load->model('scene_wall_msg_model');
            $this->data['count'] = $total_rows = $this->scene_wall_msg_model->where($where)->count();
            $query_string = implode('&', $query_arr);
            $pager = $this->_pager($total_rows, array('base_url' => site_url($this->uri->uri_string().'?').$query_string));
            $list = $this->scene_wall_msg_model->order_by('dt_add',$order_time)->limit($pager['limit']['value'], $pager['limit']['offset'])->where($where)->find_all();
            if($list) {
                $this->load->model('scene_member_model');
                foreach($list as &$_item) {
                    $scene_member = $this->scene_member_model->where(array('mid'=>$_item['mid'], 'scene_id'=>$this->scene['id']))->find();
                    $_item['is_shield'] = $scene_member ? $scene_member['is_shield'] : 0;
                }
            }
            $this->data['list'] = $list ? $list : array();
            $this->data['page'] = $pager['links'];
            $this->data['offset'] = $pager['limit']['offset'];

            $this->data['pass_count'] = $this->scene_wall_msg_model->where(array('wall_id'=>$wall['id'], 'status'=>0))->count();
            $this->data['prevent_count'] = $this->scene_wall_msg_model->where(array('wall_id'=>$wall['id'], 'status'=>-1))->count();;
            $this->data['unaudit_count'] = $this->scene_wall_msg_model->where(array('wall_id'=>$wall['id'], 'status'=>1))->count();;
        }

        $this->data['msg_status'] = $this->msg_status;
        $this->load->view($this->dcm, $this->data);
    }

    public function export()
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '上墙功能还未开通', '/u/scene');
            return FALSE;
        }
        $this->load->model('scene_wall_model');
        $wall = $this->scene_wall_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$wall) {
            $this->show_message(FALSE, '该上墙还未设置', '/u/scene');
            return FALSE;
        }

        $params = $this->input->get();
        $where = array();
        $where['wall_id'] = $wall['id'];
        $params && isset($params['status']) && $params['status'] != 'all' && $where['status'] = $params['status'];

        $this->load->model('scene_wall_msg_model');
        $list = $this->scene_wall_msg_model->order_by('dt_add','DESC')->where($where)->find_all();

        $record_list = array();
        if($list)
        {
            foreach($list as $key=> $item)
            {
                $record_list[$key]['nick_name'] = $item['nick_name'];
                $record_list[$key]['content'] = $item['content'];
                $record_list[$key]['dt_add'] = date('Y-m-d H:i:s', $item['dt_add']);
                $record_list[$key]['status'] = $this->msg_status[$item['status']];
            }

            $fields = array(
                '#'=>'#',
                'nick_name'=>'昵称',
                'content' => '内容',
                'dt_add' => '时间',
                'status' => '状态'
            );
            $this->excel_export('微现场上墙消息记录', '微现场上墙消息记录', $fields, $record_list);
        }
        else
        {
            $this->show_message(FALSE, '尚无消息记录可导出', '');
        }
    }

    public function msg_pass()
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '上墙功能还未开通', '/u/scene');
            return FALSE;
        }
        $id = $this->input->post('id');
        $this->load->model('scene_wall_msg_model');
        $msg = $this->scene_wall_msg_model->where(array('id'=>$id))->find();
        if(!$msg) {
            $this->show_message(FALSE, '没有该条消息', '/u/wall/check');
            return FALSE;
        }

        if($this->scene_wall_msg_model->where(array('id'=>$id))->edit(array('status'=>0))){
            $data['success'] = 1;
        } else {
            $data['success'] = 0;
        }
        echo json_encode($data);
    }

    public function msg_prevent()
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '上墙功能还未开通', '/u/scene');
            return FALSE;
        }
        $id = $this->input->post('id');
        $this->load->model('scene_wall_msg_model');
        $msg = $this->scene_wall_msg_model->where(array('id'=>$id))->find();
        if(!$msg) {
            $this->show_message(FALSE, '没有该条消息', '/u/wall/check');
            return FALSE;
        }

        if($this->scene_wall_msg_model->where(array('id'=>$id))->edit(array('status'=>-1))){
            $data['success'] = 1;
        } else {
            $data['success'] = 0;
        }
        echo json_encode($data);
    }

    public function msg_batch_pass()
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '上墙功能还未开通', '/u/scene');
            return FALSE;
        }
        $ids = $this->input->post('ids');
        $this->load->model('scene_wall_msg_model');
        if($this->scene_wall_msg_model->where_in('id', $ids)->edit(array('status'=>0))){
            $data['success'] = 1;
            $data['ids'] = $ids;
        } else {
            $data['success'] = 0;
        }
        echo json_encode($data);
    }

    public function msg_batch_prevent()
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '上墙功能还未开通', '/u/scene');
            return FALSE;
        }
        $ids = $this->input->post('ids');
        $this->load->model('scene_wall_msg_model');
        if($this->scene_wall_msg_model->where_in('id', $ids)->edit(array('status'=>-1))){
            $data['success'] = 1;
            $data['ids'] = $ids;
        } else {
            $data['success'] = 0;
        }
        echo json_encode($data);
    }

    public function new_msg()
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '上墙功能还未开通', '/u/scene');
            return FALSE;
        }
        $this->load->model('scene_wall_model');
        $wall = $this->scene_wall_model->where(array('scene_id'=>$this->scene['id']))->order_by('id', 'desc')->find();
        if($wall) {
            $last_id = $this->input->post('last_id');
            $this->load->model('scene_wall_msg_model');
            $list = $this->scene_wall_msg_model->where(array('wall_id'=>$wall['id'], 'status'=>1, 'id >'=>$last_id))->find_all();
            $this->data['list'] = $list;
            echo $this->load->view($this->dcm, $this->data);
        } else {
            echo '';
        }
    }

    public function msg_delete()
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '上墙功能还未开通', '/u/scene');
            return FALSE;
        }
        $id = $this->input->post('id');
        $this->load->model('scene_wall_msg_model');
        $msg = $this->scene_wall_msg_model->where(array('id'=>$id))->find();
        if(!$msg) {
            $this->show_message(FALSE, '没有该条消息', '/u/wall/stat');
            return FALSE;
        }

        if($this->scene_wall_msg_model->where(array('id'=>$id))->delete()){
            $data['success'] = 1;
        } else {
            $data['success'] = 0;
        }
        echo json_encode($data);
    }

    public function user_shield()
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '上墙功能还未开通', '/u/scene');
            return FALSE;
        }
        $this->load->model('scene_wall_model');
        $wall = $this->scene_wall_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$wall) {
            $this->show_message(FALSE, '该上墙还未设置', '/u/scene');
            return FALSE;
        }

        $mid = $this->input->post('mid');
        $this->load->model('scene_member_model');
        if(!$this->scene_member_model->where(array('mid'=>$mid, 'scene_id'=>$this->scene['id']))->find()){
            $this->show_message(FALSE, '没有该用户', '/u/wall/stat');
            return FALSE;
        }
        //将该用户标记为屏蔽上墙
        $this->scene_member_model->where(array('mid'=>$mid, 'scene_id'=>$this->scene['id']))->edit(array('is_shield'=>1));
        //将该用户的消息都置为未通过
        $this->load->model('scene_wall_msg_model');
        if($this->scene_wall_msg_model->where(array('wall_id'=>$wall['id'], 'mid'=>$mid))->edit(array('status'=>-1))) {
            $data['success'] = 1;
        } else {
            $data['success'] = 0;
        }
        echo json_encode($data);
    }

    public function user_unshield()
    {
        if(!$this->check_func()) {
            $this->show_message(FALSE, '上墙功能还未开通', '/u/scene');
            return FALSE;
        }
        $this->load->model('scene_wall_model');
        $wall = $this->scene_wall_model->where(array('scene_id'=>$this->scene['id']))->find();
        if(!$wall) {
            $this->show_message(FALSE, '该上墙还未设置', '/u/scene');
            return FALSE;
        }

        $mid = $this->input->post('mid');
        $this->load->model('scene_member_model');
        if(!$this->scene_member_model->where(array('mid'=>$mid, 'scene_id'=>$this->scene['id']))->find()){
            $this->show_message(FALSE, '没有该用户', '/u/wall/stat');
            return FALSE;
        }
        //将该用户标记为未屏蔽上墙
        $this->load->model('scene_wall_msg_model');
        if($this->scene_member_model->where(array('mid'=>$mid, 'scene_id'=>$this->scene['id']))->edit(array('is_shield'=>0))) {
            $data['success'] = 1;
        } else {
            $data['success'] = 0;
        }
        echo json_encode($data);
    }

    private function check_func()
    {
        $this->load->model('scene_model');
        $scene = $this->scene_model->where(array('id'=>$this->scene['id']))->find();
        $func = json_decode($scene['func'], TRUE);
        if($func && isset($func['wall']) && $func['wall']) {
            return TRUE;
        }
        return FALSE;
    }
} 