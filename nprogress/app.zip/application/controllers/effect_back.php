<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Effect extends CI_Controller {

	public function index() {
        $this->load->model('model_site_effect');
        $site_id = logged_user_id();
        if ($this->input->post()) {
            $type = $this->input->post('type');
            $enabled = $this->input->post('enabled');
            switch ($type) {
                case 'welcome': //欢迎页
                    $config = array(
                        'enabled' => $enabled,
                        'img' => $this->input->post('welcome_img'),
                    );
                break;
                case 'loading': //加载特效
                    $show_type = $this->input->post('show_type');
                    switch ($show_type) {
                        case 'color':
                            $value = $this->input->post('color');
                            break;
                        case 'bgimg':
                            $value = $this->input->post('bgimg');
                            if($enabled==1 && !$value)
                            {
                                $this->show_message(FALSE, '背景图片不能为空', '',1);
                            }
                            break;
                    }
                    $config = array(
                        'enabled' => $enabled,
                        'scope' => $this->input->post('scope'),
                        'type' => $this->input->post('loading_type'),
                        'show_type' => $show_type,
                        'value' => $value,
                    );
                break;
                case 'bgmusic': //背景音乐
                    $config = array(
                        'enabled' => $enabled,
                        'scope' => $this->input->post('scope'),
                        'file' => $this->input->post('musicurl'),
                    );
                break;
                case 'milieu':  //环境效果
                    $config = array(
                        'enabled' => $enabled,
                        'scope' => $this->input->post('scope'),
                        'type' => $this->input->post('milieu_type'),
                    );
                break;
            }
            if (!$this->model_site_effect->get_row(array('site_id' =>$site_id, 'type' => $type))) {
                $this->model_site_effect->add(array(
                    'site_id' => $site_id,
                    'type' => $type,
                    'config' => serialize($config),
                ));
            } else {
                $this->model_site_effect->update(array('site_id' => $site_id, 'type' => $type), array('config' => serialize($config)));
            }
            redirect_return('effect');
        } else {
            $site_effect = array();
            $res_list = $this->model_site_effect->get_all(array('site_id' => $site_id));
            foreach ($res_list as $_effect) {
                $_effect['config'] = unserialize($_effect['config']);
                $site_effect[$_effect['type']] = $_effect;
            }
            $tpl_data['site_effect'] = $site_effect;
            $this->load->library('encrypt');
            $token_data = array('user_id' => $site_id, 'time' => time());
            $tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
            $this->twig->display('effect/index', $tpl_data);
        }
	}

    public function upload_music(){
        $this->load->library('encrypt');
        $token = trim($this->input->get_post('token', TRUE));
        $token_decoded = $this->encrypt->decode($token);
        if ( ! $token_decoded) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => '请通过正常途径上传'));
            exit;
        }
        $token_data = unserialize($token_decoded);
        if ( ! isset($token_data['time']) OR ! isset($token_data['user_id']) OR (time() - $token_data['time']) > 3600) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => '请通过正常途径上传'));
            exit;
        }
        $upload_config = array(
            'upload_path'	=> FCPATH.'images/'.$token_data['user_id'].'/'.date('Ym').'/',
            'allowed_types'	=> 'mp3',
            'max_size'		=> 1024 * 10,
            'encrypt_name'     => TRUE
        );
        $this->load->library('upload', $upload_config);

        if(!is_dir($upload_config['upload_path'])){
            mkdir($upload_config['upload_path'], 0777, TRUE);
        }

        if ( ! $this->upload->do_upload('userfile')) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => $this->upload->display_errors('', '')));
            exit;
        } else {
            $mp3 = $this->upload->data();
            $filePath = $mp3['full_path'];

            $mp3_url = str_replace(str_replace(DIRECTORY_SEPARATOR, '/', FCPATH), '/', $filePath);
            echo json_encode(array(
                'success'     => 1,
                'mp3'         => image_url($mp3_url)
            ));
            exit;
        }
    }

    protected function show_message($success, $message, $redirect, $back = 0) {
        if ($this->input->is_ajax_request()) {
            $data = array(
                'success'	=> $success ? 1 : 0,
                'message'	=> strip_tags($message),
            );
            header('Content-type: application/json');
            echo json_encode($data);
        } else {
            $tpl_data = array(
                'message'	=> $message,
                'redirect'	=> $redirect,
                'back'      => $back
            );
            $this->twig->display('show_message', $tpl_data);
        }
        exit;
    }
}