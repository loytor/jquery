<?php
/**
 * Created by JetBrains PhpStorm.
 * User: llj
 * Date: 13-9-23
 * Time: 上午10:46
 * To change this template use File | Settings | File Templates.
 * @property Model_reserve_store_category $model_reserve_store_category
 * @property Model_app_config $model_app_config
 * @property Model_reserve_store $model_reserve_store
 */
class Reserve_category extends MY_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('model_reserve_store_category');
		$this->load->model('model_reserve_store');
		$this->load->model('model_app_config');
		$this->load->config('reserve');
		$this->types_arr = $this->config->item('reserve_types');
	}

	/**
	 * 门店分类列表
	 */
	public function index($type)
	{
		$this->has_reserve_auth($type);

		$id = $this->input->get('id');
		$store = $this->model_reserve_store->get_store_row(array('reserve_store.id'=>$id, 'type'=>$this->types_arr[$type]['type'], 'reserve_store.wid'=>User::$user_id));
		if(!$store)
		{
			$this->show_message(FALSE, '该门店不存在', '/reserve_store/'.$type);
		}
		$tpl_data['store'] = $store;

		$name = $this->input->get_post('name');

		$tpl_data['name'] = $name ? $name : '';

		$page = (int)$this->input->get('per_page');
		$page = $page ? $page : self::CUR_PAGE;
		$this->pageQueryString = true;

		$where = array('address_id'=>$store['address_id'], 'wid'=>User::$user_id, 'type'=>$this->types_arr[$type]['type'], 'status != '=>-1);
		//用于过滤查找
		$qs = array();
		if($name)
		{
			$where['name'] = 'like:'.$name;
			$qs[] = 'name='.$name;
		}

		$queryStr = implode('&', $qs);
		$this->queryString = '?id='. $id . $queryStr;

		$list = $this->model_reserve_store_category->get_all($where, $this->pageSize, $page, 'sort', 'asc');
		$tpl_data['list'] = $list;

		$tpl_data['type'] = $type;
		$tpl_data['type_info'] = $this->types_arr[$type];
		$tpl_data['per_page'] = $this->pageSize;
		$tpl_data['page'] = $page;
		$tpl_data['pagination'] = $this->pages($this->model_reserve_store_category->total_rows($where));
		$tpl_data['cur_nav'] = 'member_sys';
		$this->twig->display('reserve_category/index', $tpl_data);
	}

	/**
	 * 添加分类
	 */
	public function add($type, $store_id)
	{
		$this->has_reserve_auth($type);

		$store = $this->model_reserve_store->get_store_row(array('reserve_store.id'=>$store_id, 'type'=>$this->types_arr[$type]['type'], 'reserve_store.wid'=>User::$user_id));
		if(!$store)
		{
			$this->show_message(FALSE, '该门店不存在', '/reserve_store/'.$type);
		}
		$tpl_data['store'] = $store;

		$this->form_validation->set_rules('name', '分类名称', 'trim|required|max_length[32]');
		$this->form_validation->set_rules('sort', '排序', 'trim|is_natural');
		if($this->form_validation->run())
		{
			$this->model_reserve_store_category->address_id = $store['address_id'];
			$this->model_reserve_store_category->wid = User::$user_id;
			$this->model_reserve_store_category->type = $this->types_arr[$type]['type'];
			$this->model_reserve_store_category->name = $this->form_validation->set_value('name');
/*			$this->model_reserve_store_category->icon = $this->input->post('icon');
			$this->model_reserve_store_category->desc = $this->input->post('desc');*/
			$this->model_reserve_store_category->enabled = $this->input->post('enabled');
			$this->model_reserve_store_category->sort = (int)$this->input->post('sort');
			$this->model_reserve_store_category->property = json_encode($this->input->post('property'));
			$this->model_reserve_store_category->status = 0;

			if($this->model_reserve_store_category->add())
			{
				$this->show_message(TRUE, '添加分类成功', '/reserve_category/'.$type.'?id='.$store_id);
			}
			else
			{
				$this->show_message(FALSE, '添加分类失败', '/reserve_category/add/'.$type.'/'.$store_id);
			}
		}
		else
		{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/reserve_category/add/'.$type.'/'.$store_id);
			}
		}

		$tpl_data['extend_fields'] = $this->extend_fields($type);
		$tpl_data['type'] = $type;
		$tpl_data['type_info'] = $this->types_arr[$type];
		$tpl_data['token'] = $this->token;
		$tpl_data['cur_nav'] = 'member_sys';
		$this->twig->display('reserve_category/add', $tpl_data);
	}

	/**
	 * @param $type
	 * @param $store_id门店id
	 * @param $id 门店分类id
	 * 编辑门店分类
	 */
	public function edit($type, $store_id, $id)
	{
		$this->has_reserve_auth($type);

		$store = $this->model_reserve_store->get_store_row(array('reserve_store.id'=>$store_id, 'type'=>$this->types_arr[$type]['type'], 'reserve_store.wid'=>User::$user_id));
		if(!$store)
		{
			$this->show_message(FALSE, '该门店不存在', '/reserve_store/'.$type);
		}
		$tpl_data['store'] = $store;

		$where = array('id'=>$id, 'address_id'=>$store['address_id'], 'type'=>$this->types_arr[$type]['type'], 'wid'=>User::$user_id);
		$category = $this->model_reserve_store_category->get_row($where);
		if(!$category)
		{
			$this->show_message(FALSE, '该分类不存在', '/reserve_category/'.$type.'?id='.$store_id);
		}
		$tpl_data['property'] = json_decode($category['property'], TRUE);

		$this->form_validation->set_rules('name', '分类名称', 'trim|required|max_length[32]');
		$this->form_validation->set_rules('sort', '排序', 'trim|is_natural');
		if($this->form_validation->run())
		{
			$data_set['name'] = $this->form_validation->set_value('name');
/*			$data_set['icon'] = $this->input->post('icon');
			$data_set['desc'] = $this->input->post('desc');*/
			$data_set['enabled'] = $this->input->post('enabled');
			$data_set['sort'] = (int)$this->input->post('sort');
			$data_set['property'] = json_encode($this->input->post('property'));

			if($this->model_reserve_store_category->update($where, $data_set))
			{
				$this->show_message(TRUE, '编辑分类成功', '/reserve_category/'.$type.'?id='.$store_id);
			}
			else
			{
				$this->show_message(FALSE, '编辑分类失败', '/reserve_category/edit/'.$type.'/'.$store_id.'/'.$id);
			}
		}
		else
		{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/reserve_category/edit/'.$type.'/'.$store_id.'/'.$id);
			}
		}

		$tpl_data['category'] = $category;
		$tpl_data['extend_fields'] = $this->extend_fields($type);
		$tpl_data['type'] = $type;
		$tpl_data['type_info'] = $this->types_arr[$type];
		$tpl_data['token'] = $this->token;
		$tpl_data['cur_nav'] = 'member_sys';
		$this->twig->display('reserve_category/edit', $tpl_data);
	}

	/**
	 * @param $type
	 * @param $store_id
	 * @param $id
	 * 删除该门店分类
	 */
	public function delete($type, $store_id, $id)
	{
		$this->has_reserve_auth($type);

		$store = $this->model_reserve_store->get_store_row(array('reserve_store.id'=>$store_id, 'type'=>$this->types_arr[$type]['type'], 'reserve_store.wid'=>User::$user_id));
		if(!$store)
		{
			$this->show_message(FALSE, '该门店不存在', '/reserve_store/'.$type);
		}
		$tpl_data['store'] = $store;

		$where = array('id'=>$id, 'address_id'=>$store['address_id'], 'type'=>$this->types_arr[$type]['type'], 'wid'=>User::$user_id);
		$category = $this->model_reserve_store_category->get_row($where);
		if(!$category)
		{
			$this->show_message(FALSE, '该分类不存在', '/reserve_category/'.$type.'?id='.$store_id);
		}

		$data_set['status'] = -1;
		if($this->model_reserve_store_category->update($where, $data_set))
		{
			$this->show_message(TRUE, '删除分类成功', '/reserve_category/'.$type.'?id='.$store_id);
		}
		else
		{
			$this->show_message(FALSE, '删除分类失败', '/reserve_category/'.$type.'?id='.$store_id);
		}
	}

	public function has_reserve_auth($type)
	{
		if(!$this->has_authority('reserve/'.$type)){
			$this->show_message(FALSE, '您没有该权限', base_url());
		}
	}

	//获取扩展字段
	private function extend_fields($type)
	{
		$config = $this->model_app_config->get_one(array('user_id'=>User::$user_id, 'type'=>'reserve_category_'.$type), 'config');
		$config = json_decode($config, TRUE);
		$extend_fields = $config['url'];
		if(!$extend_fields)
		{
			$default_config = $this->config->item($type.'_category');
			$extend_fields = $default_config['url'];
		}
		return $extend_fields;
	}
}