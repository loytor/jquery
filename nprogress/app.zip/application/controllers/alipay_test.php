<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Class Menu
 * @property Model_menu $model_menu
 * @property Model_app_config $model_app_config
 * @property Curl $curl
 */

class Alipay_test extends MY_Controller {
    private $key = array();

	public function __construct() {
		parent::__construct();
		$this->load->database();
        $this->fix_key();
	}

	public function index() {
        //支付宝自定义菜单创建开始
        $this->load->library('curl');
        $appid = '2014070800006905';

        $alipay_menu = '{
    "button": [
        {
            "actionParam": "ZFB_HFCZ",
            "actionType": "out",
            "name": "话费充值"
        },
        {
            "name": "查询",
            "subButton": [
                {
                    "actionParam": "ZFB_YECX",
                    "actionType": "out",
                    "name": "余额查询"
                },
                {
                    "actionParam": "ZFB_LLCX",
                    "actionType": "out",
                    "name": "流量查询"
                },
                {
                    "actionParam": "ZFB_HFCX",
                    "actionType": "out",
                    "name": "话费查询"
                }
            ]
        },
        {
            "actionParam": "http://m.alipay.com",
            "actionType": "link",
            "name": "最新优惠"
        }
    ]
}';
        $timeStamp = date("Y-m-d H:i:s");
        $biz_content = menu_clean(json_encode(json_decode($alipay_menu)));
        //$string = "appid=$appid&charset=GBK&method=alipay.mobile.public.menu.add&sign_type=RSA&timestamp=$timeStamp";

        $sign = '';//签名
        //openssl_private_encrypt($string, $sign, $this->key['private_key']);

        //$url = "https://openapi.alipay.com/gateway.do?charset=GBK&sign=$sign&sign_type=RSA&app_id=$appid&method=alipay.mobile.public.menu.add&amp;timestamp=$timeStamp";

        $params = array(
            'method'=>'alipay.mobile.public.menu.add',
            'app_id'=>$appid,
            'sign_type'=>'RSA',
            'charset'=>'GBK',
            'timestamp'=>$timeStamp,
            'biz_content'=>$biz_content,
        );
        ksort($params);
        reset($params);
        $sign_string = urldecode(http_build_query($params));
        //openssl_private_encrypt($sign_string, $sign, $this->key['private_key']);

        $res = openssl_get_privatekey($this->key['private_key']);
        openssl_sign($sign_string, $sign, $res);
        openssl_free_key($res);
        $sign = base64_encode($sign);

        $params['sign'] = $sign;
        $tmpCreateInfo = $this->curl->post('https://openapi.alipay.com/gateway.do', $params);


        $tmpCreateInfo = iconv('GBK', 'UTF-8', $tmpCreateInfo);
        $tmpCreateInfo = json_decode($tmpCreateInfo, true);

        $response = $tmpCreateInfo['alipay_mobile_public_menu_add_response'];
        if($response['code'] == 200 )
        {
            $this->show_message(true, $response['msg'], '/alipay_menu', 1);
        }else{
            $this->show_message(false, $response['msg'].'，支付宝错误代码:'.$response['code'], '/alipay_menu', 1);
        }

    }

    //更新菜单
    public function update() {
        //支付宝自定义菜单更新开始
        $this->load->library('curl');
        $appid = '2014070800006905';

        $alipay_menu = '{
    "button": [
        {
            "actionParam": "ZFB_HFCZ",
            "actionType": "out",
            "name": "话费充值"
        },
        {
            "name": "查询",
            "subButton": [
                {
                    "actionParam": "ZFB_YECX",
                    "actionType": "out",
                    "name": "余额查询"
                },
                {
                    "actionParam": "ZFB_LLCX",
                    "actionType": "out",
                    "name": "流量查询"
                },
                {
                    "actionParam": "ZFB_HFCX",
                    "actionType": "out",
                    "name": "话费查询"
                }
            ]
        },
        {
            "actionParam": "http://m.alipay.com",
            "actionType": "link",
            "name": "最新优惠"
        }
    ]
}';
        $timeStamp = date("Y-m-d H:i:s");
        $biz_content = menu_clean(json_encode(json_decode($alipay_menu)));
        //$string = "appid=$appid&charset=GBK&method=alipay.mobile.public.menu.add&sign_type=RSA&timestamp=$timeStamp";

        $sign = '';//签名
        //openssl_private_encrypt($string, $sign, $this->key['private_key']);

        //$url = "https://openapi.alipay.com/gateway.do?charset=GBK&sign=$sign&sign_type=RSA&app_id=$appid&method=alipay.mobile.public.menu.add&amp;timestamp=$timeStamp";

        $params = array(
            'method'=>'alipay.mobile.public.menu.update',
            'app_id'=>$appid,
            'sign_type'=>'RSA',
            'charset'=>'GBK',
            'timestamp'=>$timeStamp,
            'biz_content'=>$biz_content,
        );
        ksort($params);
        reset($params);
        $sign_string = urldecode(http_build_query($params));
        //openssl_private_encrypt($sign_string, $sign, $this->key['private_key']);

        $res = openssl_get_privatekey($this->key['private_key']);
        openssl_sign($sign_string, $sign, $res);
        openssl_free_key($res);
        $sign = base64_encode($sign);

        $params['sign'] = $sign;
        $tmpCreateInfo = $this->curl->post('https://openapi.alipay.com/gateway.do', $params);


        $tmpCreateInfo = iconv('GBK', 'UTF-8', $tmpCreateInfo);
        $tmpCreateInfo = json_decode($tmpCreateInfo, true);
        dump($tmpCreateInfo);exit;
        $response = $tmpCreateInfo['alipay_mobile_public_menu_add_response'];
        if($response['code'] == 200 )
        {
            $this->show_message(true, $response['msg'], '/alipay_menu', 1);
        }else{
            $this->show_message(false, $response['msg'].'，支付宝错误代码:'.$response['code'], '/alipay_menu', 1);
        }

    }


    //获取菜单
    public function get() {
        $this->load->library('curl');
        $appid = '2014070800006905';


        $timeStamp = date("Y-m-d H:i:s");
        //$biz_content = menu_clean(json_encode(json_decode($alipay_menu)));
        //$string = "appid=$appid&charset=GBK&method=alipay.mobile.public.menu.add&sign_type=RSA&timestamp=$timeStamp";

        $sign = '';//签名
        //openssl_private_encrypt($string, $sign, $this->key['private_key']);

        //$url = "https://openapi.alipay.com/gateway.do?charset=GBK&sign=$sign&sign_type=RSA&app_id=$appid&method=alipay.mobile.public.menu.add&amp;timestamp=$timeStamp";

        $params = array(
            'method'=>'alipay.mobile.public.menu.get',
            'app_id'=>$appid,
            'sign_type'=>'RSA',
            'charset'=>'GBK',
            'timestamp'=>$timeStamp,
        );
        ksort($params);
        reset($params);
        $sign_string = urldecode(http_build_query($params));
        //openssl_private_encrypt($sign_string, $sign, $this->key['private_key']);

        $res = openssl_get_privatekey($this->key['private_key']);
        openssl_sign($sign_string, $sign, $res);
        openssl_free_key($res);
        $sign = base64_encode($sign);

        $params['sign'] = $sign;
        $tmpCreateInfo = $this->curl->post('https://openapi.alipay.com/gateway.do', $params);


        $tmpCreateInfo = iconv('GBK', 'UTF-8', $tmpCreateInfo);
        $tmpCreateInfo = json_decode($tmpCreateInfo, true);
        dump($tmpCreateInfo);exit;
        $response = $tmpCreateInfo['alipay_mobile_public_menu_add_response'];
        if($response['code'] == 200 )
        {
            $this->show_message(true, $response['msg'], '/alipay_menu', 1);
        }else{
            $this->show_message(false, $response['msg'].'，支付宝错误代码:'.$response['code'], '/alipay_menu', 1);
        }
    }


    /**
     * 处理公钥和私钥
     */
    private function fix_key()
    {
        $this->load->config('alipay_key');
        $alipay_key = $this->config->item('alipay_key');
        $private_key = $alipay_key['private_key'];
        $public_key = $alipay_key['public_key'];
        $this->key = array(
            'public_key' => $public_key,
            'public_key_cl' => $this->key_clean($public_key,'public'),
            'private_key' => $private_key,
            'private_key_cl' => $this->key_clean($private_key,'private'),
        );
    }

    //清楚公钥和私钥中的多余字符
    private function key_clean($key,$type='public') {
        if( $type=='public' ){
            $begin = "-----BEGIN PUBLIC KEY-----";
            $end = "-----END PUBLIC KEY-----";
        }else if( $type=='private' ){
            $begin = "-----BEGIN PRIVATE KEY-----";
            $end = "-----END PRIVATE KEY-----";
        }

        $key = preg_replace("/".$begin."/", "", $key);
        $key = preg_replace("/".$end."/", '', $key);
        $key = preg_replace("//s", "", $key);
        $key = preg_replace('/\r|\n/', "", $key);

        return $key;
    }





	private function var_url_encode($var) {
		if (is_array ( $var )) {
			foreach ( $var as $k => $v ) {
				if (is_scalar ( $v ))
				{
					$var [$k] = urlencode ( $v );
				}
				else {
					$var [$k] = $this->var_url_encode ( $v );
				}
			}
		}
		else {
			$var = urlencode ( $var );
		}
		return $var;
	}

	/**
	 * @param $str
	 * 判断是否是外链
	 */
	private function is_url($str)
	{
		return preg_match("/^(http|https):\/\/[A-Za-z0-9\-\_]+\.[A-Za-z0-9]+[\/=\?%\-&_~`@[\]\’:+!]*([^<>\"])*$/", $str);
	}
}