<?php
/**
 * Created by JetBrains PhpStorm.
 * User: zhw
 * Date: 13-7-25
 * Time: 下午2:27
 * To change this template use File | Settings | File Templates.
 *
 * @property Model_custom_res $model_custom_res
 */
class Custom_res extends MY_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
		$this->load->model('model_custom_res');
	}

	public function index()
	{
		$where = array('user_id'=>User::$user_id);
		$this->pageQueryString = true;

        $this->pageQueryString = true;
        $page = (int)$this->input->get('per_page');
        $page = $page ? $page : self::CUR_PAGE;

		$tpl_data['res_arr'] = $this->model_custom_res->get_all($where,$this->pageSize, $page);
		/*foreach($tpl_data['res_arr'] as &$res)
		{
			$res['res'] = site_url($res['res']);
		}*/
		$tpl_data['pagination'] = $this->pages($this->model_custom_res->total_rows($where));
		$tpl_data['page_size'] = $this->pageSize;
        $tpl_data['page'] = $page;

		$this->load->library('encrypt');
		$token_data = array('user_id' => User::$user_id, 'time' => time());
		$tpl_data['token'] = $this->encrypt->encode(serialize($token_data));

		$tpl_data['cur_nav'] = 'cate';
		$this->twig->display('tpl/customRes', $tpl_data);
	}

	public function save()
	{
		$this->load->library('form_validation');
		$this->load->helper('form');
		$this->form_validation->set_rules('res', '资源图片', 'trim|required');
		if ($this->form_validation->run()) {
			$this->model_custom_res->user_id = User::$user_id;
			$this->model_custom_res->res = $this->input->post('res');
			$this->model_custom_res->dt_add = date('Y-m-d H:i:s');
			$this->model_custom_res->add();
			$this->show_message(TRUE, '保存成功', '/custom_res');
		} else {
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/custom_res');
			}
		}
	}

	public function delete($id = '')
	{
		$res = $this->model_custom_res->get_row(array('id' => $id, 'user_id' => User::$user_id));
		if ( ! $res) {
			$this->show_message(FALSE, '找不到资源', '/custom_res');
		}

		$this->model_custom_res->delete(array('id'=>$id));
		//删除图片
		if (file_exists(FCPATH.$res['res'])) {
			unlink(FCPATH.$res['res']);
		}
		$this->show_message(TRUE, '删除成功', '/custom_res');
	}
}