<?php
/**
 * Created by JetBrains PhpStorm.
 * User: zhw
 * Date: 13-10-9
 * Time: 上午9:59
 * To change this template use File | Settings | File Templates.
 *
 * @property Model_address $model_address
 * @property Model_cate $model_cate
 * @property Model_app_config $model_app_config
 * @property Model_groupon_store $model_groupon_store
 * @property Model_cate_lists $model_cate_lists
 * @property Model_groupon $model_groupon
 * @property Model_groupon_category $model_groupon_category
 * @property Model_groupon_order $model_groupon_order
 * @property Model_groupon_token $model_groupon_token
 */
class Groupon extends MY_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('model_app_config');
		$this->load->model('model_cate');
		$this->load->model('model_cate_lists');
		$this->load->model('model_address');
		$this->load->model('model_groupon_store');
	}

	public function index()
	{
		//获取所有栏目
		$cate_arr = array();
		$_cate_arr = $this->model_cate->get_all(array('user_id' => User::$user_id));
		foreach ($_cate_arr as $_cate) {
			$cate_arr[$_cate['id']] = $_cate;
		}
		$tpl_data['cate_arr'] = $cate_arr;

		$address = $this->model_address->get_all(array('wid'=>User::$user_id), '', '');
		$configType = 'groupon';
		$config = $this->model_app_config->get_row(array('user_id'=>User::$user_id, 'type'=> $configType));
		$reserve_config =  $config = json_decode($config['config'], TRUE);
		$config['icon'] = isset($config['icon']) ? $config['icon'] : '';
		$tpl_data['config'] = $config;

		//外链地址
		$domain = $this->session->userdata('domain');
		$url = $domain ? "http://".$domain.".bama555.com/groupon" : '';
		$tpl_data['url'] = $url;

		//读取当前预订类型所有门店的address_id
		$reserve_store = $this->model_groupon_store->get_all(array('wid'=>User::$user_id));
		$selected_ad_ids = array();
		foreach($reserve_store as $rs)
		{
			$selected_ad_ids[] = $rs['address_id'];
		}

		$unselect_address = array();
		$selected_address = array();
		foreach($address as $ad)
		{
			if(in_array($ad['id'], $selected_ad_ids))
			{
				$selected_address[] = $ad;
			}
			elseif($ad['status'] == 0)
			{
				$unselect_address[] = $ad;
			}
		}
		$tpl_data['unselect_address'] = $unselect_address;
		$tpl_data['selected_address'] = $selected_address;

		$this->form_validation->set_rules('name', '标题', 'trim|required|max_length[32]');
		if($this->form_validation->run())
		{
			$base_config['cate_id'] = $cate_id = $this->input->post('cate_id');
			$base_config['name'] = $this->form_validation->set_value('name');
			$base_config['icon'] = $this->input->post('icon');
			$base_config['is_open'] = $this->input->post('is_open');
			$base_config['use_type'] = $this->input->post('use_type');
			$data_set['config'] = json_encode($base_config);

			if($reserve_config)//更新配置
			{
				$where['user_id'] = User::$user_id;
				$where['type']    = $configType;
				if($this->model_app_config->update($where, $data_set))
				{
					//先从reserve_store表中删除当前预订类型的记录
					$this->model_groupon_store->delete(array('wid'=>User::$user_id));
					//再插入当前地址ID到reserve_store表
					$address = $this->input->post('address');
					if($address)
					{
						foreach($address as $ad)
						{
							$data_rs['wid'] = User::$user_id;
							$data_rs['address_id'] = $ad;
							$this->model_groupon_store->add($data_rs);
						}
					}
					//更改cate_lists表的记录
					if (isset($config['cate_id']) && $config['cate_id'] != $cate_id) {
						if ($cate_id) {
							$data_cate_lists['user_id'] = User::$user_id;
							$data_cate_lists['cate_id'] = $cate_id;
							$data_cate_lists['type'] = $configType;
							$data_cate_lists['lists_id'] = 0;
							$data_cate_lists['rank'] = 9999;
							$this->model_cate_lists->add($data_cate_lists);
						}
						if ($config['cate_id']) {
							$del_data_cate_lists['user_id'] = User::$user_id;
							$del_data_cate_lists['cate_id'] = $config['cate_id'];
							$del_data_cate_lists['type'] = $configType;
							$del_data_cate_lists['lists_id'] = 0;
							$this->model_cate_lists->delete($del_data_cate_lists);
						}
					}

					$this->show_message(TRUE, '保存设置成功', '/groupon/');
				}
				else
				{
					$this->show_message(FALSE, '保存设置失败', '/groupon/');
				}
			}
			else//添加配置
			{
				$data_set['user_id'] = User::$user_id;
				$data_set['type'] = $configType;
				if($this->model_app_config->add($data_set))
				{
					//插入当前地址ID到reserve_store表
					$address = $this->input->post('address');
					if($address)
					{
						foreach($address as $ad)
						{
							$data_rs['wid'] = User::$user_id;
							$data_rs['address_id'] = $ad;
							$this->model_groupon_store->add($data_rs);
						}
					}

					//归档记录添加
					if ($cate_id) {
						$data_cate_lists['user_id'] = User::$user_id;
						$data_cate_lists['cate_id'] = $cate_id;
						$data_cate_lists['type'] = $configType;
						$data_cate_lists['lists_id'] = 0;
						$data_cate_lists['rank'] = 9999;
						$this->model_cate_lists->add($data_cate_lists);
					}
					$this->show_message(TRUE, '保存设置成功', '/groupon');
				}
				else
				{
					$this->show_message(FALSE, '保存设置失败', '/groupon');
				}
			}

		}
		else
		{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/groupon/');
			}
		}

		$tpl_data['type_info'] = '基本设置';
		$tpl_data['cur_nav'] = 'member_sys';
		$tpl_data['nav'] = 'setting';
		$tpl_data['token'] = $this->token;
		$this->twig->display('groupon/setting', $tpl_data);
	}

	/**
	 * 团购列表
	 */
	public function lists()
	{
		$this->load->model('model_groupon');
		$this->load->model('model_groupon_category');
		$this->load->model('model_groupon_order');

		//分类列表
		$rows = $this->model_groupon_category->get_all(array('wid' => User::$user_id), '', '');
		$categoryList = array();
		$categoryList[0] = '';
		foreach ($rows as $v) {
			$categoryList[$v['id']] = $v['name'];
		}

		$title = $this->input->get_post('title');
		$originalPrice = $this->input->get_post('originalPrice');
		$presentPrice = $this->input->get_post('presentPrice');
		$categoryId = $this->input->get_post('categoryId');

		$tpl_data['title'] = $title ? $title : '';
		$tpl_data['originalPrice'] = $originalPrice ? $originalPrice : '';
		$tpl_data['presentPrice'] = $presentPrice ? $presentPrice : '';
		$tpl_data['categoryId'] = $categoryId ? $categoryId : '';

		$page = (int)$this->input->get('per_page');
		$page = $page ? $page : self::CUR_PAGE;
		$this->pageQueryString = true;

		$where = array('wid' => User::$user_id);
		$qs = array();

		if($title)
		{
			$where['title'] = 'like:'.$title;
			$qs[] = 'title='.$title;
		}
		if($originalPrice)
		{
			$where['originalPrice'] = $originalPrice;
			$qs[] = 'originalPrice='.$originalPrice;
		}
		if($presentPrice)
		{
			$where['presentPrice'] = $presentPrice;
			$qs[] = 'presentPrice='.$presentPrice;
		}
		if($categoryId)
		{
			$where['categoryId'] = $categoryId;
			$qs[] = 'categoryId='.$categoryId;
		}

		$queryStr = implode('&', $qs);
		$this->queryString = '?' . $queryStr;

		$list = $this->model_groupon->get_all($where, $this->pageSize, $page);
		foreach ($list as $k => $row) {
			if (empty($categoryList[$row['categoryId']])) {
				$list[$k]['categoryId'] = 0;
			}
		}


//		foreach ($list as $k => $row) {
//			$list[$k]['joinNum'] = $this->model_groupon_order->get_join_num(array('grouponId' => $row['id']));
//		}

		$tpl_data['type_info'] = '团购列表';
		$tpl_data['cur_nav'] = 'member_sys';
		$tpl_data['nav'] = 'lists';
		$tpl_data['list'] = $list;
		$tpl_data['per_page'] = $this->pageSize;
		$tpl_data['page'] = $page;
		$tpl_data['pagination'] = $this->pages($this->model_groupon->total_rows($where));
		$tpl_data['categoryList'] = $categoryList;
		$this->twig->display('groupon/groupon_list', $tpl_data);
	}

	/**
	 * 添加团购
	 */
	public function add()
	{
		$this->load->model('model_groupon_category');
		$this->load->model('model_groupon');

		$this->form_validation->set_rules('title', '团购长标题', 'trim|required');
		$this->form_validation->set_rules('subtitle', '团购短标题', 'trim|required');
		//$this->form_validation->set_rules('categoryId', '分类名称', 'trim|required|integer');
		$this->form_validation->set_rules('img', '团购图片', 'trim|required');
		$this->form_validation->set_rules('originalPrice', '团购原价', 'trim|required');
		$this->form_validation->set_rules('presentPrice', '团购现价', 'trim|required');
		$this->form_validation->set_rules('beginTime', '开始时间', 'trim|required');
		$this->form_validation->set_rules('endTime', '结束时间', 'trim|required');
		$this->form_validation->set_rules('details', '团购详情', 'trim|required');
		$this->form_validation->set_rules('totalLimit', '总库存量', 'trim|required|integer');
		if($this->form_validation->run())
		{
			$d['wid'] = User::$user_id;
			$d['title'] = $this->input->post('title');
			$d['subtitle'] = $this->input->post('subtitle');
			$d['categoryId'] = (int)$this->input->post('categoryId');
			$d['singleLimit'] = (int)$this->input->post('singleLimit');
			$d['img'] = $this->input->post('img');
			$d['originalPrice'] = $this->input->post('originalPrice');
			$d['presentPrice'] = $this->input->post('presentPrice');
			$d['beginTime'] = strtotime($this->input->post('beginTime'));
			$d['endTime'] = strtotime($this->input->post('endTime'));
			$d['details'] = $this->input->post('details');
			$d['speTips'] = $this->input->post('speTips');
			$d['totalLimit'] = $this->input->post('totalLimit');
			//售卖分店
			$address = $this->input->post('address');
			$storeId = '';
			foreach ($address as $v) {
				$storeId .= $v .',';
			}
			if ($storeId) {
				$storeId = substr($storeId, 0, -1);
				$d['storeId'] = $storeId;
			}

			//价格区间
			$isPriceRange = $this->input->post('isPriceRange');
			if ($isPriceRange)
			{
				$priceRange1 = $this->input->post('priceRange1');
				$priceRange2 = $this->input->post('priceRange2');
				$priceRange3 = $this->input->post('priceRange3');
				$priceRange = array();
				foreach ($priceRange1 as $k=>$v) {
					if (!empty($v)) {
						$priceRange[$k]['num1'] = $v;
						$priceRange[$k]['num2'] = $priceRange2[$k];
						$priceRange[$k]['pirce'] = $priceRange3[$k];
					}
				}
				if ($priceRange)
				{
					$d['priceRange'] = json_encode($priceRange);
				}
			}

			if ($this->model_groupon->add($d)) {
				$this->show_message(TRUE, '添加团购成功', '/groupon/lists');
			}
			else {
				$this->show_message(TRUE, '添加团购成功', '/groupon/lists');
			}
		}
		else
		{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/groupon/add');
			}
		}

		$address = $this->model_address->get_all(array('wid'=>User::$user_id), '', '');
		//读取当前团购所有门店的address_id
		$reserve_store = $this->model_groupon_store->get_all(array('wid'=>User::$user_id));
		$selected_ad_ids = array();
		foreach($reserve_store as $rs)
		{
			$selected_ad_ids[] = $rs['address_id'];
		}

		$selected_address = array();
		foreach($address as $ad)
		{
			if(in_array($ad['id'], $selected_ad_ids))
			{
				$selected_address[] = $ad;
			}
		}
		$tpl_data['selected_address'] = $selected_address;

		//分类列表
		$tpl_data['categoryList'] = $this->model_groupon_category->get_all(array('wid' => User::$user_id), '', '');

		$tpl_data['type_info'] = '添加团购';
		$tpl_data['cur_nav'] = 'member_sys';
		$tpl_data['nav'] = 'lists';
		$tpl_data['token'] = $this->token;
		$this->twig->display('groupon/groupon_add', $tpl_data);
	}

	/**
	 * 添加团购
	 */
	public function edit($id)
	{
		$this->load->model('model_groupon_category');
		$this->load->model('model_groupon');

		$this->form_validation->set_rules('id', '团购Id', 'trim|required|integer');
		$this->form_validation->set_rules('title', '团购长标题', 'trim|required');
		$this->form_validation->set_rules('subtitle', '团购短标题', 'trim|required');
		//$this->form_validation->set_rules('categoryId', '分类名称', 'trim|required|integer');
		$this->form_validation->set_rules('img', '团购图片', 'trim|required');
		$this->form_validation->set_rules('originalPrice', '团购原价', 'trim|required');
		$this->form_validation->set_rules('presentPrice', '团购现价', 'trim|required');
		$this->form_validation->set_rules('beginTime', '开始时间', 'trim|required');
		$this->form_validation->set_rules('endTime', '结束时间', 'trim|required');
		$this->form_validation->set_rules('details', '团购详情', 'trim|required');
		$this->form_validation->set_rules('totalLimit', '总库存量', 'trim|required|integer');
		if($this->form_validation->run())
		{
			$id = (int)$this->input->post('id');
			$d['wid'] = User::$user_id;
			$d['title'] = $this->input->post('title');
			$d['subtitle'] = $this->input->post('subtitle');
			$d['categoryId'] = (int)$this->input->post('categoryId');
			$d['singleLimit'] = (int)$this->input->post('singleLimit');
			$d['img'] = $this->input->post('img');
			$d['originalPrice'] = $this->input->post('originalPrice');
			$d['presentPrice'] = $this->input->post('presentPrice');
			$d['beginTime'] = strtotime($this->input->post('beginTime'));
			$d['endTime'] = strtotime($this->input->post('endTime'));
			$d['details'] = $this->input->post('details');
			$d['speTips'] = $this->input->post('speTips');
			$d['totalLimit'] = $this->input->post('totalLimit');
			//售卖分店
			$address = $this->input->post('address');
			$storeId = '';
			if(is_array($address))
			{
				foreach ($address as $v) {
					$storeId .= $v .',';
				}
			}
			if ($storeId) {
				$storeId = substr($storeId, 0, -1);
				$d['storeId'] = $storeId;
			}

			//价格区间
			$isPriceRange = $this->input->post('isPriceRange');
			if ($isPriceRange)
			{
				$priceRange1 = $this->input->post('priceRange1');
				$priceRange2 = $this->input->post('priceRange2');
				$priceRange3 = $this->input->post('priceRange3');
				$priceRange = array();
				foreach ($priceRange1 as $k=>$v) {
					if (!empty($v)) {
						$priceRange[$k]['num1'] = $v;
						$priceRange[$k]['num2'] = $priceRange2[$k];
						$priceRange[$k]['pirce'] = $priceRange3[$k];
					}
				}
				if ($priceRange)
				{
					$d['priceRange'] = json_encode($priceRange);
				}
			}

			if ($this->model_groupon->update(array('wid' => User::$user_id, 'id' => $id), $d)) {
				$this->show_message(TRUE, '修改团购成功', '/groupon/lists');
			}
			else {
				$this->show_message(TRUE, '修改团购成功', '/groupon/lists');
			}
		}
		else
		{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/groupon/edit/'.$id);
			}
		}

		$address = $this->model_address->get_all(array('wid'=>User::$user_id), '', '');
		//读取当前团购所有门店的address_id
		$reserve_store = $this->model_groupon_store->get_all(array('wid'=>User::$user_id));
		$selected_ad_ids = array();
		foreach($reserve_store as $rs)
		{
			$selected_ad_ids[] = $rs['address_id'];
		}

		$selected_address = array();
		foreach($address as $ad)
		{
			if(in_array($ad['id'], $selected_ad_ids))
			{
				$selected_address[] = $ad;
			}
		}

		$id = (int)$id;
		if (!$id) {
			$this->show_message(false, '团购id为空', '/groupon/lists');
		}
		$row = $this->model_groupon->get_row(array('wid' => User::$user_id, 'id' => $id));
		$row['beginTime']= date('Y-m-d H:i:s', $row['beginTime']);
		$row['endTime']= date('Y-m-d H:i:s', $row['endTime']);
		$row['priceRange'] = json_decode($row['priceRange'], true);
		$row['storeId'] = explode(',', $row['storeId']);
		foreach ($selected_address as $k => $v) {
			$selected_address[$k]['selected'] = in_array($v['id'], $row['storeId']) ? true : false;
		}

		//分类列表
		$tpl_data['categoryList'] = $this->model_groupon_category->get_all(array('wid' => User::$user_id), '', '');
		$tpl_data['selected_address'] = $selected_address;
		$tpl_data['type_info'] = '编辑团购';
		$tpl_data['cur_nav'] = 'member_sys';
		$tpl_data['nav'] = 'lists';
		$tpl_data['token'] = $this->token;
		$tpl_data['row'] = $row;
		$this->twig->display('groupon/groupon_edit', $tpl_data);
	}

	/**
	 * 删除团购
	 */
	public function del($id)
	{
		$id = (int)$id;

		if (!$id) {
			$this->show_message(TRUE, '团购id为空', 'category_list');
		}
		$this->load->model('model_groupon');

		if ($this->model_groupon->delete(array('wid' => User::$user_id, 'id' => $id))) {
			$this->show_message(TRUE, '删除团购成功', '/groupon/lists');
		}
		else {
			$this->show_message(TRUE, '删除团购失败', '/groupon/lists');
		}
	}

	/**
	 * 团购上架
	 */
	public function up($id)
	{
		$id = (int)$id;

		if (!$id) {
			$this->show_message(TRUE, '团购id为空', 'category_list');
		}
		$this->load->model('model_groupon');
		$d['status'] = 1;
		if ($this->model_groupon->update(array('wid' => User::$user_id, 'id' => $id), $d)) {
			$this->show_message(TRUE, '团购上架成功', '/groupon/lists');
		}
		else {
			$this->show_message(TRUE, '团购上架失败', '/groupon/lists');
		}
	}

	/**
	 * 团购下架
	 */
	public function down($id)
	{
		$id = (int)$id;

		if (!$id) {
			$this->show_message(TRUE, '团购id为空', 'category_list');
		}
		$this->load->model('model_groupon');
		$d['status'] = 2;
		if ($this->model_groupon->update(array('wid' => User::$user_id, 'id' => $id), $d)) {
			$this->show_message(TRUE, '团购下架成功', '/groupon/lists');
		}
		else {
			$this->show_message(TRUE, '团购下架失败', '/groupon/lists');
		}
	}

	public function category()
	{
		$this->load->model('model_groupon_category');

		$page = (int)$this->input->get('per_page');
		$page = $page ? $page : self::CUR_PAGE;
		$this->pageQueryString = true;

		$where = array('wid' => User::$user_id);
		$list = $this->model_groupon_category->get_all($where, $this->pageSize, $page);


		$tpl_data['type_info'] = '团购分类';
		$tpl_data['cur_nav'] = 'member_sys';
		$tpl_data['nav'] = 'category';
		$tpl_data['list'] = $list;
		$tpl_data['page'] = $page;
		$tpl_data['per_page'] = $this->pageSize;
		$tpl_data['pagination'] = $this->pages($this->model_groupon_category->total_rows($where));
		$this->twig->display('groupon/category_list', $tpl_data);
	}

	public function category_add($id = '')
	{
		$this->load->model('model_groupon_category');


		$this->form_validation->set_rules('name', '分类名称', 'trim|required|max_length[32]');
		if($this->form_validation->run())
		{
			$id = (int)$this->input->post('id');
			$d['name'] = $this->input->post('name');
			$d['sort'] = (int)$this->input->post('sort');
			$d['sort'] = $d['sort'] == 0 ? 99 : $d['sort'];
			if ($id) {
				if ($this->model_groupon_category->update(array('wid' => User::$user_id, 'id' => $id), $d)) {
					$this->show_message(TRUE, '修改团购分类成功', '/groupon/category');
				}
				else {
					$this->show_message(TRUE, '修改团购分类失败', '/groupon/category');
				}
			}
			else {
				$d['wid'] = User::$user_id;
				if ($this->model_groupon_category->add($d)) {
					$this->show_message(TRUE, '添加团购分类成功', '/groupon/category');
				}
				else {
					$this->show_message(TRUE, '添加团购分类失败', '/groupon/category');
				}
			}
		}
		else
		{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/groupon/category');
			}
		}


		if (!empty($id)) {
			$row = $this->model_groupon_category->get_row(array('wid' => User::$user_id, 'id' => $id));
			$tpl_data['type_info'] = '编辑团购分类';
		}
		else {
			$row['id'] = $row['name'] = $row['sort'] =  '';
			$tpl_data['type_info'] = '添加团购分类';
		}


		$tpl_data['cur_nav'] = 'member_sys';
		$tpl_data['nav'] = 'category';
		$tpl_data['row'] = $row;

		$this->twig->display('groupon/category_add', $tpl_data);

	}

	public function category_del($id)
	{

		$id = (int)$id;

		if (!$id) {
			$this->show_message(TRUE, 'id为空', 'category_list');
		}
		$this->load->model('model_groupon_category');

		if ($this->model_groupon_category->delete(array('wid' => User::$user_id, 'id' => $id))) {
			$this->show_message(TRUE, '删除成功', '/groupon/category');
		}
		else {
			$this->show_message(TRUE, '删除失败', '/groupon/category');
		}
	}

	public function store()
	{
		$name = $this->input->get_post('name');
		$address = $this->input->get_post('address');
		$tel = $this->input->get_post('tel');

		$tpl_data['name'] = $name ? $name : '';
		$tpl_data['address'] = $address ? $address : '';
		$tpl_data['tel'] = $tel ? $tel : '';

		$page = (int)$this->input->get('per_page');
		$page = $page ? $page : self::CUR_PAGE;
		$this->pageQueryString = true;

		$where = array('groupon_store.wid'=>User::$user_id);
		//用于过滤查找
		$qs = array();
		if($name)
		{
			$where['name'] = 'like:'.$name;
			$qs[] = 'name='.$name;
		}
		if($address)
		{
			$where['address'] = 'like:'.$address;
			$qs[] = 'address='.$address;
		}
		if($tel)
		{
			$where['tel'] = 'like:'.$tel;
			$qs[] = 'tel='.$tel;
		}

		$queryStr = implode('&', $qs);
		$this->queryString = '?' . $queryStr;

		$list = $this->model_groupon_store->get_all_store($where, $this->pageSize, $page, 'groupon_store.id', 'asc');
		foreach($list as &$row)
		{
			$row['image'] = json_decode($row['image'], TRUE);
		}
		$tpl_data['list'] = $list;

		$tpl_data['type_info'] = '门店列表';
		$tpl_data['per_page'] = $this->pageSize;
		$tpl_data['page'] = $page;
		$tpl_data['pagination'] = $this->pages($this->model_groupon_store->total_rows($where));
		$tpl_data['cur_nav'] = 'member_sys';
		$tpl_data['nav'] = 'store';
		$this->twig->display('groupon/store_list', $tpl_data);
	}


	/**
	 * 编辑门店
	 */
	public function store_edit($id='')
	{

		$store = $this->model_groupon_store->get_store_row(array('groupon_store.id'=>$id, 'groupon_store.wid'=>User::$user_id));
		if(!$store)
		{
			$this->show_message(FALSE, '该门店不存在', '/groupon/store');
		}

		$this->form_validation->set_rules('business_mobile', '商家短信提醒手机号码', 'trim|max_length[20]');
		if($this->form_validation->run())
		{
			$data_set['business_mobile'] = $this->input->post('business_mobile');
			$data_set['instruction'] = $this->input->post('instruction');

			if($this->model_groupon_store->update(array('id'=>$id, 'wid'=>User::$user_id), $data_set))
			{
				$this->show_message(TRUE, '编辑门店成功', '/groupon/store/');
			}
			else
			{
				$this->show_message(FALSE, '编辑门店失败', '/groupon/store_edit/'.$id);
			}
		}
		else
		{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/groupon/store_edit/'.$id);
			}
		}

		$tpl_data['store'] = $store;
		$tpl_data['type_info'] = '编辑门店';
		$tpl_data['cur_nav'] = 'member_sys';
		$tpl_data['nav'] = 'store';
		$this->twig->display('groupon/store_edit', $tpl_data);
	}

	/**
	 * 订单列表
	 */
	public function order()
	{
		$page = (int)$this->input->get('per_page');
		$page = $page ? $page : self::CUR_PAGE;
		$this->pageQueryString = true;

		$where = array('groupon_order.wid' => User::$user_id);
		$title = $this->input->get_post('title');
		$name = $this->input->get_post('name');
		$mobile = $this->input->get_post('mobile');

		$tpl_data['name'] = $name ? $name : '';
		$tpl_data['title'] = $title ? $title : '';
		$tpl_data['mobile'] = $mobile ? $mobile : '';

		//用于过滤查找
		$qs = array();
		if($title)
		{
			$where['groupon.title'] = 'like:'.$title;
			$qs[] = 'title='.$title;
		}
		if($name)
		{
			$where['groupon_order.name'] = 'like:'.$name;
			$qs[] = 'name='.$name;
		}
		if($mobile)
		{
			$where['groupon_order.mobile'] = 'like:'.$mobile;
			$qs[] = 'mobile='.$mobile;
		}

		$queryStr = implode('&', $qs);
		$this->queryString = '?' . $queryStr;

		$queryStr = implode('&', $qs);
		$this->queryString = '?' . $queryStr;

		$this->load->model('model_groupon_order');

		$list = $this->model_groupon_order->get_all_order($where, $this->pageSize, $page);

		$tpl_data['type_info'] = '订单列表';
		$tpl_data['cur_nav'] = 'member_sys';
		$tpl_data['nav'] = 'order';
		$tpl_data['list'] = $list;
		$tpl_data['per_page'] = $this->pageSize;
		$tpl_data['page'] = $page;
		$tpl_data['pagination'] = $this->pages($this->model_groupon_order->total_rows($where));

		$this->twig->display('groupon/order_list', $tpl_data);
	}

	/**
	 * 导出所有订单
	 */
	public function export()
	{
		$where = array('groupon_order.wid' => User::$user_id);
		$this->load->model('model_groupon_order');
		$list = $this->model_groupon_order->get_all_order($where);
		$orderlist = array();
		if($list)
		{
			$fields = array(
				'#'=>'#',
				'subTitle'=>'团购标题',
				'name'=>'姓名',
				'mobile'=>'手机',
				'presentPrice'=>'团购价',
			    'inputtime'=>'下单时间',
			    'status'=>'状态',
				'num'=>'购买数量'
			);
			foreach($list as $key=> $_list)
			{
				$orderlist[$key]['subTitle'] = $_list['subTitle'];
				$orderlist[$key]['name'] = $_list['name'];
				$orderlist[$key]['mobile'] = $_list['mobile'];
				$orderlist[$key]['presentPrice'] = $_list['presentPrice'];
				$orderlist[$key]['inputtime'] = date('Y-m-d H:i:s',$_list['inputtime']);
				$orderlist[$key]['status'] = $_list['status'] ? '已取消' : '';
				$orderlist[$key]['num'] = $_list['num'];
			}
			$this->excel_export('所有订单列表', '所有订单列表', $fields, $orderlist);
		}
	}

	public function use_token($orderId)
	{
		if(!$orderId)
		{
			$this->show_message(FALSE, '团购订单不存在', '/groupon/order');
		}

		$this->load->model('model_groupon_order');
		$this->load->model('model_groupon_token');

		$where = array('groupon_order.wid' => User::$user_id, 'groupon_order.id' => $orderId);
		$row = $this->model_groupon_order->get_order_row($where);

		if(!$row)
		{
			$this->show_message(FALSE, '团购订单不存在', '/groupon/order');
		}



		if($this->submitCheck())
		{
			$token = $this->input->post('token');
            if($token)
            {
                $d['status'] = 1;
                $d['use_time'] = time();
                $where = array('orderId' => $orderId, 'wid' => User::$user_id);
                foreach ($token as $v) {
                    $where['token'] = $v;
                    $this->model_groupon_token->update($where, $d);
                }
                $this->show_message(TRUE, '使用成功', '/groupon/order');
            }
            else
            {
                $this->show_message(FALSE, '请选择团购码', '/groupon/use_token/'.$orderId);
            }
		}

		//团购token
		$where = array('wid' => User::$user_id, 'uid' => $row['uid'], 'orderId' => $orderId);
		$token = $this->model_groupon_token->get_all($where);
		if( $token ){
		    foreach( $token as $key=>$val ){
		        if( ($val['status']==1)&&$val['address_id'] ){
                    $this->load->model('address_model');
		            $address = $this->address_model->where(array('wid'=>User::$user_id, 'status'=>0,'id'=>$val['address_id']))->find();
                    $token[$key]['address'] = $address['name'];
                }
		    }
		}

		$tpl_data['type_info'] = '使用团购';
		$tpl_data['cur_nav'] = 'member_sys';
		$tpl_data['nav'] = 'order';
		$tpl_data['row'] = $row;
		$tpl_data['token'] = $token;
		$this->twig->display('groupon/use_token', $tpl_data);

	}

	/**
	 * 设置参与人数
	 */
	public function set_groupon_cheat()
	{
		$id = $this->input->post('id');
		$this->load->model('model_groupon');
		$cheatnum = $this->input->post('cheatnum');

		$d['cheatNum'] = ($cheatnum>=0) ? $cheatnum : 0 ;

		header('Content-type: application/json');
		if ($this->model_groupon->update(array('wid' => User::$user_id, 'id' => $id), $d)) {
			$data = array(
				'success'	=> 1,
				'message'	=> '',
			);
			exit(json_encode($data));
		}
		else {
			$data = array(
				'success'	=> 0,
				'message'	=> '',
			);
			exit(json_encode($data));
		}
	}

}