<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Affiche extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->database();
		
	}

	public function index() {
		
	}

	public function view($id) {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
        $this->load->model('model_affiche');
		$tpl_data['affiche'] = $this->model_affiche->get_row(array('id'=>$id));
        
		$this->twig->display('affiche/view', $tpl_data);
	}


	private function show_message($success, $message, $redirect) {
		if ($this->input->is_ajax_request()) {
			$data = array(
				'success'	=> $success ? 1 : 0,
				'message'	=> strip_tags($message),
			);
			header('Content-type: application/json');
			echo json_encode($data);
		} else {
			$tpl_data = array(
				'message'	=> $message,
				'redirect'	=> $redirect,
			);
			$this->twig->display('show_message', $tpl_data);
		}
		exit;
	}

}