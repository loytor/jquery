<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Administrator
 * Date: 13-7-10
 * Time: 下午5:50
 * To change this template use File | Settings | File Templates.
 */
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Class Ktv
 * @property Model_ktv $model_ktv
 * @property Model_cate model_cate
 * @property Model_article $model_article
 * @property Model_cate_lists $model_cate_lists
 * @property Model_ktv_hot $model_ktv_hot
 */
class Ktv extends MY_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('model_ktv');
		$this->load->config('baidu');
	}

	public function index() {
		$tpl['article_arr'] = array();
		$this->twig->display('ktv/index', $tpl);
	}

	/**
	 * 门店管理
	 */
	public function md_add()
	{
		//添加
		if (!empty($_POST)) {
			$this->load->library('form_validation');
			$this->form_validation->set_rules('name', '门店名称', 'trim');
			$this->form_validation->set_rules('address', '门店地址', 'trim');
			$this->form_validation->set_rules('tel', '门店电话', 'trim');
			$this->form_validation->set_rules('lat', '经度', 'trim');
			$this->form_validation->set_rules('lng', '维度', 'trim');
			$this->form_validation->set_rules('mdId', 'id', 'trim|integer');
			$this->form_validation->set_rules('page', 'page', 'trim|integer');

			if ($this->form_validation->run()) {

				$this->model_ktv->content = array(
					'name' => $this->form_validation->set_value('name'),
					'address' => $this->form_validation->set_value('address'),
					'tel' => $this->form_validation->set_value('tel'),
					'la' => $this->form_validation->set_value('lat'),
					'lo' => $this->form_validation->set_value('lng'),
				);
				$this->model_ktv->content = json_encode($this->model_ktv->content);

				if ($this->form_validation->set_value('mdId')) {
					$where = array(
						'id' => $this->form_validation->set_value('mdId'),
						'user_id' => User::$user_id
					);
					unset($this->model_ktv->extend, $this->model_ktv->user_id, $this->model_ktv->type, $this->model_ktv->id);
					if ($this->model_ktv->update($where)) {
						$this->show_message(TRUE, '修改成功', '/ktv/md_add/'.$this->form_validation->set_value('page'));
					}
				}
				else {
					unset($this->model_ktv->extend);
					$this->model_ktv->type = Model_ktv::MD_TYPE;
					$this->model_ktv->user_id = User::$user_id;
					if ($this->model_ktv->add()) {
						$this->show_message(TRUE, '添加成功', '/ktv/md_add');
					}
				}
			}
			else {
				$this->show_message(FALSE, validation_errors(), '/ktv/md_add');
			}
		}

		//列表
		$page = intval($this->uri->segment($this->urlSegment, self::CUR_PAGE));
		$where = array('type' => Model_ktv::MD_TYPE, 'user_id' => User::$user_id);
		$list = $this->model_ktv->get_all($where, $this->pageSize, $page);
		foreach ($list as &$v) {
			$v['content'] = json_decode($v['content'], true);
		}
		$tpl['list'] = $list;
		$tpl['page'] = $page;
		$tpl['pages'] = $this->pages($this->model_ktv->total_rows($where));
		$tpl['ak'] = $this->config->item('baidu_token');
		$this->twig->display('ktv/md_add', $tpl);
	}

	/**
	 * 门店删除
	 */
	public function md_del()
	{
		if ($this->model_ktv->delete(array('id' => $this->input->get('id'), 'user_id' => User::$user_id)))
		{
			$this->show_message(TRUE, '删除成功', '/ktv/md_add');
		}
	}

	/**
	 * 包房管理
	 */
	public function room_add()
	{
		//门店Id参数
		$mdId = (int)$this->input->get('mdId');
		$page = (int)$this->input->get('per_page');
		$mdPage  = (int)$this->input->get('mdPage');

		$page = $page ? $page : self::CUR_PAGE;
		$this->pageQueryString = true;
		$this->queryString = '?' . 'mdId=' . $mdId . '&mdPage='. $mdPage;

		//添加
		if (!empty($_POST)) {
			$this->load->library('form_validation');
			$this->form_validation->set_rules('mdId', '所属门店', '');
			$this->form_validation->set_rules('name', '包房名', 'trim');
			$this->form_validation->set_rules('price', '包房价格', 'trim');
			$this->form_validation->set_rules('num', '容纳人数', 'trim');
			$this->form_validation->set_rules('consume', '最低消费', 'trim');
			$this->form_validation->set_rules('remark', '包房备注', 'trim');
			$this->form_validation->set_rules('roomId', 'roomId', 'trim');

			if ($this->form_validation->run()) {

				$content = array(
					'name' => $this->form_validation->set_value('name'),
					'price' => $this->form_validation->set_value('price'),
					'num' => $this->form_validation->set_value('num'),
					'consume' => $this->form_validation->set_value('consume'),
					'remark' => $this->form_validation->set_value('remark'),
				);
				$this->model_ktv->content = json_encode($content);
				$this->model_ktv->extend = $this->form_validation->set_value('mdId');

				if ($this->form_validation->set_value('roomId')) {
					$where = array(
						'id' => $this->form_validation->set_value('roomId'),
						'user_id' => User::$user_id
					);
					unset($this->model_ktv->user_id, $this->model_ktv->type, $this->model_ktv->id);
					if ($this->model_ktv->update($where)) {
						$this->show_message(TRUE, '修改成功', '/ktv/room_add/' . $this->queryString);
					}
				}
				else {
					$this->model_ktv->type = Model_ktv::ROOM_TYPE;
					$this->model_ktv->user_id = User::$user_id;
					if ($this->model_ktv->add()) {
						$this->show_message(TRUE, '添加成功', '/ktv/room_add' . $this->queryString);
					}
				}
			}
			else {
				$this->show_message(FALSE, validation_errors(), '/ktv/room_add');
			}
		}

		//查询门店
		$where = array('user_id' => User::$user_id, 'type' => Model_ktv::ROOM_TYPE);
		if (!empty($mdId))
		{
			$where['extend'] = $mdId;
		}
		$tpl['mdId'] = $mdId;
		$tpl['mdList'] = $this->model_ktv->getMdList();

		//列表
		$list = $this->model_ktv->get_all($where, $this->pageSize, $page);
		foreach ($list as &$v) {
			$v['content'] = json_decode($v['content'], true);
		}

		$tpl['list'] = $list;
		$tpl['page'] = $page;
		$tpl['mdPage'] = $mdPage;
		$tpl['queryString'] = $this->queryString;
		$tpl['pages'] = $this->pages($this->model_ktv->total_rows($where));

		$this->twig->display('ktv/room_add', $tpl);
	}

	/**
	 * 门店删除
	 */
	public function room_del()
	{
		$id = (int)$this->input->get('id');
		$mdId = (int)$this->input->get('mdId');
		$mdPage = (int)$this->input->get('mdPage');
		if ($this->model_ktv->delete(array('id' => $id, 'user_id' => User::$user_id)))
		{
			$this->show_message(TRUE, '删除成功', '/ktv/room_add?mdId=' . $mdId . '&mdPage=' . $mdPage);
		}
	}

	/**
	 * 包房复制
	 */
	public function room_copy()
	{
		$id = (int)$this->input->get('id');
		$mdId = (int)$this->input->get('mdId');
		$mdPage = (int)$this->input->get('mdPage');
		$where = array('user_id' => User::$user_id, 'id' => $id);
		$rt = $this->model_ktv->get_row($where);

		$this->model_ktv->content = $rt['content'];
		$this->model_ktv->extend = $rt['extend'];
		$this->model_ktv->user_id = $rt['user_id'];
		$this->model_ktv->type = $rt['type'];
		if ($this->model_ktv->add()){
			$this->show_message(TRUE, '复制成功', '/ktv/room_add' . '?mdId=' . $mdId . '&mdPage=' . $mdPage);
		}
	}

	/**
	 * 活动管理
	 */
	public function hot_index()
	{
		//列表
		$this->load->model('model_ktv_hot');
		$this->load->model('model_cate');
		$this->load->model('model_article');
		$this->load->model('model_cate_lists');

		$where = array('user_id' => User::$user_id);
		$page = (int)$this->uri->segment(3);
		$list = $this->model_ktv_hot->get_all($where, $this->pageSize, $page);
		$id = '';
		foreach ($list as $v) {
			$id[] = $v['articleId'];
		}

		$cate_arr = array();
		$_cate_arr = $this->model_cate->get_all($where, 100, 1);
		foreach ($_cate_arr as $_cate) {
			$cate_arr[$_cate['id']] = $_cate;
		}

		$list = $idArr = array();
		if ($id) {
			$where_set['in:id'] = $id;
			$page = intval($this->uri->segment($this->urlSegment, self::CUR_PAGE));
			$articleArr = $this->model_article->get_all($where_set, $this->pageSize, $page, 'id', 'desc');
			foreach ($articleArr as $rt) {
				$rt['rank'] = $rt['rank'] == 99999 ? '' : $rt['rank'];
				$rt['cate_name'] = isset($cate_arr[$rt['cate_id']]) ? $cate_arr[$rt['cate_id']]['cate_name'] : '';
				$rt['preview_url'] = $this->get_article_url($rt);
				unset($rt['is_top']);
				$list[$rt['id']] = $rt;
				$idArr[] = $rt['id'];
			}

			if($idArr) {//查询归档列表
				$where_set['in:lists_id'] = $idArr;
				$where_set['type'] = 'article';
				$cate_lists_list = $this->model_cate_lists->get_list($where_set);
				if($cate_lists_list){
					foreach($cate_lists_list as $rt){
						$list[$rt['lists_id']]['is_top'] = $rt['is_top'];
						$list[$rt['lists_id']]['cate_lists_id'] = $rt['id'];
					}
				}
			}
		}


		$tpl['list'] = $list;
		$tpl['cate_arr'] = $cate_arr;
		$tpl['pages'] = $this->pages($this->model_ktv_hot->total_rows($where));
		$this->twig->display('ktv/hot_index', $tpl);
	}

	/**
	 * 活动添加
	 */
	public function hot_add()
	{
		//网站栏目
		$cate_arr = array();
		$this->load->model('model_cate');
		$_cate_arr = $this->model_cate->get_all(array('user_id' => User::$user_id), 100, 1);
		foreach ($_cate_arr as $_cate) {
			$cate_arr[$_cate['id']] = $_cate;
		}

		//表单提交
		if (!empty($_POST)) {
			$this->load->library('form_validation');
			$this->load->helper('form');
			$this->form_validation->set_rules('cate_id', '栏目', 'trim');
			$this->form_validation->set_rules('title', '标题', 'trim|required|max_length[255]|htmlspecialchars');
			$this->form_validation->set_rules('description', '描述', 'trim|max_length[255]|htmlspecialchars');
			$this->form_validation->set_rules('content', '内容', 'trim');
			$this->form_validation->set_rules('url', '外部链接', 'trim|max_length[255]');
			$this->form_validation->set_rules('image', '图片', 'trim|callback__check_image');

			if ($this->form_validation->run()) {
				$this->load->model('model_article');
				$this->load->model('model_cate_lists');
				$this->load->model('model_ktv_hot');

				$data['user_id'] = User::$user_id;
				$cate_id = $this->form_validation->set_value('cate_id');
				if ($cate_id && !isset($cate_arr[$cate_id])) {
					$this->show_message(FALSE, '栏目不存在', '/article/add');
				}

				$mdId = $this->input->post('mdId') ? $this->input->post('mdId') : array();
				$mdId = implode(',', $mdId);
				if ($mdId) {
					$mdId .= ',';
				}
				else {
					$this->show_message(FALSE, '请选择门店', '/ktv/');
				}

				$data['cate_id'] = $cate_id;
				$data['type'] = '';
				$data['title'] = $this->form_validation->set_value('title');
				$data['description'] = $this->form_validation->set_value('description');
				$data['content'] = $this->form_validation->set_value('content');
				$data['url'] = $this->form_validation->set_value('url');
				$data['image'] = $this->form_validation->set_value('image');
				$is_image_sic = $this->input->post('is_image_sic');
				$data['is_image_sic'] = $is_image_sic ? 1 : 0;
				$is_top = $this->input->post('is_top');
				$data['is_top'] = $is_top ? 1 : 0;
				$data['rank'] = 99999;
				$article_id = $this->model_article->add($data);
				if ($cate_id) {
					//cate_lists
					$this->model_cate->count_step($cate_id, 'count_article', 1);
					$dataCateLists['user_id'] = User::$user_id;
					$dataCateLists['cate_id'] = $cate_id;
					$dataCateLists['type'] = 'article';
					$dataCateLists['lists_id'] = $article_id;
					$dataCateLists['rank'] = 9999;
					$dataCateLists['is_top'] = $is_top ? 1 : 0;
					$this->model_cate_lists->add($dataCateLists);
				}
				//ktv门店对应活动
				$this->model_ktv_hot->articleId = $article_id;
				$this->model_ktv_hot->mdId = $mdId;
				$this->model_ktv_hot->user_id = User::$user_id;
				$this->model_ktv_hot->add();

				$this->show_message(TRUE, '添加成功', '/ktv/');
			}
			else {
				$this->show_message(FALSE, validation_errors(), '/ktv/hot_add');
			}
		}

		$tpl['cate_arr'] = $cate_arr;
		$tpl['token'] = $this->token;
		$tpl['mdList'] = $this->model_ktv->getMdList();
		$this->twig->display('ktv/hot_add', $tpl);
	}


	public function ajax ()
	{
		header(' Content-Type:text/json');
		$id = (int)$this->input->get('id');
		$where = array('user_id' => User::$user_id, 'id' => $id);
		$content = $this->model_ktv->get_one($where, 'content');
		echo $content;
	}

}