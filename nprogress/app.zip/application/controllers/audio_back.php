<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Audio extends CI_Controller {

	public function __construct() {
		parent::__construct();
	}
    
    public function index(){
        
    }
    
    public function upload(){
        
        $this->load->library('encrypt');
		$token = trim($this->input->get_post('token', TRUE));
		$token_decoded = $this->encrypt->decode($token);
		if ( ! $token_decoded) {
			header('Content-type: application/json');
			echo json_encode(array('success' => 0, 'message' => '请通过正常途径上传'));
			exit;
		}
		$token_data = unserialize($token_decoded);
		if ( ! isset($token_data['time']) OR ! isset($token_data['user_id']) OR (time() - $token_data['time']) > 3600) {
			header('Content-type: application/json');
			echo json_encode(array('success' => 0, 'message' => '请通过正常途径上传'));
			exit;
		}
		$upload_config = array(
			'upload_path'	=> FCPATH.'images/'.$token_data['user_id'].'/'.date('Ym').'/',
			'allowed_types'	=> 'mp3',
			'max_size'		=> 1024 * 10,
			'encrypt_name'     => TRUE
		);
		$this->load->library('upload', $upload_config);
        
        if(!is_dir($upload_config['upload_path'])){
            mkdir($upload_config['upload_path'], 0777, TRUE);
        }
        
		if ( ! $this->upload->do_upload('userfile')) {
		    header('Content-type: application/json');
			echo json_encode(array('success' => 0, 'message' => $this->upload->display_errors('', '')));
			exit;
		} else {
			$mp3 = $this->upload->data();
            $filePath = $mp3['full_path'];
            
			$mp3_url = str_replace(str_replace(DIRECTORY_SEPARATOR, '/', FCPATH), '/', $filePath);
			echo json_encode(array(
                    'success'     => 1,
                    'mp3'         => image_url($mp3_url)
            ));
            exit;
		}
	}
    
    
}