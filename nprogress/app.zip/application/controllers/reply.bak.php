<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Reply extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('model_reply');
		$this->load->model('model_article');
		$this->load->model('model_marketing');
		$this->load->model('model_cate');
		$this->load->model('model_vipcard');
	}

	public function index() {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$where_set = array('user_id' => $logged_user_id);
		$this->load->library('pagination');
		$pagination_config = array(
			'base_url'		=> '/reply/index/',
			'total_rows'	=> $this->model_reply->total_rows($where_set),
			'per_page'		=> 8,
			'uri_segment'	=> 3,
		);
		$this->pagination->initialize($pagination_config);
		$tpl_data['pagination'] = $this->pagination->create_links();
		$reply_arr = $this->model_reply->get_all($where_set, $pagination_config['per_page'], intval($this->uri->segment($pagination_config['uri_segment'], 1)));
		foreach ($reply_arr as &$_reply) {
			$_reply['keyword'] = str_replace(',', ' ', $_reply['keyword']);
			if ($_reply['type'] == 'article') {
				$_article_arr = json_decode($_reply['content'], TRUE);
                if($_article_arr){
                    $_reply['count_article'] = count($_article_arr);
	                $first_article =  array_shift($_article_arr);
    				$_reply['content'] = $first_article['title'];
                }
			}
			if ($_reply['type'] == 'marketing') {
				$_marketing_arr = json_decode($_reply['content'], TRUE);
				$_reply['count_marketing'] = count($_marketing_arr);
				$first_marketting =  array_shift($_marketing_arr);
				$_reply['content'] = $first_marketting['title'];
			}
			if ($_reply['type'] == 'marketing_vote_text') {//文字版投票
				$_marketing_vote_text = json_decode($_reply['content'], TRUE);
				$first_marketing_vote_text = array_shift($_marketing_vote_text);
				$_reply['content'] = $first_marketing_vote_text['title'];
			}
			if ($_reply['type'] == 'vipcard') {//会员卡
				$_reply['content'] = '';
			}
		}
		$tpl_data['reply_arr'] = $reply_arr;
		$tpl_data['cur_nav'] = 'reply';
		$this->twig->display('reply/index', $tpl_data);
	}

	public function add() {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$type = $this->input->post('type');
		$this->load->library('form_validation');
		$this->load->helper('form');
		if($type == ''){
			$this->form_validation->set_rules('text-keyword', '关键词', 'trim|required|max_length[255]|htmlspecialchars');
		}elseif($type == 'article'){
			$this->form_validation->set_rules('article-keyword', '关键词', 'trim|required|max_length[255]|htmlspecialchars');
		}elseif($type == 'marketing'){
			$this->form_validation->set_rules('marketing-keyword', '关键词', 'trim|required|max_length[255]|htmlspecialchars');
		}
		if ($this->form_validation->run()) {
			$data_set['user_id'] = $logged_user_id;			
			
			if($type == ''){ //文字
				$data_set['keyword'] = $this->form_validation->set_value('text-keyword');
				$keyword_arr = explode(' ', $data_set['keyword']);
				foreach($keyword_arr as &$keyword){
					$keyword = trim($keyword);
				}
				$data_set['keyword'] = implode(',', $keyword_arr);
				
				$content = $this->input->post('content');
				if (empty($content)) {
					$this->show_message(FALSE, '请填写回复内容', '/reply/add');
				}

				$data_set['content'] = $content;
				$data_set['type'] = '';
				$reply_id = $this->model_reply->add($data_set);
			}elseif($type == 'article'){ //文章
				$data_set['keyword'] = $this->form_validation->set_value('article-keyword');
				$keyword_arr = explode(' ', $data_set['keyword']);
				foreach($keyword_arr as &$keyword){
					$keyword = trim($keyword);
				}
				$data_set['keyword'] = implode(',', $keyword_arr);
				
				$article_arr = array();
				$_articles = $this->input->post('articles');
				if (is_array($_articles) AND ! empty($_articles)) {
					foreach ($_articles as $article_id => $rank) {
						$_articles[$article_id] = empty($rank) ? 99999 : intval($rank);
					}
					asort($_articles);
					foreach ($_articles as $article_id => $rank) {
						$_article = $this->model_article->get_row(array('id' => $article_id, 'user_id' => $logged_user_id), 'id, type, title, url, description, image');
						if ($_article) {
							$_article['rank'] = $rank;
							$article_arr[] = $_article;
						}
					}
				}

				if (empty($content) AND empty($article_arr)) {
					$this->show_message(FALSE, '至少选择一种回复方式', '/reply/add');
				}
				$data_set['content'] = json_encode($article_arr);
				$data_set['type'] = 'article';
				$reply_id = $this->model_reply->add($data_set);
				if ($reply_id AND ! empty($article_arr)) {
					foreach ($article_arr as $_article) {
						$this->model_reply->article_add($reply_id, $_article['id'], $_article['rank']);
					}
				}				
			}elseif($type == 'marketing'){ //活动
				$data_set['keyword'] = $this->form_validation->set_value('marketing-keyword');
				$keyword_arr = explode(' ', $data_set['keyword']);
				foreach($keyword_arr as &$keyword){
					$keyword = trim($keyword);
				}
				$data_set['keyword'] = implode(',', $keyword_arr);
				
				$marketing_arr = array();
				$_marketings= $this->input->post('marketings');
                
				if (is_array($_marketings) AND !empty($_marketings)) {
					foreach ($_marketings as $marketing_id => $m) {					
						$_marketings[$marketing_id]['rank'] = empty($m['rank']) ? 99999 : intval($m['rank']);
					}
					asort($_marketings);
					foreach ($_marketings as $marketing_id => $m) {
						$_marketing = $this->model_marketing->get_marketing(array('id' => $marketing_id, 'user_id' => $logged_user_id), $m['type'],'id, type, title, description, image_start');
						if ($_marketing) {
							$_marketing['rank'] = $m['rank'];
							$marketing_arr[] = $_marketing;
						}
					}
				}

				if (empty($content) AND empty($marketing_arr)) {
					$this->show_message(FALSE, '至少选择一种回复方式', '/reply/add');
				}
				$data_set['content'] = json_encode($marketing_arr);
				$data_set['type'] = 'marketing';
				$reply_id = $this->model_reply->add($data_set);
				if ($reply_id AND ! empty($marketing_arr)) {
					foreach ($marketing_arr as $_marketing) {
						$this->model_reply->marketing_add($reply_id, $_marketing['id'], $_marketing['rank']);
					}
				}				
			}
			$this->show_message(TRUE, '添加成功', '/reply');
		} else {
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/reply/add');
			}
		}
		$cate_arr = array();
		$_cate_arr = $this->model_cate->get_all(array('user_id' => $logged_user_id), 100, 1);
		foreach ($_cate_arr as $_cate) {
			$cate_arr[$_cate['id']] = $_cate;
		}
		$tpl_data['cate_arr'] = $cate_arr;
		$tpl_data['cur_nav'] = 'reply';
		$this->twig->display('reply/add', $tpl_data);
	}

	public function update($reply_id = '') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$reply = $this->model_reply->get_row(array('id' => $reply_id, 'user_id' => $logged_user_id));
		if ( ! $reply) {
			$this->show_message(FALSE, '找不到自定义回复', '/reply');
		}
		if ($reply['keyword'] == '__default__') {
			redirect('/reply/setting');
		}
		$reply['keyword'] = str_replace(',', ' ', $reply['keyword']);
		$tpl_data['reply'] = $reply;
		$this->load->library('form_validation');
		$this->load->helper('form');
		$this->form_validation->set_rules('keyword', '关键词', 'trim|required|max_length[255]|htmlspecialchars');
		if ($this->form_validation->run()) {
			if( $reply['type'] == '' ){
				$content = $this->input->post('content');
				if (empty($content)) {
					$this->show_message(FALSE, '请填写回复', '/reply/update/'.$reply['id']);
				}
				$data_set['content'] = $content;
				$data_set['type'] = '';
			}elseif( $reply['type'] == 'article'){
				$article_arr = array();
				$_articles = $this->input->post('articles');
				if (is_array($_articles) AND ! empty($_articles)) {
					foreach ($_articles as $article_id => $rank) {
						$_articles[$article_id] = empty($rank) ? 99999 : intval($rank);
					}
					asort($_articles);
					foreach ($_articles as $article_id => $rank) {
						$_article = $this->model_article->get_row(array('id' => $article_id, 'user_id' => $logged_user_id), 'id, type, title, url, description, image');
						if ($_article) {
							$_article['rank'] = $rank;
							$article_arr[] = $_article;
						}
					}
				}
				if (empty($article_arr)) {
					$this->show_message(FALSE, '至少选择一种回复图文', '/reply/update/'.$reply['id']);
				}
				
				$data_set['content'] = json_encode($article_arr);
				$data_set['type'] = 'article';
			}elseif( $reply['type'] == 'marketing'){
				$marketing_arr = array();
				$_marketings = $this->input->post('marketings');
				if (is_array($_marketings) AND ! empty($_marketings)) {
					foreach ($_marketings as $marketing_id => $m) {
						$_marketings[$marketing_id]['rank'] = empty($m['rank']) ? 99999 : intval($m['rank']);
					}
					asort($_marketings);
					foreach ($_marketings as $marketing_id => $m) {
						$_marketing = $this->model_marketing->get_marketing(array('id' => $marketing_id, 'user_id' => $logged_user_id), $m['type'], 'id, type, title, description, image_start');
						if ($_marketing) {
							$_marketing['rank'] = $m['rank'];
							$marketing_arr[] = $_marketing;
						}
					}
				}
				if (empty($marketing_arr)) {
					$this->show_message(FALSE, '至少选择一种回复活动', '/reply/update/'.$reply['id']);
				}
				
				$data_set['content'] = json_encode($marketing_arr);
				$data_set['type'] = 'marketing';
			}elseif( $reply['type'] == 'marketing_vote_text') {
				$instruction = $this->input->post('content');
				$content = json_decode($reply['content'], TRUE);
				$content = $content[0];
				if($content)
				{
					$content['title'] = $instruction;
					$content['instruction'] = $instruction;
				}
				$new_content[0] = $content;
				$data_set['content'] = json_encode($new_content);
			}

			$data_set['user_id'] = $logged_user_id;
			$data_set['keyword'] = $this->form_validation->set_value('keyword');
			$keyword_arr = explode(' ', $data_set['keyword']);
			foreach($keyword_arr as &$keyword){
				$keyword = trim($keyword);
			}
			$data_set['keyword'] = implode(',', $keyword_arr);
			
			$this->model_reply->update($reply['id'], $data_set);
			
			if ($reply['type'] == 'article') {
				$this->model_reply->article_delete($reply['id']);
				if (! empty($article_arr)) {
					foreach ($article_arr as $_article) {
						$this->model_reply->article_add($reply['id'], $_article['id'], $_article['rank']);
					}
				}
			} elseif($reply['type'] == 'marketing') {
				$this->model_reply->marketing_delete($reply['id']);
				if (! empty($marketing_arr)) {
					foreach ($marketing_arr as $_marketing) {
						$this->model_reply->marketing_add($reply['id'], $_marketing['id'], $_marketing['rank']);
					}
				}				
			}

			$this->show_message(TRUE, '更新成功', '/reply');
		} else {
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/reply/update/'.$reply['id']);
			}
		}
		if ($reply['type'] == 'article') {
			$article_arr = $this->model_reply->article_list($reply['id']);
			foreach ($article_arr as &$_article) {
				$_article['rank'] = $_article['article_rank'] == 99999 ? '' : $_article['article_rank'];
			}
			$tpl_data['article_arr'] = $article_arr;
		}
		if ($reply['type'] == 'marketing') {
			$marketing_arr = $this->model_reply->marketing_list($reply['id']);
			foreach ($marketing_arr as &$_marketing) {
				$_marketing['rank'] = $_marketing['rank'] == 99999 ? '' : $_marketing['rank'];
			}
			$tpl_data['marketing_arr'] = $marketing_arr;
		}
		if ($reply['type'] == 'marketing_vote_text') {
			$tpl_data['marketing_vote_text'] = json_decode($reply['content'], TRUE);
		}
		if($reply['type'] == 'vipcard'){
			$vipcard_id = $reply['content'];
			$tpl_data['vipcard'] = $this->model_vipcard->get_row(array('id'=>$vipcard_id));		
		}		
		$cate_arr = array();
		$_cate_arr = $this->model_cate->get_all(array('user_id' => $logged_user_id), 100, 1);
		foreach ($_cate_arr as $_cate) {
			$cate_arr[$_cate['id']] = $_cate;
		}
		$tpl_data['cate_arr'] = $cate_arr;
		$tpl_data['cur_nav'] = 'reply';
		$this->twig->display('reply/update', $tpl_data);
	}

	public function delete($reply_id = '') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$reply = $this->model_reply->get_row(array('id' => $reply_id, 'user_id' => $logged_user_id));
		if ( ! $reply) {
			$this->show_message(FALSE, '找不到自定义回复', '/reply');
		}
		$this->model_reply->delete($reply['id']);
		$this->show_message(TRUE, '删除成功', '/reply');
	}

	public function setting() {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$tpl_data['reply'] = $reply = $this->model_reply->get_row(array('user_id' => $logged_user_id, 'keyword' => '__default__'));
		if ($this->input->post()) {
			$article_arr = array();
			$_articles = $this->input->post('articles');
			if (is_array($_articles) AND ! empty($_articles)) {
				foreach ($_articles as $article_id => $rank) {
					$_articles[$article_id] = empty($rank) ? 99999 : intval($rank);
				}
				asort($_articles);
				foreach ($_articles as $article_id => $rank) {
					$_article = $this->model_article->get_row(array('id' => $article_id, 'user_id' => $logged_user_id), 'id, type, title,url, description, image');
					if ($_article) {
						$_article['rank'] = $rank;
						$article_arr[] = $_article;
					}
				}
			}
			$content = $this->input->post('content');
			if (empty($content) AND empty($article_arr)) {
				$this->show_message(FALSE, '至少选择一种回复方式', '/reply/setting');
			}
			$data_set['user_id'] = $logged_user_id;
			$data_set['keyword'] = '__default__';
			if ( ! empty($article_arr)) {
				$data_set['content'] = json_encode($article_arr);
				$data_set['type'] = 'article';
			} else {
				$data_set['content'] = $content;
				$data_set['type'] = '';
			}
			if ($reply) {
				$this->model_reply->update($reply['id'], $data_set);
				if ($reply['type'] == 'article') {
					$this->model_reply->article_delete($reply['id']);
				}
				if (! empty($article_arr)) {
					foreach ($article_arr as $_article) {
						$this->model_reply->article_add($reply['id'], $_article['id'], $_article['rank']);
					}
				}
			} else {
				$reply_id = $this->model_reply->add($data_set);
				if ($reply_id AND ! empty($article_arr)) {
					foreach ($article_arr as $_article) {
						$this->model_reply->article_add($reply_id, $_article['id'], $_article['rank']);
					}
				}
			}
			$this->show_message(TRUE, '设置成功', '/reply');
		}
		if ($reply AND $reply['type'] == 'article') {
			$article_arr = $this->model_reply->article_list($reply['id']);
			foreach ($article_arr as &$_article) {
				$_article['rank'] = $_article['rank'] == 99999 ? '' : $_article['rank'];
			}
			$tpl_data['article_arr'] = $article_arr;
		}
		$cate_arr = array();
		$_cate_arr = $this->model_cate->get_all(array('user_id' => $logged_user_id), 100, 1);
		foreach ($_cate_arr as $_cate) {
			$cate_arr[$_cate['id']] = $_cate;
		}
		$tpl_data['cate_arr'] = $cate_arr;
		$tpl_data['cur_nav'] = 'reply';
		$this->twig->display('reply/setting', $tpl_data);
	}

	private function show_message($success, $message, $redirect) {
		if ($this->input->is_ajax_request()) {
			$data = array(
				'success'	=> $success ? 1 : 0,
				'message'	=> strip_tags($message),
			);
			header('Content-type: application/json');
			echo json_encode($data);
		} else {
			$tpl_data = array(
				'message'	=> $message,
				'redirect'	=> $redirect,
			);
			$this->twig->display('show_message', $tpl_data);
		}
		exit;
	}

}