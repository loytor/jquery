<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Marketing extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('model_marketing');
        $this->load->model('model_marketing_lottery_sncode');
        $this->load->model('model_marketing_lottery_record');
        $this->load->model('model_marketing_win_record');
        $this->load->model('model_welcome');
        $this->load->model('model_cate_lists');
	}

	public function index() {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}

		$where_set = array('user_id' => $logged_user_id);
		$this->load->library('pagination');
		$pagination_config = array(
				'base_url'		=> '/marketing/index/',
				'total_rows'	=> $this->model_marketing->total_rows($where_set),
				'per_page'		=> 8,
				'uri_segment'	=> 3,
		);
		$this->pagination->initialize($pagination_config);
		$tpl_data['pagination'] = $this->pagination->create_links();

		$this->load->model('model_cate');
		$cate_arr = array();
		$_cate_arr = $this->model_cate->get_all(array('user_id' => $logged_user_id), 100, 1);
		foreach ($_cate_arr as $_cate) {
			$cate_arr[$_cate['id']] = $_cate;
		}
        $tpl_data['cate_arr'] = $cate_arr;

		$cate_lists = array();
		$_cate_lists = $this->model_cate_lists->get_all(array('type !=' => 'vipcard', 'type != ' => 'article'), 100, 1);
		foreach ($_cate_lists as $_cate_list) {
			$cate_lists[$_cate_list['lists_id']] = $_cate_list;
		}

		$where_set['in:type'] = array('rotate', 'scratch', 'fruit');
		$marketing_arr = $this->model_marketing->get_all($where_set, $pagination_config['per_page'], intval($this->uri->segment($pagination_config['uri_segment'], 1)), 'dt_update', 'desc');

		foreach($marketing_arr as &$_marketing){
			$_marketing['cate_name'] = isset($cate_arr[$_marketing['cate_id']]) ? $cate_arr[$_marketing['cate_id']]['cate_name'] : '';
			$_marketing['is_top'] = isset($cate_lists[$_marketing['id']]) ? $cate_lists[$_marketing['id']]['is_top'] : '';
			$_marketing['cate_lists_id'] = isset($cate_lists[$_marketing['id']]) ? $cate_lists[$_marketing['id']]['id'] : '';
		}		
		
		$types = array('rotate'=>'欢乐大转盘','scratch'=>'刮刮乐', 'fruit'=>'水果达人');
		foreach($marketing_arr as $key=>$marketing){
			$marketing_arr[$key]['type_name'] = $types[$marketing['type']];
		}		
		$tpl_data['marketing_arr'] = $marketing_arr;
		
		//获取用户权限
		$this->load->model('model_user_authority');
		$user_authority = $this->model_user_authority->get_row(array('user_id'=>$logged_user_id));
		
		if($user_authority){
			$user_auth = $user_authority['authority'];
		}else{
			$user_auth = 0;
		}
		//喜帖权限值
		$this->config->load('authority');
        $conf_authority = $this->config->item('authority');
        $authority = array();

        foreach($conf_authority as $key=>$ca){
        	if($ca[2]==0 && $user_auth & $ca[0]){
        		$authority[$key] = $ca;
        	}
        }
        $tpl_data['authority'] = $authority;

        $tpl_data['cur_nav'] = 'marketing';
		$this->twig->display('marketing/index', $tpl_data);
	}

	public function search_x() {
		$data = array(
				'marketing_arr'	=> array(),
				'last_page'		=> 0,
				'next_page'		=> 0,
		);
		$logged_user_id = logged_user_id();
		if ($logged_user_id) {
			$where_set = array('user_id' => $logged_user_id, 'dt_start < ' => date('Y-m-d H:i:s'), 'dt_end > '=>date('Y-m-d H:i:s'));
			$cate_id = trim($this->input->get('cate_id'));
			if ($cate_id) {
				$where_set['cate_id'] = $cate_id;
			}
			$keyword = trim($this->input->get('keyword'));
			if ($keyword) {
				$where_set['title'] = 'like:'.$keyword;
			}
			$total_rows = $this->model_marketing->total_rows($where_set);
			$page = intval($this->input->get('page'));
			$page = $page < 1 ? 1 : $page;
			$per_page = 5;

			$marketing_arr = $this->model_marketing->get_all_for_search($where_set, $per_page, $page);

            $marketing_newarr = array();
            foreach ($marketing_arr as $_marketing) {
            	if($_marketing['type'] != 'vote_text' && $_marketing['type'] != 'coupon'){
	                $marketing_info = $this->model_marketing->get_marketing_info($_marketing['id'],$_marketing['type']);
	                if($_marketing['type'] == 'enroll' ){
	                	$marketing_info['image_start'] = $marketing_info['image_start'] ? $marketing_info['image_start'] : image_url('/assets/img/enroll.jpg');
	                }	                
	                $_marketing['image_preview'] = image_url($marketing_info['image_start'], 80, 80);
	                $marketing_newarr[] = array_merge($_marketing,$marketing_info);
            	}
            }
			$data['marketing_arr'] = $marketing_newarr;
			if ($page * $per_page < $total_rows) {
				$data['next_page'] = $page + 1;
			}
			if ($page > 1) {
				$data['last_page'] = $page - 1;
			}
		}
		header('Content-type: application/json');
		echo json_encode($data);
	}
    
    public function stop($marketing_id='') {
    	$logged_user_id = logged_user_id();
    	if ( ! $logged_user_id) {
    		redirect_return('/auth/login');
    	}
    	    	
    	$data_set['status'] = '已结束';
    	$data_set['dt_end'] = date('Y-m-d H:i:s');
    	$marketing = $this->model_marketing->get_row(array('id' => $marketing_id, 'user_id' => $logged_user_id));
    	if($marketing){
    		if($this->model_marketing->update($marketing_id, $data_set)){
    			$this->show_message(TRUE, '活动停止成功', '/marketing');
    		}else{
    			$this->show_message(FALSE, '活动停止失败', '/marketing');
    		}    		
    	}else{
    		$this->show_message(TRUE, '不存在该活动', '/marketing');
    	}
    }

//     public function start($marketing_id='') {
//     	$data_set['status'] = '已开始';
//     	if($this->model_marketing->update($marketing_id, $data_set)){
//     		$this->show_message(TRUE, '活动已开始', '/marketing');
//     	}else{
//     		$this->show_message(FALSE, '活动开始失败', '/marketing');
//     	}    	
//     }
    
    public function delete($marketing_id='') {
    	$logged_user_id = logged_user_id();
    	if ( ! $logged_user_id) {
    		redirect_return('/auth/login');
    	}
    	
        //判断是否是自己发布的
        $marketing = $this->model_marketing->get_row(array('id' => $marketing_id, 'user_id' => $logged_user_id));
        if($marketing){
            if($this->model_marketing->delete($marketing_id)){
        		//cate表count_marketing -1, cate_lists表删除
        		$this->load->model('model_cate');
        		$this->load->model('model_cate_lists');
            	if ($marketing['cate_id']) {
            		$this->model_cate->count_step($marketing['cate_id'], 'count_marketing', -1);
            		$del_data_cate_lists['user_id'] = $logged_user_id;
            		$del_data_cate_lists['cate_id'] = $marketing['cate_id'];
            		$del_data_cate_lists['type'] = str_replace('marketing_', '', $marketing['type']);
            		$del_data_cate_lists['lists_id'] = $marketing_id;
            		$this->model_cate_lists->delete($del_data_cate_lists);
            	}
            	        		
            	if($marketing['type'] == 'rotate'){
            	    $this->load->model('model_marketing_rotate');
            		$this->model_marketing_rotate->delete(array('marketing_id' => $marketing_id));
					$this->model_marketing_lottery_sncode->delete(array('marketing_id' => $marketing_id));
            		$this->model_marketing_lottery_record->delete(array('marketing_id' => $marketing_id));
            		$this->model_marketing_win_record->delete(array('marketing_id' => $marketing_id));
            	}else if($marketing['type'] == 'scratch'){
            		$this->load->model('model_marketing_scratch');
                    $this->model_marketing_scratch->delete(array('marketing_id' => $marketing_id));
            		$this->model_marketing_lottery_sncode->delete(array('marketing_id' => $marketing_id));
            		$this->model_marketing_lottery_record->delete(array('marketing_id' => $marketing_id));
            		$this->model_marketing_win_record->delete(array('marketing_id' => $marketing_id));
            	}else if($marketing['type'] == 'fruit'){
            		$this->load->model('model_marketing_fruit');
            		$this->load->model('model_marketing_fruit_sncode');
            		$this->load->model('model_marketing_fruit_record');
            		$this->load->model('model_marketing_fruit_win_record');
            		$this->model_marketing_fruit->delete(array('marketing_id' => $marketing_id));
            		$this->model_marketing_fruit_sncode->delete(array('marketing_id' => $marketing_id));
            		$this->model_marketing_fruit_record->delete(array('marketing_id' => $marketing_id));
            		$this->model_marketing_fruit_win_record->delete(array('marketing_id' => $marketing_id));            		
            	}else if($marketing['type'] == 'vote_text' || $marketing['type'] == 'vote_img'){
            	    $this->load->model('model_marketing_vote');
                    $this->load->model('model_marketing_vote_info');
                    $this->load->model('model_marketing_latest_reply');
        
            		$this->model_marketing_vote->delete(array('marketing_id' => $marketing_id));
            		$this->model_marketing_vote_info->delete(array('marketing_id' => $marketing_id));           		
            		$this->model_marketing_latest_reply->delete(array('marketing_id' => $marketing_id));
            	}else if($marketing['type'] == 'enroll'){
            	    //删除报名附加信息
                    $this->load->model('model_marketing_enroll');
            	    $this->model_marketing_enroll->delete(array('marketing_id'=>$marketing_id));
                    //删除对应的报名表
                    $this->load->model('model_marketing_enroll_record');
                    $this->model_marketing_enroll_record->delete(array('marketing_id'=>$marketing_id));
                    
            	}else if($marketing['type'] == 'coupon'){
            	    //删除优惠券附加信息
            	    $this->load->model('model_marketing_coupon');
                    $this->model_marketing_coupon->delete(array('marketing_id'=>$marketing_id));
            	}
            	
            	/*//删除对应的自定义回复
                $this->load->model('model_reply');
        	    $reply_list = $this->model_reply->reply_list_by_marketing($marketing_id);
    	    	foreach($reply_list as $reply){
    	    		$marketing_arr = json_decode($reply['content']);
    	    		foreach($marketing_arr as $key=>$marketing){
    	    			if($marketing->id == $marketing_id){
    	    				unset($marketing_arr[$key]);
    	    			}
    	    		}
    	    		$content = json_encode($marketing_arr);
    	    		if(count($marketing_arr) > 0){
    	    			$this->model_reply->update($reply['id'], array('content'=>$content));
    	    		}else{
    	    			$this->model_reply->delete($reply['id']);
    	    		}
    	    		$this->model_reply->marketing_delete($reply['id'], $marketing_id);
    	    	}
    	    	//删除对应的welcome
    			$welcome = $this->model_welcome->get_row(array('user_id' => $logged_user_id));
    			if($welcome){
	    			$content = json_decode($welcome['content']);
	    			if($content){
		    			foreach($content as $k=>$c){
		    				if(isset($c->marketing_id) && $c->marketing_id == $marketing_id){
		    					unset($content[$k]);
		    				}
		    			}
	    			}
	    			$content = json_encode($content);
	    			$this->model_welcome->update($welcome['id'], array('content'=>$content));
    			}*/
        		$this->show_message(TRUE, '活动已删除', '/marketing');
        	}else{
        		$this->show_message(FALSE, '活动删除失败', '/marketing');
        	}
        }else{
            $this->show_message(FALSE, '非法操作', '/marketing');
        }    	  	
    }

    public function top($cate_lists_id = '', $cate_id = '') {
    	$cate_list = $this->model_cate_lists->get_row(array('id'=>$cate_lists_id, 'cate_id'=>$cate_id));
    	if($cate_list){
    		if($this->model_cate_lists->update(array('id'=>$cate_lists_id), array('is_top'=>1))){
    			$this->show_message(TRUE, '置顶成功', '/marketing');
    		}else{
    			$this->show_message(FALSE, '置顶失败', '/marketing');
    		}
    	}else{
    		$this->show_message(FALSE, '该内容不存在', '/marketing');
    	}
    }
    
    public function cancel_top($cate_lists_id='', $cate_id = ''){
    	$cate_list = $this->model_cate_lists->get_row(array('id'=>$cate_lists_id, 'cate_id'=>$cate_id));
    	if($cate_list){
    		if($this->model_cate_lists->update(array('id'=>$cate_lists_id), array('is_top'=>0))){
    			$this->show_message(TRUE, '取消置顶成功', '/marketing');
    		}else{
    			$this->show_message(FALSE, '取消置顶失败', '/marketing');
    		}
    	}else{
    		$this->show_message(FALSE, '该内容不存在', '/marketing');
    	}
    }
        
    private function show_message($success, $message, $redirect) {
		if ($this->input->is_ajax_request()) {
			$data = array(
				'success'	=> $success ? 1 : 0,
				'message'	=> strip_tags($message),
				'redirect'	=> $redirect
			);
			header('Content-type: application/json');
			echo json_encode($data);
		} else {
			$tpl_data = array(
				'message'	=> $message,
				'redirect'	=> $redirect,
			);
			$this->twig->display('show_message', $tpl_data);
		}
		exit;
	}

}