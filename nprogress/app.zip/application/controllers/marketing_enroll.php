<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Class Marketing_enroll
 * @property Model_marketing_enroll $model_marketing_enroll
 * @property Model_marketing $model_marketing
 * @property Model_cate $model_cate
 * @property Model_cate_lists $model_cate_lists
 * @property Model_welcome $model_welcome
 */
class Marketing_enroll extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('model_marketing_enroll');
		$this->load->model('model_marketing');
        $this->load->model('model_cate');
        $this->load->model('model_cate_lists');
	}

	public function index(){
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}

		$where_set = array('user_id' => $logged_user_id, 'type'=>'enroll');
		$this->load->library('pagination');
		$pagination_config = array(
			'base_url'		=> '/marketing_enroll/index/',
			'total_rows'	=> $this->model_marketing->total_rows($where_set),
			'per_page'		=> 8,
			'uri_segment'	=> 3,
		);
		$this->pagination->initialize($pagination_config);
		$tpl_data['pagination'] = $this->pagination->create_links();

		$this->load->model('model_cate');
		$cate_arr = array();
		$_cate_arr = $this->model_cate->get_all(array('user_id' => $logged_user_id), '', '');
		foreach ($_cate_arr as $_cate) {
			$cate_arr[$_cate['id']] = $_cate;
		}
		$tpl_data['cate_arr'] = $cate_arr;

		$cate_lists = array();
		$_cate_lists = $this->model_cate_lists->get_all(array('type = ' => 'enroll'), '', '');
		foreach ($_cate_lists as $_cate_list) {
			$cate_lists[$_cate_list['lists_id']] = $_cate_list;
		}

		$enroll_arr = $this->model_marketing->get_all($where_set, $pagination_config['per_page'], intval($this->uri->segment($pagination_config['uri_segment'], 1)), 'dt_update', 'desc');
		foreach($enroll_arr as &$enroll){
			$enroll['cate_name'] = isset($cate_arr[$enroll['cate_id']]) ? $cate_arr[$enroll['cate_id']]['cate_name'] : '';
			$enroll['is_top'] = isset($cate_lists[$enroll['id']]) ? $cate_lists[$enroll['id']]['is_top'] : '';
			$enroll['cate_lists_id'] = isset($enroll[$enroll['id']]) ? $cate_lists[$enroll['id']]['id'] : '';
		}
		$tpl_data['enroll_arr'] = $enroll_arr;

		$this->twig->display('marketing_enroll/index', $tpl_data);
	}
	
	public function add() {
       
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}

		$cate_arr = array();
		$_cate_arr = $this->model_cate->get_all(array('user_id' => $logged_user_id), 500, 1);
		foreach ($_cate_arr as $_cate) {
			$cate_arr[$_cate['id']] = $_cate;
		}
		$tpl_data['cate_arr'] = $cate_arr;
        
		$this->load->library('form_validation');

		$vos = serialize($this->input->post('enroll_setting'));
        
		$this->form_validation->set_rules('cate_id', '栏目', 'trim');
        $this->form_validation->set_rules('title', '报名活动标题', 'trim|required|htmlspecialchars');
        $this->form_validation->set_rules('description', '报名活动描述', 'trim|required|htmlspecialchars');
		$this->form_validation->set_rules('instruction', '报名须知', 'trim');
		$this->form_validation->set_rules('dt_start', '报名活动开始时间', 'trim|required|htmlspecialchars');
		$this->form_validation->set_rules('dt_end', '报名活动结束时间', 'trim|required|htmlspecialchars');
        
		$this->form_validation->set_rules('enroll_setting', '报名项目', "callback_enroll_setting_check[".$vos."]");
		
		if ($this->form_validation->run()) {
			$cate_id = $this->form_validation->set_value('cate_id');
			if ($cate_id AND ! isset($cate_arr[$cate_id])) {
				$this->show_message(FALSE, '栏目不存在', '/marketing_enroll/add');
			}			
			$data_set['user_id'] = $logged_user_id;
            $data_set['cate_id'] = $cate_id;
			$data_set['dt_start'] = $this->form_validation->set_value('dt_start');
			$data_set['dt_end'] = $this->form_validation->set_value('dt_end');
			$data_set['title'] = $this->form_validation->set_value('title');
            $data_set['description'] = $this->form_validation->set_value('description');
            
			//判断时间
			if(strtotime($data_set['dt_start']) > time()){
				$data_set['status'] = '未开始';
			}elseif(strtotime($data_set['dt_end']) < time()){
				$data_set['status'] = '已结束';
			}else{
				$data_set['status'] = '已开始';
			}
			$data_set['type'] = 'enroll';
            
			$add_data_set['marketing_id'] = $this->model_marketing->add($data_set);
			//栏目表count_marketing +1, cate_lists增加记录
			if ($cate_id) {
				$this->model_cate->count_step($cate_id, 'count_marketing', 1);
				$data_cate_lists['user_id'] = $logged_user_id;
				$data_cate_lists['cate_id'] = $cate_id;
				$data_cate_lists['type'] = 'enroll';
				$data_cate_lists['lists_id'] = $add_data_set['marketing_id'];
				$data_cate_lists['rank'] = 9999;
				$this->model_cate_lists->add($data_cate_lists);
			}
			            
			//基础表添加成功 处理附加表
			if($add_data_set['marketing_id']){
                				
				//设置报名项目
				$enroll_setting = $this->input->post('enroll_setting');
				$add_data_set['enroll_setting'] = serialize($enroll_setting);
				
				$add_data_set['instruction'] = $this->form_validation->set_value('instruction');
                
                if($this->input->post('displayimage')=='1' && $this->input->post('image_start')){
                    $add_data_set['image_start'] = $this->input->post('image_start');
                }
                
                $add_data_set['wintips'] = $this->input->post('wintips');
                $add_data_set['endtitle'] = $this->input->post('endtitle');
                
                
				//附加表添加成功，自动生成报名信息
				if($this->model_marketing_enroll->add($add_data_set)){
					//加一个默认的自定义回复
                    $reply_data = array();
                    $reply_data['keyword'][] = '报名';
                    $reply_data['type'] = 'article';
                    $reply_data['site_id'] = $logged_user_id;
                    $reply_data['count_match'] = 0;
                    $reply_data['dt_add'] = $reply_data['dt_update'] = time();
                    $item_id = (string)new MongoId();
                    $reply_data['content'][$item_id] = array(
                        'id'    => $item_id,
                        'type'  => 'Marketing_enroll',
                        'title' => $data_set['title'],
                        'desc'  => $data_set['description'],
                        'image' => '',
                        'ref_id'=> $add_data_set['marketing_id'],
                        'url'   => '/marketing_enroll/view/'.$add_data_set['marketing_id'],
                        'rank'  => 9999
                    );
                    $this->load->library('Mongo_db');
                    $this->mongo_db->insert('reply', $reply_data);

					$this->show_message(TRUE, '活动添加成功', '/marketing_enroll');
				}
			}
		}else{
			$errors = validation_errors();

			if ($errors) {
				$this->show_message(FALSE, $errors, '/marketing_enroll/add');
			}		
		}
		$this->load->library('encrypt');
		$token_data = array('user_id' => $logged_user_id, 'time' => time());
		$tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
		$tpl_data['cur_nav'] = 'marketing';
		$this->twig->display('marketing_enroll/add', $tpl_data);
	}
	
	public function update($marketing_id='') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$marketing = $this->model_marketing->get_marketing($marketing_id,'enroll');

		if ( ! $marketing || $marketing['user_id'] != $logged_user_id) {
			$this->show_message(FALSE, '找不到该活动', '/marketing_enroll');
		}

        $cate_arr = array();
		$_cate_arr = $this->model_cate->get_all(array('user_id' => $logged_user_id), 500, 1);
		foreach ($_cate_arr as $_cate) {
			$cate_arr[$_cate['id']] = $_cate;
		}
		$tpl_data['cate_arr'] = $cate_arr;

		$marketing['enroll_setting'] = unserialize($marketing['enroll_setting']);

		$tpl_data['marketing'] = $marketing;
        
        //封面图片
        if($marketing['image_start']){
            $tpl_data['image_start_preview'] = image_url($marketing['image_start'], 640, 320);
            $tpl_data['image_start'] = $marketing['image_start'];
        }else{
            $tpl_data['image_start_preview'] = '';
            $tpl_data['image_start'] = '';
        }
        
		$this->load->library('form_validation');
		
		$vos = serialize($this->input->post('enroll_setting'));
		
		$this->form_validation->set_rules('cate_id', '栏目', 'trim');
		$this->form_validation->set_rules('title', '报名活动标题', 'trim|required|htmlspecialchars');
        $this->form_validation->set_rules('description', '报名活动描述', 'trim|required|htmlspecialchars');
		$this->form_validation->set_rules('instruction', '报名须知', 'trim');
		$this->form_validation->set_rules('dt_start', '报名活动开始时间', 'trim|required|htmlspecialchars');
		$this->form_validation->set_rules('dt_end', '报名活动结束时间', 'trim|required|htmlspecialchars');
        
		$this->form_validation->set_rules('enroll_setting', '报名项目', "callback_enroll_setting_check[".$vos."]");        
		
		if ($this->form_validation->run()) {
			$cate_id = $this->form_validation->set_value('cate_id');
			if ($cate_id AND ! isset($cate_arr[$cate_id])) {
				$this->show_message(FALSE, '栏目不存在', '/marketing_enroll/update/'.$marketing_id);
			}
						
			$data_set['user_id'] = $logged_user_id;
			$data_set['cate_id'] = $cate_id;
			$data_set['dt_start'] = $this->form_validation->set_value('dt_start');
			$data_set['dt_end'] = $this->form_validation->set_value('dt_end');
			$data_set['title'] = $this->form_validation->set_value('title');
            $data_set['description'] = $this->form_validation->set_value('description');
            
				
			//判断时间
			if(strtotime($data_set['dt_start']) > time()){
				$data_set['status'] = '未开始';
			}elseif(strtotime($data_set['dt_end']) < time()){
				$data_set['status'] = '已结束';
			}else{
				$data_set['status'] = '已开始';
			}
			$data_set['type'] = 'enroll';
		
			if($this->model_marketing->update($marketing_id, $data_set)){
				if ($marketing['cate_id'] != $cate_id) {
					if ($cate_id) {
						$this->model_cate->count_step($cate_id, 'count_marketing', 1);
						$data_cate_lists['user_id'] = $logged_user_id;
						$data_cate_lists['cate_id'] = $cate_id;
						$data_cate_lists['type'] = 'enroll';
						$data_cate_lists['lists_id'] = $marketing_id;
						$data_cate_lists['rank'] = 9999;
						$this->model_cate_lists->add($data_cate_lists);
					}
					if ($marketing['cate_id']) {
						$this->model_cate->count_step($marketing['cate_id'], 'count_marketing', -1);
						$del_data_cate_lists['user_id'] = $logged_user_id;
						$del_data_cate_lists['cate_id'] = $marketing['cate_id'];
						$del_data_cate_lists['type'] = 'enroll';
						$del_data_cate_lists['lists_id'] = $marketing_id;
						$this->model_cate_lists->delete($del_data_cate_lists);
					}
				}
				
				//设置报名项目
				$enroll_setting = $this->input->post('enroll_setting');

				if( $marketing['status'] == '未开始'){
					$update_data_set['enroll_setting'] = serialize($enroll_setting);
				}else{
					$enroll_setting_data = array();
					foreach($enroll_setting as $k => $v){
						$enroll_setting_data[$k]['name'] = (isset($marketing['enroll_setting'][$k]) && isset($marketing['enroll_setting'][$k]['name'])) ? $marketing['enroll_setting'][$k]['name'] : $v['name'];//(isset($v['name'])) ? $v['name'] : $marketing['enroll_setting'][$k]['name'];
						if(isset($v['must']))
						{
							$enroll_setting_data[$k]['must'] = $v['must'];
						}
					}
					$update_data_set['enroll_setting'] = serialize($enroll_setting_data);
				}
				
                $update_data_set['instruction'] = $this->form_validation->set_value('instruction');
                
                if($this->input->post('displayimage')=='1' && $this->input->post('image_start')){
                    $update_data_set['image_start'] = $this->input->post('image_start');
                }else{
                    $update_data_set['image_start'] = '';
                }
                
                $update_data_set['wintips'] = $this->input->post('wintips');
                $update_data_set['endtitle'] = $this->input->post('endtitle');
                
		
				$this->model_marketing_enroll->update(array('marketing_id'=>$marketing_id),$update_data_set);
		
				$this->show_message(TRUE, '更新成功', '/marketing_enroll');
			}
		} else {
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/marketing_enroll/update/'.$marketing_id);
			}
		}
		$this->load->library('encrypt');
		$token_data = array('user_id' => $logged_user_id, 'time' => time());
		$tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
		$tpl_data['cur_nav'] = 'marketing';
		$this->twig->display('marketing_enroll/update', $tpl_data);
	}
	
	public function enroll_setting_check($str, $enroll_setting) {
		$enroll_setting = unserialize($enroll_setting);
		if(count($enroll_setting) < 1) {
			$this->form_validation->set_message('enroll_setting_check', '%s至少需要1项');
			return FALSE;			
		}else{
			$error = array();
			foreach($enroll_setting as $vs) {
				
				if($vs['name'] == '' && !isset($error['name'])){
					$error['name'] = '报名内容/项目';;
				}
			}
            if(isset($error['name'])){
				$s = $error['name'];
                
                $this->form_validation->set_message('enroll_setting_check', $s.'不能为空');
				return FALSE;
			}
		}
		return true;
	}

	public function stop($marketing_id='') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}

		$data_set['status'] = '已结束';
		$data_set['dt_end'] = date('Y-m-d H:i:s');
		$marketing = $this->model_marketing->get_row(array('id' => $marketing_id, 'user_id' => $logged_user_id));
		if($marketing){
			if($this->model_marketing->update($marketing_id, $data_set)){
				$this->show_message(TRUE, '终止成功', '/marketing_enroll');
			}else{
				$this->show_message(FALSE, '终止失败', '/marketing_enroll');
			}
		}else{
			$this->show_message(TRUE, '不存在该预约报名', '/marketing_enroll');
		}
	}

	public function delete($marketing_id='') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}

		//判断是否是自己发布的
		$marketing = $this->model_marketing->get_row(array('id' => $marketing_id, 'user_id' => $logged_user_id));
		if($marketing){
			if($this->model_marketing->delete($marketing_id)){
				//cate表count_marketing -1, cate_lists表删除
				$this->load->model('model_cate');
				$this->load->model('model_cate_lists');
				if ($marketing['cate_id']) {
					$this->model_cate->count_step($marketing['cate_id'], 'count_marketing', -1);
					$del_data_cate_lists['user_id'] = $logged_user_id;
					$del_data_cate_lists['cate_id'] = $marketing['cate_id'];
					$del_data_cate_lists['type'] = str_replace('marketing_', '', $marketing['type']);
					$del_data_cate_lists['lists_id'] = $marketing_id;
					$this->model_cate_lists->delete($del_data_cate_lists);
				}

				//删除报名附加信息
				$this->load->model('model_marketing_enroll');
				$this->model_marketing_enroll->delete(array('marketing_id'=>$marketing_id));
				//删除对应的报名表
				$this->load->model('model_marketing_enroll_record');
				$this->model_marketing_enroll_record->delete(array('marketing_id'=>$marketing_id));

				//删除对应的自定义回复
				$this->load->model('model_reply');
				$reply_list = $this->model_reply->reply_list_by_marketing($marketing_id);
				foreach($reply_list as $reply){
					$marketing_arr = json_decode($reply['content']);
					foreach($marketing_arr as $key=>$marketing){
						if($marketing->id == $marketing_id){
							unset($marketing_arr[$key]);
						}
					}
					$content = json_encode($marketing_arr);
					if(count($marketing_arr) > 0){
						$this->model_reply->update($reply['id'], array('content'=>$content));
					}else{
						$this->model_reply->delete($reply['id']);
					}
					$this->model_reply->marketing_delete($reply['id'], $marketing_id);
				}
				//删除对应的welcome
				$this->load->model('model_welcome');
				$welcome = $this->model_welcome->get_row(array('user_id' => $logged_user_id));
				if($welcome){
					$content = json_decode($welcome['content']);
					if($content){
						foreach($content as $k=>$c){
							if(isset($c->marketing_id) && $c->marketing_id == $marketing_id){
								unset($content[$k]);
							}
						}
					}
					$content = json_encode($content);
					$this->model_welcome->update($welcome['id'], array('content'=>$content));
				}
				$this->show_message(TRUE, '删除成功', '/marketing_enroll');
			}else{
				$this->show_message(FALSE, '删除失败', '/marketing_enroll');
			}
		}else{
			$this->show_message(FALSE, '非法操作', '/marketing_enroll');
		}
	}

	private function show_message($success, $message, $redirect) {
		if ($this->input->is_ajax_request()) {
			$data = array(
					'success'	=> $success ? 1 : 0,
					'message'	=> strip_tags($message),
			);
			header('Content-type: application/json');
			echo json_encode($data);
		} else {
			$tpl_data = array(
					'message'	=> $message,
					'redirect'	=> $redirect,
			);
			$this->twig->display('show_message', $tpl_data);
		}
		exit;
	}
}