<?php
/**
 * Created by JetBrains PhpStorm.
 * User: llj
 * Date: 13-11-4
 * Time: 上午10:46
 * To change this template use File | Settings | File Templates.
 * @property Model_app_cate $model_app_cate
 * @property Model_app $model_app
 * @property Model_user_auth $model_user_auth
 */
class Module_manager extends MY_Controller
{
	public function index($type = 'my', $cate_id = 0)
	{
		$this->load->model('model_app_cate');
        $this->load->model('model_app');
        $this->load->model('model_user_auth');
		$list = array();

		$this->load->library('pagination');
		$page_size = 10;
		$uri_segment = 4;
		$page = intval($this->uri->segment($uri_segment, 1));
		$pagination_config['per_page'] = $page_size;
		$pagination_config['uri_segment'] = $uri_segment;

		switch ($type) {
            case 'my':
	            $list = $this->model_app->get_user_apps(User::$user_id, NULL, '', $page_size, $page);
	            $pagination_config['base_url'] = '/module_manager/index/'.$type;
		        $pagination_config['total_rows'] = count($this->model_app->get_user_apps(User::$user_id));
                break;
            case 'recd':
                $list = $this->model_app->get_all(array('recommend' => 1, 'status' => 0), $page_size, $page);
	            $pagination_config['base_url'] = '/module_manager/index/'.$type;
	            $pagination_config['total_rows'] = $this->model_app->total_rows(array('recommend' => 1, 'status' => 1));
                break;
            case 'cate':
	            $uri_segment = 5;
	            $page = intval($this->uri->segment($uri_segment, 1));
	            $pagination_config['uri_segment'] = $uri_segment;
                $list = $this->model_app->get_all(array('cate_id' => $cate_id, 'status' => 0), $page_size, $page);
	            $pagination_config['base_url'] = '/module_manager/index/'.$type.'/'.$cate_id;
	            $pagination_config['total_rows'] = $this->model_app->total_rows(array('cate_id' => $cate_id, 'status' => 0));
                break;
        }

        foreach ($list as $key => $val) {
            if ($type == 'my') {
                $list[$key]['action'] = $val['display'] ? 1 : 0;
            } else {
                $auth_list = $this->model_user_auth->get_all(array('user_id'=>User::$user_id));
                foreach($list as &$app)
                {
                    $app['action'] = -1; //未开通
                    foreach($auth_list as $al)
                    {
                        if($app['id'] == $al['app_id'])
                        {
                            $app['action'] = $al['display']; //0, 不显示, 添加, 1显示, 隐藏
                            break;
                        }
                    }
                }
            }
            $list[$key]['short_desc'] = mb_substr($val['listorder'], 0, 125);
        }

		$this->pagination->initialize($pagination_config);
		$tpl_data['pagination'] = $this->pagination->create_links();
        
        $tpl_data['cate_list'] = $this->model_app_cate->get_all(array());
		$tpl_data['list'] = $list;
        $tpl_data['type'] = $type;
        $tpl_data['cate_id'] = $cate_id;
		$this->load->view('module_manager/index', $tpl_data);
	}

	//添加或者隐藏模块
	public function toggle_module()
	{
		$app_id = $this->input->post('app_id');
		$display = $this->input->post('display');

		$this->load->model('model_app');
		$this->load->model('model_user_auth');
		$where['user_id'] = User::$user_id;
		$where['app_id'] = $app_id;
		$data['display'] = $display;
		if($this->model_user_auth->update($where, $data))
		{
			$result['success'] = 1;
			$result['app'] = $this->model_app->get_row(array('id'=>$app_id));
			echo json_encode($result);
		}
		else
		{
			$result['success'] = 0;
			echo json_encode($result);
		}
	}
}