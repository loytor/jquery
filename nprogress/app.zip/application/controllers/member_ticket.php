<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: zhw
 * Date: 13-8-20
 * Time: 下午2:20
 * To change this template use File | Settings | File Templates.
 * @property Model_member_ticket $modelObj
 * @property Model_member_user_ticket $user_ticket
 * @property Model_account $model_account
 */
class Member_ticket extends MY_Controller
{
	private $validArr = array(
		1 => '无期限',
//		2 => '兑换后X天',
		3 => '起止时间',
	);

	public function __construct()
	{
		parent::__construct();
		$this->load->model('model_member_ticket', 'modelObj');
		//判断是否有会员卡权限
		if(!$this->has_authority('member_card'))
		{
			$this->show_message(false, '您当前没有权限访问', '/member_sys');
		}

	}

	public function index()
	{
		//列表
		$page = intval($this->uri->segment($this->urlSegment, self::CUR_PAGE));
		$where = array(
			'wid' => User::$user_id
		);
		$list = $this->modelObj->get_all($where, $this->pageSize, $page);
		foreach ($list as &$row) {
			if ($row['type'] == 3) {
				$row['extend'] = explode('|', $row['extend']);
			}
		}

		$tpl['list'] = $list;
		$tpl['page'] = $page;
		$tpl['pages'] = $this->pages($this->modelObj->total_rows($where));
		$this->twig->display('member_ticket/index', $tpl);
	}

	public function add()
	{
		if ($this->submitCheck()) {

			$this->modelObj->title = trim($this->input->post('title', true));
			$this->modelObj->credit = intval($this->input->post('credit', true));
			$this->modelObj->type = intval($this->input->post('valid', true));
			if ($this->modelObj->type == 2) {
				$this->modelObj->extend = $this->input->post('days', true);
			}
			elseif ($this->modelObj->type == 3) {
				$this->modelObj->extend = $this->input->post('dt_start', true) . '|' . $this->input->post('dt_end', true);
			}
			$this->modelObj->content = $this->input->post('content');
			$this->modelObj->wid = User::$user_id;
			$this->modelObj->inputtime = time();

			if ($this->modelObj->add()) {
				$this->show_message(TRUE, '添加代金券成功', '/member_ticket/index');
			}
			else {
				$this->show_message(TRUE, '添加代金券失败', '/member_ticket/add');
			}
		}
		else {
			$tpl['validArr'] = $this->validArr;
			$tpl['token'] = $this->token;
			$this->twig->display('member_ticket/add', $tpl);
		}
	}


	public function edit()
	{
		$id = (int)$this->input->get_post('id');
		$where = array(
			'id' => $id,
			'wid' => User::$user_id,
		);

		if ($this->submitCheck()) {

			$this->modelObj->title = trim($this->input->post('title', true));
			$this->modelObj->credit = intval($this->input->post('credit', true));
			$this->modelObj->type = intval($this->input->post('valid', true));
			if ($this->modelObj->type == 2) {
				$this->modelObj->extend = $this->input->post('days', true);
			}
			elseif ($this->modelObj->type == 3) {
				$this->modelObj->extend = $this->input->post('dt_start', true) . '|' . $this->input->post('dt_end', true);
			}
			$this->modelObj->content = $this->input->post('content');
			$this->modelObj->wid = User::$user_id;
			$this->modelObj->inputtime = time();

			if ($this->modelObj->update($where)) {
				$this->show_message(TRUE, '修改代金券成功', '/member_ticket/index');
			}
			else {
				$this->show_message(TRUE, '修改代金券失败', '/member_ticket/edit?id='.$id);
			}
		}
		else {
			$tpl['validArr'] = $this->validArr;
			$tpl['token'] = $this->token;
			$tpl['row'] = $this->modelObj->get_row($where);
			$tpl['row']['stime'] = $tpl['row']['etime'] = $tpl['row']['days'] = '';
			if ($tpl['row']['type'] == 3) {
				$timeArr = explode('|', $tpl['row']['extend']);
				$tpl['row']['stime'] = $timeArr[0];
				$tpl['row']['etime'] = $timeArr[1];
			}
			elseif ($tpl['row']['type'] == 2) {
				$tpl['row']['days'] = $tpl['row']['extend'];
			}
			$this->twig->display('member_ticket/edit', $tpl);
		}
	}

	public function delete($id)
	{
		$where = array(
			'id' => (int)$id,
			'wid' => User::$user_id,
		);

		if ($this->modelObj->delete($where))
		{
			$this->show_message(TRUE, '删除代金券成功', '/member_ticket/index');
		}
	}

	/**
	 * 用户领取代金券列表
	 */
	public function listall()
	{
		$this->load->model('model_member_user_ticket', 'user_ticket');
		$this->load->model('model_account');

		//列表
		$page = intval($this->uri->segment($this->urlSegment, self::CUR_PAGE));
		$where = array(
			'wid' => User::$user_id
		);
		$list = $this->user_ticket->get_all($where, $this->pageSize, $page);
		$whereUid = '';
		foreach ($list as $k => $row) {
			$list[$k]['inputtime'] = date('Y-m-d H:i:s', $row['inputtime']);
			$whereUid['in:id'][] = $row['uid'];
			if ($row['type'] == 3) {
				$timeArr = explode('|', $row['extend']);
				$list[$k]['extend'] = $timeArr;
			}
		}
		//查询用户
		$userList = array();
		if (!empty($whereUid)) {
			$rows = $this->model_account->get_all($whereUid);
			foreach ($rows as $rs) {
				$userList[$rs['id']] = $rs;
			}
		}

		$tpl['userList'] = $userList;
		$tpl['list'] = $list;
		$tpl['page'] = $page;
		$tpl['pages'] = $this->pages($this->user_ticket->total_rows($where));

		$this->twig->display('member_ticket/listall', $tpl);
	}
}