<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Marketing_fruit_sncode extends CI_Controller {
	private $reward_status_arr = array(
									'0'=>'未发放',
									'1'=>'已被抽中',
									'2'=>'已兑奖');
	
	public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('model_marketing_fruit_sncode');		
	}

	public function manager($marketing_id = '', $current_page=1) {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}

		$where_set = array('marketing_id' => $marketing_id);
		$this->load->library('pagination');
		$per_page = 8;
		$pagination_config = array(
				'base_url'		=> '/marketing_fruit_sncode/manager/'.$marketing_id,
				'total_rows'	=> $this->model_marketing_fruit_sncode->total_rows($where_set),
				'per_page'		=> $per_page,
				'uri_segment'	=> 4,
		);
		$this->pagination->initialize($pagination_config);
		$tpl_data['pagination'] = $this->pagination->create_links();

		$sncode_arr = array();
		$sncode_arr = $this->model_marketing_fruit_sncode->get_all(array('marketing_id'=>$marketing_id), $pagination_config['per_page'], intval($this->uri->segment($pagination_config['uri_segment'], 1)), array('reward_status', 'dt_update', 'reward_cate'), array('DESC', 'DESC', 'DESC'));
		foreach($sncode_arr as $key=>$sn){
			$sncode_arr[$key]['number'] = ($current_page - 1)*$per_page + $key + 1;
			$sncode_arr[$key]['telephone'] = ($sn['telephone']) ? $sn['telephone'] : '';
			$sncode_arr[$key]['reward_status_text'] = $this->reward_status_arr[$sn['reward_status']];
		}

		$tpl_data['sncode_arr'] = $sncode_arr;
		$tpl_data['count'] =  $this->model_marketing_fruit_sncode->total_rows(array('marketing_id' => $marketing_id));
		$tpl_data['count_sent'] = $this->model_marketing_fruit_sncode->total_rows(array('marketing_id' => $marketing_id, 'reward_status' => 1));
		$tpl_data['count_received'] = $this->model_marketing_fruit_sncode->total_rows(array('marketing_id' => $marketing_id, 'reward_status' => 2));
		$tpl_data['marketing_id'] = $marketing_id;
		$tpl_data['cur_nav'] = 'marketing';
		$this->twig->display('marketing_fruit_sncode/index', $tpl_data);		
	}

	public function update_rewardstatus($sncode_id='') {
		$data_set['reward_status'] = $this->input->post('reward_status');
		if($data_set['reward_status'] == 1){
			$data_set['telephone'] = $this->input->post('telephone');
			if($this->input->post('old_reward_status') == 0){
				$data_set['is_cheat'] = 1;
			}
		}else if($data_set['reward_status'] == 0){
			$data_set['telephone'] = '';
			$data_set['is_cheat'] = 0;
			$data_set['is_confirm'] = 0;
		}
		$sncode = $this->input->post('sncode');
		$marketing_id = $this->input->post('marketing_id');
        //查询是否存在
        $isnull = $this->model_marketing_fruit_sncode->get_row(array('marketing_id'=>$marketing_id,'code'=>$sncode));
        if(!$isnull){
            $this->show_message(FALSE, '非法操作', '/marketing_fruit_sncode/manager/');
            exit;
        }
        
		if($this->model_marketing_fruit_sncode->update($sncode_id, $data_set)){
			$this->load->model('model_marketing_fruit_win_record');
			if($data_set['reward_status'] == 0 && $sncode){
				$this->model_marketing_fruit_win_record->delete(array('sncode'=>$sncode, 'marketing_id'=>$marketing_id));
			}else if($data_set['reward_status'] == 1 && $sncode){
				if($this->input->post('old_reward_status') == 2){ // 已兑奖->已被抽中
					$where_set['marketing_id'] = $marketing_id;
					$where_set['sncode'] = $sncode;
					$update_data_set['status'] = 1;
					$this->model_marketing_fruit_win_record->update($where_set, $update_data_set);					
				}else{// 未发放->已被抽中
					$add_data_set['marketing_id'] = $marketing_id;
					$add_data_set['sncode'] = $sncode;
					$add_data_set['prize_type'] = $this->input->post('prize_type');
					$add_data_set['telephone'] = $this->input->post('telephone');
					$add_data_set['status'] = 0;
					$this->model_marketing_fruit_win_record->add($add_data_set);
				}
			}else if($data_set['reward_status'] == 2 && $sncode){
				$where_set['marketing_id'] = $marketing_id;
				$where_set['sncode'] = $sncode;
				$update_data_set['status'] = 2;
				$this->model_marketing_fruit_win_record->update($where_set, $update_data_set);
			}
			$this->show_message(TRUE, '更新成功', '/marketing_fruit_sncode/manager/');			
		}else{
			$this->show_message(FALSE, '未更新成功', '/marketing_fruit_sncode/manager/');
		}
	}
	
	public function export($marketing_id = '') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$sncode_arr = array();
		$sncode_arr = $this->model_marketing_fruit_sncode->get_all(array('marketing_id'=>$marketing_id));

		// Starting the PHPExcel library
		$this->load->library('PHPExcel');
		$this->load->library('PHPExcel/IOFactory');
		
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->getProperties()->setTitle("导出中奖码信息")->setDescription("中奖码信息");
		
		$objPHPExcel->setActiveSheetIndex(0);
		
		// Field names in the first row
		//$fields = $query->list_fields();
			
		$fields = array('序号', '中奖码', '奖品类别', '奖品状态', '中奖人微信号', '中奖人手机号');
		 
		$col = 0;
		foreach ($fields as $field)
		{
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col, 1, $field);
			$col++;
		}
		
		$results = array();
		foreach($sncode_arr as $key=>$sncode) {
			$new_sncode['序号'] = $key+1;
			$new_sncode['中奖码'] = $sncode['code'];
			$new_sncode['奖品类别'] = $sncode['reward_cate'];
			$new_sncode['奖品状态'] = $this->reward_status_arr[$sncode['reward_status']];
			$new_sncode['中奖人微信号'] = $sncode['weixin_number'];
			$new_sncode['中奖人手机号'] = $sncode['telephone'];

			$results[] = $new_sncode;
		}
		$row = 2;
		foreach($results as $data)
		{
			$col = 0;
			foreach ($fields as $field)
			{
				$objPHPExcel->getActiveSheet()->setCellValueExplicitByColumnAndRow($col, $row, $data[$field],PHPExcel_Cell_DataType::TYPE_STRING);
				$col++;
			}
		
			$row++;
		}
		
		$objPHPExcel->setActiveSheetIndex(0);
		
		$objWriter = IOFactory::createWriter($objPHPExcel, 'Excel5');
		
		// Sending headers to force the user to download the file
		header('Content-Type: application/vnd.ms-excel');
		header('Content-Disposition: attachment;filename="中奖码信息_'.date('dMy').'.xls"');
		header('Cache-Control: max-age=0');
		
		$objWriter->save('php://output');
	}
	
	private function show_message($success, $message, $redirect) {
		if ($this->input->is_ajax_request()) {
			$data = array(
					'success'	=> $success ? 1 : 0,
					'message'	=> strip_tags($message),
					'redirect'  => $redirect
			);
			header('Content-type: application/json');
			echo json_encode($data);
		} else {
			$tpl_data = array(
					'message'	=> $message,
					'redirect'	=> $redirect,
			);
			$this->twig->display('show_message', $tpl_data);
		}
		exit;
	}
}