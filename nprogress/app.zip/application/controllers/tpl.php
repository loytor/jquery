<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Tpl extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('model_tpl');
	}

	public function index() {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}

		$selected_tpl = $this->model_tpl->get_row(array('user_id'=>$logged_user_id));
		if($selected_tpl){
			$selected_tpl['cate_tpl'] = $selected_tpl['cate_tpl'] ? $selected_tpl['cate_tpl'] : 'default';
			$selected_tpl['list_tpl'] = $selected_tpl['list_tpl'] ? $selected_tpl['list_tpl'] : 'default';
			$selected_tpl['detail_tpl'] = $selected_tpl['detail_tpl'] ? $selected_tpl['detail_tpl'] : 'default';
		}else{
			$selected_tpl['cate_tpl'] = 'default';
			$selected_tpl['list_tpl'] = 'default';
			$selected_tpl['detail_tpl'] = 'default';
		}

        //判断是否有发布的自定义首页模板
        $this->load->library('Mongo_db');
        $homepage = $this->mongo_db->select(array('content_pub'))->where(array('site_id'=>$logged_user_id,'type'=>1))->get_one('custom_page');
        if($homepage && isset($homepage['content_pub']) && $homepage['content_pub'])
        {
            $tpl_data['diy_tpl'] = 'diy';
        }

        $tpl_data['selected_tpl'] = $selected_tpl;

		$this->load->config('tpl');
		$tpl_data['cate_tpl_arr'] = $this->config->item('cate_tpl_arr');
		$tpl_data['list_tpl_arr'] = $this->config->item('list_tpl_arr');
		$tpl_data['detail_tpl_arr'] = $this->config->item('detail_tpl_arr');
		$tpl_data['preview_path'] = $this->config->item('preview_path');

		$tpl_data['cur_nav'] = 'cate';
		$this->twig->display('tpl/index', $tpl_data);
	}

	public function selected() {
		$type = $this->input->post('type');
		$tid = $this->input->post('tid');
		$logged_user_id = logged_user_id();

		$tpl = $this->model_tpl->get_row(array('user_id'=>$logged_user_id));

		$data_set[$type] = $tid;
		$data_set['user_id'] = $logged_user_id;

		$json = array();
		$json['success'] = 0;
		$json['msg'] = "保存失败";

		if($tpl){ // 编辑
			if($this->model_tpl->update(array('user_id'=>$logged_user_id), $data_set)){
				$json['success'] = 1;
				$json['msg'] = "保存成功";
			}
		}else{ // 添加
			if($this->model_tpl->add($data_set)){
				$json['success'] = 1;
				$json['msg'] = "保存成功";
			}
		}

		header('Content-type: application/json');
		echo json_encode($json);
	}
}