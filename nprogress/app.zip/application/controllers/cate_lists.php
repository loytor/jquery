<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Cate_lists extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('model_article');
		$this->load->model('model_cate');
		$this->load->model('model_cate_lists');
		$this->load->model('model_vote_paper');
	}

	public function index($cate_id = '_') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$cate_arr = array();
		$_cate_arr = $this->model_cate->get_all(array('user_id' => $logged_user_id), '', '');
		foreach ($_cate_arr as $_cate) {
			$cate_arr[$_cate['id']] = $_cate;
		}
		$where_set = array('cate_lists.user_id' => $logged_user_id);
		if ($cate_id != '_') {
			if (isset($cate_arr[$cate_id])) {
				$where_set['cate_id'] = $cate_id;
				$tpl_data['cate'] = $cate_arr[$cate_id];
			}
		}
		$this->load->library('pagination');
		$pagination_config = array(
			'base_url'		=> '/cate_lists/index/'.$cate_id.'/',
			'total_rows'	=> $this->model_cate_lists->total_rows($where_set),
			'per_page'		=> 8,
			'uri_segment'	=> 4,
		);
		$this->pagination->initialize($pagination_config);
		$tpl_data['pagination'] = $this->pagination->create_links();

		$cate_lists_arr = $this->model_cate_lists->get_all($where_set, $pagination_config['per_page'], intval($this->uri->segment($pagination_config['uri_segment'], 1)), 'cate_lists.rank asc, cate_lists.is_top desc, cate_lists.dt_update desc', '');
		foreach($cate_lists_arr as &$_cate_list){
			$_cate_list['rank'] = $_cate_list['rank'] == 99999 ? '' : $_cate_list['rank'];
			if($_cate_list['type'] == 'article'){
				$article = $this->model_article->get_row(array('id'=>$_cate_list['lists_id']));
				$_cate_list['title'] = $article['title'];
				$_cate_list['count_view'] = $article['count_view'];
			}else if($_cate_list['type'] == 'cate'){
                $cate = $this->model_cate->get_row(array('id'=>$_cate_list['lists_id']));
                $_cate_list['title'] = $cate['cate_name'];
                $_cate_list['count_view'] = '';
            }else if($_cate_list['type']=='vote'){
                $vote = $this->model_vote_paper->get_row(array('cate_id'=>$_cate_list['cate_id'],'id'=>$_cate_list['lists_id']));
                $_cate_list['title'] = $vote['title'];
                $_cate_list['count_view'] = '';
            }else if($_cate_list['type'] == 'vipcard'){
				$this->load->model('model_vipcard');
				$vipcard = $this->model_vipcard->get_row(array('id'=>$_cate_list['lists_id']));
				$_cate_list['title'] = $vipcard['name'];
				$_cate_list['count_view'] = '';
			}else if($_cate_list['type'] == 'autocard'){
                $this->load->model('model_app_config');
                $autocard = $this->model_app_config->get_row(array('user_id'=>$logged_user_id, 'type'=>$_cate_list['type']));
                if( $autocard ){
                    $rc = json_decode($autocard['config'], TRUE);
                    $_cate_list['title'] = isset($rc['name']) ? $rc['name'] : '';
                    $_cate_list['count_view'] = '';
                }
            }else if($_cate_list['type'] == 'vip'){
				$this->load->model('model_member_card');
				$vip = $this->model_member_card->get_row(array('id'=>$_cate_list['lists_id']));
				$_cate_list['title'] = $vip['name'];
				$_cate_list['count_view'] = '';
			}elseif(strrpos($_cate_list['type'], 'reserve_') !== FALSE){
				$this->load->model('model_app_config');
				$reserve_config = $this->model_app_config->get_row(array('user_id'=>$logged_user_id, 'type'=>$_cate_list['type']));
				if($reserve_config)
				{
					$rc = json_decode($reserve_config['config'], TRUE);
					$_cate_list['title'] = isset($rc['name']) ? $rc['name'] : '';
					$_cate_list['count_view'] = '';
					$_cate_list['subtype'] = str_replace('reserve_', '', $_cate_list['type']);
					$_cate_list['type'] = 'reserve';
				}
			}
			elseif($_cate_list['type'] == 'contact'){
				$this->load->model('model_contact');
				$contact = $this->model_contact->get_row(array('id'=>$_cate_list['lists_id']));
				$_cate_list['title'] = $contact['title'];
				$_cate_list['count_view'] = '';
			}
			elseif($_cate_list['type'] == 'groupon'){
				$this->load->model('model_app_config');
				$config = $this->model_app_config->get_row(array('user_id'=>$logged_user_id, 'type'=> 'groupon'));
				if($config)
				{
					$rc = json_decode($config['config'], TRUE);
					$_cate_list['title'] = isset($rc['name']) ? $rc['name'] : '';
					$_cate_list['count_view'] = '';
				}
			}
			elseif($_cate_list['type'] == 'game'){
				$this->load->model('model_game');
				$game = $this->model_game->get_row(array('id'=>$_cate_list['lists_id']));
				if($game)
				{
					$_cate_list['title'] = $game['title'];
					$_cate_list['count_view'] = '';
				}
			}
			elseif ($_cate_list['type'] == 'mall') {
				$this->load->model('model_mall');
				$mall = $this->model_mall->get_row(array('wid'=>$logged_user_id));
				if($mall)
				{
					$_cate_list['title'] = $mall['title'];
					$_cate_list['count_view'] = '';
				}
			}
		    else if($_cate_list['type'] == 'emigrated'){
                $this->load->model('model_emigrated');
                $emigrated = $this->model_emigrated->get_row(array('wid'=>$logged_user_id, 'id'=>$_cate_list['lists_id']));
                if( $emigrated ){
                    $_cate_list['title'] = $emigrated['title'];
                    $_cate_list['count_view'] = '';
                }
            }
			else{//marketing
				$this->load->model('model_marketing');
				$marketing = $this->model_marketing->get_marketing($_cate_list['lists_id'], $_cate_list['type']);
				if($marketing)
				{
					$_cate_list['title'] = $marketing['title'];
					$_cate_list['count_view'] = $marketing['count_view'];
				}
				else
				{
					$_cate_list['title'] = '';
					$_cate_list['count_view'] = '';
				}
			}
		}

		$tpl_data['cate_lists_arr'] = $cate_lists_arr;
		$tpl_data['cur_nav'] = 'cate';
		$this->twig->display('cate_lists/index', $tpl_data);
	}
	
	public function update_rank($cate_lists_id = '', $cate_id = '') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			$this->show_message(FALSE, '请先登录', '/auth/login');
		}
		
		$cate_lists = $this->model_cate_lists->get_row(array('id' => $cate_lists_id, 'user_id' => $logged_user_id));
		if ( ! $cate_lists) {
			$this->show_message(FALSE, '找不到该内容', '/cate_lists');
		}
		$this->load->library('form_validation');
		$this->load->helper('form');
		$this->form_validation->set_rules('rank', '排序', 'trim');
		if ($this->form_validation->run()) {
			$rank = $this->form_validation->set_value('rank');
			$data_set['rank'] = $rank ? intval($rank) : 99999;
			$this->model_cate_lists->update($cate_lists_id, $data_set);
			$this->show_message(TRUE, '更新成功', '/cate_lists/index/'.$cate_id);
		} else {
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/cate_lists/index/'.$cate_id);
			}
		}
	}

	public function top($cate_lists_id = '', $cate_id = '') {
		$cate_list = $this->model_cate_lists->get_row(array('id'=>$cate_lists_id, 'cate_id'=>$cate_id));
		if($cate_list){			
			if($this->model_cate_lists->update(array('id'=>$cate_lists_id), array('is_top'=>1))){
				$this->show_message(TRUE, '置顶成功', '/cate_lists/index/'.$cate_id);
			}else{
				$this->show_message(FALSE, '置顶失败', '/cate_lists/index/'.$cate_id);
			}
		}else{
			$this->show_message(FALSE, '该内容不存在', '/cate_lists/index/'.$cate_id);
		}
	}
	
	public function cancel_top($cate_lists_id='', $cate_id = ''){
		$cate_list = $this->model_cate_lists->get_row(array('id'=>$cate_lists_id, 'cate_id'=>$cate_id));
		if($cate_list){
			if($this->model_cate_lists->update(array('id'=>$cate_lists_id), array('is_top'=>0))){				
				$this->show_message(TRUE, '取消置顶成功', '/cate_lists/index/'.$cate_id);
			}else{
				$this->show_message(FALSE, '取消置顶失败', '/cate_lists/index/'.$cate_id);
			}
		}else{
			$this->show_message(FALSE, '该内容不存在', '/cate_lists/index/'.$cate_id);
		}		
	}
	
	private function show_message($success, $message, $redirect) {
		if ($this->input->is_ajax_request()) {
			$data = array(
				'success'	=> $success ? 1 : 0,
				'message'	=> strip_tags($message),
			);
			header('Content-type: application/json');
			echo json_encode($data);
		} else {
			$tpl_data = array(
				'message'	=> $message,
				'redirect'	=> $redirect,
			);
			$this->twig->display('show_message', $tpl_data);
		}
		exit;
	}

}