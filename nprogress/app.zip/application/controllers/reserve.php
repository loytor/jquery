<?php
/**
 * Created by JetBrains PhpStorm.
 * User: llj
 * Date: 13-9-10
 * Time: 下午2:10
 * To change this template use File | Settings | File Templates.
 * @property Model_reserve_store $model_reserve_store
 * @property Model_app_config $model_app_config
 * @property Model_cate $model_cate
 * @property Model_cate_lists $model_cate_lists
 * @property Model_address $model_address
 */
class Reserve extends MY_Controller
{
	private $types_arr;

	public function __construct()
	{
		parent::__construct();
		$this->load->model('model_app_config');
		$this->load->model('model_cate');
		$this->load->model('model_cate_lists');
		$this->load->model('model_address');
		$this->load->model('model_reserve_store');
		$this->load->config('reserve');
		$this->types_arr = $this->config->item('reserve_types');
	}

	/**
	 * @param $type
	 * 基本设置
	 */
	public function index($type)
	{
		$this->has_reserve_auth($type);

		//获取所有栏目
		$cate_arr = array();
		$_cate_arr = $this->model_cate->get_all(array('user_id' => User::$user_id));
		foreach ($_cate_arr as $_cate) {
			$cate_arr[$_cate['id']] = $_cate;
		}
		$tpl_data['cate_arr'] = $cate_arr;

		$address = $this->model_address->get_all(array('wid'=>User::$user_id), '', '');

		$config = $this->model_app_config->get_row(array('user_id'=>User::$user_id, 'type'=>'reserve_'.$type));
		$reserve_config =  $config = json_decode($config['config'], TRUE);
		$config['icon'] = isset($config['icon']) ? $config['icon'] : '';
		$tpl_data['config'] = $config;

		//外链地址
		$domain = $this->session->userdata('domain');
		$url = $domain ? "http://".$domain.".bama555.com/reserve/".$type : '';
		$tpl_data['url'] = $url;

		//读取当前预订类型所有门店的address_id
		$reserve_store = $this->model_reserve_store->get_all(array('wid'=>User::$user_id, 'type'=>$this->types_arr[$type]['type']));
		$selected_ad_ids = array();
		foreach($reserve_store as $rs)
		{
			$selected_ad_ids[] = $rs['address_id'];
		}

		$unselect_address = array();
		$selected_address = array();
		foreach($address as $ad)
		{
			if(in_array($ad['id'], $selected_ad_ids))
			{
				$selected_address[] = $ad;
			}
			elseif($ad['status'] == 0)
			{
				$unselect_address[] = $ad;
			}
		}
		$tpl_data['unselect_address'] = $unselect_address;
		$tpl_data['selected_address'] = $selected_address;

		$this->form_validation->set_rules('name', '标题', 'trim|required|max_length[32]');
		if($this->form_validation->run())
		{
			$base_config['cate_id'] = $cate_id = $this->input->post('cate_id');
			$base_config['name'] = $this->form_validation->set_value('name');
			$base_config['icon'] = $this->input->post('icon');
			$base_config['is_open'] = $this->input->post('is_open');
			$base_config['stuff_name'] = $this->input->post('stuff_name');
			$base_config['tpl'] = $this->input->post('tpl');
			$data_set['config'] = json_encode($base_config);

			if($reserve_config)//更新配置
			{
				$where['user_id'] = User::$user_id;
				$where['type'] = 'reserve_'.$type;
				if($this->model_app_config->update($where, $data_set))
				{
					$address = $this->input->post('address');
					$address = $address ? $address : array();
					$del_ids = array_diff($selected_ad_ids, $address);
					$add_ids = array_diff($address, $selected_ad_ids);

					foreach($del_ids as $did)
					{
						$this->model_reserve_store->delete(array('address_id'=>$did, 'wid'=>User::$user_id, 'type'=>$this->types_arr[$type]['type']));
					}

					foreach($add_ids as $aid)
					{
						$data_rs['wid'] = User::$user_id;
						$data_rs['type'] = $this->types_arr[$type]['type'];
						$data_rs['address_id'] = $aid;
						$this->model_reserve_store->add($data_rs);
					}

					//更改cate_lists表的记录
					if (isset($config['cate_id']) && $config['cate_id'] != $cate_id) {
						if ($cate_id) {
							$data_cate_lists['user_id'] = User::$user_id;
							$data_cate_lists['cate_id'] = $cate_id;
							$data_cate_lists['type'] = 'reserve_'.$type;
							$data_cate_lists['lists_id'] = 0;
							$data_cate_lists['rank'] = 9999;
							$this->model_cate_lists->add($data_cate_lists);
						}
						if ($config['cate_id']) {
							$del_data_cate_lists['user_id'] = User::$user_id;
							$del_data_cate_lists['cate_id'] = $config['cate_id'];
							$del_data_cate_lists['type'] = 'reserve_'.$type;
							$del_data_cate_lists['lists_id'] = 0;
							$this->model_cate_lists->delete($del_data_cate_lists);
						}
					}

					$this->show_message(TRUE, '保存设置成功', '/reserve/'.$type);
				}
				else
				{
					$this->show_message(FALSE, '保存设置失败', '/reserve/'.$type);
				}
			}
			else//添加配置
			{
				$data_set['user_id'] = User::$user_id;
				$data_set['type'] = 'reserve_'.$type;
				if($this->model_app_config->add($data_set))
				{
					//插入当前地址ID到reserve_store表
					$address = $this->input->post('address');
					if($address)
					{
						foreach($address as $ad)
						{
							$data_rs['wid'] = User::$user_id;
							$data_rs['type'] = $this->types_arr[$type]['type'];
							$data_rs['address_id'] = $ad;
							$this->model_reserve_store->add($data_rs);
						}
					}

					//归档记录添加
					if($cate_id)
					{
						$data_cate_lists['user_id'] = User::$user_id;
						$data_cate_lists['cate_id'] = $cate_id;
						$data_cate_lists['type'] = 'reserve_'.$type;
						$data_cate_lists['lists_id'] = 0;
						$data_cate_lists['rank'] = 9999;
						$this->model_cate_lists->add($data_cate_lists);
					}

					$this->show_message(TRUE, '保存设置成功', '/reserve/'.$type);
				}
				else
				{
					$this->show_message(FALSE, '保存设置失败', '/reserve/'.$type);
				}
			}

		}
		else
		{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/reserve/'.$type);
			}
		}

		//获取联系我们模版
		$this->load->config('tpl');
		$reserve_tpl_arr = $this->config->item('reserve_tpl_arr');
		$tpl_data['tpl_lists'] = $reserve_tpl_arr[$type];
		$tpl_data['preview_path'] = $this->config->item('preview_path');

		$tpl_data['type'] = $type;
		$tpl_data['type_info'] = $this->types_arr[$type];
		$tpl_data['cur_nav'] = 'member_sys';
		$tpl_data['reserve_nav'] = 'setting';
		$tpl_data['token'] = $this->token;
		$this->twig->display('reserve/setting', $tpl_data);
	}
}
