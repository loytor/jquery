<?php
/**
 * Created by JetBrains PhpStorm.
 * User: llj
 * Date: 13-11-4
 * Time: 上午11:35
 * To change this template use File | Settings | File Templates.
 */
$config['left_nav'] = array(
    'reply/index' => array(
        'reply/index' => array('text' => '自动回复管理', 'display' => 1),
        'reply/add' => array('text' => '添加关键词回复', 'display' => 0),
        'reply/update' => array('text' => '编辑关键词回复','display' => 0),
        'setting/welcome' => array('text' => '关注时欢迎信息', 'display' => 1),
        'reply/setting' => array('text' => '设置默认回复', 'display' => 1),
        'robot/index' => array('text' => '机器人', 'display' => 1),
    ),
	//微网站
	'cate/index' => array(
		'cate/index' => array('text' => '栏目管理', 'display' => 1),
        'cate/add' => array('text' => '添加栏目', 'display' => 0),
        'cate/update' => array('text' => '编辑栏目', 'display' => 0),
        'cate_lists/index' => array('text' => '内容管理', 'display' => 0),
		'article/index' => array('text' => '图文素材管理', 'display' => 1),
        'article/add' => array('text' => '图文素材管理', 'display' => 0),
        'article/update' => array('text' => '编辑图文素材', 'display' => 0),
        'article_contact/add' => array('text' => '图文素材管理', 'display' => 0),
		'cate_banner/index' => array('text' => '首页顶部广告', 'display' => 1),
        'cate_banner/add' => array('text' => '添加广告', 'display' => 0),
        'cate_banner/update' => array('text' => '编辑广告', 'display' => 0),
        'assist/index' => array('text' => '辅助按钮', 'display' => 1),
        'assist/setting' => array('text' => '辅助设置', 'display' => 0),
        'assist/add' => array('text' => '添加辅助按钮', 'display' => 0),
        'assist/edit' => array('text' => '编辑辅助按钮', 'display' => 0),
		'tpl/index' => array('text' => '模版选择', 'display' => 1),
		'custom_res/index' => array('text' => '模板资源', 'display' => 0),
        'diy_style/index' => array('text' => '自定义样式', 'display' => 1),
	),
	//会员卡
	'member_card/index' => array(
        'member_card/setting' => array('text' => '会员卡设置', 'display' => 1),
        'member_card/index' => array('text' => '领取列表', 'display' => 1),
        'member_card/addmoney' => array('text' => '充值', 'display' => 0),
        'member_card/addcardcredit' => array('text' => '增加积分', 'display' => 0),
        'member_card/consumerecord' => array('text' => '消费记录', 'display' => 0),
        'member_card/creditrecord' => array('text' => '积分记录', 'display' => 0),
        'member_card/setpwd' => array('text' => '交易密码重置', 'display' => 1),
        'member_card/creditrule' => array('text' => '消费积分规则', 'display' => 1),
        'member_card/forwardrule' => array('text' => '转发积分规则', 'display' => 1),
        'member_ticket/index' => array('text' => '代金券', 'display' => 1),
        'member_ticket/add' => array('text' => '添加代金券', 'display' => 0),
        'member_ticket/edit' => array('text' => '编辑代金券', 'display' => 0),
        'member_ticket/listall' => array('text' => '领取列表', 'display' => 0),
        'member_card/consumereport' => array('text' => '消费报表', 'display' => 1),
        'member_card/ticketreport' => array('text' => '代金券报表', 'display' => 1),
	),
	//4S车主关怀系统
	'autocard/index' => array(
        'autocard/show' => array('text' => '基本设置', 'display' => 1),
        'autocard/index' => array('text' => '客户列表', 'display' => 1),
        'autocard/show_vehicle_cate' => array('text' => '车系列表', 'display' => 1),
        'autocard/show_vehicle' => array('text' => '车型列表', 'display' => 1),
        'autocard/edit_account' => array('text' => '编辑客户', 'display' => 0),
        'autocard/edit_vehicle_cate' => array('text' => '编辑车系', 'display' => 0),
        'autocard/edit_vehicle' => array('text' => '编辑车型', 'display' => 0),
	),
/*	//酒店订房
	'reserve/index' => array(
        'reserve/index' => array('text' => '基本设置', 'display' => 1),
        'reserve_store/index' => array('text' => '门店列表', 'display' => 1),
        'reserve_form/index' => array('text' => '自定义预订表单项', 'display' => 1),
	),
	//KTV预订
	'reserve/ktv' => array(
		'reserve/ktv' => '基本配置',
		'reserve_store/ktv' => '门店列表',
		'reserve_form/ktv' => '自定义预订表单项'
	),
	//预约试驾
	'reserve/drive' => array(
		'reserve/drive' => '基本配置',
		'reserve_store/drive' => '门店列表',
		'reserve_form/drive' => '自定义预订表单项'
	),
	//外卖预订
	'reserve/restaurant' => array(
		'reserve/restaurant' => '基本配置',
		'reserve_store/restaurant' => '门店列表',
		'reserve_form/restaurant' => '自定义预订表单项'
	),
	//餐厅预订
	'reserve/table' => array(
		'reserve/table' => '基本配置',
		'reserve_store/table' => '门店列表',
		'reserve_form/table' => '自定义预订表单项'
	),
	//图书预订
	'reserve/book' => array(
		'reserve/book' => '基本配置',
		'reserve_store/book' => '门店列表',
		'reserve_form/book' => '自定义预订表单项'
	),
	//美容预约
	'reserve/cosmetician' => array(
		'reserve/cosmetician' => '基本配置',
		'reserve_store/cosmetician' => '门店列表',
		'reserve_form/cosmetician' => '自定义预订表单项'
	),
	//汽车保养预约
	'reserve/maintenance' => array(
		'reserve/maintenance' => '基本配置',
		'reserve_store/maintenance' => '门店列表',
		'reserve_form/maintenance' => '自定义预订表单项'
	),
	//课程预约
	'reserve/course' => array(
		'reserve/course' => '基本配置',
		'reserve_store/course' => '门店列表',
		'reserve_form/course' => '自定义预订表单项'
	),*/
	//团购
	'groupon/index' => array(
		'groupon/index' => array('text' => '基本配置', 'display' => 1),
		'groupon/category' => array('text' => '团购分类', 'display' => 1),
		'groupon/category_add' => array('text' => '添加分类', 'display' => 0),
		'groupon/lists' => array('text' => '团购列表', 'display' => 1),
		'groupon/add' => array('text' => '添加团购', 'display' => 0),
		'groupon/edit' => array('text' => '编辑团购', 'display' => 0),
		'groupon/order' => array('text' => '订单列表', 'display' => 1),
		'groupon/use_token' => array('text' => '使用', 'display' => 0),
	),
	//微商城
	'mall/index' => array(
        'mall/index' => array('text' => '基本配置', 'display' => 1),
        'mall/cate' => array('text' => '商品分类', 'display' => 1),
        'mall/cate_add' => array('text' => '添加分类', 'display' => 0),
        'mall/cate_edit' => array('text' => '编辑分类', 'display' => 0),
        'mall/lists' => array('text' => '商品列表', 'display' => 1),
        'mall/item_add' => array('text' => '添加商品', 'display' => 0),
        'mall/item_edit' => array('text' => '编辑商品', 'display' => 0),
        'mall/order' => array('text' => '订单列表', 'display' => 1),
        'mall/order_view' => array('text' => '查看订单', 'display' => 0),
        'mall/statistics' => array('text' => '数据统计', 'display' => 1),
        'mall/payment' => array('text' => '支付方式', 'display' => 1),
        'mall/payment_config' => array('text' => '配置支付', 'display' => 0),
        'mall/payment_install' => array('text' => '安装支付', 'display' => 0),
		'mall/payment_log' => array('text' => '支付记录', 'display' => 1),
	),
	//联系信息管理
	'address/index' => array(
		'address/index' => array('text' => '地址管理', 'display' => 1),
		'address/setting' => array('text' => '基本配置', 'display' => 1),
		'address/add' => array('text' => '添加地址', 'display' => 0),
		'address/edit' => array('text' => '编辑地址', 'display' => 0),
/*		'contact/index' => array('text' => '联系我们', 'display' => 1),
		'contact/add' => array('text' => '添加联系我们', 'display' => 0),
		'contact/edit' => array('text' => '编辑联系我们', 'display' => 0),*/
	)
);