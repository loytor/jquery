<?php
/**
 * Created by JetBrains PhpStorm.
 * User: along
 * Date: 13-8-30
 * Time: 下午2:27
 * To change this template use File | Settings | File Templates.
 *
 * @property Model_tpl_css $tpl_css
 */
class Diy_style extends MY_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('model_tpl_css', 'tpl_css');
	}
	public function index()
	{
		/*
		$tplData = array();
		$this->load->config('tpl');
		$tplData['cate'] = $this->config->item('cate_tpl_arr');
		$tplData['list'] = $this->config->item('list_tpl_arr');
		$tplData['detail'] = $this->config->item('detail_tpl_arr');
		$tpl_data['preview_path'] = $this->config->item('preview_path');

		$count = count($tplData['cate']) + count($tplData['list']) +count($tplData['detail']);

		$this->load->model('model_tpl_css');
		$tplCssArr = $this->model_tpl_css->get_all(array('user_id'=>User::$user_id),$count,1);
		if($tplCssArr){
			foreach($tplCssArr as $value){
				$tplData[$value['type']][$value['tpl_id']]['css'] = $value['css'];
			}
		}
		$tpl_data['tpldata'] = $tplData;
		*/
		$where = array('wid'=>User::$user_id);

		$type = $this->input->get('type');

		$type = $type ? $type : 0;
		$where['type'] = $type;

		$tpl_data['diycss'] = $this->tpl_css->get_row($where);

		$tpl_data['type'] = $type;
		$tpl_data['cur_nav'] = 'cate';
		$this->twig->display('tpl/diyCss', $tpl_data);
	}

	public function ajax()
	{
		//header('Content-type: application/json');
		//$type = $this->input->post('type');
		//$tpl = $this->input->post('tpl');
		$diyCss = $this->input->post('diyCss');
		$type = $this->input->post('csstype');
		$type = $type ? $type : 0;

		$this->tpl_css->css = $diyCss;
		$this->tpl_css->type = $type;
		$this->tpl_css->wid = User::$user_id;

		$where['wid'] = User::$user_id;
		$where['type'] = $type;
		if ($this->tpl_css->get_row($where)) {
			if ($this->tpl_css->update($where)) {
				$this->show_message(TRUE, '保存成功', '/diy_style/?type='.$type);
			}
			else {
				$this->show_message(false, '保存失败', '/diy_style/?type='.$type);
			}
		}
		else {
			if ($this->tpl_css->add()) {
				$this->show_message(TRUE, '保存成功', '/diy_style/?type='.$type);
			}
			else {
				$this->show_message(false, '保存失败', '/diy_style/?type='.$type);
			}
		}

	}
}