<?php
/**
 * Created by JetBrains PhpStorm.
 * User: zhw
 * Date: 13-7-25
 * Time: 下午2:27
 * To change this template use File | Settings | File Templates.
 *
 */
class Robot extends MY_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
        $this->load->model('model_user');
	}

	public function index()
	{
        $tpl_data['is_robot'] = $this->model_user->get_one(array('id'=>User::$user_id), 'is_robot');
		$this->load->config('robots');
		$tpl_data['robots'] = $this->config->item('robots');
		$tpl_data['cur_nav'] = 'reply';
		$this->twig->display('robot/index', $tpl_data);
	}

    public function doswitch($do)
    {
        $is_robot = $do == 'open' ? 1 : 0;
        $this->model_user->update(array('id'=>User::$user_id), array('is_robot'=>$is_robot));
        $this->show_message(TRUE, '保存设置成功', '/robot/');
    }
}