<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Article extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('model_article');
		$this->load->model('model_cate');
		//$this->load->model('model_reply');
		$this->load->model('model_cate_lists');
		$this->load->model('model_tpl');
		$this->domain = $this->session->userdata('domain');
	}

	public function index($cate_id = '_') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}

		$cate_arr = array();
		$_cate_arr = $this->model_cate->get_all(array('user_id' => $logged_user_id));
		foreach ($_cate_arr as $_cate) {
			$cate_arr[$_cate['id']] = $_cate;
		}
		$tpl_data['cate_arr'] = $cate_arr;

		$where_set = array('user_id' => $logged_user_id);
		if ($cate_id != '_') {
			if (isset($cate_arr[$cate_id])) {
				$where_set['cate_id'] = $cate_id;
				$tpl_data['cate'] = $cate_arr[$cate_id];
			}
		}

		//筛选查找
		$cate_id = $this->input->get_post('cate_id');
		$title = $this->input->get_post('title');
		$from_time = $this->input->get_post('from_time');
		$to_time = $this->input->get_post('to_time');
		$count_view = $this->input->get_post('count_view');

		$cate_id = ($cate_id === null) ? '_' : $cate_id;
		$tpl_data['cate_id'] = $cate_id;
		$tpl_data['title'] = $title ? $title : '';
		$tpl_data['from_time'] = $from_time ? $from_time : '';
		$tpl_data['to_time'] = $to_time ? $to_time : '';
		$tpl_data['count_view'] = $count_view ? $count_view : '';

		$qs = array();
		if($cate_id != '_')
		{
			$where_set['cate_id'] = $cate_id;
			$qs[] = 'cate_id='.$cate_id;
		}
		if($title)
		{
			$where_set['title'] = 'like:'.$title;
			$qs[] = 'title='.$title;
		}
		if($from_time)
		{
			$where_set['dt_update >= '] = $from_time;
			$qs[] = 'from_time='.$from_time;
		}
		if($to_time)
		{
			$where_set['dt_update <= '] = $to_time;
			$qs[] = 'to_time='.$to_time;
		}
		if($count_view)
		{
			$where_set['count_view'] = $count_view;
			$qs[] = 'count_view='.$count_view;
		}

/*		$page = $this->input->get('per_page');
		$page = $page ? $page : self::CUR_PAGE;
		$queryStr = implode('&', $qs);
		$this->queryString = '/'.$uid.'?' . $queryStr;
		$this->pageQueryString = true;*/
		$page = $this->input->get('per_page');
		$queryStr = implode('&', $qs);

		$this->load->library('pagination');
		$pagination_config = array(
			//'base_url'		=> '/article/index/'.$cate_id.'/',
			'base_url'      => '/article?'.$queryStr,
			'total_rows'	=> $this->model_article->total_rows($where_set),
			'per_page'		=> 8,
			'uri_segment'	=> 4,
			'page_query_string' => TRUE
		);

		$this->pagination->initialize($pagination_config);
		$tpl_data['pagination'] = $this->pagination->create_links();
		$article_arr = $this->model_article->get_all($where_set, $pagination_config['per_page'], $page, 'id', 'desc');

		$article_data = $article_id_arr = array();
        foreach ($article_arr as $_article) {
			$_article['rank'] = $_article['rank'] == 99999 ? '' : $_article['rank'];
			$_article['cate_name'] = isset($cate_arr[$_article['cate_id']]) ? $cate_arr[$_article['cate_id']]['cate_name'] : '';
			$_article['preview_url'] = $this->_url($_article, true);
            unset($_article['is_top']);
            $article_data[$_article['id']] = $_article;
            $article_id_arr[] = $_article['id'];
		}

        if($article_id_arr){
            //查询归档列表
	        $where_set = array();
            $where_set['in:lists_id'] = $article_id_arr;
            $where_set['type'] = 'article';
	        $where_set['user_id'] = $logged_user_id;
	        if ($cate_id != '_') {
		        if (isset($cate_arr[$cate_id])) {
			        $where_set['cate_id'] = $cate_id;
		        }
	        }
            $cate_lists_list = $this->model_cate_lists->get_list($where_set);
            if($cate_lists_list){
                foreach($cate_lists_list as $list){
                    $article_data[$list['lists_id']]['is_top'] = $list['is_top'];
                    $article_data[$list['lists_id']]['cate_lists_id'] = $list['id'];
                }
            }
        }
                
		$tpl_data['article_arr'] = $article_data;
		$tpl_data['cur_nav'] = 'article';
		$this->twig->display('article/index', $tpl_data);
	}

	public function search_x() {
		$data = array(
			'items'	=> array(),
			'last_page'		=> 0,
			'next_page'		=> 0,
		);
		$logged_user_id = logged_user_id();
		if ($logged_user_id) {
			$where_set = array('user_id' => $logged_user_id);
			$cate_id = trim($this->input->get('cate_id'));
			if ($cate_id) {
				$where_set['cate_id'] = $cate_id;
			}
			$keyword = trim($this->input->get('keyword'));
			if ($keyword) {
				$where_set['title'] = 'like:'.$keyword;
			}
			$total_rows = $this->model_article->total_rows($where_set);
			$page = intval($this->input->get('page'));
			$page = $page < 1 ? 1 : $page;
			$per_page = 5;
			$article_arr = $this->model_article->get_all($where_set, $per_page, $page);
			foreach ($article_arr as &$_article) {
				$_article['image_preview'] = image_url($_article['image'], 80, 80);
				$_article['url'] = $this->_url($_article);
			}
			$data['items'] = $article_arr;
			if ($page * $per_page < $total_rows) {
				$data['next_page'] = $page + 1;
			}
			if ($page > 1) {
				$data['last_page'] = $page - 1;
			}
		}
		header('Content-type: application/json');
		echo json_encode($data);
	}

	public function add() {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$cate_id = $this->input->get('cate_id');
		$cate_arr = array();
		$_cate_arr = $this->model_cate->get_all(array('user_id' => $logged_user_id), '', '', 'rank', 'ASC');
		foreach ($_cate_arr as $_cate) {
			if ($_cate['id'] == $cate_id) {
				$_cate['selected'] = TRUE;
			}
			$cate_arr[$_cate['id']] = $_cate;
		}
		$tpl_data['cate_arr'] = $cate_arr;
		$this->load->library('form_validation');
		$this->load->helper('form');
		$this->form_validation->set_rules('cate_id', '栏目', 'trim');
		$this->form_validation->set_rules('title', '标题', 'trim|required|max_length[255]|htmlspecialchars');
		$this->form_validation->set_rules('description', '描述', 'trim|max_length[255]|htmlspecialchars');
		$this->form_validation->set_rules('content', '内容', 'trim');
		$this->form_validation->set_rules('url', '外部链接', 'trim');
		$this->form_validation->set_rules('image', '图片', 'trim|callback__check_image');
		if ($this->form_validation->run()) {
			$data_set['user_id'] = $logged_user_id;
			$cate_id = $this->form_validation->set_value('cate_id');
			if ($cate_id AND ! isset($cate_arr[$cate_id])) {
				$this->show_message(FALSE, '栏目不存在', '/article/add');
			}
			$data_set['cate_id'] = $cate_id;
			$data_set['type'] = '';
			$data_set['title'] = $this->form_validation->set_value('title');
			$data_set['description'] = $this->form_validation->set_value('description');
			$data_set['content'] = $this->form_validation->set_value('content');
			$data_set['url'] = $this->form_validation->set_value('url');
			$data_set['image'] = $this->form_validation->set_value('image');
			$is_image_sic = $this->input->post('is_image_sic');
			$data_set['is_image_sic'] = $is_image_sic ? 1 : 0;
			$is_top = $this->input->post('is_top');
			$data_set['is_top'] = $is_top ? 1 : 0;
			$data_set['is_upvote'] = $this->input->post('is_upvote');
			$data_set['tpl'] = $this->input->post('tpl');
			$data_set['level_type'] = $this->input->post('level_type');
			if( $data_set['level_type'] ){
			    $data_set['level'] = intval($this->input->post('level'));
			}
            /*
			if ($cate_id AND $is_top) {
				$_top_article = $this->model_article->get_row(array('cate_id' => $cate_id, 'is_top' => 1));
				if ($_top_article) {
					$this->show_message(FALSE, '先取消同栏目下其他的置顶文章', '/article/add');
				}
			}
            */
			$data_set['rank'] = 99999;
			$article_id = $this->model_article->add($data_set);
			if ($cate_id) {
				$this->model_cate->count_step($cate_id, 'count_article', 1);
				$data_cate_lists['user_id'] = $logged_user_id;
				$data_cate_lists['cate_id'] = $cate_id;
				$data_cate_lists['type'] = 'article';
				$data_cate_lists['lists_id'] = $article_id;
				$data_cate_lists['rank'] = 9999;
                $data_cate_lists['is_top'] = $is_top ? 1 : 0;
				$this->model_cate_lists->add($data_cate_lists);
			}		
			$this->show_message(TRUE, '添加成功', '/article');
		} else {
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/article/add');
			}
		}

		$this->load->config('tpl');
		$detail_tpl_arr = $this->config->item('detail_tpl_arr');
		$tpl_data['tpl_lists'] = $detail_tpl_arr;
		//读取全局设置的模版
		$tpl = $this->model_tpl->get_row(array('user_id'=>$logged_user_id));
		if($tpl){
			$global_tpl = $tpl['detail_tpl'] ? $tpl['detail_tpl'] : 'default';
		}else{
			$global_tpl = 'default';
		}
		$tpl_data['global_tpl'] = $detail_tpl_arr[$global_tpl];
		$tpl_data['preview_path'] = $this->config->item('preview_path');
        
		//权限
		$level = $this->get_level();
        $tpl_data['level'] = $level;
		
		$this->load->library('encrypt');
		$token_data = array('user_id' => $logged_user_id, 'time' => time());
		$tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
		$tpl_data['cur_nav'] = 'article';
		$this->twig->display('article/add', $tpl_data);
	}
	
	//权限
	private function get_level()
    {
        $level = array();
        $this->load->model('mcard_model');
        $mcard = $this->mcard_model->where(array('site_id'=>logged_user_id()))->find();
        if( $mcard ){
            $this->load->model('mcard_level_model');
            $level_temp = $this->mcard_level_model
                      ->order_by('basic desc,id desc')
                      ->where(array(
                          'site_id' => logged_user_id(),
                          'mcard_id' => $mcard['id'],
                          'status' => 1
                      ))
                      ->find_all();
             if( $level_temp ){
                foreach ( $level_temp as $val ){
                    $level[$val['id']] = $val['title'];
                }
             }
        }
        return $level;
    }

	public function update($article_id = '') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$article = $this->model_article->get_row(array('id' => $article_id, 'user_id' => $logged_user_id));
		if ( ! $article) {
			$this->show_message(FALSE, '找不到文章', '/article');
		}
		if ($article['type'] == 'contact') {
			redirect('/article_contact/update/'.$article_id);
		}
		$tpl_data['article'] = $article;

		$this->load->config('tpl');
		$detail_tpl_arr = $this->config->item('detail_tpl_arr');
		$tpl_data['tpl_lists'] = $detail_tpl_arr;
		//读取全局设置的模版
		$tpl = $this->model_tpl->get_row(array('user_id'=>$logged_user_id));
		if($tpl){
			$global_tpl = $tpl['detail_tpl'] ? $tpl['detail_tpl'] : 'default';
		}else{
			$global_tpl = 'default';
		}
		$tpl_data['global_tpl'] = $detail_tpl_arr[$global_tpl];
		$tpl_data['preview_path'] = $this->config->item('preview_path');

		$cate_arr = array();
		$_cate_arr = $this->model_cate->get_all(array('user_id' => $logged_user_id), '', '', 'rank', 'ASC');
		foreach ($_cate_arr as $_cate) {
			$cate_arr[$_cate['id']] = $_cate;
		}
		$tpl_data['cate_arr'] = $cate_arr;
		$this->load->library('form_validation');
		$this->load->helper('form');
		$this->form_validation->set_rules('cate_id', '栏目', 'trim');
		$this->form_validation->set_rules('title', '标题', 'trim|required|max_length[255]|htmlspecialchars');
		$this->form_validation->set_rules('description', '描述', 'trim|max_length[255]|htmlspecialchars');
		$this->form_validation->set_rules('content', '内容', 'trim');
		$this->form_validation->set_rules('url', '外部链接', 'trim');
		$this->form_validation->set_rules('image', '图片', 'trim|callback__check_image');
		if ($this->form_validation->run()) {
			$cate_id = $this->form_validation->set_value('cate_id');
			if ($cate_id AND ! isset($cate_arr[$cate_id])) {
				$this->show_message(FALSE, '栏目不存在', '/article/update/'.$article_id);
			}
			$data_set['cate_id'] = $cate_id;
			$data_set['title'] = $title = $this->form_validation->set_value('title');
			$data_set['description'] = $description =  $this->form_validation->set_value('description');
			$data_set['content'] = $this->form_validation->set_value('content');
			$data_set['url'] = $this->form_validation->set_value('url');
			$data_set['image'] = $image = $this->form_validation->set_value('image');
			$is_image_sic = $this->input->post('is_image_sic');
			$data_set['is_image_sic'] = $is_image_sic ? 1 : 0;
			$is_top = $this->input->post('is_top');
			$data_set['is_top'] = $is_top ? 1 : 0;
			$data_set['is_upvote'] = $this->input->post('is_upvote');
			$data_set['tpl'] = $this->input->post('tpl');
		    $data_set['level_type'] = $this->input->post('level_type');
            if( $data_set['level_type'] ){
                $data_set['level'] = intval($this->input->post('level'));
            }else{
                $data_set['level'] = 0;
            }
            /*
			if ($cate_id AND $is_top) {
				$_top_article = $this->model_article->get_row(array('cate_id' => $cate_id, 'is_top' => 1, 'id !=' => $article_id));
				if ($_top_article) {
					$this->show_message(FALSE, '先取消同栏目下其他的置顶文章', '/article/update/'.$article_id);
				}
			}*/
			if($this->model_article->update($article_id, $data_set)){
                
                if ($article['cate_id'] != $cate_id) {
    				if ($cate_id) {
    					$this->model_cate->count_step($cate_id, 'count_article', 1);
    					$data_cate_lists['user_id'] = $logged_user_id;
    					$data_cate_lists['cate_id'] = $cate_id;
    					$data_cate_lists['type'] = 'article';
    					$data_cate_lists['lists_id'] = $article['id'];
    					$data_cate_lists['rank'] = 9999;
    					$this->model_cate_lists->add($data_cate_lists);
    				}
    				if ($article['cate_id']) {
    					$this->model_cate->count_step($article['cate_id'], 'count_article', -1);
    					$del_data_cate_lists['user_id'] = $logged_user_id;
    					$del_data_cate_lists['cate_id'] = $article['cate_id'];
    					$del_data_cate_lists['type'] = 'article';
    					$del_data_cate_lists['lists_id'] = $article['id'];
    					$this->model_cate_lists->delete($del_data_cate_lists);
    				}
    			}
                
                $this->show_message(TRUE, '更新成功', 'javascript:history.go(-2)');

			}else{
                $this->show_message(false, '更新失败', '/article');

			}

/*			$reply_arr = $this->model_reply->reply_list($article_id);
			if ($reply_arr) {
				foreach ($reply_arr as $_reply) {
					$article_arr = array();
					$_article_arr = json_decode($_reply['content'], TRUE);
					foreach ($_article_arr as $_article) {
						if ($_article['id'] == $article_id) {
							$_article['title'] = $title;
							$_article['description'] = $description;
							$_article['image'] = $image;
						}
						$article_arr[] = $_article;
					}
					$this->model_reply->update($_reply['id'], array('content' => json_encode($article_arr)));
				}
			}*/
			
		} else {
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/article/update/'.$article_id);
			}
		}
		
		//权限
        $level = $this->get_level();
        $tpl_data['level'] = $level;
		
		$this->load->library('encrypt');
		$token_data = array('user_id' => $logged_user_id, 'time' => time());
		$tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
		$tpl_data['cur_nav'] = 'article';
		$this->twig->display('article/update', $tpl_data);
	}

	public function delete($article_id = '') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$article = $this->model_article->get_row(array('id' => $article_id, 'user_id' => $logged_user_id));
		if ( ! $article) {
			$this->show_message(FALSE, '找不到文章', '/cate');
		}
		if ($article['cate_id']) {
			$this->model_cate->count_step($article['cate_id'], 'count_article', -1);
			$del_data_cate_lists['user_id'] = $logged_user_id;
			$del_data_cate_lists['cate_id'] = $article['cate_id'];
			$del_data_cate_lists['type'] = 'article';
			$del_data_cate_lists['lists_id'] = $article_id;
			$this->model_cate_lists->delete($del_data_cate_lists);
		}
		$this->model_article->delete($article_id);
/*		$reply_arr = $this->model_reply->reply_list($article_id);
		if ($reply_arr) {
			foreach ($reply_arr as $_reply) {
				$article_arr = array();
				$_article_arr = json_decode($_reply['content'], TRUE);
				foreach ($_article_arr as $_article) {
					if ($_article['id'] != $article_id) {
						$article_arr[] = $_article;
					}
				}
				$this->model_reply->update($_reply['id'], array('content' => json_encode($article_arr)));
				$this->model_reply->article_delete($_reply['id'], $article_id);
			}
		}*/
		$this->show_message(TRUE, '删除成功', $_SERVER['HTTP_REFERER']);
	}

	public function update_rank($article_id = '') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			$this->show_message(FALSE, '请先登录', '/auth/login');
		}
		$article = $this->model_article->get_row(array('id' => $article_id, 'user_id' => $logged_user_id));
		if ( ! $article) {
			$this->show_message(FALSE, '找不到文章', '/article');
		}
		$this->load->library('form_validation');
		$this->load->helper('form');
		$this->form_validation->set_rules('rank', '排序', 'trim');
		if ($this->form_validation->run()) {
			$rank = $this->form_validation->set_value('rank');
			$data_set['rank'] = $rank ? intval($rank) : 99999;
			$this->model_article->update($article_id, $data_set);
			$this->show_message(TRUE, '更新成功', '/article');
		} else {
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/article');
			}
		}
	}
	

	public function _check_image($image) {
		if ($image) {
			if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
				$this->form_validation->set_message('_check_image', '图片地址格式错误');
				return FALSE;
			}
		}
		return TRUE;
	}
    
    public function top($cate_lists_id = '') {
        if($cate_lists_id){
            $cate_list = $this->model_cate_lists->get_row(array('id'=>$cate_lists_id));
            if($cate_list){
        		if($this->model_cate_lists->update(array('id'=>$cate_lists_id), array('is_top'=>1))){
        			$this->show_message(TRUE, '置顶成功', '/article');
        		}else{
        			$this->show_message(FALSE, '置顶失败', '/article');
        		}
        	}else{
        		$this->show_message(FALSE, '该内容不存在', '/article');
        	}
        }
    }
    
    public function cancel_top($cate_lists_id=''){
    	if($cate_lists_id){
        	$cate_list = $this->model_cate_lists->get_row(array('id'=>$cate_lists_id));
        	if($cate_list){
        		if($this->model_cate_lists->update(array('id'=>$cate_lists_id), array('is_top'=>0))){
        			$this->show_message(TRUE, '取消置顶成功', '/article');
        		}else{
        			$this->show_message(FALSE, '取消置顶失败', '/article');
        		}
        	}else{
        		$this->show_message(FALSE, '该内容不存在', '/article');
        	}   
    	}
    }
    
    private function _url($article, $flag = false) {
		if ($article['url']) {
			return $article['url'];
		} else if ($article['type'] == 'contact') {
			//$url = full_url('/article_contact/view/'.$article['id'], 'w');
			$url = '/linkus?id='.$article['id'];
		} else {
			$url = '/detail?id='.$article['id'];
		}
	    if ($flag)
	    {
		    $url = full_url($url,$this->domain);
	    }
		return $url;
	}
    
	private function show_message($success, $message, $redirect) {
		if ($this->input->is_ajax_request()) {
			$data = array(
				'success'	=> $success ? 1 : 0,
				'message'	=> strip_tags($message),
			);
			header('Content-type: application/json');
			echo json_encode($data);
		} else {
			$tpl_data = array(
				'message'	=> $message,
				'redirect'	=> $redirect,
			);
			$this->twig->display('show_message', $tpl_data);
		}
		exit;
	}


    /**
     *
     * @author Qianc
     * @date 2014-9-10
     * @description 批量归档
     */
    public function batch_cat()
    {
        $ids = $this->input->get_post('ids');
        $cat_id = $this->input->get_post('cat_id');
        $logged_user_id = logged_user_id();
        if($ids && $cat_id){
            foreach($ids as $article_id){
                $article = $this->_getOneArticle($article_id);
                if ($article['cate_id'] != $cat_id) {
                    if ($cat_id) {
                        $this->model_cate->count_step($cat_id, 'count_article', 1);
                        $data_cate_lists['user_id'] = $logged_user_id;
                        $data_cate_lists['cate_id'] = $cat_id;
                        $data_cate_lists['type'] = 'article';
                        $data_cate_lists['lists_id'] = $article['id'];
                        $data_cate_lists['rank'] = 9999;
                        $this->model_cate_lists->add($data_cate_lists);
                    }
                    if ($article['cate_id']) {
                        $this->model_cate->count_step($article['cate_id'], 'count_article', -1);
                        $del_data_cate_lists['user_id'] = $logged_user_id;
                        $del_data_cate_lists['cate_id'] = $article['cate_id'];
                        $del_data_cate_lists['type'] = 'article';
                        $del_data_cate_lists['lists_id'] = $article['id'];
                        $this->model_cate_lists->delete($del_data_cate_lists);
                    }
                }
            }
            $this->load->model('article_model');
            $ret = $this->article_model->where_in('id', $ids)->edit(array('cate_id' => $cat_id));

            $rret = $ret ?  0 : 1;
            $msg = $ret ?  '操作成功' : '操作失败';
            exit($this->ajax_return(array('ret' => $rret, 'msg' => $msg)));
        }
    }

    /**
     *
     * @author Qianc
     * @date 2014-9-11
     * @description 批量删除
     */
    public function batch_del()
    {
        $ids = $this->input->get_post('ids');
        $logged_user_id = logged_user_id();
        if($ids){
            foreach($ids as $id){
                $article = $this->_getOneArticle($id);
                if ($article && $article['cate_id']) {
                    $this->model_cate->count_step($article['cate_id'], 'count_article', -1);
                    $del_data_cate_lists['user_id'] = $logged_user_id;
                    $del_data_cate_lists['cate_id'] = $article['cate_id'];
                    $del_data_cate_lists['type'] = 'article';
                    $del_data_cate_lists['lists_id'] = $id;
                    $this->model_cate_lists->delete($del_data_cate_lists);
                }
            }
            $this->load->model('article_model');//
            $ret = $this->article_model->where_in('id', $ids)->delete();

            $rret = $ret ?  0 : 1;
            $msg = $ret ?  '操作成功' : '操作失败';
            exit($this->ajax_return(array('ret' => $rret, 'msg' => $msg)));
        }
    }


    /**
     * ajax返回数据
     */
    protected function ajax_return($data, $type='json')
    {
        if(strtoupper($type)=='JSON') {
            echo $this->output->set_content_type('application/json')->set_output(json_encode($data))->get_output();
        }else{
            // TODO 增加其它格式
        }
        exit;
    }


    /**
     *
     * @author Qianc
     * @date 2014-9-17
     * @description 获取一条文章信息
     */
    protected function _getOneArticle($article_id, $field = "*")
    {
        $this->load->model('article_model');
        $where['id'] = $article_id;

        $article = $this->article_model->select($field)->where($where)->find();
        return $article;
    }
}