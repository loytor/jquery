<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Article_contact extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('model_article');
		$this->load->model('model_cate');
        $this->load->model('model_cate_lists');
		$this->load->config('baidu');
	}

	public function add() {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$cate_id = $this->input->get('cate_id');
		$cate_arr = array();
		$_cate_arr = $this->model_cate->get_all(array('user_id' => $logged_user_id));
		foreach ($_cate_arr as $_cate) {
			if ($_cate['id'] == $cate_id) {
				$_cate['selected'] = TRUE;
			}
			$cate_arr[$_cate['id']] = $_cate;
		}
		$tpl_data['cate_arr'] = $cate_arr;
		$this->load->library('encrypt');
		$token_data = array('user_id' => $logged_user_id, 'time' => time());
		$tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
		$tpl_data['ak'] = $this->config->item('baidu_token');
		$tpl_data['cur_nav'] = 'article';
		$this->twig->display('article_contact/add', $tpl_data);
	}

	public function update($article_id = '') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		
		$cate_arr = array();
		$_cate_arr = $this->model_cate->get_all(array('user_id' => $logged_user_id), 100, 1);
		foreach ($_cate_arr as $_cate) {
			$cate_arr[$_cate['id']] = $_cate;
		}
		$tpl_data['cate_arr'] = $cate_arr;

		$tpl_data['article_id'] = $article_id;
		$this->load->library('encrypt');
		$token_data = array('user_id' => $logged_user_id, 'time' => time());
		$tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
		$tpl_data['ak'] = $this->config->item('baidu_token');
		$tpl_data['cur_nav'] = 'article';
		$this->twig->display('article_contact/update', $tpl_data);
	}
		
// 	public function add() {
// 		$logged_user_id = logged_user_id();
// 		if ( ! $logged_user_id) {
// 			redirect_return('/auth/login');
// 		}
// 		$cate_id = $this->input->get('cate_id');
// 		$cate_arr = array();
// 		$_cate_arr = $this->model_cate->get_all(array('user_id' => $logged_user_id), 100, 1);
// 		foreach ($_cate_arr as $_cate) {
// 			if ($_cate['id'] == $cate_id) {
// 				$_cate['selected'] = TRUE;
// 			}
// 			$cate_arr[$_cate['id']] = $_cate;
// 		}
// 		$tpl_data['cate_arr'] = $cate_arr;
// 		$this->load->library('form_validation');
// 		$this->load->helper('form');
// 		$this->form_validation->set_rules('cate_id', '栏目', 'trim');
// 		$this->form_validation->set_rules('title', '标题', 'trim|required|max_length[255]|htmlspecialchars');
// 		$this->form_validation->set_rules('address', '地址', 'trim|max_length[255]|htmlspecialchars');
// 		$this->form_validation->set_rules('address_map_url', '地址链接', 'trim|htmlspecialchars');
// 		$this->form_validation->set_rules('tel', '电话', 'trim|max_length[255]|htmlspecialchars');
// 		$this->form_validation->set_rules('email', 'Email', 'trim|max_length[255]|htmlspecialchars');
// 		$this->form_validation->set_rules('image', '图片', 'trim');
// 		if ($this->form_validation->run()) {
// 			$data_set['user_id'] = $logged_user_id;
// 			$cate_id = $this->form_validation->set_value('cate_id');
// 			if ($cate_id AND ! isset($cate_arr[$cate_id])) {
// 				$this->show_message(FALSE, '栏目不存在', '/article_contact/add');
// 			}
// 			$data_set['cate_id'] = $cate_id;
// 			$data_set['type'] = 'contact';
// 			$data_set['title'] = $this->form_validation->set_value('title');
// 			$data_set['description'] = '';
// 			$content = array(
// 				'address'			=> $this->form_validation->set_value('address'),
// 				'address_map_url'	=> $this->form_validation->set_value('address_map_url'),
// 				'tel'				=> $this->form_validation->set_value('tel'),
// 				'email'				=> $this->form_validation->set_value('email'),
// 			);
// 			$data_set['content'] = json_encode($content);
// 			$data_set['image'] = $this->form_validation->set_value('image');
// 			$is_image_sic = $this->input->post('is_image_sic');
// 			$data_set['is_image_sic'] = $is_image_sic ? 1 : 0;
// 			$is_top = $this->input->post('is_top');
//             /*
// 			$data_set['is_top'] = $is_top ? 1 : 0;
// 			if ($cate_id AND $is_top) {
// 				$_top_article = $this->model_article->get_row(array('cate_id' => $cate_id, 'is_top' => 1));
// 				if ($_top_article) {
// 					$this->show_message(FALSE, '先取消同栏目下其他的置顶文章', '/article_contact/add');
// 				}
// 			}*/
// 			$article_id = $this->model_article->add($data_set);
// 			if ($cate_id) {
// 				$this->model_cate->count_step($cate_id, 'count_article', 1);
//                 $data_cate_lists['user_id'] = $logged_user_id;
// 				$data_cate_lists['cate_id'] = $cate_id;
// 				$data_cate_lists['type'] = 'article';
// 				$data_cate_lists['lists_id'] = $article_id;
// 				$data_cate_lists['rank'] = 999;
// 				$this->model_cate_lists->add($data_cate_lists);
// 			}
            
// 			$this->show_message(TRUE, '添加成功', '/article');
// 		} else {
// 			$errors = validation_errors();
// 			if ($errors) {
// 				$this->show_message(FALSE, $errors, '/article_contact/add');
// 			}
// 		}
// 		$this->load->library('encrypt');
// 		$token_data = array('user_id' => $logged_user_id, 'time' => time());
// 		$tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
// 		$tpl_data['cur_nav'] = 'article';
// 		$this->twig->display('article_contact/add', $tpl_data);
// 	}

// 	public function update($article_id = '') {
// 		$logged_user_id = logged_user_id();
// 		if ( ! $logged_user_id) {
// 			redirect_return('/auth/login');
// 		}
// 		$article = $this->model_article->get_row(array('id' => $article_id, 'user_id' => $logged_user_id, 'type' => 'contact'));
// 		if ( ! $article) {
// 			$this->show_message(FALSE, '找不到联系方式', '/article');
// 		}
// 		$article['content'] = json_decode($article['content'], TRUE);
// 		$tpl_data['article'] = $article;
// 		$cate_arr = array();
// 		$_cate_arr = $this->model_cate->get_all(array('user_id' => $logged_user_id), 100, 1);
// 		foreach ($_cate_arr as $_cate) {
// 			$cate_arr[$_cate['id']] = $_cate;
// 		}
// 		$tpl_data['cate_arr'] = $cate_arr;
// 		$this->load->library('form_validation');
// 		$this->load->helper('form');
// 		$this->form_validation->set_rules('cate_id', '栏目', 'trim');
// 		$this->form_validation->set_rules('title', '标题', 'trim|required|max_length[255]|htmlspecialchars');
// 		$this->form_validation->set_rules('address', '地址', 'trim|max_length[255]|htmlspecialchars');
// 		$this->form_validation->set_rules('address_map_url', '地址链接', 'trim|htmlspecialchars');
// 		$this->form_validation->set_rules('tel', '电话', 'trim|max_length[255]|htmlspecialchars');
// 		$this->form_validation->set_rules('email', 'Email', 'trim|max_length[255]|htmlspecialchars');
// 		$this->form_validation->set_rules('image', '图片', 'trim');
// 		if ($this->form_validation->run()) {
// 			$cate_id = $this->form_validation->set_value('cate_id');
// 			if ($cate_id AND ! isset($cate_arr[$cate_id])) {
// 				$this->show_message(FALSE, '栏目不存在', '/article_contact/add');
// 			}
// 			$data_set['cate_id'] = $cate_id;
// 			$data_set['title'] = $this->form_validation->set_value('title');
// 			$data_set['description'] = '';
// 			$content = array(
// 				'address'			=> $this->form_validation->set_value('address'),
// 				'address_map_url'	=> $this->form_validation->set_value('address_map_url'),
// 				'tel'				=> $this->form_validation->set_value('tel'),
// 				'email'				=> $this->form_validation->set_value('email'),
// 			);
// 			$data_set['content'] = json_encode($content);
// 			$data_set['image'] = $this->form_validation->set_value('image');
// 			$is_image_sic = $this->input->post('is_image_sic');
// 			$data_set['is_image_sic'] = $is_image_sic ? 1 : 0;
//             /*
// 			$is_top = $this->input->post('is_top');
// 			$data_set['is_top'] = $is_top ? 1 : 0;
// 			if ($cate_id AND $is_top) {
// 				$_top_article = $this->model_article->get_row(array('cate_id' => $cate_id, 'is_top' => 1, 'id !=' => $article_id));
// 				if ($_top_article) {
// 					$this->show_message(FALSE, '先取消同栏目下其他的置顶文章', '/article_contact/update/'.$article_id);
// 				}
// 			}*/
// 			$this->model_article->update($article_id, $data_set);
            
            
//             if ($article['cate_id'] != $cate_id) {
// 				if ($cate_id) {
// 					$this->model_cate->count_step($cate_id, 'count_article', 1);
// 					$data_cate_lists['user_id'] = $logged_user_id;
// 					$data_cate_lists['cate_id'] = $cate_id;
// 					$data_cate_lists['type'] = 'article';
// 					$data_cate_lists['lists_id'] = $article['id'];
// 					$data_cate_lists['rank'] = 9999;
// 					$this->model_cate_lists->add($data_cate_lists);					
// 				}
// 				if ($article['cate_id']) {
// 					$this->model_cate->count_step($article['cate_id'], 'count_article', -1);
// 					$del_data_cate_lists['user_id'] = $logged_user_id;
// 					$del_data_cate_lists['cate_id'] = $article['cate_id'];
// 					$del_data_cate_lists['type'] = 'article';
// 					$del_data_cate_lists['lists_id'] = $article['id'];
// 					$this->model_cate_lists->delete($del_data_cate_lists);					
// 				}
// 			}
//             /*
//             if($cate_id){
//                 $catelistinfo = $this->model_cate_lists->get_row(array('cate_id'=>$cate_id,'type'=>'article','lists_id'=>$article_id));
//                 if($article['cate_id'] != $cate_id){
//                     //对新的分类文章数+1
//                     $this->model_cate->count_step($cate_id, 'count_article', 1);
//                     //对旧的分类文章数-1
//                     $this->model_cate->count_step($article['cate_id'], 'count_article', -1);
                    
//                     //如果列表有记录 需要更新cate_id
//                     if($catelistinfo){
//                         $update_data['cate_id'] = $cate_id;
//                         //$update_data['is_top'] = $is_top ? 1 : 0;
//                         $this->model_cate_lists->update($catelistinfo['id'],$update_data);
//                     }else{
//                         $data_cate_lists['user_id'] = $logged_user_id;
//     					$data_cate_lists['cate_id'] = $cate_id;
//     					$data_cate_lists['type'] = 'article';
//     					$data_cate_lists['lists_id'] = $article['id'];
//     					$data_cate_lists['rank'] = 9999;
//                         //$data_cate_lists['is_top'] = $is_top ? 1 : 0;
//     					$this->model_cate_lists->add($data_cate_lists);
//                     }
//                 }else{
//                     if(!$catelistinfo){
//                         $data_cate_lists['user_id'] = $logged_user_id;
//     					$data_cate_lists['cate_id'] = $cate_id;
//     					$data_cate_lists['type'] = 'article';
//     					$data_cate_lists['lists_id'] = $article['id'];
//     					$data_cate_lists['rank'] = 9999;
//                         //$data_cate_lists['is_top'] = $is_top ? 1 : 0;
//     					$this->model_cate_lists->add($data_cate_lists);
//                     }
//                 }
//             }else{
//                 //文章未归档或者取消归档
//                 if($article['cate_id']){
//                     $catelistinfo = $this->model_cate_lists->get_row(array('cate_id'=>$article['cate_id'],'type'=>'article','lists_id'=>$article_id));
//                     if($catelistinfo){
//                         $del_data_cate_lists['id'] = $catelistinfo['id'];
//                         $this->model_cate_lists->delete($del_data_cate_lists);    
//                     }
//                     //分类-1
//                     $this->model_cate->count_step($article['cate_id'], 'count_article', -1);    
//                 }
//             }  
// 			*/
// 			$this->show_message(TRUE, '更新成功', '/article');
// 		} else {
// 			$errors = validation_errors();
// 			if ($errors) {
// 				$this->show_message(FALSE, $errors, '/article_contact/update/'.$article_id);
// 			}
// 		}
// 		$this->load->library('encrypt');
// 		$token_data = array('user_id' => $logged_user_id, 'time' => time());
// 		$tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
// 		$tpl_data['cur_nav'] = 'article';
// 		$this->twig->display('article_contact/update', $tpl_data);
// 	}

	private function show_message($success, $message, $redirect) {
		if ($this->input->is_ajax_request()) {
			$data = array(
				'success'	=> $success ? 1 : 0,
				'message'	=> strip_tags($message),
			);
			header('Content-type: application/json');
			echo json_encode($data);
		} else {
			$tpl_data = array(
				'message'	=> $message,
				'redirect'	=> $redirect,
			);
			$this->twig->display('show_message', $tpl_data);
		}
		exit;
	}

	public function article_contact_data($article_id=''){
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			$this->show_message(FALSE, '请先登录', '/auth/login');
		}		
		$article_contact = $this->model_article->get_row(array('id' => $article_id, 'user_id' => $logged_user_id, 'type' => 'contact'));
		
		$data = array();
		$data['article_id'] = $article_contact['id'];
		$data['cate_id'] = $article_contact['cate_id'];
		$data['title'] = $article_contact['title'];
		$data['image'] = $article_contact['image'];
		$data['is_image_sic'] = $article_contact['is_image_sic'];
		$data['address'] = json_decode($article_contact['content']);
		header('Content-type: application/json');
		echo json_encode($data);		
	}
	
	public function add_article_contact(){
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			header('Content-type: application/json');
			$data['result'] = '请先登录';
			$data['redirect'] = '/auth/login';
			echo json_encode($data);
			exit;
		}

		$this->load->library('form_validation');
		$this->load->helper('form');
		$this->form_validation->set_error_delimiters('', '');
		$this->form_validation->set_rules('cate_id', '栏目', 'trim');
		$this->form_validation->set_rules('title', '标题', 'trim|required|max_length[255]|htmlspecialchars');
		$this->form_validation->set_rules('image', '图片', 'trim');
		$data = array();
		if ($this->form_validation->run()) {
			$data_set['user_id'] = $logged_user_id;
			$data_set['type'] = 'contact';
			$data_set['cate_id'] = $this->input->post('cate_id');
			$data_set['title'] = $this->input->post('title');
			$data_set['image'] = $this->input->post('image');
			$data_set['is_image_sic'] = $this->input->post('is_image_sic');
			$data_set['content'] = $this->input->post('address');
	
			$article_id = $this->model_article->add($data_set);
			if($article_id){
				$cate_id = $data_set['cate_id'];
				if ($cate_id) {
					$this->model_cate->count_step($cate_id, 'count_article', 1);
					$data_cate_lists['user_id'] = $logged_user_id;
					$data_cate_lists['cate_id'] = $cate_id;
					$data_cate_lists['type'] = 'article';
					$data_cate_lists['lists_id'] = $article_id;
					$data_cate_lists['rank'] = 999;
					$this->model_cate_lists->add($data_cate_lists);
				}
				header('Content-type: application/json');
				$data['result'] = 0;
				$data['article_id'] = $article_id;
				$data['redirect'] = '/article';
				echo json_encode($data);
				exit;
			}else{
				header('Content-type: application/json');
				$data['result'] = '添加联系方式失败';
				echo json_encode($data);
				exit;		
			}
		}else{
			$errors = validation_errors();
			header('Content-type: application/json');
			$data['result'] = $errors;
			echo json_encode($data);
			exit;		
		}		
	}
	
	public function update_article_contact($article_id=''){
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			header('Content-type: application/json');
			$data['result'] = '请先登录';
			$data['redirect'] = '/auth/login';
			echo json_encode($data);
			exit;
		}		
		$article = $this->model_article->get_row(array('id' => $article_id, 'user_id' => $logged_user_id, 'type' => 'contact'));
		if ( ! $article) {
			header('Content-type: application/json');
			$data['result'] = '找不到联系方式';
			$data['redirect'] = '/article';
			echo json_encode($data);
			exit;			
		}		

		$this->load->library('form_validation');
		$this->load->helper('form');
		$this->form_validation->set_error_delimiters('', '');
		$this->form_validation->set_rules('cate_id', '栏目', 'trim');
		$this->form_validation->set_rules('title', '标题', 'trim|required|max_length[255]|htmlspecialchars');
		$this->form_validation->set_rules('image', '图片', 'trim');
		$data = array();
		if ($this->form_validation->run()) {		
			$data_set = array();
			$data_set['cate_id'] = $this->input->post('cate_id');
			$data_set['title'] = $this->input->post('title');
			$data_set['image'] = $this->input->post('image');
			$data_set['is_image_sic'] = $this->input->post('is_image_sic');
			$data_set['content'] = $this->input->post('address');
			
			if($this->model_article->update(array('id'=>$article_id), $data_set)){
				$cate_id = $data_set['cate_id'];
				if ($article['cate_id'] != $cate_id) {
					if ($cate_id) {
						$this->model_cate->count_step($cate_id, 'count_article', 1);
						$data_cate_lists['user_id'] = $logged_user_id;
						$data_cate_lists['cate_id'] = $cate_id;
						$data_cate_lists['type'] = 'article';
						$data_cate_lists['lists_id'] = $article['id'];
						$data_cate_lists['rank'] = 9999;
						$this->model_cate_lists->add($data_cate_lists);
					}
					if ($article['cate_id']) {
						$this->model_cate->count_step($article['cate_id'], 'count_article', -1);
						$del_data_cate_lists['user_id'] = $logged_user_id;
						$del_data_cate_lists['cate_id'] = $article['cate_id'];
						$del_data_cate_lists['type'] = 'article';
						$del_data_cate_lists['lists_id'] = $article['id'];
						$this->model_cate_lists->delete($del_data_cate_lists);
					}
				}
				header('Content-type: application/json');
				$data['result'] = 0;
				$data['article_id'] = $article_id;
				$data['redirect'] = '/article';
				echo json_encode($data);
				exit;
			}else{
				header('Content-type: application/json');
				$data['result'] = '更新联系方式失败';
				echo json_encode($data);
				exit;				
			}			
		}else{
			$errors = validation_errors();
			header('Content-type: application/json');
			$data['result'] = $errors;
			echo json_encode($data);
			exit;		
		}
	}
}