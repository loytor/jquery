<?php
class Vote extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->wid = User::$user_id;
        $this->load->model('model_vote_paper');
        $this->load->model('model_cate');
        $this->load->model('model_cate_lists');

        /*header('Content-type: text/html; charset=utf-8');
         var_dump($option_array);exit;*/
    }

    /**
     * 问卷列表
     */
    public function index()
    {
        $type = $this->input->get('type');
        if( $type==1 ){
            $where['paper_type'] = 1;
        }else{
            $where['paper_type'] = 0;
        }
        $tpl_data['paper_type'] = $where['paper_type'];
        $where['wid'] = $this->wid;
        $where['is_delete'] = 0;

        $this->load->library('pagination');
        $pagination_config = array(
            'base_url'      => '/vote/index/',
            'total_rows'    => $this->model_vote_paper->total_rows($where),
            'per_page'      => 8,
            'uri_segment'   => 3,
        );
        $this->pagination->initialize($pagination_config);
        $tpl_data['pagination'] = $this->pagination->create_links();
        $per_page = $pagination_config['per_page'];


        //获取模版
        $this->load->config('tpl');
        $config_tpl = $this->config->item('vote_tpl');
        $tplType = $this->config->item('vote_type');


        $domain = $this->session->userdata('domain');//生成 外链
        $list = $this->model_vote_paper->get_all($where,$per_page, intval($this->uri->segment($pagination_config['uri_segment'], 1)), 'id', 'desc', 'id,title,start_time,end_time,add_time,paper_type,template,totals,is_release,is_edit');
        foreach( $list as $key=>$value ){
            $list[$key]['start_time'] = $value['start_time'] ? date('Y-m-d H:i',$value['start_time']) : '';
            $list[$key]['end_time'] = $value['end_time'] ? date('Y-m-d H:i',$value['end_time']) : '';
            $list[$key]['preview_url'] = '';
            if( $domain ){
                $list[$key]['preview_url'] = 'http://'.$domain.'.bama555.com/vote?id='.$value['id'].'&view=true';
                $list[$key]['sure_url'] = 'http://'.$domain.'.bama555.com/vote?id='.$value['id'];
            }
            if( $value['paper_type'] ){
                $list[$key]['paper_type'] = '答题模式';
                $list[$key]['template'] = $config_tpl['exam'][$value['template']]['title'];
            }else{
                $list[$key]['paper_type'] = '调查模式';
                $list[$key]['template'] = $config_tpl['survey'][$value['template']]['title'];
            }
        }

        $tpl_data['list'] = $list;
        $tpl_data['cur_nav'] = 'marketing';
        $tpl_data['curtitle'] = '问卷列表';
        $this->twig->display('vote/index', $tpl_data);
    }


    public function edit_collection($id='')
    {
        $id = trim($id);
        //查询基本信息
        $info = $this->model_vote_paper->get_row(array(
            'id' => $id,
            'is_delete'=>0
        ),'id,title,is_collect_data,collection_data_rule,paper_type');
        if( $info ){
            $tpl_data['vote'] = $info;
            $tpl_data['paper_type'] = $info['paper_type'];
        }else{
            $this->show_message(FALSE, '操作失败', '',1);
        }

        if( !empty($_POST['dosubmit']) ){
            $id = trim($this->input->post('id'));
            $is_collect_data = intval($this->input->post('is_collect_data'));
            $collection_data_rule = trim($this->input->post('collection_data_rule'));
            /*if( !$$is_coll_data ){
             $collection_data_rule = '';
             }*/
            /**
             * 模拟数据
             */
            /*$collection[] = array(
             'field_id'    => 'gender',
             'field_name'  => '性别',
             'field_type'  => 0,
             'bixu'        => 0,
             'text'        => ''
             );
             $collection[] = array(
             'field_id'    => 'age',
             'field_name'  => '年龄',
             'field_type'  => 0,
             'bixu'        => 0,
             'text'        => ''
             );
             $collection[] = array(
             'field_id'    => 'blood',
             'field_name'  => '血型',
             'field_type'  => 0,
             'bixu'        => 0,
             'text'        => ''
             );
             $collection[] = array(
             'field_id'    => 'custom1',
             'field_name'  => '自定义1',
             'field_type'  => 1,//数字类型
             'bixu'        => 0,
             'text'        => ''
             );
             $collection[] = array(
             'field_id'    => 'custom4',
             'field_name'  => '自定义字符串',
             'field_type'  => 2,//数字类型
             'bixu'        => 0,
             'text'        => ''
             );
             $collection[] = array(
             'field_id'    => 'custom7',
             'field_name'  => '自定义日期',
             'field_type'  => 3,//日期
             'bixu'        => 0,
             'text'        => ''
             );
             $collection[] = array(
             'field_id'    => 'custom10',
             'field_name'  => '自定义单选',
             'field_type'  => 4,//日期
             'bixu'        => 0,
             'text'        => '80后##90后##10后##11后'
             );
             $collection[] = array(
             'field_id'    => 'custom13',
             'field_name'  => '自定义多选',
             'field_type'  => 5,//多选
             'bixu'        => 0,
             'text'        => '10-20岁##20-40岁##40-60岁##60岁以上'
             );
             $collection_data_rule = json_encode($collection);
             echo $collection_data_rule;exit;*/

            $result = $this->model_vote_paper->update(array('id'=>$id,'is_delete'=>0),array(
                'is_collect_data' => $is_collect_data,
                'collection_data_rule' => $collection_data_rule
            ));
            if( false !== $result ){
                $this->show_message(TRUE, '收集信息规则修改成功', '/vote/index');
            }else{
                $this->show_message(FALSE, '保存失败', '/vote/index');
            }
        }

        $tpl_data['cur_nav'] = 'marketing';
        $tpl_data['curtitle'] = '收集扩展信息规则';
        $this->twig->display('vote/edit_collection', $tpl_data);
    }

    public function add_paper()
    {
        $type = $this->input->get('type');
        if( $type==1 ){
            $paper_type = 1;
            $tpl_data['curtitle'] = '添加答题闯关';
        }else{
            $paper_type = 0;
            $tpl_data['curtitle'] = '添加问卷调查';
        }
        $tpl_data['paper_type'] = $paper_type;

        //获取所有栏目 归档
        $cate_arr = array();
        $_cate_arr = $this->model_cate->get_all(array('user_id' => User::$user_id));
        foreach ($_cate_arr as $_cate) {
            $cate_arr[$_cate['id']] = $_cate;
        }
        $tpl_data['cate_arr'] = $cate_arr;

        if( !empty($_POST['dosubmit']) ){

            $collection_rule = $this->input->post('collection_rule');

            //问题标题
            $save_data['title'] = trim($this->input->post('title'));
            !$save_data['title'] && $this->show_message(FALSE, '问卷标题必须填写', '/vote/add_paper?type='.$paper_type);

            if( (MB_ENABLED === TRUE)?(mb_strlen($save_data['title'])>50 ):(strlen($save_data['title'])>50 ) ){
                $this->show_message(FALSE, '问卷标题最多50个字', '/vote/add_paper?type='.$paper_type);
            }


            $cate_id = $this->input->post('cate_id');
            if ($cate_id AND ! isset($cate_arr[$cate_id])) {
                $this->show_message(FALSE, '栏目不存在', '/vote/add_paper?type='.$paper_type);
            }
            $save_data['cate_id'] = $cate_id;
            //可投票的用户
            $save_data['competence'] = intval($this->input->post('competence'));
            if( !($save_data['competence']==0||$save_data['competence']==1||$save_data['competence']==4) ){
                $this->show_message(FALSE, '请重新选择可以投票的用户', '/vote/add_paper?type='.$paper_type);
            }

            //奖励
            $save_data['reward_type'] = intval($this->input->post('reward_type'));
            if( $save_data['reward_type']<0||$save_data['reward_type']>3 ){
                $this->show_message(FALSE, '请重新选择奖励', '/vote/add_paper?type='.$paper_type);
            }
            if( $save_data['competence']==0&&$save_data['reward_type']!=0 ){
                $this->show_message(FALSE, '匿名用户不能有奖励', '/vote/add_paper?type='.$paper_type);
            }
            if( $save_data['competence']==1&&$save_data['reward_type']!=0 ){
                $this->show_message(FALSE, '关注用户不能有奖励', '/vote/add_paper?type='.$paper_type);
            }
            if( $save_data['reward_type']==1 ){
                $save_data['reward_sorce'] = intval($this->input->post('reward_sorce'));
                !$save_data['reward_sorce'] && $this->show_message(FALSE, '请输入奖励积分', '/vote/add_paper?type='.$paper_type);
            }elseif( $save_data['reward_type']==2 ){
                $save_data['reward_ticket_id'] = intval($this->input->post('reward_ticket_id'));
            }

            //开始时间和结束时间
            $start_time = trim($this->input->post('start_time'));
            $end_time = trim($this->input->post('end_time'));
            $save_data['start_time'] = $start_time ? strtotime($start_time) : time();
            $save_data['end_time']   = $end_time   ? strtotime($end_time) : 0;
            if( $save_data['end_time'] ){
                if( ($save_data['end_time']-$save_data['start_time'])<=0 ){
                    $this->show_message(FALSE, '开始时间必须小于结束时间', '/vote/add_paper?type='.$paper_type);
                }
            }

            //问卷说明
            $save_data['content'] = htmlspecialchars(trim($this->input->post('content')));
            //开始投票的说明
            $save_data['start_content'] = htmlspecialchars(trim($this->input->post('start_content')));

            //问卷类型
            $save_data['paper_type'] = intval($this->input->post('paper_type'));

            //问卷模版
            $save_data['template'] = htmlspecialchars(trim($this->input->post('template')));

            //结束投票的说明
            $end_content = $this->input->post('end_content');
            if( $save_data['paper_type']==0 ){
                $content = htmlspecialchars(trim($end_content[0]));
                /*$temp_id = uniqid().sprintf("%03s", mt_rand(0, 100));
                 $data = array($temp_id=>array('content'=>$content));*/
                $data = array(array('content'=>$content));
                $save_data['end_content'] = json_encode($data);
            }else if( $save_data['paper_type']==1 ){
                //过滤空值
                $data = array();
                asort($end_content[1]['sort']);
                foreach( $end_content[1]['sort'] as $key=>$value ){
                    if( $end_content[1]['content'][$key] ){
                        //$temp_id = uniqid().sprintf("%03s", mt_rand(0, 100));
                        $data[] = array(
                            'sort' => $end_content[1]['sort'][$key],
                            'ms'   => intval($end_content[1]['ms'][$key]),
                            'me'   => intval($end_content[1]['me'][$key]),
                            'content' => htmlspecialchars($end_content[1]['content'][$key]),
                        );
                    }
                }
                if( count($data)>1 ){
                    foreach( $data as $val ){
                        if( ($val['ms']<0)||(!$val['me'])||($val['ms']-$val['me']>=0) ){
                            $this->show_message(FALSE, '多个问卷结束说明时，请添加积分区间', '/vote/edit_paper/'.$id);
                        }
                    }
                }else if( count($data)==1 ){
                    $data[0]['ms'] = $data[0]['me'] = '';
                }
                array_multisort($data);
                $save_data['end_content'] = json_encode($data);
            }

            //回答后是否可查看
            $save_data['show_result'] = intval($this->input->post('show_result'));
            $save_data['show_result_type'] = intval($this->input->post('show_result_type'));
            if( $save_data['show_result']==0 ){
                $save_data['show_result_type'] = 0;
            }

            //发布设置
            $save_data['is_release'] = intval($this->input->post('is_release'));
            $save_data['is_release'] &&  $save_data['is_edit'] = 1;

            //处理规则
            $rule = $this->input->post('rule');
            $rules = $this->input->post('rules');
            $rules[$rule]['type'] = $rule;
            $save_data['rule'] = serialize($rules[$rule]);

            $save_data['cate_id'] = $cate_id;
            $save_data['wid'] = $this->wid;
            $save_data['add_time'] = time();

            $id = $this->model_vote_paper->add($save_data,true);
            if( !$id ){
                $this->show_message(FALSE, '添加问卷失败', '/vote/add_paper?type='.$paper_type);
            }else{
                //栏目表cate_lists增加记录
                if ($cate_id) {
                    $data_cate_lists['user_id'] = $this->wid;
                    $data_cate_lists['cate_id'] = $cate_id;
                    $data_cate_lists['type'] = 'vote';
                    $data_cate_lists['lists_id'] = $id;
                    $data_cate_lists['rank'] = 9999;
                    $this->model_cate_lists->add($data_cate_lists);
                }
                $this->show_message(TRUE, '添加问卷成功', '/vote/add_question/'.$id);
            }
        }


        $sel_reward[0] = '无奖励';//奖励选项判断
        $sel_reward[1] = '奖励积分';

        //获取抵物券
        $tpl_data['ticket_flag'] = 0;
        /*$this->load->model('model_member_ticket');
         $tickets = $this->model_member_ticket->get_all(array('wid'=>$this->wid),'','','id','desc','id,title');
         if( $tickets ){
         $tpl_data['ticket_flag'] = 1;
         $sel_reward[2] = '奖励抵物券';
         }*/
        $tpl_data['tickets'] = $tickets = '';

        //获取模版
        $this->load->config('tpl');
        $config_tpl = $this->config->item('vote_tpl');
        $tplArr = json_encode($config_tpl);
        $tplType = $this->config->item('vote_type');
        $tpl_data['tpl'] = $tplArr;
        if( $paper_type==0 ){
            $tpl_data['tpls'] = $config_tpl['survey'];
        }else if( $paper_type==1 ){
            $tpl_data['tpls'] = $config_tpl['exam'];
        }

        $tpl_data['sel_reward'] = $sel_reward;
        $tpl_data['cur_nav'] = 'marketing';

        $this->load->library('encrypt');
        $token_data = array('user_id' => $this->wid, 'time' => time());
        $tpl_data['token'] = $this->encrypt->encode(serialize($token_data));

        if( $paper_type==1 ){
            $this->twig->display('vote/add_paper_1', $tpl_data);
        }else{
            $this->twig->display('vote/add_paper', $tpl_data);
        }
    }

    public function edit_paper($id='')
    {
        $id = trim($id);
        //查询基本信息
        $info = $this->model_vote_paper->get_row(array(
            'id' => $id,
            'is_delete'=>0
        ));
        if( $info ){
            $info['start_time'] = $info['start_time'] ? date('Y-m-d H:i',$info['start_time']) : '';
            $info['end_time'] = $info['end_time'] ? date('Y-m-d H:i',$info['end_time']) : '';
            if( $info['rule'] ) $info['rule'] = unserialize($info['rule']);//投票规则
            $info['end_content'] = json_decode($info['end_content'],true);
            $tpl_data['vote'] = $info;
            $tpl_data['is_edit'] = 1;
            if( $info['is_edit'] ) $tpl_data['is_edit'] = 0;

            if( $info['paper_type']==1 ){
                $paper_type = 1;
                $tpl_data['curtitle'] = '添加答题闯关';
            }else{
                $paper_type = 0;
                $tpl_data['curtitle'] = '添加问卷调查';
            }
            $tpl_data['paper_type'] = $paper_type;

        }else{
            $this->show_message(FALSE, '操作失败', '/vote/index?type='.$paper_type);
        }

        //获取所有栏目 归档
        $cate_arr = array();
        $_cate_arr = $this->model_cate->get_all(array('user_id' => User::$user_id));
        foreach ($_cate_arr as $_cate) {
            $cate_arr[$_cate['id']] = $_cate;
        }
        $tpl_data['cate_arr'] = $cate_arr;

        if( !empty($_POST['dosubmit']) ){
            $id = trim($this->input->post('id'));
            //问题标题
            $save_data['title'] = trim($this->input->post('title'));
            !$save_data['title'] && $this->show_message(FALSE, '问题标题必须填写', '/vote/edit_paper/'.$id);
            if( (MB_ENABLED === TRUE)?(mb_strlen($save_data['title'])>50 ):(strlen($save_data['title'])>50 ) ){
                $this->show_message(FALSE, '问卷标题最多50个字', '/vote/add_paper?type='.$paper_type);
            }

            $cate_id = $this->input->post('cate_id');
            if ($cate_id AND ! isset($cate_arr[$cate_id])) {
                $this->show_message(FALSE, '栏目不存在', '/vote/edit_paper/'.$id);
            }
            $save_data['cate_id'] = $cate_id;
            //可投票的用户
            $save_data['competence'] = intval($this->input->post('competence'));
            if( !($save_data['competence']==0||$save_data['competence']==1||$save_data['competence']==4) ){
                $this->show_message(FALSE, '请重新选择可以投票的用户', '/vote/edit_paper/'.$id);
            }

            //奖励
            $save_data['reward_type'] = intval($this->input->post('reward_type'));
            if( $save_data['reward_type']<0||$save_data['reward_type']>3 ){
                $this->show_message(FALSE, '请重新选择奖励', '/vote/edit_paper/'.$id);
            }
            if( $save_data['competence']==0&&$save_data['reward_type']!=0 ){
                $this->show_message(FALSE, '匿名用户不能有奖励', '/vote/edit_paper/'.$id);
            }
            if( $save_data['competence']==1&&$save_data['reward_type']!=0 ){
                $this->show_message(FALSE, '关注用户不能有奖励', '/vote/edit_paper/'.$id);
            }
            if( $save_data['reward_type']==1 ){
                $save_data['reward_sorce'] = intval($this->input->post('reward_sorce'));
                !$save_data['reward_sorce'] && $this->show_message(FALSE, '请输入奖励积分', '/vote/edit_paper/'.$id);
            }elseif( $save_data['reward_type']==2 ){
                $save_data['reward_ticket_id'] = intval($this->input->post('reward_ticket_id'));
            }

            //开始时间和结束时间
            $start_time = trim($this->input->post('start_time'));
            $end_time = trim($this->input->post('end_time'));
            $save_data['start_time'] = $start_time ? strtotime($start_time) : time();
            $save_data['end_time']   = $end_time   ? strtotime($end_time) : 0;
            if( $save_data['end_time'] ){
                if( ($save_data['end_time']-$save_data['start_time'])<=0 ){
                    $this->show_message(FALSE, '开始时间必须小于结束时间', '/vote/edit_paper/'.$id);
                }
            }
            //问卷说明
            $save_data['content'] = htmlspecialchars(trim($this->input->post('content')));
            //开始投票的说明
            $save_data['start_content'] = htmlspecialchars(trim($this->input->post('start_content')));

            //问卷类型
            $save_data['paper_type'] = intval($this->input->post('paper_type'));
            if( $info['is_edit'] ){//不可修改时
                $save_data['paper_type'] = $info['paper_type'];
            }

            //结束投票的说明
            $end_content = $this->input->post('end_content');
            $save_data['end_content'] = '';
            if( $save_data['paper_type']==0 ){
                $content = htmlspecialchars(trim($end_content[0]));
                /*$temp_id = uniqid().sprintf("%03s", mt_rand(0, 100));
                 $data = array($temp_id=>array('content'=>$content));*/
                $data = array(array('content'=>$content));
                $save_data['end_content'] = json_encode($data);
            }else if( $save_data['paper_type']==1 ){
                //过滤空值
                //积分区间不写的只能有一个值
                $data = array();
                asort($end_content[1]['sort']);
                foreach( $end_content[1]['sort'] as $key=>$value ){
                    if( $end_content[1]['content'][$key] ){
                        //$temp_id = uniqid().sprintf("%03s", mt_rand(0, 100));
                        $data[] = array(
                            'sort' => $end_content[1]['sort'][$key],
                            'ms'   => intval($end_content[1]['ms'][$key]),
                            'me'   => intval($end_content[1]['me'][$key]),
                            'content' => htmlspecialchars($end_content[1]['content'][$key]),
                        );
                    }
                }
                if( count($data)>1 ){
                    foreach( $data as $val ){
                        if( ($val['ms']<0)||(!$val['me'])||($val['ms']-$val['me']>=0) ){
                            $this->show_message(FALSE, '多个问卷结束说明时，请添加积分区间', '/vote/edit_paper/'.$id);
                        }
                    }
                }else if( count($data)==1 ){
                    $data[0]['ms'] = $data[0]['me'] = '';
                }
                array_multisort($data);
                $save_data['end_content'] = json_encode($data);
            }
            //问卷模版
            $save_data['template'] = htmlspecialchars(trim($this->input->post('template')));
            //回答后是否可查看
            $save_data['show_result'] = intval($this->input->post('show_result'));
            $save_data['show_result_type'] = intval($this->input->post('show_result_type'));
            if( $save_data['show_result']==0 ){
                $save_data['show_result_type'] = 0;
            }

            //发布设置
            $save_data['is_release'] = intval($this->input->post('is_release'));
            $save_data['is_release'] && $save_data['is_edit'] = 1;

            //处理规则
            $rule = $this->input->post('rule');
            $rules = $this->input->post('rules');
            $rules[$rule]['type'] = $rule;
            $save_data['rule'] = serialize($rules[$rule]);

            $save_data['wid'] = $this->wid;
            $save_data['add_time'] = time();
            $result = $this->model_vote_paper->update(array('id'=>$id,'is_delete'=>0),$save_data);
            if( false !== $result ){

                //更改cate_lists表的记录
                if ($info['cate_id'] != $cate_id) {
                    if ($cate_id) {
                        $data_cate_lists['user_id'] = $this->wid;
                        $data_cate_lists['cate_id'] = $cate_id;
                        $data_cate_lists['type'] = 'vote';
                        $data_cate_lists['lists_id'] = $id;
                        $data_cate_lists['rank'] = 9999;
                        $this->model_cate_lists->add($data_cate_lists);
                    }
                    if ($info['cate_id']) {
                        $del_data_cate_lists['user_id'] = $this->wid;
                        $del_data_cate_lists['cate_id'] = $info['cate_id'];
                        $del_data_cate_lists['type'] = 'vote';
                        $del_data_cate_lists['lists_id'] = $id;
                        $this->model_cate_lists->delete($del_data_cate_lists);
                    }
                }

                $this->show_message(TRUE, '修改问卷成功', '/vote/index?type='.$paper_type);
            }else{
                $this->show_message(FALSE, '修改问卷失败', '/vote/edit_paper/'.$id);
            }
        }

        $sel_reward[0] = '无奖励';//奖励选项判断
        /*//查询有没会员卡权限
         $this->load->model('model_account');
         $this->load->model('model_user_authority');
         $user_authority = $this->model_user_authority->get_row(array('user_id'=>User::$user_id));

         $authority = array();
         if($user_authority['authority'])
         {
         $this->config->load('authority');
         $confAuthority = (array)$this->config->item('authority');
         foreach($confAuthority as $key=>$ca){
         if($ca[2]==1 && $user_authority['authority'] & $ca[0]){
         $authority[$key] = $ca;
         }
         }
         }
         if( isset($authority['member_card'])&&$authority['member_card'] ){
         $sel_reward[1] = '奖励积分';
         }*/
        $sel_reward[1] = '奖励积分';

        //获取抵物券
        $tpl_data['ticket_flag'] = 0;
        /*$this->load->model('model_member_ticket');
         $tickets = $this->model_member_ticket->get_all(array('wid'=>$this->wid),'','','id','desc','id,title');
         if( $tickets ){
         $tpl_data['ticket_flag'] = 1;
         $sel_reward[2] = '奖励抵物券';
         }*/
        $tpl_data['tickets'] = $tickets = '';

        //获取模版
        $this->load->config('tpl');
        $config_tpl = $this->config->item('vote_tpl');
        $tplArr = json_encode($config_tpl);
        $tplType = $this->config->item('vote_type');
        $tpl_data['tpl'] = $tplArr;
        $tpl_data['tpls'] = $tpl_data['vote']['paper_type'] ? $config_tpl['exam'] : $config_tpl['survey'];

        $tpl_data['sel_reward'] = $sel_reward;
        $tpl_data['cur_nav'] = 'marketing';
        $tpl_data['curtitle'] = '修改问卷';

        $this->load->library('encrypt');
        $token_data = array('user_id' => $this->wid, 'time' => time());
        $tpl_data['token'] = $this->encrypt->encode(serialize($token_data));

        if( $paper_type==1 ){
            $this->twig->display('vote/edit_paper_1', $tpl_data);
        }else{
            $this->twig->display('vote/edit_paper', $tpl_data);
        }
    }

    //修改发布状态
    public function edit_release($id='')
    {
        $paper_id = intval($id);
        $info = $this->model_vote_paper->get_row(array('id' => $paper_id),'id,is_release,paper_type');
        if( $info ){
            if( $info['is_release'] ){
                $save_data['is_release'] = 0;
            }else{
                $save_data['is_release'] = 1;
                $save_data['is_edit'] = 1;
            }
            $result = $this->model_vote_paper->update(array('id'=>$paper_id,'is_delete'=>0),$save_data);
            if( false !== $result ){
                $this->show_message(TRUE, '发布状态修改成功', '/vote/index?type='.$info['paper_type']);
            }else{
                $this->show_message(FALSE, '发布状态修改失败', '/vote/index?type='.$info['paper_type']);
            }
        }else{
            $this->show_message(FALSE, '非法操作', '/vote/index');
        }

    }

    //删除问卷
    public function delete_paper($id='')
    {
        $id = trim($id);
        if( $id=='' ) $this->show_message(FALSE, '无效操作', '',1);

        $info = $this->model_vote_paper->get_row(array('id'=>$id,'is_delete'=>0),'id,cate_id,paper_type');
        if( $info ){
            $this->load->model('model_vote_question');
            $this->load->model('model_vote_option');
            $questions = $this->model_vote_question->get_all(array('paper_id'=>$id,'is_delete'=>0),'','','id','desc','id');
            if( $questions ){
                foreach( $questions as $val ){
                    if( false!==$this->model_vote_option->update(array('question_id'=>$val['id']),array('is_delete'=>1)) ){
                    }else{
                        $this->show_message(FALSE, '删除选项时发生错误', '/vote/index?type='.$info['paper_type']);
                    }
                }
                if( false!==$this->model_vote_question->update(array('paper_id'=>$id),array('is_delete'=>1))){
                }else{
                    $this->show_message(FALSE, '删除题目时发生错误', '/vote/index?type='.$info['paper_type']);
                }
            }
            if( $info['cate_id'] ){

                $del_data_cate_lists['user_id'] = $this->wid;
                $del_data_cate_lists['cate_id'] = $info['cate_id'];
                $del_data_cate_lists['type'] = 'vote';
                $del_data_cate_lists['lists_id'] = $id;
                $this->model_cate_lists->delete($del_data_cate_lists);
            }

            if( false===$this->model_vote_paper->update(array('id'=>$id),array('is_delete'=>1,'cate_id'=>'')) ){
                $this->show_message(FALSE, '删除问卷时发生错误', '/vote/index?type='.$info['paper_type']);
            }

            $this->show_message(TRUE, '删除成功', '/vote/index?type='.$info['paper_type']);

        }else{
            $this->show_message(FALSE, '无效操作', '',1);
        }
    }


    //问题列表
    public function question($id='')
    {
        $paper_id = intval($id);
        if( !$paper_id ) $this->show_message(FALSE, '操作失败', '/vote/index');
        //查询基本信息
        $info = $this->model_vote_paper->get_row(array(
            'id' => $paper_id,
            'is_delete'=>0
        ),'id,is_edit,paper_type');
        if( $info ){
            $tpl_data['is_edit'] = 1;
            if( $info['is_edit'] ) $tpl_data['is_edit'] = 0;

            if( $info['paper_type']==1 ){
                $paper_type = 1;
                $tpl_data['curtitle'] = '添加答题闯关';
            }else{
                $paper_type = 0;
                $tpl_data['curtitle'] = '添加问卷调查';
            }
            $tpl_data['paper_type'] = $paper_type;
        }else{
            $this->show_message(FALSE, '操作失败', '',1);
        }

        $this->load->model('model_vote_question');

        $this->load->library('pagination');
        $pagination_config = array(
            'base_url'      => '/vote/question/'.$paper_id,
            'total_rows'    => $this->model_vote_question->total_rows(array('paper_id'=>$paper_id)),
            'per_page'      => 8,
            'uri_segment'   => 4,//分页是url第四个
        );
        $this->pagination->initialize($pagination_config);
        $tpl_data['pagination'] = $this->pagination->create_links();
        $per_page = $pagination_config['per_page'];
        $now_page = intval($this->uri->segment($pagination_config['uri_segment'], 1));
        $tpl_data['per_page'] = $per_page;
        $tpl_data['now_page'] = $now_page;

        $list = $this->model_vote_question->get_all(array('paper_id'=>$paper_id,'is_delete'=>0),$per_page, intval($this->uri->segment($pagination_config['uri_segment'], 1)), 'sort', 'asc');

        $tpl_data['list'] = $list;
        $tpl_data['paper_id'] = $paper_id;
        $tpl_data['cur_nav'] = 'marketing';
        $tpl_data['curtitle'] = '问题列表';
        $this->twig->display('vote/question', $tpl_data);
    }
    //添加问题$id 问卷id
    public function add_question($id='')
    {
        $paper_id = intval($id);
        if( !$paper_id ) $this->show_message(FALSE, '操作失败', '',1);
        $paper = $this->model_vote_paper->get_row(array('id'=>$paper_id,'is_delete'=>0),'id,paper_type');
        $tpl_data['paper'] = $paper;
        $tpl_data['paper_type'] = $paper['paper_type'];

        $this->load->model('model_vote_question');
        if( !empty($_POST['dosubmit']) ){
            $save_data['paper_id'] = $paper_id;
            $save_data['question'] = htmlspecialchars(trim($this->input->post('question')));
            if( !$save_data['question'] ) $this->show_message(FALSE, '请填写问题题目文本内容', '/vote/add_question/'.$paper_id);
            $save_data['question_img'] = trim($this->input->post('question_img'));
            $save_data['question_mp3'] = trim($this->input->post('question_mp3'));
            $save_data['question_video'] = trim($this->input->post('question_video'));

            $save_data['type'] = intval($this->input->post('type'));
            $save_data['game_time'] = intval($this->input->post('game_time'));
            $save_data['sort'] = intval($this->input->post('sort'));

            //根据题目类型   编辑选项数组
            $option_array = array();//选项
            if( $save_data['type']==0 ){//单选
                //radio数组
                $radio          = $this->input->post('radio');
                $ture_option_id = $this->input->post('ture_option_id');
                //是否选择其他
                $option_type = $this->input->post('option_type') ? $this->input->post('option_type') : 0;

                //过滤有效值
                foreach( $radio as $key=>$value ){
                    if($value['content']){
                        krsort($value);//将排序值字段放到第一位
                        if( $ture_option_id==$key ){
                            $value['true_value'] = 1;
                        }else{
                            $value['true_value'] = 0;
                        }
                        $value['other'] = 0;
                        $option_array[] = $value;
                    }
                }
                if( $option_type ){
                    $option_array[] = array(
                        'sort'       => 0,
                        'mark'       => 0,
                        'content'    => '',
                        'true_value' => 0,
                        'other'      => 1
                    );
                }
                array_multisort($option_array);//sort值从小到大排序
                if(count($option_array)>35){
                    $this->show_message(FALSE, '最多35个选项', '',1);
                }
            }else if( $save_data['type']==1 ){//多选题
                //checkbox数组
                $checkbox       = $this->input->post('checkbox');
                $option_type = $this->input->post('option_type') ? $this->input->post('option_type') : 0;//是否选择其他

                //过滤有效值
                foreach( $checkbox as $key=>$value ){
                    if($value['content']){
                        krsort($value);//将排序值字段放到第一位
                        $value['true_value'] = 0;
                        $value['other'] = 0;
                        $option_array[] = $value;
                    }
                }
                if( $option_type ){
                    $option_array[] = array(
                        'sort'       => 0,
                        'mark'       => 0,
                        'content'    => '',
                        'true_value' => 0,
                        'other'      => 1
                    );
                }
                array_multisort($option_array);//sort值从小到大排序
                
                if(count($option_array)>35){
                    $this->show_message(FALSE, '最多35个选项', '',1);
                }
                
                $multi_limit = intval($this->input->post('multi_limit'));
                if( count($option_array)<$multi_limit ){
                    $this->show_message(FALSE, '请正确设置您的答题限制数', '/vote/add_question/'.$paper_id);
                }
                $save_data['multi_limit'] = intval($multi_limit);
            }

            //保存问题
            $question_id = $this->model_vote_question->add($save_data,true);
            if( !$question_id ){
                $this->show_message(FALSE, '添加问题失败', '/vote/add_question/'.$paper_id);
            }else{
                if( $option_array ){
                    $this->load->model('model_vote_option');
                    $other_id = false;
                    $sort = 0;//记录最大sort值
                    $true_id = 0;//记录正确答案id
                    foreach( $option_array as $key=>$value ){
                        $sort = $sort<$value['sort'] ? $value['sort'] : $sort;
                        if( $value['other'] ){
                            $other_id = $key;
                            continue;
                        }
                        $option_value['question_id']  = $question_id;
                        $option_value['content']      = htmlspecialchars($value['content']);
                        $option_value['content_img']  = $value['content_img'];
                        $option_value['content_mp3']  = $value['content_mp3'];
                        $option_value['content_video']= $value['content_video'];
                        $option_value['sort']         = $value['sort'];
                        $option_value['mark']         = isset($value['mark']) ? $value['mark'] : null;
                        $option_value['type']         = 0;

                        if( $option_id=$this->model_vote_option->add($option_value,true) ){
                            if( $value['true_value'] ){
                                $true_id = $option_id;
                            }
                        }else{
                            $this->show_message(FALSE, '选项保存失败', '', 1);
                        }
                    }
                    if( false!==$other_id ){ //保存其他选项
                        $option_value['question_id']   = $question_id;
                        $option_value['content']       = '';
                        $option_value['content_img']   = '';
                        $option_value['content_mp3']   = '';
                        $option_value['content_video'] = '';
                        $option_value['sort']          = $sort+1;
                        $option_value['mark']          = null;
                        $option_value['type']          = 1;
                        if( !$option_id=$this->model_vote_option->add($option_value,true) ){
                            $this->show_message(FALSE, '选项保存失败', '', 1);
                        }
                    }
                    if( $true_id ){//有正确值时 保存回问题表中
                        $result = $this->model_vote_question->update(array('id'=>$question_id,'is_delete'=>0),array('ture_option_id'=>$true_id));
                        if( false === $result ){
                            $this->show_message(FALSE, '修改问题失败', '', 1);
                        }
                    }
                }
                $this->show_message(TRUE, '添加问题成功', '/vote/question/'.$paper_id);
            }
        }

        $tpl_data['paper_id'] = $paper_id;
        $tpl_data['cur_nav'] = 'marketing';
        $tpl_data['curtitle'] = '添加问题';
        $this->load->library('encrypt');
        $token_data = array('user_id' => $this->wid, 'time' => time());
        $tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
        $this->twig->display('vote/add_question', $tpl_data);
    }

    //修改问题$id 问题id
    public function edit_question($id='')
    {
        $question_id = intval($id);
        if( !$question_id ) $this->show_message(FALSE, '操作失败', '', 1);
        $tpl_data['question_id'] = $question_id;
        //问题
        $this->load->model('model_vote_question');
        $this->load->model('model_vote_option');
        $tpl_data['question'] = $this->model_vote_question->get_row(array('id'=>$question_id,'is_delete'=>0));
        if( !$tpl_data['question'] ){
            $this->show_message(FALSE, '非法操作', '', 1);
        }
        $tpl_data['question']['question_video'] = htmlspecialchars($tpl_data['question']['question_video']);

        $save_data['question_img'] = trim($this->input->post('question_img'));
        $save_data['question_mp3'] = trim($this->input->post('question_mp3'));
        $save_data['question_video'] = trim($this->input->post('question_video'));
        $paper_id = $tpl_data['question']['paper_id'];
        if( !$paper_id ) $this->show_message(FALSE, '操作失败', '',1);
        //查询基本信息
        $info = $this->model_vote_paper->get_row(array(
            'id' => $paper_id
        ),'id,is_edit,paper_type');
        if( $info ){
            $tpl_data['info'] = $info;
            $tpl_data['is_edit'] = 1;
            if( $info['is_edit'] ) $tpl_data['is_edit'] = 0;
            $tpl_data['paper_type'] = $info['paper_type'];
        }else{
            $this->show_message(FALSE, '操作失败', '',1);
        }

        //选项
        $option = $this->model_vote_option->get_all(array('question_id'=>$question_id,'is_delete'=>0),'','','sort','asc');
        $tpl_data['option'] = '';
        $tpl_data['option_type']= $tpl_data['question']['type'];//问题类型
        $tpl_data['option_num'] = 0;//选项除其它的数目
        $last_option_id = array();
        if( $option ){
            $abc = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N'
                         ,'O','P','Q','R','S','T','U','V','W','X','Y','Z','A1','B1','C1','D1','E1','F1','G1','H1','I1');
            foreach( $option as $key=>$value ){
                $last_option_id[$value['id']] = $value['id'];
                if( $value['type']!=2 ){
                    $tpl_data['option_num']++;
                }
                $value['content_video'] = htmlspecialchars($value['content_video']);
                if( isset($abc[$key])&&$abc[$key] ){
                    $tpl_data['option'][$abc[$key]] = $value;
                }else{
                    break;
                }
            }
        }

        if( !empty($_POST['dosubmit']) ){
            $save_data['question'] = htmlspecialchars(trim($this->input->post('question')));
            if( !$save_data['question'] ) $this->show_message(FALSE, '请填写问题题目', '' ,1);

            $save_data['type'] = intval($this->input->post('type'));
            if( $info['is_edit'] ){
                $save_data['type'] = $tpl_data['question']['type'];
            }
            $save_data['game_time'] = intval($this->input->post('game_time'));
            $save_data['sort'] = intval($this->input->post('sort'));

            $result = $this->model_vote_question->update(array('id'=>$question_id),$save_data);
            if( false !== $result ){

                //判断问题类型是否发生改变，若改变则先删除原来的选项
                if( $save_data['type']!=$tpl_data['question']['type'] ){
                    $this->model_vote_option->delete(array('question_id'=>$question_id));
                }

                //根据题目类型   编辑选项数组
                $option_array = array();//新增选项
                $option_edit = array();//编辑的选项
                $option_ed3 = array();
                $this->other_option = 0;
                if( $save_data['type']==0 ){//单选
                    //radio数组
                    $radio          = $this->input->post('radio');
                    $ture_option_id = $this->input->post('ture_option_id');

                    //是否选择其他
                    $option_type = $this->input->post('option_type') ? $this->input->post('option_type') : 0;
                    $option_type1= $this->input->post('option_type1') ? $this->input->post('option_type1') : 0;
                    $option_type && $this->other_option=1;
                    $ids = array();
                    //过滤有效值
                    foreach( $radio as $key=>$value ){
                        //是否发布过
                        if( $info['is_edit'] ){//曾发布过
                            krsort($value);//将排序值字段放到第一位
                            if( !isset($value['id']) ){
                                $this->show_message(FALSE, '无效操作', '',1);
                            }
                            if( $ture_option_id==$key ){
                                $value['true_value'] = 1;
                            }else{
                                $value['true_value'] = 0;
                            }
                            $value['other'] = 0;
                            $option_edit[] = $value;
                            $option_ed3[] = $value;
                        }else{//新增或修改
                            if($value['content']){//过滤空值
                                krsort($value);//将排序值字段放到第一位
                                if( $ture_option_id==$key ){
                                    $value['true_value'] = 1;
                                }else{
                                    $value['true_value'] = 0;
                                }
                                $value['other'] = 0;
                                if( isset($value['id']) ){
                                    $option_edit[] = $value;
                                }else{
                                    $option_array[] = $value;
                                }
                                $option_ed3[] = $value;
                            }
                        }
                    }

                    //其他选项
                    if( $option_type ){
                        if( $option_type1 ){
                            $option_ed3[] = $option_array[] = array(
                                'sort'       => 0,
                                'id'         => $option_type1,
                                'mark'       => null,
                                'content'    => '',
                                'content_img'=> '',
                                'content_mp3'=> '',
                                'content_video'=> '',
                                'true_value' => 0,
                                'other'      => 1
                            );
                        }else{
                            $option_ed3[] = $option_array[] = array(
                                'sort'       => 0,
                                'mark'       => null,
                                'content'    => '',
                                'content_img'=> '',
                                'content_mp3'=> '',
                                'content_video'=> '',
                                'true_value' => 0,
                                'other'      => 1
                            );
                        }
                    }
                    //array_multisort($option_array);//sort值从小到大排序

                    //第三版修改
                    array_multisort($option_ed3);
                    if(count($option_ed3)>35){
                        $this->show_message(FALSE, '最多35个选项', '',1);
                    }
                    if( $save_data['type']==0 && ( $tpl_data['question']['multi_limit']!=0 ) ){
                        $this->model_vote_question->update(array('id'=>$question_id),array('multi_limit'=>0));
                    }
                }else if( $save_data['type']==1 ){//多选题
                    //checkbox数组
                    $checkbox       = $this->input->post('checkbox');
                    $option_type = $this->input->post('option_type') ? $this->input->post('option_type') : 0;//是否选择其他
                    $option_type1= $this->input->post('option_type1') ? $this->input->post('option_type1') : 0;
                    $option_type && $this->other_option=1;
                    //过滤有效值
                    foreach( $checkbox as $key=>$value ){
                        if($value['content']){
                            krsort($value);//将排序值字段放到第一位
                            $value['true_value'] = 0;
                            $value['other'] = 0;
                            if( isset($value['id']) ){
                                $option_edit[] = $value;
                            }else{
                                $option_array[] = $value;
                            }
                            $option_ed3[] = $value;
                        }
                    }


                    //其他选项
                    if( $option_type ){
                        if( $option_type1 ){
                            $option_ed3[] = $option_array[] = array(
                                'sort'       => 0,
                                'id'         => $option_type1,
                                'mark'       => null,
                                'content'    => '',
                                'content_img'=> '',
                                'content_mp3'=> '',
                                'content_video'=> '',
                                'true_value' => 0,
                                'other'      => 1
                            );
                        }else{
                            $option_ed3[] = $option_array[] = array(
                                'sort'       => 0,
                                'mark'       => null,
                                'content'    => '',
                                'content_img'=> '',
                                'content_mp3'=> '',
                                'content_video'=> '',
                                'true_value' => 0,
                                'other'      => 1
                            );
                        }
                    }
                    //array_multisort($option_array);//sort值从小到大排序
                    array_multisort($option_ed3);
                    if(count($option_ed3)>35){
                        $this->show_message(FALSE, '最多35个选项', '',1);
                    }
                    $multi_limit = intval($this->input->post('multi_limit'));
                    if( count($option_ed3)<$multi_limit ){
                        $this->show_message(FALSE, '请正确设置您的答题限制数', '',1);
                    }

                    if( $save_data['type']==1 && ( $tpl_data['question']['multi_limit']!=intval($multi_limit) ) ){
                        $this->model_vote_question->update(array('id'=>$question_id),array('multi_limit'=>intval($multi_limit)));
                    }
                }


                //第三版修改
                /**
                 * 没有选择其他选项的先删除原来的
                 */
                if( !$this->other_option ){
                    $this->model_vote_option->delete(array('question_id'=>$question_id,'type'=>1));
                }

                $sort = 0;
                $true_id = 0;
                $other_temp = array();
                if( $option_ed3 ){
                    foreach( $option_ed3 as $key=>$value ){
                        $sort = $sort<$value['sort'] ? $value['sort'] : $sort;
                        if( $value['other'] ){
                            $other_temp = $value;
                            continue;
                        }
                        $option_value['question_id']  = $question_id;
                        $option_value['content']      = $value['content'];
                        $option_value['content_img']  = $value['content_img'];
                        $option_value['content_mp3']  = $value['content_mp3'];
                        $option_value['content_video']= $value['content_video'];
                        $option_value['sort']         = $value['sort'];
                        $option_value['mark']         = isset($value['mark']) ? $value['mark'] : null;
                        $option_value['type']         = 0;
                        if( isset($value['id'])&&$value['id'] ){//修改选项
                            if( $value['true_value'] ) $true_id = $value['id'];
                            if( false===$this->model_vote_option->update( array('id'=>$value['id'],'question_id'=>$question_id,'is_delete'=>0),$option_value ) ){
                                $this->show_message(FALSE, '保存失败', '',1);
                            }
                            if( $last_option_id[$value['id']] ){
                                unset($last_option_id[$value['id']]);
                            }
                        }else{//添加选项
                            if( $option_id=$this->model_vote_option->add($option_value,true) ){
                                if( $value['true_value'] ){
                                    $true_id = $option_id;
                                }
                            }else{
                                $this->show_message(FALSE, '选项保存失败', '', 1);
                            }
                        }
                    }
                }

                if( $other_temp ){//保存其他选项
                    $option_value['question_id'] = $question_id;
                    $option_value['content']     = '';
                    $option_value['content_img']  = '';
                    $option_value['content_mp3']  = '';
                    $option_value['content_video']= '';
                    $option_value['sort']        = $sort+1;
                    $option_value['mark']        = null;
                    $option_value['type']        = 1;
                    if( isset($other_temp['id'])&&$other_temp['id'] ){
                        $this->model_vote_option->update( array('id'=>$other_temp['id'],'question_id'=>$question_id,'type'=>1,'is_delete'=>0),array('sort'=>$sort+1) );
                    }else{
                        if( !$option_id=$this->model_vote_option->add($option_value,true) ){
                            $this->show_message(FALSE, '选项保存失败', '', 1);
                        }
                    }
                }

                if( $true_id ){//有正确值时 保存回问题表中
                    $result = $this->model_vote_question->update(array('id'=>$question_id,'is_delete'=>0),array('ture_option_id'=>$true_id));
                    if( false === $result ){
                        $this->show_message(FALSE, '修改问题失败', '', 1);
                    }
                }

                //比对没有的选项要删掉
                if( $last_option_id ){
                    foreach ($last_option_id as $val){
                        $this->model_vote_option->delete(array('id'=>$val));
                    }
                }

                /*echo $sort;
                 header('Content-type: text/html; charset=utf-8');
                 var_dump($option_ed3);exit;*/

                /*$this->true_id = 0;//更新到试题表的正确id
                 //要修改的项
                 if( $option_edit ){
                 //修改id对应的选项
                 $sort = 0;//记录最大sort值
                 foreach( $option_edit as $key=>$value ){
                 $sort = $sort<$value['sort'] ? $value['sort'] : $sort;
                 $option_value['question_id']  = $question_id;
                 $option_value['content']      = htmlspecialchars($value['content']);
                 $option_value['content_img']  = $value['content_img'];
                 $option_value['content_mp3']  = $value['content_mp3'];
                 $option_value['content_video']= $value['content_video'];
                 $option_value['sort']         = $value['sort'];
                 $option_value['mark']         = isset($value['mark']) ? $value['mark'] : null;
                 $option_value['type']         = 0;
                 $value['true_value'] && $this->true_id = $value['id'];
                 if( false===$this->model_vote_option->update( array('id'=>$value['id'],'is_delete'=>0),$option_value ) ){
                 $this->show_message(FALSE, '保存失败', '',1);
                 }
                 if( $last_option_id[$value['id']] ){
                 unset($last_option_id[$value['id']]);
                 }
                 }
                 //比对没有的选项要删掉
                 if( $last_option_id ){
                 foreach ($last_option_id as $val){
                 $this->model_vote_option->delete(array('id'=>$val));
                 }
                 }
                 $this->model_vote_option->update( array('question_id'=>$question_id,'type'=>1,'is_delete'=>0),array('sort'=>$sort+1) );
                 }*/

                /*//新增选项
                 if( $option_array ){
                 $other_id = false;
                 $sort = 0;//记录最大sort值
                 $true_id = 0;//记录正确答案id
                 foreach( $option_array as $key=>$value ){
                 $sort = $sort<$value['sort'] ? $value['sort'] : $sort;
                 if( $value['other'] ){
                 $other_id = $key;
                 continue;
                 }
                 $option_value['question_id']  = $question_id;
                 $option_value['content']      = htmlspecialchars($value['content']);
                 $option_value['content_img']  = $value['content_img'];
                 $option_value['content_mp3']  = $value['content_mp3'];
                 $option_value['content_video']= $value['content_video'];
                 $option_value['sort']         = $value['sort'];
                 $option_value['mark']         = isset($value['mark']) ? $value['mark'] : null;
                 $option_value['type']         = 0;
                 if( $option_id=$this->model_vote_option->add($option_value,true) ){
                 if( $value['true_value'] ){
                 $this->true_id = $option_id;
                 }
                 }else{
                 $this->show_message(FALSE, '选项保存失败', '', 1);
                 }
                 }
                 if( false!==$other_id ){ //保存其他选项
                 $option_value['question_id'] = $question_id;
                 $option_value['content']     = '';
                 $option_value['content_img']  = '';
                 $option_value['content_mp3']  = '';
                 $option_value['content_video']= '';
                 $option_value['sort']        = $sort+1;
                 $option_value['mark']        = null;
                 $option_value['type']        = 1;
                 if( !$option_id=$this->model_vote_option->add($option_value,true) ){
                 $this->show_message(FALSE, '选项保存失败', '', 1);
                 }
                 }
                 }*/


                $this->show_message(TRUE, '修改问题成功', '/vote/question/'.$paper_id);
            }else{
                $this->show_message(FALSE, '修改问题失败', '/vote/question/'.$paper_id);
            }
        }


        $tpl_data['cur_nav'] = 'marketing';
        $tpl_data['curtitle'] = '修改问题';
        $this->load->library('encrypt');
        $token_data = array('user_id' => $this->wid, 'time' => time());
        $tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
        $this->twig->display('vote/edit_question', $tpl_data);
    }
    //删除问题
    public function delete_question($id='')
    {
        $id = trim($id);
        if( $id=='' ) $this->show_message(FALSE, '无效操作', '/vote');
        $this->load->model('model_vote_question');
        $this->load->model('model_vote_option');
        //删除选项
        if( false!==$this->model_vote_option->update(array('question_id'=>$id),array('is_delete'=>1)) ){
            //删除问题
            if( false!==$this->model_vote_question->update(array('id'=>$id),array('is_delete'=>1))){
                $this->show_message(TRUE, '删除成功', '', 1);
            }
        }
        $this->show_message(FALSE, '删除失败', '', 1);
    }

    //所有用户列表
    public function vote_all_user($id='')
    {
        if( isset($_GET['export']) ){
            $this->vote_all_user_export($id);
            exit;
        }
        $id = trim($id);
        $this->load->model('model_vote_user');
        $tpl_data['id'] = $id;
        $paper = $this->model_vote_paper->get_row(array('id'=>$id,'is_delete'=>0),'id,title,collection_data_rule,paper_type,totals');
        if( !$paper ){
            $this->show_message(FALSE, '非法操作', '/vote');
        }else{
            $tpl_data['paper_id'] = $paper['id'];
            $tpl_data['paper_title'] = $paper['title'];
            $tpl_data['paper_type'] = $paper['paper_type'];
            $tpl_data['paper'] = $paper;
        }

        $name        = $this->input->get_post('name');
        $mobile      = $this->input->get_post('mobile');
        $from_time   = $this->input->get_post('from_time');
        $to_time     = $this->input->get_post('to_time');
        $start_mark  = $this->input->get_post('start_mark');
        $end_mark    = $this->input->get_post('end_mark');

        $where = array(); $is_where = 0;
        ($search['mobile'] = $mobile) && $where['mobile'] = "like:".$mobile;
        ($search['name'] = $name) && $where['name'] = "like:".$name;
        ($search['from_time'] = $from_time) && $where['answer_time>='] = strtotime($from_time);
        ($search['to_time'] = $to_time) && $where['answer_time<='] = strtotime($to_time);
        ($search['start_mark'] = $start_mark) && $where['mark>='] = $start_mark;
        ($search['end_mark'] = $end_mark)  && $where['mark<='] = $end_mark;
        $search_route = '?1=1';
        if( $where ){
            $is_where = 1;
            $search_route .= '';
            foreach( $search as $key=>$val ){
                if( $val ){
                    $search_route .= '&'.$key.'='.$val;
                }
            }
        }
        $tpl_data['is_search'] = $is_where;
        $tpl_data['search'] = $search;


        $where['paper_id'] = $id;
        $this->load->library('pagination');
        $pagination_config = array(
            'base_url'      => '/vote/vote_all_user/'.$id.$search_route,
            'total_rows'    => $this->model_vote_user->total_rows($where),
            'per_page'      => 15,
            'page_query_string' => TRUE
        );

        $this->pagination->initialize($pagination_config);
        $tpl_data['pagination'] = $this->pagination->create_links();
        $per_page = $pagination_config['per_page'];
        $now_page = (int)$this->input->get('per_page') ? (int)$this->input->get('per_page') : 1;
        $tpl_data['per_page'] = $per_page;
        $tpl_data['now_page'] = $now_page;
        $start = ($now_page-1)*$per_page;
        $tpl_data['total_rows'] = $pagination_config['total_rows'];
        $list = $this->model_vote_user->get_all($where,$per_page,$now_page, 'answer_time', 'desc', 'id,mobile,name,uid,answer_ip,answer_time,mark,collection_data_id');
        foreach ($list as $key=>$value){
            $list[$key]['answer_ip'] = long2ip($value['answer_ip']);
        }
        $tpl_data['list'] = $list;

        $tpl_data['cur_nav'] = 'marketing';
        $tpl_data['curtitle'] = '所有用户列表';
        $this->twig->display('vote/vote_all_user', $tpl_data);
    }
    
    //所有用户列表
    public function vote_all_user_export($id='')
    {
        $id = trim($id);
        $this->load->model('model_vote_user');
        $tpl_data['id'] = $id;
        $paper = $this->model_vote_paper->get_row(array('id'=>$id,'is_delete'=>0),'id,title,collection_data_rule,paper_type,totals');
        if( !$paper ){
            $this->show_message(FALSE, '非法操作', '/vote');
        }else{
            $tpl_data['paper_id'] = $paper['id'];
            $tpl_data['paper_title'] = $paper['title'];
            $tpl_data['paper_type'] = $paper['paper_type'];
            $tpl_data['paper'] = $paper;
        }

        $name        = $this->input->get_post('name');
        $mobile      = $this->input->get_post('mobile');
        $from_time   = $this->input->get_post('from_time');
        $to_time     = $this->input->get_post('to_time');
        $start_mark  = $this->input->get_post('start_mark');
        $end_mark    = $this->input->get_post('end_mark');

        $where = array(); $is_where = 0;
        ($search['mobile'] = $mobile) && $where['mobile'] = "like:".$mobile;
        ($search['name'] = $name) && $where['name'] = "like:".$name;
        ($search['from_time'] = $from_time) && $where['answer_time>='] = strtotime($from_time);
        ($search['to_time'] = $to_time) && $where['answer_time<='] = strtotime($to_time);
        ($search['start_mark'] = $start_mark) && $where['mark>='] = $start_mark;
        ($search['end_mark'] = $end_mark)  && $where['mark<='] = $end_mark;
        $search_route = '?1=1';
        if( $where ){
            $is_where = 1;
            $search_route .= '';
            foreach( $search as $key=>$val ){
                if( $val ){
                    $search_route .= '&'.$key.'='.$val;
                }
            }
        }
        $tpl_data['is_search'] = $is_where;
        $tpl_data['search'] = $search;


        $where['paper_id'] = $id;
        $this->load->library('pagination');
        $pagination_config = array(
            'base_url'      => '/vote/vote_all_user/'.$id.$search_route,
            'total_rows'    => $this->model_vote_user->total_rows($where),
            'per_page'      => 15,
            'page_query_string' => TRUE
        );

        $this->pagination->initialize($pagination_config);
        $tpl_data['pagination'] = $this->pagination->create_links();
        $per_page = $pagination_config['per_page'];
        $now_page = (int)$this->input->get('per_page') ? (int)$this->input->get('per_page') : 1;
        $tpl_data['per_page'] = $per_page;
        $tpl_data['now_page'] = $now_page;
        $start = ($now_page-1)*$per_page;
        $tpl_data['total_rows'] = $pagination_config['total_rows'];
        $list = $this->model_vote_user->get_all($where,'','', 'answer_time', 'desc', 'id,mobile,name,uid,answer_ip,answer_time,mark,collection_data_id');
        foreach ($list as $key=>$value){
            $list[$key]['answer_ip'] = long2ip($value['answer_ip']);
        }
        
        //导出 TODO
        if( $list ){
            foreach( $list as $key=>$val ){
                $list[$key]['answer_time'] = date('Y-m-d H:i:s',$val['answer_time']);
            }
            $fields = array(
                '#'=>'#',
                'name'=>'姓名',
                'mobile'=>'手机号码',
                'answer_ip'=>'IP地址',
                'answer_time'=>'答题时间'
            );
            $this->excel_export($paper['title'].' 所有用户统计', $paper['title'].' 所有用户统计', $fields, $list);
        }
        
    }

    /**
     * 用户统计
     * $id 试卷id
     */
    public function statistics($id='',$flag=0)
    {
        $id = trim($id);
        $paper = $this->model_vote_paper->get_row(array('id'=>$id),'id,title,paper_type,totals');
        if( !$paper ){
            $this->show_message(FALSE, '非法操作', '',1);
        }
        if( $paper['paper_type']==1 ){
            $paper_type = 1;
        }else{
            $paper_type = 0;
        }
        $tpl_data['paper_title'] = $paper['title'];
        $tpl_data['paper_type'] = $paper_type;

        $this->load->model('model_vote_question');
        $this->load->model('model_vote_option');
        $this->load->model('model_vote_user');
        $this->load->model('model_vote_user_answer');
        //获取试题
        $question = $this->model_vote_question->get_all(array('paper_id'=>$id,'is_delete'=>0),'','','sort','asc','id,paper_id,question,question_img,question_mp3,question_video,type,ture_option_id,totals');
        if( $question ){
            $temp1 = array();
            foreach( $question as $key=>$value ){
                $question[$key]['question'] = htmlspecialchars_decode($value['question']);
                if( $value['type']==0||$value['type']==1 ){//单选或多选
                    $options = $this->model_vote_option->get_all(array('question_id'=>$value['id'],'is_delete'=>0),'','','sort','asc','id,question_id,content,content_img,content_mp3,content_video,type,mark,totals');
                    if( $options ){
                        $abc = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N'
                                    ,'O','P','Q','R','S','T','U','V','W','X','Y','Z','A1','B1','C1','D1','E1','F1','G1','H1','I1');
                        $abc_num = 0;
                        $temp2 = array();
                        foreach( $options as $key1=>$value1 ){
                            if( isset($abc[$abc_num])&&$abc[$abc_num] ){
                                $options[$key1]['content'] = htmlspecialchars_decode($value1['content']);
                                $options[$key1]['abc'] = $abc[$abc_num];
                                $abc_num++;
                                $temp2[$value1['id']] = $options[$key1];
                            }else{
                                break;
                            }
                        }
                        $question[$key]['options'] = $temp2;
                    }
                    $temp1[$value['id']] = $question[$key];
                }else{//填空
                    $temp1[$value['id']] = $question[$key];
                }
            }
            $paper['questions'] = $temp1;

        }else{
            $paper['questions'] = array();
        }

        if( $flag ){
            return $paper;
        }else{
            $tpl_data['paper'] = $paper;
            $tpl_data['cur_nav'] = 'marketing';
            $tpl_data['curtitle'] = '综合统计';
            $tpl_data['cur_type'] = 1;
            $this->twig->display('vote/statistics', $tpl_data);
        }
    }

    public function export($id='')
    {
        $id = trim($id);
        $paper = $this->model_vote_paper->get_row(array('id'=>$id),'id,title,paper_type,totals');
        if( !$paper ){
            $this->show_message(FALSE, '非法操作', '',1);
        }
        if( $paper['paper_type']==1 ){
            $paper_type = 1;
        }else{
            $paper_type = 0;
        }
        $tpl_data['paper_title'] = $paper['title'];
        $tpl_data['paper_type'] = $paper_type;

        $this->load->model('model_vote_question');
        $this->load->model('model_vote_option');
        $this->load->model('model_vote_user');
        $this->load->model('model_vote_user_answer');
        //获取试题
        $question = $this->model_vote_question->get_all(array('paper_id'=>$id,'is_delete'=>0),'','','sort','asc','id,paper_id,question,question_img,question_mp3,question_video,type,ture_option_id,totals');
        if( $question ){
            $temp1 = array();
            foreach( $question as $key=>$value ){
                $question[$key]['question'] = htmlspecialchars_decode($value['question']);
                if( $value['type']==0||$value['type']==1 ){//单选或多选
                    $options = $this->model_vote_option->get_all(array('question_id'=>$value['id'],'is_delete'=>0),'','','sort','asc','id,question_id,content,content_img,content_mp3,content_video,type,mark,totals');
                    if( $options ){
                        $abc = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N'
                                    ,'O','P','Q','R','S','T','U','V','W','X','Y','Z','A1','B1','C1','D1','E1','F1','G1','H1','I1');
                        $abc_num = 0;
                        $temp2 = array();
                        foreach( $options as $key1=>$value1 ){
                            if( isset($abc[$abc_num])&&$abc[$abc_num] ){
                                $options[$key1]['content'] = htmlspecialchars_decode($value1['content']);
                                $options[$key1]['abc'] = $abc[$abc_num];
                                $abc_num++;
                                $temp2[$value1['id']] = $options[$key1];
                            }else{
                                break;
                            }
                        }
                        $question[$key]['options'] = $temp2;
                    }
                    $temp1[$value['id']] = $question[$key];
                }else{//填空
                    $temp1[$value['id']] = $question[$key];
                }
            }
            $paper['questions'] = $temp1;

        }else{
            $paper['questions'] = array();
        }
        if( $paper['questions'] ){
            
            $list = array();
            foreach( $paper['questions'] as $key=>$val ){
                $list[] = array(
                    'name'   => '问题'.$key.' '.$val['question'],
                    'totals' => $val['totals'].'人参与',
                    'percent'=> number_format( $val['totals']/$paper['totals'], 2, '.', '' )
                );
                if( $val['type']==0||$val['type']==1 ){
                    if( $val['options'] ){
                        foreach( $val['options'] as $v ){
                            $list[] = array(
                                'name'   => '选项'.$v['abc'].' '.$v['content'],
                                'totals' => $v['totals'].'人参与',
                                'percent'=> number_format( $v['totals']/$val['totals'], 2, '.', '' )
                            );
                        }
                    }
                }
            }
            
            
            $fields = array(
                '#'=>'#',
                'name'=>'题目/选项',
                'totals'=>'参与人数',
                'percent'=>'占比'
            );
            $this->excel_export($paper['title'].' 综合统计', $paper['title'].' 综合统计', $fields, $list);
        }
    }

    //修改统计数字
    public function edit_totals()
    {
        header('Content-type: application/json');
        $pid = intval($this->input->get('pid'));
        $qid = intval($this->input->get('qid'));
        $oid = intval($this->input->get('oid'));
        $value = intval($this->input->get('value'));
        if( $value<=0 ){
            echo json_encode(array(
                'success' => -1,
                'msg'  => '非法操作'
                ));
        }
        $flag = true;//是否有选项id
        if( $pid>0 ){
            $paper = $this->statistics($pid,1);
            if( $paper['paper_type']==1 ){
                $paper_type = 1;
            }else{
                $paper_type = 0;
            }
            $tpl_data['paper_type'] = $paper_type;
            $tpl_data['paper_id'] = $paper['id'];
            $tpl_data['paper_title'] = $paper['title'];
            if( $qid>0 ){
                if( $paper['questions']&&isset($paper['questions'][$qid])&&$question=$paper['questions'][$qid] ){
                    $tpl_data['question'] = $question;
                    if( $oid<=0 ){
                        $flag = false;
                    }else{
                        if( $question && isset($question['options'][$oid]) && $option=$question['options'][$oid] ){
                            $tpl_data['option'] = $option;
                        }else{
                            echo json_encode(array(
                                'success' => -1,
                                'msg'  => '非法操作'
                                ));
                        }
                    }
                }else{
                    echo json_encode(array(
                        'success' => -1,
                        'msg'  => '非法操作'
                        ));
                }
            }else{
                echo json_encode(array(
                    'success' => -1,
                    'msg'  => '非法操作'
                    ));
            }
        }else{
            echo json_encode(array(
                'success' => -1,
                'msg'  => '非法操作'
                ));
        }
        $tpl_data['pid'] = $pid;
        $tpl_data['qid'] = $qid;
        $tpl_data['oid'] = $oid;

        if( $flag==false ){//查询试题的统计信息
            $res = $this->model_vote_question->update(array('paper_id'=>$pid,'id'=>$qid),array('totals'=>$value));
            if( false===$res ){
                echo json_encode(array(
                    'success' => -1,
                    'msg'  => '修改失败'
                    ));
            }else{
                echo json_encode(array(
                    'success' => 1
                ));
            }
        }else{//选项
            $res = $this->model_vote_option->update(array('question_id'=>$qid,'id'=>$oid),array('totals'=>$value));
            if( false===$res ){
                echo json_encode(array(
                    'success' => -1,
                    'msg'  => '修改失败'
                    ));
            }else{
                echo json_encode(array(
                    'success' => 1
                ));
            }
        }

    }

    /**
     * $pid  paper_id
     * $qid  question_id
     * $oid  option_id
     */
    public function vote_user()
    {
        if( isset($_GET['export']) ){
            $this->vote_user_export();
            exit;
        }
        header('Content-type: text/html; charset=utf-8');
        $pid = intval($this->input->get('pid'));
        $qid = intval($this->input->get('qid'));
        $oid = intval($this->input->get('oid'));
        $flag = true;//是否有选项id
        if( $pid>0 ){
            $paper = $this->statistics($pid,1);
            if( $paper['paper_type']==1 ){
                $paper_type = 1;
            }else{
                $paper_type = 0;
            }
            $tpl_data['paper_type'] = $paper_type;
            $tpl_data['paper_id'] = $paper['id'];
            $tpl_data['paper_title'] = $paper['title'];
            if( $qid>0 ){
                if( $paper['questions']&&isset($paper['questions'][$qid])&&$question=$paper['questions'][$qid] ){
                    $tpl_data['question'] = $question;
                    if( $oid<=0 ){
                        $flag = false;
                    }else{
                        if( $question && isset($question['options'][$oid]) && $option=$question['options'][$oid] ){
                            $tpl_data['option'] = $option;
                        }else{
                            $this->show_message(FALSE, '非法操作', '',1);
                        }
                    }
                }else{
                    $this->show_message(FALSE, '非法操作', '',1);
                }
            }else{
                $this->show_message(FALSE, '非法操作', '',1);
            }
        }else{
            $this->show_message(FALSE, '非法操作', '',1);
        }
        $tpl_data['pid'] = $pid;
        $tpl_data['qid'] = $qid;
        $tpl_data['oid'] = $oid;

        $name        = $this->input->get_post('name');
        $mobile      = $this->input->get_post('mobile');
        $from_time   = $this->input->get_post('from_time');
        $to_time     = $this->input->get_post('to_time');
        $start_mark  = $this->input->get_post('start_mark');
        $end_mark    = $this->input->get_post('end_mark');

        $where = array(); $like = array(); $is_where = 0;
        ($search['mobile'] = $mobile) && $like['vote_user.mobile'] = $mobile;
        ($search['name'] = $name) && $like['vote_user.name'] = $name;
        ($search['from_time'] = $from_time) && $where['vote_user.answer_time>='] = strtotime($from_time);
        ($search['to_time'] = $to_time) && $where['vote_user.answer_time<='] = strtotime($to_time);
        ($search['start_mark'] = $start_mark) && $where['vote_user.mark>='] = $start_mark;
        ($search['end_mark'] = $end_mark)  && $where['vote_user.mark<='] = $end_mark;
        $search_route = '';
        if( $where||$like ){
            $is_where = 1;
            foreach( $search as $key=>$val ){
                if( $val ){
                    $search_route .= '&'.$key.'='.$val;
                }
            }
        }
        $tpl_data['is_search'] = $is_where;
        $tpl_data['search'] = $search;

        //查询条件
        $where['vote_user_answer.paper_id'] = $pid;


        if( $flag==false ){//查询试题的统计信息
            $where['vote_user_answer.question_id'] = $qid;

            $this->load->library('pagination');
            $pagination_config = array(
                'base_url'      => '/vote/vote_user?pid='.$pid.'&qid='.$qid.$search_route,
                'total_rows'    => $this->model_vote_user_answer->vote_user_total($where,$like),
                'per_page'      => 15,
                'page_query_string' => TRUE
            );
            $this->pagination->initialize($pagination_config);
            $tpl_data['pagination'] = $this->pagination->create_links();
            $per_page = $pagination_config['per_page'];
            $now_page = (int)$this->input->get('per_page') ? (int)$this->input->get('per_page') : 1;
            $tpl_data['per_page'] = $per_page;
            $tpl_data['now_page'] = $now_page;
            $start = ($now_page-1)*$per_page;
            $tpl_data['total_rows'] = $pagination_config['total_rows'];
            $list = $this->model_vote_user_answer->vote_user($where,$like,$start,$per_page);
            foreach ($list as $key=>$value){
                $list[$key]['answer_ip'] = long2ip($value['answer_ip']);
                $list[$key]['option_text'] = htmlspecialchars_decode($value['option_text']);
            }
            $tpl_data['list'] = $list;

            $tpl_data['cur_nav'] = 'marketing';
            $tpl_data['curtitle'] = '详细信息';
            $this->twig->display('vote/vote_user', $tpl_data);

        }else{//查询选项的统计信息
            $where['vote_user_answer.question_id'] = $qid;
            $where['vote_user_answer.option_id'] = $oid;

            $this->load->library('pagination');
            $pagination_config = array(
                'base_url'      => '/vote/vote_user?pid='.$pid.'&qid='.$qid.'&oid='.$oid,
                'total_rows'    => $this->model_vote_user_answer->vote_user_o_total($where,$like),
                'per_page'      => 15,
                'page_query_string' => TRUE
            );
            $this->pagination->initialize($pagination_config);
            $tpl_data['pagination'] = $this->pagination->create_links();
            $per_page = $pagination_config['per_page'];
            $now_page = $this->input->get('per_page') ? $this->input->get('per_page') : 1;
            $tpl_data['per_page'] = $per_page;
            $tpl_data['now_page'] = $now_page;
            $start = ($now_page-1)*$per_page;
            $tpl_data['total_rows'] = $pagination_config['total_rows'];
            $list = $this->model_vote_user_answer->vote_user_o($where,$like,$start,$per_page);
            foreach ($list as $key=>$value){
                $list[$key]['answer_ip'] = long2ip($value['answer_ip']);
                $list[$key]['option_text'] = htmlspecialchars_decode($value['option_text']);
            }
            $tpl_data['list'] = $list;

            $tpl_data['cur_nav'] = 'marketing';
            $tpl_data['curtitle'] = '详细信息';
            $this->twig->display('vote/vote_user_o', $tpl_data);

        }
    }
    
    public function vote_user_export()
    {
        header('Content-type: text/html; charset=utf-8');
        $pid = intval($this->input->get('pid'));
        $qid = intval($this->input->get('qid'));
        $oid = intval($this->input->get('oid'));
        $flag = true;//是否有选项id
        if( $pid>0 ){
            $paper = $this->statistics($pid,1);
            if( $paper['paper_type']==1 ){
                $paper_type = 1;
            }else{
                $paper_type = 0;
            }
            $tpl_data['paper_type'] = $paper_type;
            $tpl_data['paper_id'] = $paper['id'];
            $tpl_data['paper_title'] = $paper['title'];
            if( $qid>0 ){
                if( $paper['questions']&&isset($paper['questions'][$qid])&&$question=$paper['questions'][$qid] ){
                    $tpl_data['question'] = $question;
                    if( $oid<=0 ){
                        $flag = false;
                    }else{
                        if( $question && isset($question['options'][$oid]) && $option=$question['options'][$oid] ){
                            $tpl_data['option'] = $option;
                        }else{
                            $this->show_message(FALSE, '非法操作', '',1);
                        }
                    }
                }else{
                    $this->show_message(FALSE, '非法操作', '',1);
                }
            }else{
                $this->show_message(FALSE, '非法操作', '',1);
            }
        }else{
            $this->show_message(FALSE, '非法操作', '',1);
        }
        $tpl_data['pid'] = $pid;
        $tpl_data['qid'] = $qid;
        $tpl_data['oid'] = $oid;

        $name        = $this->input->get_post('name');
        $mobile      = $this->input->get_post('mobile');
        $from_time   = $this->input->get_post('from_time');
        $to_time     = $this->input->get_post('to_time');
        $start_mark  = $this->input->get_post('start_mark');
        $end_mark    = $this->input->get_post('end_mark');

        $where = array(); $like = array(); $is_where = 0;
        ($search['mobile'] = $mobile) && $like['vote_user.mobile'] = $mobile;
        ($search['name'] = $name) && $like['vote_user.name'] = $name;
        ($search['from_time'] = $from_time) && $where['vote_user.answer_time>='] = strtotime($from_time);
        ($search['to_time'] = $to_time) && $where['vote_user.answer_time<='] = strtotime($to_time);
        ($search['start_mark'] = $start_mark) && $where['vote_user.mark>='] = $start_mark;
        ($search['end_mark'] = $end_mark)  && $where['vote_user.mark<='] = $end_mark;
        $search_route = '';
        if( $where||$like ){
            $is_where = 1;
            foreach( $search as $key=>$val ){
                if( $val ){
                    $search_route .= '&'.$key.'='.$val;
                }
            }
        }
        $tpl_data['is_search'] = $is_where;
        $tpl_data['search'] = $search;

        //查询条件
        $where['vote_user_answer.paper_id'] = $pid;


        if( $flag==false ){//查询试题的统计信息
            $where['vote_user_answer.question_id'] = $qid;

            $list = $this->model_vote_user_answer->vote_user($where,$like);
            foreach ($list as $key=>$value){
                $list[$key]['answer_ip'] = long2ip($value['answer_ip']);
                $list[$key]['option_text'] = htmlspecialchars_decode($value['option_text']);
            }
            $tpl_data['list'] = $list;
            
            //导出 TODO
            if( $list ){
                foreach( $list as $key=>$val ){
                    $list[$key]['answer_time'] = date('Y-m-d H:i:s',$val['answer_time']);
                    
                }
                $fields = array(
                    '#'=>'#',
                    'name'=>'姓名',
                    'mobile'=>'手机号码',
                    'answer_ip'=>'IP地址',
                    'answer_time'=>'答题时间'
                );
                if( $tpl_data['question']['type']==2 ){
                    $fields['option_text'] = '答题内容';
                }
                
                $this->excel_export($tpl_data['question']['question'].' 所有用户统计', $tpl_data['question']['question'].' 所有用户统计', $fields, $list);
            }

        }else{//查询选项的统计信息
            $where['vote_user_answer.question_id'] = $qid;
            $where['vote_user_answer.option_id'] = $oid;

            $list = $this->model_vote_user_answer->vote_user_o($where,$like);
            foreach ($list as $key=>$value){
                $list[$key]['answer_ip'] = long2ip($value['answer_ip']);
                $list[$key]['option_text'] = htmlspecialchars_decode($value['option_text']);
            }
            $tpl_data['list'] = $list;

            //导出 TODO
            if( $list ){
                foreach( $list as $key=>$val ){
                    $list[$key]['answer_time'] = date('Y-m-d H:i:s',$val['answer_time']);
                    
                }
                $fields = array(
                    '#'=>'#',
                    'name'=>'姓名',
                    'mobile'=>'手机号码',
                    'answer_ip'=>'IP地址',
                    'answer_time'=>'答题时间'
                );
                if( $tpl_data['question']['type']==2 ){
                    $fields['option_text'] = '答题内容';
                }
                
                $this->excel_export($tpl_data['question']['question'].' 选项'.$tpl_data['option']['abc'].' 所有用户统计', $tpl_data['question']['question'].' 所有用户统计', $fields, $list);
            }
        }
    }

    //用户扩展信息
    public function vote_collection_data($id='')
    {
        $id = trim($id);
        $this->load->model('model_vote_user');
        $this->load->model('model_collection_data');
        $vote_user = $this->model_vote_user->get_row(array('id'=>$id),'id,paper_id,collection_data_id,name,mobile');
        $paper = $paper = $this->model_vote_paper->get_row(array('id'=>$vote_user['paper_id']),'id,title,collection_data_rule,paper_type');
        $tpl_data['paper_type'] = $paper['paper_type'];
        $paper['rule'] = json_decode($paper['collection_data_rule'],true);
        $collection_data = $this->model_collection_data->get_row(array('id'=>$vote_user['collection_data_id']));
        $fields = array();
        $data_list = array();
        $this->load->config('collection_data');
        $config = $this->config->item('collection_data');

        foreach( $paper['rule'] as $key=>$value ){
            $data_list[$key]['field_name'] = $value['field_name'];
            $data_list[$key][$value['field_id']] = $collection_data[$value['field_id']];
            if( !empty($config[$value['field_id']]) ){
                $i = intval($collection_data[$value['field_id']]);
                $data_list[$key]['text'] = $config[$value['field_id']][$i];
            }else{
                $data_list[$key]['text'] = $collection_data[$value['field_id']];
            }
        }

        $tpl_data['title'] = $paper['title'];
        $tpl_data['name'] = $vote_user['name'];
        $tpl_data['mobile'] = $vote_user['mobile'];
        $tpl_data['data_list'] = $data_list;

        $tpl_data['cur_nav'] = 'marketing';
        $tpl_data['curtitle'] = '用户扩展信息';
        $this->twig->display('vote/vote_collection_data', $tpl_data);
    }
}