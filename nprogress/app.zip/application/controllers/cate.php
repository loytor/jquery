<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Cate extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('model_cate');
		$this->load->model('model_tpl');
	}

	public function index() {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$domain = $this->session->userdata('domain');

		$where_set = array('user_id' => $logged_user_id);

		//$cate_arr = $this->model_cate->get_all($where_set, '', '', 'rank', 'asc');
        $this->load->model('cate_model');
        $cate_arr = $this->cate_model->get_cate_by_level($where_set);
		foreach ($cate_arr as &$_cate) {
			$_cate['rank'] = $_cate['rank'] == 99999 ? '' : $_cate['rank'];
			$_cate['preview_url'] = $_cate['url'] ? $_cate['url'] : full_url('/cate?id='.$_cate['id'], $domain);
		}
		$tpl_data['cate_arr'] = $cate_arr;
		$tpl_data['cur_nav'] = 'cate';
		$this->twig->display('cate/index', $tpl_data);
	}

	public function add($parent_cate_id='') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$this->load->library('form_validation');
		$this->load->helper('form');
		$this->form_validation->set_rules('cate_name', '栏目名称', 'trim|required|max_length[255]|htmlspecialchars');
		$this->form_validation->set_rules('description', '栏目描述', 'trim|max_length[255]|htmlspecialchars');
		$this->form_validation->set_rules('image', '栏目图片', 'trim|callback__check_image');
		$this->form_validation->set_rules('url', '外部链接', 'trim');
		$this->form_validation->set_rules('background_image', '自定义背景', 'trim|callback__check_image');
		if ($this->form_validation->run()) {
			$data_set['user_id'] = $logged_user_id;
			$data_set['cate_name'] = $this->form_validation->set_value('cate_name');
			$data_set['description'] = $this->form_validation->set_value('description');
			$data_set['image'] = $this->form_validation->set_value('image');
			$data_set['url'] = $this->form_validation->set_value('url');
			$data_set['rank'] = 99999;
			$data_set['display'] = $this->input->post('display');
			$data_set['tpl'] = $this->input->post('tpl');
		    $data_set['level_type'] = $this->input->post('level_type');
		    $data_set['background_image'] = $this->form_validation->set_value('background_image');
            if( $data_set['level_type'] ){
                $data_set['level'] = intval($this->input->post('level'));
            }
            $data_set['parent_id'] = $parent_id = $parent_cate_id ? $parent_cate_id : $this->input->post('parent_id');
            if($cate_id = $this->model_cate->add($data_set)){
                if ($parent_id) {
                    $data_cate_lists['user_id'] = $logged_user_id;
                    $data_cate_lists['cate_id'] = $parent_id;
                    $data_cate_lists['type'] = 'cate';
                    $data_cate_lists['lists_id'] = $cate_id;
                    $data_cate_lists['rank'] = 9999;
                    $this->load->model('model_cate_lists');
                    $this->model_cate_lists->add($data_cate_lists);
                }
                $this->show_message(TRUE, '添加成功', '/cate');
            } else {
                $this->show_message(FALSE, '添加失败', '/cate/add');
            }
		} else {
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/cate/add');
			}
		}

		$this->load->config('tpl');
		$list_tpl_arr = $this->config->item('list_tpl_arr');
		$tpl_data['tpl_lists'] = $list_tpl_arr;
		//读取全局设置的模版
		$tpl = $this->model_tpl->get_row(array('user_id'=>$logged_user_id));
		if($tpl){
			$global_tpl = $tpl['list_tpl'] ? $tpl['list_tpl'] : 'default';
		}else{
			$global_tpl = 'default';
		}
		$tpl_data['global_tpl'] = $list_tpl_arr[$global_tpl];
		$tpl_data['preview_path'] = $this->config->item('preview_path');

		$this->load->library('encrypt');
		$token_data = array('user_id' => $logged_user_id, 'time' => time());
		$tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
		$tpl_data['cur_nav'] = 'cate';
		
		//权限
        $level = $this->get_level();
        $tpl_data['level'] = $level;
        $this->load->model('cate_model');
        $cate_arr = $this->cate_model->get_cate_by_level(array('user_id' => $logged_user_id));
        foreach($cate_arr as &$cate) {
            $space = "|".str_pad('', $cate['level']*4, "-");
            $cate['text'] = $space.' '.$cate['cate_name'];
        }
        $tpl_data['cate_arr'] = $cate_arr;
        $tpl_data['parent_cate'] = $this->model_cate->get_row(array('id'=>$parent_cate_id));
		$this->twig->display('cate/add', $tpl_data);
	}

	public function update($cate_id = '') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$cate = $this->model_cate->get_row(array('id' => $cate_id, 'user_id' => $logged_user_id));
		if ( ! $cate) {
			$this->show_message(FALSE, '找不到栏目', '/cate');
		}
		
		if(strpos($cate['image'], 'sys_icons')){
			$tpl_data['is_sys_icon'] = TRUE;
		}else{
			$tpl_data['is_sys_icon'] = FALSE;
		}
		$tpl_data['cate'] = $cate;

		$this->load->config('tpl');
		$list_tpl_arr = $this->config->item('list_tpl_arr');
		$tpl_data['tpl_lists'] = $list_tpl_arr;
		//读取全局设置的模版
		$tpl = $this->model_tpl->get_row(array('user_id'=>$logged_user_id));
		if($tpl){
			$global_tpl = $tpl['list_tpl'] ? $tpl['list_tpl'] : 'default';
		}else{
			$global_tpl = 'default';
		}
		$tpl_data['global_tpl'] = $list_tpl_arr[$global_tpl];
		$tpl_data['preview_path'] = $this->config->item('preview_path');

		$this->load->library('form_validation');
		$this->load->helper('form');
		$this->form_validation->set_rules('cate_name', '栏目名称', 'trim|required|max_length[255]|htmlspecialchars');
		$this->form_validation->set_rules('description', '栏目描述', 'trim|max_length[255]|htmlspecialchars');
		$this->form_validation->set_rules('image', '栏目图片', 'trim|callback__check_image');
		$this->form_validation->set_rules('url', '外部链接', 'trim');
		$this->form_validation->set_rules('background_image', '自定义背景', 'trim|callback__check_image');
		if ($this->form_validation->run()) {
			$data_set['cate_name'] = $this->form_validation->set_value('cate_name');
			$data_set['description'] = $this->form_validation->set_value('description');
			$data_set['image'] = $this->form_validation->set_value('image');
			$data_set['url'] = $this->form_validation->set_value('url');
			$data_set['display'] = $this->input->post('display');
			$data_set['tpl'] = $this->input->post('tpl');
		    $data_set['level_type'] = $this->input->post('level_type');
		    $data_set['background_image'] = $this->form_validation->set_value('background_image');
            if( $data_set['level_type'] ){
                $data_set['level'] = intval($this->input->post('level'));
            }else{
                $data_set['level'] = 0;
            }
            $data_set['parent_id'] = $parent_id = $this->input->post('parent_id');
			if($this->model_cate->update($cate_id, $data_set)) {
                if ($cate['parent_id'] != $parent_id) {
                    $this->load->model('model_cate_lists');
                    if ($parent_id) {
                        $data_cate_lists['user_id'] = $logged_user_id;
                        $data_cate_lists['cate_id'] = $parent_id;
                        $data_cate_lists['type'] = 'cate';
                        $data_cate_lists['lists_id'] = $cate['id'];
                        $data_cate_lists['rank'] = 9999;
                        $this->model_cate_lists->add($data_cate_lists);
                    }
                    if ($cate['parent_id']) {
                        $del_data_cate_lists['user_id'] = $logged_user_id;
                        $del_data_cate_lists['cate_id'] = $cate['parent_id'];
                        $del_data_cate_lists['type'] = 'cate';
                        $del_data_cate_lists['lists_id'] = $cate['id'];
                        $this->model_cate_lists->delete($del_data_cate_lists);
                    }
                }
                $this->show_message(TRUE, '更新成功', '/cate');
            } else {
                $this->show_message(FALSE, '更新失败', '/cate/update/'.$cate_id);
            }
		} else {
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/cate/update/'.$cate_id);
			}
		}
		$this->load->library('encrypt');
		$token_data = array('user_id' => $logged_user_id, 'time' => time());
		$tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
		$tpl_data['cur_nav'] = 'cate';
		
		//权限
        $level = $this->get_level();
        $tpl_data['level'] = $level;
        $this->load->model('cate_model');
        $cate_arr = $this->cate_model->get_cate_by_level(array('user_id' => $logged_user_id));
        foreach($cate_arr as $key=>&$cate) {
            if($this->show_cate($cate['id'], $cate_id)) {
                $space = "|".str_pad('', $cate['level']*4, "-");
                $cate['text'] = $space.' '.$cate['cate_name'];
            } else {
                unset($cate_arr[$key]);
            }
        }
        $tpl_data['cate_arr'] = $cate_arr;
		$this->twig->display('cate/update', $tpl_data);
	}

    private function show_cate($cate_id, $cur_cate_id)
    {
        if($cate_id == $cur_cate_id) {
            return FALSE;
        } else {
            $this->load->model('cate_model');
            $cate = $this->cate_model->where(array('id'=>$cate_id))->find();
            if($cate['parent_id'] != 0) {
                return $this->show_cate($cate['parent_id'], $cur_cate_id);
            }
        }
        return TRUE;
    }

    //权限
    private function get_level()
    {
        $level = array();
        $this->load->model('mcard_model');
        $mcard = $this->mcard_model->where(array('site_id'=>logged_user_id()))->find();
        if( $mcard ){
            $this->load->model('mcard_level_model');
            $level_temp = $this->mcard_level_model
                      ->order_by('basic desc,id desc')
                      ->where(array(
                          'site_id' => logged_user_id(),
                          'mcard_id' => $mcard['id'],
                          'status' => 1
                      ))
                      ->find_all();
             if( $level_temp ){
                foreach ( $level_temp as $val ){
                    $level[$val['id']] = $val['title'];
                }
             }
        }
        return $level;
    }

	public function delete($cate_id = '') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$cate = $this->model_cate->get_row(array('id' => $cate_id, 'user_id' => $logged_user_id));
		if ( ! $cate) {
			$this->show_message(FALSE, '找不到栏目', '/cate');
		}
		if ($cate['count_article'] > 0) {
			$this->show_message(FALSE, '请先删除栏目下的文章', '/cate');
		}
        if ($cate['count_marketing'] > 0) {
			$this->show_message(FALSE, '请先删除栏目下的活动', '/cate');
		}
        if($this->model_cate->get_all(array('parent_id'=>$cate_id, 'user_id'=>$logged_user_id))) {
            $this->show_message(FALSE, '请先删除栏目下的子栏目', '/cate');
        }
		if($this->model_cate->delete($cate_id)) {
            if ($cate['parent_id']) {
                $del_data_cate_lists['user_id'] = $logged_user_id;
                $del_data_cate_lists['cate_id'] = $cate['parent_id'];
                $del_data_cate_lists['type'] = 'cate';
                $del_data_cate_lists['lists_id'] = $cate_id;
                $this->load->model('model_cate_lists');
                $this->model_cate_lists->delete($del_data_cate_lists);
            }
            $this->show_message(TRUE, '删除成功', '/cate');
        } else {
            $this->show_message(FALSE, '删除失败', '/cate');
        }
	}

	public function update_rank($cate_id = '') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			$this->show_message(FALSE, '请先登录', '/auth/login');
		}
		$cate = $this->model_cate->get_row(array('id' => $cate_id, 'user_id' => $logged_user_id));
		if ( ! $cate) {
			$this->show_message(FALSE, '找不到栏目', '/cate');
		}
		$this->load->library('form_validation');
		$this->load->helper('form');
		$this->form_validation->set_rules('rank', '排序', 'trim');
		if ($this->form_validation->run()) {
			$rank = $this->form_validation->set_value('rank');
			$data_set['rank'] = $rank ? intval($rank) : 99999;
			$this->model_cate->update($cate_id, $data_set);
			$this->show_message(TRUE, '更新成功', '/cate');
		} else {
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/cate');
			}
		}
	}

	public function search_x()
	{
		$data = array(
			'items'	=> array(),
			'last_page'		=> 0,
			'next_page'		=> 0,
		);
		$logged_user_id = logged_user_id();
		if ($logged_user_id)
		{
			$whereSet = array('user_id' => $logged_user_id);
			$keyword = trim($this->input->get('keyword'));
			if ($keyword) {
				$whereSet['cate_name'] = 'like:'.$keyword;
			}

			$totalRows = $this->model_cate->total_rows($whereSet);
			$page = intval($this->input->get('page'));
			$page = $page < 1 ? 1 : $page;
			$per_page = 5;
			$cateArr = $this->model_cate->get_all($whereSet, $per_page, $page);

			if($cateArr)
			{
				foreach($cateArr as &$cate)
				{
					$cate['title'] = $cate['cate_name'];
					if(empty($cate['url']))
					{
						$cate['url'] = '/cate/?id='.$cate['id'];
					}
				}
			}
			$data['items'] = $cateArr;

			if ($page * $per_page < $totalRows) {
				$data['next_page'] = $page + 1;
			}
			if ($page > 1) {
				$data['last_page'] = $page - 1;
			}
		}
		header('Content-type: application/json');
		echo json_encode($data);
		exit;
	}

	public function _check_image($image) {
		if ($image) {
			if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
				$this->form_validation->set_message('_check_image', '图片地址格式错误');
				return FALSE;
			}
		}
		return TRUE;
	}

	private function show_message($success, $message, $redirect) {
		if ($this->input->is_ajax_request()) {
			$data = array(
				'success'	=> $success ? 1 : 0,
				'message'	=> strip_tags($message),
			);
			header('Content-type: application/json');
			echo json_encode($data);
		} else {
			$tpl_data = array(
				'message'	=> $message,
				'redirect'	=> $redirect,
			);
			$this->twig->display('show_message', $tpl_data);
		}
		exit;
	}

}