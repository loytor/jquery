<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Tpl extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('model_tpl');
	}

	public function index() {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}

		$cache_tpl = $this->get_tpl_cache($logged_user_id);
		if($cache_tpl){
			$selected_tpl = $cache_tpl;
		}else{
			$selected_tpl = $this->model_tpl->get_row(array('user_id'=>$logged_user_id));
		}
		if($selected_tpl){
			$selected_tpl['cate_tpl'] = $selected_tpl['cate_tpl'] ? $selected_tpl['cate_tpl'] : 'default';
			$selected_tpl['list_tpl'] = $selected_tpl['list_tpl'] ? $selected_tpl['list_tpl'] : 'default';
			$selected_tpl['detail_tpl'] = $selected_tpl['detail_tpl'] ? $selected_tpl['detail_tpl'] : 'default';
		}else{
			$selected_tpl['cate_tpl'] = 'default';
			$selected_tpl['list_tpl'] = 'default';
			$selected_tpl['detail_tpl'] = 'default';
		}

		$tpl_data['selected_tpl'] = $selected_tpl;

		$tpl_data['cate_tpl_arr'] = array(
										array('template_id'=>'default', 'title'=>'默认模版', 'image'=>'/assets/img/template/cate/default.jpg'),
										array('template_id'=>'t1', 'title'=>'模版1', 'image'=>'/assets/img/template/cate/t1.jpg'),
										array('template_id'=>'t2', 'title'=>'模版2', 'image'=>'/assets/img/template/cate/t2.jpg'),
										array('template_id'=>'t3', 'title'=>'模版3', 'image'=>'/assets/img/template/cate/t3.jpg'),
										array('template_id'=>'t4', 'title'=>'模版4', 'image'=>'/assets/img/template/cate/t4.jpg'),
										array('template_id'=>'t5', 'title'=>'模版5', 'image'=>'/assets/img/template/cate/t5.jpg'),
										array('template_id'=>'t6', 'title'=>'模版6', 'image'=>'/assets/img/template/cate/t6.jpg'),
										array('template_id'=>'logitech_index', 'title'=>'IT(首页)模版', 'image'=>'/assets/img/template/cate/logitech_index.jpg')
									);
		$tpl_data['list_tpl_arr'] = array(
										array('template_id'=>'default', 'title'=>'默认模版', 'image'=>'/assets/img/template/list/default.jpg'),
										array('template_id'=>'t1', 'title'=>'模版1', 'image'=>'/assets/img/template/list/t1.jpg'),
										array('template_id'=>'logitech_product_list', 'title'=>'IT(列表)模版', 'image'=>'/assets/img/template/list/logitech_product_list.jpg'),
										array('template_id'=>'logitech_product_list_1', 'title'=>'IT新(列表)模版', 'image'=>'/assets/img/template/list/logitech_product_list_1.jpg'),
										array('template_id'=>'logitech_product_list_2', 'title'=>'IT2(列表)模版', 'image'=>'/assets/img/template/list/logitech_product_list_2.jpg')
									);
		$tpl_data['detail_tpl_arr'] = array(
										array('template_id'=>'default', 'title'=>'默认模版', 'image'=>'/assets/img/template/detail/default.jpg'),
										array('template_id'=>'logitech_product_detail', 'title'=>'IT(详情)模版', 'image'=>'/assets/img/template/detail/logitech_product_detail.jpg')
									);

		$tpl_data['cur_nav'] = 'cate';
		$this->twig->display('tpl/index', $tpl_data);
	}

	public function selected() {
		$type = $this->input->post('type');
		$tid = $this->input->post('tid');
		$logged_user_id = logged_user_id();

		$tpl = $this->model_tpl->get_row(array('user_id'=>$logged_user_id));

		$data_set[$type] = $tid;
		$data_set['user_id'] = $logged_user_id;

		$json = array();
		$json['success'] = 0;
		$json['msg'] = "保存失败";

		if($tpl){ // 编辑
			if($this->model_tpl->update(array('user_id'=>$logged_user_id), $data_set)){
				$json['success'] = 1;
				$json['msg'] = "保存成功";
				//更新memcached中的tpl信息
				$cache_tpl = array('cate_tpl'=>'default', 'list_tpl'=>'default', 'detail_tpl'=>'default');
				$cache_tpl['cate_tpl'] = $tpl['cate_tpl'] ? $tpl['cate_tpl'] : 'default';
				$cache_tpl['list_tpl'] = $tpl['list_tpl'] ? $tpl['list_tpl'] : 'default';
				$cache_tpl['detail_tpl'] = $tpl['detail_tpl'] ? $tpl['detail_tpl'] : 'default';

				$cache_tpl[$type] = $data_set[$type];
				$this->cache_tpl($logged_user_id, $cache_tpl);
			}
		}else{ // 添加
			if($this->model_tpl->add($data_set)){
				$json['success'] = 1;
				$json['msg'] = "保存成功";
				//添加tpl信息到memcached中
				$cache_tpl = array('cate_tpl'=>'default', 'list_tpl'=>'default', 'detail_tpl'=>'default');
				$cache_tpl[$type] = $data_set[$type];
				$this->cache_tpl($logged_user_id, $cache_tpl);
			}
		}

		header('Content-type: application/json');
		echo json_encode($json);
	}

	private function cache_tpl($user_id='', $tpl = array('cate_tpl'=>'default', 'list_tpl'=>'default', 'detail_tpl'=>'default')) {
		$this->load->driver('cache', array('adapter'=>'memcached', 'backup'=>'file'));
		$user_cache = $this->cache->get("'".$user_id."'");
		if ( ! $user_cache) {
			$cache_data = array();
			$cache_data['tpl'] = $tpl;
			$this->cache->save("'".$user_id."'", $cache_data, 0);
		}else{
			$user_cache['tpl'] = $tpl;
			$this->cache->save("'".$user_id."'", $user_cache, 0);
		}
	}

	private function get_tpl_cache($user_id='') {
		$this->load->driver('cache', array('adapter'=>'memcached', 'backup'=>'file'));
		$user_cache = $this->cache->get("'".$user_id."'");
		$result = array();
		if( $user_cache) {
			$result = isset($user_cache['tpl']) ? $user_cache['tpl'] : array();
		}
		return $result;
	}
}