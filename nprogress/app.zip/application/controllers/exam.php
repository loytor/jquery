<?php
class Exam extends MY_Controller
{
    private $wid = null;
    private $tpl_data = array();

    public function __construct()
    {
        parent::__construct();
        $this->wid = User::$user_id;
        $this->load->model('model_emigrated_question');
    }
    
    public function index()
    {   
        $where_set = array(
            'wid'    => '',
            'day_id' => null
        );
        
        $this->load->library('pagination');
        $pagination_config = array(
            'base_url'      => '/exam/index/',
            'total_rows'    => $this->model_emigrated_question->total_rows($where_set),
            'per_page'      => 15,
            'uri_segment'   => 3,
        );
        $this->pagination->initialize($pagination_config);
        $this->tpl_data['pagination'] = $this->pagination->create_links();
        $per_page = $pagination_config['per_page'];
        $page = intval($this->uri->segment($pagination_config['uri_segment'], 1));
        $this->tpl_data['now_page'] = $page;
        $this->tpl_data['per_page'] = $per_page;
        $this->tpl_data['count_list'] = $pagination_config['total_rows'];
        
        $list = $this->model_emigrated_question->get_all($where_set,$per_page,$page,'id','asc','id,title,add_time');
        $this->tpl_data['list'] = $list;
        
        
        $this->tpl_data['curtitle'] = '题库列表';
        $this->token();
        $this->twig->display('exam/index',$this->tpl_data);
    }
    
    public function add()
    {
        $count_list = $this->model_emigrated_question->total_rows(array('wid'=>'','day_id'=>null));
        if( $count_list>=5000 ){
            $this->show_message(FALSE, '系统题库最多5000个', '/exam');
        }
        //验证并保存
        $this->load->library('form_validation');
        $this->form_validation->set_rules('question', '题目内容', 'trim|required|max_length[50]');
        if($this->form_validation->run()){
            $question = $this->form_validation->set_value('question');
            if( $question ){
                $question_img = $this->input->post('question_img');
                $true_option = $this->input->post('true_option');
                $option_temp = $this->input->post('option');
                $options = array();//保存选项
                $i = 0;//给选项加唯一值
                $true_correct = 0;//正确选项是否写对
                foreach ( $option_temp as $key=>$val ){
                    if( $val['text'] ){
                        if( (MB_ENABLED === TRUE)?(mb_strlen($val['text'])>50 ):(strlen($val['text'])>50 ) ){
                            $this->show_message(FALSE, '答案内容最多50个字', '',1);
                        }
                        $correct = 0;
                        if( $true_option==$key ){
                            $correct = 1;
                            $true_correct = 1;
                        }
                        $options[$i] = array(
                            'id'        => $i+1,
                            'title'     => $val['text'],
                            'title_img' => $val['img'],
                            'correct'   => $correct
                        );
                        $i++;
                    }
                }
                if( !$options ){
                    $this->show_message(FALSE, '答案内容不能为空', '',1);
                }
                if( !$true_correct ){
                    $this->show_message(FALSE, '请重新选择正确选项', '',1);
                }
                $option_set = array(
                    'title'  =>  $question,
                    'title_img' => $question_img,
                    'options'   => json_encode($options)
                );
                if( !$this->model_emigrated_question->add($option_set) ){
                    $this->show_message(FALSE, '添加失败', '',1);
                }else{
                    $this->show_message(TRUE, '添加成功', '/exam/index');
                }
            }
        }else{
            $errors = validation_errors();
            if ($errors) {
                $this->show_message(FALSE, $errors, '/exam');
            }
        }
        
        $this->tpl_data['curtitle'] = '添加题目';
        $this->token();
        $this->twig->display('exam/add',$this->tpl_data);
    }
    
    public function update($id='')
    {
        $question = $this->model_emigrated_question->get_row(array('id'=>$id));
        if( !$question||($question['wid']!='')||($question['day_id']!=null) ){
            $this->show_message(FALSE, '非法参数', '',1);
        }
        //验证并保存
        $this->load->library('form_validation');
        $this->form_validation->set_rules('question', '题目内容', 'trim|required|max_length[50]');
        if($this->form_validation->run()){
            $question = $this->form_validation->set_value('question');
            if( $question ){
                $question_img = $this->input->post('question_img');
                $true_option = $this->input->post('true_option');
                $option_temp = $this->input->post('option');
                $options = array();//保存选项
                $i = 0;//给选项加唯一值
                $true_correct = 0;//正确选项是否写对
                foreach ( $option_temp as $key=>$val ){
                    if( $val['text'] ){
                        if( (MB_ENABLED === TRUE)?(mb_strlen($val['text'])>50 ):(strlen($val['text'])>50 ) ){
                            $this->show_message(FALSE, '答案内容最多50个字', '/exam/update/'.$id);
                        }
                        $correct = 0;
                        if( $true_option==$key ){
                            $correct = 1;
                            $true_correct = 1;
                        }
                        $options[$i] = array(
                            'id'        => $i+1,
                            'title'     => $val['text'],
                            'title_img' => $val['img'],
                            'correct'   => $correct
                        );
                        $i++;
                    }
                }
                if( !$options ){
                    $this->show_message(FALSE, '答案内容不能为空', '/exam/update/'.$id);
                }
                if( !$true_correct ){
                    $this->show_message(FALSE, '请重新选择正确选项', '/exam/update/'.$id);
                }
                $option_set = array(
                    'title'  =>  $question,
                    'title_img' => $question_img,
                    'options'   => json_encode($options)
                );
                if( !$this->model_emigrated_question->update(array('id'=>$id),$option_set) ){
                    $this->show_message(FALSE, '修改失败', '/exam/update/'.$id);
                }else{
                    $this->show_message(TRUE, '修改成功', '/exam/index');
                }
            }
        }else{
            $errors = validation_errors();
            if ($errors) {
                $this->show_message(FALSE, $errors, '/exam');
            }
        }
        
        $question['options'] = json_decode($question['options'],true);
        $abc = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
        foreach( $question['options'] as $key=>$value ){
            $question['options'][$key]['abc'] = $abc[$key];
        }
        
        $this->tpl_data['info'] = $question;
        $this->tpl_data['option_num'] = count($question['options']);
        
        $this->tpl_data['curtitle'] = '修改题目';
        $this->token();
        $this->twig->display('exam/update',$this->tpl_data);
    }
    
    public function delete($id='')
    {
        $question = $this->model_emigrated_question->get_row(array('id'=>$id));
        if( !$question||($question['wid']!='')||($question['day_id']!=null) ){
            $this->show_message(FALSE, '非法参数', '',1);
        }
        if( $this->model_emigrated_question->delete(array('id'=>$id)) ){
            $this->show_message(TRUE, '删除成功', '/exam');
        }else{
            $this->show_message(FALSE, '删除失败', '/exam');
        }
    }
    
    //token
    private function token()
    {
        $this->load->library('encrypt');
        $token_data = array('user_id' => $this->wid, 'time' => time());
        $this->tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
    }

}