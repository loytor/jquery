<?php
/**
 * Created by PhpStorm.
 * User: llj
 * Date: 14-7-14
 * Time: 下午3:01
 * @property app_model $app_model
 * 接口文档:https://app.yinxiang.com/shard/s36/sh/a1d09a2e-225c-42f3-bc3a-82e037e31e28/382fbef071ad93bee98a106b811dd0a8
 */
class GetAppList extends API_Controller {

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $site_id = $this->input->get('site_id',true);

        if(!$site_id)
        {
            exit($this->ajax_return(array('ret'=>20002,'msg'=>'site_id不能为空')));
        }
        switch ($this->type)
        {
            case 'yixing':
                $app_list = array();
                break;
            case 'alipay':
                $app_list = array();
                break;
            default:
                $this->load->model('user_auth_model');
                $app_list = $this->user_auth_model->select('wb_app.id, wb_app.name, wb_app.icon')->join('wb_app', 'wb_app.id = user_auth.app_id', 'left')->where(array('wb_app.status'=>0, 'user_auth.user_id'=>$site_id))->find_all();
                $app_list = $app_list ? $app_list : array();
                break;
        }

        exit($this->ajax_return(array('ret'=>0,'data'=>$app_list)));
    }
}