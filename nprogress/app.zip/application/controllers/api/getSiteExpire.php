<?php
/**
 * Created by PhpStorm.
 * User: songxiyao
 * Date: 14-10-24
 * Time: 上午10:05
 */

class GetSiteExpire extends API_Controller {

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $domain = $this->input->get('domain',true);

        if(!$domain)
        {
            exit($this->ajax_return(array('ret'=>101,'msg'=>'domain empty')));
        }
        $this->load->model('user_model');
        $result = $this->user_model
            ->select('dt_expire,is_deleted,is_active')
            ->where(array('domain'=>$domain))
            ->find();
        if(!$result)
        {
            exit($this->ajax_return(array('ret'=>102,'msg'=>'The site does not exist')));
        }
        if($result['is_deleted'] != 0 || $result['is_active'] != 1)
        {
            exit($this->ajax_return(array('ret'=>103,'msg'=>'The site has been deleted')));
        }
        $expire = strtotime($result['dt_expire']);
        if($expire <= time())
        {
            exit($this->ajax_return(array('ret'=>104,'msg'=>'The site has expired','data'=>$expire)));
        }
        exit($this->ajax_return(array('ret'=>0,'data'=>$expire)));
    }
} 