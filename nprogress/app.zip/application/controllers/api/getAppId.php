<?php
/**
 * Created by PhpStorm.
 * User: llj
 * Date: 14-8-2
 * Time: 下午2:42
 * 根据moudle和method获取应用ID
 */
class GetAppId extends API_Controller {

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $module = $this->input->get('module',true);
        $method = $this->input->get('method',true);

        switch ($this->type)
        {
            case 'yixing':
                $result = array();
                break;
            case 'alipay':
                $result = array();
                break;
            default:
                $this->load->model('app_model');
                $result = $this->app_model
                    ->select('id')
                    ->where(array('module'=>$module, 'method'=>$method))
                    ->find();
                break;
        }


        if(!$result)
        {
            exit($this->ajax_return(array('ret'=>102,'msg'=>'应用不存在')));
        }
        exit($this->ajax_return(array('ret'=>0,'data'=>$result)));
    }
}