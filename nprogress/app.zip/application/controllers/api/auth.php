<?php
/**
 * Created by PhpStorm.
 * User: along
 * Date: 14-7-14
 * Time: 下午3:26
 * 接口文档：https://app.yinxiang.com/shard/s39/sh/2e99d6cc-a02c-413e-96f5-29095f95ad46/f1c477a7d9ec18a6530f21343748d8ea
 * @property user_model $user_model
 */

class Auth extends API_Controller {

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        //微网站用户名
        $username = $this->input->post('username',true);
        if(!$username)
        {
            exit($this->ajax_return(array('ret'=>30001,'msg'=>'用户名不能为空')));
        }
        //密码
        $password = $this->input->post('password',true);
        if(!$password)
        {
            exit($this->ajax_return(array('ret'=>30002,'msg'=>'密码不能为空')));
        }
        $this->load->model('user_model');
        $result = $this->user_model
            ->select('id,is_deleted,is_active,password,dt_expire')
            ->where(array('username'=>$username))
            ->find();
        if ( ! $result) {
            exit($this->ajax_return(array('ret'=>30003,'msg'=>'用户不存在')));
        }
        if ($result['password'] != md5($password)) {
            exit($this->ajax_return(array('ret'=>30004,'msg'=>'密码不正确')));
        }

        if($result['is_active'] == 0)
        {
            exit($this->ajax_return(array('ret'=>30005,'msg'=>'该账号已被禁用')));
        }
        if($result['is_deleted'] == 1)
        {
            exit($this->ajax_return(array('ret'=>30006,'msg'=>'该账号已被删除')));
        }

        //判断帐号是否过期
        $expire = strtotime($result['dt_expire']);
        if($expire - time() < 0)
        {
            exit($this->ajax_return(array('ret'=>30007,'msg'=>'帐号已过期')));
        }
        exit($this->ajax_return(array('ret'=>0,'data'=>array('site_id'=>$result['id']))));
    }
} 