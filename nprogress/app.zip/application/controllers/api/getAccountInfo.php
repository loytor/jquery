<?php
/**
 * Created by PhpStorm.
 * User: 111
 * Date: 14-10-10
 * Time: 下午4:22
 * 获取account表 用户信息
 */

class GetAccountInfo extends API_Controller{

    public function __construct()
    {
        parent::__construct();
    }

    public function get_info()
    {

        $post_data = file_get_contents('php://input');
        //$post_data = '{"domain":"llmtest.bama555.com","uid_member":["1254_20000000"]}';
        $post_data = json_decode($post_data,true);
        if( !isset( $post_data['domain'] )||!isset( $post_data['uid_member'] ) ){
            exit($this->ajax_return(array('ret'=>120000,'msg'=>'参数不完整')));
        }

        $domain = $post_data['domain'];
        $domain_array = explode( '.', $domain );
        $domain = $domain_array[0];
        $this->load->model('user_model');
        $site_info = $this->user_model->select('id')->where(array('domain'=>$domain))->find();
        if( !$site_info ){
            exit($this->ajax_return(array('ret'=>10000,'msg'=>'没有找到该微网站')));
        }

        $list = array();

        $this->load->model('account_model');
        $this->load->model('member_model');
        $this->member_model->setTable($site_info['id']);
        foreach( $post_data['uid_member'] as $key=>$val ){
            $list[$key] = array(
                'id'     => $val,
                'name'   => '',
                'mobile' => '',
                'nick'   => '',
                'avatar' => '',
                'gender' => 0
            );
            $temp = explode('_',$val);
            if( $temp[0] ){//uid
                $account = $this->account_model->select('name,mobile')->where(array('id'=>$temp[0],'wid'=>$site_info['id']))->find();
                if( $account ){
                    $list[$key]['name'] = $account['name'];
                    $list[$key]['mobile'] = $account['mobile'];
                }
            }
            if( $temp[1] ){//member_id
                $member = $this->member_model->select('mobile,name as nick,avatar,gender')->where(array('site_id'=>$site_info['id'],'id'=>$temp[1]))->find();
                if( $member ){
                    $list[$key]['nick'] = $member['nick'] ? $member['nick'] : '';
                    if( $member['mobile'] ){
                        $list[$key]['mobile'] = $member['mobile'];
                    }
                    $list[$key]['avatar'] = $member['avatar'] ? $member['avatar'] : '';
                    $list[$key]['gender'] = $member['gender'] ? $member['gender'] : '';
                }
            }
        }

        exit($this->ajax_return(array('ret'=>0,'data'=>$list)));
    }
}