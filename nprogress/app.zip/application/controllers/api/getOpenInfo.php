<?php
/**
 * Created by PhpStorm.
 * User: along
 * Date: 14-7-11
 * Time: 上午11:45
 * 接口文档：https://app.yinxiang.com/shard/s39/sh/1b74ae35-3f97-43cd-9bea-4670db8813ca/69c295e4b91c286598ed24835f63c4c8
 * @property user_model $user_model
 */

class GetOpenInfo extends API_Controller {

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $site_id = $this->input->get('site_id',true);

        if(!$site_id)
        {
            exit($this->ajax_return(array('ret'=>101,'msg'=>'site_id不能为空')));
        }
        switch ($this->type)
        {
            case 'yixing':
                $openInfo = array();
                break;
            case 'alipay':
                $openInfo = array();
                break;
            default:
                $this->load->model('user_model');
                $openInfo = $this->user_model
                    ->select('mp_username,appid,appsecret,is_service')
                    ->where(array('id'=>$site_id,'is_deleted'=>0,'is_active'=>1))
                    ->find();
                break;
        }


        if(!$openInfo)
        {
            exit($this->ajax_return(array('ret'=>102,'msg'=>'用户不存在或已删除')));
        }
        exit($this->ajax_return(array('ret'=>0,'data'=>$openInfo)));
    }
} 