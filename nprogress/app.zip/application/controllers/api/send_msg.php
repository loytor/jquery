<?php

/**
 * Created by PhpStorm.
 * User: songxiyao
 * Date: 2014/11/11
 * Time: 16:02
 */
class Send_msg extends API_Controller {

    public function __construct() {
        parent::__construct();
    }

    public function index() {
        $post_data = json_decode(file_get_contents("php://input"), true);

        if (isset($post_data['uid'])) {
            if (!$post_data['domain'] || !$post_data['content']) {
                $this->ajax_return(array('ret' => 1001, 'msg' => '缺少必要参数', 'data' => explode(",", $post_data['uid'])));
                return false;
            }
        } else {
            $this->ajax_return(array('ret' => 1001, 'msg' => '缺少必要参数', 'data' => array()));
            return false;
        }
        //查询微网站信息
        $this->load->model('model_user', 'user');
        $user_info = $this->user->get_row(array('domain' => $post_data['domain']), 'id');
        if (!$user_info) {
            $this->ajax_return(array('ret' => 1002, 'msg' => '微网站不存在'));
            return false;
        }
        //查询app_id
        $this->load->library('Mongo_db');
        $wx_info = $this->mongo_db->where(array('site_id' => $user_info['id']))->get_one(MONGO_WX_SET);
        if (!$wx_info['appid']) {
            $this->ajax_return(array('ret' => 1003, 'msg' => '请配置微信appid相关信息'));
            return false;
        }
        //获取access_token
        $this->load->library('wbcurl');
        $response = json_decode($this->wbcurl->simple_post(TOKEN_WX_SERVER . 'info', array('app_id' => $wx_info['appid'])), true);

        if (!$response['token']) {
            $this->ajax_return(array('ret' => 1004, 'msg' => '获取access_token失败，请检查app_id和app_secret信息'));
            return false;
        }
        //发送信息
        $uid_arr = explode(",", $post_data['uid']);
        $this->load->library('wechat', array(
                'app_id' => $wx_info['appid'],
                'secret' => $wx_info['appscret'])
        );
        $this->load->model('member_model');
        $faild = 0;//发送失败数量
        $faild_uid = array();//发送失败的用户
        foreach ($uid_arr as $v) {
            $content = str_replace('/', '\/', str_replace('"', '\"', $post_data['content']));
            //查询对应的open_id
            $this->member_model->setTable($user_info['id']);
            $member = $this->member_model->getMemberById($v);
            $data = array(
                'touser'  => $member['public_id'],
                'msgtype' => 'text',
                'text'    => array(
                    'content' => $content
                )
            );
            $post_json = urldecode(json_encode($data));
            $res = $this->wechat->message_custom_post($post_json, $response['token']);
            if (is_numeric($res) && $res > 0) {
                $faild += 1;
                $faild_uid[] = array(
                    'errorcode' => $res,
                    'uid'       => $v
                );
            }
        }
        if ($faild > 0) {
            $this->ajax_return(array('ret' => 1005, 'msg' => '有' . $faild . '位用户发送失败', 'data' => $faild_uid));
        } else {
            $this->ajax_return(array('ret' => 0, 'msg' => '发送成功'));
        }
    }
}