<?php
/**
 * Created by PhpStorm.
 * User: along
 * Date: 14-7-14
 * Time: 下午3:16
 * 接口文档：
 * @property user_model $user_model
 */
class GetSiteTitle extends API_Controller {

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $site_id = $this->input->get('site_id',true);

        if(!$site_id)
        {
            exit($this->ajax_return(array('ret'=>101,'msg'=>'site_id不能为空')));
        }
        switch ($this->type)
        {
            case 'yixing':
                $result = array();
                break;
            case 'alipay':
                $result = array();
                break;
            default:
                $this->load->model('user_model');
                $result = $this->user_model
                    ->select('web_name')
                    ->where(array('id'=>$site_id,'is_deleted'=>0,'is_active'=>1))
                    ->find();
                break;
        }


        if(!$result)
        {
            exit($this->ajax_return(array('ret'=>102,'msg'=>'用户不存在或已删除')));
        }
        exit($this->ajax_return(array('ret'=>0,'data'=>$result)));
    }
}