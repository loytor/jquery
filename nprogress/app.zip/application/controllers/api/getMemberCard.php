<?php
/**
 * Created by solaa.
 * User: solaa
 * Date: 2014/11/11 16:21
 */

class GetMemberCard extends API_Controller {

    private $site_id = '';

    public function __construct()
    {
        parent::__construct();
        /*$uid = 'wn0bIIsLXolsZdvMpMNVsLncU+Mpnl9548WS4zxLrqeELB59e871h78PQharxPCSchtW9stTq1PENotPl82wSA==';
        $this->load->library('encrypt');
        $uid = $this->encrypt->decode(rawurldecode($uid),'WeiBaXinXiweixinshengyibao');
        if( !is_numeric($uid) ){
            $account_id = urldecode($uid);
            $uid = $this->encrypt->decode(str_replace(' ','+', $uid),'WeiBaXinXiweixinshengyibao');
        }
        echo $uid;exit;*/
        $this->get_site();
    }

    public function get_config($inline=FALSE)
    {
        //钱包设置
        $this->load->library('Mongo_db');
        $money_setting = $this->mongo_db->where(array('site_id'=>$this->site_id))->get_one('money');
        $data['money_set'] = isset($money_setting['on']) ? $money_setting['on'] : 0;

        //积分设置
        $credit_setting = $this->mongo_db->where(array('site_id'=>$this->site_id))->get_one('credit');
        $data['credit_set'] = isset($credit_setting['on']) ? $credit_setting['on'] : 0;

        //会员卡设置
        $this->load->model('mcard_model');
        $mcard = $this->mcard_model->where(array('site_id'=>$this->site_id))->find();
        $data['mcard_set'] = isset($mcard['on']) ? $mcard['on'] : 0;
        !$inline && exit($this->ajax_return(array('ret'=>0,'data'=>$data)));

        return $data;
    }

    public function get_mcard_level()
    {
        //会员卡设置
        $this->load->model('mcard_model');
        $mcard = $this->mcard_model->where(array('site_id'=>$this->site_id))->find();
        $mcard_set = isset($mcard['on']) ? $mcard['on'] : 0;
        if( !$mcard_set ) exit($this->ajax_return(array('ret'=>10000,'msg'=>'会员卡功能未开启')));

        $where['site_id'] = $mcard['site_id'];
        $where['mcard_id'] = $mcard['id'];
        $where['status'] = 1;
        $this->load->model('mcard_level_model');
        $list = $this->mcard_level_model->order_by('basic desc,id desc')->where($where)->find_all();
        exit($this->ajax_return(array('ret'=>0,'data'=>$list)));
    }

    public function get_account_info($inline=FALSE)
    {
        $account_id = $this->input->post('uid');
        $this->load->library('encrypt');
        $uid = $this->encrypt->decode(rawurldecode($account_id),'WeiBaXinXiweixinshengyibao');
        if( !is_numeric($uid) ){
            $account_id = urldecode($account_id);
            $uid = $this->encrypt->decode(str_replace(' ','+', $account_id),'WeiBaXinXiweixinshengyibao');
        }
        $this->load->model('account_model');
        $account = $this->account_model->select('id,name,mobile,wid as site_id,money,credit,level_credit')->where(array('id'=>$uid,'wid'=>$this->site_id))->find();
        if( !$account ){
            exit($this->ajax_return(array('ret'=>10000,'msg'=>'没有找到该用户')));
        }
        $account['mcard_info'] = array();
        $config = $this->get_config(TRUE);
        //会员卡信息
        if( $config['mcard_set'] ){
            $this->load->model('mcard_member_model');
            $account['mcard_info'] = $this->mcard_member_model->select('id,mcard_id,card_num,level_id')->where(array('uid'=>$account['id'], 'site_id'=>$this->site_id, 'is_deleted'=>0))->find();
            if( $account['mcard_info'] ){
                //按积分的等级
                $this->load->model('mcard_level_model');
                if(!$account['mcard_info']['level_id']) {
                    $level_credit = $account['level_credit'];
                    $level = $this->mcard_level_model->where(array('mcard_id'=>$account['mcard_info']['mcard_id'], 'site_id'=>$this->site_id, 'conditions'=>2, 'status'=>1, 'minpoints <= '=>$level_credit))->order_by('minpoints desc')->find();
                    if(!$level) {
                        $level = $this->mcard_level_model->where(array('site_id'=>$this->site_id, 'basic'=>1, 'mcard_id'=>$account['mcard_info']['mcard_id']))->find();
                    }
                }else{
                    $level = $this->mcard_level_model->where(array('id'=>$account['mcard_info']['level_id'], 'site_id'=>$this->site_id))->find();
                }
                if( isset( $level['id'] ) ){
                    $account['mcard_info']['level_id'] = $level['id'];
                    $account['mcard_info']['level_title'] = $level['title'];
                }
            }

        }
        !$inline && exit($this->ajax_return(array('ret'=>0,'data'=>$account)));

        $data['account'] = $account;
        $data['config'] = $config;
        return $data;
    }

    private function get_site()
    {
        $username = $this->input->post('username',true);
        if( !$username ){
            exit($this->ajax_return(array('ret'=>10000,'msg'=>'参数不完整')));
        }
        if( strlen($username)>30 ){
            exit($this->ajax_return(array('ret'=>10000,'msg'=>'非法入侵')));
        }
        $this->load->model('user_model');
        $site = $this->user_model->select('id,is_active,dt_expire,free_trial')->where(array('username'=>$username))->find();
        if ( !$site) {
            exit($this->ajax_return(array('ret'=>10000,'msg'=>'用户名不存在')));
        }
        if($site['is_active'] == 0){
            exit($this->ajax_return(array('ret'=>10000,'msg'=>'对不起，该账号已被禁用，请联系代理商')));
        }

        //判断帐号是否过期
        $expire = strtotime($site['dt_expire']);
        if($expire && ($expire - time() < 0)){
            $this->load->model('free_trial_model');
            $free_trial = $this->free_trial_model->where(array('username'=>$site['username']))->find();
            if($site['free_trial'] == 1 && $free_trial['status'] == 0) {
            } else {
                exit($this->ajax_return(array('ret'=>10000,'msg'=>'您的帐号已过期')));
            }
        }
        $this->site_id = $site['id'];
    }

    /**
     * 支付 只减不加
     * @source 来源 mall商城
     * @param uid
     * @param pay_type 1:积分;1:钱包
     * @param minus 减少的数值 只能是负数
     * @param memo 备注
     */
    public function weiba_pay()
    {
        $pay_type = trim($this->input->post('pay_type'));
        if( ($pay_type!=1)&&($pay_type!=2)){
            exit($this->ajax_return(array('ret'=>10000,'msg'=>'参数类型错误')));
        }
        $minus = trim($this->input->post('minus'));
        if( $minus>=0 ){
            exit($this->ajax_return(array('ret'=>10000,'msg'=>'参数类型错误')));
        }

        $memo = trim($this->input->post('memo'));
        $source = trim($this->input->post('source'));
        $source_cn = $source = $source ? $source : 'mall';
        switch( $source ){
            case 'mall':
                $source_cn = '商城';
                break;
            default:;
        }
        $data = $this->get_account_info(TRUE);

        switch( $pay_type ){
            case 1:                 //积分
                if( $data['config']['credit_set'] ){
                    if( ($data['account']['credit']+$minus)<0 ){
                        exit($this->ajax_return(array('ret'=>10000,'msg'=>'您的积分余额不足')));
                    }

                    //用户积分减少
                    $this->load->model('account_model');
                    $ret = $this->account_model->where(array('id'=>$data['account']['id'],'wid'=>$this->site_id,'credit'=>$data['account']['credit']))->edit(array('credit'=>($data['account']['credit']+$minus)));
                    if( $ret ){

                        //老日志表
                        $action_data = array(
                            'uid'  => $data['account']['id'],
                            'wid'  => $this->site_id,
                            'scope' => 2,
                            'type'  => 1,
                            'sub_type' => 4,
                            'memo'  => $source_cn . $memo . '(冻结)',
                            'value' => $minus
                        );
                        $this->action_record($action_data);

                        //新日志表
                        $action_data = array();
                        $action_data['site_id'] = $this->site_id;
                        $action_data['mid'] = $data['account']['id'];
                        $action_data['username'] = $data['account']['name'];
                        $action_data['credit'] = $minus;
                        $action_data['remark'] = $source_cn . $memo . $minus."分(冻结)";
                        $action_data['dt_record'] = time();
                        $this->load->model('credit_record_model');
                        $this->credit_record_model->add($action_data);

                        //生成冻结表信息
                        $dongjie_data['site_id'] = $this->site_id;
                        $dongjie_data['uid'] = $data['account']['id'];
                        $dongjie_data['type'] = $pay_type;
                        $dongjie_data['secret'] = abs($minus);
                        $dongjie_data['add_time'] = time();
                        $this->load->model('freezing_funds_model');
                        $dongjie_id = $this->freezing_funds_model->add($dongjie_data);
                        if( $dongjie_id ){
                            exit($this->ajax_return(array('ret'=>0,'data'=>$dongjie_id)));
                        }else{
                            $this->account_model->where(array('id'=>$data['account']['id']))->set_inc( 'credit', null, abs($minus) );
                            exit($this->ajax_return(array('ret'=>10000,'msg'=>'积分冻结失败')));
                        }
                    }else{
                        exit($this->ajax_return(array('ret'=>10000,'msg'=>'扣除积分失败')));
                    }
                }else{
                    exit($this->ajax_return(array('ret'=>10000,'msg'=>'该微网站已关闭积分功能')));
                }
                break;
            case 2:                 //钱包
                if( $data['config']['money_set'] ){
                    if( ($data['account']['money']+$minus)<0 ){
                        exit($this->ajax_return(array('ret'=>10000,'msg'=>'您的钱包余额不足')));
                    }
                    //用户金额减少
                    $this->load->model('account_model');
                    $ret = $this->account_model->where(array('id'=>$data['account']['id'],'wid'=>$this->site_id,'money'=>$data['account']['money']))->edit(array('money'=>($data['account']['money']+$minus)));
                    if( $ret ){
                        //老日志表  减少金额 1 5 0
                        $action_data = array(
                            'uid'  => $data['account']['id'],
                            'wid'  => $this->site_id,
                            'scope' => 1,
                            'type'  => 5,
                            'sub_type' => 0,
                            'memo'  => $source_cn . $memo . '(冻结)',
                            'value' => $minus
                        );
                        $this->action_record($action_data);

                        //新日志表
                        $action_data = array();
                        $action_data['site_id'] = $this->site_id;
                        $action_data['mid'] = $data['account']['id'];
                        $action_data['username'] = $data['account']['name'];
                        $action_data['money'] = $minus;
                        $action_data['remark'] = $source_cn . $memo . $minus."元(冻结)";
                        $action_data['dt_record'] = time();
                        $this->load->model('money_record_model');
                        $this->money_record_model->add($action_data);

                        //生成冻结表信息
                        $dongjie_data['site_id'] = $this->site_id;
                        $dongjie_data['uid'] = $data['account']['id'];
                        $dongjie_data['type'] = $pay_type;
                        $dongjie_data['money'] = abs($minus);
                        $dongjie_data['add_time'] = time();
                        $this->load->model('freezing_funds_model');
                        $dongjie_id = $this->freezing_funds_model->add($dongjie_data);
                        if( $dongjie_id ){
                            exit($this->ajax_return(array('ret'=>0,'data'=>$dongjie_id)));
                        }else{
                            $this->account_model->where(array('id'=>$data['account']['id']))->set_inc( 'money', null, abs($minus) );
                            exit($this->ajax_return(array('ret'=>10000,'msg'=>'钱包金额冻结失败')));
                        }
                    }else{
                        exit($this->ajax_return(array('ret'=>10000,'msg'=>'钱包扣钱失败')));
                    }
                }else{
                    exit($this->ajax_return(array('ret'=>10000,'msg'=>'该微网站已关闭钱包功能')));
                }
                break;
            default :
                exit($this->ajax_return(array('ret'=>10000,'msg'=>'参数类型错误')));
        }

    }


    /**
     * 操作冻结资金
     * @param uid
     * @id 冻结资金表id
     * @action_type 1交易成功-删除资金, 2交易失败-资金回流
     * @source 来源 mall商城
     */
    public function freezing_funds()
    {
        $id = intval(trim($this->input->post('id')));
        !$id && exit($this->ajax_return(array('ret'=>10000,'msg'=>'参数类型错误')));

        $action_type = trim($this->input->post('action_type'));
        if( ($action_type!=1)&&($action_type!=2)){
            exit($this->ajax_return(array('ret'=>10000,'msg'=>'参数类型错误')));
        }

        $source = trim($this->input->post('source'));
        $source_cn = $source = $source ? $source : 'mall';
        switch( $source ){
            case 'mall':
                $source_cn = '商城';
                break;
            default:;
        }
        $data = $this->get_account_info(TRUE);

        $this->load->model('freezing_funds_model');
        $where_data['site_id'] = $this->site_id;
        $where_data['id'] = $id;
        $where_data['uid'] = $data['account']['id'];
        $record = $this->freezing_funds_model->where($where_data)->find();
        if( !$record ){
            exit($this->ajax_return(array('ret'=>10000,'msg'=>'没有找到资金流向数据')));
        }
        //var_dump($record);exit;
        switch( $action_type ){
            case 1://删除数据
                $this->freezing_funds_model->where(array('id'=>$record['id']))->delete();
                switch( $record['type'] ){
                    case 1://积分 删除
                        $this->old_log_action_type($data['account']['id'],$this->site_id,2,1,5,$source_cn . '(交易成功扣除)','-'.$record['secret']);
                        $action_data = array();
                        $action_data['site_id'] = $this->site_id;
                        $action_data['mid'] = $data['account']['id'];
                        $action_data['username'] = $data['account']['name'];
                        $action_data['credit'] = '-'.$record['secret'];
                        $action_data['remark'] = $source_cn . '-'.$record['secret'] .  "分(交易成功扣除)";
                        $action_data['dt_record'] = time();
                        $this->load->model('credit_record_model');
                        $this->credit_record_model->add($action_data);
                        exit($this->ajax_return(array('ret'=>0,'data'=>array())));
                        break;
                    case 2://金额 删除
                        $this->old_log_action_type($data['account']['id'],$this->site_id,1,6,0,$source_cn . '(交易成功扣除)','-'.$record['money']);
                        //新日志表
                        $action_data = array();
                        $action_data['site_id'] = $this->site_id;
                        $action_data['mid'] = $data['account']['id'];
                        $action_data['username'] = $data['account']['name'];
                        $action_data['money'] = '-'.$record['money'];
                        $action_data['remark'] = $source_cn . '-'.$record['money'] . "元(交易成功扣除)";
                        $action_data['dt_record'] = time();
                        $this->load->model('money_record_model');
                        $this->money_record_model->add($action_data);
                        exit($this->ajax_return(array('ret'=>0,'data'=>array())));
                        break;
                    default:;
                }
                break;
            case 2://回滚数据

                switch( $record['type'] ){
                    case 1://积分 回滚
                        //还原积分
                        $this->load->model('account_model');
                        $this->account_model->where(array('id'=>$data['account']['id']))->set_inc( 'credit', null, $record['secret'] );

                        //记录日志
                        $this->old_log_action_type($data['account']['id'],$this->site_id,2,1,6,$source_cn . '(交易失败送还积分)', $record['secret']);
                        $action_data = array();
                        $action_data['site_id'] = $this->site_id;
                        $action_data['mid'] = $data['account']['id'];
                        $action_data['username'] = $data['account']['name'];
                        $action_data['credit'] = $record['secret'];
                        $action_data['remark'] = $source_cn . $record['secret'] .  "分(交易失败送还积分)";
                        $action_data['dt_record'] = time();
                        $this->load->model('credit_record_model');
                        $this->credit_record_model->add($action_data);

                        $this->freezing_funds_model->where(array('id'=>$record['id']))->delete();
                        exit($this->ajax_return(array('ret'=>0,'data'=>array())));
                        break;
                    case 2://金额 回滚
                        //还原金额
                        $this->load->model('account_model');
                        $this->account_model->where(array('id'=>$data['account']['id']))->set_inc( 'money', null, $record['money'] );

                        //记录日志
                        $this->old_log_action_type($data['account']['id'],$this->site_id,1,7,0,$source_cn . '(交易失败送还金额)',$record['money']);
                        $action_data = array();
                        $action_data['site_id'] = $this->site_id;
                        $action_data['mid'] = $data['account']['id'];
                        $action_data['username'] = $data['account']['name'];
                        $action_data['money'] = $record['money'];
                        $action_data['remark'] = $source_cn . $record['money'] . "元(交易失败送还金额)";
                        $action_data['dt_record'] = time();
                        $this->load->model('money_record_model');
                        $this->money_record_model->add($action_data);

                        $this->freezing_funds_model->where(array('id'=>$record['id']))->delete();

                        exit($this->ajax_return(array('ret'=>0,'data'=>array())));
                        break;
                    default:;
                }

                break;
            default:;
        }

        exit($this->ajax_return(array('ret'=>10000,'msg'=>'操作失败')));
    }



    private function old_log_action_type($uid,$wid,$scope,$type,$sub_type,$memo,$value)
    {
        //老日志表
        $action_data = array(
            'uid'  => $uid,
            'wid'  => $wid,
            'scope' => $scope,
            'type'  => $type,
            'sub_type' => $sub_type,
            'memo'  => $memo,
            'value' => $value
        );
        $this->action_record($action_data);
    }


    /**
     * @param $data
     * @return object
     * 记录操作行为
     */
    private function action_record($data)
    {
        $scope = isset($data['scope']) ? $data['scope'] : 0;
        $type = isset($data['type']) ? $data['type'] : 0;
        $sub_type = isset($data['sub_type']) ? $data['sub_type'] : 0;
        $memo = isset($data['memo']) ? $data['memo'] : '';
        $data_json = isset($data['data_json']) ? $data['data_json'] : '';
        $uid =  isset($data['uid']) ? $data['uid'] : 0;
        $value = isset($data['value']) ? $data['value'] : '';
        $wid = $data['wid'];
        if($wid)
        {
            $this->load->model('model_action_record');
            $this->model_action_record->wid = $wid;
            $this->model_action_record->uid = $uid;
            $this->model_action_record->scope = $scope;
            $this->model_action_record->type = $type;
            $this->model_action_record->sub_type = $sub_type;
            $this->model_action_record->value = $value;
            $this->model_action_record->memo = $memo;
            $this->model_action_record->data_json = $data_json;
            $this->model_action_record->action_time = time();
            $this->model_action_record->ip = isset($_SERVER['REMOTE_ADDR']) ? ip2long($_SERVER['REMOTE_ADDR']) : 0;
            $this->model_action_record->browser_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
            $this->model_action_record->add();
        }
    }

}