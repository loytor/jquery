<?php
/**
 * Created by PhpStorm.
 * User: llj
 * Date: 14-8-2
 * Time: 下午2:42
 * 根据微网站用户名获取ID
 */
class GetSiteId extends API_Controller {

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $username = $this->input->get('username',true);

        switch ($this->type)
        {
            case 'yixing':
                $result = array();
                break;
            case 'alipay':
                $result = array();
                break;
            default:
                $this->load->model('user_model');
                $result = $this->user_model
                    ->select('id')
                    ->where(array('username'=>$username))
                    ->find();
                break;
        }


        if(!$result)
        {
            exit($this->ajax_return(array('ret'=>102,'msg'=>'用户不存在或已删除')));
        }
        exit($this->ajax_return(array('ret'=>0,'data'=>$result)));
    }
}