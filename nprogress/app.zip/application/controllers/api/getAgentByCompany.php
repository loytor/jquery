<?php
/**
 * Created by PhpStorm.
 * User: 111
 * Date: 14-8-7
 * Time: 下午1:57
 * 根据公司名称获取代理商信息
 */
class GetAgentByCompany extends API_Controller {

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $company = $this->input->get('company',true);
        $level = $this->input->get('level',true) ? intval($this->input->get('level',true)) : 1;

        switch ($this->type)
        {
            case 'yixing':
                $result = array();
                break;
            case 'alipay':
                $result = array();
                break;
            default:
                $this->load->model('agent_model');
                $result = $this->agent_model
                    ->select('country, province, city, type,level')
                    ->where(array('company'=>$company, 'level'=>$level))
                    ->find();
                break;
        }


        if(!$result)
        {
            exit($this->ajax_return(array('ret'=>102,'msg'=>'您所查询的代理商不存在，请确认后查询！')));
        }
        exit($this->ajax_return(array('ret'=>0,'data'=>$result)));
    }
}