<?php
class Emigrated extends MY_Controller
{
    private $wid = null;
    private $tpl_data = array();

    public function __construct()
    {
        parent::__construct();
        $this->wid = User::$user_id;
        $this->tpl_data['cur_nav'] = 'marketing';
        
        $this->load->model('model_emigrated');
        
        $this->model_emigrated->update(array('wid' => $this->wid,'end_time <'=>time()),array('status'=>2));
    }
    
    public function index()
    {
        $where_set = array(
            'is_delete' => 0,
            'wid'       => $this->wid
        );
        
        $list = $this->model_emigrated->get_all($where_set,'','','id','desc','id,title,keyword,cate_id,start_time,end_time,views,joins,status');
        $domain = $this->session->userdata('domain');//生成外链
        foreach ($list as $key=>$val){
            $list[$key]['url_view'] = 'http://'.$domain.BASE_DOMAIN.'/emigrated?id='.$val['id'].'&view=true';
        }
        $this->tpl_data['list'] = $list;
        $this->get_cate();
        $this->tpl_data['curtitle'] = '闯关列表';
        
        $this->twig->display('emigrated/index',$this->tpl_data);
    }
    
    public function add()
    {
        if( $this->input->post() ){
            $this->load->library('form_validation');
            $this->form_validation->set_rules('cate_id', '栏目', 'trim');
            $this->form_validation->set_rules('title', '闯关名称', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('keyword', '关键词', 'trim|max_length[50]');
            $this->form_validation->set_rules('start_time', '开始时间', 'trim|required|htmlspecialchars');
            $this->form_validation->set_rules('days', '答题天数', 'integer|required|greater_than_equal_to[1]|less_than_equal_to[30]');
            $this->form_validation->set_rules('ques_nums', '每天(关)题目数', 'integer|required|greater_than_equal_to[5]|less_than_equal_to[50]');
            $this->form_validation->set_rules('ques_time', '每题时长', 'integer|required|greater_than_equal_to[0]');
            $this->form_validation->set_rules('code_time', '兑奖码到期时间', 'trim');
            $this->form_validation->set_rules('reward_type', '奖励方式', 'integer|required');
            
            $this->form_validation->set_rules('img', '分享图片', 'trim|callback__check_image');
            $this->form_validation->set_rules('content', '闯关说明', 'trim|htmlspecialchars');
            $this->form_validation->set_rules('rule_content', '闯关规则', 'trim|htmlspecialchars');
            $this->form_validation->set_rules('award_content', '获奖文案', 'trim|htmlspecialchars');
            $this->form_validation->set_rules('award_no_content', '未获奖文案', 'trim|htmlspecialchars');
            if($this->form_validation->run()){
                $data_set['cate_id']    = $this->form_validation->set_value('cate_id');
                $data_set['wid']        = $this->wid;
                $data_set['title']      = $this->form_validation->set_value('title');
                $data_set['keyword']    = $this->form_validation->set_value('keyword');
                $data_set['img']        = $this->form_validation->set_value('img');
                $start_time             = $this->form_validation->set_value('start_time');
                $data_set['days']       = $this->form_validation->set_value('days'); 
                $data_set['start_time'] = strtotime($start_time);
                $data_set['end_time']   = $data_set['start_time']+($data_set['days']*24*60*60);
                $data_set['ques_nums']  = $this->form_validation->set_value('ques_nums');
                $data_set['ques_time']  = $this->form_validation->set_value('ques_time');
                
                $data_set['code_time'] = strtotime($this->form_validation->set_value('code_time'));
                if( $data_set['code_time'] && ($data_set['code_time']<=$data_set['start_time']) ){
                    $this->show_message(FALSE, '兑奖码到期时间必须大于闯关开始时间', '',1);
                }
                
                $data_set['reward_type']= $this->form_validation->set_value('reward_type');
                
                //奖励设置
                $reward_set_temp = $this->input->post('r'.$data_set['reward_type']);
                $reward_set = array();
                $max_score = intval($data_set['days']) * intval($data_set['ques_nums']);
                foreach( $reward_set_temp as $key=>$val ){
                    if( intval($val['rs'])>=0&&intval($val['re'])>=0&&$val['content'] ){
                        if( $val['rs']>$max_score ){
                            $this->show_message(FALSE, '开始分数必须小于总分数', '/emigrated/add');
                        }
                        if( $val['re']>$max_score ){
                            $this->show_message(FALSE, '结束分数必须小于等于总分数', '/emigrated/add');
                        }
                        if( $val['rs']>$val['re'] ){
                            $this->show_message(FALSE, '开始分数必须小于结束分数', '/emigrated/add');
                        }
                        if( $data_set['reward_type']==1||$data_set['reward_type']==2 ){
                            if( !is_numeric($val['content']) ){
                                $this->show_message(FALSE, '奖励内容必须是数字', '/emigrated/add');
                            }
                        }
                        $reward_set[] = $val;
                    }
                }
                $data_set['reward_set'] = json_encode($reward_set);
                
                //奖品设置  选择抽奖时，积分范围不为空，奖品设置必须要有
                $prize = array();
                if( $data_set['reward_type']==1 ){
                    if( !$reward_set ){
                        $this->show_message(FALSE, '奖励抽奖时，请填写积分范围', '/emigrated/add');
                    }
                    $prize_temp = (array)$this->input->post('prize');
                    $rate = 0;
                    foreach( $prize_temp as $val ){
                        if( ($val['name']!='')&&($val['rate']!='') ){
                            if( !preg_match('/^[0-9]*\.?[0-9]+$/', $val['rate']) ){
                                $this->show_message(FALSE, '请填写正确的中奖率', '/emigrated/add');
                            }
                            if( ($rate+=$val['rate'])>100 ){
                                $this->show_message(FALSE, '总的中奖率不能超过100%', '/emigrated/add');
                            }
                            $val['number'] = intval($val['number']);
                            $val['true_number'] = intval($val['true_number']);
                            $prize[] = $val;
                        }
                    }
                    if( !$prize ){
                        $this->show_message(FALSE, '至少设置一项奖品', '/emigrated/add');
                    }
                }
                $data_set['prize'] = json_encode($prize);
                
                $data_set['content']          = $this->form_validation->set_value('content');
                $data_set['rule_content']     = $this->form_validation->set_value('rule_content');
                $data_set['award_content']    = $this->form_validation->set_value('award_content');
                $data_set['award_no_content'] = $this->form_validation->set_value('award_no_content');
                
                $data_set['add_time'] = time();
                
                if( !$emigrated_id=$this->model_emigrated->add($data_set,true) ){
                    $this->show_message(FALSE, '添加失败', '', 1);
                }
                
                //日期表新增天数信息
                $this->load->model('model_emigrated_day');
                for( $i=0;$i<$data_set['days'];$i++ ){
                    $day_set['wid']          = $this->wid;
                    $day_set['emigrated_id'] = $emigrated_id;
                    $day_set['day']          = $data_set['start_time'] + $i*24*60*60;
                    $day_set['num_sys']      = $data_set['ques_nums'];
                    if( !$this->model_emigrated_day->add($day_set) ){
                        $this->show_message(FALSE, '分配天数时失败', '', 1);
                    }
                }
                
                //规档
                if($data_set['cate_id'] && $emigrated_id)
                {
                    $data_cate_lists['user_id']  = $this->wid;
                    $data_cate_lists['cate_id']  = $data_set['cate_id'];
                    $data_cate_lists['type']     = 'emigrated';
                    $data_cate_lists['lists_id'] = $emigrated_id;
                    $data_cate_lists['rank']     = 9999;
                    $this->load->model('model_cate_lists');
                    $this->model_cate_lists->add($data_cate_lists);
                }
                
                //自动回复关键字TODO
 /*               if( $emigrated_id && $data_set['keyword'] ){
                    $keyword_arr = explode(' ',$data_set['keyword']);
                    foreach($keyword_arr as $key=>&$keyword){
                        if( !$keyword ){
                            unset($keyword_arr[$key]);
                        }
                    }
                    $reply_data = array();
                    $reply_data['keyword'] = implode(',', $keyword_arr);
                    $reply_data['type'] = 'article';
                    $reply_data['site_id'] = $this->wid;
                    $reply_data['count_match'] = 0;
                    $reply_data['dt_add'] = $reply_data['dt_update'] = time();
                    $item_id = (string)new MongoId();
                    $reply_data['content'][$item_id] = array(
                        'id'    => $item_id,
                        'type'  => 'Emigrated',
                        'title' => $data_set['title'],
                        'image' => $data_set['img'],
                        'ref_id'=> $emigrated_id,
                        'url'   => '/emigrated?id='.$emigrated_id,
                        'rank'  => 9999
                    );
                    $this->load->library('Mongo_db');
                    $this->mongo_db->insert('reply', $reply_data);
                }*/
                
                $this->show_message(TRUE, '添加成功', '/emigrated_day/index/'.$emigrated_id);
                
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '/emigrated/add');
                }
            }
        }else{
            $this->get_cate();
            $this->token();
            $this->tpl_data['curtitle'] = '创建答题闯关';
            
            $this->twig->display('emigrated/add',$this->tpl_data);
        }
    }
    
    public function update($emigrated_id='')
    {
        $where_set = array(
            'is_delete' => 0,
            'wid'       => $this->wid,
            'id'        => $emigrated_id
        );
        $emigrated = $this->model_emigrated->get_row($where_set);
        if(!$emigrated){
            $this->show_message(FALSE, '没有找到该答题闯关', '/emigrated');
        }
        if( $emigrated['status']==0 ){
            $this->tpl_data['is_edit'] = 1;
        }else{
            $this->tpl_data['is_edit'] = 0;
        }
        //提交内容
        $this->load->library('form_validation');
        $this->form_validation->set_rules('cate_id', '栏目', 'trim');
        $this->form_validation->set_rules('title', '闯关名称', 'trim|required|max_length[50]');
        $this->form_validation->set_rules('keyword', '关键词', 'trim|max_length[50]');
        $this->form_validation->set_rules('img', '分享图片', 'trim|callback__check_image');
        
        $this->form_validation->set_rules('code_time', '兑奖码到期时间', 'trim');
        
        //$this->form_validation->set_rules('ques_nums', '每天(关)题目数', 'integer|required|greater_than_equal_to[5]|less_than_equal_to[50]');
        //$this->form_validation->set_rules('start_time', '开始时间', 'trim|required|htmlspecialchars');
        //$this->form_validation->set_rules('days', '答题天数', 'integer|required|greater_than_equal_to[1]|less_than_equal_to[30]');
        $this->form_validation->set_rules('ques_time', '每题时长', 'integer|required|greater_than_equal_to[0]');
        if( $emigrated['status']==0 ){
			$this->form_validation->set_rules('reward_type', '奖励方式', 'integer|required');
        }
        
        $this->form_validation->set_rules('content', '闯关说明', 'trim|htmlspecialchars');
        $this->form_validation->set_rules('rule_content', '闯关规则', 'trim|htmlspecialchars');
        $this->form_validation->set_rules('award_content', '获奖文案', 'trim|htmlspecialchars');
        $this->form_validation->set_rules('award_no_content', '未获奖文案', 'trim|htmlspecialchars');
        if($this->form_validation->run()){
            
            $data_set['cate_id']    = $this->form_validation->set_value('cate_id');
            $data_set['wid']        = $this->wid;
            $data_set['title']      = $this->form_validation->set_value('title');
            $data_set['keyword']    = $this->form_validation->set_value('keyword');
            $data_set['img']        = $this->form_validation->set_value('img');
            $data_set['ques_time']  = $this->form_validation->set_value('ques_time');
            
            $data_set['code_time'] = strtotime($this->form_validation->set_value('code_time'));
            if( $data_set['code_time'] && ($data_set['code_time']<=$emigrated['start_time']) ){
                $this->show_message(FALSE, '兑奖码到期时间必须大于闯关开始时间', '',1);
            }
            
            $data_set['ques_nums']  = $emigrated['ques_nums'];
            if( $emigrated['status']==0 ){
                $data_set['reward_type']= $this->form_validation->set_value('reward_type');
            
                //奖励设置
                $reward_set_temp = $this->input->post('r'.$data_set['reward_type']);
                $reward_set = array();
                $max_score = intval($emigrated['days']) * intval($data_set['ques_nums']);
                foreach( $reward_set_temp as $key=>$val ){
                    if( intval($val['rs'])>=0&&intval($val['re'])>=0&&$val['content'] ){
                        if( $val['rs']>=$max_score ){
                            $this->show_message(FALSE, '开始分数必须小于总分数', '',1);
                        }
                        if( $val['re']>$max_score ){
                            $this->show_message(FALSE, '结束分数必须小于等于总分数', '',1);
                        }
                        if( $val['rs']>=$val['re'] ){
                            $this->show_message(FALSE, '开始分数必须小于结束分数', '',1);
                        }
                        if( $data_set['reward_type']==1||$data_set['reward_type']==2 ){
                            if( !is_numeric($val['content']) ){
                                $this->show_message(FALSE, '奖励内容必须是数字', '',1);
                            }
                        }
                        $reward_set[] = $val;
                    }
                }
                $data_set['reward_set'] = json_encode($reward_set);
            
                //奖品设置  选择抽奖时，积分范围不为空，奖品设置必须要有
                $prize = array();
                if( $data_set['reward_type']==1 ){
                    if( !$reward_set ){
                        $this->show_message(FALSE, '奖励抽奖时，请填写积分范围', '',1);
                    }
                    $prize_temp = (array)$this->input->post('prize');
                    $rate = 0;
                    foreach( $prize_temp as $val ){
                        if( ($val['name']!='')&&($val['rate']!='') ){
                            if( !preg_match('/^[0-9]*\.?[0-9]+$/', $val['rate']) ){
                                $this->show_message(FALSE, '请填写正确的中奖率', '',1);
                            }
                            if( ($rate+=$val['rate'])>100 ){
                                $this->show_message(FALSE, '总的中奖率不能超过100%', '',1);
                            }
                            $val['number'] = intval($val['number']);
                            $val['true_number'] = intval($val['true_number']);
                            $prize[] = $val;
                        }
                    }
                    if( !$prize ){
                        $this->show_message(FALSE, '至少设置一项奖品', '',1);
                    }
                }
                $data_set['prize'] = json_encode($prize);
            }
            
            $data_set['content']          = $this->form_validation->set_value('content');
            $data_set['rule_content']     = $this->form_validation->set_value('rule_content');
            $data_set['award_content']    = $this->form_validation->set_value('award_content');
            $data_set['award_no_content'] = $this->form_validation->set_value('award_no_content');
            
            
            if( false===$this->model_emigrated->update($where_set,$data_set) ){
                $this->show_message(FALSE, '修改失败', '',1);
            }else{
                //归档操作
                if ($emigrated['cate_id'] != $data_set['cate_id']) {
                    $this->load->model('model_cate_lists');
                    if ($data_set['cate_id']) {
                        $data_cate_lists['user_id'] = $this->wid;
                        $data_cate_lists['cate_id'] = $data_set['cate_id'];
                        $data_cate_lists['type'] = 'emigrated';
                        $data_cate_lists['lists_id'] = $emigrated_id;
                        $data_cate_lists['rank'] = 9999;
                        $this->model_cate_lists->add($data_cate_lists);
                    }
                    if ($emigrated['cate_id']) {
                        $del_catelists_set['user_id'] = $this->wid;
                        $del_catelists_set['cate_id'] = $emigrated['cate_id'];
                        $del_catelists_set['type'] = 'emigrated';
                        $del_catelists_set['lists_id'] = $emigrated_id;
                        $this->model_cate_lists->delete($del_catelists_set);
                    }
                }

                //自动回复关键字
/*                if( $emigrated_id ){
                    //查找之前的自动回复内容
                    $this->load->model('model_reply');
                    if( $reply_emigrated=$this->model_reply->emigrated_get($emigrated_id) ){
                        //之前就存在该回复关键字
                        if( $data_set['keyword'] ){//修改
                            $keyword_arr = explode(' ',$data_set['keyword']);
                            foreach($keyword_arr as $key=>&$keyword){
                                if( !$keyword ){
                                    unset($keyword_arr[$key]);
                                }
                            }
                            $reply_set['keyword'] = implode(',', $keyword_arr);
                            $reply_set['type']    = 'emigrated';
                            $reply_set['user_id'] = $this->wid;
                            $domain = $this->session->userdata('domain');//生成 外链
                            $reply_set['content'] = json_encode(array(
                                    'id'    => $emigrated_id,
                                    'title' => $data_set['title'],
                                    'image' => $data_set['img'],
                                    'url'   => 'http://'.$domain.BASE_DOMAIN.'/emigrated?id='.$emigrated_id,
                                    'rank'  => 9999
                                ));
                            $this->model_reply->update(array('id'=>$reply_emigrated['reply_id']),$reply_set);
                        }else{//删除
                            $this->model_reply->emigrated_delete($reply_emigrated['reply_id'],$emigrated_id);
                            $this->model_reply->delete(array('id'=>$reply_emigrated['reply_id']));
                        }
                    }else{//添加
                        if( $data_set['keyword'] ){
                            $keyword_arr = explode(' ',$data_set['keyword']);
                            foreach($keyword_arr as $key=>&$keyword){
                                if( !$keyword ){
                                    unset($keyword_arr[$key]);
                                }
                            }
                            $reply_set['keyword'] = implode(',', $keyword_arr);
                            $reply_set['type']    = 'emigrated';
                            $reply_set['user_id'] = $this->wid;
                            $domain = $this->session->userdata('domain');//生成 外链
                            $reply_set['content'] = json_encode(array(
                                    'id'    => $emigrated_id,
                                    'title' => $data_set['title'],
                                    'image' => $data_set['img'],
                                    'url'   => 'http://'.$domain.BASE_DOMAIN.'/emigrated?id='.$emigrated_id,
                                    'rank'  => 9999
                                ));
                            $this->load->model('model_reply');
                            $reply_id = $this->model_reply->add($reply_set);
                            if ( $reply_id ) {
                                $this->model_reply->emigrated_add($reply_id, $emigrated_id, 9999);
                            }
                        }
                    }

                    if( !$data_set['keyword'] ){

                    }
                }else{

                }*/

                $this->show_message(TRUE, '修改成功', '/emigrated');
            }
        }else{
            $errors = validation_errors();
            if ($errors) {
                $this->show_message(FALSE, $errors, '',1);
            }
        }
        
        foreach(array('reward_set','prize') as $value)
        {
            if(isset($emigrated[$value]))
            {
                $emigrated[$value] = json_decode($emigrated[$value],true);
            }
        }
        $this->tpl_data['info'] = $emigrated;
        
        $this->get_cate();
        $this->token();
        $this->tpl_data['curtitle'] = '修改答题闯关';
        
        $this->twig->display('emigrated/update',$this->tpl_data);
    }
    
    //删除闯关
    public function delete($emigrated_id='')
    {
        $where_set = array(
            'is_delete' => 0,
            'wid'       => $this->wid,
            'id'        => $emigrated_id
        );
        $emigrated = $this->model_emigrated->get_row($where_set);
        if(!$emigrated){
            $this->show_message(FALSE, '没有找到该答题闯关', '/emigrated');
        }

        //删除自动回复
/*        $this->load->model('model_reply');
        if( $reply_emigrated=$this->model_reply->emigrated_get($emigrated_id) ){
            $this->model_reply->emigrated_delete($reply_emigrated['reply_id'],$emigrated_id);
            $this->model_reply->delete(array('id'=>$reply_emigrated['reply_id']));
        }*/
        
        //删除归档TODO
        if( $emigrated['cate_id'] ){
            $this->load->model('model_cate_lists');
            $del_catelists_set['user_id'] = $this->wid;
            $del_catelists_set['cate_id'] = $emigrated['cate_id'];
            $del_catelists_set['type'] = 'emigrated';
            $del_catelists_set['lists_id'] = $emigrated['id'];
            $this->model_cate_lists->delete($del_catelists_set);
        }

        $this->model_emigrated->update($where_set,array('is_delete'=>1,'keyword'=>''));
        $this->show_message(TRUE, '删除成功', '/emigrated');
    }
    
    public function set_status($emigrated_id='')
    {
        $where_set = array(
            'is_delete' => 0,
            'wid'       => $this->wid,
            'id'        => $emigrated_id
        );
        $emigrated = $this->model_emigrated->get_row($where_set,'id,status,reward_type,reward_set,prize');
        if(!$emigrated){
            $this->show_message(FALSE, '没有找到该答题闯关', '/emigrated');
        }
        if( $emigrated['reward_type']==0 ){
            $this->show_message(FALSE, '该闯关的奖励内容未设定', '/emigrated/update/'.$emigrated['id']);
        }
        $status = 0;
        if( $emigrated['status']==0 ){
            
            //判断是否有抽奖设置
            if( $emigrated['reward_type']==1 ){
                $reward_set = json_decode($emigrated['reward_set'],true);
                $prize = json_decode($emigrated['prize'],true);
                if( !$reward_set || !$prize ){
                    $this->show_message(FALSE, '该闯关的抽奖内容未设定', '/emigrated/update/'.$emigrated['id']);
                }
            }
            $status = 1;
        }else if( $emigrated['status']==1 ){
            $status = 2;
        }else{
            $this->show_message(FALSE, '非法操作', '/emigrated');
        }
        $this->model_emigrated->update($where_set,array('status'=>$status));
        $this->show_message(TRUE, '修改成功', '/emigrated');
    }
    
    //奖励统计
    public function reward_statistics()
    {
        $emigrated_id = intval($this->input->get('id'));
        $where_set = array(
            'is_delete' => 0,
            'wid'       => $this->wid,
            'id'        => $emigrated_id
        );
        $emigrated = $this->model_emigrated->get_row($where_set);
        if(!$emigrated){
            $this->show_message(FALSE, '没有找到该闯关', '/emigrated');
        }
        $this->tpl_data['emigrated_id'] = $emigrated['id'];
        $this->tpl_data['emigrated_code_time'] = $emigrated['code_time'];
        $this->tpl_data['emigrated_now_time'] = time();
        $this->load->model('model_emigrated_reward_record');
        $where_user = array(
            'emigrated_reward_record.wid'       => $this->wid,
            'emigrated_reward_record.eid'       => $emigrated['id'],
            'emigrated_reward_record.reward_type' => $emigrated['reward_type'],
            'emigrated_reward_record.flag'      => 1
        );
        if( $emigrated['reward_type']==1 ){//抽奖
            $where_user['lottery_type'] = 0;
        }
        
        
        $name   = $this->input->get_post('name');
        $mobile = $this->input->get_post('mobile');
        $code   = $this->input->get_post('code');
        
        $search = array(); $where = array(); $like = array(); $is_where = 0;
        ($search['code'] = $code) && $like['emigrated_reward_record.code'] = $code;
        ($search['mobile'] = $mobile) && $like['emigrated_reward_record.mobile'] = $mobile;
        ($search['name'] = $name) && $like['emigrated_reward_record.name'] = $name;
        $search_route = '';
        if( $where||$like ){
            foreach( $search as $key=>$val ){
                if( $val ){
                    $search_route .= '&'.$key.'='.$val;
                }
            }
        }
        $this->tpl_data['search'] = $search;
        
        
        $this->load->library('pagination');
        $pagination_config = array(
            'base_url'      => '/emigrated/reward_statistics?id='.$emigrated['id'].$search_route,
            'total_rows'    => $this->model_emigrated_reward_record->all_user($where_user,$like,0,0,true),
            'per_page'      => 15,
            'page_query_string' => TRUE
        );
        $this->pagination->initialize($pagination_config);
        $this->tpl_data['pagination'] = $this->pagination->create_links();
        $per_page = $pagination_config['per_page'];
        $now_page = (int)$this->input->get('per_page') ? (int)$this->input->get('per_page') : 1;
        $this->tpl_data['per_page'] = $per_page;
        $this->tpl_data['now_page'] = $now_page;
        $start = ($now_page-1)*$per_page;
        $this->tpl_data['total_rows'] = $pagination_config['total_rows'];
        
        $this->load->model('model_emigrated_record');
        $list = $this->model_emigrated_reward_record->all_user($where_user,$like,$start,$per_page);
        foreach ( $list as $key=>$val ){
            $total_score = $this->model_emigrated_record->get_one(array(
                'wid' => $this->wid,
                'eid' => $emigrated['id'],
                'uid' => $val['uid']
            ),'total_score','total_score');
            $list[$key]['total_score'] = $total_score;
        }
        $this->tpl_data['list'] = $list;
        
        $this->tpl_data['curtitle'] = '闯关奖励统计';
        
        $this->twig->display('emigrated/reward_statistics',$this->tpl_data);
    }
    
    //更改奖励状态
    public function exchange_reward($record_id='')
    {
        $this->load->model('model_emigrated_reward_record');
        $where_set = array(
            'wid'       => $this->wid,
            'id'        => $record_id
        );
        $record = $this->model_emigrated_reward_record->get_row($where_set);
        if(!$record){
            $this->show_message(FALSE, '没有该中奖记录', '',1);
        }
        
        $emigrated = $this->model_emigrated->get_row(array('is_delete' => 0,'wid'=> $this->wid,'id'=> $record['eid']));
        if(!$emigrated){
            $this->show_message(FALSE, '没有找到该闯关', '',1);
        }
        if( $emigrated['code_time']&&(time()>$emigrated['code_time']) ){
            $this->show_message(FALSE, '该中奖码已过期', '',1);
        }
        
        $this->model_emigrated_reward_record->update($where_set,array('status'=>1));
        $this->show_message(TRUE, '修改成功', '',1);
    }
    
    
    public function export()
    {
        $emigrated_id = intval($this->input->get('id'));
        $where_set = array(
            'is_delete' => 0,
            'wid'       => $this->wid,
            'id'        => $emigrated_id
        );
        $emigrated = $this->model_emigrated->get_row($where_set);
        if(!$emigrated){
            $this->show_message(FALSE, '没有找到该闯关', '/emigrated');
        }
        $this->tpl_data['emigrated_id'] = $emigrated['id'];
        $this->load->model('model_emigrated_reward_record');
        $where_user = array(
            'emigrated_reward_record.wid'       => $this->wid,
            'emigrated_reward_record.eid'       => $emigrated['id'],
            'emigrated_reward_record.reward_type' => $emigrated['reward_type'],
            'emigrated_reward_record.flag'      => 1
        );
        if( $emigrated['reward_type']==1 ){//抽奖
            $where_user['lottery_type'] = 0;
        }
        
        
        $name   = $this->input->get_post('name');
        $mobile = $this->input->get_post('mobile');
        
        $search = array(); $where = array(); $like = array(); $is_where = 0;
        ($search['mobile'] = $mobile) && $like['account.mobile'] = $mobile;
        ($search['name'] = $name) && $like['account.name'] = $name;
        $search_route = '';
        if( $where||$like ){
            foreach( $search as $key=>$val ){
                if( $val ){
                    $search_route .= '&'.$key.'='.$val;
                }
            }
        }
        $this->tpl_data['search'] = $search;
        $this->load->model('model_emigrated_record');
        $list = $this->model_emigrated_reward_record->all_user($where_user,$like);
        foreach ( $list as $key=>$val ){
            $total_score = $this->model_emigrated_record->get_one(array(
                'wid' => $this->wid,
                'eid' => $emigrated['id']
            ),'total_score');
            $list[$key]['total_score'] = $total_score;
            $list[$key]['add_time'] = date('Y-m-d',$val['add_time']);
            if( $val['reward_type']==2 ){
                $list[$key]['prize_name'] = $val['prize_name'].' 积分';
            }
            if( $val['status']==0 ){
                $list[$key]['status'] = '未兑奖';
                if( time()>$emigrated['code_time'] ){
                    $list[$key]['status'] .= '(已过期)';
                }
            }else if( $val['status']==1 ){
                $list[$key]['status'] = '已兑奖';
            }
        }
        $this->tpl_data['list'] = $list;
        
        
        $fields = array(
            'name'=>'用户名',
            'code'=>'中奖码',
            'mobile'=>'手机号',
            'add_time'=>'获得时间',
            'prize_name'=>'奖品',
            'total_score' => '总得分',
            'status' => '是否兑换'
        );
        $this->excel_export('答题闯关奖励信息列表', '中奖信息', $fields, $list);
    }
    
    //获取所有栏目
    private function get_cate()
    {
        //获取所有栏目 归档
        $cate_arr = array();
        $this->load->model('model_cate');
        $_cate_arr = $this->model_cate->get_all(array('user_id' =>$this->wid),'','','id','asc','id,cate_name');
        foreach ($_cate_arr as $_cate) {
            $cate_arr[$_cate['id']] = $_cate;
        }
        $this->tpl_data['cate_arr'] = $cate_arr;
    }
    //token
    private function token()
    {
        $this->load->library('encrypt');
        $token_data = array('user_id' => $this->wid, 'time' => time());
        $this->tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
    }
    
    //检查图片格式
    public function _check_image($image) {
        if ($image) {
            if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
                $this->form_validation->set_message('_check_image', '图片地址格式错误');
                return FALSE;
            }
        }
        return TRUE;
    }

}