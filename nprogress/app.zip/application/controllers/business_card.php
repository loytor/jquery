<?php

class Business_card extends MY_Controller
{
    private $wid = '';
    private $address_list = array();//分店
    private $tpl_data = array();
    private $bcard_config = array();//微名片配置
    
    protected $app_key = '5318162aac6f0086';
    protected $app_secret = '0c28536510e0b0b429750f478222d549';
    
    public function __construct()
    {
        parent::__construct();
        $this->wid = User::$user_id;
        $this->load->model('model_bcard');
        $this->load->model('model_bcard_config');
    }
    
    public function index()
    {
        //读取基本配置
        $this->get_bcard_config();
        
        $this->tpl_data['config'] = array();
        $this->tpl_data['custom'] = array();
        if( $this->bcard_config ){
            foreach( $this->bcard_config['config'] as $val ){
                if( $val['type']==1 ){
                    $this->tpl_data['config'][$val['name']] = $val['value'];
                }else if( $val['type']==2 ){
                    $this->tpl_data['custom'][] = $val;
                }
            }
        }
        $this->tpl_data['last_num'] = 3-count($this->tpl_data['custom']);
        
        if( $this->input->post() ){
            $this->form_validation->set_rules('company_id', '默认单位', 'trim|required');
            $this->form_validation->set_rules('bg_img', '背景', 'trim|required');
            if ($this->form_validation->run()) {
                
                $save_data['wid']        = $this->wid;
                $save_data['company_id'] = $this->input->post('company_id');
                $save_data['bg_img']     = $this->form_validation->set_value('bg_img');
                $save_data['behind_url'] = trim($this->input->post('behind_url'));
                $save_data['tpl']        = $this->input->post('bcard_tpl');
                
                $config = $this->create_config();
                $save_data['config']     = json_encode($config);

                if( $this->tpl_data['bcard_config'] ){//更新
                    if( false===$this->model_bcard_config->update(array('wid'=>$this->wid),$save_data) ){
                        $this->show_message(FALSE, '保存失败', '',1);
                    }else{
                        $this->show_message(FALSE, '保存成功', '/business_card');
                    }
                }else{//添加
                    $save_data['add_time']= time();
                    if($this->model_bcard_config->add($save_data,true)){
                        $this->show_message(FALSE, '保存成功', '/business_card');
                    }else{
                        $this->show_message(FALSE, '保存失败', '',1);
                    }
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '',1);
                }
            }
        }else{
            $this->address();
            $this->token();
            
            //获取模版
            $this->load->config('tpl');
            $config_tpl = $this->config->item('bcard_tpl');
            $this->tpl_data['bcard_tpl'] = $config_tpl;
        }
        
        $this->twig->display('business_card/index',$this->tpl_data);
    }
    
    
    //生成配置
    private function create_config()
    {
        $config = array();
        //系统字段
        $m_config = $this->input->post('m_config');
        /*ksort($m_config['name']);
        ksort($m_config['value']);*/
        if( isset($m_config['name'])&&$m_config['name'] ){
            foreach( $m_config['name'] as $key=>$val ){
                if( $val&&$m_config['value'][$key] ){
                    $config[] = array(
                        'name'  => $val,
                        'value' => $m_config['value'][$key],
                        'type'  => 1,
                        'sele'  => 1
                    );
                }
            }
        }
        
        //自定义字段
        $m_custom = $this->input->post('m_custom') ? $this->input->post('m_custom') : array();
        $i = 1;
        if( isset($m_custom['value'])&&$m_custom['value'] ){
            foreach( $m_custom['value'] as $key=>$val ){
                if( $val ){
                    if( mb_strlen($val)>10 ){
                        $this->show_message(false, '字段名请不要超过10个字', '',1);
                    }
                    $sele = 0;
                    if( isset($m_custom['name'][$key]) ){
                        $sele = 1;
                    }
                    $config[] = array(
                        'name'  => 'm_custom'.$i,
                        'value' => $val,
                        'type'  => 2,
                        'sele'  => $sele
                    );
                    $i++;
                }
            }
        }
        
        return $config;
    }
    
    //微名片列表
    public function bcard_list()
    {   
        $name   = $this->input->get_post('name');
        $code   = $this->input->get_post('code');
        $search = array(); $where = array(); $like = array();
        ($search['name'] = $name) && $like['bcard.name'] = $name;
        ($search['code'] = $code) && $like['bcard.code'] = $code;
        $search_route = '';
        if( $where||$like ){
            foreach( $search as $key=>$val ){
                if( $val ){
                    $search_route .= '&'.$key.'='.$val;
                }
            }
        }
        $this->tpl_data['search'] = $search;
        
        $where['wid'] = $this->wid;
        
        $this->load->library('pagination');
        $pagination_config = array(
            'base_url'      => '/business_card/bcard_list?1=1'.$search_route,
            'total_rows'    => $this->model_bcard->get_list($where,$like,0,0,true),
            'per_page'      => 15,
            'page_query_string' => TRUE
        );
        $this->pagination->initialize($pagination_config);
        $this->tpl_data['pagination'] = $this->pagination->create_links();
        $per_page = $pagination_config['per_page'];
        $now_page = (int)$this->input->get('per_page') ? (int)$this->input->get('per_page') : 1;
        $start = ($now_page-1)*$per_page;
        $this->tpl_data['per_page'] = $per_page;
        $this->tpl_data['now_page'] = $now_page;
        $this->tpl_data['total_rows'] = $pagination_config['total_rows'];
        
        $list = $this->model_bcard->get_list($where,$like,$start,$per_page);
        foreach( $list as $key=>$val ){
            $config = $this->get_bcard_profile($val['id']);
            $list[$key]['config'] = $config;
        }
        $this->tpl_data['list'] = $list;
        
        
        $this->tpl_data['type_info'] = '微名片列表';
        
        $this->twig->display('business_card/bcard_list',$this->tpl_data);
    }
    
    //添加微名片
    public function add()
    {
        //读取基本配置
        $this->get_bcard_config();
        if( !$this->tpl_data['bcard_config'] ){
            $this->show_message(FALSE, '请先设置微名片基本配置', '/business_card/index');
        }
        //基本配置字段格式化
        $m_config = array();
        foreach( $this->tpl_data['bcard_config']['config'] as $val ){
            if( $val['sele']==1 ){
                $m_config[] = array(
                    'name'  => $val['name'],
                    'value' => $val['value']
                );
            }
        }
        $this->tpl_data['m_config'] = $m_config;
        
        //默认地址
        $base_address = '';
        $this->address();
        foreach( $this->tpl_data['address_list'] as $val ){
            if( $val['id']==$this->tpl_data['bcard_config']['company_id'] ){
                $base_address = $val['address'];
                break;
            }
        }
        $this->tpl_data['base_address'] = $base_address;
        $this->tpl_data['addresss'] = json_encode($this->tpl_data['address_list']);
        
        if( $this->input->post() ){
            
            $this->form_validation->set_rules('name', '名片姓名', 'trim|required|max_length[20]');
            $this->form_validation->set_rules('code', '名片编号', 'trim|required|max_length[20]');
            $this->form_validation->set_rules('avatar', '名片头像', 'trim|callback__check_image');
            $this->form_validation->set_rules('company_id', '公司', 'trim|required');
            $this->form_validation->set_rules('background', '背景', 'trim|required');
            if ($this->form_validation->run()) {
                
                $save_data['wid']  = $this->wid;
                $save_data['name'] = $this->form_validation->set_value('name');
                $save_data['code'] = $this->form_validation->set_value('code');
                $save_data['avatar'] = $this->form_validation->set_value('avatar');
                $save_data['company_id'] = $this->form_validation->set_value('company_id');
                $save_data['bg_img'] = $this->form_validation->set_value('background');
                $save_data['add_time'] = time();
                
                //编号检查唯一性
                if( !$this->model_bcard->check_code($this->wid,$save_data['code']) ){
                    $this->show_message(FALSE, '已存在该编号', '',1);
                }
                
                $res = $this->check_bcard_profile($this->tpl_data['m_config']);
                if( $res['res']==0 ){
                    $this->show_message(FALSE, $res['msg'], '',1);
                }
                $save_config = $res['data'];
                if( $save_config ){
                    //保存到mysql的基本数据
                    if( $bcard_id=$this->model_bcard->add($save_data,true) ){
                    }else{
                        $this->show_message(FALSE, '添加失败', '',1);
                    }
                    //保存到mongodb的数据
                    $this->save_bcard_profile($save_config,$bcard_id);
                    
                    //关键字回复
                    //$this->save_keyword($save_data['name'], $save_data['code'], $bcard_id);
                    
                    //保存二维码
                    $qrcode_img = $this->qrcode($bcard_id);
                    $this->model_bcard->update(array('id'=>$bcard_id),array('qrcode_img'=>$qrcode_img),true);

                    $this->show_message(true, '添加成功', '/business_card/bcard_list');
                }else{
                    $this->show_message(FALSE, '非法提交', '',1);
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '',1);
                }
            }
        }else{
            $this->token();
            $this->tpl_data['type_info'] = '添加微名片';
            
            $this->twig->display('business_card/add',$this->tpl_data);
        }
    }
    
    
    public function update($bcard_id='')
    {
        $bcard = $this->model_bcard->get_row(array('id'=>$bcard_id,'wid'=>$this->wid));
        if( !$bcard ){
            $this->show_message(FALSE, '非法提交', '',1);
        }
        $bcard['config'] = $this->get_bcard_profile($bcard['id']);
        $this->tpl_data['bcard'] = $bcard;

        /***************************************************/
        //读取基本配置
        $this->get_bcard_config();
        if( !$this->tpl_data['bcard_config'] ){
            $this->show_message(FALSE, '请先设置微名片基本配置', '/business_card/index');
        }
        //基本配置字段格式化
        $m_config = array();
        foreach( $this->tpl_data['bcard_config']['config'] as $val ){
            if( $val['sele']==1 ){
                $m_config[] = array(
                    'name'  => $val['name'],
                    'value' => $val['value']
                );
            }
        }
        $this->tpl_data['m_config'] = $m_config;
        
        //默认地址
        $base_address = '';
        $this->address();
        foreach( $this->tpl_data['address_list'] as $val ){
            if( $val['id']==$bcard['company_id'] ){
                $base_address = $val['address'];
                break;
            }
        }
        $this->tpl_data['base_address'] = $base_address;
        $this->tpl_data['addresss'] = json_encode($this->tpl_data['address_list']);
        /***************************************************/
        
        if( $this->input->post() ){
            $this->form_validation->set_rules('name', '名片姓名', 'trim|required|max_length[20]');
            $this->form_validation->set_rules('code', '名片编号', 'trim|required|max_length[20]');
            $this->form_validation->set_rules('avatar', '名片头像', 'trim|callback__check_image');
            $this->form_validation->set_rules('company_id', '公司', 'trim|required');
            $this->form_validation->set_rules('background', '背景', 'trim|required');
            if ($this->form_validation->run()) {
                
                $save_data['wid']  = $this->wid;
                $save_data['name'] = $this->form_validation->set_value('name');
                $save_data['code'] = $this->form_validation->set_value('code');
                $save_data['avatar'] = $this->form_validation->set_value('avatar');
                $save_data['company_id'] = $this->form_validation->set_value('company_id');
                $save_data['bg_img'] = $this->form_validation->set_value('background');
                $save_data['add_time'] = time();
                
                //编号检查唯一性
                if( !$this->model_bcard->check_code($this->wid,$save_data['code'],$bcard['id']) ){
                    $this->show_message(FALSE, '已存在该编号', '',1);
                }
                
                $res = $this->check_bcard_profile($this->tpl_data['m_config']);
                if( $res['res']==0 ){
                    $this->show_message(FALSE, $res['msg'], '',1);
                }
                $save_config = $res['data'];
                if( $save_config ){
                    //保存到mysql的基本数据
                    if( false===$this->model_bcard->update(array('id'=>$bcard['id']),$save_data,true) ){
                        $this->show_message(FALSE, '修改失败', '',1);
                    }
                    
                    //保存到mongodb的数据
                    $this->save_bcard_profile($save_config,$bcard['id'],false);
                    
                    //关键字回复
/*                    $this->load->model('model_reply');
                    if( $reply_bcard=$this->model_reply->bcard_get($bcard['id']) ){//更新
                        if( $bcard['code']!=$save_data['code'] ){//更新
                            $reply_set['keyword'] = $save_data['code'];
                            $this->model_reply->update(array('id'=>$reply_bcard['reply_id']),$reply_set);
                        }
                    }else{//添加
                        $this->save_keyword($save_data['name'], $save_data['code'], $bcard['id']);
                    }*/
                    
                    //保存二维码
                    $qrcode_img = $this->qrcode($bcard['id']);
                    $this->model_bcard->update(array('id'=>$bcard['id']),array('qrcode_img'=>$qrcode_img),true);
                    
                    $this->show_message(true, '修改成功', '/business_card/bcard_list');
                }else{
                    $this->show_message(FALSE, '非法提交', '',1);
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '',1);
                }
            }
        }else{
            $this->token();
            $this->tpl_data['type_info'] = '修改微名片';
            
            $this->twig->display('business_card/update',$this->tpl_data);
        }
    }
    
    //删除微名片
    public function delete($bcard_id='')
    {
        $bcard_id = (int)$bcard_id;
        $bcard = $this->model_bcard->get_row(array('id'=>$bcard_id,'wid'=>$this->wid));
        if( !$bcard ){
            $this->show_message(FALSE, '非法提交', '/business_card/bcard_list');
        }
        
        //删除自动回复
/*        $this->load->model('model_reply');
        if( $reply_bcard=$this->model_reply->bcard_get($bcard_id) ){
            $this->model_reply->bcard_delete($reply_bcard['reply_id'],$bcard_id);
            $this->model_reply->delete(array('id'=>$reply_bcard['reply_id']));
        }*/
        
        $this->load->library('Mongo_db');
        if( !$this->model_bcard->delete(array('id'=>$bcard_id)) ){
            $this->show_message(FALSE, '删除失败', '/business_card/bcard_list');exit;
        }
        $res = $this->mongo_db->where(array('wid'=>$this->wid,'bcard_id'=>$bcard_id))->delete('bcard_profile');
        $this->show_message(FALSE, '删除成功', '/business_card/bcard_list');
    }

    //生成名片二维码
    private function qrcode($bcard_id)
    {
        $bcard = $this->model_bcard->get_row(array('id'=>$bcard_id,'wid'=>$this->wid));
        if( !$bcard ){
            $this->show_message(FALSE, '非法提交', '',1);
        }
        $config = $this->get_bcard_profile($bcard['id']);
        
        $port = isset($config["m_port"]) ? $config["m_port"] : '';
        $tel  = isset($config["m_mobile"]) ? $config["m_mobile"] : '';
        $email = isset($config["m_email"]) ? $config["m_email"] : '';
        
        $company = '';
        $address = $this->address();
        foreach( $address as $val ){
            if( $val['id']==$bcard['company_id'] ){
                $company = $val['name'];
                $address_t = $val['address'];
            }
        }

        $url='BEGIN:VCARD
VERSION:3.0
FN:'.$bcard["name"].'
TITLE:'.$port.'
TEL:'.$tel.'
EMAIL:'.$email.'
ORG:'.$company.'
ADR;WORK:'.$address_t.'
END:VCARD';
        
        $bcard_id = abs(intval($bcard_id));
        $sbcard_id = sprintf("%09d", $bcard_id);
        $dir1 = substr($sbcard_id, 0, 3);
        $dir2 = substr($sbcard_id, 3, 2);
        $dir3 = substr($sbcard_id, 5, 4);
        
        $this->load->library('Qrcode_make');
        if( !is_dir(FCPATH.'images/temp') ){
            mkdir(FCPATH.'images/temp',0777,true);
        }
        $native_img = FCPATH.'images/temp/bcard_'.$bcard_id.'.png';
        $this->qrcode_make->make($url,$native_img);
        return $this->rest_upload($native_img,'images/'.$this->wid.'/'.$dir1 . '/' . $dir2 . '/' . $dir3.'/','bcard_'.$bcard_id.'.png');
    }
    
    /**
     * @name 上传到图片服务器,并返回图片相对路径
     * @param $image
     */
    private function rest_upload($full_path,$upload_path='',$image_path='')
    {
        $this->load->library('rest', array(
            'server' => "http://".IMAGE_SERVER."/api",
            'app_key' => $this->app_key,
            'secret_key' => $this->app_secret,
        ));

        $data = array(
            'img' => '@'.$full_path,
            'upload_path' => $upload_path,
            'img_name'  => $image_path
        );
        $result = $this->rest->post('upload/img', $data);
        @unlink($full_path);
        //$this->rest->debug();
        if(isset($result['error'])) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => $result['error']));
            exit;
        } else {
            return $result['img'];
        }
    }
    
    //保存自动回复
/*    private function save_keyword($name,$keyword,$bcard_id)
    {
        $reply_set['keyword'] = $keyword;
        $reply_set['type']    = 'bcard';
        $reply_set['user_id'] = $this->wid;
        $domain = $this->session->userdata('domain');//生成 外链
        $reply_set['content'] = json_encode(array(
            'id'    => $bcard_id,
            'title' => $name.'的名片',
            'image' => '',
            'url'   => 'http://'.$domain.BASE_DOMAIN.'/business_card?id='.$bcard_id,
            'rank'  => 9999
        ));
        $this->load->model('model_reply');
        $reply_id = $this->model_reply->add($reply_set);
        if ( $reply_id ) {
            $this->model_reply->bcard_add($reply_id, $bcard_id, 9999);
        }
    }*/
    
    //检查名片信息字段
    private function check_bcard_profile($m_config)
    {
        $save_data = array();
        foreach( $m_config as $val ){
            $temp = $this->input->post($val['name']);
            if( $val['name']=='m_address' ){
                /*$address = $this->input->post('m_address');
                if( !$address ){
                    return array('res'=>0,'msg'=>'请先完善分店管理的地址信息');
                }
                if( mb_strlen($temp)>50 ){
                    return array('res'=>0,'msg'=>$val['value'].'最多50个字');
                }*/
            }elseif( $val['name']=='m_mobile' ){
                $m_mobile = $this->input->post('m_mobile');
                if( !$m_mobile ){
                    return array('res'=>0,'msg'=>'请填写手机号码');
                }
            }elseif( $val['name']=='m_email' ){
                $m_email = $this->input->post('m_email');
                if( $m_email ){
                    if(preg_match("/^[\w\d]+[\w\d-.]*@[\w\d-.]+\.[\w\d]{2,10}$/i",$m_email)){
                    }else{
                        return array('res'=>0,'msg'=>'邮箱格式错误');
                    }
                }
            }elseif( $val['name']=='m_qq' ){
                $m_qq = $this->input->post('m_qq');
                if( $m_qq ){
                    if(preg_match("/^[1-9][0-9]{4,11}$/",$m_qq)){
                    }else{
                        return array('res'=>0,'msg'=>'QQ号码格式错误');
                    }
                }
            }elseif( $val['name']=='m_sign' ){
                if( mb_strlen($temp)>30 ){
                    return array('res'=>0,'msg'=>$val['value'].'最多30个字');
                }
                $temp = htmlspecialchars($temp);
            }else{
                if( mb_strlen($temp)>50 ){
                    return array('res'=>0,'msg'=>$val['value'].'最多50个字');
                }
            }
            if( $temp ){
                $save_data[] = array(
                    'name'  => $val['name'],
                    'value' => $temp
                );
            }
        }
        return array('res'=>1,'data'=>$save_data);
    }
    
    //保存名片信息字段
    private function save_bcard_profile($save_config,$bcard_id,$flag=true)
    {
        $bcard_id = (int)$bcard_id;
        $save_data['wid'] = $this->wid;
        $save_data['bcard_id'] = $bcard_id;
        $save_data['config'] = $save_config;
        
        $this->load->library('Mongo_db');
        if( !$flag ){
            $this->mongo_db->where(array('wid'=>$this->wid,'bcard_id'=>$bcard_id))->set($save_data)->update('bcard_profile');
        }else{
            $insert_id = $this->mongo_db->insert('bcard_profile', $save_data);
        }
        return true;
    }
    
    //获取名片信息字段
    private function get_bcard_profile($bcard_id)
    {
        $bcard_id = (int)$bcard_id;
        $this->load->library('Mongo_db');
        $result = $this->mongo_db->where(array('wid'=>$this->wid,'bcard_id'=>$bcard_id))->get_one('bcard_profile');
        $temp = $result['config'];
        $config = array();
        if( $temp ){
            foreach($temp as $val){
                $config[$val['name']] = $val['value'];
            }
        }
        $config = $config ? $config : array();
        return $config;
    }
    
    /**
     * 微名片基本配置
     */
    private function get_bcard_config()
    {
        $where_set = array(
            'wid' => $this->wid
        );
        $bcard_config = $this->model_bcard_config->get_row($where_set);
        if( isset($bcard_config['config'])&&$bcard_config['config'] ){
            $bcard_config['config'] = json_decode($bcard_config['config'],true);
        }
        $this->bcard_config = $bcard_config ? $bcard_config : array();
        
        $this->tpl_data['bcard_config'] = $this->bcard_config;
    }
    
    /**
     * 默认单位  联系方式里的
     */
    private function address()
    {
        //分店
        $this->load->model('model_address');
        $address_list = $this->model_address->get_all(array('wid'=>User::$user_id, 'status'=>0), '', '');
        $this->address_list = $address_list ? $address_list : array();
        return $this->tpl_data['address_list'] = $this->address_list;
    }
    
    //获取所有栏目
    private function get_cate()
    {
        //获取所有栏目 归档
        $cate_arr = array();
        $this->load->model('model_cate');
        $_cate_arr = $this->model_cate->get_all(array('user_id' =>$this->wid),'','','id','asc','id,cate_name');
        foreach ($_cate_arr as $_cate) {
            $cate_arr[$_cate['id']] = $_cate;
        }
        $this->tpl_data['cate_arr'] = $cate_arr ? $cate_arr : array();
    }
    //token
    private function token()
    {
        $this->load->library('encrypt');
        $token_data = array('user_id' => $this->wid, 'time' => time());
        $this->tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
    }
    
    //检查图片格式
    public function _check_image($image) {
        if ($image) {
            if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
                $this->form_validation->set_message('_check_image', '图片地址格式错误');
                return FALSE;
            }
        }
        return TRUE;
    }

    public function import()
    {
        $this->token();
        $this->tpl_data['type_info'] = '批量导入名片';

        $this->twig->display('business_card/import',$this->tpl_data);
    }

    //微名片批量导入
    public function import_business_card_excel()
    {
        $site_id = $this->wid;

        //门店列表
        $this->load->model('address_model');
        $address_list = $this->address_model->select('id,name,address')->where(array('wid'=>$site_id, 'status'=>0))->find_all();

        $card_list = $this->get_file();
        if( $card_list&&(count($card_list)>1) ){
            $this->load->model('model_bcard');
            $msg = '';
            foreach( $card_list as $key=>$val ){
                if( $key>0 ){
                    $add_data_sql = array();
                    $add_data_mongo = array();
                    $add_data_sql['wid'] = $site_id;
                    $msg_temp = '';
                    foreach( $val as $k=>$v ){
                        $v = htmlspecialchars(trim($v));
                        if( mb_strlen($v)>100 ){
                            $msg_temp = '第'.($key+1).'行，属性长度不能超过100个字；';
                            break;
                        }
                        switch($k){
                            case 0://门店名称
                                if( !$v||(!trim($v)) ){//判断是否填写具体信息
                                    $msg_temp = '第'.($key+1).'行，门店名称必须填写；';
                                    break 2;
                                }
                                $company_id = 0;
                                $company_address = '';
                                foreach($address_list as $add){
                                    if( $add['name']==$v ){
                                        $company_id = $add['id'];
                                        $company_address = $add['address'];
                                        break;
                                    }
                                }
                                if( !$company_id ){
                                    $msg_temp = '第'.($key+1).'行，没有找到该门店；';
                                    break 2;
                                }
                                $add_data_sql['company_id'] = $company_id;
                                $add_data_mongo[] = array(
                                    'name' => 'm_address',
                                    'value' => $company_address
                                );
                                break;
                            case 1://编号
                                if( !$v||(!trim($v)) ){//判断是否填写具体信息
                                    $msg_temp = '第'.($key+1).'行，编号必须填写；';
                                    break 2;
                                }
                                //编号检查唯一性
                                if( !$this->model_bcard->check_code($site_id, $v) ){
                                    $msg_temp = '第'.($key+1).'行的编号已经存在；';
                                    break 2;
                                }
                                $add_data_sql['code'] = $v;
                                break;
                            case 2://姓名
                                if( !$v||(!trim($v)) ){//判断是否填写具体信息
                                    $msg_temp = '第'.($key+1).'行，姓名必须填写；';
                                    break 2;
                                }
                                $add_data_sql['name'] = $v;
                                break;
                            case 3://手机
                                if( !$v||(!trim($v)) ){//判断是否填写具体信息
                                    $msg_temp = '第'.($key+1).'行，手机必须填写；';
                                    break 2;
                                }
                                $add_data_mongo[] = array(
                                    'name' => 'm_mobile',
                                    'value' => $v
                                );
                                break;
                            case 4://电话
                                $add_data_mongo[] = array(
                                    'name' => 'm_tele',
                                    'value' => $v
                                );
                                break;
                            case 5://部门
                                $add_data_mongo[] = array(
                                    'name' => 'm_department',
                                    'value' => $v
                                );
                                break;
                            case 6://职位
                                $add_data_mongo[] = array(
                                    'name' => 'm_port',
                                    'value' => $v
                                );
                                break;
                            case 7://邮箱
                                $add_data_mongo[] = array(
                                    'name' => 'm_email',
                                    'value' => $v
                                );
                                break;
                            default :;
                        }
                    }
                    if( !$msg_temp&&$add_data_mongo&&$add_data_sql ){
                        //保存到mysql的基本数据
                        $add_data_sql['add_time'] = time();
                        if( !$bcard_id=$this->model_bcard->add($add_data_sql,true) ){
                            $msg .= '第'.($key+1).'行，导入失败；';
                            continue;
                        }else{
                            //保存到mongodb的数据
                            $this->save_bcard_profile($add_data_mongo,$bcard_id);
                            //保存二维码
                            $qrcode_img = $this->qrcode($bcard_id);
                            $this->model_bcard->update(array('id'=>$bcard_id),array('qrcode_img'=>$qrcode_img),true);
                        }
                    }else{
                        $msg .= $msg_temp;
                    }
                }
            }

            exit( json_encode(array(
                'success' => 1,
                'msg'     => '导入完成；'. $msg,
            )) );
        }else{
            exit( json_encode(array(
                'success' => 0,
                'msg'     => '亲，没有要导入的名片！',
            )) );
        }
    }

    //读取excel文件，组成数组形式返回
    private function get_file()
    {
        $this->load->library('encrypt');
        $token = trim($this->input->get_post('token', TRUE));
        $token_decoded = $this->encrypt->decode($token);
        if ( ! $token_decoded) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => '请通过正常途径上传'));
            exit;
        }
        $token_data = unserialize($token_decoded);
        if ( ! isset($token_data['time']) OR ! isset($token_data['user_id']) OR (time() - $token_data['time']) > 3600) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => '该页面已过期，请刷新后再上传'));
            exit;
        }
        $upload_config = array(
            'upload_path'   => FCPATH.'images/'.$token_data['user_id'].'/',
            'allowed_types' => 'xls|xlsx',
            'max_size'      => 1024 * 2,
            'encrypt_name'     => TRUE
        );
        $this->load->library('upload', $upload_config);

        if(!is_dir($upload_config['upload_path'])){
            mkdir($upload_config['upload_path'], 0777, TRUE);
        }

        if ( ! $this->upload->do_upload('userfile')) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => $this->upload->display_errors('', '')));
            exit;
        } else {
            $file = $this->upload->data();
            $filePath = $file['full_path'];

            $this->load->library('PHPExcel');

            /**默认用excel2007读取excel，若格式不对，则用之前的版本进行读取*/
            $PHPReader = new PHPExcel_Reader_Excel2007();

            if(!$PHPReader->canRead($filePath)){
                $PHPReader = new PHPExcel_Reader_Excel5();
                if(!$PHPReader->canRead($filePath)){
                    header('Content-type: application/json');
                    echo json_encode(array('success' => 0, 'message' => '读取xls出错'));
                    exit;
                }
            }
            $PHPExcel = $PHPReader->load($filePath);

            /**读取excel文件中的第一个工作表*/

            $currentSheet = $PHPExcel->getSheet(0);

            $sheet = $PHPExcel->getSheet(0); //读取第一个工作表从0读起

            $content = $sheet->toArray();
            //删除上传文件
            unlink($filePath);

            return $content;
        }
    }

}