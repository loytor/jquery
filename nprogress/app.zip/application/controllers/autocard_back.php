<?php
/**
 * Created by JetBrains PhpStorm.
 * User: lsl
 * Date: 13-8-20
 * Time: 下午18:51
 * To change this template use File | Settings | File Templates.
 */

class Autocard extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->default_key = array(
            'vehicle'           => '',
            'plate'             => '',
            'owner'             => '',
            'license'           => '',
            'license_dt'        => 12,
            'new_maintenance'   => '',
            'maintenance_dt'    => 1,
            'maintenance_km'    => '',
            'maintenance_money' => '',
            'safety'            => '',
            'safety_dt'         => 12,
            'safety_money'      => ''
        );
        $this->load->model('model_cate');
        $this->load->model('model_cate_lists');
    }

    /**
     * 汽车保养卡会员列表
     */
    public function index($debug=0)
    {
        $this->load->model('model_account');
        $this->load->model('model_account_config');

        $this->load->library('pagination');
        $pagination_config = array(
            'base_url'      => '/autocard/index/',
            'total_rows'    => $this->model_account_config->join_total(),
            'per_page'      => 8,
            'uri_segment'   => 3,
        );
        $this->pagination->initialize($pagination_config);
        $tpl_data['pagination'] = $this->pagination->create_links();
        $per_page = $pagination_config['per_page'];
        $start = $per_page*(intval($this->uri->segment($pagination_config['uri_segment'], 1))-1);

        //获取会员配置信息
        $rows = $this->model_account_config->join($per_page,$start);

        if( $rows ){
            $vehicle = $this->get_vehicle();//车型
            foreach ( $rows as $key=>$value ){
                $rows[$key]['config'] = json_decode($rows[$key]['config'], TRUE);
                foreach( $this->default_key as $key2=>$value ){
                    !isset($rows[$key]['config'][$key2]) && $rows[$key]['config'][$key2] = '';
                }
                if( isset($vehicle[$rows[$key]['config']['vehicle']]) ){
                    $rows[$key]['config']['vehicle'] = $vehicle[$rows[$key]['config']['vehicle']]['name'];
                }else{
                    $rows[$key]['config']['vehicle'] = '';
                }
            }
        }else{
            $rows = '';
        }
        $tpl_data['members'] = $rows;
        $tpl_data['cur_nav'] = 'member_sys';
        $tpl_data['curtitle'] = '车主关怀系统';

        $this->twig->display('autocard/cardlist', $tpl_data);
    }

    //添加汽车保养卡会员
    public function add_account()
    {
        $this->load->model('model_account_config');
        $this->load->model('model_account');

        if( !empty($_POST['dosubmit']) ){
            $mobile = trim($this->input->post('account'));
            if( !$mobile ){
                $this->show_message(FALSE, '会员手机号码必须填写', '/autocard/add_account');
            }
            
            $account_id = $this->ajax_get_id($mobile,1);
            if( $account_id==0 ){
                $this->show_message(FALSE, '没有该用户', '/autocard/add_account');exit;
            }else if( $account_id==-1 ){
                $this->show_message(FALSE, '该会员的保养卡已存在', '/autocard/add_account');exit;
            }
            
            /*//判断该会员是否存在
            $a = $this->model_account->total_rows(array('id'=>$account_id));
            $b = $this->model_account_config->total_rows(array('account_id'=>$account_id));
            !$a && $this->show_message(FALSE, '没有该用户', '/autocard/add_account');
            $b  && $this->show_message(FALSE, '该用户已存在', '/autocard/add_account');*/

            $data = $this->input->post('data');
            $save_data['account_id'] = $account_id;
            $save_data['type']    = 'autocard';
            foreach( $data as $key=>$value ){
                switch($key){
                    case 'license_dt':
                        if( !preg_match("/^[0-9]+$/",$value)||(intval($value)<=0) ){
                            return $this->show_message(FALSE, '年检间隔时间必须是大于0的整数', '', 1);
                        }
                        $save_data['config'][$key] = intval($value);
                        break;
                    case 'maintenance_dt':
                        if( !preg_match("/^[0-9]+$/",$value)||(intval($value)<=0) ){
                            return $this->show_message(FALSE, '保养间隔时间必须是大于0的整数', '', 1);
                        }
                        $save_data['config'][$key] = intval($value);
                        break;
                    case 'safety_dt':
                        if( !preg_match("/^[0-9]+$/",$value)||(intval($value)<=0) ){
                            return $this->show_message(FALSE, '保险间隔时间必须是大于0的整数', '', 1);
                        }
                        $save_data['config'][$key] = intval($value);
                        break;
                    default :
                        $save_data['config'][$key] = $value;
                }
            }
            $save_data['config'] = json_encode($save_data['config'],true);
            $this->model_account_config->add($save_data);
            $this->show_message(TRUE, '添加成功', '/autocard');
        }

        $this->load->model('model_app_config');
        $tpl_data['vehicle_cate'] = $this->get_vehicle_cate();//车系
        $app_config = $this->model_app_config->get_row(array(
            'user_id'=> User::$user_id,
            'type'   => 'vehicle'
        ));
        $app_config ? $config = $app_config['config']:$config='';
        $tpl_data['vehicle'] = $config;
        $tpl_data['cur_nav'] = 'member_sys';
        $this->twig->display('autocard/add_account', $tpl_data);
    }

    public function ajax_get_id($mobile='',$flag=0)
    {
        $mobile = trim($mobile);
        header('Content-Type:text/html; charset=utf-8');
        if( $mobile ){
            $this->load->model('model_account');
            $id = $this->model_account->get_one(array('mobile'=>$mobile, 'wid'=>User::$user_id),'id');
            if( $id ){
                $this->load->model('model_account_config');
                $c_id = $this->model_account_config->get_one(array('account_id'=>$id,'type'=>'autocard'),'id');
                if( $c_id ){
                    $data = array(
                        'sure'   => -1
                    );
                    !$flag && exit(json_encode($data));
                    return -1;
                }
                $data = array(
                    'sure'   => 1,
                    //'id' => $id
                );
                !$flag && exit(json_encode($data));
                return $id;
            }
        }
        $data = array(
            'sure'   => 0
        );
        !$flag && exit(json_encode($data));
        return 0;
    }
    //修改汽车保养卡会员
    public function edit_account($id='')
    {
        $this->load->model('model_account_config');

        if( !empty($_POST['dosubmit']) ){
            $account_id = trim($this->input->post('account_id'));

            $save_data['account_id'] = $account_id;
            $save_data['type']    = 'autocard';
            $data = $this->input->post('data');
            foreach( $data as $key=>$value ){
                switch($key){
                    case 'license_dt':
                        if( !preg_match("/^[0-9]+$/",$value)||(intval($value)<=0) ){
                            return $this->show_message(FALSE, '年检间隔时间必须是大于0的整数', '', 1);
                        }
                        $save_data['config'][$key] = intval($value);
                        break;
                    case 'maintenance_dt':
                        if( !preg_match("/^[0-9]+$/",$value)||(intval($value)<=0) ){
                            return $this->show_message(FALSE, '保养间隔时间必须是大于0的整数', '', 1);
                        }
                        $save_data['config'][$key] = intval($value);
                        break;
                    case 'safety_dt':
                        if( !preg_match("/^[0-9]+$/",$value)||(intval($value)<=0) ){
                            return $this->show_message(FALSE, '保险间隔时间必须是大于0的整数', '', 1);
                        }
                        $save_data['config'][$key] = intval($value);
                        break;
                    default :
                        $save_data['config'][$key] = $value;
                }
            }
            $save_data['config'] = json_encode($save_data['config'],true);

            $this->model_account_config->update(array(
                'account_id'=> $save_data['account_id'],
                'type'   => $save_data['type']
            ),$save_data);
            $this->show_message(TRUE, '修改成功', '/autocard');
        }

        $id = trim($id);
        //查询基本信息
        $this->load->model('model_account_config');
        $info = $this->model_account_config->get_row(
        array(
                 'id'=> $id,
                 'type'   => 'autocard'
                 ));
                 if( $info ){

                     $this->load->model('model_app_config');
                     $app_config = $this->model_app_config->get_row(
                     array(
                     'user_id'=> User::$user_id,
                     'type'   => 'vehicle'
                     ));
                     $app_config ? $config = $app_config['config']:$config='';
                     $tpl_data['vehicle'] = $config;//车型
                     $tpl_data['vehicle_cate'] = $this->get_vehicle_cate();//车系


                     $this->load->model('model_account');
                     $mobile = $this->model_account->get_one(array('id'=>$info['account_id']),'mobile');
                     $info['mobile'] = $mobile;
                     $info['config'] = json_decode($info['config'],true);
                     //字段补齐
                     foreach( $this->default_key as $key=>$value ){
                         !isset($info['config'][$key]) && $info['config'][$key] = $this->default_key[$key];
                     }

                     //获得车系ID
                     $info['config']['cate'] = '';
                     $temp = json_decode($tpl_data['vehicle'],true);//车型
                     if( $temp ){
                         foreach( $temp as $key=>$value ){
                             if( $key==$info['config']['vehicle'] ){
                                 $info['config']['cate'] = $value['cate'];
                             }
                         }
                     }
                 }else{
                     $this->show_message(FALSE, '无效参数', '/autocard');
                 }
                 $tpl_data['member'] = $info;
                 $tpl_data['cur_nav'] = 'member_sys';
                 $this->twig->display('autocard/edit_account', $tpl_data);
    }
    //删除汽车保养卡会员
    public function delete_account($id='')
    {
        $id = trim($id);
        if( $id=='' ) $this->show_message(FALSE, '无效操作', '/autocard');
        $this->load->model('model_account_config');
        $this->model_account_config->delete(array('id'=>$id));
        $this->show_message(TRUE, '删除成功', '/autocard');
    }


    /**
     * 商家 汽车保养卡 基本信息
     * 名称+联系方式
     */
    public function show()
    {
        $this->load->model('model_app_config');
         
        $app_config = $this->model_app_config->get_row(
        array(
            'user_id'=> User::$user_id,
            'type'   => 'autocard'
        ));
        $app_config ? $config = json_decode($app_config['config'], TRUE):$config='';
        if( !isset($config['name']) ){//汽车保养卡 自定义名称
            $config['name'] = '车主关怀系统';
        }
        if( !isset($config['is_open']) ){//汽车保养卡 自定义名称
            $config['is_open'] = 1;
        }
        if( !isset($config['tels']) ){//咨询电话
            $config['tels'] = '';
        }
        if( !isset($config['break_rule']) ){//违章查询网址
            $config['break_rule'] = '';
        }
        if( !isset($config['cate_id']) ){
            $config['cate_id'] = '';
        }
        
        $tpl_data['config'] = $config;

        $tpl_data['cur_nav'] = 'member_sys';
        $tpl_data['curtitle'] = '基本设置';
        $domain = $this->session->userdata('domain');//生成 外链
        $tpl_data['preview_url'] = '';
        if( $domain ){
            $tpl_data['preview_url'] = 'http://'.$domain.'.bama555.com/autocard';
        }
        //获取所有栏目 归档
        $cate_arr = array();
        $_cate_arr = $this->model_cate->get_all(array('user_id' => User::$user_id));
        foreach ($_cate_arr as $_cate) {
            $cate_arr[$_cate['id']] = $_cate;
        }
        $tpl_data['cate_arr'] = $cate_arr;
        
        $this->twig->display('autocard/show', $tpl_data);
    }

    /**
     * 基本信息修改
     * 名称+联系方式
     */
    public function edit()
    {
        $name    = $this->input->post('name');
        $is_open = $this->input->post('is_open'); 
        $tels    = $this->input->post('tels');
        $break_rule = $this->input->post('break_rule');
        
        $data['cate_id'] = $cate_id = $this->input->post('cate_id');
        $data['is_open'] = ($is_open=='0'||$is_open=='1') ? $is_open : '1';
        $data['name'] = $name ? $name:'车主关怀系统';
        $data['break_rule'] = $break_rule ? $break_rule:'';
        $data['tels'] = array();
        //过滤无效咨询信息 并排序
        foreach( $tels as $key=>$value ){
            if( $value['content']!='' ){
                $value['choice'] = intval($value['choice']);
                $data['tels'][] = $value;
            }
        }
        array_multisort($data['tels']);

        $save_data['user_id'] = User::$user_id;
        $save_data['type']    = 'autocard';
        $save_data['config']  = json_encode($data);
        
        $this->load->model('model_app_config');
        $rows = $this->model_app_config->get_row(array(
             'user_id'=> User::$user_id,
             'type'   => 'autocard'
        ));
        $flag = FALSE;
        if( $rows ){
            $config = json_decode($rows['config'], TRUE);
            if(!isset($config['cate_id'])) $config['cate_id']='';
            
            $result = $this->model_app_config->update(array(
                    'user_id'=> User::$user_id,
                    'type'   => 'autocard'
            ),$save_data);
            if( false!==$result ){
                 //更改cate_lists表的记录
                 if ($config['cate_id']!= $cate_id) {
                     if ($cate_id) {
                         $data_cate_lists['user_id'] = User::$user_id;
                         $data_cate_lists['cate_id'] = $cate_id;
                         $data_cate_lists['type'] = 'autocard';
                         $data_cate_lists['lists_id'] = 0;
                         $data_cate_lists['rank'] = 9999;
                         $this->model_cate_lists->add($data_cate_lists);
                     }
                     if ($config['cate_id']) {
                         $del_data_cate_lists['user_id'] = User::$user_id;
                         $del_data_cate_lists['cate_id'] = $config['cate_id'];
                         $del_data_cate_lists['type'] = 'autocard';
                         $del_data_cate_lists['lists_id'] = 0;
                         $this->model_cate_lists->delete($del_data_cate_lists);
                     }
                 }
             }else{
                 $this->show_message(FALSE, '保存失败', '/autocard/show');
             }
        }else{
             $this->model_app_config->add($save_data);
             //归档记录添加
             $data_cate_lists['user_id'] = User::$user_id;
             $data_cate_lists['cate_id'] = $cate_id;
             $data_cate_lists['type'] = 'autocard';
             $data_cate_lists['lists_id'] = 0;
             $data_cate_lists['rank'] = 9999;
             $this->model_cate_lists->add($data_cate_lists);
        }
        $tpl_data['cur_nav'] = 'member_sys';
        $this->show_message(TRUE, '保存成功', '/autocard/show');
    }

    //检查图片格式
    public function _check_image($image) {
        if ($image) {
            if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
                $this->form_validation->set_message('_check_image', '图片地址格式错误');
                return FALSE;
            }
        }
        return TRUE;
    }

    /**
     * 汽车车系列表
     */
    public function show_vehicle_cate()
    {
        $this->load->model('model_app_config');
         
        $app_config = $this->model_app_config->get_row(
        array(
                 'user_id'=> User::$user_id,
                 'type'   => 'vehicle_cate'
                 ));
                 $app_config ? $config = json_decode($app_config['config'], TRUE):$config='';
                 $tpl_data['config'] = $config;

                 $tpl_data['cur_nav'] = 'member_sys';
                 $tpl_data['curtitle'] = '基本设置';
                 $this->twig->display('autocard/show_vehicle_cate', $tpl_data);
    }
    /**
     * 获取车系信息列表
     */
    private function get_vehicle_cate()
    {
        $this->load->model('model_app_config');
        $app_config = $this->model_app_config->get_row(
        array(
                 'user_id'=> User::$user_id,
                 'type'   => 'vehicle_cate'
                 ));
                 $app_config ? $config = json_decode($app_config['config'], TRUE):$config='';
        if( !$config ){
            return array();
        }else{
            return $config;
        }
    }
    /**
     * 添加车系
     */
    public function add_vehicle_cate()
    {
        $this->load->library('form_validation');
        $this->load->helper('form');
        $this->form_validation->set_rules('vehicle_cate_name', '车系名称', 'trim|required|max_length[255]|htmlspecialchars');
        $this->form_validation->set_rules('image', '车系图片', 'trim|required|callback__check_image');
        $this->form_validation->set_rules('abst', '车系描述', 'trim|max_length[255]|htmlspecialchars');
        $this->form_validation->set_rules('sort', '排序值', 'intval');
        if ( $this->form_validation->run() ) {
            $vehicle_cate_name = $this->form_validation->set_value('vehicle_cate_name');
            $image             = $this->form_validation->set_value('image');
            $sort              = $this->form_validation->set_value('sort')?$this->form_validation->set_value('sort'):0;
            $abst              = $this->form_validation->set_value('abst');
            //读取以前的输入并判断唯一性
            $old_config = $this->get_vehicle_cate();
            $save_data['user_id'] = User::$user_id;
            $save_data['type']    = 'vehicle_cate';
            $new_id = uniqid().sprintf("%03s", mt_rand(1, 10000));
            if( !$old_config ){
                $data[$new_id] = array(
                    'choice'=> $sort,
                    'name'  => $vehicle_cate_name,
                    'image' => $image,
                    'abst'  => $abst
                );
                $save_data['config'] = json_encode($data);
                if( strlen($save_data['config'])>65530 ){
                    $this->show_message(FALSE, '您的数据量太大，请与代理商联系!', '/autocard/show_vehicle');exit;
                }
                $this->model_app_config->add($save_data);
                $this->show_message(TRUE, '添加成功', '/autocard/show_vehicle_cate');
            }else{
                foreach( $old_config as $value ){
                    if( $value['name']==$vehicle_cate_name ){
                        $this->show_message(FALSE, '该车系已经存在', '/autocard/show_vehicle_cate');
                    }
                }
                $old_config[$new_id] = array(
                    'choice'=> $sort,
                    'name'  => $vehicle_cate_name,
                    'image' => $image,
                    'abst'  => $abst
                );
                array_multisort($old_config);
                $save_data['config'] = json_encode($old_config);
                $this->model_app_config->update(array(
                    'user_id'=> User::$user_id,
                    'type'   => 'vehicle_cate'
                    ),$save_data);
                    $this->show_message(TRUE, '添加成功', '/autocard/show_vehicle_cate');
            }
        }else{
            $errors = validation_errors();
            if ($errors) {
                $this->show_message(FALSE, $errors, '/autocard/add_vehicle_cate');
            }
        }

        $this->load->library('encrypt');
        $token_data = array('user_id' => User::$user_id, 'time' => time());
        $tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
        $tpl_data['cur_nav'] = 'member_sys';
        $this->twig->display('autocard/add_vehicle_cate', $tpl_data);
    }

    /**
     * 编辑车系信息
     * @param $id
     */
    public function edit_vehicle_cate($id='')
    {
        $this->load->library('form_validation');
        $this->load->helper('form');
        $this->form_validation->set_rules('vehicle_cate_name', '车系名称', 'trim|required|max_length[255]|htmlspecialchars');
        $this->form_validation->set_rules('image', '车系图片', 'trim|required|callback__check_image');
        $this->form_validation->set_rules('abst', '车系描述', 'trim|max_length[255]|htmlspecialchars');
        $this->form_validation->set_rules('sort', '排序值', 'intval');
        $tid               = trim($this->input->post('id'));
        if ( $this->form_validation->run() ) {
            $vehicle_cate_name = $this->form_validation->set_value('vehicle_cate_name');
            $image             = $this->form_validation->set_value('image');
            $sort              = $this->form_validation->set_value('sort')?$this->form_validation->set_value('sort'):0;
            $abst              = $this->form_validation->set_value('abst');

            //读取以前的输入并判断唯一性
            $old_config = $this->get_vehicle_cate();
            $save_data['user_id'] = User::$user_id;
            $save_data['type']    = 'vehicle_cate';
            foreach( $old_config as $key=>$value ){
                if( $value['name']==$vehicle_cate_name&&$key!=$tid ){
                    $this->show_message(FALSE, '该车系已经存在', '/autocard/edit_vehicle_cate/'.$tid);
                }
            }
            $old_config[$tid] = array(
                'choice'=> $sort,
                'name'  => $vehicle_cate_name,
                'image' => $image,
                'abst'  => $abst
            );
            array_multisort($old_config);
            $save_data['config'] = json_encode($old_config);
            if( strlen($save_data['config'])>65530 ){
                $this->show_message(FALSE, '系统错误，请联系管理员!', '/autocard/show_vehicle');exit;
            }
            $this->model_app_config->update(array(
                'user_id'=> User::$user_id,
                'type'   => 'vehicle_cate'
                ),$save_data);
                $this->show_message(TRUE, '修改成功', '/autocard/show_vehicle_cate');
        }else{
            $errors = validation_errors();
            if ($errors) {
                $this->show_message(FALSE, $errors, '/autocard/edit_vehicle_cate/'.$tid);
            }
        }

        if( $id=='' ) $this->show_message(FALSE, '无效操作', '/autocard/show_vehicle_cate');
        $id = trim($id);
        $vehicles = $this->get_vehicle_cate();
        if(!$vehicles[$id]) $this->show_message(FALSE, '无效操作', '/autocard/show_vehicle');
        $tpl_data['vehicle_cate'] = $vehicles[$id];
        $this->load->library('encrypt');
        $token_data = array('user_id' => User::$user_id, 'time' => time());
        $tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
        $tpl_data['cur_nav'] = 'member_sys';
        $tpl_data['id'] = $id;
        $this->twig->display('autocard/edit_vehicle_cate', $tpl_data);
    }

    /**
     *删除车系
     * @param $id
     */
    public function delete_vehicle_cate($id='')
    {
        if( $id=='' ) $this->show_message(FALSE, '无效操作', '/autocard/show_vehicle');
        $id = trim($id);
        $vehicle_cates = $this->get_vehicle_cate();
        if(!$vehicle_cates[$id]) $this->show_message(FALSE, '无效操作', '/autocard/show_vehicle_cate');
        unset($vehicle_cates[$id]);
        if( count($vehicle_cates) ){
            array_multisort($vehicle_cates);
            $save_data['config'] = json_encode($vehicle_cates);
            $this->model_app_config->update(array(
                'user_id'=> User::$user_id,
                'type'   => 'vehicle_cate'
                ),$save_data);
        }else{
            $this->model_app_config->delete(array(
                'user_id'=> User::$user_id,
                'type'   => 'vehicle_cate'
                ));
        }
        //删除关联信息
        $vehicles = $this->get_vehicle();
        if( $vehicles ){
            foreach ( $vehicles as $key=>$value ){
                if( $value['cate']==$id ){
                    unset($vehicles[$key]);
                }
            }
            if( count($vehicles) ){
                array_multisort($vehicles);
                $save_data['config'] = json_encode($vehicles);
                $this->model_app_config->update(array(
                    'user_id'=> User::$user_id,
                    'type'   => 'vehicle'
                    ),$save_data);
            }else{
                $this->model_app_config->delete(array(
                    'user_id'=> User::$user_id,
                    'type'   => 'vehicle'
                    ));
            }
        }
        $this->show_message(TRUE, '删除成功', '/autocard/show_vehicle_cate');
    }

    /**
     * 汽车车型列表
     */
    public function show_vehicle()
    {
        $this->load->model('model_app_config');
         
        $app_config = $this->model_app_config->get_row(
        array(
                 'user_id'=> User::$user_id,
                 'type'   => 'vehicle'
                 ));
                 if( $app_config ){
                     $config = json_decode($app_config['config'], TRUE);
                     $cates = $this->get_vehicle_cate();
                     if( $config ){
                         foreach( $config as $key=>$value ){
                             $config[$key]['cate_name'] = $cates[$value['cate']]['name'];
                             if( $value['image']=='' ){
                                 $config[$key]['image'] = $cates[$value['cate']]['image'];
                             }
                         }
                     }
                 }else{
                     $config='';
                 }
                 $tpl_data['config'] = $config;

                 $tpl_data['cur_nav'] = 'member_sys';
                 $tpl_data['curtitle'] = '基本设置';
                 $this->twig->display('autocard/show_vehicle', $tpl_data);
    }

    /**
     * 添加车型
     */
    public function add_vehicle()
    {
        $this->load->library('form_validation');
        $this->load->helper('form');
        $this->form_validation->set_rules('vehicle_name', '车型名称', 'trim|required|max_length[255]|htmlspecialchars');
        $this->form_validation->set_rules('cate', '车系', 'trim|required');
        $this->form_validation->set_rules('image', '车型图片', 'trim|callback__check_image');
        $this->form_validation->set_rules('abst', '车型描述', 'trim|max_length[255]|htmlspecialchars');
        $this->form_validation->set_rules('sort', '排序值', 'intval');
        if ( $this->form_validation->run() ) {
            $vehicle_name = $this->form_validation->set_value('vehicle_name');
            $cate         = $this->form_validation->set_value('cate');
            $image        = $this->form_validation->set_value('image');
            $sort         = $this->form_validation->set_value('sort')?$this->form_validation->set_value('sort'):0;
            $abst         = $this->form_validation->set_value('abst');
            //读取以前的输入并判断唯一性
            $old_config = $this->get_vehicle();
            $save_data['user_id'] = User::$user_id;
            $save_data['type']    = 'vehicle';
            $new_id = uniqid().sprintf("%03s", mt_rand(1, 10000));
            if( !$old_config ){
                $data[$new_id] = array(
                    'choice'=> $sort,
                    'name'  => $vehicle_name,
                    'image' => $image,
                    'cate'  => $cate,
                    'abst'  => $abst
                );
                $save_data['config'] = json_encode($data);
                if( strlen($save_data['config'])>65530 ){
                    $this->show_message(FALSE, '您的数据量太大，请与代理商联系!', '/autocard/show_vehicle');exit;
                }
                $this->model_app_config->add($save_data);
                $this->show_message(TRUE, '添加成功', '/autocard/show_vehicle');
            }else{
                foreach( $old_config as $value ){
                    if( $value['name']==$vehicle_name ){
                        $this->show_message(FALSE, '该车型已经存在', '/autocard/show_vehicle');
                    }
                }
                $old_config[$new_id] = array(
                    'choice'=> $sort,
                    'name'  => $vehicle_name,
                    'image' => $image,
                    'cate'  => $cate,
                    'abst'  => $abst
                );
                array_multisort($old_config);
                $save_data['config'] = json_encode($old_config);
                if( strlen($save_data['config'])>65530 ){
                    $this->show_message(FALSE, '您的数据量太大，请与代理商联系!', '/autocard/show_vehicle');exit;
                }
                $this->model_app_config->update(array(
                    'user_id'=> User::$user_id,
                    'type'   => 'vehicle'
                    ),$save_data);
                $this->show_message(TRUE, '添加成功', '/autocard/show_vehicle');
            }
        }else{
            $errors = validation_errors();
            if ($errors) {
                $this->show_message(FALSE, $errors, '/autocard/add_vehicle');
            }
        }

        //车系列表
        $tpl_data['vehicle_cate'] = $this->get_vehicle_cate();
        $this->load->library('encrypt');
        $token_data = array('user_id' => User::$user_id, 'time' => time());
        $tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
        $tpl_data['cur_nav'] = 'member_sys';
        $this->twig->display('autocard/add_vehicle', $tpl_data);
    }

    /**
     * 获取车型信息
     */
    private function get_vehicle()
    {
        $this->load->model('model_app_config');
        $app_config = $this->model_app_config->get_row(
        array(
                 'user_id'=> User::$user_id,
                 'type'   => 'vehicle'
                 ));
                 $app_config ? $config = json_decode($app_config['config'], TRUE):$config='';
        if( !$config ){
            return array();
        }else{
            return $config;
        }
    }

    /**
     * 编辑车型信息
     * @param $id
     */
    public function edit_vehicle($id='')
    {
        $this->load->library('form_validation');
        $this->load->helper('form');
        $this->form_validation->set_rules('vehicle_name', '车型名称', 'trim|required|max_length[255]|htmlspecialchars');
        $this->form_validation->set_rules('cate', '车系', 'trim|required');
        $this->form_validation->set_rules('image', '车型图片', 'trim|callback__check_image');
        $this->form_validation->set_rules('abst', '车型描述', 'trim|max_length[255]|htmlspecialchars');
        $this->form_validation->set_rules('sort', '排序值 ', 'intval');
        $tid = trim($this->input->post('id'));
        if ( $this->form_validation->run() ) {
            $vehicle_name = $this->form_validation->set_value('vehicle_name');
            $cate         = $this->form_validation->set_value('cate');
            $image        = $this->form_validation->set_value('image');
            $sort         = $this->form_validation->set_value('sort')?$this->form_validation->set_value('sort'):0;
            $abst         = $this->form_validation->set_value('abst');
            //读取以前的输入并判断唯一性
            $old_config = $this->get_vehicle();
            $save_data['user_id'] = User::$user_id;
            $save_data['type']    = 'vehicle';

            foreach( $old_config as $key=>$value ){
                if( $value['name']==$vehicle_name&&$key!=$tid ){
                    $this->show_message(FALSE, '该车型已经存在', '/autocard/edit_vehicle/'.$tid);
                }
            }
            $old_config[$tid] = array(
                'choice'=> $sort,
                'name'  => $vehicle_name,
                'image' => $image,
                'cate'  => $cate,
                'abst'  => $abst
            );
            array_multisort($old_config);
            $save_data['config'] = json_encode($old_config);
            if( strlen($save_data['config'])>65530 ){
                $this->show_message(FALSE, '您的数据量太大，请与代理商联系!', '/autocard/show_vehicle');exit;
            }
            $this->model_app_config->update(array(
                'user_id'=> User::$user_id,
                'type'   => 'vehicle'
                ),$save_data);
                $this->show_message(TRUE, '修改成功', '/autocard/show_vehicle');

        }else{
            $errors = validation_errors();
            if ($errors) {
                $this->show_message(FALSE, $errors, '/autocard/edit_vehicle/'.$tid);
            }
        }

        if( $id=='' ) $this->show_message(FALSE, '无效操作', '/autocard/show_vehicle');
        $id = trim($id);
        $vehicles = $this->get_vehicle();
        if(!$vehicles[$id]) $this->show_message(FALSE, '无效操作', '/autocard/show_vehicle');
        //车系列表
        $tpl_data['vehicle_cate'] = $this->get_vehicle_cate();
        $tpl_data['vehicle'] = $vehicles[$id];
        $this->load->library('encrypt');
        $token_data = array('user_id' => User::$user_id, 'time' => time());
        $tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
        $tpl_data['cur_nav'] = 'member_sys';
        $tpl_data['id'] = $id;
        $this->twig->display('autocard/edit_vehicle', $tpl_data);
    }

    /**
     *删除车型
     * @param $id
     */
    public function delete_vehicle($id='')
    {
        $id = trim($id);
        if( $id=='' ) $this->show_message(FALSE, '无效操作', '/autocard/show_vehicle');
        $vehicles = $this->get_vehicle();
        if(!$vehicles[$id]) $this->show_message(FALSE, '无效操作', '/autocard/show_vehicle');
        unset($vehicles[$id]);
        if( count($vehicles) ){
            array_multisort($vehicles);
            $save_data['config'] = json_encode($vehicles);
            $this->model_app_config->update(array(
                'user_id'=> User::$user_id,
                'type'   => 'vehicle'
                ),$save_data);
        }else{
            $this->model_app_config->delete(array(
                'user_id'=> User::$user_id,
                'type'   => 'vehicle'
                ));
        }
        $this->show_message(TRUE, '删除成功', '/autocard/show_vehicle');
    }
}