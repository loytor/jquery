<?php
/**
 * Created by JetBrains PhpStorm.
 * User: along
 * Date: 13-9-6
 * Time: 下午2:41
 * To change this template use File | Settings | File Templates.
 * @property Model_game $modelObj
 * @property Model_cate_lists $model_cate_lists
 * @property Model_cate $model_cate
 * @property Model_game_record $model_game_record
 * @property Model_account $model_account
 */

class game extends MY_Controller
{
    private $game_type = array(
        1=>array('type'=>'rotate','tpl'=>'rotate', 'title'=>'大转盘','prizenum'=>3),
        2=>array('type'=>'fruit','tpl'=>'fruit', 'title'=>'水果达人','prizenum'=>10),
        3=>array('type'=>'scratch','tpl'=>'default', 'title'=>'刮刮乐','prizenum'=>10),
        4=>array('type'=>'hitegg','tpl'=>'hitegg', 'title'=>'砸金蛋','prizenum'=>10),
        5=>array('type'=>'shake','tpl'=>'shake', 'title'=>'摇一摇','prizenum'=>10),
        6=>array('type'=>'sudoku','tpl'=>'sudoku', 'title'=>'幸运卡牌','prizenum'=>7)
    );

    private $wid = '';

    //默认提示
    private $tips = array(
        'wintips'=>'恭喜您，中奖了！您的运气实在太好了！',
        'failtips'=>'再接再厉哟！',
        'endtitle'=>'亲，活动已经结束，请继续关注我们的后续活动哦。'
    );
    //奖项
    private $rewards = array(
        '1'=>'奖项一',
        '2'=>'奖项二',
        '3'=>'奖项三',
        '4'=>'奖项四',
        '5'=>'奖项五',
        '6'=>'奖项六',
        '7'=>'奖项七',
        '8'=>'奖项八',
        '9'=>'奖项九',
        '10'=>'奖项十'
    );

    //网站栏目
    public $cateData = array();

    public function __construct()
    {
        parent::__construct();
        $this->load->model('model_game', 'modelObj');
        $this->load->model('model_cate');
        $this->load->model('model_game_record');
        $this->load->model('model_cate_lists');

        $this->wid = User::$user_id;
        $cateList = $this->model_cate->get_all(array('user_id' => $this->wid), 500, 1);
        $cateArr = array();
        if($cateList)
        {
            foreach($cateList as $cate)
            {
                $cateArr[$cate['id']] = $cate;
            }
            $this->cateData = $cateArr;
        }
    }

    public function setting()
    {
        $this->load->model('model_app_config');
        if ($this->input->post()) {
            $base_config['checkurl'] = trim($this->input->post('checkurl',true));
            $base_config['sendurl'] = trim($this->input->post('sendurl',true));
            $base_config['token'] = trim($this->input->post('token',true));
            $data_set['config'] = json_encode($base_config);
            if (!$this->model_app_config->get_row(array('user_id'=>User::$user_id, 'type'=>'game'))) {
                if($this->model_app_config->add(array(
                    'user_id'=>User::$user_id,
                    'type'=>'game',
                    'config' => $data_set['config'],
                ))){
                    $this->show_message(TRUE, '保存设置成功', '/game/setting');
                } else {
                    $this->show_message(FALSE, '保存设置失败', '/game/setting');
                }
            } else {
                if($this->model_app_config->update(array('user_id'=>User::$user_id, 'type'=>'game'), $data_set)){
                    $this->show_message(TRUE, '保存设置成功', '/game/setting');
                } else {
                    $this->show_message(FALSE, '保存设置失败', '/game/setting');
                }
            }

        }

        $config = $this->model_app_config->get_row(array('user_id'=>User::$user_id, 'type'=>'game'));
        $tpl_data['config'] = json_decode($config['config'], TRUE);
        $tpl_data['curtitle'] = '接口设置';

        $this->twig->display('game/setting', $tpl_data);
    }

    /**
     * name 列表
     */
    public function index()
    {
        $where = array(
            'wid' => $this->wid,
            'is_deleted' => 0
        );
        $pageurl = '/game/index/';
        $gametype = $this->game_type;
        $type = $this->input->get('type');
        $where['type'] = array_key_exists($type, $gametype) ? $type : 1;
        $pageurl .= '?type='.$where['type'];

        //$page = intval($this->uri->segment($this->urlSegment, self::CUR_PAGE));
        $page = intval($this->input->get('per_page'));
        $page = $page ? $page : 1;

        $list = $this->modelObj->get_all($where, $this->pageSize, $page);
        $now = time();
        foreach ($list as &$v) {
            //$v['content'] = json_decode($v['content'], true);
            if($v['start_time'] > $now)
            {
                $v['status'] = '<span class="text-success">(未开始)</span>';
            }
            else if($v['end_time'] < $now)
            {
                $v['status'] = '<span class="text-error">(已结束)</span>';
            }
            else
            {
                $v['status'] = '<span class="text-info">(进行中)</span>';
            }
        }

        $tpl['gamelist'] = $list;
        $tpl['page'] = $page;

        $this->pageQueryString = true;
        $tpl['pages'] = $this->pages($this->modelObj->total_rows($where),$pageurl);

        $tpl['curtitle'] = $gametype[$where['type']]['title'].'游戏列表';

        $this->load->model('model_user');
        $user = $this->model_user->get_row($this->wid);

        if($user['all_domain'])
        {
            $tpl['viewurl'] = $user['all_domain'].'/';
        }
        else
        {
            $tpl['viewurl'] = full_url('',$user['domain']);
        }
        $tpl['type'] = $where['type'];
        $tpl['catelist'] = $this->cateData;

        $this->twig->display('game/index', $tpl);
    }

    public function add()
    {
        $type = $this->input->get('type');
        if(!array_key_exists($type, $this->game_type))
        {
            $this->show_message(FALSE, '没有该类型的游戏', '/game');
        }

        $this->form_validation->set_rules('cate_id', '栏目', 'trim');
        $this->form_validation->set_rules('title', '游戏标题', 'trim|required|max_length[255]|htmlspecialchars');
        $this->form_validation->set_rules('desc', '游戏描述', 'trim|max_length[255]|htmlspecialchars');
        $this->form_validation->set_rules('content', '游戏说明', 'trim');

        $this->form_validation->set_rules('start_time', '开始时间', 'trim|required|htmlspecialchars');
        $this->form_validation->set_rules('end_time', '结束时间', 'trim|required|htmlspecialchars');

        $this->form_validation->set_rules('image_start', '游戏开始封面图片', 'trim|callback__check_image');
        $this->form_validation->set_rules('image_end', '游戏结束封面图片', 'trim|callback__check_image');

        $this->form_validation->set_rules('validatecode', '现场验证码', 'trim|alpha_numeric|max_length[10]');

        if ($this->form_validation->run())
        {
            //奖品设置
            $prize = (array)$this->input->post('prize');
            $rate = 0;
            foreach($prize as &$_prize)
            {
                if(empty($_prize['name']))
                {
                    $this->show_message(TRUE, '请完整填写游戏奖品名称！', '',1);
                }
                $_prize['rate'] = is_numeric($_prize['rate']) ? $_prize['rate'] : 0;

                $_prize['number'] = (is_numeric($_prize['number']) && $_prize['number']>0) ? $_prize['number'] : 0;
                //处理奖品真实数量
                if($_prize['true_number']>0 && $_prize['true_number']>$_prize['number'])
                {
                    $_prize['true_number'] = $_prize['number'];
                }
                $_prize['true_number'] = ($_prize['true_number'] > 0) ? $_prize['true_number'] : 0;
                //概率总数不超过100%
                $rate += $_prize['rate'];
            }
            if($rate > 100)
            {
                $this->show_message(TRUE, '所有奖品中奖率之和请不要超过100%！', '',1);
            }
            $dataSet['prize'] = json_encode($prize);

            $dataSet['cate_id'] = $this->form_validation->set_value('cate_id');
            $dataSet['wid'] = $this->wid;
            $dataSet['title'] = $this->form_validation->set_value('title');
            $dataSet['desc'] = $this->form_validation->set_value('desc');
            $dataSet['content'] = $this->form_validation->set_value('content');
            $dataSet['start_time'] = strtotime($this->form_validation->set_value('start_time'));
            $dataSet['end_time'] = strtotime($this->form_validation->set_value('end_time'));

            //时间判断
            if($dataSet['end_time'] < $dataSet['start_time'])
            {
                $this->show_message(TRUE, '活动结束时间不能小于开始时间', '',1);
            }
            $dataSet['chance'] = $this->input->post('chance');
            $dataSet['chance'] = $dataSet['chance'] ? $dataSet['chance'] : 0;

            //游戏类别
            $dataSet['type'] = $type;
            //关键词
            //$dataSet['keyword'] = $this->input->post('keyword');

            //参与权限
            $tmp = 0;
            $auth = $this->input->post('auth');
            if($auth)
            {
                foreach($auth as $v)
                {
                    $tmp |= $v;
                }
            }
            $dataSet['auth'] = $tmp;

            //开始和结束封面图片
            $coverImg = array(
                'image_start'=>$this->form_validation->set_value('image_start'),
                'image_end'=>$this->form_validation->set_value('image_end')
            );
            $dataSet['cover_img'] = json_encode($coverImg);
            $editData['backgroundimage'] = $this->input->post('backgroundimage');

            //抽奖规则
            $rule = $this->input->post('rule');
            $rule = $rule ? $rule : 1;
            $rules = $this->input->post('rules');
            $rules[$rule]['type'] = $rule;

            $rules[$rule]['number'] = (is_numeric($rules[$rule]['number']) && $rules[$rule]['number']>1) ? $rules[$rule]['number'] : 1;
            if($rule == 2)
            {
                $rules[$rule]['day'] = (is_numeric($rules[$rule]['day']) && $rules[$rule]['day']>1) ? $rules[$rule]['day'] : 1;
            }

            //增加会员可中奖次数
            $rules[$rule]['lotterynum'] = $this->input->post('lotterynum');
            $rules[$rule]['lotterynum'] = is_numeric($rules[$rule]['lotterynum']) ? $rules[$rule]['lotterynum'] : 0;

            //增加同一奖品被抽出冻结时间规则
            $rules[$rule]['frozentime'] = $this->input->post('frozentime');
            $rules[$rule]['frozentime'] = (is_numeric($rules[$rule]['frozentime']) && $rules[$rule]['frozentime']>0) ? $rules[$rule]['frozentime'] : 0;

            $dataSet['rule'] = json_encode($rules[$rule]);

            //各种提示信息
            $tips['wintips'] = $this->input->post('wintips');
            $tips['failtips'] = $this->input->post('failtips');
            $tips['endtitle'] = $this->input->post('endtitle');
            $dataSet['tips'] = json_encode($tips);

            $dataSet['inputtime'] = $_SERVER['REQUEST_TIME'];

            //高级设置
            $advset['displaywinner'] = $this->input->post('displaywinner');
            $advset['displaywinner'] = $advset['displaywinner'] ? $advset['displaywinner'] : 0;
            $advset['showprizenum'] = $this->input->post('showprizenum');
            $advset['showprizenum'] = $advset['showprizenum'] ? $advset['showprizenum'] : 0;
            //中奖是否要填写地址
            $advset['address_must'] = $this->input->post('address_must');
            $advset['address_must'] = $advset['address_must']==1 ? 1 : 0;

            $advset['btype'] = $this->input->post('btype') ? $this->input->post('btype') : 1;
            $dataSet['advset'] = json_encode($advset);

            //现场验证码
            $dataSet['validatecode'] =  $this->form_validation->set_value('validatecode');

            //增加入库
            $gid = $this->modelObj->add($dataSet,true);

            //规档
            if($dataSet['cate_id'] && $gid)
            {
                $data_cate_lists['user_id'] =$dataSet['wid'];
                $data_cate_lists['cate_id'] = $dataSet['cate_id'];
                $data_cate_lists['type'] = 'game';
                $data_cate_lists['lists_id'] = $gid;
                $data_cate_lists['rank'] = 9;
                $this->model_cate_lists->add($data_cate_lists);
            }

            //关键词回复
            $gameType = $this->game_type;

            if(isset($gameType[$type]['title']))
            {
                $reply_data = array();
                $reply_data['keyword'][] = $gameType[$type]['title'];
                $reply_data['type'] = 'article';
                $reply_data['site_id'] = $this->wid;
                $reply_data['count_match'] = 0;
                $reply_data['dt_add'] = $reply_data['dt_update'] = time();
                $item_id = (string)new MongoId();
                $reply_data['content'][$item_id] = array(
                    'id'    => $item_id,
                    'type'  => 'Game',
                    'title' => $dataSet['title'],
                    'desc'  => $dataSet['desc'],
                    'image' => $coverImg['image_start'],
                    'ref_id'=> $gid,
                    'url'   => '/game?id='.$gid,
                    'rank'  => 9999
                );
                $this->load->library('Mongo_db');
                $this->mongo_db->insert('reply', $reply_data);
            }

            $this->show_message(TRUE, '游戏创建成功', '/game/?type='.$type);
        }
        else
        {
            $errors = validation_errors();
            if ($errors) {
                $this->show_message(FALSE, $errors, '/game/add/?type='.$type);
            }
        }

        $tpl_data['token'] = $this->token;

        $tpl_data['cate_arr'] = $this->cateData;
        $tpl_data['tips'] = $this->tips;
        $tpl_data['game_type'] = $this->game_type[$type];

        $tpl_data['cover_img'] = array(
            'image_start' => site_url().'assets/game/'.$tpl_data['game_type']['type'].'_start.jpg',
            'image_end' => site_url().'assets/game/'.$tpl_data['game_type']['type'].'_end.jpg',
        );

        $this->twig->display('game/'.$this->game_type[$type]['tpl'].'/add', $tpl_data);
    }


    public function edit()
    {
        $id = $this->input->get('id');
        //查询是否存在
        $gameInfo = $this->modelObj->get_row(array('id'=>$id,'is_deleted'=>0,'wid'=>$this->wid));
        if(!$gameInfo)
        {
            $this->show_message(FALSE, '该游戏不存在或已删除', '',1);
        }
        $this->form_validation->set_rules('cate_id', '栏目', 'trim');
        $this->form_validation->set_rules('title', '游戏标题', 'trim|required|max_length[255]|htmlspecialchars');
        $this->form_validation->set_rules('desc', '游戏描述', 'trim|max_length[255]|htmlspecialchars');
        $this->form_validation->set_rules('content', '游戏说明', 'trim');

        $this->form_validation->set_rules('start_time', '游戏开始时间', 'trim|required|htmlspecialchars');
        $this->form_validation->set_rules('end_time', '游戏结束时间', 'trim|required|htmlspecialchars');

        $this->form_validation->set_rules('image_start', '游戏开始封面图片', 'trim|callback__check_image');
        $this->form_validation->set_rules('image_end', '游戏结束封面图片', 'trim|callback__check_image');

        $this->form_validation->set_rules('image_end', '游戏结束封面图片', 'trim|callback__check_image');

        $this->form_validation->set_rules('validatecode', '现场验证码', 'trim|alpha_numeric|max_length[10]');

        if ($this->form_validation->run())
        {
            //奖品设置
            $prize = (array)$this->input->post('prize');
            $rate = 0;
            foreach($prize as &$_prize)
            {
                if(empty($_prize['name']))
                {
                    $this->show_message(TRUE, '请完整填写游戏奖品名称！', '',1);
                }
                $_prize['rate'] = is_numeric($_prize['rate']) ? $_prize['rate'] : 0;

                $_prize['number'] = (is_numeric($_prize['number']) && $_prize['number']>0) ? $_prize['number'] : 0;
                //处理奖品真实数量
                if($_prize['true_number']>0 && $_prize['true_number']>$_prize['number'])
                {
                    $_prize['true_number'] = $_prize['number'];
                }
                $_prize['true_number'] = ($_prize['true_number'] > 0) ? $_prize['true_number'] : 0;
                //概率总数不超过100%
                $rate += $_prize['rate'];
            }
            if($rate > 100)
            {
                $this->show_message(TRUE, '所有奖品中奖率之和请不要超过100%！', '',1);
            }
            $editData['prize'] = json_encode($prize);

            $editData['cate_id'] = $this->form_validation->set_value('cate_id');
            $editData['title'] = $this->form_validation->set_value('title');
            $editData['desc'] = $this->form_validation->set_value('desc');
            $editData['content'] = $this->form_validation->set_value('content');
            $editData['start_time'] = strtotime($this->form_validation->set_value('start_time'));
            $editData['end_time'] = strtotime($this->form_validation->set_value('end_time'));

            //时间判断
            if($editData['end_time'] < $editData['start_time'])
            {
                $this->show_message(TRUE, '活动结束时间不能小于开始时间', '',1);
            }

            $editData['chance'] = $this->input->post('chance');
            $editData['chance'] = $editData['chance'] ? $editData['chance'] : 0;

            //开始和结束封面图片
            $coverImg = array(
                'image_start'=>$this->form_validation->set_value('image_start'),
                'image_end'=>$this->form_validation->set_value('image_end')
            );
            $editData['cover_img'] = json_encode($coverImg);
            $editData['backgroundimage'] = $this->input->post('backgroundimage');

            //抽奖规则
            $rule = $this->input->post('rule');
            $rule = $rule ? $rule : 1;
            $rules = $this->input->post('rules');
            $rules[$rule]['type'] = $rule;

            $rules[$rule]['number'] = (is_numeric($rules[$rule]['number']) && $rules[$rule]['number']>1) ? $rules[$rule]['number'] : 1;
            if($rule == 2)
            {
                $rules[$rule]['day'] = (is_numeric($rules[$rule]['day']) && $rules[$rule]['day']>1) ? $rules[$rule]['day'] : 1;
            }

            //增加会员可中奖次数
            $rules[$rule]['lotterynum'] = $this->input->post('lotterynum');
            $rules[$rule]['lotterynum'] = is_numeric($rules[$rule]['lotterynum']) ? $rules[$rule]['lotterynum'] : 0;

            //增加同一奖品被抽出冻结时间规则
            $rules[$rule]['frozentime'] = $this->input->post('frozentime');
            $rules[$rule]['frozentime'] = (is_numeric($rules[$rule]['frozentime']) && $rules[$rule]['frozentime']>0) ? $rules[$rule]['frozentime'] : 0;

            $editData['rule'] = json_encode($rules[$rule]);

            //参与权限
            $tmp = 0;
            $auth = $this->input->post('auth');
            if($auth)
            {
                foreach($auth as $v)
                {
                    $tmp |= $v;
                }
            }
            $editData['auth'] = $tmp;

            //各种提示信息
            $tips['wintips'] = $this->input->post('wintips');
            $tips['failtips'] = $this->input->post('failtips');
            $tips['endtitle'] = $this->input->post('endtitle');
            $editData['tips'] = json_encode($tips);

            //高级设置
            $advset['displaywinner'] = $this->input->post('displaywinner');
            $advset['displaywinner'] = $advset['displaywinner'] ? $advset['displaywinner'] : 0;
            $advset['showprizenum'] = $this->input->post('showprizenum');
            $advset['showprizenum'] = $advset['showprizenum'] ? $advset['showprizenum'] : 0;

            //中奖是否要填写地址
            $advset['address_must'] = $this->input->post('address_must');
            $advset['address_must'] = $advset['address_must']==1 ? 1 : 0;

            $advset['btype'] = $this->input->post('btype') ? $this->input->post('btype') : 1;
            $editData['advset'] = json_encode($advset);
            //现场验证码
            $editData['validatecode'] = $this->form_validation->set_value('validatecode');

            //更新操作
            $this->modelObj->update(array('id'=>$id,'wid'=>$this->wid),$editData);

            //记录日志
            $this->load->model('game_edit_log_model');

            $this->game_edit_log_model->add(array(
                                                    'gid'=>$id,
                                                    'site_id'=>$this->wid,
                                                    'title'=>$editData['title'],
                                                    'start_time'=>$editData['start_time'],
                                                    'end_time' => $editData['end_time'],
                                                    'rule' => $editData['rule'],
                                                    'prize' => $editData['prize'],
                                                    'inputtime'=>time()
                                                  )
                                            );

            //归档操作
            if ($gameInfo['cate_id'] != $editData['cate_id']) {
                $this->load->model('model_cate_lists');
                if ($editData['cate_id']) {
                    $data_cate_lists['user_id'] = $this->wid;
                    $data_cate_lists['cate_id'] = $editData['cate_id'];
                    $data_cate_lists['type'] = 'game';
                    $data_cate_lists['lists_id'] = $id;
                    $data_cate_lists['rank'] = 99;
                    $this->model_cate_lists->add($data_cate_lists);
                }
                if ($gameInfo['cate_id']) {
                    $del_catelists_set['user_id'] = $this->wid;
                    $del_catelists_set['cate_id'] = $gameInfo['cate_id'];
                    $del_catelists_set['type'] = 'game';
                    $del_catelists_set['lists_id'] = $id;
                    $this->model_cate_lists->delete($del_catelists_set);
                }
            }
            $this->show_message(TRUE, '游戏修改成功', '/game/?type='.$gameInfo['type']);
        }
        else
        {
            $errors = validation_errors();
            if ($errors) {
                $this->show_message(FALSE, $errors, '/game/edit/?id='.$id);
            }
        }

        foreach(array('prize','rule','cover_img','tips','advset') as $value)
        {
            if(isset($gameInfo[$value]))
            {
                $gameInfo[$value] = json_decode($gameInfo[$value],true);
            }
        }
        //容错 兼容老的游戏
        $gameInfo['advset']['btype'] = isset($gameInfo['advset']['btype']) ? $gameInfo['advset']['btype'] : 1;
        //print_r($gameInfo);
        //exit;
        //处理奖品图片
        foreach($gameInfo['prize'] as &$prizes)
        {
            if(isset($prizes['pic']) && $prizes['pic'])
            {
                $prizes['smallpic'] = image_url($prizes['pic'], 64, 64);
            }
        }

        $gameInfo['cover_img']['image_start_preview'] = image_url($gameInfo['cover_img']['image_start'], 640, 320);
        $gameInfo['cover_img']['image_end_preview'] = image_url($gameInfo['cover_img']['image_end'], 640, 320);
        $gameInfo['start_time'] = date('Y-m-d H:i:s', $gameInfo['start_time']);
        $gameInfo['end_time'] = date('Y-m-d H:i:s', $gameInfo['end_time']);
        $tpl_data['game'] = $gameInfo;
        $tpl_data['cate_arr'] = $this->cateData;

        $tpl_data['game_type'] = $this->game_type[$gameInfo['type']];
        $tpl_data['token'] = $this->token;
        if($gameInfo['type'] == 2)
        {
            $tpl_data['rewards'] = $this->fruitPrizeRewards();
        }
        else
        {
            $tpl_data['rewards'] = $this->rewards;
        }
        $this->twig->display('game/'.$this->game_type[$gameInfo['type']]['tpl'].'/edit', $tpl_data);
    }

    private function fruitPrizeRewards()
    {
        $rewardArr['rewards'] = $this->rewards;

        $rewardArr['icons'] = array(
            '1' => '<i class="ic-fruit-1"></i><i class="ic-fruit-1"></i><i class="ic-fruit-1"></i>',
            '2' => '<i class="ic-fruit-3"></i><i class="ic-fruit-3"></i><i class="ic-fruit-3"></i>',
            '3' => '<i class="ic-fruit-1"></i><i class="ic-fruit-1"></i><i class="ic-fruit-3"></i>',
            '4' => '<i class="ic-fruit-1"></i><i class="ic-fruit-2"></i><i class="ic-fruit-2"></i>',
            '5' => '<i class="ic-fruit-1"></i><i class="ic-fruit-5"></i><i class="ic-fruit-5"></i>',
            '6' => '<i class="ic-fruit-9"></i><i class="ic-fruit-3"></i><i class="ic-fruit-3"></i>',
            '7' => '<i class="ic-fruit-3"></i><i class="ic-fruit-4"></i><i class="ic-fruit-4"></i>',
            '8' => '<i class="ic-fruit-4"></i><i class="ic-fruit-5"></i><i class="ic-fruit-5"></i>',
            '9' => '<i class="ic-fruit-9"></i><i class="ic-fruit-8"></i><i class="ic-fruit-3"></i>',
            '10' => '<i class="ic-fruit-4"></i><i class="ic-fruit-5"></i><i class="ic-fruit-6"></i>'
        );
        return $rewardArr;
    }

    /**
     * 内定中奖者
     */
    public function slate()
    {
        $id = $this->input->get('id');
        //查询是否是自己创建的游戏
        $gameInfo = $this->modelObj->get_row(array('id'=>$id,'wid'=>$this->wid));
        if(!$gameInfo)
        {
            $this->show_message(FALSE, '对不起，你没有权限执行当前操作', '/game');
        }

        //内定列表
        $slateList = $this->model_game_record->get_all(array('gid'=>$gameInfo['id'],'slated'=>1));

        //所有奖品
        $prize = json_decode($gameInfo['prize'],true);

        $prizeList = array();
        foreach($prize as $key=> $v)
        {
            if($v['true_number']>0 && $v['true_number']<=$v['number'])
            {
                $v['numbers'] = $v['true_number'];
            }
            else
            {
                $v['numbers'] = $v['number'];
            }
            $v['type'] = $key+1;
            //是否抽完
            $totalRows = $this->model_game_record->total_rows(array('gid'=>$gameInfo['id'],'prize_type'=>$v['type']));
            if($totalRows >= $v['numbers'])
            {
                $v['over'] = 1;
            }
            else
            {
                $v['over'] = 0;
            }
            $prizeList[] = $v;
        }
        //array_push($prizeList, array('type'=>0, 'name'=>'谢谢参与','numbers'=>9999999));
        //是否抽中
        //print_r($prizeList);

        $this->form_validation->set_rules('prize_type', '奖品', 'trim');
        $this->form_validation->set_rules('mobile', '手机号', 'trim|required|max_length[11]|htmlspecialchars');
        if($this->form_validation->run())
        {
            //选中的奖品是否已经抽完
            $prize_type = $this->form_validation->set_value('prize_type');
            if($prizeList[$prize_type-1]['over']==1)
            {
                $this->show_message(FALSE, '该奖品已经被抽完，不能内定了', '/game/slate/?id='.$id);
            }

            //查询该手机号码是否是注册用户
            $mobile = $this->form_validation->set_value('mobile');
            $this->load->model('model_account');
            $account = $this->model_account->get_row(array('wid' => $this->wid, 'mobile'=>$mobile));
            if(!$account)
            {
                $this->show_message(FALSE, '该手机号码还没有注册，不能内定中奖', '/game/slate/?id='.$id);
            }
            $data['wid'] = $this->wid;
            $data['gid'] = $id;
            $data['uid'] = $account['id'];
            $data['slated'] = 1;
            $data['flag'] = 1;
            $data['mobile'] = $mobile;
            $data['prize_type'] = $prizeList[$prize_type-1]['type'];
            $data['prize_name'] = $prizeList[$prize_type-1]['name'];
            $data['inputtime'] = time();

            $this->model_game_record->add($data);
            $this->show_message(true, '内定成功', '/game/slate/?id='.$id);
        }
        else
        {
            $errors = validation_errors();
            if ($errors) {
                $this->show_message(FALSE, $errors, '/game/slate/?id='.$id);
            }
        }

        $tpl['prizelist'] = $prizeList;
        $tpl['gameinfo'] = $gameInfo;
        $tpl['slatelist'] = $slateList;

        $this->twig->display('game/slate',$tpl);
    }

    /**
     * 取消内定中奖
     */
    public function resetSlate()
    {
        $id = $this->input->get('id');
        $wid = $this->wid;
        $gid = $this->input->get('gid');
        //查询记录是否存在
        $where = array(
            'wid'   =>  $wid,
            'id'    =>  $id
        );
        $record = $this->model_game_record->get_row($where);
        if(!$record || $record['slated'] != 1)
        {
            $this->show_message(FALSE, '取消内定失败，内定不存在', '/game/slate/?id='.$gid);
        }
        if($record['status'] != 0 )
        {
            $this->show_message(FALSE, '用户已提交中奖信息，无法取消', '/game/slate/?id='.$gid);
        }
        //执行取消操作
        $this->model_game_record->delete($where);
        $this->show_message(true, '取消成功', '/game/slate/?id='.$gid);
    }

    /**
     * name 删除游戏
     */
    public function delete()
    {
        $id = $this->input->get('id');
        //查询是否是自己创建的游戏
        $gameInfo = $this->modelObj->get_row(array('id'=>$id,'wid'=>$this->wid));
        if(!$gameInfo)
        {
            $this->show_message(FALSE, '对不起，你没有权限删除当前游戏', '/game');
        }
        //执行删除操作
        $this->modelObj->delete(array('id'=>$id));

        //如果规档
        if ($gameInfo['cate_id']) {
            $del_data_cate_lists['user_id'] = $this->wid;
            $del_data_cate_lists['cate_id'] = $gameInfo['cate_id'];
            $del_data_cate_lists['type'] = 'game';
            $del_data_cate_lists['lists_id'] = $id;
            $this->model_cate_lists->delete($del_data_cate_lists);
        }

        $this->show_message(true, '游戏删除成功！', '/game/?type='.$gameInfo['type']);
    }

    /**
     * 活动统计
     */
    public function record()
    {
        $id = $this->input->get_post('id');
        $p = $this->input->get('per_page');
        $p = $p ? $p : self::CUR_PAGE;
        //查询是否存在
        $gameInfo = $this->modelObj->get_row(array('id'=>$id,'wid'=>$this->wid));
        //print_r($gameInfo);

        if(!$gameInfo)
        {
            $this->show_message(FALSE, '该游戏不存在', '/game');
        }
        //奖品
        foreach(array('prize','rule','cover_img','tips','advset') as $value)
        {

            if(isset($gameInfo[$value]))
            {

            }
        }
        $gameInfo['prize'] = json_decode($gameInfo['prize'],true);
        $tpl['gameinfo'] = $gameInfo;

        //查询中奖结果
        $where = array(
            'gid' => $id,
            'wid' => $this->wid
        );

        //总参加人数
        $tpl['joinnums'] = $this->model_game_record->total_rows_group($where,'mobile');

        $this->route = '/game/record/?id='.$id;
        //查询按奖品名
        $prizename = $this->input->get_post('prizename');
        if($prizename)
        {
            $where['prize_name'] = 'like:'.$prizename;
            $tpl['prize_name'] = $prizename;
            $this->route .= '&prizename='.$prizename;
        }
        //查询按奖品类型
        $prizetype = $this->input->get_post('prizetype');
        if($prizetype)
        {
            $where['prize_type'] = $prizetype;
            $tpl['prizetype'] = $prizetype;
            $this->route .= '&prizetype='.$prizetype;
        }
        //查询按中奖者姓名
        $username = $this->input->get_post('username');
        if($username)
        {
            $where['username'] = 'like:'.$username;
            $tpl['username'] = $username;
            $this->route .= '&username='.$username;
        }
        //查询按手机号
        $mobile = $this->input->get_post('mobile');
        if($mobile)
        {
            $where['mobile'] = 'like:'.$mobile;
            $tpl['mobile'] = $mobile;
            $this->route .= '&mobile='.$mobile;
        }
        //查询按状态
        $status = $this->input->get_post('status');
        if(isset($status))
        {
            if(in_array($status,array(0,1,2,3)))
            {
                $where['status'] = $status ? $status : 0;
                $tpl['status'] = $status;
                $this->route .= '&status='.$status;
            }
        }

        if(!isset($status) || $status==-1)
        {
            $where['status>='] = 0;
            $tpl['status'] = -1;
            $this->route .= '&status=-1';
        }

        $tpl['where'] = $where;

        $where['flag'] = 1;

        $this->pageQueryString = true;
        $this->pageSize = 10;

        $list = $this->model_game_record->get_all($where, $this->pageSize, $p);

        $tpl['list'] = $list;

        //中奖人数
        $tpl['winnums'] = $this->model_game_record->total_rows($where);
        $tpl['pages'] = $this->pages($tpl['winnums']);

        $this->twig->display('game/record', $tpl);
    }

    public function log()
    {
        $id = $this->input->get('id',true);
        $this->load->model('game_edit_log_model');

        //查询是否存在
        $gameInfo = $this->modelObj->get_row(array('id'=>$id,'wid'=>$this->wid));
        //print_r($gameInfo);

        if(!$gameInfo)
        {
            $this->show_message(FALSE, '该游戏不存在', '/game');
        }
        //查询修改记录
        $where = array('site_id'=>$this->wid,'gid'=>$id);
        //$total_rows = $this->game_edit_log_model->where($where)->count();

        $result = $this->game_edit_log_model->where($where)->limit(20, 0)->order_by('id desc')->find_all();
        if($result)
        {
            foreach($result as &$_result)
            {
                $_result['prize'] = json_decode($_result['prize'],true);
                $_result['rule'] = json_decode($_result['rule'],true);
            }
        }
        //print_r($result);exit;
        $tpl['gameinfo'] = $gameInfo;
        $tpl['list'] = $result;

        $this->twig->display('game/log', $tpl);
    }

    public function setStatus()
    {
        header('Content-type: application/json');
        $gid = $this->input->post('gid');
        //查询是否存在
        $gameInfo = $this->modelObj->get_row(array('id'=>$gid,'wid'=>$this->wid));
        if(!$gameInfo)
        {
            echo json_encode(array('ret'=>1001,'msg'=>'游戏不存在，无法设置状态！'));
            exit;
        }
        //中奖记录是否存在
        $id = $this->input->post('id');
        $rwhere = array('id'=>$id);
        $recordInfo = $this->model_game_record->get_row($rwhere);

        if(!$recordInfo)
        {
            echo json_encode(array('ret'=>1002,'msg'=>'中将记录不存在，无法设置状态！'));
            exit;
        }
        $status = $this->input->post('status');
        if(!is_numeric($status) && $status!=2)
        {
            echo json_encode(array('ret'=>1003,'msg'=>'未知状态'));
            exit;
        }
        if($recordInfo['status'] >= $status)
        {
            echo json_encode(array('ret'=>1004,'msg'=>'设置失败'));
            exit;
        }

        $this->model_game_record->update($rwhere,array('status'=>$status,'gettime'=>time()));
        echo json_encode(array('ret'=>0,'msg'=>'设置成功'));
        exit;
    }

    /**
     * 导出
     */

    public function export()
    {
        $id = $this->input->get_post('id');
        //查询是否存在
        $gameInfo = $this->modelObj->get_row(array('id'=>$id,'wid'=>$this->wid));
        if(!$gameInfo)
        {
            $this->show_message(FALSE, '该游戏不存在', '/game');
        }
        $where = array(
            'wid' => $this->wid,
            'gid' => $id,
            'flag'=>1
        );
        $prizename = $this->input->post('prizename');
        if($prizename)
        {
            $where['prize_name'] = 'like:'.$prizename;
        }
        //查询按奖品类型
        $prizetype = $this->input->get_post('prizetype');
        if($prizetype)
        {
            $where['prize_type'] = $prizetype;
        }
        $mobile = $this->input->post('mobile');
        if($mobile)
        {
            $where['mobile'] = 'like:'.$mobile;
        }

        $status = $this->input->post('status');
        if(isset($status))
        {
            if(in_array($status,array(0,1,2,3)))
            {
                $where['status'] = $status ? $status : 0;
            }
        }

        if(!isset($status) || $status==-1)
        {
            $where['status >= '] = 0;
        }

        $recordArr = array();
        $list = $this->model_game_record->get_all($where);
        foreach ($list as $k=> $row)
        {
            if($row['status'] == 0)
            {
                $row['status'] = '未确认';
            }
            elseif($row['status'] == 1)
            {
                $row['status'] = '已确认';
            }
            elseif($row['status'] == 2)
            {
                $row['status'] = '已兑奖';
            }
            elseif($row['status'] == 3)
            {
                $row['status'] = '已放弃';
            }
            $row['inputtime'] = date('Y-m-d H:i:s', $row['inputtime']);
            $recordArr[] = $row;
        }
        $fields = array(
            '#'=>'#',
            'mobile'=>'手机号',
            'wxid'  =>'openid',
            'username'=>'中奖者姓名',
            'address'=>'联系地址',
            'prize_name'=>'奖品',
            'status'    =>'状态',
            'inputtime'=>'中奖时间'
        );
        $this->excel_export($gameInfo['title'].'中奖结果', '中奖结果', $fields, $recordArr);
    }

    public function search_x()
    {
        $data = array(
            'list'	=> array(),
            'last_page'		=> 0,
            'next_page'		=> 0,
        );

        $time = time();
        $where_set = array('wid' => User::$user_id, 'is_deleted'=>0,'start_time < ' => $time, 'end_time > '=> $time);

        $catId = trim($this->input->get('cate_id'));
        if ($catId) {
            $where_set['cate_id'] = $catId;
        }

        $keyword = trim($this->input->get('keyword'));
        if ($keyword) {
            $where_set['title'] = 'like:'.$keyword;
        }

        $total = $this->modelObj->total_rows($where_set);
        $page = intval($this->input->get('page'));
        $page = $page < 1 ? 1 : $page;
        $per_page = 5;

        $list = $this->modelObj->get_all($where_set, $per_page, $page);
        foreach ($list as &$row) {
            $cover_img = json_decode($row['cover_img'], true);
            $row['image_preview'] = image_url($cover_img['image_start'], 80, 80);
            $row['image_start'] = $cover_img['image_start'];
        }

        $data['game_list'] = $list;
        if ($page * $per_page < $total) {
            $data['next_page'] = $page + 1;
        }
        if ($page > 1) {
            $data['last_page'] = $page - 1;
        }
        header('Content-type: application/json');
        echo json_encode($data);
    }
}