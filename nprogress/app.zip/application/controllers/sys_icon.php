<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Sys_icon extends CI_Controller {
	public function __construct() {
		parent::__construct();		
	}

	public function typelist(){
		$data = array();
		$data[0] = array('id'=>1, 'name'=>'企业风采');
		$data[1] = array('id'=>2, 'name'=>'产品介绍');
		$data[2] = array('id'=>3, 'name'=>'服务介绍');
		$data[3] = array('id'=>4, 'name'=>'品牌介绍');
		$data[4] = array('id'=>5, 'name'=>'联系方式');
		$data[5] = array('id'=>6, 'name'=>'交通工具');
		$data[6] = array('id'=>7, 'name'=>'楼房');
		$data[7] = array('id'=>8, 'name'=>'新闻');
		$data[8] = array('id'=>9, 'name'=>'活动');
		$data[9] = array('id'=>10, 'name'=>'会员');
		
		header('Content-type: application/json');
		echo json_encode($data);		
	}
	
	public function icons($t=''){
		$data = array();
		$data['t'] = $t;
		
		$icons = array();
		for($i=1; $i<8; $i++){
			$icons[] = array('url'=>c_image_url('/assets/img/sys_icons/'.$t.'_'.$i.'.png'),'id'=>$t.'_'.$i);
		}		
		$data['icons'] = $icons;
		
		header('Content-type: application/json');
		echo json_encode($data);		
	}
}