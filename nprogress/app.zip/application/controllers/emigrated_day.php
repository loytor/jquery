<?php
class Emigrated_day extends MY_Controller
{
    private $wid = null;
    private $tpl_data = array();

    public function __construct()
    {
        parent::__construct();
        $this->wid = User::$user_id;
        $this->tpl_data['cur_nav'] = 'marketing';
        $this->load->model('model_emigrated_day');
    }
    
    public function index($emigrated_id='')
    {
        if( !$emigrated = $this->emigrated($emigrated_id) ){
            $this->show_message(FALSE, '非法参数', '/emigrated');
        }
        $where_set = array(
            'emigrated_id' => $emigrated_id,
            'wid'       => $this->wid
        );
        $list = $this->model_emigrated_day->get_all($where_set,'','','id','asc','id,day,num_sys,num_cus');
        $this->tpl_data['list'] = $list;
        $this->tpl_data['count_list'] = count($list);
        $this->tpl_data['curtitle'] = '设置问题';
        
        $this->twig->display('emigrated_day/index',$this->tpl_data);
    }
    
    //编辑 赛前文字和添加试题
    public function update($id='')
    {
        $emigrated_day = $this->model_emigrated_day->get_row(array('id'=>$id),'id,emigrated_id,day,num_sys,num_cus,content,content_time');
        if( !$emigrated_day ){
            $this->show_message(FALSE, '非法参数', '',1);
        }
        if( !$emigrated = $this->emigrated($emigrated_day['emigrated_id']) ){
            $this->show_message(FALSE, '非法参数', '',1);
        }
        
        $this->tpl_data['status'] = $emigrated['status'];
        $this->load->model('model_emigrated_question');
        
        //TODO  ALTER TABLE  `emigrated_question` ADD  `title_sort` SMALLINT( 3 ) NOT NULL DEFAULT  '0' AFTER  `title_img` ;
        
        //题目排序数
        $ques_array_num = array();
        for( $i=1;$i<=$emigrated['ques_nums'];$i++ ){
            $ques_array_num[$i] = $i;
        }
        $this->tpl_data['ques_array_num'] = $ques_array_num;
        
        //验证并保存
        $this->load->library('form_validation');
        $this->form_validation->set_rules('content', '赛前阅读', 'trim|htmlspecialchars');
        $this->form_validation->set_rules('content_time', '阅读时间', 'integer|greater_than_equal_to[3]|less_than_equal_to[60]');
        $this->form_validation->set_rules('question', '题目内容', 'trim|max_length[50]');
        if($this->form_validation->run()){
            $data_set['content']      = $this->form_validation->set_value('content');
            $data_set['content_time'] = $this->form_validation->set_value('content_time');
            if( $data_set['content']&&$data_set['content_time'] ){
                $where_set = array(
                    'id'  => $id,
                    'wid' => $this->wid
                );
                if(false===$this->model_emigrated_day->update($where_set,$data_set)){
                    $this->show_message(FALSE, '保存失败', '',1);
                }
            }
            $question = $this->form_validation->set_value('question');
            if( $question ){
                if( $emigrated_day['num_sys']==0 ){
                    $this->show_message(FALSE, '自定义题目最多'.$emigrated_day['num_cus'].'个', '',1);
                }
                $question_img  = $this->input->post('question_img');
                $question_sort = $this->input->post('question_sort');
                $true_option   = $this->input->post('true_option');
                $option_temp   = $this->input->post('option');
                $options = array();//保存选项
                $i = 0;//给选项加唯一值
                $true_correct = 0;
                foreach ( $option_temp as $key=>$val ){
                    if( $val['text'] ){
                        if( (MB_ENABLED === TRUE)?(mb_strlen($val['text'])>50 ):(strlen($val['text'])>50 ) ){
                            $this->show_message(FALSE, '答案内容最多50个字', '',1);
                        }
                        $correct = 0;
                        if( $true_option==$key ){
                            $correct = 1;
                            $true_correct = 1;
                        }
                        $options[$i] = array(
                            'id'        => $i+1,
                            'title'     => $val['text'],
                            'title_img' => $val['img'],
                            'correct'   => $correct
                        );
                        $i++;
                    }
                }
                if( !$options ){
                    $this->show_message(FALSE, '答案内容不能为空', '',1);
                }
                if( !$true_correct ){
                    $this->show_message(FALSE, '请重新选择正确选项', '',1);
                }
                $option_set = array(
                    'day_id' => $id,
                    'wid'    => $this->wid,
                    'title'  =>  $question,
                    'title_img' => $question_img,
                    'title_sort'=> $question_sort,
                    'options'   => json_encode($options),
                    'add_time'  => time()
                );
                if( !$this->model_emigrated_question->add($option_set) ){
                    $this->show_message(FALSE, '保存失败', '',1);
                }else{
                    $this->db->query("update emigrated_day set num_sys=num_sys-1,num_cus=num_cus+1 where id=".$id);
                    $this->show_message(TRUE, '保存成功', '/emigrated_day/update/'.$id);
                }
            }else{
                $this->show_message(TRUE, '保存成功', '/emigrated_day/update/'.$id);
            }
        }else{
            $errors = validation_errors();
            if ($errors) {
                $this->show_message(FALSE, $errors, '/emigrated/add');
            }
        }
        
        $this->tpl_data['info'] = $emigrated_day;
        //自定义题目列表
        $list = $this->model_emigrated_question->get_all(array('wid'=>$this->wid,'day_id'=>$id),'','','id','desc','id,title');
        $this->tpl_data['list'] = $list;
        
        $this->token();
        $this->tpl_data['curtitle'] = '添加';
        $this->twig->display('emigrated_day/update',$this->tpl_data);
    }
    
    //编辑 赛前文字和编辑试题
    //试题id
    public function edit($id='')
    {
        $this->load->model('model_emigrated_question');
        $question = $this->model_emigrated_question->get_row(array('id'=>$id));
        if( !$question ){
            $this->show_message(FALSE, '非法参数', '',1);
        }
        $emigrated_day = $this->model_emigrated_day->get_row(array('id'=>$question['day_id']),'id,emigrated_id,day,num_sys,num_cus,content,content_time');
        if( !$emigrated_day ){
            $this->show_message(FALSE, '非法参数', '',1);
        }
        if( !$emigrated = $this->emigrated($emigrated_day['emigrated_id']) ){
            $this->show_message(FALSE, '非法参数', '',1);
        }
        
        //题目排序数
        $ques_array_num = array();
        for( $i=1;$i<=$emigrated['ques_nums'];$i++ ){
            $ques_array_num[$i] = $i;
        }
        $this->tpl_data['ques_array_num'] = $ques_array_num;
        
        //验证并保存
        $this->load->library('form_validation');
        $this->form_validation->set_rules('question', '题目内容', 'trim|required|max_length[50]');
        if($this->form_validation->run()){
            $question = $this->form_validation->set_value('question');
            if( $question ){
                $question_img = $this->input->post('question_img');
                $question_sort = $this->input->post('question_sort');
                $true_option = $this->input->post('true_option');
                $option_temp = $this->input->post('option');
                $options = array();//保存选项
                $i = 0;//给选项加唯一值
                $true_correct = 0;//正确选项是否写对
                foreach ( $option_temp as $key=>$val ){
                    if( $val['text'] ){
                        if( (MB_ENABLED === TRUE)?(mb_strlen($val['text'])>50 ):(strlen($val['text'])>50 ) ){
                            $this->show_message(FALSE, '答案内容最多50个字', '',1);
                        }
                        $correct = 0;
                        if( $true_option==$key ){
                            $correct = 1;
                            $true_correct = 1;
                        }
                        $options[$i] = array(
                            'id'        => $i+1,
                            'title'     => $val['text'],
                            'title_img' => $val['img'],
                            'correct'   => $correct
                        );
                        $i++;
                    }
                }
                if( !$options ){
                    $this->show_message(FALSE, '答案内容不能为空', '',1);
                }
                if( !$true_correct ){
                    $this->show_message(FALSE, '请重新选择正确选项', '',1);
                }
                $option_set = array(
                    'title'  =>  $question,
                    'title_img' => $question_img,
                    'title_sort'=> $question_sort,
                    'options'   => json_encode($options)
                );
                if( !$this->model_emigrated_question->update(array('id'=>$id),$option_set) ){
                    $this->show_message(FALSE, '保存失败', '',1);
                }else{
                    $this->show_message(TRUE, '保存成功', '/emigrated_day/index/'.$emigrated['id']);
                }
            }
            
        }else{
            $errors = validation_errors();
            if ($errors) {
                $this->show_message(FALSE, $errors, '/emigrated_day/edit/'.$id);
            }
        }
        
        
        $question['options'] = json_decode($question['options'],true);
        $abc = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
        foreach( $question['options'] as $key=>$value ){
            $question['options'][$key]['abc'] = $abc[$key];
        }
        
        $this->tpl_data['info'] = $question;
        $this->tpl_data['option_num'] = count($question['options']);
        $this->tpl_data['emigrated_day'] = $emigrated_day;
        //自定义题目列表
        //$list = $this->model_emigrated_question->get_all(array('wid'=>$this->wid,'day_id'=>$id),'','','id','desc','id,title');
        $this->tpl_data['list'] = '';
        
        $this->token();
        $this->tpl_data['curtitle'] = '修改问题';
        $this->twig->display('emigrated_day/edit',$this->tpl_data);
    }
    
    public function delete($id='')
    {
        $this->load->model('model_emigrated_question');
        $question = $this->model_emigrated_question->get_row(array('id'=>$id));
        if( !$question ){
            $this->show_message(FALSE, '非法参数', '',1);
        }
        $emigrated_day = $this->model_emigrated_day->get_row(array('id'=>$question['day_id']),'id,emigrated_id,day,num_sys,num_cus,content,content_time');
        if( !$emigrated_day ){
            $this->show_message(FALSE, '非法参数', '',1);
        }
        if( !$emigrated = $this->emigrated($emigrated_day['emigrated_id']) ){
            $this->show_message(FALSE, '非法参数', '',1);
        }
        if( $this->model_emigrated_question->delete(array('id'=>$id)) ){
            $this->db->query("update emigrated_day set num_sys=num_sys+1,num_cus=num_cus-1 where id=".$emigrated_day['id']);
            $this->show_message(TRUE, '删除成功', '/emigrated_day/update/'.$emigrated_day['id']);
        }else{
            $this->show_message(FALSE, '删除失败', '/emigrated_day/update/'.$emigrated_day['id']);
        }
    }
    
    //统计
    public function statistics($emigrated_id='')
    {
        if( !$emigrated = $this->emigrated($emigrated_id) ){
            $this->show_message(FALSE, '非法参数', '/emigrated');
        }
        $this->tpl_data['emigrated_id'] = $emigrated_id;
        $where_set = array(
            'emigrated_id' => $emigrated_id,
            'wid'       => $this->wid
        );
        $record_list = $this->model_emigrated_day->get_all($where_set,'','','id','asc');
        foreach( $record_list as $key=>$val ){
            $rate = $val['joins'] ? number_format($val['overs']/$val['joins'],3)*100 : 0;
            $record_list[$key]['rate'] = $rate;
        }
        $this->tpl_data['list'] = $record_list;
        
        $this->tpl_data['curtitle'] = '数据统计';
        $this->twig->display('emigrated_day/statistics',$this->tpl_data);
    }
    
    //参与用户
    public function all_user()
    {
        $eid = intval($this->input->get('eid'));
        $did = intval($this->input->get('did'));
        !$eid && $this->show_message(FALSE, '非法参数', '',1);
        if( !$emigrated = $this->emigrated($eid) ){
            $this->show_message(FALSE, '非法参数', '',1);
        }
        $this->tpl_data['emigrated_id'] = $eid;
        $where = array(
            'emigrated_record.wid' => $this->wid,
            'emigrated_record.eid' => $eid
        );
        if( $did ){
            $emigrated_day = $this->model_emigrated_day->get_row(array('emigrated_id'=>$eid,'id'=>$did));
            if( !$emigrated_day ){
                $this->show_message(FALSE, '非法参数', '',1);
            }
            $where['emigrated_record.did'] = $did;
        }
        $this->tpl_data['did'] = $did;
        $this->load->model('model_emigrated_record');
        $from_time   = $this->input->get_post('from_time');
        $to_time     = $this->input->get_post('to_time');
        ($search['from_time'] = $from_time) && $where['emigrated_day.day>='] = strtotime($from_time);
        ($search['to_time'] = $to_time) && $where['emigrated_day.day<='] = strtotime($to_time);
        $this->tpl_data['search'] = $search;
        $search_route = '';
        if( $where ){
            foreach( $search as $key=>$val ){
                if( $val ){
                    $search_route .= '&'.$key.'='.$val;
                }
            }
        }
        $this->load->library('pagination');
        $pagination_config = array(
            'base_url'      => '/emigrated_day/all_user?eid='.$eid.'&did='.$did.$search_route,
            'total_rows'    => $this->model_emigrated_record->all_user($where,'',0,0,true),
            'per_page'      => 15,
            'page_query_string' => TRUE
        );
        $this->pagination->initialize($pagination_config);
        $this->tpl_data['pagination'] = $this->pagination->create_links();
        $per_page = $pagination_config['per_page'];
        $now_page = (int)$this->input->get('per_page') ? (int)$this->input->get('per_page') : 1;
        $this->tpl_data['per_page'] = $per_page;
        $this->tpl_data['now_page'] = $now_page;
        $start = ($now_page-1)*$per_page;
        $this->tpl_data['total_rows'] = $pagination_config['total_rows'];
        
        
        $list = $this->model_emigrated_record->all_user($where,'',$start,$per_page);
        $this->tpl_data['list'] = $list;
        
        $this->tpl_data['curtitle'] = '闯关用户数据';
        $this->twig->display('emigrated_day/all_user',$this->tpl_data);
    }
    
    public function export()
    {
        $eid = intval($this->input->get('eid'));
        $did = intval($this->input->get('did'));
        !$eid && $this->show_message(FALSE, '非法参数', '',1);
        if( !$emigrated = $this->emigrated($eid) ){
            $this->show_message(FALSE, '非法参数', '',1);
        }
        $where = array(
            'emigrated_record.wid' => $this->wid,
            'emigrated_record.eid' => $eid
        );
        if( $did ){
            $emigrated_day = $this->model_emigrated_day->get_row(array('emigrated_id'=>$eid,'id'=>$did));
            if( !$emigrated_day ){
                $this->show_message(FALSE, '非法参数', '',1);
            }
            $where['emigrated_record.did'] = $did;
        }
        $this->load->model('model_emigrated_record');
        $from_time   = $this->input->get_post('from_time');
        $to_time     = $this->input->get_post('to_time');
        ($search['from_time'] = $from_time) && $where['emigrated_day.day>='] = strtotime($from_time);
        ($search['to_time'] = $to_time) && $where['emigrated_day.day<='] = strtotime($to_time);
        $list = $this->model_emigrated_record->all_user($where,'','','');
        foreach( $list as $key=>$val ){
            $list[$key]['day'] = date('Y-m-d',$val['day']);
        }
        
        $fields = array(
            'name'=>'用户名',
            'mobile'=>'手机号',
            'day'=>'参与时间',
            'score'=>'得分'
        );
        $this->excel_export('答题闯关参与会员列表', '参与会员信息', $fields, $list);
    }
    
    private function emigrated($emigrated_id)
    {
        $this->load->model('model_emigrated');
        $where_set = array(
            'id'        => $emigrated_id,
            'is_delete' => 0,
            'wid'       => $this->wid
        );
        $info = $this->model_emigrated->get_row($where_set,'id,title,status,ques_nums');
        return $info;
    }
    
    //token
    private function token()
    {
        $this->load->library('encrypt');
        $token_data = array('user_id' => $this->wid, 'time' => time());
        $this->tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
    }

}