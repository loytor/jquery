<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: along
 * Date: 13-8-19
 * Time: 上午9:19
 * To change this template use File | Settings | File Templates.
 * @property Model_caipiao $model_caipiao
 * @property Model_caipiao_setting $model_caipiao_setting
 * @property Model_user $model_user
 */
class Caipiao extends MY_Controller {
	public function __construct() {
		parent::__construct();
	}

	public function index() {
		$tpl['cur_nav'] = 'marketing';

		$this->load->model('model_caipiao');
		//取彩票列表

		$page = intval($this->uri->segment($this->urlSegment, self::CUR_PAGE));
		$where = array('bid'=>User::$user_id);
		$list = $this->model_caipiao->get_all($where, $this->pageSize, $page);
		foreach($list as &$_list)
		{
			$_list['content'] = json_decode($_list['content'],true);
		}

		//print_r($list);
		$tpl['lottery_arr'] = $list;
		$tpl['page'] = $page;
		$tpl['pages'] = $this->pages($this->model_caipiao->total_rows($where));


		$this->twig->display('caipiao/index', $tpl);
	}

    public function export()
    {
        $this->load->model('model_caipiao');
        $where = array('bid'=>User::$user_id);
        $list = $this->model_caipiao->get_all($where);
        if( $list ){
            $export_list = array();
            foreach($list as &$_list)
            {
                $_list['content'] = json_decode($_list['content'],true);
                $export_list[] = array(
                    'lotteryType' => isset($_list['content']['lotteryType']) ? $_list['content']['lotteryType'] : '',
                    'lotteryTerm' => isset($_list['content']['lotteryTerm']) ? $_list['content']['lotteryTerm'] : '',
                    'lotteryNo' => isset($_list['content']['lotteryNo']) ? $_list['content']['lotteryNo'] : '',
                    'mobile' => isset($_list['mobile']) ? $_list['mobile'] : '',
                    'inputtime' => isset($_list['inputtime']) ? date('Y-m-d H:i:s',$_list['inputtime']) : ''
                );
            }

            $fields = array(
                '#'=>'#',
                'lotteryType'=>'彩票种类',
                'lotteryTerm'=>'彩票期数',
                'lotteryNo'=>'彩票号码',
                'mobile'=>'手机号',
                'inputtime'=>'领取时间'
            );
            $this->excel_export('彩票', '彩票', $fields, $export_list);
        }
    }

	public function settings()
	{

		$this->load->model('model_caipiao_setting');

		$tpl = array();
		$tpl['num'] = $tpl['stime'] = $tpl['etime'] = '';
		$row = $this->model_caipiao_setting->get_row(array('wid' => User::$user_id));

		$this->load->model('model_caipiao');
		$num = $this->model_caipiao->total_rows(array('bid'=>User::$user_id));
		$this->load->model('site_caipiao_model');
        $caipiaoNum = $this->site_caipiao_model->where(array('site_id' => User::$user_id))->get_field('caipiao_num');

		if ($this->submitCheck()) {
			$d['num'] = (int)$this->input->post('num');

			if ($d['num'] > ($caipiaoNum - $num)) {
				$this->show_message(FALSE, '您的可领取彩票数量不够，请重新设置规则', '/caipiao');
			}
			$d['stime'] = strtotime($this->input->post('stime'));
			$d['etime'] = strtotime($this->input->post('etime'));
			if (!empty($row)) {
				$this->model_caipiao_setting->update(array('wid' => User::$user_id), $d);
			}
			else {
				$d['wid'] = User::$user_id;
				$this->model_caipiao_setting->add($d);
			}
			$this->show_message(FALSE, '设置彩票规则成功', '/caipiao');
		}


		if (!empty($row)) {
			$tpl['num'] = $row['num'];
			$tpl['stime'] = date('Y-m-d H:i:s', $row['stime']);
			$tpl['etime'] = date('Y-m-d H:i:s', $row['etime']);
		}

		$tpl['caipiao_num'] = $caipiaoNum;
		$tpl['receiveNum'] = $num;
		$this->twig->display('caipiao/setting', $tpl);
	}
}