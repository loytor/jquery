<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Class Setting
 * @property Model_user $model_user
 * @property Model_welcome $model_welcome
 * @property Model_cate $model_cate
 * @property Model_scrollinfo $model_scrollinfo
 * @property Model_assist $model_assist
 */
class Butt extends MY_Controller {

	public function __construct() {
		parent::__construct();
        $this->load->config('alipay_key');
	}

    /**
     *
     * @author Qianc
     * @date 2014-7-21
     * @description 微信对接
     */
	public function index() {
		$this->load->model('model_user');
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}

		$user = $this->model_user->get_row($logged_user_id);
		if ( !$user ) {
			redirect_return('/auth/login');
		}

		$this->form_validation->set_rules('mp_username', '公众帐号', 'trim|required');
		if($this->form_validation->run())
		{
			$where['id'] = $logged_user_id;
			$data_set['mp_username'] = $this->form_validation->set_value('mp_username');
			//$data_set['web_name'] = $this->input->post('web_name');

            //$data_set['mp_account'] = trim($this->input->post('mp_account'));
            //$data_set['mp_password'] = trim($this->input->post('mp_password'));
            //验证用户名密码
            //TODO

			$data_set['auto_attention'] = trim($this->input->post('auto_attention'));
            //$data_set['all_domain'] = trim($this->input->post('all_domain'), '/');
			$data_set['appid'] = $this->input->post('appid');
			$data_set['appsecret'] = $this->input->post('appsecret');
			$is_service = intval($this->input->post('is_service')) ;
			if( $is_service==1||$is_service==2 ){
			    $data_set['is_service'] = $is_service;
			    if( $is_service==2 ){
			        $data_set['appid'] = $data_set['appsecret'] = '';
			    }
			    if( $is_service==1 ){
			        if( $data_set['appid']=='' ){
			            $this->show_message(FALSE, 'appid必须填写', '/butt');
			        }
			        if( $data_set['appsecret']=='' ){
                        $this->show_message(FALSE, 'appsecret必须填写', '/butt');
                    }
			    }
			}

			if($this->model_user->update($where, $data_set))
			{
				$this->show_message(TRUE, '保存成功', '/butt');
			}
			else
			{
				$this->show_message(FALSE, '保存失败', '/butt');
			}
		}
		else
		{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/butt');
			}
		}

        $user['en_mp_password'] = str_pad('', mb_strlen($user['mp_password']), '*');
        $user['qrcode'] = 'http://open.weixin.qq.com/qr/code/?username='.$user['mp_username'];
        $tpl_data['user'] = $user;
		$tpl_data['api_url'] = full_url('/api/'.$user['username'], 'w');
		$tpl_data['api_token'] = $user['token'];
		$tpl_data['cur_nav'] = 'butt';

		$this->load->library('encrypt');
		$token_data = array('user_id' => $logged_user_id, 'time' => time());
		$tpl_data['token'] = $this->encrypt->encode(serialize($token_data));

		$this->twig->display('butt/index', $tpl_data);
	}

    /**
     *
     * @author Qianc
     * @date 2014-7-21
     * @description 支付宝对接
     */
    public function alipay() {
        $this->load->model('model_user');
        $logged_user_id = logged_user_id();
        if ( ! $logged_user_id) {
            redirect_return('/auth/login');
        }

        $user = $this->model_user->get_row($logged_user_id);
        if ( !$user ) {
            redirect_return('/auth/login');
        }
        $tpl_data['api_url'] = full_url('/api_alipay/'.$user['username'], 'w');

        $this->load->model('alipay_config_model');
        $app_config = $this->alipay_config_model->get_row(array('site_id'=>$logged_user_id));
        $tpl_data['appid'] = $app_config['appid'];



        //支付宝公钥
        $alipay_key = $this->config->item('alipay_key');
        $ali_public = $alipay_key['public_key'];
        $alipay_key = public_key_clean($ali_public);
        $tpl_data['alipay_key'] = $alipay_key;
        $tpl_data['user'] = $user;
        $this->twig->display('butt/alipay', $tpl_data);
    }




}