<?php
/**
 * Created by PhpStorm.
 * User: 111
 * Date: 14-5-8
 * Time: 下午7:51
 */

class Delrecord extends CI_Controller {

    public function index()
    {
        $p = $this->input->get('p');
        $p = $p ? $p : 1;


        if($p < 200)
        {
            $dsql = 'delete from game_record where flag=0 order by id asc limit 10000';

            $this->db->query($dsql);

            $page = $p+1;
            $urls ='/delrecord/?p='.$page;
            echo '正在删除第'.$p.'页...';
            echo '<script type="text/javascript">var the_timeout;the_timeout = setTimeout("Refresh()",3000);function Refresh(){window.location.href="'.$urls.'"}</script>';
        }
    }

} 