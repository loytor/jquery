<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Image extends CI_Controller {

    protected $app_key = '5318162aac6f0086';
    protected $app_secret = '0c28536510e0b0b429750f478222d549';

    public function upload() {
        $this->load->library('encrypt');
        $token = trim($this->input->get_post('token', TRUE));
        $token_decoded = $this->encrypt->decode($token);
        if ( ! $token_decoded) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => '请通过正常途径上传图片'));
            exit;
        }
        $token_data = unserialize($token_decoded);
        if ( ! isset($token_data['time']) OR ! isset($token_data['user_id']) OR (time() - $token_data['time']) > 3600) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => '页面停留时间过长，请刷新页面重新上传'));
            exit;
        }
        $upload_config = array(
            'upload_path'	=> FCPATH.'images/'.$token_data['user_id'].'/'.date('Ym').'/',
            'allowed_types'	=> 'gif|jpg|jpeg|png',
            'max_size'		=> 1024 * 2,
            'encrypt_name'	=> TRUE,
        );
        $this->load->library('upload', $upload_config);
        if(!is_dir($upload_config['upload_path'])){
            mkdir($upload_config['upload_path'], 0777, TRUE);
        }
        if ( ! $this->upload->do_upload('image')) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => $this->upload->display_errors('', '')));
            exit;
        } else {
            $size = array(array('width'=>80, 'height'=>80, 'resize'=>false), array('width'=>640, 'height'=>320), array('width'=>640, 'height'=>640));
            $image = $this->rest_upload($this->upload->data(), $size);
            header('Content-type: application/json');
            echo json_encode(array(
                'success'		=> 1,
                'image_preview'	=> image_url($image, 80, 80),
                'image_middle'   => image_url($image, 640,320),
                'image'			=> image_url($image),
            ));
            exit;
        }
    }

    public function upload_for_editor() {
        $this->load->library('encrypt');
        $token = trim($this->input->get_post('token', TRUE));
        $token_decoded = $this->encrypt->decode($token);
        if ( ! $token_decoded) {
            header('Content-type: application/json');
            echo json_encode(array('error' => 1, 'message' => '请通过正常途径上传图片'));
            exit;
        }
        $token_data = unserialize($token_decoded);
        if ( ! isset($token_data['time']) OR ! isset($token_data['user_id']) OR (time() - $token_data['time']) > 3600) {
            header('Content-type: application/json');
            echo json_encode(array('error' => 1, 'message' => '页面停留时间过长，请刷新页面重新上传'));
            exit;
        }
        $upload_config = array(
            'upload_path'	=> FCPATH.'images/'.$token_data['user_id'].'/'.date('Ym').'/',
            'allowed_types'	=> 'gif|jpg|jpeg|png',
            'max_size'		=> 1024 * 2,
            'encrypt_name'	=> TRUE,
        );
        $this->load->library('upload', $upload_config);
        if(!is_dir($upload_config['upload_path'])){
            mkdir($upload_config['upload_path'], 0777, TRUE);
        }
        if ( ! $this->upload->do_upload('image')) {
            header('Content-type: application/json');
            echo json_encode(array('error' => 1, 'message' => $this->upload->display_errors('', '')));
            exit;
        } else {
            $size = array(array('width'=>640, 'height'=>640, 'resize'=>false));
            $image = $this->rest_upload($this->upload->data(), $size);
            header('Content-type: application/json');
            echo json_encode(array(
                'error'	=> 0,
                'url'	=> image_url($image, 640, 640),
            ));
            exit;
        }
    }

    public function upload_logo() {
        $this->load->library('encrypt');
        $token = trim($this->input->get_post('token', TRUE));
        $token_decoded = $this->encrypt->decode($token);
        if ( ! $token_decoded) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => '请通过正常途径上传图片'));
            exit;
        }
        $token_data = unserialize($token_decoded);
        if ( ! isset($token_data['time']) OR ! isset($token_data['user_id']) OR (time() - $token_data['time']) > 3600) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => '页面停留时间过长，请刷新页面重新上传'));
            exit;
        }
        $upload_config = array(
            'upload_path'	=> FCPATH.'images/'.$token_data['user_id'].'/'.date('Ym').'/',
            'allowed_types'	=> 'gif|jpg|jpeg|png',
            'max_size'		=> 1024 * 2,
            'encrypt_name'	=> TRUE,
        );
        $this->load->library('upload', $upload_config);
        if(!is_dir($upload_config['upload_path'])){
            mkdir($upload_config['upload_path'], 0777, TRUE);
        }
        if ( ! $this->upload->do_upload('image')) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => $this->upload->display_errors('', '')));
            exit;
        } else {
            $size = array(array('width'=>248, 'height'=>122));
            $image = $this->rest_upload($this->upload->data(), $size);
            header('Content-type: application/json');
            echo json_encode(array(
                'success'		=> 1,
                'image_vipcard_logo'   => image_url($image, 248, 122),
                'image'			=> image_url($image),
            ));
            exit;
        }
    }

    public function upload_background() {
        $this->load->library('encrypt');
        $token = trim($this->input->get_post('token', TRUE));
        $token_decoded = $this->encrypt->decode($token);
        if ( ! $token_decoded) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => '请通过正常途径上传图片'));
            exit;
        }
        $token_data = unserialize($token_decoded);
        if ( ! isset($token_data['time']) OR ! isset($token_data['user_id']) OR (time() - $token_data['time']) > 3600) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => '页面停留时间过长，请刷新页面重新上传'));
            exit;
        }
        $upload_config = array(
            'upload_path'	=> FCPATH.'images/'.$token_data['user_id'].'/'.date('Ym').'/',
            'allowed_types'	=> 'gif|jpg|jpeg|png',
            'max_size'		=> 1024 * 2,
            'encrypt_name'	=> TRUE,
        );
        $this->load->library('upload', $upload_config);
        if(!is_dir($upload_config['upload_path'])){
            mkdir($upload_config['upload_path'], 0777, TRUE);
        }
        if ( ! $this->upload->do_upload('image')) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => $this->upload->display_errors('', '')));
            exit;
        } else {
            $size = array(array('width'=>480, 'height'=>308));
            $image = $this->rest_upload($this->upload->data(), $size);
            header('Content-type: application/json');
            echo json_encode(array(
                'success'		=> 1,
                'image_vipcard_background'   => image_url($image, 480, 308),
                'image'			=> image_url($image),
            ));
            exit;
        }
    }

    public function upload_gd($type='') {
        $this->load->library('encrypt');
        $token = trim($this->input->get_post('token', TRUE));
        $token_decoded = $this->encrypt->decode($token);
        $compress_w = trim($this->input->get_post('compress_w', TRUE));
        $compress_h = trim($this->input->get_post('compress_h', TRUE));
        //file_put_contents('1.txt', print_r($token_decoded, true));
        if ( ! $token_decoded) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => '请通过正常途径上传图片'));
            exit;
        }
        $token_data = unserialize($token_decoded);
        //file_put_contents('2.txt', print_r($token_data, true));
        if ( ! isset($token_data['time']) OR ! isset($token_data['user_id']) OR (time() - $token_data['time']) > 3600) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => '页面停留时间过长，请刷新页面重新上传'));
            exit;
        }
        $upload_config = array(
            'upload_path'	=> FCPATH.'images/'.$token_data['user_id'].'/'.date('Ym').'/',
            'allowed_types'	=> 'gif|jpg|jpeg|png',
            'max_size'		=> 1024 * 2,
            'encrypt_name'	=> TRUE,
        );
        $this->load->library('upload', $upload_config);
        if(!is_dir($upload_config['upload_path'])){
            mkdir($upload_config['upload_path'], 0777, TRUE);
        }
        if ( ! $this->upload->do_upload('image')) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => $this->upload->display_errors('', '')));
            exit;
        } else {
            $image = $this->upload->data();
            //$this->load->helper('image');
            $img_size = getimagesize($image['full_path']);
            $image_url_width = $img_size[0];
            $image_url_height = $img_size[1];
            /***需压缩图片的类型***/
            if( $type!='' )
            {
                switch($type)
                {
                    case 'avatar':
                        if( $image_url_width>160 || $image_url_height>160 )
                        {
                            $image_url_width = $image_url_height = 160;
                        }
                        break;
                    case 'coupon':
                        $image_url_width = 400;
                        $image_url_height = 160;
                        break;
                    case 'printer_qrcode':
                        if($image_url_width != 334 || $image_url_height!=334)
                        {
                            header('Content-type: application/json');
                            echo json_encode(array('success' => 0, 'message' => '二维码图片尺寸不正确，请重新上传'));
                            exit;
                        }
                        break;
                    case 'printer_ad':
                        if($image_url_width != 1300 || $image_url_height!=1064)
                        {
                            header('Content-type: application/json');
                            echo json_encode(array('success' => 0, 'message' => '宣传图片尺寸不正确，请重新上传'));
                            exit;
                        }
                        break;
                    default:break;
                }
                $size = array(array('width'=>$image_url_width,'height'=>$image_url_height));
                if($type == 'compress') {
                    $compress_size['width'] = $compress_w ? $compress_w : $image_url_width;
                    $compress_size['height'] = $compress_h ? $compress_h : $image_url_height;
                    $image = $this->rest_upload($image, array(), TRUE, $compress_size);
                } else {
                    $image = $this->rest_upload($image, $size);
                }
            }
            else
            {
                if($image_url_width > 640)
                {
                    $image_url_width = 640;
                }
                $size = array(array('width'=>$image_url_width, 'height'=>$image_url_height));
                $image = $this->rest_upload($image, $size);
            }

            header('Content-type: application/json');
            echo json_encode(array(
                'success'		=> 1,
                'image'			=> $type == 'compress' ? image_url($image) : image_url($image,$image_url_width,$image_url_height),
                'filepath'      => ltrim($image, '/data')
            ));
            exit;
        }
    }

    public function upload_gd_prize()
    {
        $this->load->library('encrypt');
        $token = trim($this->input->get_post('token', TRUE));
        $token_decoded = $this->encrypt->decode($token);
        if ( ! $token_decoded) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => '请通过正常途径上传图片'));
            exit;
        }
        $token_data = unserialize($token_decoded);
        if ( ! isset($token_data['time']) OR ! isset($token_data['user_id']) OR (time() - $token_data['time']) > 3600) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => '页面停留时间过长，请刷新页面重新上传'));
            exit;
        }
        $upload_config = array(
            'upload_path'	=> FCPATH.'images/'.$token_data['user_id'].'/'.date('Ym').'/',
            'allowed_types'	=> 'gif|jpg|jpeg|png',
            'max_size'		=> 1024 * 2,
            'encrypt_name'	=> TRUE,
        );
        $this->load->library('upload', $upload_config);
        if(!is_dir($upload_config['upload_path'])){
            mkdir($upload_config['upload_path'], 0777, TRUE);
        }
        if ( ! $this->upload->do_upload('image')) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => $this->upload->display_errors('', '')));
            exit;
        } else {
            $size = array(array('width'=>64, 'height'=>64), array('width'=>320, 'height'=>320));
            $image = $this->rest_upload($this->upload->data(), $size);
            header('Content-type: application/json');
            echo json_encode(array(
                'success'		=> 1,
                'image'			=> image_url($image),
                'imagePreview'  => image_url($image,64,64),
            ));
            exit;
        }
    }

    public function upload_res() {
        $this->load->library('encrypt');
        $token = trim($this->input->get_post('token', TRUE));
        $token_decoded = $this->encrypt->decode($token);
        if ( ! $token_decoded) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => '请通过正常途径上传图片'));
            exit;
        }
        $token_data = unserialize($token_decoded);
        if ( ! isset($token_data['time']) OR ! isset($token_data['user_id']) OR (time() - $token_data['time']) > 3600) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => '页面停留时间过长，请刷新页面重新上传'));
            exit;
        }
        $upload_config = array(
            'upload_path'	=> FCPATH.'images/'.$token_data['user_id'].'/res/',
            'allowed_types'	=> 'gif|jpg|jpeg|png',
            'max_size'		=> 1024 * 2,
            'encrypt_name'	=> TRUE,
        );
        $this->load->library('upload', $upload_config);
        if(!is_dir($upload_config['upload_path'])){
            mkdir($upload_config['upload_path'], 0777, TRUE);
        }
        if ( ! $this->upload->do_upload('image')) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => $this->upload->display_errors('', '')));
            exit;
        } else {
            $image = $this->rest_upload($this->upload->data());
            header('Content-type: application/json');
            echo json_encode(array(
                'success'		=> 1,
                'image'			=> image_url($image)
            ));
            exit;
        }
    }

    public function image_resize_gd($image_path, $width, $height='',$maintain_ratio=true) {
        $this->load->library('image_lib');
        $config['image_library'] = 'gd2';
        $config['source_image'] = $image_path;
        $config['create_thumb'] = TRUE;

        $config['width'] = $width;
        if($maintain_ratio)
        {
            $config['maintain_ratio'] = TRUE;
        }
        else
        {
            $config['maintain_ratio'] = FALSE;
        }
        if($height != ''){
            $config['height'] = $height;
            $config['thumb_marker'] = '_'.$width.'_'.$height;
        }
        else
        {
            $config['thumb_marker'] = '_'.$width;
        }

        $this->load->library('image_lib', $config);

        return $this->image_lib->resize();
    }

    public function upload_assist()
    {
        $this->load->library('encrypt');
        $token = trim($this->input->get_post('token', TRUE));
        $token_decoded = $this->encrypt->decode($token);
        if ( ! $token_decoded) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => '请通过正常途径上传图片'));
            exit;
        }
        $token_data = unserialize($token_decoded);
        if ( ! isset($token_data['time']) OR ! isset($token_data['user_id']) OR (time() - $token_data['time']) > 3600) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => '页面停留时间过长，请刷新页面重新上传'));
            exit;
        }
        $upload_config = array(
            'upload_path'	=> FCPATH.'images/'.$token_data['user_id'].'/'.date('Ym').'/',
            'allowed_types'	=> 'gif|jpg|jpeg|png',
            'max_size'		=> 1024 * 2,
            'encrypt_name'	=> TRUE,
        );
        $this->load->library('upload', $upload_config);
        if(!is_dir($upload_config['upload_path'])){
            mkdir($upload_config['upload_path'], 0777, TRUE);
        }
        if ( ! $this->upload->do_upload('image')) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => $this->upload->display_errors('', '')));
            exit;
        } else {
            $size = array(array('width'=>64, 'height'=>64));
            $image = $this->rest_upload($this->upload->data(), $size);
            header('Content-type: application/json');
            echo json_encode(array(
                'success'		=> 1,
                'image'			=> image_url($image, 64, 64)
            ));
            exit;
        }
    }

    public function upload_effect()
    {
        $this->load->library('encrypt');
        $token = trim($this->input->get_post('token', TRUE));
        $token_decoded = $this->encrypt->decode($token);
        if ( ! $token_decoded) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => '请通过正常途径上传图片'));
            exit;
        }
        $token_data = unserialize($token_decoded);
        if ( ! isset($token_data['time']) OR ! isset($token_data['user_id']) OR (time() - $token_data['time']) > 3600) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => '页面停留时间过长，请刷新页面重新上传'));
            exit;
        }
        $upload_config = array(
            'upload_path'	=> FCPATH.'images/'.$token_data['user_id'].'/'.date('Ym').'/',
            'allowed_types'	=> 'gif|jpg|jpeg|png',
            'max_size'		=> 1024 * 2,
            'encrypt_name'	=> TRUE,
        );
        $this->load->library('upload', $upload_config);
        if(!is_dir($upload_config['upload_path'])){
            mkdir($upload_config['upload_path'], 0777, TRUE);
        }
        if ( ! $this->upload->do_upload('image')) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => $this->upload->display_errors('', '')));
            exit;
        } else {
            $image = $this->rest_upload($this->upload->data());
            header('Content-type: application/json');
            echo json_encode(array(
                'success'		=> 1,
                'image'			=> image_url($image),
            ));
            exit;
        }
    }

    /**
     * 会员卡导入-excel文件上传
     */
    public function upload_excel() {
        $this->load->library('encrypt');
        $token = trim($this->input->get_post('token', TRUE));
        $token_decoded = $this->encrypt->decode($token);
        if ( ! $token_decoded) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => '请通过正常途径上传文件'));
            exit;
        }
        $token_data = unserialize($token_decoded);
        if ( ! isset($token_data['time']) OR ! isset($token_data['user_id']) OR (time() - $token_data['time']) > 3600) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => '页面停留时间过长，请刷新页面重新上传'));
            exit;
        }
        $upload_config = array(
            'upload_path'	=> FCPATH.'images/'.$token_data['user_id'].'/'.date('Ym').'/',
            'allowed_types'	=> 'xls|xlsx',
            'max_size'		=> 1024 * 2,
            'encrypt_name'	=> TRUE,
        );
        $this->load->library('upload', $upload_config);
        if(!is_dir($upload_config['upload_path'])){
            mkdir($upload_config['upload_path'], 0777, TRUE);
        }
        if ( ! $this->upload->do_upload('image')) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => $this->upload->display_errors('', '')));
            exit;
        } else {
            //$image = $this->rest_upload($this->upload->data());
            $file_data = $this->upload->data();
            header('Content-type: application/json');
            echo json_encode(array(
                'success'		=> 1,
                'file_url'		=> $file_data['full_path'],
            ));
            exit;
        }
    }

    /**
     * @name 上传到图片服务器,并返回图片相对路径
     * @param $image
     * @param array $size example: array(array('width'=>80, 'height'=>80), array('width'=>640, 'height'=>320), array('width'=>640, 'height'=>640))
     * @return mixed
     */
    private function rest_upload($image, $size=array(), $compress=FALSE, $compress_size=array())
    {
        $this->load->library('rest', array(
            'server' => "http://".IMAGE_SERVER."/api",
            'app_key' => $this->app_key,
            'secret_key' => $this->app_secret,
        ));

        $data = array(
            'img' => '@'.$image['full_path']
        );
        $size && $data['size'] = json_encode($size);
        $compress && $data['compress'] = $compress;
        $compress && $data['compress_size'] = json_encode($compress_size);
        //var_dump($data);exit;
        $result = $this->rest->post('upload/img', $data);
        @unlink($image['full_path']);
        //$this->rest->debug();exit;
        //print_r($result);exit;
        if(isset($result['error'])) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => $result['error']));
            exit;
        } else {
            return $result['img'];
        }
    }
}