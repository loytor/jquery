<?php
/**
 * Created by JetBrains PhpStorm.
 * User: along
 * Date: 13-8-30
 * Time: 下午2:27
 * To change this template use File | Settings | File Templates.
 *
 * @property Model_tpl_css $tpl_css
 */
class Custom extends C_Controller
{
    private $site_id = '';
    private $mongo_custom_page = 'custom_page';
	public function __construct()
	{
		parent::__construct();
        $this->site_id = $this->site_info['id'];
        $this->load->library('Mongo_db');
	}


	public function index()
	{
		
		
	}

	public function home()
	{
        if( $this->input->post() ){
            $page = $this->_getOneCustomPage(1);

            $this->form_validation->set_rules('content', '内容', 'trim|required');
            if ( $this->form_validation->run() ){
                $content = $this->form_validation->set_value('content');
                $save_data['content'] = $this->shtmlspecialchars($content);

                if($page){
                    $save_data['update_time'] = time();
                    $ret = $this->mongo_db->where(array('site_id'=>$this->site_id,'type'=>1))->set($save_data)->update($this->mongo_custom_page);
                }else{
                    //$data['site_id'] = $this->site_info['id'];
                    $save_data['site_id'] = $this->site_id;
                    $save_data['type'] = 1;
					$save_data['content_pub'] = '';
                    $save_data['add_time'] = time();
                    $ret = $this->mongo_db->insert($this->mongo_custom_page, $save_data);

                    //$ret = $this->custom_page_model->add($save_data);
                }
                if($ret){
                    $this->show_message(true, '操作成功', '/custom/home');return FALSE;
                }else{
                    $this->show_message(false, '操作失败', '');return FALSE;
                }

            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            $user_id = $this->site_id;
            $tpl_data = array();
            $page = $this->_getOneCustomPage(1);
            $page['content'] = isset($page['content']) ? $page['content'] : '';

            $tpl_data['page'] = $page;
            $tpl_data['preview'] = $this->create_url('/custom/home');
            $this->load->library('encrypt');
            $token_data = array('user_id' => $user_id, 'time' => time());
            $tpl_data['token'] = $this->encrypt->encode(serialize($token_data));

            $this->twig->display('custom/home', $tpl_data);
        }
	}


    public function ajax_pub_home()
    {
        //读取自定义内容
        $content = $this->_getOneCustomPage(1,'content');
        //print_r($content['content']);exit;
        if($content && $content['content'])
        {
            $pub_content = $this->compress_html($content['content']);
            //保存
            $this->mongo_db->where(array('site_id'=>$this->site_id,'type'=>1))->set(array('content_pub'=>$pub_content))->update($this->mongo_custom_page);
            $this->ajax_return(array('ret'=>0,'msg'=>'自定义首页发布成功'));
        }
        else
        {
            $this->ajax_return(array('ret'=>101,'msg'=>'请先添加自定义首页模板内容'));
        }
    }

    public function qrcode()
    {
        $this->load->library('qrcode_make');
        $this->qrcode_make->make_direct($this->create_url('/custom/home'));
    }

    public function style()
    {
        $this->load->model('model_tpl_css', 'tpl_css');
        $where = array('wid'=>$this->site_id);

        $type = $this->input->get('type');

        $type = $type ? $type : 0;
        $where['type'] = $type;

        $tpl_data['diycss'] = $this->tpl_css->get_row($where);

        $tpl_data['type'] = $type;
        $this->twig->display('custom/style', $tpl_data);
    }

    public function ajax_save_style()
    {
        $diyCss = $this->input->post('diyCss');
        $type = $this->input->post('csstype');
        $type = $type ? $type : 0;

		$this->load->model('model_tpl_css', 'tpl_css');

        $this->tpl_css->css = $diyCss;
        $this->tpl_css->type = $type;
        $this->tpl_css->wid = $this->site_id;

        $where['wid'] = $this->site_id;
        $where['type'] = $type;

		
        if ($this->tpl_css->get_row($where)) {
            if ($this->tpl_css->update($where)) {
                $this->show_message(TRUE, '保存成功', '/custom/style/?type='.$type);
            }
            else {
                $this->show_message(false, '保存失败', '/custom/style/?type='.$type);
            }
        }
        else {
            if ($this->tpl_css->add()) {
                $this->show_message(TRUE, '保存成功', '/custom/style/?type='.$type);
            }
            else {
                $this->show_message(false, '保存失败', '/custom/style/?type='.$type);
            }
        }
    }


    private function shtmlspecialchars($string)
    {
        if (is_array($string)) {
            foreach ($string as $key => $val) {
                $string[$key] = $this->shtmlspecialchars($val);
            }
        } else {
            if(!empty($string))
            {
                $pattern='/\<\?(.|\r\n|\s)*\?\>/U';//过滤php代码
                $string = preg_replace($pattern, '', $string);

                $pattern='/\<\%(.|\r\n|\s)*\%\>/U';//过滤php代码
                $string = preg_replace($pattern, '', $string);
                $string = htmlspecialchars($string);
            }
        }
        return $string;
    }

    private function compress_html($string) {
        $string = str_replace("\r\n", '', $string); //清除换行符
        $string = str_replace("\n", '', $string); //清除换行符
        $string = str_replace("\t", '', $string); //清除制表符
        $pattern = array (
            "/> *([^ ]*) *</", //去掉注释标记
            "/[\s]+/",
            "/<!--[^!]*-->/",
            "/\" /",
            "/ \"/",
            "'/\*[^*]*\*/'"
        );
        $replace = array (
            ">\\1<",
            " ",
            "",
            "\"",
            "\"",
            ""
        );
        return preg_replace($pattern, $replace, $string);
    }


    /**
     *
     * @author Qianc
     * @date 2014-9-17
     * @description 获取一条自定义页面信息
     */
    protected function _getOneCustomPage($type, $field = "")
    {
        $where['site_id'] = $this->site_id;
        $where['type'] = $type;
        if($field){
            $page = $this->mongo_db->select(array($field))->where($where)->get_one($this->mongo_custom_page);
        }else{
            $page = $this->mongo_db->where($where)->get_one($this->mongo_custom_page);
        }
        return $page;
    }

}