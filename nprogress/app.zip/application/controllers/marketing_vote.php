<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Class Marketing_vote
 * @property Model_marketing_vote $model_marketing_vote
 * @property Model_marketing $model_marketing
 * @property Model_cate $model_cate
 * @property Model_cate_lists $model_cate_lists
 * @property Model_marketing_vote_info $model_marketing_vote_info
 * @property Model_marketing_latest_reply $model_marketing_latest_reply
 * @property Model_welcome $model_welcome
 */
class Marketing_vote extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('model_marketing_vote');
		$this->load->model('model_marketing');
	}

	public function index(){
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}

		$where_set = array('user_id' => $logged_user_id, 'type'=>'vote_text');
		$this->load->library('pagination');
		$pagination_config = array(
			'base_url'		=> '/marketing_vote/index/',
			'total_rows'	=> $this->model_marketing->total_rows($where_set),
			'per_page'		=> 8,
			'uri_segment'	=> 3,
		);
		$this->pagination->initialize($pagination_config);
		$tpl_data['pagination'] = $this->pagination->create_links();

		$vote_arr = $this->model_marketing->get_all($where_set, $pagination_config['per_page'], intval($this->uri->segment($pagination_config['uri_segment'], 1)), 'dt_update', 'desc');
		$tpl_data['vote_arr'] = $vote_arr;

		$this->twig->display('marketing_vote/index', $tpl_data);
	}
	
	public function add() {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		
		$this->load->library('form_validation');

		$vos = serialize($this->input->post('vote_setting'));

		$this->form_validation->set_rules('instruction', '投票活动说明', 'trim|required|max_length[200]|htmlspecialchars');
		$this->form_validation->set_rules('rule', '投票规则设置天数', 'trim|required|is_natural_no_zero');
        $this->form_validation->set_rules('rule_jnum', '投票规则设置次数', 'trim|required|is_natural_no_zero');
		$this->form_validation->set_rules('dt_start', '投票活动开始时间', 'trim|required|htmlspecialchars');
		$this->form_validation->set_rules('dt_end', '投票活动结束时间', 'trim|required|htmlspecialchars');
		$this->form_validation->set_rules('vote_setting', '投票项目', "callback_vote_setting_check[".$vos."]");
		
		if ($this->form_validation->run()) {
			$data_set['user_id'] = $logged_user_id;
			$data_set['dt_start'] = $this->form_validation->set_value('dt_start');
			$data_set['dt_end'] = $this->form_validation->set_value('dt_end');
			
			//判断时间
			if(strtotime($data_set['dt_start']) > time()){
				$data_set['status'] = '未开始';
			}elseif(strtotime($data_set['dt_end']) < time()){
				$data_set['status'] = '已结束';
			}else{
				$data_set['status'] = '已开始';
			}
			$data_set['type'] = 'vote_text';
			
			$add_data_set['marketing_id'] = $this->model_marketing->add($data_set);

			//基础表添加成功 处理附加表
			if($add_data_set['marketing_id']){
				$add_data_set['rule'] = $this->form_validation->set_value('rule');
				
				//设置投票项目
				$vote_setting = $this->input->post('vote_setting');
				$add_data_set['vote_setting'] = serialize($vote_setting);
				
				//单选/多选
				$choice = $this->input->post('choice');
                //单选
                if($choice['type'] == 0) {
                    $add_data_set['rule_jnum'] = $this->form_validation->set_value('rule_jnum');
                } else {
                    $add_data_set['rule_jnum'] = 1;
                }
				$add_data_set['choice'] = serialize($choice);
				
				//投票结果
				$display = $this->input->post('display');
				$add_data_set['display'] = $display ? $display : 0;
				
				$add_data_set['type'] = 'text'; //文字版投票
				
				$add_data_set['instruction'] = $this->form_validation->set_value('instruction');
			
				//附加表添加成功，自动生成投票信息
				if($this->model_marketing_vote->add($add_data_set)){
					//加一个默认的自定义回复
                    $reply_data = array();
                    $reply_data['keyword'][] = '投票';
                    $reply_data['type'] = 'text_vote';
                    $reply_data['site_id'] = $logged_user_id;
                    $reply_data['count_match'] = 0;
                    $reply_data['dt_add'] = $reply_data['dt_update'] = time();
                    $reply_data['content'] = $add_data_set['marketing_id'];
                    $this->load->library('Mongo_db');
                    $this->mongo_db->insert('reply', $reply_data);

					$this->show_message(TRUE, '活动添加成功', '/marketing_vote');
				}
			}
		}else{
			$errors = validation_errors();

			if ($errors) {
				$this->show_message(FALSE, $errors, '/marketing_vote/add');
			}		
		}
		$this->load->library('encrypt');
		$token_data = array('user_id' => $logged_user_id, 'time' => time());
		$tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
		$tpl_data['cur_nav'] = 'marketing';
		$this->twig->display('marketing_vote/add', $tpl_data);
	}
	
	public function update($marketing_id='') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$marketing = $this->model_marketing->get_marketing($marketing_id,'vote');

		if ( ! $marketing || $marketing['user_id'] != $logged_user_id) {
			$this->show_message(FALSE, '找不到该活动', '/marketing_vote');
		}

		$marketing['choice'] = unserialize($marketing['choice']);
		$marketing['vote_setting'] = unserialize($marketing['vote_setting']);

		$tpl_data['marketing'] = $marketing;

		$this->load->library('form_validation');

		//进行判断投票选项设置,已添加的无法再修改
		$vote_setting = $this->input->post('vote_setting');	
		$added_vote_setting = $marketing['vote_setting'];
		foreach($added_vote_setting as $key=>$avs){
			$vote_setting[$key]['choice'] = $avs['choice'];
		}		
		$vos = serialize($vote_setting);

		$this->form_validation->set_rules('instruction', '投票活动说明', 'trim|required|max_length[200]|htmlspecialchars');
        $this->form_validation->set_rules('rule', '投票规则设置天数', 'trim|required|is_natural_no_zero');
        $this->form_validation->set_rules('rule_jnum', '投票规则设置次数', 'trim|required|is_natural_no_zero');
		$this->form_validation->set_rules('dt_start', '投票活动开始时间', 'trim|required|htmlspecialchars');
		$this->form_validation->set_rules('dt_end', '投票活动结束时间', 'trim|required|htmlspecialchars');
		$this->form_validation->set_rules('vote_setting', '投票项目', "callback_vote_setting_check[".$vos."]");
		
		if ($this->form_validation->run()) {
			$data_set['user_id'] = $logged_user_id;
			$data_set['dt_start'] = $this->form_validation->set_value('dt_start');
			$data_set['dt_end'] = $this->form_validation->set_value('dt_end');
				
			//判断时间
			if(strtotime($data_set['dt_start']) > time()){
				$data_set['status'] = '未开始';
			}elseif(strtotime($data_set['dt_end']) < time()){
				$data_set['status'] = '已结束';
			}else{
				$data_set['status'] = '已开始';
			}
			$data_set['type'] = 'vote_text';
		
			if($this->model_marketing->update($marketing_id, $data_set)){
				$update_data_set['rule'] = $this->form_validation->set_value('rule');
				
				//设置投票项目
				$update_data_set['vote_setting'] = serialize($vote_setting);
				
				//单选/多选
				$choice = $this->input->post('choice');
                //单选
                if($choice['type'] == 0) {
                    $update_data_set['rule_jnum'] = $this->form_validation->set_value('rule_jnum');
                } else {
                    $update_data_set['rule_jnum'] = 1;
                }
				$update_data_set['choice'] = serialize($choice);
				
				//投票结果
				$display = $this->input->post('display');
				$update_data_set['display'] = $display ? $display : 0;
				
				$update_data_set['type'] = 'text'; //文字版投票
				
				$update_data_set['instruction'] = $this->form_validation->set_value('instruction');
		
				$this->model_marketing_vote->update(array('marketing_id'=>$marketing_id),$update_data_set);
		
				$this->show_message(TRUE, '更新成功', '/marketing_vote');
			}
		} else {
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/marketing_vote/update/'.$marketing_id);
			}
		}
		$this->load->library('encrypt');
		$token_data = array('user_id' => $logged_user_id, 'time' => time());
		$tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
		$tpl_data['cur_nav'] = 'marketing';
		$this->twig->display('marketing_vote/update', $tpl_data);
	}
	
	public function vote_setting_check($str, $vote_setting) {
		$vote_setting = unserialize($vote_setting);
		if(count($vote_setting) < 2) {
			$this->form_validation->set_message('vote_setting_check', '%s至少需要2项');
			return FALSE;
		}else{
			$error = array();
			foreach($vote_setting as $vs) {
				if($vs['choice'] == '' && !isset($error['choice'])){
					$error['choice'] = '回复选项';
				}
				if($vs['content'] == '' && !isset($error['content'])){
					$error['content'] = '投票内容';;
				}
			}
			if($error){
				$s = '';
				if(isset($error['choice']) && isset($error['content'])){
					$s = $error['choice'].', '.$error['content'];
				}else if(isset($error['choice'])){
					$s = $error['choice'];
				}else if(isset($error['content'])){
					$s = $error['content'];
				}
				if($s)
				{
					$this->form_validation->set_message('vote_setting_check', $s.'不能为空');
					return FALSE;
				}
			}
		}
		return true;
	}

	public function stop($marketing_id='') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}

		$data_set['status'] = '已结束';
		$data_set['dt_end'] = date('Y-m-d H:i:s');
		$marketing = $this->model_marketing->get_row(array('id' => $marketing_id, 'user_id' => $logged_user_id));
		if($marketing){
			if($this->model_marketing->update($marketing_id, $data_set)){
				$this->show_message(TRUE, '终止成功', '/marketing_vote');
			}else{
				$this->show_message(FALSE, '终止失败', '/marketing_vote');
			}
		}else{
			$this->show_message(TRUE, '不存在该投票', '/marketing_vote');
		}
	}

	public function delete($marketing_id='') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}

		//判断是否是自己发布的
		$marketing = $this->model_marketing->get_row(array('id' => $marketing_id, 'user_id' => $logged_user_id));
		if($marketing){
			if($this->model_marketing->delete($marketing_id)){
				//cate表count_marketing -1, cate_lists表删除
				$this->load->model('model_cate');
				$this->load->model('model_cate_lists');
				if ($marketing['cate_id']) {
					$this->model_cate->count_step($marketing['cate_id'], 'count_marketing', -1);
					$del_data_cate_lists['user_id'] = $logged_user_id;
					$del_data_cate_lists['cate_id'] = $marketing['cate_id'];
					$del_data_cate_lists['type'] = str_replace('marketing_', '', $marketing['type']);
					$del_data_cate_lists['lists_id'] = $marketing_id;
					$this->model_cate_lists->delete($del_data_cate_lists);
				}

				$this->load->model('model_marketing_vote_info');
				$this->load->model('model_marketing_latest_reply');

				$this->model_marketing_vote->delete(array('marketing_id' => $marketing_id));
				$this->model_marketing_vote_info->delete(array('marketing_id' => $marketing_id));
				$this->model_marketing_latest_reply->delete(array('marketing_id' => $marketing_id));

				/*//删除对应的自定义回复
				$this->load->model('model_reply');
				$reply_list = $this->model_reply->reply_list_by_marketing($marketing_id);
				foreach($reply_list as $reply){
					$marketing_arr = json_decode($reply['content']);
					foreach($marketing_arr as $key=>$marketing){
						if($marketing->id == $marketing_id){
							unset($marketing_arr[$key]);
						}
					}
					$content = json_encode($marketing_arr);
					if(count($marketing_arr) > 0){
						$this->model_reply->update($reply['id'], array('content'=>$content));
					}else{
						$this->model_reply->delete($reply['id']);
					}
					$this->model_reply->marketing_delete($reply['id'], $marketing_id);
				}
				//删除对应的welcome
				$this->load->model('model_welcome');
				$welcome = $this->model_welcome->get_row(array('user_id' => $logged_user_id));
				if($welcome){
					$content = json_decode($welcome['content']);
					if($content){
						foreach($content as $k=>$c){
							if(isset($c->marketing_id) && $c->marketing_id == $marketing_id){
								unset($content[$k]);
							}
						}
					}
					$content = json_encode($content);
					$this->model_welcome->update($welcome['id'], array('content'=>$content));
				}*/
				$this->show_message(TRUE, '删除成功', '/marketing_vote');
			}else{
				$this->show_message(FALSE, '删除失败', '/marketing_vote');
			}
		}else{
			$this->show_message(FALSE, '非法操作', '/marketing_vote');
		}
	}

	private function show_message($success, $message, $redirect) {
		if ($this->input->is_ajax_request()) {
			$data = array(
					'success'	=> $success ? 1 : 0,
					'message'	=> strip_tags($message),
			);
			header('Content-type: application/json');
			echo json_encode($data);
		} else {
			$tpl_data = array(
					'message'	=> $message,
					'redirect'	=> $redirect,
			);
			$this->twig->display('show_message', $tpl_data);
		}
		exit;
	}
}