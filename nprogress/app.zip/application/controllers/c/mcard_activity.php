<?php

/**
 * 特权活动
 * Enter description here ...
 * @author Administrator
 *
 */
class Mcard_activity extends C_Controller {
    
    
    private $wid = '';
    
    public function __construct()
    {
        parent::__construct();
        
        $this->wid = $this->site_info['id'];
        
        $this->load->model('mcard_activity_model');
        
        $this->mcard_activity_model->where(array('site_id'=>$this->wid,'time_range'=>1,'end_time <'=>time()))->edit(array('status'=>1));
        
    }
    
    
    //特权活动
    public function index()
    {
        if( !$this->check_mcard() ){
            return false;
        }
        
        $where = array(
            'site_id' => $this->wid
        );
        $total_rows = $this->mcard_activity_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15));
        $list = $this->mcard_activity_model
                ->limit($pager['limit']['value'], $pager['limit']['offset'])
                ->where($where)->find_all();
        
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        
        $this->load->view($this->dcm, $this->data);
    }
    
    //添加特权活动
    public function add()
    {
        if( !$this->check_mcard() ){
            return false;
        }
        
        $this->load->library('Mongo_db');
        $credit_setting = $this->mongo_db->where(array('site_id'=>$this->wid))->get_one('credit');
        $credit_on = 0;
        if($credit_setting && !$credit_setting['on']) {
            $credit_on = 0;
        }else{
            $credit_on = 1;
        }
        $this->data['credit_on'] = $credit_on;
        
        if( $this->input->post() ){
            $type = intval($this->input->post('type'));
            $name = trim($this->input->post('name'));
            if( !$type ){
                return $this->show_message(FALSE, '请选择活动类型', '',1);
            }
            if( !$name ){
                return $this->show_message(FALSE, '请填写活动名称', '',1);
            }
            if( strlen($name)>50 ){
                return $this->show_message(FALSE, '活动名称最多50个字', '',1);
            }
            
            switch ($type){
                case 1: 
                    if( $credit_on==0 ){
                        return $this->show_message(FALSE, '积分功能已关闭，不能添加该类型的活动', '',1);
                    }
                    
                    $res = $this->check_has_activity($type);
                    if( $res ){
                        return $this->show_message(FALSE, '该时间段已存在该类型的活动', '/c/mcard_activity/index');
                    }
                    $score_num = intval($this->input->post('score_num'));
                    if( !$score_num ){
                        if( !preg_match('/^[1-9]+[0-9]{0,}$/', $score_num) ){
                            return $this->show_message(FALSE, '请填写合适的数字', '',1);
                        }
                        return $this->show_message(FALSE, '请填写赠送积分量', '',1);
                    }
                    if( $score_num<1 ){
                        return $this->show_message(FALSE, '请填写合适的赠送积分量', '',1);
                    }
                    $save_data['score_num'] = $score_num;
                    
                    $time_range = $this->input->post('time_range');
                    $save_data['time_range'] = $time_range;
                    if( $time_range==1 ){
                        $start_time = trim($this->input->post('start_time'));
                        if( !$start_time ){
                            $this->show_message(false, '请填写开始时间', '',1);return FALSE;
                        }
                        $end_time = trim($this->input->post('end_time'));
                        if( !$end_time ){
                            $this->show_message(false, '请填写结束时间', '',1);return FALSE;
                        }
                        $start_time = strtotime($start_time);
                        $end_time = strtotime($end_time);
                        if( $end_time<=$start_time ){
                            $this->show_message(false, '结束时间必须大于开始时间', '',1);return FALSE;
                        }
                        $save_data['start_time'] = $start_time;
                        $save_data['end_time'] = $end_time;
                    }
                    
                    $intro = htmlspecialchars(trim($this->input->post('intro')));
                    $save_data['intro'] = $intro;
                    
                    break;
                case 2:
                    if( $credit_on==0 ){
                        return $this->show_message(FALSE, '积分功能已关闭，不能添加该类型的活动', '',1);
                    }
                    
                    $res = $this->check_has_activity($type);
                    if( $res ){
                        return $this->show_message(FALSE, '该时间段已存在该类型的活动', '/c/mcard_activity/index');
                    }
                    $score_num = intval($this->input->post('score_num'));
                    if( !$score_num ){
                        if( !preg_match('/^[1-9]+[0-9]{0,}$/', $score_num) ){
                            return $this->show_message(FALSE, '请填写合适的数字', '',1);
                        }
                        return $this->show_message(FALSE, '请填写赠送积分量', '',1);
                    }
                    if( $score_num<1 ){
                        return $this->show_message(FALSE, '请填写合适的赠送积分量', '',1);
                    }
                    $save_data['score_num'] = $score_num;
                    
                    //完善信息部分
                    $required_name = intval($this->input->post('required_name'));
                    $save_data['required_name'] = $required_name;
                    $required_mobile = intval($this->input->post('required_mobile'));
                    $save_data['required_mobile'] = $required_mobile;
                    $required_fields = $this->input->post('required_fields') ? $this->input->post('required_fields') : array();
                    $save_data['required_fields'] = implode(',', $required_fields);
                    if( !$required_name&&!$required_mobile&&!$save_data['required_fields'] ){
                        $this->show_message(false, '请选择需完善信息项', '',1);return FALSE;
                    }
                    
                    $time_range = $this->input->post('time_range');
                    $save_data['time_range'] = $time_range;
                    if( $time_range==1 ){
                        $start_time = trim($this->input->post('start_time'));
                        if( !$start_time ){
                            $this->show_message(false, '请填写开始时间', '',1);return FALSE;
                        }
                        $end_time = trim($this->input->post('end_time'));
                        if( !$end_time ){
                            $this->show_message(false, '请填写结束时间', '',1);return FALSE;
                        }
                        $start_time = strtotime($start_time);
                        $end_time = strtotime($end_time);
                        if( $end_time<=$start_time ){
                            $this->show_message(false, '结束时间必须大于开始时间', '',1);return FALSE;
                        }
                        $save_data['start_time'] = $start_time;
                        $save_data['end_time'] = $end_time;
                    }
                    
                    //显示方式
                    $show_type = intval($this->input->post('show_type'));
                    $save_data['show_type'] = $show_type;
                    if( $show_type==2 ){
                        $url = trim($this->input->post('url'));
                        if( !$url ){
                            $this->show_message(false, '请填写链接地址', '',1);return FALSE;
                        }
                        $save_data['url'] = $url;
                    }
                    
                    //$intro = htmlspecialchars(trim($this->input->post('intro')));
                    //$save_data['intro'] = $intro;
                    
                    break;
                case 3: 
                    
                    $time_range = $this->input->post('time_range');
                    $save_data['time_range'] = $time_range;
                    if( $time_range==1 ){
                        $start_time = trim($this->input->post('start_time'));
                        if( !$start_time ){
                            $this->show_message(false, '请填写开始时间', '',1);return FALSE;
                        }
                        $end_time = trim($this->input->post('end_time'));
                        if( !$end_time ){
                            $this->show_message(false, '请填写结束时间', '',1);return FALSE;
                        }
                        $start_time = strtotime($start_time);
                        $end_time = strtotime($end_time);
                        if( $end_time<=$start_time ){
                            $this->show_message(false, '结束时间必须大于开始时间', '',1);return FALSE;
                        }
                        $save_data['start_time'] = $start_time;
                        $save_data['end_time'] = $end_time;
                    }
                    
                    //显示方式
                    $show_type = intval($this->input->post('show_type'));
                    $save_data['show_type'] = $show_type;
                    if( $show_type==2 ){
                        $url = trim($this->input->post('url'));
                        if( !$url ){
                            $this->show_message(false, '请填写链接地址', '',1);return FALSE;
                        }
                        $save_data['url'] = $url;
                    }
                    
                    $intro = htmlspecialchars(trim($this->input->post('intro')));
                    $save_data['intro'] = $intro;
                    
                    break;
                default:
                    return $this->show_message(FALSE, '非法提交', '/c/mcard_activity/index');
            }
            
            $save_data['site_id']   = $this->wid;
            $save_data['type']      = $type;
            $save_data['name']      = $name;
            $save_data['status']    = 0;
            $save_data['add_time']  = time();
            
            if( $activity_id=$this->mcard_activity_model->add($save_data) ){
                $this->show_message(true, '添加成功', '/c/mcard_activity/index');return FALSE;
            }else{
                $this->show_message(false, '添加失败', '',1);return FALSE;
            }
            
        }else{
            //需完善信息项
            $this->load->library('Mongo_db');
            $field_list = $this->mongo_db->where(array('wid'=>$this->site_info['id']))->order_by(array('sort', 'ASC'))->get('account_fields');
            $this->data['field_list'] = $field_list;
            
            $this->load->view($this->dcm, $this->data);
        }
    }
    
    //修改活动
    public function update($activity_id='')
    {
        if( !$this->check_mcard() ){
            return false;
        }
        
        $where = array(
            'site_id' => $this->wid,
            'id' => $activity_id
        );
        $activity = $this->mcard_activity_model->where($where)->find();
        if( !$activity ){
            $this->show_message(false, '非法操作', '/c/mcard_activity/index');return FALSE;
        }
        $activity['required_fields'] = explode(',', $activity['required_fields']);
        $this->data['activity'] = $activity;
        
        if( $this->input->post() ){
            $type = intval($this->input->post('type'));
            $name = trim($this->input->post('name'));
            if( !$name ){
                return $this->show_message(FALSE, '请填写活动名称', '',1);
            }
            if( strlen($name)>50 ){
                return $this->show_message(FALSE, '活动名称最多50个字', '',1);
            }
            
            switch ($type){
                case 1: 
                    
                    $res = $this->check_has_activity($type,$activity_id);
                    if( $res ){
                        return $this->show_message(FALSE, '该时间段已存在该类型的活动', '/c/mcard_activity/index');
                    }
                    $score_num = trim($this->input->post('score_num'));
                    if( !$score_num ){
                        if( !preg_match('/^[1-9]+[0-9]{0,}$/', $score_num) ){
                            return $this->show_message(FALSE, '请填写合适的数字', '',1);
                        }
                        return $this->show_message(FALSE, '请填写赠送积分量', '',1);
                    }
                    if( $score_num<1 ){
                        return $this->show_message(FALSE, '请填写合适的赠送积分量', '',1);
                    }
                    $save_data['score_num'] = $score_num;
                    
                    $time_range = $this->input->post('time_range');
                    $save_data['time_range'] = $time_range;
                    if( $time_range==1 ){
                        $start_time = trim($this->input->post('start_time'));
                        if( !$start_time ){
                            $this->show_message(false, '请填写开始时间', '',1);return FALSE;
                        }
                        $end_time = trim($this->input->post('end_time'));
                        if( !$end_time ){
                            $this->show_message(false, '请填写结束时间', '',1);return FALSE;
                        }
                        $start_time = strtotime($start_time);
                        $end_time = strtotime($end_time);
                        if( $end_time<=$start_time ){
                            $this->show_message(false, '结束时间必须大于开始时间', '',1);return FALSE;
                        }
                        $save_data['start_time'] = $start_time;
                        $save_data['end_time'] = $end_time;
                    }
                    
                    $intro = htmlspecialchars(trim($this->input->post('intro')));
                    $save_data['intro'] = $intro;
                    
                    break;
                case 2:

                    $res = $this->check_has_activity($type,$activity_id);
                    if( $res ){
                        return $this->show_message(FALSE, '该时间段已存在该类型的活动', '/c/mcard_activity/index');
                    }
                    $score_num = intval($this->input->post('score_num'));
                    if( !$score_num ){
                        if( !preg_match('/^[1-9]+[0-9]{0,}$/', $score_num) ){
                            return $this->show_message(FALSE, '请填写合适的数字', '',1);
                        }
                        return $this->show_message(FALSE, '请填写赠送积分量', '',1);
                    }
                    if( $score_num<1 ){
                        return $this->show_message(FALSE, '请填写合适的赠送积分量', '',1);
                    }
                    $save_data['score_num'] = $score_num;
                    
                    //完善信息部分
                    $required_name = intval($this->input->post('required_name'));
                    $save_data['required_name'] = $required_name;
                    $required_mobile = intval($this->input->post('required_mobile'));
                    $save_data['required_mobile'] = $required_mobile;
                    $required_fields = $this->input->post('required_fields') ? $this->input->post('required_fields') : array();
                    $save_data['required_fields'] = implode(',', $required_fields);
                    if( !$required_name&&!$required_mobile&&!$save_data['required_fields'] ){
                        $this->show_message(false, '请选择需完善信息项', '',1);return FALSE;
                    }
                    
                    $time_range = $this->input->post('time_range');
                    $save_data['time_range'] = $time_range;
                    if( $time_range==1 ){
                        $start_time = trim($this->input->post('start_time'));
                        if( !$start_time ){
                            $this->show_message(false, '请填写开始时间', '',1);return FALSE;
                        }
                        $end_time = trim($this->input->post('end_time'));
                        if( !$end_time ){
                            $this->show_message(false, '请填写结束时间', '',1);return FALSE;
                        }
                        $start_time = strtotime($start_time);
                        $end_time = strtotime($end_time);
                        if( $end_time<=$start_time ){
                            $this->show_message(false, '结束时间必须大于开始时间', '',1);return FALSE;
                        }
                        $save_data['start_time'] = $start_time;
                        $save_data['end_time'] = $end_time;
                    }
                    
                    //显示方式
                    $show_type = intval($this->input->post('show_type'));
                    $save_data['show_type'] = $show_type;
                    if( $show_type==2 ){
                        $url = trim($this->input->post('url'));
                        if( !$url ){
                            $this->show_message(false, '请填写链接地址', '',1);return FALSE;
                        }
                        $save_data['url'] = $url;
                    }
                    
                    //$intro = htmlspecialchars(trim($this->input->post('intro')));
                    //$save_data['intro'] = $intro;
                    
                    break;
                case 3: 
                    
                    $time_range = $this->input->post('time_range');
                    $save_data['time_range'] = $time_range;
                    if( $time_range==1 ){
                        $start_time = trim($this->input->post('start_time'));
                        if( !$start_time ){
                            $this->show_message(false, '请填写开始时间', '',1);return FALSE;
                        }
                        $end_time = trim($this->input->post('end_time'));
                        if( !$end_time ){
                            $this->show_message(false, '请填写结束时间', '',1);return FALSE;
                        }
                        $start_time = strtotime($start_time);
                        $end_time = strtotime($end_time);
                        if( $end_time<=$start_time ){
                            $this->show_message(false, '结束时间必须大于开始时间', '',1);return FALSE;
                        }
                        $save_data['start_time'] = $start_time;
                        $save_data['end_time'] = $end_time;
                    }
                    
                    //显示方式
                    $show_type = intval($this->input->post('show_type'));
                    $save_data['show_type'] = $show_type;
                    if( $show_type==2 ){
                        $url = trim($this->input->post('url'));
                        if( !$url ){
                            $this->show_message(false, '请填写链接地址', '',1);return FALSE;
                        }
                        $save_data['url'] = $url;
                    }else{
                        $intro = htmlspecialchars(trim($this->input->post('intro')));
                        $save_data['intro'] = $intro;
                    }
                    
                    break;
                default:
                    return $this->show_message(FALSE, '非法提交', '/c/mcard_activity/index');
            }
            
            $save_data['site_id']   = $this->wid;
            $save_data['type']      = $type;
            $save_data['name']      = $name;
            $save_data['status']    = 0;
            $save_data['add_time']  = time();
            
            if( $this->mcard_activity_model->where($where)->edit($save_data) ){
                $this->show_message(true, '修改成功', '/c/mcard_activity/index');return FALSE;
            }else{
                $this->show_message(false, '修改失败', '',1);return FALSE;
            }
            
        }else{
            //需完善信息项
            $this->load->library('Mongo_db');
            $field_list = $this->mongo_db->where(array('wid'=>$this->site_info['id']))->order_by(array('sort', 'ASC'))->get('account_fields');
            $this->data['field_list'] = $field_list;
            
            $this->load->view($this->dcm, $this->data);
        }
        
    }
    
    
    //删除活动
    public function delete($activity_id='')
    {
        if( !$this->check_mcard() ){
            return false;
        }
        
        $where = array(
            'site_id' => $this->wid,
            'id' => $activity_id
        );
        $activity = $this->mcard_activity_model->where($where)->find();
        if( !$activity ){
            $this->show_message(false, '非法操作', '/c/mcard_activity/index');return FALSE;
        }
        
        if( $this->mcard_activity_model->where($where)->delete() ){
            $this->show_message(true, '删除成功', '/c/mcard_activity/index');return FALSE;
        }
        $this->show_message(false, '非法操作', '/c/mcard_activity/index');return FALSE;
    }
    
    public function check_has_activity($type,$id='')
    {
        $where = array(
            'site_id' => $this->wid,
            'type' => $type
        );
        if( $id ){
            $where['id <>'] = $id;
        }
        
        $activity = $this->mcard_activity_model->where($where)->find_all();
        foreach( $activity as $val ){
            if( $val['time_range']==0 ){
                return 1;exit;
            }
            if( time()<$val['end_time'] ){
                return 1;exit;
            }
        }
        return 0;
    }
    
    //检查会员卡是否存在
    public function check_mcard()
    {
        $this->load->model('mcard_model');
        $mcard = $this->mcard_model->where(array('site_id'=>$this->site_info['id']))->find();
        if(!$mcard) {
            return $this->show_message(FALSE, '会员卡不存在，请先去设置', '/c/mcard/index');
        }
        return true;
    }
    
    
}