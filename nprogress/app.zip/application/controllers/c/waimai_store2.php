<?php
/**
 * Created by PhpStorm.
 * User: along
 * Date: 13-12-9
 * Time: 下午3:10
 * 外卖门店
 * @property Waimai_model $model
 * @property Dishes_model $dishes_model
 * @property Waimai_dishes_model $waimai_dishes_model
 * @property Waimai_store_tag_model $waimai_store_tag_model
 * @property Waimai_dishes_tag_model $waimai_dishes_tag_model
 * @property Waimai_order_model $waimai_order_model
 * @property Waimai_order_dishes_model $waimai_order_dishes_model
 * @property Waimai_address_model $waimai_address_model
 * @property Waimai_order_statistics_model $waimai_order_statistics_model
 */

class Waimai_store2 extends C_Controller {

    protected $auto_load_model = TRUE;
    protected $model_name = 'waimai_store';
    
    protected $data = '';
    
    private $site_id = '';

    private $order_status_list = array(
        '-1' => '已关闭',
        '0' => '未付款',
        '1' => '已付款',
        '2' => '配送中',
        '3' => '货到付款',
        '4' => '交易成功'
    );

    public function __construct()
    {
        parent::__construct();

        $this->site_id = $this->site_info['id'];
        
        $this->load->model('waimai_model');
        $this->load->model('waimai_dishes_model');
        $this->load->model('waimai_dishes_tag_model');
        $this->load->model('waimai_store_tag_model');
        $this->load->model('waimai_order_model');
    }
    
    public function index()
    {
        $like = array();$is_search = 0;
        $search['sear_name'] = $this->input->get('sear_name');
        $search['sear_add'] = $this->input->get('sear_add');
        $search['sear_tel'] = $this->input->get('sear_tel');
        
        $this->data['search'] = $search;
        $search_url = site_url($this->uri->uri_string().'?');
        if( $search ){
            foreach( $search as $key=>$val ){
                if( $val ){
                    $search_url .= '&'.$key.'='.$val;
                    switch ($key){
                        case 'sear_name':
                            $like['address.name'] = $search['sear_name'];
                            break;
                        case 'sear_add':
                            $like['waimai_store.address'] = $search['sear_add'];
                            break;
                        case 'sear_tel':
                            $like['waimai_store.tele'] = $search['sear_tel'];
                            break;
                        default: break;
                    }
                }
            }
            $is_search = 1;
        }
        
        $this->data['is_search'] = $is_search;
        
        $where = array(
            'waimai_store.site_id' => $this->site_id,
            'waimai_store.status' => 0
        );
        
        $total_rows = $this->model->join('address','address.id=waimai_store.address_id')->where($where)->like($like)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$search_url));
        $list = $this->model
                ->select('waimai_store.id,waimai_store.tele,waimai_store.address as old_address,address.name as add_name,address.address as address')
                ->join('address','address.id=waimai_store.address_id')
                ->limit($pager['limit']['value'], $pager['limit']['offset'])
                ->where($where)->like($like)->find_all();
        
        
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];


        $this->load->view($this->dcm, $this->data);
    }
    
    //添加门店
    public function add_store()
    {
        //所有门店
        $res = $this->address();
        if( !$res ){
            $this->show_message(false, '请先添加地址', '/address/add');return FALSE;
        }
        
        //已添加的门店
        $waimai_add = $this->model->select('id,address_id')->where(array('site_id'=>$this->site_id,'status'=>0))->find_all();
        $has_store = array();
        if( $waimai_add ){
            foreach( $waimai_add as $val ){
                $has_store[$val['address_id']] = $val['address_id'];
            }
        }
        
        $address_list = array();
        foreach( $this->data['address_list'] as $val ){
            if( !isset($has_store[$val['id']]) ){
                $address_list[] = $val;
            }
        }
        
        if( !$address_list ){
            $this->show_message(false, '您所拥有的门店已全部添加到了外卖门店里', '/c/waimai_store2/');return FALSE;
        }
        $this->data['address_list'] = $address_list;

        //检查是否开通微助手
        if( $this->check_assistant($this->site_id) ){
            $this->data['assistant'] = 1;
        }else{
            $this->data['assistant'] = 0;
        }
        
        if( $this->input->post() ){
            $this->form_validation->set_rules('address_id', '选择门店', 'trim|required');
            $this->form_validation->set_rules('tele', '外卖电话', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('rule', '配送费设置', 'trim|numeric|greater_than[0]');
            $this->form_validation->set_rules('r2s', '配送费收费多少钱', 'trim|numeric|greater_than_equal_to[0]');
            $this->form_validation->set_rules('r2e', '配送费满后免费', 'trim|numeric|greater_than_equal_to[0]');
            $this->form_validation->set_rules('qisong', '起送条件', 'trim|required|numeric|greater_than_equal_to[0]');
            $this->form_validation->set_rules('step_time', '送餐预留时间', 'trim|required|numeric|greater_than_equal_to[900]');
            $this->form_validation->set_rules('ship_type', '订购支持', 'trim|required|numeric|greater_than_equal_to[1]');
            $this->form_validation->set_rules('ship_time', '提前订购天数', 'trim|numeric|greater_than_equal_to[1]');
            $this->form_validation->set_rules('range', '配送范围', 'trim|numeric');
            $this->form_validation->set_rules('sales_volume', '菜品显示销量', 'trim|intval');
            $this->form_validation->set_rules('printer_num', '小票打印机设置', 'trim|required|numeric|greater_than_equal_to[1]|intval');
            $this->form_validation->set_rules('assistant', '微助手提醒', 'trim|intval');
            $this->form_validation->set_rules('email', '订单微信提醒', 'trim|valid_email');
            $this->form_validation->set_rules('intro', '外卖说明', 'trim|htmlspecialchars|max_length[500]');
            $this->form_validation->set_rules('deliveryTime', '外卖派送时间', 'trim|required|htmlspecialchars|max_length[500]');
        
            if ( $this->form_validation->run() ){
                $save_data['address_id'] = $this->form_validation->set_value('address_id');
                $save_data['tele'] = $this->form_validation->set_value('tele');
                
                //配送规则
                $rule = $this->form_validation->set_value('rule');
                $save_rule['rule'] = $rule;
                if( $rule==2 ){
                    $r2s = $rule = $this->form_validation->set_value('r2s');
                    if( !$r2s ){
                        $this->show_message(false, '请填写配送费用', '');return FALSE;
                    }
                    $r2e = $this->form_validation->set_value('r2e');
                    $r2e = $r2e ? $r2e : 0;
                    $save_rule['r2s'] = $r2s;
                    $save_rule['r2e'] = $r2e;
                }
                $save_data['rule'] = serialize($save_rule);
                
                $save_data['qisong'] = $this->form_validation->set_value('qisong');
                
                //营业时间
                $save_data['sh'] = intval($this->input->post('sh'));
                $save_data['eh'] = intval($this->input->post('eh'));
                
                $save_data['step_time'] = $this->form_validation->set_value('step_time');
                $save_data['ship_type'] = $this->form_validation->set_value('ship_type');
                $save_data['ship_time'] = $this->form_validation->set_value('ship_time');

                $save_data['shape'] = $this->input->post('shape');
                switch($save_data['shape']){
                    case 'circle':
                        $radius = $this->input->post('radius');
                        $point = $this->input->post('point');
                        $save_data['range_content'] = json_encode(array(
                            'radius' => $radius,
                            'point'  => $point
                        ));
                        break;
                    case 'polygon':
                        $points = $this->input->post('polygon_point');
                        if( $points ){
                            $save_data['range_content'] = json_encode($points);
                        }
                    default :;
                }
                if( !isset($save_data['range_content']) ){
                    $save_data['shape'] = 'circle';
                    $save_data['range_content'] = json_encode(array(
                        'radius' => 0,
                        'point'  => array(
                            'lng' => '',
                            'lat' => ''
                        )
                    ));
                }
                
                $save_data['range'] = $this->form_validation->set_value('range');
                $save_data['sales_volume'] = $this->form_validation->set_value('sales_volume');
                $save_data['printer_num'] = $this->form_validation->set_value('printer_num');
                $save_data['assistant'] = $this->form_validation->set_value('assistant');
                $save_data['email'] = $this->form_validation->set_value('email');
                $save_data['intro'] = $this->form_validation->set_value('intro');
                $save_data['delivery_time'] = $this->form_validation->set_value('deliveryTime');                
                
                //发送订单选项
                if( $save_data['email'] ){
                    $order_email_contents = $this->input->post('order',true);
                    if( !$order_email_contents ){
                        $this->show_message(false, '请选择要提醒的内容', '');return FALSE;
                    }
                    $order_email = '';
                    foreach( $order_email_contents as $key=>$val ){
                        $order_email .= $key.',';
                    }
                    $order_email = substr($order_email, 0,-1);
                    $save_data['send_content'] = $order_email;
                }
                //提醒设置
                $remind_type = $this->input->post('remind_type',true);
                if(($save_data['assistant'] || $save_data['email']) && !$remind_type)
                {
                    $this->show_message(false, '请选择提醒方式', '');return FALSE;
                }
                $remind_type && $save_data['remind_type'] = implode(',',$remind_type);
                
                $del_temp = $this->model->where(array('site_id'=>$this->site_id,'address_id'=>$save_data['address_id'],'status'=>1))->find();
                if( $del_temp ){//改状态
                    $save_data['status'] = 0;
                    if($this->model->where(array('site_id'=>$this->site_id,'address_id'=>$save_data['address_id']))->edit($save_data)){
                    }else{
                        $this->show_message(false, '添加失败', '/c/waimai_store2');return FALSE;
                    }
                }else{//添加
                    $save_data['site_id'] = $this->site_id;
                    $save_data['add_time'] = time();
                    if($this->model->add($save_data)){
                    }else{
                        $this->show_message(false, '添加失败', '/c/waimai_store2');return FALSE;
                    }
                }
                $this->show_message(true, '添加成功', '/c/waimai_store2');return FALSE;
            }else{ 
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            $this->load->view($this->dcm, $this->data);
        }
    }
    
    
    //配置门店     废弃
    public function config_address()
    {
        $res = $this->address();
        if( !$res ){
            $this->show_message(false, '请先添加地址', '/address/add');return FALSE;
        }
        
        $waimai_add = $this->model->select('id,address_id')->where(array('site_id'=>$this->site_id,'status'=>0))->find_all();
        $this->data['waimai_add'] = $waimai_add;
        
        
        if( $this->input->post() ){
            
            $add_temp = $this->input->post('address');
            $add_temp = $add_temp ? $add_temp : array();
            
            $selected_ad_ids = array();
            if( $waimai_add ){
                foreach($waimai_add as $ma) {
                    $selected_ad_ids[] = $ma['address_id'];
                }
            }
            
            $selected_ad_ids = isset($selected_ad_ids) && $selected_ad_ids ? $selected_ad_ids : array();
            $del_ids = array_diff($selected_ad_ids, $add_temp);
            $add_ids = array_diff($add_temp, $selected_ad_ids);
            
            if( $del_ids ){//需删除的门店
                foreach( $del_ids as $did ){
                    $this->model->where(array('site_id'=>$this->site_id,'address_id'=>$did))->edit(array('status'=>1));
                }
            }
            if( $add_ids ){//需添加的门店
                foreach( $add_ids as $aid ){
                    $del_temp = $this->model->where(array('site_id'=>$this->site_id,'address_id'=>$aid,'status'=>1))->find();
                    if( $del_temp ){//改状态
                        $this->model->where(array('site_id'=>$this->site_id,'address_id'=>$aid))->edit(array('status'=>0));
                    }else{//添加
                        $add_data = array(
                            'site_id' => $this->site_id,
                            'address_id' => $aid,
                            'add_time' => time()
                        );
                        $this->model->add($add_data);
                    }
                }
            }
            $this->show_message(true, '保存成功', '/c/waimai_store2');return FALSE;
            
        }else{
            $this->load->view($this->dcm, $this->data);
        }
    }
    
    /**
     * 修改门店信息
     */
    public function edit($store_id)
    {
        $res = $this->get_store($store_id);
        if( !$res ){
            $this->show_message(false, '非法操作', '/c/waimai_store2');return FALSE;
        }
        //配送费设置规则
        if( $this->data['store']['rule'] ){
            $this->data['store']['rule'] = unserialize($this->data['store']['rule']);
        }
        if( $this->data['store']['email'] ){
            $this->data['store']['send_content'] = explode(',', $this->data['store']['send_content']);
        }

        //配送范围
        if( $this->data['store']['range_content'] ){
            if( $this->data['store']['range_content'] ){
                $this->data['store']['range_content'] = json_decode($this->data['store']['range_content'], true);
            }
        }else{
            switch($this->data['store']['shape']){
                case 'circle':
                    $this->data['store']['range_content'] = array(
                        'radius' => 0,
                        'point'  => array(
                            'lng' => '',
                            'lat' => ''
                        )
                    );
                    break;
                default :
                    $this->data['store']['range_content'];
            }
        }

        //检查是否开通微助手
        if( $this->check_assistant($this->site_id) ){
            $this->data['assistant'] = 1;
        }else{
            $this->data['assistant'] = 0;
        }

        //获取门店名称和地址
        $this->load->model('model_address');
        $address = $this->model_address->get_row(array('id'=>$this->data['store']['address_id']));
        $this->data['address'] = $address;

        if( $this->input->post() ){
            $this->form_validation->set_rules('tele', '外卖电话', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('rule', '配送费设置', 'trim|numeric|greater_than[0]');
            $this->form_validation->set_rules('r2s', '配送费收费多少钱', 'trim|numeric|greater_than_equal_to[0]');
            $this->form_validation->set_rules('r2e', '配送费满后免费', 'trim|numeric|greater_than_equal_to[0]');
            $this->form_validation->set_rules('qisong', '起送条件', 'trim|required|numeric|greater_than_equal_to[0]');
            $this->form_validation->set_rules('step_time', '送餐预留时间', 'trim|required|numeric|greater_than_equal_to[900]');
            $this->form_validation->set_rules('ship_type', '订购支持', 'trim|required|numeric|greater_than_equal_to[1]');
            $this->form_validation->set_rules('ship_time', '提前订购天数', 'trim|numeric|greater_than_equal_to[1]');
            $this->form_validation->set_rules('sales_volume', '菜品显示销量', 'trim|intval');
            $this->form_validation->set_rules('printer_num', '小票打印机设置', 'trim|required|numeric|greater_than_equal_to[1]|intval');
            $this->form_validation->set_rules('assistant', '微助手提醒', 'trim|intval');
            $this->form_validation->set_rules('email', '订单微信提醒', 'trim|valid_email');
            $this->form_validation->set_rules('intro', '外卖说明', 'trim|htmlspecialchars|max_length[500]');
            $this->form_validation->set_rules('deliveryTime', '外卖派送时间', 'trim|required|htmlspecialchars|max_length[500]');            
            if ( $this->form_validation->run() ){
                $save_data['tele'] = $this->form_validation->set_value('tele');

                //配送规则
                $rule = $this->form_validation->set_value('rule');
                $save_rule['rule'] = $rule;
                if( $rule==2 ){
                    $r2s = $rule = $this->form_validation->set_value('r2s');
                    if( !$r2s ){
                        $this->show_message(false, '请填写配送费', '');return FALSE;
                    }
                    $r2e = $this->form_validation->set_value('r2e');
                    $r2e = $r2e ? $r2e : 0;
                    $save_rule['r2s'] = $r2s;
                    $save_rule['r2e'] = $r2e;
                }
                $save_data['rule'] = serialize($save_rule);
                
                $save_data['qisong'] = $this->form_validation->set_value('qisong');
                
                //营业时间
                $save_data['sh'] = intval($this->input->post('sh'));
                $save_data['eh'] = intval($this->input->post('eh'));
                
                $save_data['step_time'] = $this->form_validation->set_value('step_time');
                $save_data['ship_type'] = $this->form_validation->set_value('ship_type');
                $save_data['ship_time'] = $this->form_validation->set_value('ship_time');
                $save_data['delivery_time'] = $this->form_validation->set_value('deliveryTime');                

                $save_data['shape'] = $this->input->post('shape');
                switch($save_data['shape']){
                    case 'circle':
                        $radius = $this->input->post('radius');
                        $point = $this->input->post('point');
                        $save_data['range_content'] = json_encode(array(
                            'radius' => $radius,
                            'point'  => $point
                        ));
                        break;
                    case 'polygon':
                        $points = $this->input->post('polygon_point');
                        if( $points ){
                            $save_data['range_content'] = json_encode($points);
                        }
                    default :;
                }
                if( !isset($save_data['range_content']) ){
                    $save_data['shape'] = 'circle';
                    $save_data['range_content'] = json_encode(array(
                        'radius' => 0,
                        'point'  => array(
                            'lng' => '',
                            'lat' => ''
                        )
                    ));
                }

                $save_data['sales_volume'] = $this->form_validation->set_value('sales_volume');
                $save_data['printer_num'] = $this->form_validation->set_value('printer_num');
                $save_data['assistant'] = $this->form_validation->set_value('assistant');
                $save_data['email'] = $this->form_validation->set_value('email');
                $save_data['intro'] = $this->form_validation->set_value('intro');

                //发送订单选项
                if( $save_data['email'] ){
                    $order_email_contents = $this->input->post('order',true);
                    if( !$order_email_contents ){
                        $this->show_message(false, '请选择要提醒的内容', '');return FALSE;
                    }
                    $order_email = '';
                    foreach( $order_email_contents as $key=>$val ){
                        $order_email .= $key.',';
                    }
                    $order_email = substr($order_email, 0,-1);
                    $save_data['send_content'] = $order_email;
                }
                //提醒设置
                $remind_type = $this->input->post('remind_type',true);
                if(($save_data['assistant'] || $save_data['email']) && !$remind_type)
                {
                    $this->show_message(false, '请选择提醒方式', '');return FALSE;
                }
                $remind_type && $save_data['remind_type'] = implode(',',$remind_type);

                if( $this->model->where(array('site_id' => $this->site_id,'status' => 0,'id' => $store_id))->edit($save_data) ){
                    $this->show_message(true, '保存成功', '/c/waimai_store2');return FALSE;
                }else{
                    $this->show_message(false, '保存失败', '/c/waimai_store2');return FALSE;
                }
            }else{ 
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            $this->load->view($this->dcm, $this->data);
        }
    }
    
    public function delete_store($store_id)
    {
        $res = $this->get_store($store_id);
        if( !$res ){
            $this->show_message(false, '非法操作', '/c/waimai_store2');return FALSE;
        }
        
        if( $this->model->where(array('site_id'=>$this->site_id,'status' => 0,'id'=>$store_id))->edit(array('status'=>1)) ){
            $this->show_message(true, '删除成功', '/c/waimai_store2');return FALSE;
        }else{
            $this->show_message(false, '删除失败', '/c/waimai_store2');return FALSE;
        }
    }
    
    
    //门店标签
    public function tags($store_id)
    {
        $res = $this->get_store($store_id);
        if( !$res ){
            $this->show_message(false, '非法操作', '/c/waimai_store2');return FALSE;
        }
        $where = array(
            'site_id' => $this->site_id,
            'store_id' => $store_id,
            'status' => 0
        );
        $total_rows = $this->waimai_store_tag_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15));
        $list = $this->waimai_store_tag_model
                ->limit($pager['limit']['value'], $pager['limit']['offset'])
                ->where($where)->order_by('sort asc,id desc')->find_all();
        
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        
        
        $this->load->view($this->dcm, $this->data);
    }
    
    //添加标签
    public function add_tag($store_id)
    {
        $res = $this->get_store($store_id);
        if( !$res ){
            $this->show_message(false, '非法操作', '/c/waimai_store2/tags/'.$store_id);return FALSE;
        }
        
        if( $this->input->post() ){
            $this->form_validation->set_rules('name', '标签名', 'trim|required|max_length[10]');
            $this->form_validation->set_rules('sort', '排序', 'trim|is_natural_no_zero');
            $this->form_validation->set_rules('show', '排序', 'trim|intval');
            $this->form_validation->set_rules('intro', '外卖说明', 'trim|htmlspecialchars|max_length[500]');
            if ( $this->form_validation->run() ){
                
                $save_data['name'] = $this->form_validation->set_value('name');
                $save_data['sort'] = $this->form_validation->set_value('sort');
                $save_data['sort'] = $save_data['sort'] ? $save_data['sort'] : 0;
                $save_data['show'] = $this->form_validation->set_value('show');
                $save_data['intro'] = $this->form_validation->set_value('intro');
                
                $save_data['site_id'] = $this->site_id;
                $save_data['store_id'] = $store_id;
                
                //唯一验证
                $res = $this->check_tag($save_data['name'],$store_id);
                if( $res ){
                    $this->show_message(false, '已添加过该标签', '/c/waimai_store2/tags/'.$store_id);return FALSE;
                }
                
                //判断是否已经存在过
                $temp_tag  = $this->waimai_store_tag_model->where(array('site_id'=>$this->site_id,'store_id'=>$store_id,'name'=>$save_data['name'],'status'=>1))->find();
                if( $temp_tag ){
                    //修改原来的数据
                    $save_data['status'] = 0;
                    if( $this->waimai_store_tag_model->where(array('site_id'=>$this->site_id,'store_id'=>$store_id,'name'=>$save_data['name'],'status'=>1))->edit($save_data) ){
                        $this->show_message(true, '添加成功', '/c/waimai_store2/tags/'.$store_id);return FALSE;
                    }else{
                        $this->show_message(false, '添加失败', '/c/waimai_store2/tags/'.$store_id);return FALSE;
                    }
                }else{
                    $save_data['add_time'] = time();
                    if( $this->waimai_store_tag_model->add($save_data) ){
                        $this->show_message(true, '添加成功', '/c/waimai_store2/tags/'.$store_id);return FALSE;
                    }else{
                        $this->show_message(false, '添加失败', '/c/waimai_store2/tags/'.$store_id);return FALSE;
                    }
                }
                
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            $this->load->view($this->dcm, $this->data);
        }
    }
    
    //标签唯一性验证
    private function check_tag($name,$sid,$id='')
    {
        $where = array(
            'site_id' => $this->site_id,
            'store_id' => $sid,
            'name' => $name,
            'status' => 0
        );
        
        if( $id ){
            $where['id <>'] = $id;
        }
        $tag = $this->waimai_store_tag_model->where($where)->find();
        if( $tag ){
            return true;
        }else{
            return false;
        }
    }
    
    //编辑标签
    public function edit_tag()
    {
        $store_id = $this->input->get('sid');
        $tag_id = $this->input->get('id');
        
        $res = $this->get_store($store_id);
        if( !$res ){
            $this->show_message(false, '非法操作', '/c/waimai_store2/tags/'.$store_id);return FALSE;
        }

        $tag = $this->waimai_store_tag_model->where(array('site_id'=>$this->site_id,'store_id'=>$store_id,'id'=>$tag_id,'status'=>0))->find();
        if( !$tag ){
            $this->show_message(false, '非法操作', '/c/waimai_store2/tags/'.$store_id);return FALSE;
        }
        $this->data['tag'] = $tag;
        
        if( $this->input->post() ){
            $this->form_validation->set_rules('name', '标签名', 'trim|required|max_length[10]');
            $this->form_validation->set_rules('sort', '排序', 'trim|is_natural_no_zero');
            $this->form_validation->set_rules('show', '排序', 'trim|intval');
            $this->form_validation->set_rules('intro', '外卖说明', 'trim|htmlspecialchars|max_length[500]');
            if ( $this->form_validation->run() ){
                
                $save_data['name'] = $this->form_validation->set_value('name');
                $save_data['sort'] = $this->form_validation->set_value('sort');
                $save_data['sort'] = $save_data['sort'] ? $save_data['sort'] : 0;
                $save_data['show'] = $this->form_validation->set_value('show');
                $save_data['intro'] = $this->form_validation->set_value('intro');
                
                $save_data['site_id'] = $this->site_id;
                $save_data['store_id'] = $store_id;
                
                //唯一验证
                $res = $this->check_tag($save_data['name'],$store_id,$tag_id);
                if( $res ){
                    $this->show_message(false, '已添加过该标签', '/c/waimai_store2/tags/'.$store_id);return FALSE;
                }
                
                if( $this->waimai_store_tag_model->where(array('site_id'=>$this->site_id,'store_id'=>$store_id,'id'=>$tag_id,'status'=>0))->edit($save_data) ){
                    $this->show_message(true, '修改成功', '/c/waimai_store2/tags/'.$store_id);return FALSE;
                }else{
                    $this->show_message(false, '修改失败', '/c/waimai_store2/tags/'.$store_id);return FALSE;
                }
                
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            $this->load->view($this->dcm, $this->data);
        }
    }
    
    //删除标签
    public function delete_tag()
    {
        $store_id = $this->input->get('sid');
        $tag_id = $this->input->get('id');
        
        $res = $this->get_store($store_id);
        if( !$res ){
            $this->show_message(false, '非法操作', '/c/waimai_store2/tags/'.$store_id);return FALSE;
        }
        $tag = $this->waimai_store_tag_model->where(array('site_id'=>$this->site_id,'store_id'=>$store_id,'id'=>$tag_id,'status'=>0))->find();
        if( !$tag ){
            $this->show_message(false, '非法操作', '/c/waimai_store2/tags/'.$store_id);return FALSE;
        }
        
        $save_data['status'] = 1;
        if( $this->waimai_store_tag_model->where(array('site_id'=>$this->site_id,'store_id'=>$store_id,'id'=>$tag_id,'status'=>0))->edit($save_data) ){
            $this->show_message(true, '删除成功', '/c/waimai_store2/tags/'.$store_id);return FALSE;
        }else{
            $this->show_message(false, '删除失败', '/c/waimai_store2/tags/'.$store_id);return FALSE;
        }
    }
    
    
    //获取门店信息
    private function get_store($store_id)
    {
        $where = array(
            'site_id' => $this->site_id,
            'status' => 0,
            'id' => $store_id
        );
        $waimai_store = $this->model->where($where)->find();
        $waimai_store = $waimai_store ? $waimai_store : array();
        $this->data['store'] = $waimai_store;
        if( !$waimai_store ){
            return false;
        }
        return true;
    }
    
    /**
     * 默认单位  联系方式里的
     */
    private function address()
    {
        //分店
        $this->load->model('model_address');
        $address_list = $this->model_address->get_all(array('wid'=>$this->site_id, 'status'=>0), '', '');
        $address_list = $address_list ? $address_list : array();
        $this->data['address_list'] = $address_list;
        if( !$address_list ){
            return false;
        }
        return true;
    }

    /**
     * @name 一个门店下的菜品列表
     * @return bool
     */
    public function dishes()
    {
        $sid = $this->input->get('sid');

        //门店是否存在
        $storeInfo = $this->get_store($sid);
        if(!$sid || !$storeInfo)
        {
            $this->show_message(false, '门店不存在', '/c/waimai_store2');return FALSE;
        }

        $this->xiajia($sid);

        $where = array(
            'waimai_dishes.site_id'=>$this->site_id,
            'waimai_dishes.sid'=>$sid
        );

        $like = array();
        $search['title'] = $this->input->get('title');
        $search['price'] = $this->input->get('price');
        $search['oldprice'] = $this->input->get('oldprice');

        $this->data['search'] = $search;
        $search_url = '/c/waimai_store2/dishes/?sid='.$sid;
        //标题模糊查询
        if($search['title'])
        {
            $like['dishes.title'] = $search['title'];
        }
        if($search['oldprice'])
        {
            $where['dishes.price'] = $search['oldprice'];
        }
        if($search['price'])
        {
            $where['waimai_dishes.price'] = $search['price'];
        }
        if($search)
        {
            foreach( $search as $key=>$val ){
                $search_url .= '&'.$key.'='.$val;
            }
        }

        $total_rows = $this->waimai_dishes_model->join('dishes','dishes.id=waimai_dishes.dishes_id')->where($where)->like($like)->count();

        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$search_url));


        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        //门店下的所有标签
        $tagwhere = array(
            'site_id' => $this->site_id,
            'store_id' => $sid,
            'status' => 0
        );
        $taglist = $this->waimai_store_tag_model->where($tagwhere)->order_by('id desc')->find_all();
        $tagArr = array();
        if($taglist)
        {
            foreach($taglist as $tag)
            {
                $tagArr[$tag['id']] = $tag;
            }
        }

        $list = $this->waimai_dishes_model
            ->select('waimai_dishes.id,waimai_dishes.price,waimai_dishes.stock,waimai_dishes.stock_set,waimai_dishes.purchase_set,waimai_dishes.purchase,waimai_dishes.publish,dishes.cid,dishes.pic,dishes.price as oldprice,dishes.title')
            ->join('dishes','dishes.id=waimai_dishes.dishes_id')
            ->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->where($where)->like($like)->order_by('waimai_dishes.rank desc')->find_all();
        $dishesArr = array();
        if($list)
        {
            foreach($list as $_list)
            {
                //菜品的tag
                $dishesTag = $this->waimai_dishes_tag_model
                    ->select('waimai_store_tag.name')
                    ->join('waimai_store_tag','waimai_dishes_tag.tag_id=waimai_store_tag.id')
                    ->where(array('waimai_dishes_tag.site_id'=>$this->site_id,'waimai_dishes_tag.sid'=>$sid,'waimai_dishes_tag.dishes_id'=>$_list['id']))
                    ->find_all();
                if($dishesTag)
                {
                    $dot = $tags = '';
                    foreach($dishesTag as $tag)
                    {
                        $tags .= $dot.$tag['name'];
                        $dot = ',';
                    }
                    $_list['tag'] = $tags;
                }
                $dishesArr[] = $_list;
            }
        }

        $this->data['list'] = $dishesArr;

        $this->load->view($this->dcm, $this->data);
    }

    /**
     * @name 增加门店的菜品
     * @return bool
     */
    public function get_dishes()
    {
        $sid = $this->input->get('sid');
        //门店是否存在
        $storeInfo = $this->get_store($sid);
        if(!$sid || !$storeInfo)
        {
            $this->show_message(false, '门店不存在', '/c/waimai_store2');return FALSE;
        }

        $this->xiajia($sid);

        //所有的菜品
        $this->load->model('dishes_model');
        $where['site_id'] = $this->site_info['id'];

        $list = $this->dishes_model->order_by('id desc')->where($where)->find_all();
        if(!$list)
        {
            $this->show_message(false, '请先添加菜品', '/c/dishes2');return FALSE;
        }
        $dishesList = array();
        foreach($list as $_list)
        {
            $dishesList[$_list['id']] = $_list;
        }
        //门店下的所有标签

        $where = array(
            'site_id' => $this->site_id,
            'store_id' => $sid,
            'status' => 0
        );
        $taglist = $this->waimai_store_tag_model->where($where)->order_by('sort asc,id desc')->find_all();
        if(!$taglist)
        {
            $this->show_message(false, '请先添加该门店下的标签', '/c/waimai_store2/add_tag/'.$sid);return FALSE;
        }
        $this->data['taglist'] = $taglist;
        $post = $this->input->post();

        //print_r($postData);
        if($post)
        {
            //菜品是否有选择
            $dishes_id = $this->input->post('dishes_id');
            if(!$dishes_id)
            {
                $this->show_message(false, '请选择菜品', '/c/waimai_store2/get_dishes/?sid='.$sid);return FALSE;
            }
            //tag是否有选择
            $tag = $this->input->post('tag');
            if(!$tag)
            {
                $this->show_message(false, '请选择标签！', '/c/waimai_store2/get_dishes/?sid='.$sid);return FALSE;
            }
            $price = $this->input->post('price');
            //判断价格
            if(!is_numeric($price) || $price<0)
            {
                $this->show_message(false, '价格必须是非负数！', '/c/waimai_store2/get_dishes/?sid='.$sid);return FALSE;
            }
            $price = $price ? $price : $dishesList[$dishes_id]['price'];

            $unit = $this->input->post('unit',true);
            if( mb_strlen($unit)>20 ){
                $this->show_message(false, '单位不能超过20个字！', '/c/waimai_store2/get_dishes/?sid='.$sid);return FALSE;
            }

            //排序
            $rank = $this->input->post('rank');
            $rank = is_numeric($rank) ? $rank : 0;
            
            //库存
            $stock_set = intval($this->input->post('stock_set'));
            if( $stock_set ){
                $stock = $this->input->post('stock');
                $stock = is_numeric($stock) ? $stock : 0;
            }else{
                $stock = 0;
            }

            //限购
            $purchase_set = intval($this->input->post('purchase_set'));
            if( $purchase_set ){
                $purchase = intval($this->input->post('purchase'));
                if( !$purchase ){
                    $this->show_message(false, '请填写限购数量', '/c/waimai_store2/get_dishes/?sid='.$sid);return FALSE;
                }
            }else{
                $purchase = 0;
            }

            //发布
            $publish = intval($this->input->post('publish'));
                               
            $newdishesid = $this->waimai_dishes_model->add(array(
                'site_id'=>$this->site_id,
                'sid'=>$sid,
                'dishes_id'=>$dishes_id,
                'price'=>$price,
                'rank'=>$rank,
                'inputtime'=>time(),
                'stock_set'=>$stock_set,
                'stock'=>$stock,
                'purchase_set'=>$purchase_set,
                'purchase'=>$purchase,
                'publish'=>$publish
            ));
            if($newdishesid)
            {
                foreach($tag as $_tag)
                {
                    $this->waimai_dishes_tag_model->add(array('site_id'=>$this->site_id,'sid'=>$sid,'dishes_id'=>$newdishesid,'tag_id'=>$_tag));
                }
            }
            $this->show_message(true, '添加成功', '/c/waimai_store2/dishes/?sid='.$sid);return FALSE;
        }
        else
        {
            //当前门店下已选择的菜品
            $storeDishesList = $this->waimai_dishes_model->where(array('site_id'=>$this->site_info['id'],'sid'=>$sid))->find_all();
            if($storeDishesList)
            {
                //可选择的菜品
                foreach($storeDishesList as $slist)
                {
                    if(isset($dishesList[$slist['dishes_id']])&&$dishesList[$slist['dishes_id']])
                    {
                        unset($dishesList[$slist['dishes_id']]);
                    }
                }
            }
            $this->data['list'] = $dishesList;
            $this->load->view($this->dcm, $this->data);
        }

    }

    /**
     * @name 编辑门店下的菜品
     * @return bool
     */
    public function edit_dishes()
    {
        $id = $this->input->get('id');
        //菜品是否存在
        $storeDishes = $this->waimai_dishes_model
            ->select('waimai_dishes.id,waimai_dishes.price,waimai_dishes.sid,waimai_dishes.rank,dishes.cid,dishes.pic,dishes.price as oldprice,dishes.title,dishes.description,stock_set,stock,purchase_set,purchase,publish,unit')
            ->join('dishes','dishes.id=waimai_dishes.dishes_id')
            ->where(array('waimai_dishes.site_id'=>$this->site_id,'waimai_dishes.id'=>$id))->find();

        //门店是否存在
        $storeInfo = $this->get_store($storeDishes['sid']);
        if( !$storeInfo)
        {
            $this->show_message(false, '门店不存在', '/c/waimai_store2');return FALSE;
        }
        $this->xiajia($storeInfo['id']);
        $tagWhere = array('site_id'=>$this->site_id,'sid'=>$storeDishes['sid'],'dishes_id'=>$id);

        if( $this->input->post() )
        {
            $this->form_validation->set_rules('price', '菜品现价', 'trim');
            $this->form_validation->set_rules('unit', '单位', 'trim|max_length[20]');
            $this->form_validation->set_rules('rank', '排序', 'trim|numeric');
            $this->form_validation->set_rules('stock_set', '库存限制', 'trim|numeric|intval');
            $this->form_validation->set_rules('stock', '库存', 'trim|numeric');
            $this->form_validation->set_rules('purchase_set', '限购限制', 'trim|numeric|intval');
            $this->form_validation->set_rules('purchase', '限购数量', 'trim|numeric');
            $this->form_validation->set_rules('publish', '发布', 'trim|numeric|intval');
                    
            if($this->form_validation->run())
            {
                $save_data['price'] = $this->form_validation->set_value('price');
                //判断价格
                if(!is_numeric($save_data['price']) || $save_data['price'] <0 )
                {
                    $this->show_message(false, '价格必须是非负数！', '/c/waimai_store2/edit_dishes/?id='.$id);return FALSE;
                }
                $save_data['unit'] = $this->form_validation->set_value('unit');
                $save_data['rank'] = $this->form_validation->set_value('rank');
                $save_data['rank'] = is_numeric($save_data['rank']) ? $save_data['rank'] : 0;
                $tag = $this->input->post('tag');
                if(!$tag)
                {
                    $this->show_message(false, '请选择标签！', '/c/waimai_store2/edit_dishes/?id='.$id);return FALSE;
                }
                else
                {
                    //删除原有的tag
                    $this->waimai_dishes_tag_model->where($tagWhere)->delete();
                    foreach($tag as $_tag)
                    {
                        $this->waimai_dishes_tag_model->add(array('site_id'=>$this->site_id,'sid'=>$storeDishes['sid'],'dishes_id'=>$id,'tag_id'=>$_tag));
                    }
                }
                
                $save_data['stock_set'] = $this->form_validation->set_value('stock_set');
                if( !$save_data['stock_set'] ){
                    $save_data['stock'] = 0;
                }else{
                    $save_data['stock'] = $this->form_validation->set_value('stock');
                }
                $save_data['purchase_set'] = $this->form_validation->set_value('purchase_set');
                if( !$save_data['purchase_set'] ){
                    $save_data['purchase'] = 0;
                }else{
                    $save_data['purchase'] = $this->form_validation->set_value('purchase');
                    if( !$save_data['purchase'] ){
                        $this->show_message(false, '请填写限购数量', '/c/waimai_store2/edit_dishes/?id='.$id);return FALSE;
                    }
                }
                $save_data['publish'] = $this->form_validation->set_value('publish');

                if( $this->waimai_dishes_model->where(array('site_id' => $this->site_id,'id' => $id))->edit($save_data) )
                {
                    $this->show_message(true, '保存成功', '/c/waimai_store2/dishes/?sid='.$storeDishes['sid']);return FALSE;
                }else{
                    $this->show_message(false, '保存失败', '/c/waimai_store2/edit_dishes/?id='.$id);return FALSE;
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }
        else
        {
            //已经保存的菜品标签
            $this->data['dishestaglist'] = $this->waimai_dishes_tag_model->where($tagWhere)->find_all();

            //门店下的所有标签
            $where = array(
                'site_id' => $this->site_id,
                'store_id' => $storeDishes['sid'],
                'status' => 0
            );
            $taglist = $this->waimai_store_tag_model->where($where)->order_by('sort asc,id desc')->find_all();
			
            $this->data['taglist'] = $taglist;
            $this->data['storedishes'] = $storeDishes;
            $this->load->view($this->dcm, $this->data);
        }
    }

    /**
     * @name 删除一个菜品
     * @param $id
     * @return bool
     */
    public function delete_dishes($id)
    {
        //菜品是否存在
        $storeDishes = $this->waimai_dishes_model
            ->select('waimai_dishes.id,waimai_dishes.price,waimai_dishes.sid,waimai_dishes.rank,dishes.cid,dishes.pic,dishes.price as oldprice,dishes.title,dishes.description')
            ->join('dishes','dishes.id=waimai_dishes.dishes_id')
            ->where(array('waimai_dishes.site_id'=>$this->site_id,'waimai_dishes.id'=>$id))->find();

        //门店是否存在
        $storeInfo = $this->get_store($storeDishes['sid']);
        if( !$storeInfo)
        {
            $this->show_message(false, '门店不存在', '/c/waimai_store2');return FALSE;
        }
        $this->xiajia($storeInfo['id']);
        if( $this->waimai_dishes_model->where(array('site_id' => $this->site_id,'id' => $id))->delete() )
        {
            //删除tag
            $tagWhere = array('site_id'=>$this->site_id,'sid'=>$storeDishes['sid'],'dishes_id'=>$id);
            $this->waimai_dishes_tag_model->where($tagWhere)->delete();
            $this->show_message(true, '删除成功', '/c/waimai_store2/dishes/?sid='.$storeDishes['sid']);return FALSE;
        }else{
            $this->show_message(false, '删除失败', '/c/waimai_store2/dishes/?sid='.$storeDishes['sid']);return FALSE;
        }
    }

    /**
     * 上架
     */
    public function dishes_publish($id)
    {
        //菜品是否存在
        $storeDishes = $this->waimai_dishes_model
            ->select('waimai_dishes.*,stock_set,stock,purchase_set,purchase,publish')
            ->join('dishes','dishes.id=waimai_dishes.dishes_id')
            ->where(array('waimai_dishes.site_id'=>$this->site_id,'waimai_dishes.id'=>$id))->find();
        if( !$storeDishes ){
            $this->show_message(false, '没有找到该菜品', '/c/waimai_store2');return FALSE;
        }

        //门店是否存在
        $storeInfo = $this->get_store($storeDishes['sid']);
        if( !$storeInfo){
            $this->show_message(false, '门店不存在', '/c/waimai_store2');return FALSE;
        }
        $this->xiajia($storeInfo['id']);
        if( $storeDishes['stock_set']==1 ){
            if( $storeDishes['stock']==0 ){
                $this->show_message(false, '该菜品没有库存了，不能上架', '/c/waimai_store2/dishes/?sid='.$storeDishes['sid']);return FALSE;
            }
        }
        if( $this->waimai_dishes_model->where(array('id' => $storeDishes['id']))->edit(array('publish'=>1)) ){
            $this->show_message(true, '保存成功', '/c/waimai_store2/dishes/?sid='.$storeDishes['sid']);return FALSE;
        }else{
            $this->show_message(false, '保存失败', '/c/waimai_store2');return FALSE;
        }
    }

    /**
     * 上架
     */
    public function dishes_publish_down($id)
    {
        //菜品是否存在
        $storeDishes = $this->waimai_dishes_model
            ->select('waimai_dishes.*,stock_set,stock,purchase_set,purchase,publish')
            ->join('dishes','dishes.id=waimai_dishes.dishes_id')
            ->where(array('waimai_dishes.site_id'=>$this->site_id,'waimai_dishes.id'=>$id))->find();
        if( !$storeDishes ){
            $this->show_message(false, '没有找到该菜品', '/c/waimai_store2');return FALSE;
        }

        //门店是否存在
        $storeInfo = $this->get_store($storeDishes['sid']);
        if( !$storeInfo){
            $this->show_message(false, '门店不存在', '/c/waimai_store2');return FALSE;
        }
        $this->xiajia($storeInfo['id']);
        if( $this->waimai_dishes_model->where(array('id' => $storeDishes['id']))->edit(array('publish'=>0)) ){
            $this->show_message(true, '保存成功', '/c/waimai_store2/dishes/?sid='.$storeDishes['sid']);return FALSE;
        }else{
            $this->show_message(false, '保存失败', '/c/waimai_store2');return FALSE;
        }
    }

    /**
     * @name  查看订单详情
     * @return bool
     */
    public function order_detail()
    {
        //订单id
        $id = $this->input->get('id');

        $orderDetail = $this->get_one_order_info($id);
        if(!$orderDetail)
        {
            $this->show_message(false, '订单不存在', '');return FALSE;
        }
        //订单商品
        $this->load->model('waimai_order_dishes_model');
        $orderDishes = $this->waimai_order_dishes_model->where(array('site_id'=>$this->site_id,'order_id'=>$id))->find_all();
        $this->data['orderdishes'] = $orderDishes;

        //联系人信息
        $this->load->model('waimai_address_model');
        $address = $this->waimai_address_model->where(array('site_id'=>$this->site_id,'id'=>$orderDetail['address_id']))->find();
        if( !$orderDetail['name'] ){
            if( !$address ){
                $address['name'] = $address['mobile'] = $address['address'] = $address['lat'] = $address['lng'] ='';
            }
        }else{
            $address['name'] = $orderDetail['name'];
            $address['mobile'] = $orderDetail['mobile'];
            $address['address'] = $orderDetail['address'];
            $address['lat'] = $orderDetail['lat'];
            $address['lng'] = $orderDetail['lng'];
        }
        $this->data['address'] = $address;

        //订单状态
        $orderStatus = $this->order_status_list;

        $orderDetail['status'] = $orderStatus[$orderDetail['order_status']];

        $this->data['detail'] = $orderDetail;

        $this->load->view($this->dcm, $this->data);
    }

    //打印订单
    public function order_print()
    {
        $id = $this->input->get_post('id');

        $order_info = $this->get_one_order_info($id);
        if(!$order_info){
            $result['success'] = -1;
            $result['msg'] = '订单不存在';
            exit(json_encode($result));
        }
        $store = $this->get_store($order_info['store_id']);
        if(!$store){
            $result['success'] = -1;
            $result['msg'] = '门店不存在';
            exit(json_encode($result));
        }
        $store = $this->data['store'];
        $this->load->model('model_address');
        $store_add = $this->model_address->get_row(array('wid'=>$order_info['site_id'], 'id'=>$store['address_id']));
        if( !$store_add ){
            $result['success'] = -1;
            $result['msg'] = '没有找到该订单中的地址';
            exit(json_encode($result));
        }
        if( !$store_add['printer_name']||!$store_add['printer_secret'] ){
            $result['success'] = -1;
            $result['msg'] = '请先配置好小票打印机';
            exit(json_encode($result));
        }
        $store['add_name'] = $store_add['name'] ? $store_add['name'] : '';
        $store['printer_name'] = $store_add['printer_name'];
        $store['printer_secret'] = $store_add['printer_secret'];
        $store['dayinji_type'] = $store_add['dayinji_type'];

        //获取预订人信息
        $this->load->model('model_account');
        $user = $this->model_account->get_row(array('id'=>$order_info['uid'],'wid'=>$order_info['site_id']));

        //收货人及收货地址
        if( !$order_info['name'] ){
            $this->load->model('waimai_address_model');
            $address = $this->waimai_address_model->where(array('site_id'=>$this->site_id,'id'=>$order_info['address_id']))->find();
            if( !$address ){
                $address['name'] = $address['mobile'] = $address['address'] = '';
            }
        }else{
            $address['name'] = $order_info['name'];
            $address['mobile'] = $order_info['mobile'];
            $address['address'] = $order_info['address'];
        }

        //获取菜品
        $this->load->model('waimai_order_dishes_model');
        $order_dishes = $this->waimai_order_dishes_model->where(array('site_id'=>$order_info['site_id'],'order_id'=>$order_info['id']))->find_all();

        //订单状态
        $orderStatus = $this->order_status_list;
        $order_info['status'] = $orderStatus[$order_info['order_status']];

        if($order_info && $store && $address && $order_dishes) {
            $content = "CC!-CC!".date('Y-m-d H:i:s', $order_info['add_time'])."\n";
            $content .= "--------------------------------\n";
            $content .= '订单编号：'.$order_info['order_sn']."\n";
            $content .= '门店名：'.$store['add_name']."\n地址：".$store['address']."\n";
            $content .= '预订人电话：'.$user['mobile']."\n";
            $content .= '订单总价：￥'.$order_info['all_price']."\n";
            $content .= '收货人：'.$address['name']."\n收货人电话：".$address['mobile']."\n收货人地址：".$address['address']."\n";
            $content .= '送达时间：'.$order_info['reach_time']."\n";
            $content .= "--------------------------------\n";
            foreach( $order_dishes as $val ){
                $content .= '【'.$val['dishes_name'].' ￥'.$val['dishes_price'].'】×'.$val['dishes_num']."\n";
            }
            $order_info['mark'] && $content .= '订单备注：'.$order_info['mark']."\n";
            $content .= "--------------------------------\n";
            $content .= '订单状态：'.$order_info['status']."\n";
            if($order_info['pay_time']>0){
                $content .= '付款时间：'.date('Y-m-d H:i:s',$order_info['pay_time'])."\n";
            }
            if($order_info['payment_name']){
                $content .= '付款方式：'.$order_info['payment_name']."\n";
            }
            if($order_info['payment_sn']){
                $content .= '付款单号：'.$order_info['payment_sn']."\n";
            }

            if( $store['dayinji_type']==2 ){
                $content = str_replace( "\n", "\\n", $content );
            }
            $store['printer_num'] = $store['printer_num'] ? intval($store['printer_num']) : 1;
            $printer_num = intval($store['printer_num']);
            for( $i=0;$i<$printer_num;$i++ ){
                if( intval($store['printer_num'])>1 ){
                    $content_end = "CC!-CC!".($i+1)."CC!-CC!\n".$content;
                }else{
                    $content_end = $content;
                }
                $ret = $this->print_ticket($store, $content_end);
            }
        }else{
            $result['success'] = -1;
            $result['msg'] = '打印信息不完整';
            exit(json_encode($result));
        }

        $result['success'] = 1;
        $result['msg'] = '已加入到打印队列';
        exit(json_encode($result));
    }

    public function order_price()
    {
        $id = $this->input->post('id');

        $orderDetail = $this->get_one_order_info($id);
        if(!$orderDetail)
        {
            $this->show_message(false, '订单不存在', '');return FALSE;
        }
        $data = $this->input->post('data');
        if($orderDetail['order_status'] == 0)
        {
            $this->waimai_order_model->where(array('id'=>$id,'site_id'=>$this->site_id))->edit($data);
            $result['success'] = 1;
            $result['msg'] = '修改成功';

        }
        else
        {
            $result['success'] = 0;
            $result['msg'] = '当前订单不能修改总价';
        }

        echo json_encode($result);
        exit;
    }

    /**
     * @name 取消订单
     * @return bool
     */
    public function order_cancel()
    {
        $id = $this->input->post('id');
        $orderDetail = $this->get_one_order_info($id);
        if(!$orderDetail)
        {
            $this->show_message(false, '订单不存在', '');return FALSE;
        }
        if($orderDetail['order_status'] ==0 || $orderDetail['order_status'] == 3)
        {
            if($this->waimai_order_model->where(array('id'=>$id))->edit(array('order_status'=>-1,'end_time'=>time())))
            {
                $result['success'] = 1;
                $result['msg'] = '修改成功';

                //修改订单统计表
                //$this->load->model('waimai_order_statistics_model');
                //通过创建订单的时间得到当天开始时间
                $starttime = strtotime(date('Y-m-d',$orderDetail['add_time']));
                $this->db
                    ->where(array('site_id'=>$this->site_id,'store_id'=>$orderDetail['store_id'],'add_time'=>$starttime))
                    ->set('valid_order', 'valid_order+1', FALSE)
                    ->set('invalid_order', 'invalid_order-1', FALSE)
                    ->update('waimai_order_statistics');
            }
            else
            {
                $result['success'] = 0;
                $result['msg'] = '修改失败';
            }
        }
        else
        {
            $result['success'] = 0;
            $result['msg'] = '不能取消当前状态下的订单';
        }
        echo json_encode($result);
        exit;
    }

    /**
     * @name 订单状态改为已付款
     * @return bool
     */
    public function order_payed()
    {
        $id = $this->input->post('id');
        $orderDetail = $this->get_one_order_info($id);
        if(!$orderDetail)
        {
            $this->show_message(false, '订单不存在', '');return FALSE;
        }
        //判断订单是否可以改成已支付状态
        if($orderDetail['order_status']==0)
        {
            if($this->waimai_order_model->where(array('id'=>$id))->edit(array('order_status'=>1,'pay_time'=>time())))
            {
                $result['success'] = 1;
                $result['msg'] = '修改成功';
            }
            else
            {
                $result['success'] = 0;
                $result['msg'] = '修改失败';
            }
        }
        else
        {
            $result['success'] = 0;
            $result['msg'] = '当前订单不支持修改成已付款';
        }
        echo json_encode($result);
        exit;
    }

    /**
     * @name 将订单状态改为 确认订单 到配送中
     * @return bool
     */
    public function order_send()
    {
        $id = $this->input->post('id');
        $orderDetail = $this->get_one_order_info($id);
        if(!$orderDetail)
        {
            $this->show_message(false, '订单不存在', '');return FALSE;
        }
        if($orderDetail['order_status']==1 || $orderDetail['order_status']==3)//已付款 / 货到付款
        {
            if($this->waimai_order_model->where(array('id'=>$id))->edit(array('order_status'=>2)))
            {
                $result['success'] = 1;
                $result['msg'] = '修改成功';
            }
            else
            {
                $result['success'] = 0;
                $result['msg'] = '修改失败';
            }
        }
        else
        {
            $result['success'] = 0;
            $result['msg'] = '当前订单不支持修改成配送中';
        }
        echo json_encode($result);
        exit;
    }

    /**
     * @name 将订单状态改为交易成功
     * @return bool
     */
    public function order_received()
    {
        $id = $this->input->post('id');
        $orderDetail = $this->get_one_order_info($id);
        if(!$orderDetail)
        {
            $this->show_message(false, '订单不存在', '');return FALSE;
        }
        if($orderDetail['order_status']==2)
        {
            if($this->waimai_order_model->where(array('id'=>$id))->edit(array('order_status'=>4,'confirm_time'=>time(),'end_time'=>time())))
            {
                $result['success'] = 1;
                $result['msg'] = '修改成功';
                //修改订单统计表

                //通过创建订单的时间得到当天开始时间
                $starttime = strtotime(date('Y-m-d',$orderDetail['add_time']));
                $this->db
                    ->where(array('site_id'=>$this->site_id,'store_id'=>$orderDetail['store_id'],'add_time'=>$starttime))
                    ->set('valid_order', 'valid_order+1', FALSE)
                    ->set('invalid_order', 'invalid_order-1', FALSE)
                    ->set('total_price','total_price+'.$orderDetail['all_price'],false)
                    ->set('avg_price','total_price/total_order',false)
                    ->update('waimai_order_statistics');
            }
            else
            {
                $result['success'] = 0;
                $result['msg'] = '修改失败';
            }
        }
        else
        {
            $result['success'] = 0;
            $result['msg'] = '修改失败';
        }
        echo json_encode($result);
        exit;
    }

    /**
     * 修改商家备注
     */
    public function order_cmark()
    {
        $id = $this->input->post('id');
        $orderDetail = $this->get_one_order_info($id);
        if(!$orderDetail)
        {
            $this->show_message(false, '订单不存在', '');return FALSE;
        }
        $cmark = $this->input->post('cmark');
        if($this->waimai_order_model->where(array('id'=>$id))->edit(array('cmark'=>$cmark)))
        {
            $result['success'] = 1;
            $result['msg'] = '备注修改成功';
        }
        else
        {
            $result['success'] = 0;
            $result['msg'] = '操作失败';
        }
        echo json_encode($result);
        exit;
    }
    
    //订单列表
    public function order_list($store_id)
    {
        $res = $this->get_store($store_id);
        if( !$res ){
            $this->show_message(false, '非法操作', '/c/waimai_store2');return FALSE;
        }
        $this->load->model('waimai_order_model');

        $where = "site_id = '{$this->site_id}' AND store_id = {$store_id}";
        $search = array();
        $search['sear_type'] = $this->input->get('sear_type');
        $search['sear_keyword'] = $this->input->get('sear_keyword');
        $search['start_time'] = trim($this->input->get('start_time'));
        $search['end_time'] = trim($this->input->get('end_time'));
        $search['status'] = $this->input->get('status');
        $this->data['search'] = $search;

        if( $search['sear_keyword'] ){
            switch($search['sear_type']){
                case 1:
                    $where .= " AND name LIKE '%{$search['sear_keyword']}%'";
                    break;
                case 2:
                    $where .= " AND mobile LIKE '%{$search['sear_keyword']}%'";
                    break;
                case 3:
                    $where .= " AND order_sn LIKE '%{$search['sear_keyword']}%'";
                    break;
                default:;
            }
        }

        if( $search['start_time'] ){
            $where .= " AND add_time < ".strtotime($search['start_time']);
        }
        if( $search['end_time'] ){
            $where .= " AND add_time > ".strtotime($search['end_time']);
        }

        if( $search['status']!='' ){
            if( $search['status']==-2 ){
                $where .= " AND order_status IN (1,3)";
            }else{
                $where .= " AND order_status = {$search['status']}";
            }
        }

        $search_url = site_url($this->uri->uri_string().'?').http_build_query($search);

        if( $search ){
            $is_search = 1;
        }else{
            $is_search = 0;
        }
        $this->data['is_search'] = $is_search;

        $total_rows = $this->waimai_order_model->where($where)->order_by('waimai_order.id desc')->count();

        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$search_url));
        $list = $this->waimai_order_model->select('*')->where($where)->order_by('id desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->find_all();
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->load->view($this->dcm, $this->data);
    }

    /**
     * 订单导出
     */
    public function order_export()
    {
        $sid = $this->input->get_post('sid');
        $res = $this->get_store($sid);
        if( !$res ){
            $this->show_message(false, '非法操作', '/c/waimai_store2');return FALSE;
        }
        $this->load->model('waimai_order_model');

        $where = "site_id = '{$this->site_id}' AND store_id = {$sid}";
        $search = array();
        $search['sear_type'] = $this->input->get('sear_type');
        $search['sear_keyword'] = $this->input->get('sear_keyword');
        $search['start_time'] = trim($this->input->get('start_time'));
        $search['end_time'] = trim($this->input->get('end_time'));
        $search['status'] = $this->input->get('status');
        $this->data['search'] = $search;

        if( $search['sear_keyword'] ){
            switch($search['sear_type']){
                case 1:
                    $where .= " AND name LIKE '%{$search['sear_keyword']}%'";
                    break;
                case 2:
                    $where .= " AND mobile LIKE '%{$search['sear_keyword']}%'";
                    break;
                case 3:
                    $where .= " AND order_sn LIKE '%{$search['sear_keyword']}%'";
                    break;
                default:;
            }
        }

        if( $search['start_time'] ){
            $where .= " AND add_time < ".strtotime($search['start_time']);
        }
        if( $search['end_time'] ){
            $where .= " AND add_time > ".strtotime($search['end_time']);
        }

        if( $search['status']!='' ){
            if( $search['status']==-2 ){
                $where .= " AND order_status IN (1,3)";
            }else{
                $where .= " AND order_status = {$search['status']}";
            }
        }

        $orders = $this->waimai_order_model->select('*')->where($where)->order_by('id desc')->find_all();

        $orders = $orders ? $orders : array();
        $order_status = $this->order_status_list;
        foreach($orders as &$order) {
            $order['add_time'] = date('Y-m-d H:i:s', $order['add_time']);
            $order['pay_time'] = $order['pay_time'] ? date('Y-m-d H:i:s', $order['pay_time']) : '';
            $order['status_name'] = $order_status[$order['order_status']];
            switch( $order['origin'] ){
                case 'wechat':
                    $order['origin'] = '微信';
                    break;
                case 'fuwuchuang':
                    $order['origin'] = '服务窗';
                    break;
                default:;
            }

            //订单菜品
            $this->load->model('waimai_order_dishes_model');
            $item_list = $this->waimai_order_dishes_model->where(array('site_id'=>$this->site_id,'order_id'=>$order['id']))->find_all();

            $items = '';
            foreach($item_list as $item) {
                $items .= "菜品：".$item['dishes_name'].", 单价：".$item['dishes_price'].", 数量：".$item['dishes_num']."; ";
            }
            $items = $items ? $items : '尚无订单商品';
            $order['items'] = $items;

            //联系人信息
            if( !$order['name'] ){
                $this->load->model('waimai_address_model');
                $address = $this->waimai_address_model->where(array('site_id'=>$this->site_id,'id'=>$order['address_id']))->find();
                if( !$address ){
                    $order['name'] = $order['mobile'] = $order['address'] = '';
                }
            }
        }

        $fields = array(
            '#'=>'#',
            'order_sn'=>'订单号',
            'mobile'=>'收货人手机号',
            'name'=>'收货人姓名',
            'address' => '收货人地址',
            'all_price'=>'总价',
            'add_time'=>'订单时间',
            'reach_time' => '送餐时间',
            'origin'=>'订单来源',
            'status_name'=>'订单状态',
            'pay_time'=>'付款时间',
            'payment_name'=>'支付方式',
            'items'=>'订单商品',
            'mark'=>'用户备注',
            'cmark'=>'商家备注'
        );

        $this->excel_export($this->data['store']['address'].'订单列表', '订单列表', $fields, $orders);
    }

    //获取外卖配置
    private function get_config()
    {
        $where = array(
            'site_id' => $this->site_id
        );
        $waimai = $this->waimai_model->where($where)->find();
        $waimai = $waimai ? $waimai : array();
        $this->data['waimai'] = $waimai;
        return $waimai;
    }

    //获得一个订单详情
    private function get_one_order_info($id)
    {
        $where = array(
            'waimai_order.site_id'  => $this->site_id,
            'waimai_order.id' => $id
        );
        $orderDetail = $this->waimai_order_model
            ->select('waimai_order.*,waimai_store.address as store_address')
            ->join('waimai_store','waimai_order.store_id=waimai_store.id')
            ->where($where)->find();
        if(!$orderDetail)
        {
            return false;
        }
        else
        {
            return $orderDetail;
        }
    }
    //检查图片格式
    public function _check_image($image) {
        if ($image) {
            if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
                $this->form_validation->set_message('_check_image', '图片地址格式错误');
                return FALSE;
            }
        }
        return TRUE;
    }

    /**
     * 库存为0的菜品下架
     */
    private function xiajia($sid)
    {
        $this->load->model('waimai_dishes_model');
        $this->waimai_dishes_model->where(array('sid'=>$sid,'stock_set'=>1,'stock'=>0))->edit(array('publish'=>0));
    }

    //TODO
    public function exchange_data()
    {
        $list = $this->model
            ->select('waimai_store.id,waimai_store.range,address.name as add_name,address.lng,address.lat')
            ->join('address','address.id=waimai_store.address_id')
            ->find_all();
        foreach( $list as $val ){
            $range_content = array(
                'radius' => $val['range'],
                'point'  => array(
                    'lng' => $val['lng'],
                    'lat' => $val['lat']
                )
            );
            $range_content = json_encode($range_content);
            $this->model->where(array('id'=>$val['id']))->edit(array('range_content'=>$range_content));
        }
        exit('转换over！！！');
    }

} 