<?php
/**
 * Created by PhpStorm.
 * User: along
 * Date: 14-8-15
 * Time: 上午11:58
 * @property oauth_client_cate_model $oauth_client_cate_model
 * @property oauth_client_model $oauth_client_model
 * @property site_client_model $site_client_model
 * @property client_order_model $client_order_model
 * @property developer_model $developer_model
 */

class Open_platform extends C_Controller{

    protected $data = array();


    public function __construct()
    {
        parent::__construct();
        $this->load->model('oauth_client_model');
        //应用分类
        $this->load->model('oauth_client_cate_model');
        $this->load->model('site_client_model');
        $this->load->model('client_order_model');
    }

    /**
     * 应用列表
     */
    public function index()
    {
        $where['status'] = 2;
        $where['deleted'] = 0;
        $where['online'] = 1;

        $search_url = site_url($this->uri->uri_string().'?');

        $c = intval($this->input->get('c',true));
        if($c)
        {
            $where['cate_id'] = $c;
            $search_url .= 'c='.$c;
        }


        //print_r($where);
        $fields = 'id,cate_id,developer_id,name,type,intro,icon,app_img,day_limit,cuser,user_price,trial_day,dt_add,unit,cbaseuser,tag,is_free,free_limit';

        $this->data['client_cate'] = $this->oauth_client_cate_model->get_all_cate(array());
        //每页9条

        $total_rows = $this->oauth_client_model->get_total($where);
        $pager = $this->_pager($total_rows, array('per_page'=>9,'base_url'=>$search_url));

        $this->data['oauth_client'] = $this->oauth_client_model->get_client_list($where,$fields,$pager['limit']['value'],$pager['limit']['offset']);

        $this->data['page'] = $pager['links'];
        $this->data['c'] = $c;

        $this->load->view($this->dcm,$this->data);
    }

    /**
     * 应用详情
     * @return bool
     */
    public function detail()
    {
        $id = intval($this->input->get('id',true));
        $detail = $this->get_one_client($id);

        if($detail)
        {
            //分类名
            $client_cate = $this->oauth_client_cate_model->get_all_cate(array('id'=>$detail['cate_id']));

            $detail['cate_name'] = $client_cate[$detail['cate_id']]['name'];

            $detail['user_price'] = json_decode($detail['user_price'],true);
            //print_r($detail);
            $this->data['client'] = $detail;

            $site_client_result = $this->site_client_model->where(array('site_id'=>$this->site_info['id'],'client_id'=>$id))->find();

            //print_r($site_client_result);
            if(!$site_client_result)
            {
                //是否可以试用
                if($detail['trial_day'] > 0 && $detail['is_free'] !=1)
                {
                    $this->data['trial_status'] = 1;
                }
                //是否可以免费开通
                if($detail['is_free'] == 1)
                {
                    $this->data['free_status'] = 1;
                }

                //根据价格判断是否可以免费开通
                if(is_array($detail['user_price']))
                {
                    foreach($detail['user_price'] as $price)
                    {
                        if(isset($price['month']) && $price['month']==0 && isset($price['year']) && $price['year']==0)
                        {
                            $this->data['free_status'] = 1;
                        }
                    }
                }
                //没设置免费，也没有设置价格的情况下，免费
                if($detail['is_free'] !=1 && !$detail['user_price'])
                {
                    $this->data['free_status'] = 1;
                }
                //是否在审核中
                if(!isset($this->data['free_status']))
                {
                    $order_where = array('site_id'=>$this->site_info['id'],'client_id'=>$detail['id'],'type > '=>0);
                    $client_order_result = $this->client_order_model->where($order_where)->find();
                    //如果有订单记录，则已经提交过购买申请，订单处于审核期
                    if($client_order_result)
                    {
                        if($client_order_result['pay_status'] == 0)
                        {
                            $this->data['pay_status'] = 1;
                        }
                    }
                    else
                    {
                        $this->data['buy_status'] = 1;
                    }
                }
            }
            else
            {
                //试用
                if($site_client_result['type'] == 0)
                {
                    //试用状态下是否有购买申请
                    $trial_order_where = array('site_id'=>$this->site_info['id'],'client_id'=>$detail['id'],'type >= '=>1);
                    $client_order = $this->client_order_model->where($trial_order_where)->find();

                    if($client_order)
                    {
                        //购买申请中
                        $this->data['pay_status'] = 1;
                    }
                    else
                    {
                        //可购买
                        $this->data['buy_status'] = 1;
                    }
                    //试用中
                    $this->data['open_trial_status'] = 1;
                }
                else
                {
                    //已购买
                    $this->data['open_buy_status'] = 1;
                }
            }

            //$this->data['_client'] = $client_order_result['type'];

            $this->data['developer'] = array();
            if($detail['developer_id'])
            {
                //开发者信息
                $this->load->model('developer_model');
                $developer = $this->developer_model->where(array('id'=>$detail['developer_id']))->find();
                if($developer['province'])
                {
                    $this->load->model('region_model');
                    $province = $this->region_model->select('region_name')->where(array('id'=>$developer['province']))->find();
                    $developer['prov'] = $province['region_name'];

                    if($developer['city'])
                    {
                        $city = $this->region_model->select('region_name')->where(array('id'=>$developer['city']))->find();
                        $developer['city_name'] = $city['region_name'];
                    }
                }

                $this->data['developer'] = $developer;
                //print_r($this->data['developer']);
                //该开发者的其他应用
                $orther_where = array('developer_id'=>$detail['developer_id'],'status'=>2,'deleted'=>0,'id != '=>$detail['id']);
                $this->data['orther_client'] = $this->oauth_client_model->get_client_list($orther_where,'id,name,icon,app_img',5);
            }

            //代理商信息
            $this->data['agent_info'] = array('company'=>'','mobile'=>'');
            if($this->site_info['agent_id'])
            {
                $this->load->model('agent_model');
                $this->data['agent_info'] = $this->agent_model->select('company,mobile')->where(array('id'=>$this->site_info['agent_id']))->find();
            }
            $this->load->view($this->dcm,$this->data);
        }
    }

    /**
     * 免费开通
     */
    public function free_open()
    {

        $id = intval($this->input->post('id',true));
        $client_info = $this->get_one_client($id);

        if($client_info['is_free'] != 1)
        {
            $this->ajax_return(array('ret'=>202,'msg'=>'对不起，该应用不支持免费使用'));
        }

        //是否已购买
        $site_client = $this->client_order_model->where(array('site_id'=>$this->site_info['id'],'client_id'=>$client_info['id']))->find();

        if($site_client)
        {
            $this->ajax_return(array('ret'=>203,'msg'=>'您已免费开通了此应用'));
        }
        //增加到订单表
        $order_data = $this->comb_order_data($client_info);

        //金额
        $order_data['amount'] = 0;
        $order_data['type'] = 3;

        $order_data['cmonth'] = $client_info['free_limit'];
        $order_data['pay_status'] = 1;
        $order_data['dt_done'] = $order_data['dt_add'];

        if($this->client_order_model->add($order_data))
        {
            //开通
            $savedata['client_id'] = $client_info['id'];
            $savedata['site_id'] = $this->site_info['id'];
            //结束时间
            $savedata['expires'] = $client_info['free_limit']>0 ? time()+$client_info['free_limit']*30*86400 : 0;
            $savedata['type'] = 2;
            if($this->site_client_model->add($savedata))
            {
                //更新用户数
                $this->oauth_client_model->set_inc('cuser',$client_info['id']);
                $this->ajax_return(array('ret'=>0,'msg'=>'恭喜您，应用已经免费开通了，赶紧去体验一下吧'));
            }
            else
            {
                $this->ajax_return(array('ret'=>209,'msg'=>'开通失败'));
            }
        }
        else
        {
            $this->ajax_return(array('ret'=>208,'msg'=>'订单创建失败'));
        }
    }


    /**
     * 购买
     */
    public function buy()
    {

        $id = intval($this->input->post('id',true));
        $client_info = $this->get_one_client($id);

        $expires = intval($this->input->post('expires',true));
        if($expires <1)
        {
            $this->ajax_return(array('ret'=>201,'msg'=>'购买期限请大于1'));
        }
        //是否已购买
        $client_order = $this->client_order_model
                             ->where(array('site_id'=>$this->site_info['id'],'client_id'=>$client_info['id'],'type > '=>0))
                             ->find();

        if($client_order)
        {
            $this->ajax_return(array('ret'=>203,'msg'=>'您已购买该应用，请不要重复购买'));
        }

        //计算金额
        $price_type = $this->input->post('price_type',true);
        if(!$price_type)
        {
            $this->ajax_return(array('ret'=>204,'msg'=>'购买方式非法'));
        }
        $user_price = json_decode($client_info['user_price'],true);
        $amount = $cmonth = 0;
        //按年购买
        if($price_type == 1 && isset($user_price['year']) && $user_price['year'])
        {
            $amount = $expires*$user_price['year'];
            $cmonth = $expires*12;
        }
        elseif($price_type == 2 && isset($user_price['month']) && $user_price['month'])
        {
            $amount = $expires*$user_price['month'];
            $cmonth = $expires;
        }

        //是否有试用订单
        $trial_order = $this->client_order_model
                            ->where(array('site_id'=>$this->site_info['id'],'client_id'=>$client_info['id'],'type'=>0))
                            ->find();
        //更新订单 试用转正
        if($trial_order)
        {
            $editdata = array(
                'type' => 2,
                'amount' => $amount,
                'cmonth' => $cmonth,
                'dt_positive'=>time()
            );
            $result = $this->client_order_model->where(array('id'=>$trial_order['id']))->edit($editdata);
        }
        else
        {
            //组装订单表数据
            $order_data = $this->comb_order_data($client_info);

            $order_data['amount'] = $amount;
            $order_data['cmonth'] = $cmonth;
            //正式订单
            $order_data['type'] = 1;
            $order_data['pay_status'] = 0;
            $order_data['dt_done'] = 0;
            $result = $this->client_order_model->add($order_data);
        }
        if($result)
        {
            $this->ajax_return(array('ret'=>0,'msg'=>'您的购买申请已提交成功!'));
        }
        else
        {
            $this->ajax_return(array('ret'=>208,'msg'=>'订单创建失败'));
        }
    }

    /**
     * 试用
     */
    public function trial()
    {
        //是否已经申请试用过了,并用已经购买过了
        $id = intval($this->input->post('id',true));
        $client_info = $this->get_one_client($id);

        if($client_info['trial_day'] <= 0)
        {
            $this->ajax_return(array('ret'=>201,'msg'=>'该应用不支持试用！'));
        }
        //是否已申请试用或已购买
        $client_order = $this->site_client_model->where(array('site_id'=>$this->site_info['id'],'client_id'=>$client_info['id']))->find();
        if($client_order)
        {
            $this->ajax_return(array('ret'=>202,'msg'=>'您已经申请或已购买此应用,请不要重复申请'));
        }
        $this->load->model('client_order_model');
        //增加到订单表
        $order_data = $this->comb_order_data($client_info);

        //计算金额
        $order_data['amount'] = 0;

        $order_data['type'] = 0;

        $order_data['cmonth'] = '';
        $order_data['pay_status'] = 0;
        $order_data['dt_done'] = $order_data['dt_add'];

        if($this->client_order_model->add($order_data))
        {
            $savedata['expires'] = time()+$client_info['trial_day']*86400;
            $savedata['type'] = 0;
            $savedata['client_id'] = $client_info['id'];
            $savedata['site_id'] = $this->site_info['id'];
            if($this->site_client_model->add($savedata))
            {
                //更新用户数
                $this->oauth_client_model->set_inc('cuser',$client_info['id']);
                $this->ajax_return(array('ret'=>0,'msg'=>'试用成功，赶紧去体验一下吧'));
            }
            else
            {
                $this->ajax_return(array('ret'=>205,'msg'=>'试用申请失败！'));
            }
        }
        else
        {
            $this->ajax_return(array('ret'=>208,'msg'=>'订单创建失败'));
        }
    }

    /**
     * 获取一个应用详情
     * @param $id
     * @param int $ajax
     * @return bool
     */
    private function get_one_client($id,$ajax=0)
    {
        if(!$id)
        {
            if($ajax == 1){
                $this->ajax_return(array('ret'=>101,'msg'=>'缺少参数'));
            }
            else
            {
                $this->show_message(false, '缺少参数', '/c/open_platform');return FALSE;
            }
        }

        $detail = $this->oauth_client_model->where(array('id'=>$id))->find();
        if(!$detail)
        {
            if($ajax == 1)
            {
                $this->ajax_return(array('ret'=>102,'msg'=>'该应用不存在'));
            }
            else
            {
                $this->show_message(false, '该应用不存在', '/c/open_platform');return FALSE;
            }
        }

        if($detail['online'] != 1)
        {
            if($ajax == 1)
            {
                $this->ajax_return(array('ret'=>104,'msg'=>'该应用未上架'));
            }
            else
            {
                $this->show_message(false, '该应用未上架', '/c/open_platform');return false;
            }
        }
        //是否删除，未审核
        if($detail['deleted'] == 1 || $detail['status']!=2)
        {
            if($ajax == 1)
            {
                $this->ajax_return(array('ret'=>103,'msg'=>'应用未审核或已删除'));
            }
            else
            {
                $this->show_message(false, '应用未审核或已删除', '/c/open_platform');return FALSE;
            }
        }
        return $detail;
    }

    /**
     * 组装共用订单数据
     * @param $client_info
     * @return mixed
     */
    private function comb_order_data($client_info)
    {
        $order_data['client_id'] = $client_info['id'];
        $order_data['client_name'] = $client_info['name'];

        //开发者信息
        $this->load->model('developer_model');

        $developer = $this->developer_model->where(array('id'=>$client_info['developer_id']))->find();

        $order_data['developer_id'] = $developer['id'];
        $order_data['developer_name'] = $developer['company'];

        //代理商信息
        if($this->site_info['agent_id'])
        {
            $this->load->model('agent_model');
            $agentInfo = $this->agent_model->select('id,company,level')->where(array('id'=>$this->site_info['agent_id']))->find();
        }
        $order_data['agent_id'] = isset($agentInfo['id']) ? $agentInfo['id'] : '';
        $order_data['agent_company'] = isset($agentInfo['company']) ? $agentInfo['company'] : '';
        $order_data['agent_username'] = '';
        $order_data['agent_level'] = isset($agentInfo['level']) ? $agentInfo['level'] : '';

        //站点信息
        $order_data['site_id'] = $this->site_info['id'];
        $order_data['site_name'] = $this->site_info['username'];

        //订单号
        $order_data['trade_no'] = $this->_order_sn();

        $order_data['dt_add'] = time();
        return $order_data;
    }


    /**
     * 生成订单号
     * @return string
     */
    protected function _order_sn()
    {
        $trade_no = date('ymdhis').str_pad(mt_rand(1, 99999), 5, '0', STR_PAD_LEFT);  //订单号
        if(!$this->client_order_model->where(array('trade_no'=>$trade_no))->count()) {
            return $trade_no;
        } else {
            return $this->_order_sn();
        }
    }
}