<?php

/**
 * 会员卡特权 和特权分组
 * 函数里面的 show_message函数 无法真正的退出TODO
 * 
 */
class Mcard_priv extends C_Controller {
    
    
    private $wid = '';
    
    public function __construct()
    {
        parent::__construct();
        
        $this->wid = $this->site_info['id'];
        
        $this->load->model('mcard_priv_model');
        $this->load->model('mcard_priv_level_model');
        $this->load->model('mcard_group_model');
        
        $this->mcard_priv_model->where(array('site_id'=>$this->wid,'time_range'=>1,'end_time <'=>time()))->edit(array('status'=>1));
        
    }
    
    
    //特权列表
    public function index()
    {
        if( !$this->check_mcard() ){
            return false;
        }
        
        $where = array(
            'mcard_priv.site_id' => $this->wid
        );
        $total_rows = $this->mcard_priv_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15));
        $list = $this->mcard_priv_model
                ->select('mcard_priv.*,mcard_group.name as group_name')
                ->join('mcard_group','mcard_group.id=mcard_priv.group_id')
                ->order_by('mcard_priv.id asc')
                ->limit($pager['limit']['value'], $pager['limit']['offset'])
                ->where($where)->find_all();
        
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        
        $this->load->view($this->dcm, $this->data);
    }
    
    //添加特权
    public function add()
    {
        if( !$this->check_mcard() ){
            return false;
        }
        
        if( $this->input->post() ){
            $this->load->library('form_validation');
            $this->form_validation->set_rules('name', '特权名称', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('time_range', '时间范围', 'trim|required');
            $this->form_validation->set_rules('group_id', '特权名称', 'trim|required');
            $this->form_validation->set_rules('intro', '特权说明', 'trim|max_length[200]|htmlspecialchars');
            if ( $this->form_validation->run() ) {
                $save_data['site_id'] = $this->site_info['id'];
                $save_data['name'] = $this->form_validation->set_value('name');
                $save_data['time_range'] = $this->form_validation->set_value('time_range');
                $save_data['group_id'] = $this->form_validation->set_value('group_id');
                $save_data['intro'] = $this->form_validation->set_value('intro');
                $save_data['add_time'] = time();
                
                //时间范围
                if( $save_data['time_range']==1 ){
                    $start_time = trim($this->input->post('start_time'));
                    if( !$start_time ){
                        $this->show_message(false, '请填写开始时间', '',1);return FALSE;
                    }
                    $end_time = trim($this->input->post('end_time'));
                    if( !$end_time ){
                        $this->show_message(false, '请填写结束时间', '',1);return FALSE;
                    }
                    $start_time = strtotime($start_time);
                    $end_time = strtotime($end_time);
                    if( $end_time<=$start_time ){
                        $this->show_message(false, '结束时间必须大于开始时间', '',1);return FALSE;
                    }
                    $save_data['start_time'] = $start_time;
                    $save_data['end_time'] = $end_time;
                }
                
                //适用门店
                $save_data['address_ids'] = '';
                $address_ids = $this->input->post('address_ids');
                if( $address_ids ){
                    $save_data['address_ids'] = implode(',', $address_ids);
                }else{
                    $this->show_message(false, '请选择适用门店', '',1);return FALSE;
                }
                
                //特权等级 范围
                $level_ids = $this->input->post('level_ids');
                if( !$level_ids ){
                    $this->show_message(false, '请选择特权范围', '',1);return FALSE;
                }
                
                //添加数据
                if( $priv_id=$this->mcard_priv_model->add($save_data) ){
                    //保存特权等级范围
                    foreach( $level_ids as $val ){
                        $this->mcard_priv_level_model->add( array('priv_id'=>$priv_id,'level_id'=>$val) );
                    }
                    $this->show_message(true, '添加成功', '/c/mcard_priv/index');return FALSE;
                }else{
                    $this->show_message(false, '添加失败', '',1);return FALSE;
                }
                
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            if( !$this->group_list() ){//分组列表
                $this->show_message(false, '请先添加特权分组', '/c/mcard_priv/group_add');return FALSE;
            }
            
            if( !$this->address_list() ){//地址列表
                $this->show_message(false, '请先设置适用门店', '/c/mcard/index');return FALSE;
            }
            
            if( !$this->level_list() ){//会员卡等级列表
                $this->show_message(false, '请先设置特权等级', '/c/mcard_level/index');return FALSE;
            }
            
            $this->load->view($this->dcm, $this->data);
        }
    }
    
    //修改特权
    public function update($priv_id='')
    {
        if( !$this->check_mcard() ){
            return false;
        }
        
        $where = array(
            'site_id' => $this->wid,
            'id' => $priv_id
        );
        $mcard_priv = $this->mcard_priv_model->where($where)->find();
        if( !$mcard_priv ){
            return $this->show_message(false, '非法参数', '/c/mcard_priv/index');
        }
        $levels = $this->mcard_priv_level_model->where(array('priv_id'=>$priv_id))->find_all();
        
        if( $this->input->post() ){
            $this->load->library('form_validation');
            $this->form_validation->set_rules('name', '特权名称', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('time_range', '时间范围', 'trim|required');
            $this->form_validation->set_rules('group_id', '特权名称', 'trim|required');
            $this->form_validation->set_rules('intro', '特权说明', 'trim|max_length[200]|htmlspecialchars');
            if ( $this->form_validation->run() ) {
                $save_data['site_id'] = $this->site_info['id'];
                $save_data['name'] = $this->form_validation->set_value('name');
                $save_data['time_range'] = $this->form_validation->set_value('time_range');
                $save_data['group_id'] = $this->form_validation->set_value('group_id');
                $save_data['intro'] = $this->form_validation->set_value('intro');
                $save_data['add_time'] = time();
                
                //时间范围
                if( $save_data['time_range']==1 ){
                    $start_time = trim($this->input->post('start_time'));
                    if( !$start_time ){
                        $this->show_message(false, '请填写开始时间', '',1);return FALSE;
                    }
                    $end_time = trim($this->input->post('end_time'));
                    if( !$end_time ){
                        $this->show_message(false, '请填写结束时间', '',1);return FALSE;
                    }
                    $start_time = strtotime($start_time);
                    $end_time = strtotime($end_time);
                    $save_data['start_time'] = $start_time;
                    $save_data['end_time'] = $end_time;
                }
                
                //适用门店
                $save_data['address_ids'] = '';
                $address_ids = $this->input->post('address_ids');
                if( $address_ids ){
                    $save_data['address_ids'] = implode(',', $address_ids);
                }else{
                    $this->show_message(false, '请选择适用门店', '',1);return FALSE;
                }
                
                //特权等级 范围
                $level_ids = $this->input->post('level_ids');
                if( !$level_ids ){
                    $this->show_message(false, '请选择特权范围', '',1);return FALSE;
                }
                
                //添加数据
                if( $this->mcard_priv_model->where($where)->edit($save_data) ){
                    //保存特权等级范围
                    $temp1_levels = array();
                    foreach( $levels as $val ){
                        $temp1_levels[] = $val['level_id'];
                    }
                    
                    foreach( $level_ids as $key1=>$val1 ){//比对该删还是修改
                        foreach( $temp1_levels as $key2=>$val2 ){
                            if( $val2==$val1 ){
                                unset($level_ids[$key1]);
                                unset($temp1_levels[$key2]);
                            }
                        }
                    }
                    
                    if( $temp1_levels ){//删除多余的
                        foreach( $temp1_levels as $val ){
                            $this->mcard_priv_level_model->where(array('priv_id'=>$priv_id,'level_id'=>$val))->delete();
                        }
                    }
                    if( $level_ids ){//增加没有的
                        foreach( $level_ids as $val ){
                            $this->mcard_priv_level_model->add( array('priv_id'=>$priv_id,'level_id'=>$val) );
                        }
                    }
                    
                    $this->show_message(true, '修改成功', '/c/mcard_priv/index');return FALSE;
                }else{
                    $this->show_message(false, '修改失败', '',1);return FALSE;
                }
                
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            if( !$this->group_list() ){//分组列表
                $this->show_message(false, '请先添加特权分组', '/c/mcard_priv/group_add');return FALSE;
            }
            
            if( !$this->address_list() ){//地址列表
                $this->show_message(false, '请先设置适用门店', '/c/mcard/index');return FALSE;
            }
            
            if( !$this->level_list() ){//会员卡等级列表
                $this->show_message(false, '请先设置特权等级', '/c/mcard_level/index');return FALSE;
            }
            
            $mcard_priv['address_id'] = explode(',', $mcard_priv['address_ids']);
            $this->data['priv']   = $mcard_priv;
            $this->data['levels'] = $levels;
            
            $this->load->view($this->dcm, $this->data);
        }
    }
    
    //删除特权
    public function delete($priv_id='')
    {
        if( !$this->check_mcard() ){
            return false;
        }
        
        $where = array(
            'site_id' => $this->wid,
            'id' => $priv_id
        );
        $mcard_priv = $this->mcard_priv_model->where($where)->find();
        if( !$mcard_priv ){
            return $this->show_message(false, '非法参数', '/c/mcard_priv/index');
        }
        $levels = $this->mcard_priv_level_model->where(array('priv_id'=>$priv_id))->find_all();
        
        if( $this->mcard_priv_level_model->where(array('priv_id'=>$priv_id))->delete() ){
            if( $this->mcard_priv_model->where($where)->delete() ){
                $this->show_message(false, '删除成功', '/c/mcard_priv/index');return false;
            }
        }
        $this->show_message(false, '删除失败', '/c/mcard_priv/index');return false;
    }
    
    
/**************************分组*****************************/
    
    //特权分组
    public function group_index()
    {
        if( !$this->check_mcard() ){
            return false;
        }
        
        $where = array(
            'site_id' => $this->wid
        );
        
        $total_rows = $this->mcard_group_model->where(array('site_id' => $this->wid))->count();
        if( !$total_rows ){
            $this->proup_default();
        }
        
        $total_rows = $this->mcard_group_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15));
        $list = $this->mcard_group_model->order_by('id asc')
                ->limit($pager['limit']['value'], $pager['limit']['offset'])
                ->where($where)->find_all();
        
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        
        $this->load->view($this->dcm, $this->data);
    }
    
    //添加默认分组
    private function proup_default()
    {
        $save_data = array(
            'site_id' => $this->wid,
            'name'    => '默认',
            'type'    => 0
        );
        $this->mcard_group_model->add($save_data);
    }
    
    //添加特权分组
    public function group_add()
    {
        if( !$this->check_mcard() ){
            return false;
        }
        
        $total_rows = $this->mcard_group_model->where(array('site_id' => $this->wid))->count();
        if( !$total_rows ){
            $this->proup_default();
        }
        
        if( $this->input->post() ){
            $name = trim($this->input->post('name'));
            if( !$name ){
                $this->show_message(false, '特权分组名称必须填写', '',1);
                return FALSE;
            }
            if( strlen($name)>50 ){
                $this->show_message(false, '分组名称不能超过50个字', '',1);
                return FALSE;
            }
            if( !$this->mcard_group_model->check_name($this->wid,$name) ){
                $this->show_message(false, '该分组已存在', '',1);
                return FALSE;
            }
            
            if( $id=$this->mcard_group_model->add(array('site_id'=>$this->wid,'name'=>$name)) ){
                $this->show_message(true, '添加成功', '/c/mcard_priv/group_index');return false;
            }else{
                $this->show_message(false, '分组添加失败', '',1);return false;
            }
        }
        
        $this->load->view($this->dcm, $this->data);
    }
    
    //修改特权分组
    public function group_update($group_id='')
    {
        if( !$this->check_mcard() ){
            return false;
        }
        
        $total_rows = $this->mcard_group_model->where(array('site_id' => $this->wid))->count();
        if( !$total_rows ){
            $this->proup_default();
        }
        
        $group = $this->mcard_group_model->where(array('site_id' => $this->wid,'id'=>$group_id))->find();
        if( !$group || $group['type']==0 ){
            $this->show_message(false, '非法操作', '',1);return FALSE;
        }
        
        if( $this->input->post() ){
            $name = trim($this->input->post('name'));
            if( !$name ){
                $this->show_message(false, '特权分组名称必须填写', '',1);
                return FALSE;
            }
            if( strlen($name)>50 ){
                $this->show_message(false, '分组名称不能超过50个字', '',1);
                return FALSE;
            }
            if( !$this->mcard_group_model->check_name($this->wid,$name) ){
                $this->show_message(false, '该分组已存在', '',1);
                return FALSE;
            }
            $save_data = array(
                'name' => $name,
                'type' => 1
            );
            if( false===$this->mcard_group_model->where(array('site_id' => $this->wid,'id'=>$group_id))->edit($save_data) ){
                $this->show_message(false, '分组修改失败', '',1);return false;
            }
            $this->show_message(true, '分组修改成功', '/c/mcard_priv/group_index');return false;
        }
        
        $this->data['info'] = $group;
        $this->load->view($this->dcm, $this->data);
    }
    
    //删除特权分组
    public function group_delete($group_id='')
    {
        if( !$this->check_mcard() ){
            return false;
        }
        
        $total_rows = $this->mcard_group_model->where(array('site_id' => $this->wid))->count();
        if( !$total_rows ){
            $this->proup_default();
        }
        
        $group = $this->mcard_group_model->where(array('site_id' => $this->wid,'id'=>$group_id))->find();
        if( !$group || $group['type']==0 ){
            $this->show_message(false, '非法操作', '',1);return FALSE;
        }
        
        if( $this->mcard_group_model->where(array('site_id' => $this->wid,'id'=>$group_id))->delete() ){
            $this->show_message(true, '分组删除成功', '/c/mcard_priv/group_index');return false;
        }else{
            $this->show_message(false, '分组删除失败', '/c/mcard_priv/group_index');return false;
        }
    }
    
    //获取特权分组列表
    private function group_list()
    {
        $where = array(
            'site_id' => $this->wid
        );
        $total_rows = $this->mcard_group_model->where(array('site_id' => $this->wid))->count();
        if( !$total_rows ){
            $this->proup_default();
        }
        
        $list = $this->mcard_group_model->order_by('id asc')
                ->where($where)->find_all();
        $this->data['group_list'] = $list;
        return $list;
    }
    
/********************************************/
    
    //会员等级列表
    private function level_list()
    {
        $where = array(
            'site_id' => $this->wid,
            'status' => 1
        );
        $this->load->model('mcard_level_model');
        $list = $this->mcard_level_model->where($where)->find_all();
        
        $this->data['level_list'] = $list;
        return $list;
    }
    
    //会员卡门店列表   返回  关联id 和地址名
    private function address_list()
    {
        $where = array(
            'mcard_address.site_id' => $this->wid
        );
        $this->load->model('mcard_address_model');
        $res = $this->mcard_address_model
               ->select('mcard_address.id,address.name')
               ->join('address','address.id=mcard_address.address_id')
               ->where($where)->find_all();
        return $this->data['address_list'] = $res;
    }
    
    
    //检查会员卡是否存在
    public function check_mcard()
    {
        $this->load->model('mcard_model');
        $mcard = $this->mcard_model->where(array('site_id'=>$this->site_info['id']))->find();
        if(!$mcard) {
            return $this->show_message(FALSE, '会员卡不存在，请先去设置', '/c/mcard/index');
        }
        return true;
    }
    
    
}