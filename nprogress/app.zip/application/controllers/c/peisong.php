<?php
/**
 * 配送设置
 */

class Peisong extends C_Controller {

    protected $auto_load_model = TRUE;
    protected $model_name = 'peisong';
    
    protected $data = '';
    
    private $site_id = '';
    
    public function __construct()
    {
        parent::__construct();
        
        $this->site_id = $this->site_info['id'];
    }
    
    public function index()
    {
        $peisong = $this->get_config();
        $base_url = '';
        if( $this->data['peisong'] ){
            $base_url = 'http://'.$this->site_info['domain'].BASE_DOMAIN.'/peisong';
            if( $this->data['peisong']['type']==2 ){
                $this->data['peisong']['required_fields'] = explode(',', $this->data['peisong']['required_fields']);
            }
        }

        $this->data['base_url'] = $base_url;
        
        if( $this->input->post() ){
            $this->form_validation->set_rules('title', '配送标题', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('status', '是否开启', 'trim|intval');
            $this->form_validation->set_rules('title_img', '配送标题图', 'trim|callback__check_image');
            $this->form_validation->set_rules('type', '使用条件', 'trim|intval');
            $this->form_validation->set_rules('show_img', '宣传图', 'trim|callback__check_image');
            $this->form_validation->set_rules('tpl', '模版选择', 'trim');
            $this->form_validation->set_rules('required_mobile', '手机', 'trim|intval');
            $this->form_validation->set_rules('required_name', '姓名', 'trim|intval');
            if ( $this->form_validation->run() ){
                
                $save_data['status'] = $this->form_validation->set_value('status');
                $save_data['title'] = $this->form_validation->set_value('title');
                $save_data['title_img'] = $this->form_validation->set_value('title_img');
                $save_data['type'] = $this->form_validation->set_value('type');
                $save_data['show_img'] = $this->form_validation->set_value('show_img');
                $save_data['tpl'] = $this->form_validation->set_value('tpl');
                
                if( $save_data['type']==2 ){
                    //完善信息部分
                    $required_name = intval($this->input->post('required_name'));
                    $save_data['required_name'] = $required_name;
                    $required_mobile = intval($this->input->post('required_mobile'));
                    $save_data['required_mobile'] = $required_mobile;
                    $required_fields = $this->input->post('required_fields') ? $this->input->post('required_fields') : array();
                    $save_data['required_fields'] = implode(',', $required_fields);
                    if( !$required_name&&!$required_mobile&&!$save_data['required_fields'] ){
                        $this->show_message(false, '请选择需完善信息项', '',1);return FALSE;
                    }
                }
                
                $save_data['site_id'] = $this->site_id;
                
                if( $this->data['peisong'] ){
                    if( $this->model->where(array('site_id'=>$this->site_id))->edit($save_data) ){
                        $this->show_message(true, '保存成功', '/c/peisong/index');return FALSE;
                    }else{
                        $this->show_message(false, '保存失败', '/c/peisong/index');return FALSE;
                    }
                }else{//添加
                    $save_data['add_time'] = time();
                    if( $this->model->add($save_data) ){
                        $this->show_message(true, '保存成功', '/c/peisong/index');return FALSE;
                    }else{
                        $this->show_message(false, '保存失败', '/c/peisong/index');return FALSE;
                    }
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            //需完善信息项
            $this->load->library('Mongo_db');
            $field_list = $this->mongo_db->where(array('wid'=>$this->site_info['id']))->order_by(array('sort', 'ASC'))->get('account_fields');
            $this->data['field_list'] = $field_list;
            
            //获取模版
            $this->load->config('tpl');
            $config_tpl = $this->config->item('peisong_tpl');
            $this->data['peisong_tpl'] = $config_tpl;
            
            $this->load->view($this->dcm, $this->data);
        }
    }

    public function tongji()
    {
        $search['sear_starttime'] = $this->input->get('sear_starttime');
        $search['sear_endtime'] = $this->input->get('sear_endtime');

        $this->data['search'] = $search;

        $this->load->model('peisong_order_statistics_model');
        $search_url = '/c/peisong/tongji/?';
        $where = array(
            'site_id' => $this->site_id,
        );
        $search_url = '/c/peisong/store_tongji/?';
        $where = array(
            'site_id' => $this->site_id,
        );
        if($search['sear_starttime'])
        {
            $where['add_time >='] = strtotime($search['sear_starttime']);
            $search_url .= '&sear_starttime='.$search['sear_starttime'];
        }

        if($search['sear_endtime'])
        {
            $where['add_time <='] = strtotime($search['sear_endtime']);
            $search_url .= '&sear_endtime='.$search['sear_endtime'];
        }

        $total_rows = $this->peisong_order_statistics_model->where($where)->group_by('add_time')->count();

        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$search_url));
        $this->data['page'] = $pager['links'];

        $list = $this->peisong_order_statistics_model
            ->select('add_time,SUM(total_order) as total_order_num, SUM(valid_order) as valid_order_num,SUM(invalid_order) as invalid_order_num,SUM(total_price) as total_price,AVG(avg_price) as avg_price' )
            ->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->where($where)->group_by('add_time')->order_by('add_time desc,id desc')->find_all();

        $this->data['list'] = $list;

        $this->load->view($this->dcm,$this->data);
    }

    public function store_tongji()
    {
        $search['sear_starttime'] = $this->input->get('sear_starttime');
        $search['sear_endtime'] = $this->input->get('sear_endtime');

        $this->data['search'] = $search;

        $this->load->model('peisong_order_statistics_model');

        $search_url = '/c/peisong/store_tongji/?';
        $where = array(
            'site_id' => $this->site_id,
        );
        if($search['sear_starttime'])
        {
            $where['add_time >='] = strtotime($search['sear_starttime']);
            $search_url .= '&sear_starttime='.$search['sear_starttime'];
        }

        if($search['sear_endtime'])
        {
            $where['add_time <='] = strtotime($search['sear_endtime']);
            $search_url .= '&sear_endtime='.$search['sear_endtime'];
        }
        $this->load->model('peisong_store_model');
        $total_rows = $this->peisong_store_model->where(array('peisong_store.site_id'=>$this->site_id,'peisong_store.status'=>0))->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$search_url));

        $list = array();
        if($total_rows>0)
        {
            $stores = $this->peisong_store_model->select('peisong_store.id,address.name')
                ->join('address','address.id=peisong_store.address_id')
                ->where(array('peisong_store.site_id'=>$this->site_id,'peisong_store.status'=>0))
                ->limit($pager['limit']['value'], $pager['limit']['offset'])
                ->find_all();
            if($stores)
            {
                foreach($stores as &$store)
                {
                    $where['store_id'] = $store['id'];
                    //print_r($where);
                    $order = $this->peisong_order_statistics_model
                             ->select('SUM(total_order) as total_order_num, SUM(valid_order) as valid_order_num,SUM(invalid_order) as invalid_order_num,SUM(total_price) as total_price,AVG(avg_price) as avg_price' )
                             ->where($where)
                             ->group_by('store_id')
                             ->find();
                    $store['order'] = $order;
                }
            }
            $list = $stores;

        }
        $this->data['list'] = $list;
        //print_r($list);
        $this->data['left_menu_active'] = 'peisong/tongji';
        $this->data['page'] = $pager['links'];

        $this->load->view($this->dcm,$this->data);
    }
    
    //获取配送配置
    private function get_config()
    {
        $where = array(
            'site_id' => $this->site_id
        );
        $peisong = $this->model->where($where)->find();
        $peisong = $peisong ? $peisong : array();
        $this->data['peisong'] = $peisong;
        return $peisong;
    }
    
    //检查图片格式
    public function _check_image($image) {
        if ($image) {
            if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
                $this->form_validation->set_message('_check_image', '图片地址格式错误');
                return FALSE;
            }
        }
        return TRUE;
    }
} 