<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Affiche extends C_Controller {

	public function __construct() {
		parent::__construct();
	}

	public function index() {
		//查询列表
        $this->load->model('affiche_model');
        $this->data['affiche_list'] = $this->affiche_model->where('status=1 and (type=0 or type=1)')->order_by('dt_add desc')->find_all();
        //var_dump($this->data['affiche_list']);exit;
        $this->load->view($this->dcm, $this->data);
	}

	public function view($id) {

        $this->load->model('affiche_model');
        $this->data['affiche'] = $this->affiche_model->where(array('id'=>$id))->find();
        $this->load->view($this->dcm, $this->data);
	}



}