<?php
/**
 * Created by PhpStorm.
 * User: along
 * Date: 14-5-5
 * Time: 下午8:02
 */

class Bbs extends C_Controller {

    public function index()
    {
        $this->load->view($this->dcm, $this->data);
    }
} 