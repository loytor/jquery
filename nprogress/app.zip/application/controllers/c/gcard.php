<?php
/**
 * Created by PhpStorm.
 * User: llj
 * Date: 13-12-16
 * Time: 上午11:16
 * 微贺卡
 * @property Gcard_type_model $gcard_type_model
 * @property Gcard_config_model $gcard_config_model
 * @property Gcard_statistics_model $gcard_statistics_model
 * @property Gcard_type_statistics_model $gcard_type_statistics_model
 */
class Gcard extends C_Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * 设置
     */
    public function index()
    {
        $this->load->model('gcard_config_model');
        $gcard = $this->gcard_config_model->where(array('site_id'=>$this->site_info['id']))->find();

        $this->form_validation->set_rules('title', '贺卡页面名称', 'trim|required|max_length[20]');
        $this->form_validation->set_rules('keyword', '贺卡页面关键词', 'trim|required|max_length[255]');
        if($this->form_validation->run()) {
            $data = array();
            $data['title'] = $this->form_validation->set_value('title');
            $data['keyword'] = $this->form_validation->set_value('keyword');
            $data['on'] = $this->input->post('on');
            $data['icon'] = $this->input->post('icon');
            $url = $this->input->post('url');
            if($url) {
                $data['url'] = implode(',', $url);
            } else {
                $data['url'] = '';
            }

            if($gcard) { //更新
                if($this->gcard_config_model->where(array('id'=>$gcard['id'], 'site_id'=>$this->site_info['id']))->edit($data)) {
                    $this->show_message(TRUE, '保存成功', '');
                    return FALSE;
                } else {
                    $this->show_message(FALSE, '保存失败', '');
                    return FALSE;
                }
            } else { //添加
                $data['site_id'] = $this->site_info['id'];
                $data['dt_add'] = time();
                if($this->gcard_config_model->add($data)) {
                    $this->show_message(TRUE, '保存成功', '');
                    return FALSE;
                } else {
                    $this->show_message(FALSE, '保存失败', '');
                    return FALSE;
                }
            }
        } else {
            $errors = validation_errors();
            if ($errors) {
                $this->show_message(FALSE, $errors, '');
                return FALSE;
            }
        }
        //外链地址
        $domain = $this->session->userdata('domain');
        $url = $domain ? "http://".$domain.BASE_DOMAIN."/gcard" : '';
        $this->data['url'] = $url;

        $gcard && $gcard['url'] = explode(',', $gcard['url']);
        $this->data['gcard'] = $gcard ? $gcard : array();
        $this->load->view($this->dcm, $this->data);
    }

    /**
     * 类型列表
     */
    public function types()
    {
        $gcard = $this->check_gcard();
        if(!$gcard) {
            return FALSE;
        }

        $domain = $this->session->userdata('domain');

        $this->load->model('gcard_type_model');
        $total_rows =$this->gcard_type_model->count();
        $pager = $this->_pager($total_rows);
        $list = $this->gcard_type_model->limit($pager['limit']['value'], $pager['limit']['offset'])->find_all();
        foreach($list as &$item) {
            $item['keyword'] = $gcard['keyword'].$item['id'];
            $item['img'] = "http://".$domain.BASE_DOMAIN.'/assets/public/images/gcard_preview/'.$item['cate'].'_'.$item['sub_id'].'.jpg';
        }

        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->data['list'] = $list;
        $this->load->view($this->dcm, $this->data);
    }

    /**
     * 统计
     */
    public function statistics()
    {
        $gcard = $this->check_gcard();
        if(!$gcard) {
            return FALSE;
        }

        $where = array();
        $where['site_id'] = $this->site_info['id'];
        ($from_time = $this->input->get('from_time')) && $where['dt >='] = strtotime($from_time);
        ($end_time = $this->input->get('end_time')) && $where['dt <='] = strtotime($end_time);
        $type_id = $this->input->get('type_id');

        $this->load->model('gcard_statistics_model');
        if($type_id && $type_id != -1) {
            $where['type_id'] = $type_id;
            $total_rows = $this->gcard_statistics_model->where($where)->count();
            $pager = $this->_pager($total_rows);
            $list = $this->gcard_statistics_model->where($where)->order_by('dt', 'desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->find_all();
        } else {
            $total_rows = $this->gcard_statistics_model->distinct('dt')->where($where)->group_by('dt')->count();
            $pager = $this->_pager($total_rows, array('base_url' => site_url($this->uri->uri_string().'?').$_SERVER['QUERY_STRING']));
            $list = $this->gcard_statistics_model->select('*, SUM(`create_num`) AS create_num, SUM(`forward_num`) AS forward_num')->where($where)->group_by('dt')->order_by('dt', 'desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->find_all();
        }

        $this->load->model('gcard_type_model');
        $types_arr = $this->gcard_type_model->find_all();

        $this->data['search'] = $this->input->get();
        $this->data['types_arr'] = $types_arr;
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->load->view($this->dcm, $this->data);
    }

    /**
     * @return bool
     * 检查贺卡是否设置
     */
    private function check_gcard()
    {
        $this->load->model('gcard_config_model');
        $gcard = $this->gcard_config_model->where(array('site_id'=>$this->site_info['id']))->find();
        if(!$gcard) {
            $this->show_message(FALSE, '请先进行贺卡设置', '');
            return FALSE;
        }
        return $gcard;
    }
}