<?php
/**
 * Created by PhpStorm.
 * User: llj
 * Date: 14-1-15
 * Time: 下午7:20
 * @property Mp_info_model $mp_info_model
 * @property User_model $user_model
 */
class Mp_info extends C_Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $this->load->model('mp_info_model');
        $mp_info = $this->mp_info_model->where(array('site_id'=>$this->site_info['id']))->find();
        if($this->input->post()) {
            $this->form_validation->set_rules('mp_account', '微信公众平台登录帐号', 'trim');
            $this->form_validation->set_rules('mp_password', '微信公众平台登录密码', 'trim');
            if($this->form_validation->run()) {
                $data['mp_account'] = $this->form_validation->set_value('mp_account');
                $data['mp_password'] = $this->form_validation->set_value('mp_password');
                $result = file_get_contents('http://112.124.20.186/check.php?mp_account=' . $data['mp_account'] . '&mp_password=' . urlencode($data['mp_password']));
                $result = json_decode($result, TRUE);
                if ($result['ret'] == -1) {
                    $this->show_message(TRUE, '验证失败，请不要频繁点击，15分钟后点击保存，期间不要登陆微信公众平台', '/c/mp_info');
                    return FALSE;
                }
                if($mp_info) {
                    if($this->mp_info_model->where(array('site_id'=>$this->site_info['id'], 'id'=>$mp_info['id']))->edit($data)){
                        $this->show_message(TRUE, '保存成功', '/c/mp_info');
                        return FALSE;
                    } else {
                        $this->show_message(FALSE, '保存失败', '/c/mp_info');
                        return FALSE;
                    }
                } else {
                    $data['site_id'] = $this->site_info['id'];
                    if($this->mp_info_model->add($data)){
                        $this->show_message(TRUE, '保存成功', '/c/mp_info');
                        return FALSE;
                    } else {
                        $this->show_message(FALSE, '保存失败', '/c/mp_info');
                        return FALSE;
                    }
                }
            } else {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '/c/mp_info');
                    return FALSE;
                }
            }
        } else {
            $mp_info && $mp_info['en_mp_password'] = str_pad('', mb_strlen($mp_info['mp_password']), '*');
            $this->data['mp_info'] = $mp_info;
            $this->load->view($this->dcm, $this->data);
        }
    }

    public function check_info()
    {
        $this->load->model('mp_info_model');
        $mp_info = $this->mp_info_model->where(array('site_id'=>$this->site_info['id']))->find();
        $mp_info && $mp_info['en_mp_password'] = str_pad('', mb_strlen($mp_info['mp_password']), '*');
        $this->data['mp_info'] = $mp_info;
        $this->data['need_code'] = 0;
        if ($this->input->post()) {
            $mp_account = $this->input->post('mp_account');
            $mp_password = $this->input->post('mp_password');
            $imgcode = $this->input->post('imgcode');
            $result = file_get_contents('http://112.124.20.186/check.php?mp_account=' . $mp_account . '&mp_password=' . urlencode($mp_password) . '&imgcode=' . $imgcode);
            $result = json_decode($result, TRUE);
            if ($result['ret'] == 0) {
                $this->show_message(TRUE, '成功', '/c/mp_info/check_info');
            } else {
                $this->data['need_code'] = 1;
                $this->data['imgcode'] = $result['imgcode'];
            }
        }
        $this->load->view($this->dcm, $this->data);

/*
        $mp_account = $this->input->get('mp_account');
        $mp_password = $this->input->get('mp_password');
        $imgcode = $this->input->get('imgcode');
        $result = file_get_contents('http://112.124.20.186/check.php?mp_account=' . $mp_account . '&mp_password=' . urlencode($mp_password) . '&imgcode=' . $imgcode);
        $result = json_decode($result, TRUE);
        if ($result['ret'] == 0) {
            echo json_encode(array(
                'ret' => 0
            ));
        } else {
            $img_result = 'http://112.124.20.186/getimgcode.php?mp_account=' . $mp_account . '&mp_password=' . urlencode($mp_password);
            echo json_encode(array(
                'ret' => -1,
                'imgcode' => $result['imgcode'],
                'imgsrc' => $img_result
            ));
        }
        exit;
*/
    }

    public function test()
    {
        $this->load->model('mp_info_model');
        $this->load->model('user_model');
        $user_list = $this->user_model->find_all();
        $i = 0;
        foreach($user_list as $user) {
            if($user['mp_account'] && $user['mp_password']) {
                $mp_info = $this->mp_info_model->where(array('site_id'=>$user['id']))->find();
                if(!$mp_info) {
                    $data['site_id'] = $user['id'];
                    $data['mp_account'] = $user['mp_account'];
                    $data['mp_password'] = $user['mp_password'];
                    if($this->mp_info_model->add($data)){
                        $i++;
                    }
                }
            }
        }
        echo 'success:'.$i;
    }
}