<?php
class Setting extends C_Controller{


    public function __construct()
    {
        parent::__construct();
        $this->load->model('cache_model');
    }

    public function index()
    {

        var_dump($this->cache_model->read($this->site_info['domain'],'test'));
    }

    public function clearcache()
    {
        $this->load->view($this->dcm,$this->data);
    }

    public function do_clear()
    {
        $action = array('effect','effect_share','cate_list','cate_banner','assist','footer');
        foreach($action as $_ac)
        {
            $this->cache_model->remove($this->site_info['domain'],$_ac);
        }
        exit($this->ajax_return(array('ret' => 0, 'msg' => '缓存更新成功')));
    }


    public function clearapicache()
    {
    /*
        $this->cache_model->setcachekey('WEIBAAPI_KEYWORD');
        $cache = $this->cache_model->read($this->site_info['domain'],$this->site_info['domain']);
        print_r($cache);
        */
        $this->load->view($this->dcm,$this->data);
    }
    public function do_clearapicache()
    {
        $this->cache_model->setcachekey('WEIBAAPI_KEYWORD');
        $cache = $this->cache_model->read($this->site_info['domain'],$this->site_info['domain']);
        if($cache)
        {
            foreach($cache as $k => $_cache)
            {
                $this->cache_model->remove($this->site_info['domain'],$k);
            }
            $this->cache_model->remove($this->site_info['domain'],$this->site_info['domain']);
        }
        exit($this->ajax_return(array('ret' => 0, 'msg' => '缓存更新成功')));
    }
}