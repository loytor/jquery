<?php
/**
 * Created by PhpStorm.
 * User: 111
 * Date: 14-9-27
 * Time: 下午4:36
 */
class Money_game extends C_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->site_id = $this->site_info['id'];
        $token_data = array('user_id' => logged_user_id(), 'time' => time());
        $this->data['token'] = $this->encrypt->encode(serialize($token_data));
        $this->load->model('money_model');
    }

    public function index()
    {
        $where = array('site_id'=>$this->site_id,'status'=>0);
        $total_rows = $this->money_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15));

        $list = $this->money_model->order_by('id desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->where($where)->find_all();
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->data['pre_url'] = $this->site_info['all_domain'] ? $this->site_info['all_domain'] : 'http://'.$this->site_info['domain'].BASE_DOMAIN;
        $this->load->view($this->dcm, $this->data);
    }

    public function set()
    {
        $where = array();
        $id = $this->input->get_post('id');
        $money_game = array();
        if($id) {
            $where['id'] = $id;
            $where['site_id'] = $this->site_id;
            $money_game = $this->money_model->where($where)->find();
        }

        $post = $this->input->post();
        if($post) {
            $this->form_validation->set_rules('title', '标题', 'trim|required|max_length[30]|htmlspecialchars');
            $this->form_validation->set_rules('intro', '游戏说明', 'htmlspecialchars');
            $this->form_validation->set_rules('count_down', '倒计时', 'required|numeric|greater_than[4]|less_than[31]');
            $this->form_validation->set_rules('cgame', '每天每人可参与次数', 'numeric');
            $this->form_validation->set_rules('crank', '排行榜显示条数', 'numeric');
            $this->form_validation->set_rules('cshare', '分享获得机会次数', 'numeric');
            $this->form_validation->set_rules('cvirtual', '虚拟参与人数', 'numeric');
            $this->form_validation->set_rules('dt_start', '开始时间', 'required');
            $this->form_validation->set_rules('dt_end', '结束时间', 'required');

            if($this->form_validation->run()) {
                //开始时间
                $data['title'] = $this->form_validation->set_value('title');
                $data['dt_start'] = strtotime($this->form_validation->set_value('dt_start'));
                $data['dt_end'] = strtotime($this->form_validation->set_value('dt_end'));
                $data['count_down'] = $this->form_validation->set_value('count_down');
                $data['cvirtual'] = $this->form_validation->set_value('cvirtual');
                $data['concern'] = $post['concern'];
                if($data['concern'] != '') {
                    $data['concern'] = substr($data['concern'],0,7) != 'http://' ? 'http://'.$data['concern'] : $post['concern'];
                }else{
                    $data['concern'] = $this->site_info['auto_attention'];
                }
                $data['share_title'] = $post['share_title'];
/*                $data['share_desc'] = $post['share_desc'];
                $data['share_img'] = $post['share_img'];*/
                $data['bg_img'] = $post['bg_img'];
                $data['cgame'] = $this->form_validation->set_value('cgame');
                $data['cshare'] = $this->form_validation->set_value('cshare');
                $data['intro'] = $this->form_validation->set_value('intro');
                $data['crank'] = $this->form_validation->set_value('crank');

                //更新
                if($money_game) {
                    $this->money_model->where(array('id'=>$money_game['id']))->edit($data);
                } else {
                    $data['site_id'] = $this->site_id;
                    $this->money_model->add($data);
                }
                $this->show_message(true, '提交成功', '/c/money_game');return false;
            } else {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(false, $errors, '');return false;
                }
            }
        } else {
            $this->data['setting'] = $money_game;
            $this->data['auto_attention'] = $this->site_info['auto_attention'];
            $this->load->view($this->dcm, $this->data);
        }
    }

    public function del($id)
    {
        $money_game = $this->money_model->where(array('id'=>$id))->find();
        if(!$money_game || $money_game['site_id'] != $this->site_id)
        {
            $this->show_message(false, '该游戏不存在', '/c/money_game/index');
            return false;
        }
        $this->money_model->where(array('id'=>$money_game['id']))->edit(array('status'=>-1));
        $this->show_message(false, '删除成功', '/c/money_game/index');
        return false;
    }

    public function record($id = '')
    {
        if(!$id){
            $this->show_message(false, '非法访问', '/c/money_game/index');
            return false;
        }
        $this->load->model('money_member_model');
        $where = " site_id = '".$this->site_id."'";

        $searchUrl = '/c/money_game/record/'.$id.'/?';

        $keyword = $this->input->get('keyword');
        if($keyword)
        {
            $this->data['search'] = array('keyword'=>$keyword);
            $where .= " and (name like '%".$keyword."%' or mobile like '%".$keyword."%')";
            $searchUrl .= 'keyword='.$keyword;
        }

        $money_game = $this->money_model->where(array('site_id' => $this->site_id,'id'=>$id))->find();
        $where .= " and money_id = ".$money_game['id'];

        $total_rows = $this->money_member_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$searchUrl));

        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->data['list'] = array();
        if($total_rows > 0)
        {
            $this->data['list'] = $this->money_member_model->where($where)->limit($pager['limit']['value'], $pager['limit']['offset'])->order_by('hmoney desc')->find_all();
        }
        $this->data['money'] = $money_game;
        $this->load->view($this->dcm,$this->data);
    }

    public function export()
    {
        $this->load->model('money_member_model');
        $where = " site_id = '".$this->site_id."'";
        $keyword = $this->input->get('keyword');
        if($keyword)
        {
            $this->data['search'] = array('keyword'=>$keyword);
            $where .= " and (name like '%".$keyword."%' or mobile like '%".$keyword."%')";
        }
        $id = $this->input->get('id');
        $money_game = $this->money_model->where(array('site_id' => $this->site_id,'id'=>$id))->find();
        if(!$money_game)
        {
            $this->show_message(false,'暂无数据可以导出','');
            return false;
        }
        $where .= " and money_id = ".$money_game['id'];

        $list = $this->money_member_model->where($where)->order_by('hmoney desc')->find_all();
        $money_game_list = array();
        if($list)
        {
            foreach($list as $key=> $item)
            {
                $money_game_list[$key]['name'] = $item['name'];
                $money_game_list[$key]['mobile'] = $item['mobile'];
                $money_game_list[$key]['hmoney'] = $item['hmoney'];
            }

            $fields = array(
                'name'=>'姓名',
                'mobile'=>'手机',
                'hmoney'=>'金额'
            );
            //$this->excel_export('数钱游戏数据统计', '数钱游戏数据统计', $fields, $money_game_list);
            $this->excel_flush_export($fields, $money_game_list, '数钱游戏数据统计');
        }
        else
        {
            $this->show_message(false,'暂无数据可以导出','');
        }
    }
}