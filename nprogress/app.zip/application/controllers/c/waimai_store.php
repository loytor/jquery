<?php
/**
 * Created by PhpStorm.
 * User: along
 * Date: 13-12-9
 * Time: 下午3:10
 * 外卖门店
 * @property Waimai_model $model
 * @property Dishes_model $dishes_model
 * @property Waimai_dishes_model $waimai_dishes_model
 * @property Waimai_store_tag_model $waimai_store_tag_model
 * @property Waimai_dishes_tag_model $waimai_dishes_tag_model
 * @property Waimai_order_model $waimai_order_model
 * @property Waimai_order_dishes_model $waimai_order_dishes_model
 * @property Waimai_address_model $waimai_address_model
 * @property Waimai_order_statistics_model $waimai_order_statistics_model
 */

class Waimai_store extends C_Controller {

    protected $auto_load_model = TRUE;
    protected $model_name = 'waimai_store';
    
    protected $data = '';
    
    private $site_id = '';

    private $order_status_list = array(
        '-1' => '已关闭',
        '0' => '未付款',
        '1' => '已付款',
        '2' => '配送中',
        '3' => '货到付款',
        '4' => '交易成功'
    );

    public function __construct()
    {
        parent::__construct();
        
        $this->site_id = $this->site_info['id'];
        
        $this->load->model('waimai_model');
        $this->load->model('waimai_dishes_model');
        $this->load->model('waimai_dishes_tag_model');
        $this->load->model('waimai_store_tag_model');
        $this->load->model('waimai_order_model');
    }
    
    public function index()
    {
        $like = array();$is_search = 0;
        $search['sear_name'] = $this->input->get('sear_name');
        $search['sear_add'] = $this->input->get('sear_add');
        $search['sear_tel'] = $this->input->get('sear_tel');
        
        $this->data['search'] = $search;
        $search_url = site_url($this->uri->uri_string().'?');
        if( $search ){
            foreach( $search as $key=>$val ){
                if( $val ){
                    $search_url .= '&'.$key.'='.$val;
                    switch ($key){
                        case 'sear_name':
                            $like['address.name'] = $search['sear_name'];
                            break;
                        case 'sear_add':
                            $like['waimai_store.address'] = $search['sear_add'];
                            break;
                        case 'sear_tel':
                            $like['waimai_store.tele'] = $search['sear_tel'];
                            break;
                        default: break;
                    }
                }
            }
            $is_search = 1;
        }
        
        $this->data['is_search'] = $is_search;
        
        $where = array(
            'waimai_store.site_id' => $this->site_id,
            'waimai_store.status' => 0
        );
        
        $total_rows = $this->model->join('address','address.id=waimai_store.address_id')->where($where)->like($like)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$search_url));
        $list = $this->model
                ->select('waimai_store.*,address.name as add_name')
                ->join('address','address.id=waimai_store.address_id')
                ->limit($pager['limit']['value'], $pager['limit']['offset'])
                ->where($where)->like($like)->find_all();
        
        
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];


        $this->load->view($this->dcm, $this->data);
    }
    
    //添加门店
    public function add_store()
    {
        //所有门店
        $res = $this->address();
        if( !$res ){
            $this->show_message(false, '请先添加地址', '/address/add');return FALSE;
        }
        
        //已添加的门店
        $waimai_add = $this->model->select('id,address_id')->where(array('site_id'=>$this->site_id,'status'=>0))->find_all();
        $has_store = array();
        if( $waimai_add ){
            foreach( $waimai_add as $val ){
                $has_store[$val['address_id']] = $val['address_id'];
            }
        }
        
        $address_list = array();
        foreach( $this->data['address_list'] as $val ){
            if( !isset($has_store[$val['id']]) ){
                $address_list[] = $val;
            }
        }
        
        if( !$address_list ){
            $this->show_message(false, '您所拥有的门店已全部添加到了外卖门店里', '/c/waimai_store/');return FALSE;
        }
        $this->data['address_list'] = $address_list;

        //检查是否开通微助手
        if( $this->check_assistant($this->site_id) ){
            $this->data['assistant'] = 1;
        }else{
            $this->data['assistant'] = 0;
        }
        
        if( $this->input->post() ){
            $this->form_validation->set_rules('address_id', '选择门店', 'trim|required');
            $this->form_validation->set_rules('address', '门店地址', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('tele', '外卖电话', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('rule', '配送费设置', 'trim|numeric|greater_than[0]');
            $this->form_validation->set_rules('r2s', '配送费收费多少钱', 'trim|numeric|greater_than_equal_to[0]');
            $this->form_validation->set_rules('r2e', '配送费满后免费', 'trim|numeric|greater_than_equal_to[0]');
            $this->form_validation->set_rules('qisong', '起送条件', 'trim|required|numeric|greater_than_equal_to[0]');
            $this->form_validation->set_rules('step_time', '送餐预留时间', 'trim|required|numeric|greater_than_equal_to[900]');
            $this->form_validation->set_rules('ship_type', '订购支持', 'trim|required|numeric|greater_than_equal_to[1]');
            $this->form_validation->set_rules('ship_time', '提前订购天数', 'trim|numeric|greater_than_equal_to[1]');
            $this->form_validation->set_rules('range', '配送范围', 'trim|numeric');
            $this->form_validation->set_rules('printer_num', '小票打印机设置', 'trim|required|numeric|greater_than_equal_to[1]|intval');
            $this->form_validation->set_rules('assistant', '微助手提醒', 'trim|intval');
            $this->form_validation->set_rules('email', '订单微信提醒', 'trim|valid_email');
            $this->form_validation->set_rules('intro', '外卖说明', 'trim|htmlspecialchars|max_length[500]');
            if ( $this->form_validation->run() ){
                
                $save_data['address_id'] = $this->form_validation->set_value('address_id');
                $save_data['address'] = $this->form_validation->set_value('address');
                $save_data['tele'] = $this->form_validation->set_value('tele');
                
                //配送规则
                $rule = $this->form_validation->set_value('rule');
                $save_rule['rule'] = $rule;
                if( $rule==2 ){
                    $r2s = $rule = $this->form_validation->set_value('r2s');
                    if( !$r2s ){
                        $this->show_message(false, '请填写配送费', '/c/waimai_store/add_store');return FALSE;
                    }
                    $r2e = $this->form_validation->set_value('r2e');
                    $r2e = $r2e ? $r2e : 0;
                    $save_rule['r2s'] = $r2s;
                    $save_rule['r2e'] = $r2e;
                }
                $save_data['rule'] = serialize($save_rule);
                
                $save_data['qisong'] = $this->form_validation->set_value('qisong');
                
                //营业时间
                $save_data['sh'] = intval($this->input->post('sh'));
                $save_data['eh'] = intval($this->input->post('eh'));
                
                $save_data['step_time'] = $this->form_validation->set_value('step_time');
                $save_data['ship_type'] = $this->form_validation->set_value('ship_type');
                $save_data['ship_time'] = $this->form_validation->set_value('ship_time');
                
                $save_data['range'] = $this->form_validation->set_value('range');
                $save_data['printer_num'] = $this->form_validation->set_value('printer_num');
                $save_data['assistant'] = $this->form_validation->set_value('assistant');
                $save_data['email'] = $this->form_validation->set_value('email');
                $save_data['intro'] = $this->form_validation->set_value('intro');
                
                //发送订单选项
                if( $save_data['email'] ){
                    $order_email_contents = $this->input->post('order',true);
                    if( !$order_email_contents ){
                        $this->show_message(false, '请选择要提醒的内容', '/c/waimai_store/add_store');return FALSE;
                    }
                    $order_email = '';
                    foreach( $order_email_contents as $key=>$val ){
                        $order_email .= $key.',';
                    }
                    $order_email = substr($order_email, 0,-1);
                    $save_data['send_content'] = $order_email;
                }
                
                $del_temp = $this->model->where(array('site_id'=>$this->site_id,'address_id'=>$save_data['address_id'],'status'=>1))->find();
                if( $del_temp ){//改状态
                    $save_data['status'] = 0;
                    if($this->model->where(array('site_id'=>$this->site_id,'address_id'=>$save_data['address_id']))->edit($save_data)){
                    }else{
                        $this->show_message(false, '添加失败', '/c/waimai_store');return FALSE;
                    }
                }else{//添加
                    $save_data['site_id'] = $this->site_id;
                    $save_data['add_time'] = time();
                    if($this->model->add($save_data)){
                    }else{
                        $this->show_message(false, '添加失败', '/c/waimai_store');return FALSE;
                    }
                }
                $this->show_message(true, '添加成功', '/c/waimai_store');return FALSE;
            }else{ 
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            $this->load->view($this->dcm, $this->data);
        }
    }
    
    
    //配置门店     废弃
    public function config_address()
    {
        $res = $this->address();
        if( !$res ){
            $this->show_message(false, '请先添加地址', '/address/add');return FALSE;
        }
        
        $waimai_add = $this->model->select('id,address_id')->where(array('site_id'=>$this->site_id,'status'=>0))->find_all();
        $this->data['waimai_add'] = $waimai_add;
        
        
        if( $this->input->post() ){
            
            $add_temp = $this->input->post('address');
            $add_temp = $add_temp ? $add_temp : array();
            
            $selected_ad_ids = array();
            if( $waimai_add ){
                foreach($waimai_add as $ma) {
                    $selected_ad_ids[] = $ma['address_id'];
                }
            }
            
            $selected_ad_ids = isset($selected_ad_ids) && $selected_ad_ids ? $selected_ad_ids : array();
            $del_ids = array_diff($selected_ad_ids, $add_temp);
            $add_ids = array_diff($add_temp, $selected_ad_ids);
            
            if( $del_ids ){//需删除的门店
                foreach( $del_ids as $did ){
                    $this->model->where(array('site_id'=>$this->site_id,'address_id'=>$did))->edit(array('status'=>1));
                }
            }
            if( $add_ids ){//需添加的门店
                foreach( $add_ids as $aid ){
                    $del_temp = $this->model->where(array('site_id'=>$this->site_id,'address_id'=>$aid,'status'=>1))->find();
                    if( $del_temp ){//改状态
                        $this->model->where(array('site_id'=>$this->site_id,'address_id'=>$aid))->edit(array('status'=>0));
                    }else{//添加
                        $add_data = array(
                            'site_id' => $this->site_id,
                            'address_id' => $aid,
                            'add_time' => time()
                        );
                        $this->model->add($add_data);
                    }
                }
            }
            $this->show_message(true, '保存成功', '/c/waimai_store');return FALSE;
            
        }else{
            $this->load->view($this->dcm, $this->data);
        }
    }
    
    /**
     * 修改门店信息
     */
    public function edit($store_id)
    {
        $res = $this->get_store($store_id);
        if( !$res ){
            $this->show_message(false, '非法操作', '/c/waimai_store');return FALSE;
        }
        //配送费设置规则
        if( $this->data['store']['rule'] ){
            $this->data['store']['rule'] = unserialize($this->data['store']['rule']);
        }
        if( $this->data['store']['email'] ){
            $this->data['store']['send_content'] = explode(',', $this->data['store']['send_content']);
        }
        
        //获取门店名称和地址
        $this->load->model('model_address');
        $address = $this->model_address->get_row(array('id'=>$this->data['store']['address_id']));
        $this->data['address'] = $address;

        //检查是否开通微助手
        if( $this->check_assistant($this->site_id) ){
            $this->data['assistant'] = 1;
        }else{
            $this->data['assistant'] = 0;
        }
        
        if( $this->input->post() ){
            $this->form_validation->set_rules('address', '门店地址', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('tele', '外卖电话', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('rule', '配送费设置', 'trim|numeric|greater_than[0]');
            $this->form_validation->set_rules('r2s', '配送费收费多少钱', 'trim|numeric|greater_than_equal_to[0]');
            $this->form_validation->set_rules('r2e', '配送费满后免费', 'trim|numeric|greater_than_equal_to[0]');
            $this->form_validation->set_rules('qisong', '起送条件', 'trim|required|numeric|greater_than_equal_to[0]');
            $this->form_validation->set_rules('step_time', '送餐预留时间', 'trim|required|numeric|greater_than_equal_to[900]');
            $this->form_validation->set_rules('ship_type', '订购支持', 'trim|required|numeric|greater_than_equal_to[1]');
            $this->form_validation->set_rules('ship_time', '提前订购天数', 'trim|numeric|greater_than_equal_to[1]');
            $this->form_validation->set_rules('range', '配送范围', 'trim|numeric');
            $this->form_validation->set_rules('printer_num', '小票打印机设置', 'trim|required|numeric|greater_than_equal_to[1]|intval');
            $this->form_validation->set_rules('assistant', '微助手提醒', 'trim|intval');
            $this->form_validation->set_rules('email', '订单微信提醒', 'trim|valid_email');
            $this->form_validation->set_rules('intro', '外卖说明', 'trim|htmlspecialchars|max_length[500]');
            if ( $this->form_validation->run() ){
                
                $save_data['address'] = $this->form_validation->set_value('address');
                $save_data['tele'] = $this->form_validation->set_value('tele');
                
                //配送规则
                $rule = $this->form_validation->set_value('rule');
                $save_rule['rule'] = $rule;
                if( $rule==2 ){
                    $r2s = $rule = $this->form_validation->set_value('r2s');
                    if( !$r2s ){
                        $this->show_message(false, '请填写配送费', '/c/waimai_store/edit/'.$store_id);return FALSE;
                    }
                    $r2e = $this->form_validation->set_value('r2e');
                    $r2e = $r2e ? $r2e : 0;
                    $save_rule['r2s'] = $r2s;
                    $save_rule['r2e'] = $r2e;
                }
                $save_data['rule'] = serialize($save_rule);
                
                $save_data['qisong'] = $this->form_validation->set_value('qisong');
                
                //营业时间
                $save_data['sh'] = intval($this->input->post('sh'));
                $save_data['eh'] = intval($this->input->post('eh'));
                
                $save_data['step_time'] = $this->form_validation->set_value('step_time');
                $save_data['ship_type'] = $this->form_validation->set_value('ship_type');
                $save_data['ship_time'] = $this->form_validation->set_value('ship_time');
                
                $save_data['range'] = $this->form_validation->set_value('range');
                $save_data['printer_num'] = $this->form_validation->set_value('printer_num');
                $save_data['assistant'] = $this->form_validation->set_value('assistant');
                $save_data['email'] = $this->form_validation->set_value('email');
                $save_data['intro'] = $this->form_validation->set_value('intro');
                
                //发送订单选项
                if( $save_data['email'] ){
                    $order_email_contents = $this->input->post('order',true);
                    if( !$order_email_contents ){
                        $this->show_message(false, '请选择要提醒的内容', '/c/waimai_store/add_store');return FALSE;
                    }
                    $order_email = '';
                    foreach( $order_email_contents as $key=>$val ){
                        $order_email .= $key.',';
                    }
                    $order_email = substr($order_email, 0,-1);
                    $save_data['send_content'] = $order_email;
                }
                
                if( $this->model->where(array('site_id' => $this->site_id,'status' => 0,'id' => $store_id))->edit($save_data) ){
                    $this->show_message(true, '保存成功', '/c/waimai_store');return FALSE;
                }else{
                    $this->show_message(false, '保存失败', '/c/waimai_store');return FALSE;
                }
            }else{ 
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            $this->load->view($this->dcm, $this->data);
        }
    }
    
    public function delete_store($store_id)
    {
        $res = $this->get_store($store_id);
        if( !$res ){
            $this->show_message(false, '非法操作', '/c/waimai_store');return FALSE;
        }
        
        if( $this->model->where(array('site_id'=>$this->site_id,'status' => 0,'id'=>$store_id))->edit(array('status'=>1)) ){
            $this->show_message(true, '删除成功', '/c/waimai_store');return FALSE;
        }else{
            $this->show_message(false, '删除失败', '/c/waimai_store');return FALSE;
        }
    }
    
    
    //门店标签
    public function tags($store_id)
    {
        $res = $this->get_store($store_id);
        if( !$res ){
            $this->show_message(false, '非法操作', '/c/waimai_store');return FALSE;
        }
        $where = array(
            'site_id' => $this->site_id,
            'store_id' => $store_id,
            'status' => 0
        );
        $total_rows = $this->waimai_store_tag_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15));
        $list = $this->waimai_store_tag_model
                ->limit($pager['limit']['value'], $pager['limit']['offset'])
                ->where($where)->order_by('sort asc,id desc')->find_all();
        
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        
        
        $this->load->view($this->dcm, $this->data);
    }
    
    //添加标签
    public function add_tag($store_id)
    {
        $res = $this->get_store($store_id);
        if( !$res ){
            $this->show_message(false, '非法操作', '/c/waimai_storetags/'.$store_id);return FALSE;
        }
        
        if( $this->input->post() ){
            $this->form_validation->set_rules('name', '标签名', 'trim|required|max_length[10]');
            $this->form_validation->set_rules('sort', '排序', 'trim|is_natural_no_zero');
            $this->form_validation->set_rules('show', '排序', 'trim|intval');
            $this->form_validation->set_rules('intro', '外卖说明', 'trim|htmlspecialchars|max_length[500]');
            if ( $this->form_validation->run() ){
                
                $save_data['name'] = $this->form_validation->set_value('name');
                $save_data['sort'] = $this->form_validation->set_value('sort');
                $save_data['sort'] = $save_data['sort'] ? $save_data['sort'] : 0;
                $save_data['show'] = $this->form_validation->set_value('show');
                $save_data['intro'] = $this->form_validation->set_value('intro');
                
                $save_data['site_id'] = $this->site_id;
                $save_data['store_id'] = $store_id;
                
                //唯一验证
                $res = $this->check_tag($save_data['name'],$store_id);
                if( $res ){
                    $this->show_message(false, '已添加过该标签', '/c/waimai_store/tags/'.$store_id);return FALSE;
                }
                
                //判断是否已经存在过
                $temp_tag  = $this->waimai_store_tag_model->where(array('site_id'=>$this->site_id,'store_id'=>$store_id,'name'=>$save_data['name'],'status'=>1))->find();
                if( $temp_tag ){
                    //修改原来的数据
                    $save_data['status'] = 0;
                    if( $this->waimai_store_tag_model->where(array('site_id'=>$this->site_id,'store_id'=>$store_id,'name'=>$save_data['name'],'status'=>1))->edit($save_data) ){
                        $this->show_message(true, '添加成功', '/c/waimai_store/tags/'.$store_id);return FALSE;
                    }else{
                        $this->show_message(false, '添加失败', '/c/waimai_store/tags/'.$store_id);return FALSE;
                    }
                }else{
                    $save_data['add_time'] = time();
                    if( $this->waimai_store_tag_model->add($save_data) ){
                        $this->show_message(true, '添加成功', '/c/waimai_store/tags/'.$store_id);return FALSE;
                    }else{
                        $this->show_message(false, '添加失败', '/c/waimai_store/tags/'.$store_id);return FALSE;
                    }
                }
                
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            $this->load->view($this->dcm, $this->data);
        }
    }
    
    //标签唯一性验证
    private function check_tag($name,$sid,$id='')
    {
        $where = array(
            'site_id' => $this->site_id,
            'store_id' => $sid,
            'name' => $name,
            'status' => 0
        );
        
        if( $id ){
            $where['id <>'] = $id;
        }
        $tag = $this->waimai_store_tag_model->where($where)->find();
        if( $tag ){
            return true;
        }else{
            return false;
        }
    }
    
    //编辑标签
    public function edit_tag()
    {
        $store_id = $this->input->get('sid');
        $tag_id = $this->input->get('id');
        
        $res = $this->get_store($store_id);
        if( !$res ){
            $this->show_message(false, '非法操作', '/c/waimai_storetags/'.$store_id);return FALSE;
        }

        $tag = $this->waimai_store_tag_model->where(array('site_id'=>$this->site_id,'store_id'=>$store_id,'id'=>$tag_id,'status'=>0))->find();
        if( !$tag ){
            $this->show_message(false, '非法操作', '/c/waimai_storetags/'.$store_id);return FALSE;
        }
        $this->data['tag'] = $tag;
        
        if( $this->input->post() ){
            $this->form_validation->set_rules('name', '标签名', 'trim|required|max_length[10]');
            $this->form_validation->set_rules('sort', '排序', 'trim|is_natural_no_zero');
            $this->form_validation->set_rules('show', '排序', 'trim|intval');
            $this->form_validation->set_rules('intro', '外卖说明', 'trim|htmlspecialchars|max_length[500]');
            if ( $this->form_validation->run() ){
                
                $save_data['name'] = $this->form_validation->set_value('name');
                $save_data['sort'] = $this->form_validation->set_value('sort');
                $save_data['sort'] = $save_data['sort'] ? $save_data['sort'] : 0;
                $save_data['show'] = $this->form_validation->set_value('show');
                $save_data['intro'] = $this->form_validation->set_value('intro');
                
                $save_data['site_id'] = $this->site_id;
                $save_data['store_id'] = $store_id;
                
                //唯一验证
                $res = $this->check_tag($save_data['name'],$store_id,$tag_id);
                if( $res ){
                    $this->show_message(false, '已添加过该标签', '/c/waimai_store/tags/'.$store_id);return FALSE;
                }
                
                if( $this->waimai_store_tag_model->where(array('site_id'=>$this->site_id,'store_id'=>$store_id,'id'=>$tag_id,'status'=>0))->edit($save_data) ){
                    $this->show_message(true, '修改成功', '/c/waimai_store/tags/'.$store_id);return FALSE;
                }else{
                    $this->show_message(false, '修改失败', '/c/waimai_store/tags/'.$store_id);return FALSE;
                }
                
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            $this->load->view($this->dcm, $this->data);
        }
    }
    
    //删除标签
    public function delete_tag()
    {
        $store_id = $this->input->get('sid');
        $tag_id = $this->input->get('id');
        
        $res = $this->get_store($store_id);
        if( !$res ){
            $this->show_message(false, '非法操作', '/c/waimai_storetags/'.$store_id);return FALSE;
        }
        $tag = $this->waimai_store_tag_model->where(array('site_id'=>$this->site_id,'store_id'=>$store_id,'id'=>$tag_id,'status'=>0))->find();
        if( !$tag ){
            $this->show_message(false, '非法操作', '/c/waimai_storetags/'.$store_id);return FALSE;
        }
        
        $save_data['status'] = 1;
        if( $this->waimai_store_tag_model->where(array('site_id'=>$this->site_id,'store_id'=>$store_id,'id'=>$tag_id,'status'=>0))->edit($save_data) ){
            $this->show_message(true, '删除成功', '/c/waimai_store/tags/'.$store_id);return FALSE;
        }else{
            $this->show_message(false, '删除失败', '/c/waimai_store/tags/'.$store_id);return FALSE;
        }
    }
    
    
    //获取门店信息
    private function get_store($store_id)
    {
        $where = array(
            'site_id' => $this->site_id,
            'status' => 0,
            'id' => $store_id
        );
        $waimai_store = $this->model->where($where)->find();
        $waimai_store = $waimai_store ? $waimai_store : array();
        $this->data['store'] = $waimai_store;
        if( !$waimai_store ){
            return false;
        }
        return true;
    }
    
    /**
     * 默认单位  联系方式里的
     */
    private function address()
    {
        //分店
        $this->load->model('model_address');
        $address_list = $this->model_address->get_all(array('wid'=>$this->site_id, 'status'=>0), '', '');
        $address_list = $address_list ? $address_list : array();
        $this->data['address_list'] = $address_list;
        if( !$address_list ){
            return false;
        }
        return true;
    }

    /**
     * @name 一个门店下的菜品列表
     * @return bool
     */
    public function dishes()
    {
        $sid = $this->input->get('sid');

        //门店是否存在
        $storeInfo = $this->get_store($sid);
        if(!$sid || !$storeInfo)
        {
            $this->show_message(false, '门店不存在', '/c/waimai_store');return FALSE;
        }

        $where = array(
            'waimai_dishes.site_id'=>$this->site_id,
            'waimai_dishes.sid'=>$sid
        );

        $like = array();
        $search['title'] = $this->input->get('title');
        $search['price'] = $this->input->get('price');
        $search['oldprice'] = $this->input->get('oldprice');

        $this->data['search'] = $search;
        $search_url = '/c/waimai_store/dishes/?sid='.$sid;
        //标题模糊查询
        if($search['title'])
        {
            $like['dishes.title'] = $search['title'];
        }
        if($search['oldprice'])
        {
            $where['dishes.price'] = $search['oldprice'];
        }
        if($search['price'])
        {
            $where['waimai_dishes.price'] = $search['price'];
        }
        if($search)
        {
            foreach( $search as $key=>$val ){
                $search_url .= '&'.$key.'='.$val;
            }
        }

        $total_rows = $this->waimai_dishes_model->join('dishes','dishes.id=waimai_dishes.dishes_id')->where($where)->like($like)->count();

        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$search_url));


        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        //门店下的所有标签
        $tagwhere = array(
            'site_id' => $this->site_id,
            'store_id' => $sid,
            'status' => 0
        );
        $taglist = $this->waimai_store_tag_model->where($tagwhere)->order_by('id desc')->find_all();
        $tagArr = array();
        if($taglist)
        {
            foreach($taglist as $tag)
            {
                $tagArr[$tag['id']] = $tag;
            }
        }

        $list = $this->waimai_dishes_model
            ->select('waimai_dishes.id,waimai_dishes.price,dishes.cid,dishes.pic,dishes.price as oldprice,dishes.title')
            ->join('dishes','dishes.id=waimai_dishes.dishes_id')
            ->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->where($where)->like($like)->order_by('waimai_dishes.rank desc')->find_all();
        $dishesArr = array();
        if($list)
        {
            foreach($list as $_list)
            {
                //菜品的tag
                $dishesTag = $this->waimai_dishes_tag_model
                    ->select('waimai_store_tag.name')
                    ->join('waimai_store_tag','waimai_dishes_tag.tag_id=waimai_store_tag.id')
                    ->where(array('waimai_dishes_tag.site_id'=>$this->site_id,'waimai_dishes_tag.sid'=>$sid,'waimai_dishes_tag.dishes_id'=>$_list['id']))
                    ->find_all();
                if($dishesTag)
                {
                    $dot = $tags = '';
                    foreach($dishesTag as $tag)
                    {
                        $tags .= $dot.$tag['name'];
                        $dot = ',';
                    }
                    $_list['tag'] = $tags;
                }
                $dishesArr[] = $_list;
            }
        }

        $this->data['list'] = $dishesArr;

        $this->load->view($this->dcm, $this->data);
    }

    /**
     * @name 增加门店的菜品
     * @return bool
     */
    public function get_dishes()
    {
        $sid = $this->input->get('sid');
        //门店是否存在
        $storeInfo = $this->get_store($sid);
        if(!$sid || !$storeInfo)
        {
            $this->show_message(false, '门店不存在', '/c/waimai_store');return FALSE;
        }
        //所有的菜品
        $this->load->model('dishes_model');
        $where['site_id'] = $this->site_info['id'];

        $list = $this->dishes_model->order_by('id desc')->where($where)->find_all();
        if(!$list)
        {
            $this->show_message(false, '请先添加菜品', '/c/dishes');return FALSE;
        }
        $dishesList = array();
        foreach($list as $_list)
        {
            $dishesList[$_list['id']] = $_list;
        }
        //门店下的所有标签

        $where = array(
            'site_id' => $this->site_id,
            'store_id' => $sid,
            'status' => 0
        );
        $taglist = $this->waimai_store_tag_model->where($where)->order_by('sort asc,id desc')->find_all();
        if(!$taglist)
        {
            $this->show_message(false, '请先添加该门店下的标签', '/c/waimai_store/add_tag/'.$sid);return FALSE;
        }
        $this->data['taglist'] = $taglist;
        $post = $this->input->post();

        //print_r($postData);
        if($post)
        {
            //菜品是否有选择
            $dishes_id = $this->input->post('dishes_id');
            if(!$dishes_id)
            {
                $this->show_message(false, '请选择菜品', '/c/waimai_store/get_dishes/?sid='.$sid);return FALSE;
            }
            //tag是否有选择
            $tag = $this->input->post('tag');
            if(!$tag)
            {
                $this->show_message(false, '请选择标签！', '/c/waimai_store/get_dishes/?sid='.$sid);return FALSE;
            }
            $price = $this->input->post('price');
            //判断价格
            if(!is_numeric($price) || $price<0)
            {
                $this->show_message(false, '价格必须是非负数！', '/c/waimai_store/get_dishes/?sid='.$sid);return FALSE;
            }
            $price = $price ? $price : $dishesList[$dishes_id]['price'];
            //排序
            $rank = $this->input->post('rank');
            $rank = is_numeric($rank) ? $rank : 0;
            $newdishesid = $this->waimai_dishes_model->add(array('site_id'=>$this->site_id,'sid'=>$sid,'dishes_id'=>$dishes_id,'price'=>$price,'rank'=>$rank,'inputtime'=>time()));
            if($newdishesid)
            {
                foreach($tag as $_tag)
                {
                    $this->waimai_dishes_tag_model->add(array('site_id'=>$this->site_id,'sid'=>$sid,'dishes_id'=>$newdishesid,'tag_id'=>$_tag));
                }
            }
            $this->show_message(true, '添加成功', '/c/waimai_store/dishes/?sid='.$sid);return FALSE;
        }
        else
        {
            //当前门店下已选择的菜品
            $storeDishesList = $this->waimai_dishes_model->where(array('site_id'=>$this->site_info['id'],'sid'=>$sid))->find_all();
            if($storeDishesList)
            {
                //可选择的菜品
                foreach($storeDishesList as $slist)
                {
                    if(isset($dishesList[$slist['dishes_id']])&&$dishesList[$slist['dishes_id']])
                    {
                        unset($dishesList[$slist['dishes_id']]);
                    }
                }
            }
            $this->data['list'] = $dishesList;
            $this->load->view($this->dcm, $this->data);
        }

    }

    /**
     * @name 编辑门店下的菜品
     * @return bool
     */
    public function edit_dishes()
    {
        $id = $this->input->get('id');
        //菜品是否存在
        $storeDishes = $this->waimai_dishes_model
            ->select('waimai_dishes.id,waimai_dishes.price,waimai_dishes.sid,waimai_dishes.rank,dishes.cid,dishes.pic,dishes.price as oldprice,dishes.title,dishes.description')
            ->join('dishes','dishes.id=waimai_dishes.dishes_id')
            ->where(array('waimai_dishes.site_id'=>$this->site_id,'waimai_dishes.id'=>$id))->find();

        //门店是否存在
        $storeInfo = $this->get_store($storeDishes['sid']);
        if( !$storeInfo)
        {
            $this->show_message(false, '门店不存在', '/c/waimai_store');return FALSE;
        }

        $tagWhere = array('site_id'=>$this->site_id,'sid'=>$storeDishes['sid'],'dishes_id'=>$id);

        if( $this->input->post() )
        {
            $this->form_validation->set_rules('price', '菜品现价', 'trim');
            $this->form_validation->set_rules('rank', '排序', 'trim|numeric');
            if($this->form_validation->run())
            {
                $save_data['price'] = $this->form_validation->set_value('price');
                //判断价格
                if(!is_numeric($save_data['price']) || $save_data['price'] <0 )
                {
                    $this->show_message(false, '价格必须是非负数！', '/c/waimai_store/edit_dishes/?id='.$id);return FALSE;
                }
                $save_data['rank'] = $this->form_validation->set_value('rank');
                $save_data['rank'] = is_numeric($save_data['rank']) ? $save_data['rank'] : 0;
                $tag = $this->input->post('tag');
                if(!$tag)
                {
                    $this->show_message(false, '请选择标签！', '/c/waimai_store/edit_dishes/?id='.$id);return FALSE;
                }
                else
                {
                    //删除原有的tag
                    $this->waimai_dishes_tag_model->where($tagWhere)->delete();
                    foreach($tag as $_tag)
                    {
                        $this->waimai_dishes_tag_model->add(array('site_id'=>$this->site_id,'sid'=>$storeDishes['sid'],'dishes_id'=>$id,'tag_id'=>$_tag));
                    }
                }
                //print_r($save_data);exit;
                if( $this->waimai_dishes_model->where(array('site_id' => $this->site_id,'id' => $id))->edit($save_data) )
                {
                    $this->show_message(true, '保存成功', '/c/waimai_store/dishes/?sid='.$storeDishes['sid']);return FALSE;
                }else{
                    $this->show_message(false, '保存失败', '/c/waimai_store/edit_dishes/?id='.$id);return FALSE;
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }
        else
        {
            //已经保存的菜品标签
            $this->data['dishestaglist'] = $this->waimai_dishes_tag_model->where($tagWhere)->find_all();

            //门店下的所有标签
            $where = array(
                'site_id' => $this->site_id,
                'store_id' => $storeDishes['sid'],
                'status' => 0
            );
            $taglist = $this->waimai_store_tag_model->where($where)->order_by('sort asc,id desc')->find_all();

            $this->data['taglist'] = $taglist;
            $this->data['storedishes'] = $storeDishes;
            $this->load->view($this->dcm, $this->data);
        }
    }

    /**
     * @name 删除一个菜品
     * @param $id
     * @return bool
     */
    public function delete_dishes($id)
    {
        //菜品是否存在
        $storeDishes = $this->waimai_dishes_model
            ->select('waimai_dishes.id,waimai_dishes.price,waimai_dishes.sid,waimai_dishes.rank,dishes.cid,dishes.pic,dishes.price as oldprice,dishes.title,dishes.description')
            ->join('dishes','dishes.id=waimai_dishes.dishes_id')
            ->where(array('waimai_dishes.site_id'=>$this->site_id,'waimai_dishes.id'=>$id))->find();

        //门店是否存在
        $storeInfo = $this->get_store($storeDishes['sid']);
        if( !$storeInfo)
        {
            $this->show_message(false, '门店不存在', '/c/waimai_store');return FALSE;
        }
        if( $this->waimai_dishes_model->where(array('site_id' => $this->site_id,'id' => $id))->delete() )
        {
            //删除tag
            $tagWhere = array('site_id'=>$this->site_id,'sid'=>$storeDishes['sid'],'dishes_id'=>$id);
            $this->waimai_dishes_tag_model->where($tagWhere)->delete();
            $this->show_message(true, '删除成功', '/c/waimai_store/dishes/?sid='.$storeDishes['sid']);return FALSE;
        }else{
            $this->show_message(false, '删除失败', '/c/waimai_store/dishes/?sid='.$storeDishes['sid']);return FALSE;
        }
    }

    /**
     * @name  查看订单详情
     * @return bool
     */
    public function order_detail()
    {
        //订单id
        $id = $this->input->get('id');

        $orderDetail = $this->get_one_order_info($id);
        if(!$orderDetail)
        {
            $this->show_message(false, '订单不存在', '');return FALSE;
        }
        //订单商品
        $this->load->model('waimai_order_dishes_model');
        $orderDishes = $this->waimai_order_dishes_model->where(array('site_id'=>$this->site_id,'order_id'=>$id))->find_all();
        $this->data['orderdishes'] = $orderDishes;

        /*//联系人信息
        $this->load->model('waimai_address_model');
        $address = $this->waimai_address_model->where(array('site_id'=>$this->site_id,'id'=>$orderDetail['address_id']))->find();
        $this->data['address'] = $address;*/
        //联系人信息
        $this->load->model('waimai_address_model');
        $address = $this->waimai_address_model->where(array('site_id'=>$this->site_id,'id'=>$orderDetail['address_id']))->find();
        if( !$orderDetail['name'] ){
            if( !$address ){
                $address['name'] = $address['mobile'] = $address['address'] = $address['lat'] = $address['lng'] ='';
            }
        }else{
            $address['name'] = $orderDetail['name'];
            $address['mobile'] = $orderDetail['mobile'];
            $address['address'] = $orderDetail['address'];
            $address['lat'] = $orderDetail['lat'];
            $address['lng'] = $orderDetail['lng'];
        }
        $this->data['address'] = $address;

        //订单状态
        $orderStatus = $this->order_status_list;

        $orderDetail['status'] = $orderStatus[$orderDetail['order_status']];

        $this->data['detail'] = $orderDetail;

        $this->load->view($this->dcm, $this->data);
    }

    public function order_price()
    {
        $id = $this->input->post('id');

        $orderDetail = $this->get_one_order_info($id);
        if(!$orderDetail)
        {
            $this->show_message(false, '订单不存在', '');return FALSE;
        }
        $data = $this->input->post('data');
        if($orderDetail['order_status'] == 0)
        {
            $this->waimai_order_model->where(array('id'=>$id,'site_id'=>$this->site_id))->edit($data);
            $result['success'] = 1;
            $result['msg'] = '修改成功';

        }
        else
        {
            $result['success'] = 0;
            $result['msg'] = '当前订单不能修改总价';
        }

        echo json_encode($result);
        exit;
    }

    /**
     * @name 取消订单
     * @return bool
     */
    public function order_cancel()
    {
        $id = $this->input->post('id');
        $orderDetail = $this->get_one_order_info($id);
        if(!$orderDetail)
        {
            $this->show_message(false, '订单不存在', '');return FALSE;
        }
        if($orderDetail['order_status'] ==0 || $orderDetail['order_status'] == 3)
        {
            if($this->waimai_order_model->where(array('id'=>$id))->edit(array('order_status'=>-1,'end_time'=>time())))
            {
                $result['success'] = 1;
                $result['msg'] = '修改成功';

                //修改订单统计表
                //$this->load->model('waimai_order_statistics_model');
                //通过创建订单的时间得到当天开始时间
                $starttime = strtotime(date('Y-m-d',$orderDetail['add_time']));
                $this->db
                    ->where(array('site_id'=>$this->site_id,'store_id'=>$orderDetail['store_id'],'add_time'=>$starttime))
                    ->set('valid_order', 'valid_order+1', FALSE)
                    ->set('invalid_order', 'invalid_order-1', FALSE)
                    ->update('waimai_order_statistics');
            }
            else
            {
                $result['success'] = 0;
                $result['msg'] = '修改失败';
            }
        }
        else
        {
            $result['success'] = 0;
            $result['msg'] = '不能取消当前状态下的订单';
        }
        echo json_encode($result);
        exit;
    }

    /**
     * @name 订单状态改为已付款
     * @return bool
     */
    public function order_payed()
    {
        $id = $this->input->post('id');
        $orderDetail = $this->get_one_order_info($id);
        if(!$orderDetail)
        {
            $this->show_message(false, '订单不存在', '');return FALSE;
        }
        //判断订单是否可以改成已支付状态
        if($orderDetail['order_status']==0)
        {
            if($this->waimai_order_model->where(array('id'=>$id))->edit(array('order_status'=>1,'pay_time'=>time())))
            {
                $result['success'] = 1;
                $result['msg'] = '修改成功';
            }
            else
            {
                $result['success'] = 0;
                $result['msg'] = '修改失败';
            }
        }
        else
        {
            $result['success'] = 0;
            $result['msg'] = '当前订单不支持修改成已付款';
        }
        echo json_encode($result);
        exit;
    }

    /**
     * @name 将订单状态改为配送中
     * @return bool
     */
    public function order_send()
    {
        $id = $this->input->post('id');
        $orderDetail = $this->get_one_order_info($id);
        if(!$orderDetail)
        {
            $this->show_message(false, '订单不存在', '');return FALSE;
        }
        if($orderDetail['order_status']==1)
        {
            if($this->waimai_order_model->where(array('id'=>$id))->edit(array('order_status'=>2)))
            {
                $result['success'] = 1;
                $result['msg'] = '修改成功';
            }
            else
            {
                $result['success'] = 0;
                $result['msg'] = '修改失败';
            }
        }
        else
        {
            $result['success'] = 0;
            $result['msg'] = '当前订单不支持修改成配送中';
        }
        echo json_encode($result);
        exit;
    }

    /**
     * @name 将订单状态改为交易成功
     * @return bool
     */
    public function order_received()
    {
        $id = $this->input->post('id');
        $orderDetail = $this->get_one_order_info($id);
        if(!$orderDetail)
        {
            $this->show_message(false, '订单不存在', '');return FALSE;
        }
        if($orderDetail['order_status']==3 || $orderDetail['order_status']==2)
        {
            if($this->waimai_order_model->where(array('id'=>$id))->edit(array('order_status'=>4,'confirm_time'=>time(),'end_time'=>time())))
            {
                $result['success'] = 1;
                $result['msg'] = '修改成功';
                //修改订单统计表

                //通过创建订单的时间得到当天开始时间
                $starttime = strtotime(date('Y-m-d',$orderDetail['add_time']));
                $this->db
                    ->where(array('site_id'=>$this->site_id,'store_id'=>$orderDetail['store_id'],'add_time'=>$starttime))
                    ->set('valid_order', 'valid_order+1', FALSE)
                    ->set('invalid_order', 'invalid_order-1', FALSE)
                    ->set('total_price','total_price+'.$orderDetail['all_price'],false)
                    ->set('avg_price','total_price/total_order',false)
                    ->update('waimai_order_statistics');
            }
            else
            {
                $result['success'] = 0;
                $result['msg'] = '修改失败';
            }
        }
        else
        {
            $result['success'] = 0;
            $result['msg'] = '当前订单不支持修改成配送中';
        }
        echo json_encode($result);
        exit;
    }

    /**
     * 修改商家备注
     */
    public function order_cmark()
    {
        $id = $this->input->post('id');
        $orderDetail = $this->get_one_order_info($id);
        if(!$orderDetail)
        {
            $this->show_message(false, '订单不存在', '');return FALSE;
        }
        $cmark = $this->input->post('cmark');
        if($this->waimai_order_model->where(array('id'=>$id))->edit(array('cmark'=>$cmark)))
        {
            $result['success'] = 1;
            $result['msg'] = '备注修改成功';
        }
        else
        {
            $result['success'] = 0;
            $result['msg'] = '操作失败';
        }
        echo json_encode($result);
        exit;
    }
    
    //订单列表
    public function order_list($store_id)
    {
        $res = $this->get_store($store_id);
        if( !$res ){
            $this->show_message(false, '非法操作', '/c/waimai_store');return FALSE;
        }
        $this->load->model('waimai_order_model');
        
        $where_in = $like = $search = array();$is_search = 0;
        $search['sear_type'] = $this->input->get('sear_type');
        $search['sear_keyword'] = $this->input->get('sear_keyword');
        $search['start_time'] = trim($this->input->get('start_time'));
        $search['end_time'] = trim($this->input->get('end_time'));
        $search['status'] = $this->input->get('status');
        $this->data['search'] = $search;
        
        $search_url = site_url($this->uri->uri_string().'?');
        if( $search&&$search['sear_keyword'] ){
            switch($search['sear_type']){
                case 1:
                    $like['account.name'] = $search['sear_keyword'];
                    break;
                case 2:
                    $like['account.mobile'] = $search['sear_keyword'];
                    break;
                case 3:
                    $like['waimai_order.order_sn'] = $search['sear_keyword'];
                    break;
                default:break;
            }
        }
        if( $search['start_time'] ){
            $where['waimai_order.add_time <'] = strtotime($search['start_time']);
        }
        if( $search['end_time'] ){
            $where['waimai_order.add_time >'] = strtotime($search['end_time']);
        }
        if( $search['status']!='' ){
            if( $search['status']==-2 ){
                $where_in = array(1,3);
            }else{
                $where['waimai_order.order_status'] = $search['status'];
            }
        }
        if( $search ){
            $is_search = 1;
        }
        
        $where['site_id'] = $this->site_id;
        $where['store_id'] = $store_id;
        
        $this->data['is_search'] = $is_search;
        
        $this->waimai_order_model->join('account','account.id=waimai_order.uid');
        $where_in && $this->waimai_order_model->where_in('waimai_order.order_status',$where_in);
        $total_rows = $this->waimai_order_model->where($where)->like($like)->order_by('waimai_order.id desc')->count();
        
        $pager = $this->_pager($total_rows, array('per_page'=>15));
        
        $this->waimai_order_model->select('waimai_order.*,account.name,account.mobile')
                ->join('account','account.id=waimai_order.uid');
        $where_in && $this->waimai_order_model->where_in('waimai_order.order_status',$where_in);
        $list = $this->waimai_order_model->where($where)->like($like)->order_by('waimai_order.id desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->find_all();
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->load->view($this->dcm, $this->data);
    }

    /**
     * 订单导出
     */
    public function order_export()
    {
        $sid = $this->input->get_post('sid');
        $res = $this->get_store($sid);
        if( !$res ){
            $this->show_message(false, '非法操作', '/c/waimai_store');return FALSE;
        }
        $this->load->model('waimai_order_model');

        $where_in = $like = $search = array();$is_search = 0;
        $search['sear_type'] = $this->input->get('sear_type');
        $search['sear_keyword'] = $this->input->get('sear_keyword');
        $search['start_time'] = trim($this->input->get('start_time'));
        $search['end_time'] = trim($this->input->get('end_time'));
        $search['status'] = $this->input->get('status');
        $this->data['search'] = $search;

        $search_url = site_url($this->uri->uri_string().'?');
        if( $search&&$search['sear_keyword'] ){
            switch($search['sear_type']){
                case 1:
                    $like['account.name'] = $search['sear_keyword'];
                    break;
                case 2:
                    $like['account.mobile'] = $search['sear_keyword'];
                    break;
                case 3:
                    $like['waimai_order.order_sn'] = $search['sear_keyword'];
                    break;
                default:break;
            }
        }
        if( $search['start_time'] ){
            $where['waimai_order.add_time <'] = strtotime($search['start_time']);
        }
        if( $search['end_time'] ){
            $where['waimai_order.add_time >'] = strtotime($search['end_time']);
        }
        if( $search['status']!='' ){
            if( $search['status']==-2 ){
                $where_in = array(1,3);
            }else{
                $where['waimai_order.order_status'] = $search['status'];
            }
        }
        if( $search ){
            $is_search = 1;
        }

        $where['waimai_order.site_id'] = $this->site_id;
        $where['waimai_order.store_id'] = $sid;

        $this->waimai_order_model->select('waimai_order.*,account.name,account.mobile')
            ->join('account','account.id=waimai_order.uid');
        $where_in && $this->waimai_order_model->where_in('waimai_order.order_status',$where_in);
        $orders = $this->waimai_order_model->where($where)->like($like)->find_all();

        $orders = $orders ? $orders : array();
        $order_status = $this->order_status_list;
        foreach($orders as &$order) {
            $order['add_time'] = date('Y-m-d H:i:s', $order['add_time']);
            $order['pay_time'] = $order['pay_time'] ? date('Y-m-d H:i:s', $order['pay_time']) : '';
            $order['status_name'] = $order_status[$order['order_status']];

            //订单菜品
            $this->load->model('waimai_order_dishes_model');
            $item_list = $this->waimai_order_dishes_model->where(array('site_id'=>$this->site_id,'order_id'=>$order['id']))->find_all();

            $items = '';
            foreach($item_list as $item) {
                $items .= "菜品：".$item['dishes_name'].", 单价：".$item['dishes_price'].", 数量：".$item['dishes_num']."; ";
            }
            $items = $items ? $items : '尚无订单商品';
            $order['items'] = $items;

            /*//联系人信息
            $this->load->model('waimai_address_model');
            $address = $this->waimai_address_model->where(array('site_id'=>$this->site_id,'id'=>$order['address_id']))->find();
            $order['consignee_info'] = '姓名：'. $address['name'] .', 地址：'. $address['address'] .', 手机：' . $address['mobile'];
            */

            //联系人信息
            if( !$order['name'] ){
                $this->load->model('waimai_address_model');
                $address = $this->waimai_address_model->where(array('site_id'=>$this->site_id,'id'=>$order['address_id']))->find();
                if( !$address ){
                    $address['name'] = $address['mobile'] = $address['address'] = '';
                }
            }else{
                $address['name'] = $order['name'];
                $address['mobile'] = $order['mobile'];
                $address['address'] = $order['address'];
            }
            $order['consignee_info'] = '姓名：'. $address['name'] .', 地址：'. $address['address'] .', 手机：' . $address['mobile'];

        }

        $fields = array(
            '#'=>'#',
            'order_sn'=>'订单号',
            'add_time'=>'订单时间',
            'mobile'=>'手机号码',
            'all_price'=>'总价',
            'payment_name'=>'支付方式',
            'pay_time'=>'付款时间',
            'reach_time' => '送餐时间',
            'status_name'=>'订单状态',
            'items'=>'订单商品',
            'consignee_info'=>'收货人信息',
            'mark'=>'用户备注',
            'cmark'=>'商家备注'
        );

        $this->excel_export($this->data['store']['address'].'订单列表', '订单列表', $fields, $orders);
    }

    //获取外卖配置
    private function get_config()
    {
        $where = array(
            'site_id' => $this->site_id
        );
        $waimai = $this->waimai_model->where($where)->find();
        $waimai = $waimai ? $waimai : array();
        $this->data['waimai'] = $waimai;
        return $waimai;
    }

    //获得一个订单详情
    private function get_one_order_info($id)
    {
        $where = array(
            'waimai_order.site_id'  => $this->site_id,
            'waimai_order.id' => $id
        );
        $orderDetail = $this->waimai_order_model
            ->select('waimai_order.*,waimai_store.address as store_address')
            ->join('waimai_store','waimai_order.store_id=waimai_store.id')
            ->where($where)->find();
        if(!$orderDetail)
        {
            return false;
        }
        else
        {
            return $orderDetail;
        }
    }
    //检查图片格式
    public function _check_image($image) {
        if ($image) {
            if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
                $this->form_validation->set_message('_check_image', '图片地址格式错误');
                return FALSE;
            }
        }
        return TRUE;
    }
} 