<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Class Menu
 * @property Model_menu $model_menu
 * @property Model_app_config $model_app_config
 * @property Curl $curl
 */

class Menu extends C_Controller {

    private $errorCodeArr = array(
        '-1' => '系统繁忙',
        '40001' => '验证失败',
        '40002' => '不合法的凭证类型',
        '40013' => '不合法的APPID',
        '40014' => '不合法的access_token',
        '40015' => '不合法的菜单类型',
        '40016' => '不合法的按钮个数',
        '40017' => '不合法的按钮个数',
        '40018'	=> '不合法的按钮名字长度',
        '40019' => '不合法的按钮KEY长度',
        '40020'	=> '不合法的按钮URL长度',
        '40021'	=> '不合法的菜单版本号',
        '40022'	=> '不合法的子菜单级数',
        '40023' => '不合法的子菜单按钮个数',
        '40024'	=> '不合法的子菜单按钮类型',
        '40025'	=> '不合法的子菜单按钮名字长度',
        '40026'	=> '不合法的子菜单按钮KEY长度',
        '40027'	=> '不合法的子菜单按钮URL长度',
        '40028'	=> '不合法的自定义菜单使用用户',
        '42001' => '请求超时',//access_token超时
        '48001' => '功能未授权',//api功能未授权
        '50001' => '用户未授权',//用户未授权该api
    );

    public function __construct() {
        parent::__construct();
        $this->load->model('model_menu');
        $this->load->model('model_app_config');
    }

    //微信自定义菜单
    public function index() {

        $app_config = $this->model_app_config->get_row(array('type'=>'menu', 'user_id'=>$this->site_info['id']));
        $menu_config['button'] = array();

        if($app_config)
        {
            $menu_config = json_decode($app_config['config'], TRUE);
            $menu_config['button'] = $menu_config;
        }
        //print_r($menu_config);
        $this->data['menu_config'] = $menu_config;
        //print_r($menu_config);exit;
        $this->load->view($this->dcm, $this->data);
        /*
         if($postData['button'])
            {
                $postData = urldecode(json_encode($this->var_url_encode($postData)));


        $tmpCreateInfo = $this->curl->post("https://api.weixin.qq.com/cgi-bin/menu/create?access_token=".$accessToken,$postData);
        $tmpCreateInfo = json_decode($tmpCreateInfo,true);
        if($tmpCreateInfo['errcode'] !=0 )
        {
            if(isset($this->errorCodeArr[$tmpCreateInfo['errcode']])){
                return $this->show_message(false, $this->errorCodeArr[$tmpCreateInfo['errcode']], '/c/menu', 1);
            }else{
                return $this->show_message(false, '菜单创建失败，腾讯微信错误代码:'.$tmpCreateInfo['errcode'].'错误详情:'.$tmpCreateInfo['errmsg'], '/c/menu', 1);
            }
        }
    }
         */
    }

    /**
     * 保存菜单
     */
    public function save_menu()
    {
        $menu = $this->input->post('menu');
        if($menu){
            //这次循环为了排序
            $rank = array();
            foreach ($menu as $key => &$row) {
                $rank[$key] = (isset($row['rank']) && $row['rank']) ? $row['rank'] : $key;
                if(isset($row['sub_menu'])){
                    $srank = array();
                    foreach($row['sub_menu'] as $sk=>$sr) {
                        $srank[$sk] = ($sr['rank'] == '') ? $sk : $sr['rank'];
                    }
                    array_multisort($srank, SORT_ASC, $row['sub_menu']);
                }
            }
            array_multisort($rank, SORT_ASC, $menu);

            foreach($menu as $mk => $mr)
            {
                //如果没有子菜单
                if(isset($mr['keyword']) && $mr['keyword'] && !isset($mr['sub_menu']))
                {
                    //修改状态
                    if(isset($mr['key']) && $mr['key'])
                    {
                        $main_keyword = $this->model_menu->get_row(array('id'=>$mr['key'],'user_id'=>$this->site_info['id']));
                        if($main_keyword)
                        {
                            $m_key = $mr['key'];
                            if($main_keyword['keyword'] != $mr['keyword'])
                            {
                                $this->model_menu->update(array('id'=>$main_keyword['id']), array('keyword'=>$mr['keyword']));
                            }
                        }
                        else
                        {
                            $add_set['user_id'] = $this->site_info['id'];
                            $add_set['keyword'] = $mr['keyword'];
                            $add_set['dt_add'] = $add_set['dt_update'] = date('Y-m-d H:i:s');
                            $m_key = $this->model_menu->add($add_set, TRUE);
                        }
                    }
                    else
                    {
                        $add_set['user_id'] = $this->site_info['id'];
                        $add_set['keyword'] = $mr['keyword'];
                        $add_set['dt_add'] = $add_set['dt_update'] = date('Y-m-d H:i:s');
                        $m_key = $this->model_menu->add($add_set, TRUE);
                    }

                    $menu[$mk]['key'] = $m_key;
                }

                //更新或添加子菜单
                if(isset($mr['sub_menu']) && is_array($mr['sub_menu']))
                {
                    foreach($mr['sub_menu'] as $sk => $sr)
                    {
                        //修改状态
                        if(isset($sr['key']) && $sr['key'])
                        {
                            $sub_menu = $this->model_menu->get_row(array('id'=>$sr['key'],'user_id'=>$this->site_info['id']));
                            if($sub_menu)
                            {
                                $s_key = $sub_menu['id'];
                                if($sr['keyword'] != $sub_menu['keyword'])
                                {
                                    $this->model_menu->update(array('id'=>$sub_menu['id']), array('keyword'=>$sr['keyword']));
                                }
                            }
                            else
                            {
                                $sub_menu_data['user_id'] = $this->site_info['id'];
                                $sub_menu_data['keyword'] = $sr['keyword'];
                                $sub_menu_data['dt_add'] = $sub_menu_data['dt_update'] = date('Y-m-d H:i:s');
                                $s_key = $this->model_menu->add($sub_menu_data, TRUE);
                            }
                        }
                        else
                        {
                            $sub_menu_data['user_id'] = $this->site_info['id'];
                            $sub_menu_data['keyword'] = $sr['keyword'];
                            $sub_menu_data['dt_add'] = $sub_menu_data['dt_update'] = date('Y-m-d H:i:s');
                            $s_key = $this->model_menu->add($sub_menu_data, TRUE);
                        }

                        $menu[$mk]['sub_menu'][$sk]['key'] = $s_key;
                    }
                }
            }
            $config['menu'] = $menu;
            $save_config = json_encode($config, JSON_UNESCAPED_UNICODE);

            $app_config = $this->model_app_config->get_row(array('type'=>'menu', 'user_id'=>$this->site_info['id']));
            if($app_config)
            {
                $this->model_app_config->update(array('id'=>$app_config['id']), array('config'=>$save_config));
            }
            else
            {
                $data_set['config'] = $save_config;
                $data_set['type'] = 'menu';
                $data_set['user_id'] = $this->site_info['id'];
                $this->model_app_config->add($data_set);
            }
            $this->show_message(true,'菜单创建成功','/c/menu');
        }
        else
        {
            $app_config = $this->model_app_config->get_row(array('type'=>'menu', 'user_id'=>$this->site_info['id']));
            if($app_config)
            {
                $this->model_app_config->update(array('id'=>$app_config['id']), array('config'=>''));
                $this->show_message(true,'菜单修改成功','/c/menu');
            }else{
                $this->show_message(false,'菜单不能为空哦','');
            }
        }
    }

    //创建菜单

    public function create_menu()
    {
        $app_config = $this->model_app_config->get_row(array('type'=>'menu', 'user_id'=>$this->site_info['id']));
        if(!$app_config)
        {
            $this->ajax_return(array('ret'=>101,'msg'=>'请先稍加自定义菜单'));
        }
        $menu = json_decode($app_config['config'],true);
        if($menu['menu'])
        {
            //从token服务器获取数据
            $this->load->library('Mongo_db');
            $wx = $this->mongo_db->where(array('site_id'=>$this->site_info['id']))->get_one(MONGO_WX_SET);
            if( !$wx ){
                $this->ajax_return(array('ret'=>102,'msg'=>'获取微信配置失败'));
            }
            if( isset($wx['appid'])&&$wx['appid'] ){
                $this->load->library('wbcurl');
                $response = $this->wbcurl->simple_post(TOKEN_WX_SERVER . 'info', array('app_id'=>$wx['appid']));
                $response = json_decode($response,true);
                if( $response['ret']!=0 ){
                    $this->ajax_return(array('ret'=>$response['ret'],'msg'=>$response['msg']));
                }
                if( !(1&$response['ability_rank']) ){//没有菜单
                    $this->ajax_return(array('ret'=>2565,'msg'=>'您当前的appid没有创建菜单的权限'));
                }
            }else{
                $this->ajax_return(array('ret'=>102,'msg'=>'请先配置微信appid,secret信息'));
            }

            //查询出已经保存的menu key
            $allKey = $this->model_menu->get_all(array('user_id'=>$this->site_info['id']));
            $all_menu_key = array();
            if($allKey)
            {
                foreach($allKey as $all)
                {
                    $all_menu_key[$all['id']] = $all;
                }
            }

            //组合成微信需要的菜单格式,并找出沉余的key
            //print_r($menu['menu']);exit;
            $button = array();
            $used_key = array();
            foreach($menu['menu'] as $mk => $mr)
            {
                $button[$mk]['name'] = $mr['name'];
                //无子菜单
                if(isset($mr['keyword']) && $mr['keyword'] && !isset($mr['sub_menu']))
                {
                    //如果是链接
                    if($this->is_url($mr['keyword']))
                    {
                        $button[$mk]['type'] = 'view';
                        $button[$mk]['url'] = $mr['keyword'];
                    }
                    else
                    {
                        $button[$mk]['type'] = 'click';
                        $button[$mk]['key'] = $mr['key'];
                    }
                    //未使用的key
                    if(isset($all_menu_key[$mr['key']]))
                    {
                        $used_key[] = $mr['key'];
                    }
                }
                else
                {
                    if( isset($mr['sub_menu'])&&$mr['sub_menu'] ){
                        foreach($mr['sub_menu'] as $sk => $sr)
                        {
                            if($sr['keyword'] && $this->is_url($sr['keyword']))
                            {
                                $button[$mk]['sub_button'][$sk]['type'] = 'view';
                                $button[$mk]['sub_button'][$sk]['name'] =  $sr['name'];
                                $button[$mk]['sub_button'][$sk]['url'] = $sr['keyword'];
                            }
                            else
                            {
                                $button[$mk]['sub_button'][$sk]['type'] = 'click';
                                $button[$mk]['sub_button'][$sk]['name'] =  $sr['name'];
                                $button[$mk]['sub_button'][$sk]['key'] = $sr['key'];
                            }
                            //未使用的key
                            if(isset($all_menu_key[$sr['key']]))
                            {
                                $used_key[] = $sr['key'];
                            }
                        }
                    }
                }
            }

            //查询
            /*
            $response_menu = $this->wechat->menu_get($response['token']);
            print_r($response_menu);exit;
            */
            $this->load->library('wechat',array('app_id'=>$wx['appid'],'secret'=>$wx['appscret']));
            $result = $this->wechat->menu_create($button,$response['token']);

            //成功
            if(isset($result['errcode']) && $result['errcode'] == 0)
            {
                //删除沉余的key
                if(count($used_key) > 0)
                {
                    $where_set['notin:id'] = $used_key;
                    $where_set['user_id'] = $this->site_info['id'];
                    $this->model_menu->delete($where_set);
                }
                $this->ajax_return(array('ret'=>0,'msg'=>'自定义菜单生成成功，请打开微信体验'));
            }
            else
            {
                $msg = $result['errcode'].$result['errmsg'];
                if( isset($this->errorCodeArr[$result['errcode']]) ){
                    $msg = $result['errcode'].' '.$this->errorCodeArr[$result['errcode']];
                }
                $this->ajax_return(array('ret'=>102,'msg'=>$msg));
            }
        }
        else
        {
            $this->ajax_return(array('ret'=>101,'msg'=>'请先稍加自定义菜单'));
        }
    }

    public function delete_menu()
    {
        $this->load->library('Mongo_db');
        $wx = $this->mongo_db->where(array('site_id'=>$this->site_info['id']))->get_one(MONGO_WX_SET);
        if( !$wx ){
            $this->ajax_return(array('ret'=>102,'msg'=>'请先配置微信appid,secret信息'));
        }
        if( isset($wx['appid'])&&$wx['appid'] ){
            $this->load->library('wbcurl');
            $response = $this->wbcurl->simple_post(TOKEN_WX_SERVER . 'info', array('app_id'=>$wx['appid']));
            $response = json_decode($response,true);
            if( $response['ret']!=0 ){
                $this->ajax_return(array('ret'=>$response['ret'],'msg'=>$response['msg']));
            }
            if( !(1&$response['ability_rank']) ){//没有菜单
                $this->ajax_return(array('ret'=>2565,'msg'=>'您当前的appid没有设置自定义菜单的权限'));
            }
        }else{
            $this->ajax_return(array('ret'=>102,'msg'=>'请先配置微信appid,secret信息'));
        }


        $this->load->library('wechat',array('app_id'=>$wx['appid'],'secret'=>$wx['appscret']));
        $result = $this->wechat->menu_delete($response['token']);

        //成功
        if(isset($result['errcode']) && $result['errcode'] == 0)
        {
            $this->ajax_return(array('ret'=>0,'msg'=>'自定义菜单删除成功'));
        }
        else
        {
            $msg = $result['errcode'].$result['errmsg'];
            if( isset($this->errorCodeArr[$result['errcode']]) ){
                $msg = $result['errcode'].' '.$this->errorCodeArr[$result['errcode']];
            }
            $this->ajax_return(array('ret'=>102,'msg'=>$msg));
            //$this->ajax_return(array('ret'=>102,'msg'=>$result['errcode'].$result['errmsg']));
        }

    }

    private function var_url_encode($var) {
        if (is_array ( $var )) {
            foreach ( $var as $k => $v ) {
                if (is_scalar ( $v ))
                {
                    $var [$k] = urlencode ( $v );
                }
                else {
                    $var [$k] = $this->var_url_encode ( $v );
                }
            }
        }
        else {
            $var = urlencode ( $var );
        }
        return $var;
    }

    /**
     * 判断是否是外链
     * @param $str
     * @return int
     */
    private function is_url($str)
    {
        return preg_match("/^(http|https):\/\/[A-Za-z0-9\-\_]+\.[A-Za-z0-9]+[\/=\?%\-&_~`@[\]\’:+!]*([^<>\"])*$/", $str);
    }

    //支付宝自定义菜单----列表
    public function alipay_index() {
        $response = $this->postAlipay('get');
        if( !$response ){
            return $this->show_message(false, '您没有配置支付宝服务窗，请配置后再来...', '/c/menu/index');
        }
        if( isset($response['error_response']) ){
            return $this->show_message(false, $response['error_response']['sub_msg'], '/c/menu/index');
        }
        $getResponse = $response['alipay_mobile_public_menu_get_response'];
        if($getResponse['code'] == 200 )
        {
            $menu_content = json_decode($getResponse['menu_content'], TRUE);
            $this->data['button'] = $menu_content['button'];
            $this->load->view($this->dcm, $this->data);
        }else{
            return $this->show_message(false, $getResponse['msg'].'，支付宝错误代码:'.$getResponse['code'], '/c/menu/alipay_index', 1);
        }
    }


    //支付宝自定义菜单----更新
    public function alipay_update() {
        $menu = $this->input->post('menu');
        $button = array();
        if($menu){
            foreach($menu as $k => $v){
                if(isset($v['name']) && !empty($v['name'])){
                    $button['button'][$k]['name'] = $v['name'];
                    isset($v['actionParam']) ? $button['button'][$k]['actionParam'] = $v['actionParam'] : '';
                    isset($v['actionParam']) ? ($button['button'][$k]['actionType'] = $this->is_url($v['actionParam']) ? 'link' : 'out') : '';
                    if(isset($v['sub_menu'])){
                        foreach($v['sub_menu'] as $kk => $vv){
                            if(isset($vv['name']) && !empty($vv['name'])){
                                $button['button'][$k]['subButton'][$kk]['name'] = $vv['name'];
                                $button['button'][$k]['subButton'][$kk]['actionParam'] = $vv['actionParam'];
                                $button['button'][$k]['subButton'][$kk]['actionType'] = $this->is_url($vv['actionParam']) ? 'link' : 'out';
                            }
                        }
                    }
                }
            }

            $biz_content = json_encode($button);
            //无数据增加接口，有数据更新接口
            $response = $this->postAlipay('get');
            if( !$response ){
                return $this->show_message(false, '您没有配置支付宝服务窗，请配置后再来...', '/c/menu/index');
            }
            if( isset($response['error_response']) ){
                return $this->show_message(false, $response['error_response']['sub_msg'], '/c/menu/index');
            }
            $getResponse = $response['alipay_mobile_public_menu_get_response'];
            if($getResponse['code'] == 200 )
            {
                $response = $this->postAlipay('update', $biz_content);
                $updateResponse = $response['alipay_mobile_public_menu_update_response'];
                if($updateResponse['code'] == 200 )
                {
                    return $this->show_message(TRUE, $updateResponse['msg'], '/c/menu/alipay_index');
                }else{
                    return $this->show_message(false, $updateResponse['msg'].'，支付宝错误代码:'.$updateResponse['code'], '/c/menu/alipay_index', 1);
                }
            }else{
                $response = $this->postAlipay('add', $biz_content);
                $addResponse = $response['alipay_mobile_public_menu_add_response'];
                if($addResponse['code'] == 200 )
                {
                    return $this->show_message(TRUE, $addResponse['msg'], '/c/menu/alipay_index');
                }else{
                    return $this->show_message(false, $addResponse['msg'].'，支付宝错误代码:'.$addResponse['code'], '/c/menu/alipay_index', 1);
                }
            }
        }
    }

    /**
     *
     * @author Qianc
     * @date 2014-7-24
     * @description 传递数据到支付宝对接
     */
    private function postAlipay($action = 'get', $biz_content = ''){

        $this->load->library('Mongo_db');
        $alipay = $this->mongo_db->where(array('site_id'=>$this->site_info['id']))->get_one(MONGO_ALIPAY_SET);
        if( !$alipay ){
            return false;
        }
        $this->load->library('wbcurl');
        $post_data = array('app_id'=>$alipay['appid']);
        $response = $this->wbcurl->simple_post(TOKEN_ALIPAY_SERVER . 'info', $post_data);
        $response = json_decode($response,true);
        if( $response['ret']!=0 ){
            return false;
        }else{
            $appid = $alipay['appid'];
            $private_key = $response['init_private_key'];
        }

        /*$app_config = $this->alipay_config_model->get_row(array('site_id'=>$this->site_info['id']));
        if( !$app_config ){
            return false;
        }
        $appid = $app_config['appid'];
        $private_key = $app_config['private_key'];*/

        $timeStamp = date("Y-m-d H:i:s");
        switch($action) {
            case 'get':
                $params = array(
                    'method'=>'alipay.mobile.public.menu.get',
                    'app_id'=>$appid,
                    'sign_type'=>'RSA',
                    'charset'=>'GBK',
                    'timestamp'=>$timeStamp,
                );
                break;
            case 'add':
                $params = array(
                    'method'=>'alipay.mobile.public.menu.add',
                    'app_id'=>$appid,
                    'sign_type'=>'RSA',
                    'charset'=>'GBK',
                    'timestamp'=>$timeStamp,
                    'biz_content'=>$biz_content
                );
                break;
            case 'update':
                $params = array(
                    'method'=>'alipay.mobile.public.menu.update',
                    'app_id'=>$appid,
                    'sign_type'=>'RSA',
                    'charset'=>'GBK',
                    'timestamp'=>$timeStamp,
                    'biz_content'=>$biz_content
                );
                break;
            default:
                $params = array(
                    'method'=>'alipay.mobile.public.menu.get',
                    'app_id'=>$appid,
                    'sign_type'=>'RSA',
                    'charset'=>'GBK',
                    'timestamp'=>$timeStamp,
                );

        }

        //签名,生成sign
        ksort($params);
        reset($params);
        $sign_string = urldecode(http_build_query($params));
        //openssl_private_encrypt($sign_string, $sign, $this->key['private_key']);
        $res = openssl_get_privatekey($private_key);
        $sign = '';//签名
        openssl_sign($sign_string, $sign, $res);
        openssl_free_key($res);
        $sign = base64_encode($sign);
        $params['sign'] = $sign;

        $this->load->library('curl');
        $alipayResponse = $this->curl->post('https://openapi.alipay.com/gateway.do', $params);
        $alipayResponse = iconv('GBK', 'UTF-8', $alipayResponse);
        $alipayResponse = json_decode($alipayResponse, true);
        return $alipayResponse;
    }
}