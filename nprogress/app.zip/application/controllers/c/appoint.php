<?php
/**
 * Author: Qianc
 * CreateTime: 14-9-19 下午3:48
 * Description: 微预约控制器
 */


class appoint extends C_Controller{

    private $site_id = '';

    public function __construct()
    {
        parent::__construct();
        $this->site_id = $this->site_info['id'];
        $this->load->model('address_model');
    }


    /**
     *
     * @author Qianc
     * @date 2014-9-19
     * @description 门店管理
     */
    public function index()
    {
        $where = array();
        $where['status'] = 0;
        $where['wid'] = $this->site_id;;

        $search['keyword'] = $this->input->get('keyword');
        $search['tel'] = $this->input->get('tel');
        $search['appoint_status'] = $this->input->get('appoint_status');

        $search['keyword'] ? $where['name like '] = "%{$search['keyword']}%" : '';
        $search['tel'] ? $where['tel like '] = "%{$search['tel']}%" : '';
        $search['appoint_status'] ? $where['appoint_status'] = $search['appoint_status'] : '';

        $search_url = site_url($this->uri->uri_string().'?');
        $base_url = $search_url.http_build_query($search);
        $this->data['search'] = $search;

        //dump($where);exit;
        $total_rows = $this->address_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$base_url));
        $this->data['page'] = $pager['links'];


        $list = $this->address_model
            ->select('*')
            ->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->where($where)->order_by('rank asc, id desc')->find_all();

        //$list = $this->_index($list);
        $this->data['offset'] = $pager['limit']['offset'];
        $this->data['list'] = $list;

        $this->load->view($this->dcm,$this->data);
    }


    //门店启用/不启用
    public function change_appoint_status($id=0)
    {
        if( !$id ){
            exit(json_encode(array('ret' => 1,'msg' => '非法修改')));
        }

        $where['wid'] = $this->site_id;
        $where['id'] = $id;
        $where['status'] = 0;
        $address = $this->address_model->where($where)->find();
        if( !$address ){
            exit(json_encode(array('ret' => 1,'msg' => '没有找到您要修改的门店')));
        }

        $appoint_status = $address['appoint_status']==1 ? 2 : 1;
        if( $this->address_model->where($where)->edit(array('appoint_status'=>$appoint_status)) ){
            exit(json_encode(array('ret' => 0,'msg' => '修改成功')));
        }else{
            exit(json_encode(array('ret' => 1,'msg' => '修改失败')));
        }
    }

}