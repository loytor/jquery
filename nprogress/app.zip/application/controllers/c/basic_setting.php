<?php
/**
 * Author: Qianc
 * CreateTime: 14-9-12 上午11:27
 * Description:基本设置
 */

class Basic_setting extends C_Controller{

    private $site_id = '';
    private $mongo_wx_set = MONGO_WX_SET;
    private $mongo_alipay_set = MONGO_ALIPAY_SET;
    protected $_token_wx_server = TOKEN_WX_SERVER;
    protected $_token_alipay_server = TOKEN_ALIPAY_SERVER;
    public function __construct() {
        parent::__construct();
        $this->site_id = $this->site_info['id'];
        $this->load->library('Mongo_db');
    }

    /**
     *
     * @author Qianc
     * @date 2014-9-12
     * @description 基本信息
     */
    public function index() {
        if( $this->input->post() ){
            //$this->form_validation->set_rules('mp_username', '公众帐号', 'trim|required');
            if($this->input->post('domain'))
            {
                if($this->site_info['domain'] != $this->input->post('domain'))
                {
                    $this->form_validation->set_message('is_unique', '二级域名已经被使用，请重新设置');
                    $this->form_validation->set_rules('domain', '二级域名', 'trim|required|min_length[4]|max_length[35]|alpha_dash|is_unique[user.domain]');
                }
                else
                {
                    $this->form_validation->set_rules('domain', '二级域名', 'trim|required|min_length[4]|max_length[35]|alpha_dash');
                }
            }

            $this->form_validation->set_rules('logo', '企业LOGO1', 'trim|max_length[255]|callback__check_image');
            $this->form_validation->set_rules('logo2', '企业LOGO2', 'trim|max_length[255]|callback__check_image');
            $this->form_validation->set_rules('cid', '行业', 'trim|max_length[10]|is_natural');
            $this->form_validation->set_rules('code', '快商通', 'trim');
            if($this->form_validation->run())
            {
                $where['id'] = $this->site_id;
                if($this->input->post('domain'))
                {
                    $data_set['domain'] = strtolower($this->form_validation->set_value('domain'));
                    $data_set['has_domain'] = 1;
                    $where['has_domain'] = 0;
                }
                $data_set['logo'] = $this->input->post('logo');
                $data_set['logo2'] = $this->input->post('logo2');
                $data_set['cid'] = $this->input->post('cid') ? $this->input->post('cid') : 0 ;
                $data_set['code'] = $this->input->post('code');

                if($this->user_model->where($where)->edit($data_set))
                {
                    $this->show_message(TRUE, '保存成功', '/c/basic_setting');
                    return FALSE;;
                }
                $this->show_message(FALSE, '保存失败');
            }
            else
            {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '/c/basic_setting');
                }
            }
        }else{
            $this->data['user'] = $this->site_info;
            //获取行业分类
            $this->load->model('trade_cate_model');
            $trade_cate_list = $this->trade_cate_model->get_trade_cate_list_by_level();
            $this->data['trade_cate_list'] = $trade_cate_list;

            $this->load->view($this->dcm,$this->data);
        }
    }

    //检查图片格式
    public function _check_image($image) {
        if ($image) {
            if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
                $this->form_validation->set_message('_check_image', '图片地址格式错误');
                return FALSE;
            }
        }
        return TRUE;
    }

    public function wxTokenInfo(){
        $this->load->library('wbcurl');
        $post_data = array('app_id'=>'wxefe6ec1ec93f8601');
        $response = $this->wbcurl->simple_post($this->_token_wx_server . 'info', $post_data);
        dump($response);exit;
    }

    /**
     *
     * @author Qianc
     * @date 2014-9-12
     * @description 微信信息
     */
    public function wx_info() {
//        $this->load->library('wbcurl');
//        $post_data = array('app_id'=>'wxefe6ec1ec93f8601');
//        $response = $this->wbcurl->simple_post($this->_token_wx_server . 'info', $post_data);
//        dump($response);exit;
//        $response = json_decode($response,true);

        $wx = $this->mongo_db->where(array('site_id'=>$this->site_info['id']))->get_one($this->mongo_wx_set);
        if( $this->input->post() ){
            $this->form_validation->set_rules('hao', '微信号', 'trim|max_length[255]');
            $this->form_validation->set_rules('original_id', '原始ID', 'trim|max_length[255]');
            $this->form_validation->set_rules('appid', 'APPID', 'trim|max_length[255]');
            $this->form_validation->set_rules('appscret', 'APPSCRET', 'trim|max_length[255]');
            $this->form_validation->set_rules('ability_rank', '接口能力', 'trim|max_length[255]');
            $this->form_validation->set_rules('page', '一键关注页面', 'trim|max_length[255]');
            if($this->form_validation->run())
            {
                $data['hao'] = !$this->form_validation->set_value('hao') ? $wx['hao'] : $this->form_validation->set_value('hao');
                $data['original_id'] = $this->form_validation->set_value('original_id');
                $data['appid'] = $this->form_validation->set_value('appid');
                if( $data['appid'] ){
                    $data['appscret'] = $this->form_validation->set_value('appscret');
                }else{
                    $data['appscret'] = '';
                }
                if( $data['appid'] && $data['appscret'] ){
                    $data['ability_rank'] = $this->form_validation->set_value('ability_rank');
                }else{
                    $data['ability_rank'] = 0;
                }
                $data['page'] = $this->form_validation->set_value('page');
                if($wx){
                    $ret = $this->mongo_db->where(array('site_id'=>$this->site_info['id']))->set($data)->update($this->mongo_wx_set);
                }else{
                    $data['site_id'] = $this->site_info['id'];
                    $ret = $this->mongo_db->insert($this->mongo_wx_set, $data);
                }
                //微信信息更新到token服务器
                $ability_rank = 0;
                if($data['appid'] && $data['appscret'] ){
                    switch($this->form_validation->set_value('ability_rank')){
                        case 1:
                            $ability_rank = 1;
                            break;
                        case 2:
                            $ability_rank = 3;
                            break;
                        case 4:
                            $ability_rank = 7;
                            break;
                        case 8:
                            $ability_rank = 15;
                            break;
                        default:
                            $ability_rank = 0;
                    }
                }
                if($ret)
                {
                    //将信息更新到user表
                    $this->user_model->where(array('id'=>$this->site_info['id']))->edit(array('mp_username'=>$data['hao']));
                    $response = '';
                    $wx = $this->mongo_db->where(array('site_id'=>$this->site_info['id']))->get_one($this->mongo_wx_set);
                    $wx['appid'] = isset($wx['appid']) ? $wx['appid'] : '';
                    $wx['appscret'] = isset($wx['appscret']) ? $wx['appscret'] : '';
                    if($wx['appid'] && $wx['appscret']){
                        $response = $this->wxUpdateToken($wx['appid'], $wx['appscret'], $ability_rank);
                    }
                    if(isset($response['ret']) && $response['ret'] > 0)
                    {
                        $this->show_message(FALSE, $response['msg']);
                    }
                    else
                    {
                        $this->show_message(TRUE, '保存成功', '/c/basic_setting/wx_info');
                    }
                    return FALSE;;
                }
                $this->show_message(FALSE, '保存失败');
            }
            else
            {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '/c/basic_setting/wx_info');
                }
            }
        }else{
            //$this->mongo_db->where(array('site_id'=>$this->site_info['id']))->delete($this->mongo_wx_set);
            $wx = $this->mongo_db->where(array('site_id'=>$this->site_info['id']))->get_one($this->mongo_wx_set);
            $wx['hao'] = isset($wx['hao']) ? $wx['hao'] : '';
            $wx['original_id'] = isset($wx['original_id']) ? $wx['original_id'] : '';
            $wx['appid'] = isset($wx['appid']) ? $wx['appid'] : '';
            $wx['appscret'] = isset($wx['appscret']) ? $wx['appscret'] : '';
            $wx['ability_rank'] = isset($wx['ability_rank']) ? $wx['ability_rank'] : '';
            $wx['page'] = isset($wx['page']) ? $wx['page'] : '';

            $wx['api_url'] = full_url('/api/'.$this->site_info['username'], 'w');
            $wx['api_token'] = $this->site_info['token'];
            $wx['author2_url'] = $this->site_info['domain'].'.bama555.com';
            $this->data['wx'] = $wx;

            $this->load->view($this->dcm,$this->data);
        }
    }

    /**
     *
     * @author Qianc
     * @date 2014-9-13
     * @description 微信信息更新到token服务器
     */
    protected function wxUpdateToken($appid, $appscret, $ability_rank) {
        $this->load->library('wbcurl');
        $post_data = array('app_id'=>$appid, 'secret'=>$appscret, 'ability_rank'=>$ability_rank);
        $response = $this->wbcurl->simple_post($this->_token_wx_server . 'update', $post_data);
        $response = json_decode($response,true);
        return $response;
    }

    /**
     *
     * @author Qianc
     * @date 2014-9-12
     * @description 支付宝服务窗
     */
    public function alipay_info() {
        if( $this->input->post() ){
            $this->form_validation->set_rules('appid', 'APPID', 'trim|required|max_length[255]');
            if($this->form_validation->run())
            {
                $alipay = $this->mongo_db->where(array('site_id'=>$this->site_info['id']))->get_one($this->mongo_alipay_set);
                $data['appid'] = !$this->form_validation->set_value('appid') ? $alipay['appid'] : $this->form_validation->set_value('appid');
                if($alipay){
                    $ret = $this->mongo_db->where(array('site_id'=>$this->site_info['id']))->set($data)->update($this->mongo_alipay_set);
                }else{
                    $data['site_id'] = $this->site_info['id'];
                    $ret = $this->mongo_db->insert($this->mongo_alipay_set, $data);
                }
                if($ret)
                {
                    $this->alipayUpdateToken($this->form_validation->set_value('appid'));
                    $this->show_message(TRUE, '保存成功', '/c/basic_setting/alipay_info');
                    return FALSE;;
                }
                $this->show_message(FALSE, '保存失败');
            }
            else
            {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '/c/basic_setting/alipay_info');
                }
            }
        }else{
            $alipay = $this->mongo_db->where(array('site_id'=>$this->site_info['id']))->get_one($this->mongo_alipay_set);
            $alipay['appid'] = isset($alipay['appid']) ? $alipay['appid'] : '';
            //$alipay['set_id'] = isset($alipay['_id']) ? $alipay['_id'] : '';
            $alipay['purePublicKey'] = $alipay['appid'] ? $this->purePublicKey($alipay['appid']) : '';
            $alipay['api_url'] = full_url('/api_alipay/'.$this->site_info['username'], 'w');
            $this->data['alipay'] = $alipay;

            $this->load->view($this->dcm,$this->data);
        }
    }

    /**
     *
     * @author Qianc
     * @date 2014-9-13
     * @description 支付宝信息更新到token服务器
     */
    protected function alipayUpdateToken($appid) {
        $this->load->library('wbcurl');
        $post_data = array('app_id'=>$appid);
        $response = $this->wbcurl->simple_post($this->_token_alipay_server . 'update', $post_data);
        $response = json_decode($response,true);
        return $response;
    }

    /**
     *
     * @author Qianc
     * @date 2014-9-13
     * @description 支付宝纯净公钥
     */
    protected function purePublicKey($appid) {
        if($appid){
            $this->load->library('wbcurl');
            $post_data = array('app_id'=>$appid);
            $response = $this->wbcurl->simple_post($this->_token_alipay_server . 'info', $post_data);
            $response = json_decode($response,true);
            return isset($response['public_key']) ? $response['public_key'] : '';
        }
    }


} 