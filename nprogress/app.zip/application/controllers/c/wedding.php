<?php
/**
 * Created by PhpStorm.
 * User: lsl
 * Date: 14-6-19
 * Time: 上午11:58
 */

class wedding extends C_Controller {

    private $site_id = '';

    public function __construct()
    {
        parent::__construct();

        $this->site_id = $this->site_info['id'];
        $this->data['country'] = $this->site_info['country'];
        $this->load->model('wedding_config_model');
        $this->load->model('wedding_list_model');
    }

    public function index()
    {
        $config = $this->wedding_config_model->where(array('site_id'=>$this->site_id))->find();
        if( $this->input->post() ){
            $this->form_validation->set_rules('title', '回复标题', 'trim|max_length[50]');
            $this->form_validation->set_rules('img', '回复图片', 'trim|max_length[255]|callback__check_image');
            $this->form_validation->set_rules('codes', '案例喜帖码', 'trim|max_length[30]');
            $this->form_validation->set_rules('description', '登录提示信息', 'trim|max_length[65500]|htmlspecialchars');
            if ( $this->form_validation->run() ){
                $save_data['title'] = $this->form_validation->set_value('title');
                $save_data['img'] = $this->form_validation->set_value('img');
                $save_data['codes'] = $this->form_validation->set_value('codes');
                $save_data['description'] = $this->form_validation->set_value('description');
                //验证codes
                if( $save_data['codes'] ){
                    $temps = explode(',',$save_data['codes']);
                    $temp_array = array();
                    foreach($temps as $val){
                        if( $val ){
                            $temp_array[] = $val;
                        }
                    }
                    if( count($temp_array)>3 ){
                        return $this->show_message(FALSE, '案例喜帖码不能超过3个', '');
                    }
                    $save_data['codes'] = implode(',',$temp_array);
                }
                if( $config ){
                    if( $this->wedding_config_model->where(array('site_id'=>$this->site_id))->edit($save_data) ){
                        return $this->show_message(TRUE, '修改成功', '/c/wedding');
                    }else{
                        return $this->show_message(FALSE, '修改失败', '');
                    }
                }else{
                    $save_data['site_id'] = $this->site_id;
                    $save_data['dt_add'] = time();
                    if( $this->wedding_config_model->add($save_data) ){
                        return $this->show_message(TRUE, '添加成功', '/c/wedding');
                    }else{
                        return $this->show_message(FALSE, '添加失败', '');
                    }
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    return $this->show_message(FALSE, $errors, '');
                }
            }
        }else{
            $this->data['config'] = $config;

            $this->load->view($this->dcm, $this->data);
        }
    }

    public function weddings()
    {
        $where['site_id'] = $this->site_id;
        $where['status'] = 0;
        $search_url = site_url($this->uri->uri_string().'?');
        $total_rows = $this->wedding_list_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$search_url));
        $list = $this->wedding_list_model
            ->select('id,title,code,status')
            ->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->order_by('id desc')->where($where)->find_all();

        if( $list ){
            foreach($list as &$val){
                $val['yewu_url'] = base_url().'c/wedding/details/'.$val['code'];
            }
        }

        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->data['list'] = $list;

        $this->load->view($this->dcm,$this->data);
    }

    public function add()
    {
        if( $this->input->post() ){
            $this->form_validation->set_rules('title', '喜帖标题', 'trim|required|max_length[30]');
            if ( $this->form_validation->run() ){
                $save_data['title'] = $this->form_validation->set_value('title');
                $save_data['code'] = $this->formatNewId();
                $save_data['site_id'] = $this->site_id;
                $save_data['dt_add'] = time();
                if( $this->wedding_list_model->add($save_data) ){
                    return $this->show_message(TRUE, '添加成功', '/c/wedding/weddings');
                }else{
                    return $this->show_message(FALSE, '添加失败', '');
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    return $this->show_message(FALSE, $errors, '');
                }
            }
        }else{
            $this->load->view($this->dcm, $this->data);
        }
    }

    public function edit($id='')
    {
        if( !$wedding=$this->get_one_wedding($id) ){
            return $this->show_message(FALSE, '非法请求', '/c/wedding/weddings');
        }
        if( $this->input->post() ){
            $this->form_validation->set_rules('title', '喜帖标题', 'trim|required|max_length[30]');
            if ( $this->form_validation->run() ){
                $save_data['title'] = $this->form_validation->set_value('title');
                $save_data['dt_update'] = time();
                if( $this->wedding_list_model->where(array('id'=>$wedding['id']))->edit($save_data) ){
                    return $this->show_message(TRUE, '修改成功', '/c/wedding/weddings');
                }else{
                    return $this->show_message(FALSE, '修改失败', '');
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    return $this->show_message(FALSE, $errors, '');
                }
            }
        }else{
            $this->data['info'] = $wedding;
            $this->load->view($this->dcm, $this->data);
        }
    }

    public function delete($id='')
    {
        if( !$wedding=$this->get_one_wedding($id) ){
            return $this->show_message(FALSE, '非法请求', '/c/wedding/weddings');
        }

        if( $this->wedding_list_model->where(array('id'=>$wedding['id']))->edit(array('status'=>1)) ){
            return $this->show_message(TRUE, '删除成功', '/c/wedding/weddings');
        }else{
            return $this->show_message(FALSE, '删除失败', '');
        }
    }


    //业务单编辑
    public function yewudan_edit($id='')
    {
        if( !$wedding=$this->get_one_wedding($id) ){
            return $this->show_message(FALSE, '非法请求', '/c/wedding/weddings');
        }

        if( $this->input->post() ){
            $this->form_validation->set_rules('groom_name', '新郎名字', 'trim|required|max_length[30]');
            $this->form_validation->set_rules('bride_name', '新娘名字', 'trim|required|max_length[30]');
            $this->form_validation->set_rules('wedding_title', '喜帖标题', 'trim|max_length[30]');
            $this->form_validation->set_rules('wedding_img', '首页图片', 'trim|max_length[255]|callback__check_image');
            $this->form_validation->set_rules('tpl', '喜帖模版', 'trim|max_length[30]');
            $this->form_validation->set_rules('background_img', '封面图片', 'trim|max_length[255]|callback__check_image');
            $this->form_validation->set_rules('share_img', '分享图标', 'trim|max_length[255]|callback__check_image');
            $this->form_validation->set_rules('share_intro', '分享描述', 'trim|max_length[200]');
            $this->form_validation->set_rules('video', '视频', 'trim|max_length[65500]|htmlspecialchars');
            $this->form_validation->set_rules('dt_name', '宴会时间名称', 'trim|max_length[50]');
            $this->form_validation->set_rules('dt_day', '宴会时间', 'trim|max_length[100]');
            $this->form_validation->set_rules('address_name', '宴会地点名称', 'trim|max_length[50]');
            $this->form_validation->set_rules('address', '宴会地点', 'trim|max_length[100]');
            $this->form_validation->set_rules('tele_name', '联系我们名称', 'trim|max_length[50]');
            $this->form_validation->set_rules('tele', '联系我们', 'trim|max_length[100]');
            $this->form_validation->set_rules('declarations', '新人寄语', 'trim|max_length[65500]|htmlspecialchars');
            if ( $this->form_validation->run() ){
                $save_data['groom_name'] = $this->form_validation->set_value('groom_name');
                $save_data['bride_name'] = $this->form_validation->set_value('bride_name');
                $save_data['wedding_title'] = $this->form_validation->set_value('wedding_title');
                $save_data['wedding_img'] = $this->form_validation->set_value('wedding_img');
                $save_data['tpl'] = $this->form_validation->set_value('tpl');

                //背景音乐
                $music_is_sys = $this->input->post('music_is_sys');
                if( $music_is_sys ){
                    $music = $this->input->post('music_sys');
                }else{
                    $music = $this->input->post('music');
                }
                $save_data['music'] = $music;
                $save_data['music_is_sys'] = $music_is_sys ? 1 : 0;

                $save_data['background_img'] = $this->form_validation->set_value('background_img');
                $save_data['share_img'] = $this->form_validation->set_value('share_img');
                $save_data['share_intro'] = $this->form_validation->set_value('share_intro');
                $save_data['video'] = $this->form_validation->set_value('video');
                $save_data['declarations'] = $this->form_validation->set_value('declarations');

                //相册
                $album_img = $this->input->post('album_img');
                if( $album_img ){
                    $save_data['album_img'] = json_encode($album_img);
                }
                $save_data['dt_name'] = $this->form_validation->set_value('dt_name');
                $save_data['dt_day'] = $this->form_validation->set_value('dt_day');

                //地址
                $save_data['address_name'] = $this->form_validation->set_value('address_name');
                $save_data['address'] = $this->form_validation->set_value('address');
                $lat = $this->input->post('lat');
                $lng = $this->input->post('lng');
                $save_data['lat'] = $lat;
                $save_data['lng'] = $lng;

                //接待电话
                $save_data['tele_name'] = $this->form_validation->set_value('tele_name');
                $save_data['tele'] = $this->form_validation->set_value('tele');

                $save_data['dt_update'] = time();
                if( $this->wedding_list_model->where(array('id'=>$wedding['id']))->edit($save_data) ){
                    return $this->show_message(TRUE, '修改成功', '/c/wedding/yewudan_edit/'.$id);
                }else{
                    return $this->show_message(FALSE, '修改失败', '');
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    return $this->show_message(FALSE, $errors, '');
                }
            }
        }else{
            $wedding['album_img'] = json_decode($wedding['album_img'], TRUE);
            $this->data['info'] = $wedding;

            //获取模版
            $this->load->config('tpl');
            $config_tpl = $this->config->item('wedding_tpl');
            $this->data['wedding_tpl'] = $config_tpl;

            $this->config->load('music');
            $this->data['music_arr'] = $this->config->item('music');

            //$this->data['music_base_url'] = substr(base_url(),0,strlen(base_url())-1);
            $this->data['music_base_url'] = 'http://image'.BASE_DOMAIN.'/data';

            $this->load->view($this->dcm, $this->data);
        }
    }

    //祝福墙
    public function benison($id='')
    {
        if( !$wedding=$this->get_one_wedding($id) ){
            return $this->show_message(FALSE, '非法请求', '/c/wedding/weddings');
        }

        $this->load->model('wedding_benison_model');
        $where['wedding_id'] = $wedding['id'];
        $search_url = site_url($this->uri->uri_string().'?');
        $total_rows = $this->wedding_benison_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$search_url));
        $list = $this->wedding_benison_model
            ->select('id,img,benison,dt_add,status')
            ->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->order_by('id desc')->where($where)->find_all();

        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->data['list'] = $list;

        $this->load->view($this->dcm,$this->data);
    }

    //屏蔽祝福
    public function benison_status($id='')
    {
        $this->load->model('wedding_benison_model');
        $benison = $this->wedding_benison_model->where(array('id'=>$id))->find();
        if( !$benison ){
            return $this->show_message(FALSE, '非法请求', '/c/wedding/weddings');
        }
        if( !$wedding=$this->get_one_wedding($benison['wedding_id']) ){
            return $this->show_message(FALSE, '非法请求', '/c/wedding/weddings');
        }
        $status = $benison['status'] ? 0 : 1;
        if( $this->wedding_benison_model->where(array('id'=>$benison['id']))->edit(array('status'=>$status)) ){
            return $this->show_message(TRUE, '修改成功', '/c/wedding/benison/'.$wedding['id']);
        }else{
            return $this->show_message(FALSE, '修改失败', '');
        }
    }

    //删除祝福
    public function benison_delete($id='')
    {
        $this->load->model('wedding_benison_model');
        $benison = $this->wedding_benison_model->where(array('id'=>$id))->find();
        if( !$benison ){
            return $this->show_message(FALSE, '非法请求', '/c/wedding/weddings');
        }
        if( !$wedding=$this->get_one_wedding($benison['wedding_id']) ){
            return $this->show_message(FALSE, '非法请求', '/c/wedding/weddings');
        }
        if( $this->wedding_benison_model->where(array('id'=>$benison['id']))->delete() ){
            return $this->show_message(TRUE, '删除成功', '/c/wedding/benison/'.$wedding['id']);
        }else{
            return $this->show_message(FALSE, '修改失败', '');
        }
    }

    //统计
    public function joinbless($id='')
    {
        if( !$wedding=$this->get_one_wedding($id) ){
            return $this->show_message(FALSE, '非法请求', '/c/wedding/weddings');
        }

        $this->load->model('wedding_joinbless_model');
        $where['wedding_id'] = $wedding['id'];
        $search_url = site_url($this->uri->uri_string().'?');
        $total_rows = $this->wedding_joinbless_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$search_url));
        $list = $this->wedding_joinbless_model
            ->select('id,name,mobile,dt_add,has_car,nums')
            ->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->order_by('id desc')->where($where)->find_all();

        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->data['list'] = $list;

        //带车的人数
        $has_car_num = $this->wedding_joinbless_model
            ->where(array('wedding_id'=>$wedding['id'],'has_car'=>1))
            ->count();
        $this->data['has_car_num'] = $has_car_num;

        $tongji = $this->wedding_joinbless_model->where(array('wedding_id'=>$wedding['id']))->sum('nums');
        $this->data['total_rows'] = $tongji;

        $this->data['wedding'] = $wedding;
        $this->load->view($this->dcm,$this->data);
    }

    //统计导出
    public function joinbless_export($id='')
    {
        if( !$wedding=$this->get_one_wedding($id) ){
            return $this->show_message(FALSE, '非法请求', '/c/wedding/weddings');
        }

        $this->load->model('wedding_joinbless_model');
        $where['wedding_id'] = $wedding['id'];
        $list = $this->wedding_joinbless_model
            ->select('id,name,mobile,dt_add,has_car,nums')
            ->order_by('id desc')->where($where)->find_all();
        if( $list ){
            $fields = array(
                '#'=>'#',
                'name' => '姓名',
                'mobile' => '电话',
                'nums' => '赴宴人数',
                'has_car' => '车辆'
            );
            foreach( $list as &$val ){
                $val['has_car'] = $val['has_car'] ? '带车' : '不带车';
            }
            $this->excel_export('赴宴统计', '赴宴统计', $fields, $list);
        }
    }

    //喜帖业务单
    public function details($code='')
    {
        if( !$code ){
            return $this->show_message(FALSE, '非法请求', '/c/wedding/weddings');
        }
        $where['site_id'] = $this->site_id;
        $where['status'] = 0;
        $where['code'] = $code;
        $wedding = $this->wedding_list_model->where($where)->find();

        $this->data['info']['groom_name'] = $wedding['groom_name'];
        $this->data['info']['bride_name'] = $wedding['bride_name'];
        $this->data['info']['code'] = $wedding['code'];
        $this->data['info']['url'] = base_url().'u/wedding';
        $this->data['mp_username'] = $this->site_info['mp_username'];

        $this->load->view($this->dcm,$this->data);
    }

    private function get_one_wedding($id='')
    {
        $where['site_id'] = $this->site_id;
        $where['status'] = 0;
        $where['id'] = $id;
        $wedding = $this->wedding_list_model->where($where)->find();
        return $wedding;
    }


    private function formatNewId() {
        $uid = uniqid("", true);
        $data = time();
        $data .= microtime();
        $hash = strtoupper(hash('ripemd128', $uid . md5(str_shuffle($data))));
        return substr($hash, -5);
    }

    //检查图片格式
    public function _check_image($image) {
        if ($image) {
            if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
                $this->form_validation->set_message('_check_image', '图片地址格式错误');
                return FALSE;
            }
        }
        return TRUE;
    }

    //老数据app_config转换新数据
    public function exchange_data()
    {
        $this->load->model('model_app_config');
        //读取喜帖相关配置
        $app_config = $this->model_app_config->get_all(array('type'=>'wedding'),'','','id','asc');
        if( $app_config ){
            foreach( $app_config as $val ){
                $site_id = $val['user_id'];
                $config = json_decode($val['config'], TRUE);
                if(!isset($config['image'])){//业务主题图
                    $config['image'] = c_image_url('/assets/wedding/images/wedding.jpg');
                }
                if(!isset($config['description'])){//业务欢迎语  登录页下面的提示
                    $config['description'] = '';
                }
                if(!isset($config['case_id'])){//案例喜帖码
                    $config['case_id'] = '';
                }

                //保存配置
                $config_new = $this->wedding_config_model->where(array('site_id'=>$site_id))->find();
                if( !$config_new ){
                    $save_config['site_id'] = $site_id;
                    $save_config['img'] = $config['image'] ? $config['image'] : '';
                    $save_config['codes'] = $config['case_id'] ? $config['case_id'] : '';
                    $save_config['description'] = $config['description'] ? $config['description'] : '';
                    $save_config['dt_add'] = time();
                    if( $this->wedding_config_model->add($save_config) ){
                    }else{
                        exit($site_id.' app_config导入失败');
                    }
                }
            }
            echo "app_config导入完成!";exit;
        }else{
            echo "app_config没有要导入的";exit;
        }
    }

    //wedding_invitation导入
    public function exchange_invitation()
    {
        $this->load->model('model_wedding_invitation');
        $where_set = array();
        $wedding_invitation_arr = $this->model_wedding_invitation->get_all($where_set, '', '','dt_add','asc');
        if( $wedding_invitation_arr ){
            foreach($wedding_invitation_arr as $val){
                $save_invitation['site_id'] = $val['user_id'];
                $save_invitation['title'] = $val['groom_name'].' 与 '.$val['bride_name'];
                $save_invitation['wedding_title'] = $val['groom_name'].' 与 '.$val['bride_name'];
                $save_invitation['code'] = $val['id'];
                $save_invitation['groom_name'] = $val['groom_name'];
                $save_invitation['bride_name'] = $val['bride_name'];
                $save_invitation['background_img'] = $val['cover_img'];//背景图
                $save_invitation['wedding_img'] = $save_invitation['share_img'] = $val['thumb'];//封面图
                $save_invitation['music_is_sys'] = 1;
                $save_invitation['music'] = $val['music'] ? substr(base_url(),0,strlen(base_url())-1).$val['music'] : '';
                $save_invitation['video'] = $val['video_url'];
                $save_invitation['album_img'] = ($val['photo'])&&($val['photo']!='null') ? $val['photo'] : '';
                $save_invitation['declarations'] = $val['declarations'];
                $save_invitation['dt_day'] = $val['date'] ? $val['date'] : '';

                $save_invitation['address'] = $val['address'] ? $val['address'] : '';
                $save_invitation['lat'] = $val['lat'];
                $save_invitation['lng'] = $val['lng'];

                $save_invitation['tele'] = $val['telephone'] ? $val['telephone'] : '';
                $save_invitation['dt_add'] = strtotime($val['dt_add']);
                $save_invitation['dt_update'] = strtotime($val['dt_update']);
                $save_invitation['tpl'] = 'default1';

                if( $this->wedding_list_model->add($save_invitation) ){
                }else{
                    echo "invitation".' '.$val['id'].'导入失败';exit;
                }
            }
            echo "invitation导入完成!";exit;
        }else{
            echo "invitation没有要导入的";exit;
        }
    }

    //祝福导入
    public function exchange_benison()
    {
        $page = $this->input->get('page');
        $page = $page ? $page : 1;
        $per_page = 5000;
        $this->load->model('model_wedding_joinbless');
        $where_set['type'] = 0;
        $benison_list = $this->model_wedding_joinbless->get_all($where_set,$per_page,$page,'id','asc');
        $this->load->model('wedding_benison_model');
        if( $benison_list ){
            foreach( $benison_list as $val ){
                $wedding = $this->wedding_list_model->where(array('code'=>$val['wedding_invitation_id']))->find();
                $wedding_id = '';
                if($wedding){
                    $wedding_id = $wedding['id'];
                }
                $save_benison['wedding_id'] = $wedding_id;
                $save_benison['benison'] = $val['bless_word'];
                $save_benison['dt_add'] = strtotime($val['dt_add']);
                $save_benison['status'] = 0;
                if( $this->wedding_benison_model->add($save_benison) ){
                }else{
                    echo "祝福".' '.$val['id'].'导入失败';exit;
                }
            }
            ob_start();
            echo $page;
            ob_clean();
            redirect(base_url().'c/wedding/exchange_benison?page='.($page+1));
        }else{
            echo "祝福导入完成";exit;
        }
    }

    //赴宴导入
    public function exchange_joinbless()
    {
        $page = $this->input->get('page');
        $page = $page ? $page : 1;
        $per_page = 5000;
        $this->load->model('model_wedding_joinbless');
        $where_set['type'] = 1;
        $joinbless_list = $this->model_wedding_joinbless->get_all($where_set,$per_page,$page,'id','asc');
        $this->load->model('wedding_joinbless_model');
        if( $joinbless_list ){
            foreach( $joinbless_list as $val ){
                $wedding = $this->wedding_list_model->where(array('code'=>$val['wedding_invitation_id']))->find();
                $wedding_id = '';
                if($wedding){
                    $wedding_id = $wedding['id'];
                }
                $save_joinbless['wedding_id'] = $wedding_id;
                $save_joinbless['name'] = $val['name'];
                $save_joinbless['mobile'] = $val['telephone'];
                $save_joinbless['nums'] = $val['attend_number'] ? $val['attend_number'] : 0;
                $save_joinbless['has_car'] = 0;
                $save_joinbless['dt_add'] = strtotime($val['dt_add']);
                if( $this->wedding_joinbless_model->add($save_joinbless) ){
                }else{
                    echo "赴宴信息".' '.$val['id'].'导入失败';exit;
                }
            }
            ob_start();
            echo $page;
            ob_clean();
            redirect(base_url().'c/wedding/exchange_joinbless?page='.($page+1));
        }else{
            echo "赴宴信息导入完成";exit;
        }
    }

}