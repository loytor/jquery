<?php
/**
 * Created by PhpStorm.
 * User: llj
 * Date: 14-2-19
 * Time: 下午3:08
 */
class Hardware extends C_Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * @return bool
     * 小票打印机设置
     */
    public function index()
    {
        $this->load->model('user_model');
        $user = $this->user_model->where(array('id'=>$this->site_info['id']))->find();
        if($this->input->post()) {
            $this->form_validation->set_rules('printer_name', '设备名称', 'trim|exact_length[10]');
            $this->form_validation->set_rules('printer_secret', '设备密钥', 'trim');
            if($this->form_validation->run()) {
                $data['printer_name'] = $this->form_validation->set_value('printer_name');
                $data['printer_secret'] = $this->form_validation->set_value('printer_secret');
                $result = $this->secret_valid($data['printer_name'], $data['printer_secret']);
                if($result['ret'] != 0) {
                    $this->show_message(FALSE, '密钥验证失败', '/c/hardware');
                    return FALSE;
                }

                if($this->user_model->where(array('id'=>$this->site_info['id']))->edit($data)){
                    $this->show_message(TRUE, '设置成功', '/c/hardware');
                    return FALSE;
                } else {
                    $this->show_message(FALSE, '设置失败', '/c/hardware');
                    return FALSE;
                }
            } else {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '/c/hardware');
                    return FALSE;
                }
            }
        } else {
            $this->data['user'] = $user;
            $this->load->view($this->dcm, $this->data);
        }
    }

    private function secret_valid($printer, $secret)
    {
        $query = 'printer='.$printer.'&password='.$secret;
        $url = 'http://printer.bama555.com/bind?' . $query;

        $this->load->library('curl');
        $result = $this->curl->get($url);
        $result = json_decode($result, true);
        return $result;
    }
}