<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * lbs本地商家
 */
class Lbs extends C_Controller{
    
    private $site_id = '';
    protected $data = array();
    
    public function __construct()
    {
        parent::__construct();
        $this->site_id = $this->site_info['id'];
    }
    
    public function index()
    {
        $this->data['online'] = 1;//商家服务 开启/关闭
        $this->load->model('lbs_site_model');
        $lbs_site = $this->lbs_site_model->where(array('site_id'=>$this->site_id))->find();
        if( $lbs_site ){
            $this->data['online'] = $lbs_site['status'];
            $this->data['cate_id'] = $lbs_site['cate_id'];
        }
        
        //获取分类列表
        $this->load->model('lbs_cate_model');
        $this->data['cate_list'] = $this->lbs_cate_model->find_all();
        
        //获取所有分店信息
        $address = $this->address();
        if( !$address ){
            return $this->show_message(false, '请先添加分店地址', '/c/lbs/index');
        }
        
        $select_address = array();
        if( $lbs_site['status'] ){//存在已 添加的地址
            $this->load->model('lbs_model');
            $lbs_address = $this->lbs_model->where(array('site_id'=>$this->site_id))->find_all();
            if( $lbs_address ){
                foreach( $lbs_address as $val ){
                    $select_address[] = $val['address_id'];
                }
            }
        }
        
        $this->data['select_address'] = $select_address;
        
        $this->data['url'] = $this->create_url('/lbs');
        
        $this->load->view($this->dcm, $this->data);
    }
    
    //配置要上线的分店(删除/添加)
    public function config()
    {
        $this->load->model('lbs_site_model');
        $lbs_site = $this->lbs_site_model->where(array('site_id'=>$this->site_id))->find();
        
        $status = $this->input->post('status');
        $cate_id = $this->input->post('cate_id');
        if( !$cate_id ){
            return $this->show_message(false, '请选择所属行业','',1);
        }
        if( $lbs_site ){
            if( ($lbs_site['status']!=$status)||($lbs_site['cate_id']!=$cate_id) ){
                $status = $status ? 1 : 0;
                $this->lbs_site_model->where(array('site_id'=>$this->site_id))->edit(array('status'=>$status,'cate_id'=>$cate_id));
            }
        }else{
            $status = $status ? 1 : 0;
            $this->lbs_site_model->add(array('site_id'=>$this->site_id,'status'=>$status,'cate_id'=>$cate_id));
        }
        
        if( $status ){//开启
            
            $check_address = $this->input->post('address');
            if( !$check_address ){
                return $this->show_message(false, '请选择店铺','',1);
            }
            
            //获取已添加的分店
            $select_address = array();
            $this->load->model('lbs_model');
            $lbs_address = $this->lbs_model->where(array('site_id'=>$this->site_id))->find_all();
            if( $lbs_address ){
                
                $this->lbs_model->where(array('site_id'=>$this->site_id))->edit(array('cate_id'=>$cate_id));
                foreach( $lbs_address as $val ){
                    $select_address[] = $val['address_id'];
                }
            }
            
            $add_address = array_diff($check_address, $select_address);
            $del_address = array_diff($select_address, $check_address);
            
            if( $del_address ){
                $this->lbs_model->where(array('site_id'=>$this->site_id))->where_in('address_id',$del_address)->delete();
            }
            if( $add_address ){
                foreach( $add_address as $val ){
                    $add_data['site_id'] = $this->site_id;
                    $add_data['cate_id'] = $cate_id;
                    $add_data['address_id'] = $val;
                    $add_data['status'] = 0;
                    $this->lbs_model->add($add_data);
                }
            }
            
        }else{//关闭LBS商家服务
            $this->load->model('lbs_model');
            $this->lbs_model->where(array('site_id'=>$this->site_id))->delete();
        }
        return $this->show_message(true, '保存成功','/c/lbs/index');
    }
    
    
    /**
     * 默认单位  联系方式里的
     */
    private function address()
    {
        //分店
        $this->load->model('model_address');
        $address_list = $this->model_address->get_all(array('wid'=>$this->site_id, 'status'=>0), '', '');
        $address_list = $address_list ? $address_list : array();
        $this->data['address_list'] = $address_list;
        if( !$address_list ){
            return false;
        }
        return true;
    }   
    
}
