<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 全景图管理
 */
class Panorama extends C_Controller {

    protected $data = '';
    private $site_id = '';

    public function __construct()
    {
        parent::__construct();
        $this->site_id = $this->site_info['id'];

        $this->load->model('panorama_model');
        $this->load->model('user_model');
    }

    public function index()
    {
        $where['type'] = '0';
        $where['site_id'] = $this->site_id;
        $total_rows = $this->panorama_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>10));
        $total_rows = $this->panorama_model->where($where)->limit($pager['limit']['value'], $pager['limit']['offset'])->order_by('id asc')->find_all();
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->data['list'] = $total_rows;
        if($this->data['list'])
        {
            foreach($this->data['list'] as &$mscat)
            {
                $url = $this->create_url('panorama?id='.$mscat['id']);
                $mscat['url']= $url;
            }
        }
        $this->load->view($this->dcm,$this->data);
    }
    public function add()
    {
        if( $this->input->post() ){
            $this->form_validation->set_rules('title', '标题', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('p_back', 'back', 'trim|required|callback__check_image');
            $this->form_validation->set_rules('p_bottom', 'bottom', 'trim|required|callback__check_image');
            $this->form_validation->set_rules('p_front', 'front', 'trim|required|callback__check_image');
            $this->form_validation->set_rules('p_left', 'left', 'trim|required|callback__check_image');
            $this->form_validation->set_rules('p_right', 'right', 'trim|required|callback__check_image');
            $this->form_validation->set_rules('p_top', 'top', 'trim|required|callback__check_image');

            if ( $this->form_validation->run() ){
                $save_data['type'] = 0;
                $save_data['site_id'] = $this->site_id;
                $save_data['title'] = $this->form_validation->set_value('title');
                $save_data['pic_back'] = $this->form_validation->set_value('p_back');
                $save_data['pic_bottom'] = $this->form_validation->set_value('p_bottom');
                $save_data['pic_front'] = $this->form_validation->set_value('p_front');
                $save_data['pic_left'] = $this->form_validation->set_value('p_left');
                $save_data['pic_right'] = $this->form_validation->set_value('p_right');
                $save_data['pic_top'] = $this->form_validation->set_value('p_top');
                $save_data['parent_id'] = 0;
                $save_data['add_time'] = time();
                $save_data['address'] = 1;
                if( !$id=$this->panorama_model->add($save_data)){
                    $this->show_message(false, '添加失败', '');
                    return FALSE;
                }else{
                    $this->show_message(true, '添加成功', '/c/panorama/index');
                    return FALSE;
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            $this->load->view($this->dcm,$this->data);
        }
    }
    public function edit($id = '')
    {
        if(!$id){
            $this->show_message(false, '非法参数', '');return false;
        }
        $cate = $this->panorama_model->where(array('id'=>$id))->find();
        if(!$cate){
            $this->show_message(false, '指标不存在', '');return false;
        }else{
            if($cate['site_id']!=$this->site_id){
                $this->show_message(false, '无权限', '');return false;
            }
            if($cate['type']!=0){
                $this->show_message(false, '指标不存在', '');return false;
            }
        }

        if( $this->input->post() ){
            $this->form_validation->set_rules('title', '标题', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('p_back', 'back', 'trim|required|callback__check_image');
            $this->form_validation->set_rules('p_bottom', 'bottom', 'trim|required|callback__check_image');
            $this->form_validation->set_rules('p_front', 'front', 'trim|required|callback__check_image');
            $this->form_validation->set_rules('p_left', 'left', 'trim|required|callback__check_image');
            $this->form_validation->set_rules('p_right', 'right', 'trim|required|callback__check_image');
            $this->form_validation->set_rules('p_top', 'top', 'trim|required|callback__check_image');
            if ( $this->form_validation->run() ){
                $save_data['title'] = $this->form_validation->set_value('title');
                $save_data['pic_back'] = $this->form_validation->set_value('p_back');
                $save_data['pic_bottom'] = $this->form_validation->set_value('p_bottom');
                $save_data['pic_front'] = $this->form_validation->set_value('p_front');
                $save_data['pic_left'] = $this->form_validation->set_value('p_left');
                $save_data['pic_right'] = $this->form_validation->set_value('p_right');
                $save_data['pic_top'] = $this->form_validation->set_value('p_top');
                if(false === $this->panorama_model->where(array('id'=>$id))->edit($save_data) ){
                    $this->show_message(false, '编辑失败', '');
                }else{
                    $this->show_message(true, '编辑成功', '/c/panorama/index');
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            $this->data['info'] = $cate;
            $this->load->view($this->dcm,$this->data);
        }
    }

    /**
     * @name 删除
     * @param string $id
     * @return bool
     */
    public function delete($id = '')
    {
        if(!$id){
            $this->show_message(false, '非法参数', '');return false;
        }
        $cate = $this->panorama_model->where(array('id'=>$id))->find();
        if(!$cate){
            $this->show_message(false, '全景图不存在', '/c/panorama/index');return false;
        }
        $this->panorama_model->where(array('id'=>$id))->delete();
        $this->show_message(true, '删除成功!', '/c/panorama/index');return false;
    }
    //检查名称
    public function _check_title($title) {
        if ($title) {
            $cate = $this->panorama_model->like('title',$title)->where(array('type'=>0))->count();
            if($cate)
            {
                $this->form_validation->set_message('_check_title', '名称已经存在');
                return FALSE;
            }
        }
        return TRUE;
    }
    //检查图片格式
    public function _check_image($image) {
        if ($image) {
            if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
                $this->form_validation->set_message('_check_image', '图片地址格式错误');
                return FALSE;
            }
        }
        return TRUE;
    }
}