<?php
/**
 * 点菜
 * Enter description here ...
 * @author Administrator
 *
 */
class Diancai_store extends C_Controller {

    protected $auto_load_model = TRUE;
    protected $model_name = 'diancai_store';
    
    protected $data = '';
    
    private $site_id = '';

    public function __construct()
    {
        parent::__construct();
        
        $this->site_id = $this->site_info['id'];
        
        $this->load->model('diancai_model');
        $this->load->model('diancai_shangpin_model');
        $this->load->model('diancai_shangpin_tag_model');
        $this->load->model('diancai_store_tag_model');
        $this->load->model('diancai_order_model');
    }
    
    public function index()
    {
        $like = array();$is_search = 0;
        $search['sear_name'] = $this->input->get('sear_name');
        $search['sear_add'] = $this->input->get('sear_add');
        $search['sear_tel'] = $this->input->get('sear_tel');
        
        $this->data['search'] = $search;
        $search_url = site_url($this->uri->uri_string().'?');
        if( $search ){
            foreach( $search as $key=>$val ){
                if( $val ){
                    $search_url .= '&'.$key.'='.$val;
                    switch ($key){
                        case 'sear_name':
                            $like['address.name'] = $search['sear_name'];
                            break;
                        case 'sear_add':
                            $like['wb_diancai_store.address'] = $search['sear_add'];
                            break;
                        case 'sear_tel':
                            $like['wb_diancai_store.tele'] = $search['sear_tel'];
                            break;
                        default: break;
                    }
                }
            }
            $is_search = 1;
        }
        
        $this->data['is_search'] = $is_search;
        
        $where = array(
            'wb_diancai_store.site_id' => $this->site_id,
            'wb_diancai_store.status' => 0
        );
        
        $total_rows = $this->model->join('address','address.id=wb_diancai_store.address_id')->where($where)->like($like)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$search_url));
        $list = $this->model
                ->select('wb_diancai_store.*,address.name as add_name,address.address')
                ->join('address','address.id=wb_diancai_store.address_id','left')
                ->limit($pager['limit']['value'], $pager['limit']['offset'])
                ->where($where)->like($like)->find_all();
        
        
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];


        $this->load->view($this->dcm, $this->data);
    }
    
    //添加门店
    public function add_store()
    {
        //所有门店
        $res = $this->address();
        if( !$res ){
            $this->show_message(false, '请先添加地址', '/address/add');return FALSE;
        }
        
        //已添加的门店
        $diancai_add = $this->model->select('id,address_id')->where(array('site_id'=>$this->site_id,'status'=>0))->find_all();
        $has_store = array();
        if( $diancai_add ){
            foreach( $diancai_add as $val ){
                $has_store[$val['address_id']] = $val['address_id'];
            }
        }
        
        $address_list = array();
        foreach( $this->data['address_list'] as $val ){
            if( !isset($has_store[$val['id']]) ){
                $address_list[] = $val;
            }
        }
        
        if( !$address_list ){
            $this->show_message(false, '您所拥有的门店已全部添加到了点菜门店里', '/c/diancai_store/');return FALSE;
        }
        $this->data['address_list'] = $address_list;

        //检查是否开通微助手
        if( $this->check_assistant($this->site_id) ){
            $this->data['assistant'] = 1;
        }else{
            $this->data['assistant'] = 0;
        }
        
        if( $this->input->post() ){
            $this->form_validation->set_rules('address_id', '选择门店', 'trim|required');
            $this->form_validation->set_rules('tele', '门店电话', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('printer_num', '小票打印机设置', 'trim|required|numeric|greater_than_equal_to[1]|intval');
            $this->form_validation->set_rules('printer_type', '打印机时间', 'trim|required|intval');
            $this->form_validation->set_rules('assistant', '微助手提醒', 'trim|intval');
            $this->form_validation->set_rules('sales_volume', '菜品显示销量', 'trim|required|intval');
            $this->form_validation->set_rules('desk_set', '下单选择餐台', 'trim|required|intval');
            $this->form_validation->set_rules('email', '订单微信提醒', 'trim|valid_email');
            $this->form_validation->set_rules('intro', '点菜说明', 'trim|htmlspecialchars|max_length[500]');
            if ( $this->form_validation->run() ){
                $save_data['address_id'] = $this->form_validation->set_value('address_id');
                $save_data['tele'] = $this->form_validation->set_value('tele');
                $save_data['printer_num'] = $this->form_validation->set_value('printer_num');
                $save_data['printer_type'] = $this->form_validation->set_value('printer_type');
                $save_data['assistant'] = $this->form_validation->set_value('assistant');
                $save_data['sales_volume'] = $this->form_validation->set_value('sales_volume');
                $save_data['desk_set'] = $this->form_validation->set_value('desk_set');
                $save_data['email'] = $this->form_validation->set_value('email');
                $save_data['intro'] = $this->form_validation->set_value('intro');
                
                //营业时间
                $save_data['sh'] = intval($this->input->post('sh'));
                $save_data['eh'] = intval($this->input->post('eh'));
                
                //发送订单选项
                if( $save_data['email'] ){
                    $order_email_contents = $this->input->post('order',true);
                    if( !$order_email_contents ){
                        return $this->show_message(false, '请选择要提醒的内容', '',1);
                    }
                    $order_email = '';
                    foreach( $order_email_contents as $key=>$val ){
                        $order_email .= $key.',';
                    }
                    $order_email = substr($order_email, 0,-1);
                    $save_data['send_content'] = $order_email;
                }
                $remind_type = $this->input->post('remind_type',true);
                $save_data['remind_type'] = implode(',',$remind_type);
                
                $del_temp = $this->model->where(array('site_id'=>$this->site_id,'address_id'=>$save_data['address_id'],'status'=>1))->find();
                if( $del_temp ){//改状态
                    $save_data['status'] = 0;
                    if($this->model->where(array('site_id'=>$this->site_id,'address_id'=>$save_data['address_id']))->edit($save_data)){
                    }else{
                        $this->show_message(false, '添加失败', '/c/diancai_store');return FALSE;
                    }
                }else{//添加
                    $save_data['site_id'] = $this->site_id;
                    $save_data['add_time'] = time();
                    if($this->model->add($save_data)){
                    }else{
                        $this->show_message(false, '添加失败', '/c/diancai_store');return FALSE;
                    }
                }
                $this->show_message(true, '添加成功', '/c/diancai_store');return FALSE;
            }else{ 
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            $this->load->view($this->dcm, $this->data);
        }
    }
    
    
    /**
     * 修改门店信息
     */
    public function edit($store_id)
    {
        $res = $this->get_store($store_id);
        if( !$res ){
            $this->show_message(false, '非法操作', '/c/diancai_store');return FALSE;
        }
        
        if( $this->data['store']['email'] ){
            $this->data['store']['send_content'] = explode(',', $this->data['store']['send_content']);
        }
        
        //获取门店名称和地址
        $this->load->model('model_address');
        $address = $this->model_address->get_row(array('id'=>$this->data['store']['address_id']));
        $this->data['address'] = $address;
        $this->data['store']['address'] = $address['address'];

        //检查是否开通微助手
        if( $this->check_assistant($this->site_id) ){
            $this->data['assistant'] = 1;
        }else{
            $this->data['assistant'] = 0;
        }
        
        if( $this->input->post() ){
            $this->form_validation->set_rules('tele', '点菜电话', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('printer_num', '小票打印机设置', 'trim|required|numeric|greater_than_equal_to[1]|intval');
            $this->form_validation->set_rules('printer_type', '打印机时间', 'trim|required|intval');
            $this->form_validation->set_rules('assistant', '微助手提醒', 'trim|intval');
            $this->form_validation->set_rules('sales_volume', '菜品显示销量', 'trim|required|intval');
            $this->form_validation->set_rules('desk_set', '下单选择餐台', 'trim|required|intval');
            $this->form_validation->set_rules('email', '订单微信提醒', 'trim|valid_email');
            $this->form_validation->set_rules('intro', '点菜说明', 'trim|htmlspecialchars|max_length[500]');
            if ( $this->form_validation->run() ){
                
                $save_data['tele'] = $this->form_validation->set_value('tele');
                $save_data['printer_num'] = $this->form_validation->set_value('printer_num');
                $save_data['printer_type'] = $this->form_validation->set_value('printer_type');
                $save_data['assistant'] = $this->form_validation->set_value('assistant');
                $save_data['sales_volume'] = $this->form_validation->set_value('sales_volume');
                $save_data['desk_set'] = $this->form_validation->set_value('desk_set');
                $save_data['email'] = $this->form_validation->set_value('email');
                $save_data['intro'] = $this->form_validation->set_value('intro');
                
                //营业时间
                $save_data['sh'] = intval($this->input->post('sh'));
                $save_data['eh'] = intval($this->input->post('eh'));
                
                //发送订单选项
                if( $save_data['email'] ){
                    $order_email_contents = $this->input->post('order',true);
                    if( !$order_email_contents ){
                        $this->show_message(false, '请选择要提醒的内容', '',1);return FALSE;
                    }
                    $order_email = '';
                    foreach( $order_email_contents as $key=>$val ){
                        $order_email .= $key.',';
                    }
                    $order_email = substr($order_email, 0,-1);
                    $save_data['send_content'] = $order_email;
                }else{
                    $save_data['send_content'] = '';
                }
                $remind_type = $this->input->post('remind_type',true);
                $save_data['remind_type'] = $remind_type ? (implode(',',$remind_type)) : '';
                
                if( $this->model->where(array('site_id' => $this->site_id,'status' => 0,'id' => $store_id))->edit($save_data) ){
                    $this->show_message(true, '保存成功', '/c/diancai_store');return FALSE;
                }else{
                    $this->show_message(false, '保存失败', '/c/diancai_store');return FALSE;
                }
            }else{ 
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            $this->load->view($this->dcm, $this->data);
        }
    }
    
    public function delete_store($store_id)
    {
        $res = $this->get_store($store_id);
        if( !$res ){
            $this->show_message(false, '非法操作', '/c/diancai_store');return FALSE;
        }
        
        if( $this->model->where(array('site_id'=>$this->site_id,'status' => 0,'id'=>$store_id))->edit(array('status'=>1)) ){
            $this->show_message(true, '删除成功', '/c/diancai_store');return FALSE;
        }else{
            $this->show_message(false, '删除失败', '/c/diancai_store');return FALSE;
        }
    }
    
    
    //门店标签
    public function tags($store_id)
    {
        $res = $this->get_store($store_id);
        if( !$res ){
            $this->show_message(false, '非法操作', '/c/diancai_store');return FALSE;
        }
        $where = array(
            'site_id' => $this->site_id,
            'store_id' => $store_id,
            'status' => 0
        );
        $total_rows = $this->diancai_store_tag_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15));
        $list = $this->diancai_store_tag_model
                ->limit($pager['limit']['value'], $pager['limit']['offset'])
                ->where($where)->order_by('sort asc,id desc')->find_all();
        
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        
        
        $this->load->view($this->dcm, $this->data);
    }
    
    //添加标签
    public function add_tag($store_id)
    {
        $res = $this->get_store($store_id);
        if( !$res ){
            $this->show_message(false, '非法操作', '/c/diancai_storetags/'.$store_id);return FALSE;
        }
        
        if( $this->input->post() ){
            $this->form_validation->set_rules('name', '标签名', 'trim|required|max_length[10]');
            $this->form_validation->set_rules('sort', '排序', 'trim|is_natural_no_zero');
            $this->form_validation->set_rules('show', '显示', 'trim|intval');
            $this->form_validation->set_rules('intro', '标签说明', 'trim|htmlspecialchars|max_length[500]');
            if ( $this->form_validation->run() ){
                
                $save_data['name'] = $this->form_validation->set_value('name');
                $save_data['sort'] = $this->form_validation->set_value('sort');
                $save_data['sort'] = $save_data['sort'] ? $save_data['sort'] : 0;
                $save_data['show'] = $this->form_validation->set_value('show');
                $save_data['intro'] = $this->form_validation->set_value('intro');
                
                $save_data['site_id'] = $this->site_id;
                $save_data['store_id'] = $store_id;
                
                //唯一验证
                $res = $this->check_tag($save_data['name'],$store_id);
                if( $res ){
                    $this->show_message(false, '已添加过该标签', '/');return FALSE;
                }
                
                //判断是否已经存在过
                $temp_tag  = $this->diancai_store_tag_model->where(array('site_id'=>$this->site_id,'store_id'=>$store_id,'name'=>$save_data['name'],'status'=>1))->find();
                if( $temp_tag ){
                    //修改原来的数据
                    $save_data['status'] = 0;
                    if( $this->diancai_store_tag_model->where(array('site_id'=>$this->site_id,'store_id'=>$store_id,'name'=>$save_data['name'],'status'=>1))->edit($save_data) ){
                        $this->show_message(true, '添加成功', '/c/diancai_store/tags/'.$store_id);return FALSE;
                    }else{
                        $this->show_message(false, '添加失败', '');return FALSE;
                    }
                }else{
                    $save_data['add_time'] = time();
                    if( $this->diancai_store_tag_model->add($save_data) ){
                        $this->show_message(true, '添加成功', '/c/diancai_store/tags/'.$store_id);return FALSE;
                    }else{
                        $this->show_message(false, '添加失败', '');return FALSE;
                    }
                }
                
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            $this->load->view($this->dcm, $this->data);
        }
    }
    
    //标签唯一性验证
    private function check_tag($name,$sid,$id='')
    {
        $where = array(
            'site_id' => $this->site_id,
            'store_id' => $sid,
            'name' => $name,
            'status' => 0
        );
        
        if( $id ){
            $where['id <>'] = $id;
        }
        $tag = $this->diancai_store_tag_model->where($where)->find();
        if( $tag ){
            return true;
        }else{
            return false;
        }
    }
    
    //编辑标签
    public function edit_tag()
    {
        $store_id = $this->input->get('sid');
        $tag_id = $this->input->get('id');
        
        $res = $this->get_store($store_id);
        if( !$res ){
            $this->show_message(false, '非法操作', '/c/diancai_storetags/'.$store_id);return FALSE;
        }

        $tag = $this->diancai_store_tag_model->where(array('site_id'=>$this->site_id,'store_id'=>$store_id,'id'=>$tag_id,'status'=>0))->find();
        if( !$tag ){
            $this->show_message(false, '非法操作', '/c/diancai_storetags/'.$store_id);return FALSE;
        }
        $this->data['tag'] = $tag;
        
        if( $this->input->post() ){
            $this->form_validation->set_rules('name', '标签名', 'trim|required|max_length[10]');
            $this->form_validation->set_rules('sort', '排序', 'trim|is_natural_no_zero');
            $this->form_validation->set_rules('show', '显示', 'trim|intval');
            $this->form_validation->set_rules('intro', '标签说明', 'trim|htmlspecialchars|max_length[500]');
            if ( $this->form_validation->run() ){
                
                $save_data['name'] = $this->form_validation->set_value('name');
                $save_data['sort'] = $this->form_validation->set_value('sort');
                $save_data['sort'] = $save_data['sort'] ? $save_data['sort'] : 0;
                $save_data['show'] = $this->form_validation->set_value('show');
                $save_data['intro'] = $this->form_validation->set_value('intro');
                
                $save_data['site_id'] = $this->site_id;
                $save_data['store_id'] = $store_id;
                
                //唯一验证
                $res = $this->check_tag($save_data['name'],$store_id,$tag_id);
                if( $res ){
                    $this->show_message(false, '已添加过该标签', '');return FALSE;
                }
                
                if( $this->diancai_store_tag_model->where(array('site_id'=>$this->site_id,'store_id'=>$store_id,'id'=>$tag_id,'status'=>0))->edit($save_data) ){
                    $this->show_message(true, '修改成功', '/c/diancai_store/tags/'.$store_id);return FALSE;
                }else{
                    $this->show_message(false, '修改失败', '');return FALSE;
                }
                
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            $this->load->view($this->dcm, $this->data);
        }
    }
    
    //删除标签
    public function delete_tag()
    {
        $store_id = $this->input->get('sid');
        $tag_id = $this->input->get('id');
        
        $res = $this->get_store($store_id);
        if( !$res ){
            $this->show_message(false, '非法操作', '/c/diancai_storetags/'.$store_id);return FALSE;
        }
        $tag = $this->diancai_store_tag_model->where(array('site_id'=>$this->site_id,'store_id'=>$store_id,'id'=>$tag_id,'status'=>0))->find();
        if( !$tag ){
            $this->show_message(false, '非法操作', '/c/diancai_storetags/'.$store_id);return FALSE;
        }
        
        $save_data['status'] = 1;
        if( $this->diancai_store_tag_model->where(array('site_id'=>$this->site_id,'store_id'=>$store_id,'id'=>$tag_id,'status'=>0))->edit($save_data) ){
            $this->show_message(true, '删除成功', '/c/diancai_store/tags/'.$store_id);return FALSE;
        }else{
            $this->show_message(false, '删除失败', '/c/diancai_store/tags/'.$store_id);return FALSE;
        }
    }
    
    
    //获取门店信息
    private function get_store($store_id)
    {
        $where = array(
            'site_id' => $this->site_id,
            'status' => 0,
            'id' => $store_id
        );
        $diancai_store = $this->model->where($where)->find();
        $diancai_store = $diancai_store ? $diancai_store : array();
        
        if( $diancai_store ){
            $this->load->model('model_address');
            $address = $this->model_address->get_row(array('wid'=>$this->site_id,'id'=>$diancai_store['address_id']));
            if( $address ){
                $diancai_store['address'] = $address['address'];
            }
        }
        
        $this->data['store'] = $diancai_store;
        if( !$diancai_store ){
            return false;
        }
        return true;
    }
    
    /**
     * 默认单位  联系方式里的
     */
    private function address()
    {
        //分店
        $this->load->model('model_address');
        $address_list = $this->model_address->get_all(array('wid'=>$this->site_id, 'status'=>0), '', '');
        $address_list = $address_list ? $address_list : array();
        $this->data['address_list'] = $address_list;
        if( !$address_list ){
            return false;
        }
        return true;
    }

    /**
     * @name 一个门店下的菜品列表
     * @return bool
     */
    public function shangpin()
    {
        $sid = $this->input->get('sid');

        //门店是否存在
        $storeInfo = $this->get_store($sid);
        if(!$sid || !$storeInfo)
        {
            $this->show_message(false, '门店不存在', '/c/diancai_store');return FALSE;
        }

        $where = array(
            'wb_diancai_shangpin.site_id'=>$this->site_id,
            'wb_diancai_shangpin.sid'=>$sid
        );

        $like = array();
        $search['title'] = $this->input->get('title');
        $search['price'] = $this->input->get('price');
        $search['oldprice'] = $this->input->get('oldprice');

        $this->data['search'] = $search;
        $search_url = '/c/diancai_store/shangpin/?sid='.$sid;
        //标题模糊查询
        if($search['title'])
        {
            $like['dishes.title'] = $search['title'];
        }
        if($search['oldprice'])
        {
            $where['dishes.price'] = $search['oldprice'];
        }
        if($search['price'])
        {
            $where['wb_diancai_shangpin.price'] = $search['price'];
        }
        if($search)
        {
            foreach( $search as $key=>$val ){
                $search_url .= '&'.$key.'='.$val;
            }
        }

        $total_rows = $this->diancai_shangpin_model->join('dishes','dishes.id=wb_diancai_shangpin.shangpin_id')->where($where)->like($like)->count();

        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$search_url));


        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        //门店下的所有标签
        $tagwhere = array(
            'site_id' => $this->site_id,
            'store_id' => $sid,
            'status' => 0
        );
        $taglist = $this->diancai_store_tag_model->where($tagwhere)->order_by('id desc')->find_all();
        $tagArr = array();
        if($taglist)
        {
            foreach($taglist as $tag)
            {
                $tagArr[$tag['id']] = $tag;
            }
        }

        $list = $this->diancai_shangpin_model
            ->select('wb_diancai_shangpin.id,wb_diancai_shangpin.price,dishes.cid,dishes.pic,dishes.price as oldprice,dishes.title')
            ->join('dishes','dishes.id=wb_diancai_shangpin.shangpin_id')
            ->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->where($where)->like($like)->order_by('wb_diancai_shangpin.rank desc')->find_all();
        $shangpinArr = array();
        if($list)
        {
            foreach($list as $_list)
            {
                //菜品的tag
                $shangpinTag = $this->diancai_shangpin_tag_model
                    ->select('wb_diancai_store_tag.name')
                    ->join('wb_diancai_store_tag','wb_diancai_shangpin_tag.tag_id=wb_diancai_store_tag.id','left')
                    ->where(array('wb_diancai_shangpin_tag.site_id'=>$this->site_id,'wb_diancai_shangpin_tag.sid'=>$sid,'wb_diancai_shangpin_tag.shangpin_id'=>$_list['id'],'wb_diancai_store_tag.status'=>0))
                    ->find_all();
                if($shangpinTag)
                {
                    $dot = $tags = '';
                    foreach($shangpinTag as $tag)
                    {
                        $tags .= $dot.$tag['name'];
                        $dot = ',';
                    }
                    $_list['tag'] = $tags;
                }
                $shangpinArr[] = $_list;
            }
        }

        $this->data['list'] = $shangpinArr;

        $this->load->view($this->dcm, $this->data);
    }

    /**
     * @name 增加门店的菜品
     * @return bool
     */
    public function get_shangpin()
    {
        $sid = $this->input->get('sid');
        //门店是否存在
        $storeInfo = $this->get_store($sid);
        if(!$sid || !$storeInfo)
        {
            $this->show_message(false, '门店不存在', '/c/diancai_store');return FALSE;
        }
        //所有的菜品
        $this->load->model('dishes_model');
        $where['site_id'] = $this->site_info['id'];

        $list = $this->dishes_model->order_by('id desc')->where($where)->find_all();
        if(!$list)
        {
            $this->show_message(false, '请先添加菜品', '/c/shangpin');return FALSE;
        }
        $shangpinList = array();
        foreach($list as $_list)
        {
            $shangpinList[$_list['id']] = $_list;
        }
        //门店下的所有标签

        $taglist = $this->diancai_store_tag_model->where($where)->order_by('sort asc,id desc')->find_all();
        $where = array(
            'site_id' => $this->site_id,
            'store_id' => $sid,
            'status' => 0
        );
        $taglist = $this->diancai_store_tag_model->where($where)->order_by('sort asc,id desc')->find_all();
        if(!$taglist)
        {
            $this->show_message(false, '请先添加该门店下的标签', '/c/diancai_store/add_tag/'.$sid);return FALSE;
        }
        $this->data['taglist'] = $taglist;
        $post = $this->input->post();

        //print_r($postData);
        if($post)
        {
            //菜品是否有选择
            $shangpin_id = $this->input->post('shangpin_id');
            if(!$shangpin_id)
            {
                $this->show_message(false, '请选择商品', '/c/diancai_store/get_shangpin/?sid='.$sid);return FALSE;
            }
            //tag是否有选择
            $tag = $this->input->post('tag');
            if(!$tag)
            {
                $this->show_message(false, '请选择标签！', '/c/diancai_store/get_shangpin/?sid='.$sid);return FALSE;
            }
            $price = $this->input->post('price');
            //判断价格
            if(!is_numeric($price) || $price<0)
            {
                $this->show_message(false, '价格必须是非负数！', '/c/diancai_store/get_shangpin/?sid='.$sid);return FALSE;
            }
            $price = $price ? $price : $shangpinList[$shangpin_id]['price'];
            //排序
            $rank = $this->input->post('rank');
            $rank = is_numeric($rank) ? $rank : 0;
            $newshangpinid = $this->diancai_shangpin_model->add(array('site_id'=>$this->site_id,'sid'=>$sid,'shangpin_id'=>$shangpin_id,'price'=>$price,'rank'=>$rank,'inputtime'=>time()));
            if($newshangpinid)
            {
                foreach($tag as $_tag)
                {
                    $this->diancai_shangpin_tag_model->add(array('site_id'=>$this->site_id,'sid'=>$sid,'shangpin_id'=>$newshangpinid,'tag_id'=>$_tag));
                }
            }
            $this->show_message(true, '添加成功', '/c/diancai_store/shangpin/?sid='.$sid);return FALSE;
        }
        else
        {
            //当前门店下已选择的菜品
            $storeDishesList = $this->diancai_shangpin_model->where(array('site_id'=>$this->site_info['id'],'sid'=>$sid))->find_all();
            if($storeDishesList)
            {
                //可选择的菜品
                foreach($storeDishesList as $slist)
                {
                    if(isset($shangpinList[$slist['shangpin_id']])&&$shangpinList[$slist['shangpin_id']])
                    {
                        unset($shangpinList[$slist['shangpin_id']]);
                    }
                }
            }
            
            $this->data['list'] = $shangpinList;
            $this->load->view($this->dcm, $this->data);
        }

    }

    /**
     * @name 编辑门店下的菜品
     * @return bool
     */
    public function edit_shangpin()
    {
        $id = $this->input->get('id');
        //菜品是否存在
        $storeDishes = $this->diancai_shangpin_model
            ->select('wb_diancai_shangpin.id,wb_diancai_shangpin.price,wb_diancai_shangpin.sid,wb_diancai_shangpin.rank,dishes.cid,dishes.pic,dishes.price as oldprice,dishes.title,dishes.description')
            ->join('dishes','dishes.id=wb_diancai_shangpin.shangpin_id')
            ->where(array('wb_diancai_shangpin.site_id'=>$this->site_id,'wb_diancai_shangpin.id'=>$id))->find();

        //门店是否存在
        $storeInfo = $this->get_store($storeDishes['sid']);
        if( !$storeInfo)
        {
            $this->show_message(false, '门店不存在', '/c/diancai_store');return FALSE;
        }

        $tagWhere = array('site_id'=>$this->site_id,'sid'=>$storeDishes['sid'],'shangpin_id'=>$id);

        if( $this->input->post() )
        {
            $this->form_validation->set_rules('price', '商品现价', 'trim');
            $this->form_validation->set_rules('rank', '排序', 'trim|numeric');
            if($this->form_validation->run())
            {
                $save_data['price'] = $this->form_validation->set_value('price');
                //判断价格
                if(!is_numeric($save_data['price']) || $save_data['price'] <0 )
                {
                    $this->show_message(false, '价格必须是非负数！', '');return FALSE;
                }
                $save_data['rank'] = $this->form_validation->set_value('rank');
                $save_data['rank'] = is_numeric($save_data['rank']) ? $save_data['rank'] : 0;
                $tag = $this->input->post('tag');
                if(!$tag){
                    $this->show_message(false, '请选择标签！', '');return FALSE;
                }else{
                    //删除原有的tag
                    $this->diancai_shangpin_tag_model->where($tagWhere)->delete();
                    foreach($tag as $_tag){
                        $this->diancai_shangpin_tag_model->add(array('site_id'=>$this->site_id,'sid'=>$storeDishes['sid'],'shangpin_id'=>$id,'tag_id'=>$_tag));
                    }
                }
                
                if( $this->diancai_shangpin_model->where(array('site_id' => $this->site_id,'id' => $id))->edit($save_data) ){
                    $this->show_message(true, '保存成功', '/c/diancai_store/shangpin/?sid='.$storeDishes['sid']);return FALSE;
                }else{
                    $this->show_message(false, '保存失败', '');return FALSE;
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }
        else
        {
            //已经保存的菜品标签
            $this->data['shangpintaglist'] = $this->diancai_shangpin_tag_model->where($tagWhere)->find();

            //门店下的所有标签
            $where = array(
                'site_id' => $this->site_id,
                'store_id' => $storeDishes['sid'],
                'status' => 0
            );
            $taglist = $this->diancai_store_tag_model->where($where)->order_by('sort asc,id desc')->find_all();

            $this->data['taglist'] = $taglist;
            $this->data['storeshangpin'] = $storeDishes;
            $this->load->view($this->dcm, $this->data);
        }
    }

    /**
     * @name 删除一个菜品
     * @param $id
     * @return bool
     */
    public function delete_shangpin($id)
    {
        //菜品是否存在
        $storeDishes = $this->diancai_shangpin_model
            ->select('wb_diancai_shangpin.id,wb_diancai_shangpin.price,wb_diancai_shangpin.sid,wb_diancai_shangpin.rank,dishes.cid,dishes.pic,dishes.price as oldprice,dishes.title,dishes.description')
            ->join('dishes','dishes.id=wb_diancai_shangpin.shangpin_id')
            ->where(array('wb_diancai_shangpin.site_id'=>$this->site_id,'wb_diancai_shangpin.id'=>$id))->find();

        //门店是否存在
        $storeInfo = $this->get_store($storeDishes['sid']);
        if( !$storeInfo)
        {
            $this->show_message(false, '门店不存在', '/c/diancai_store');return FALSE;
        }
        if( $this->diancai_shangpin_model->where(array('site_id' => $this->site_id,'id' => $id))->delete() )
        {
            //删除tag
            $tagWhere = array('site_id'=>$this->site_id,'sid'=>$storeDishes['sid'],'shangpin_id'=>$id);
            $this->diancai_shangpin_tag_model->where($tagWhere)->delete();
            $this->show_message(true, '删除成功', '/c/diancai_store/shangpin/?sid='.$storeDishes['sid']);return FALSE;
        }else{
            $this->show_message(false, '删除失败', '/c/diancai_store/shangpin/?sid='.$storeDishes['sid']);return FALSE;
        }
    }

    /**
     * @name  查看订单详情
     * @return bool
     */
    public function order_detail()
    {
        //订单id
        $id = $this->input->get('id');

        $orderDetail = $this->get_one_order_info($id);
        if(!$orderDetail)
        {
            $this->show_message(false, '订单不存在', '');return FALSE;
        }
        $storeInfo = $this->get_store($orderDetail['store_id']);
        if(!$storeInfo){
            $this->show_message(false, '门店不存在', '/c/diancai_store');return FALSE;
        }
        
        $this->load->model('model_address');
        $address = $this->model_address->get_row(array('id'=>$this->data['store']['address_id']));
        $orderDetail['address'] = $address ? $address['address'] : '';
        
        //订单商品
        $this->load->model('diancai_order_dishes_model');
        $orderDishes = $this->diancai_order_dishes_model->where(array('site_id'=>$this->site_id,'order_id'=>$id))->find_all();
        $this->data['orderDishes'] = $orderDishes;
        
        $this->data['detail'] = $orderDetail;
        
        $this->load->view($this->dcm, $this->data);
    }

    public function order_price()
    {
        $id = $this->input->post('id');

        $orderDetail = $this->get_one_order_info($id);
        if(!$orderDetail)
        {
            $this->show_message(false, '订单不存在', '');return FALSE;
        }
        $data = $this->input->post('data');
        if($orderDetail['order_status'] == 0)
        {
            $this->diancai_order_model->where(array('id'=>$id,'site_id'=>$this->site_id))->edit($data);
            $result['success'] = 1;
            $result['msg'] = '修改成功';

        }
        else
        {
            $result['success'] = 0;
            $result['msg'] = '当前订单不能修改总价';
        }

        echo json_encode($result);
        exit;
    }


    /**
     * @name 订单状态改为已付款
     * @return bool
     */
    public function order_payed()
    {
        $id = $this->input->post('id');
        $orderDetail = $this->get_one_order_info($id);
        if(!$orderDetail)
        {
            $this->show_message(false, '订单不存在', '');return FALSE;
        }
        //判断订单是否可以改成已支付状态
        if($orderDetail['pay_status']==0)
        {
            if($this->diancai_order_model->where(array('id'=>$id))->edit(array('pay_status'=>1,'pay_time'=>time())))
            {
                $result['success'] = 1;
                $result['msg'] = '修改成功';
            }
            else
            {
                $result['success'] = 0;
                $result['msg'] = '修改失败';
            }
        }
        else
        {
            $result['success'] = 0;
            $result['msg'] = '当前订单不支持修改成已付款';
        }
        echo json_encode($result);
        exit;
    }
    
    /**
     * @name 订单状态改为已确认
     * @return bool
     */
    public function order_status()
    {
        $id = $this->input->post('id');
        $orderDetail = $this->get_one_order_info($id);
        if(!$orderDetail)
        {
            $this->show_message(false, '订单不存在', '');return FALSE;
        }
        //判断订单是否可以改成已支付状态
        if($orderDetail['order_status']==0)
        {
            $this->load->model('diancai_store_model');
            $store = $this->diancai_store_model
                    ->select('wb_diancai_store.*,address.name as add_name,address.address,address.lat,address.lng,address.dayinji_type,address.printer_name,address.printer_secret')
                    ->join('address','address.id=wb_diancai_store.address_id','left')
                    ->where(array( 'wb_diancai_store.site_id'=>$this->site_id,'wb_diancai_store.id'=>$orderDetail['store_id'] ))
                    ->find();
            !$store && exit( json_encode(array('success'=>0,'msg'=>'修改失败')) );
            
            if($this->diancai_order_model->where(array('id'=>$id))->edit(array('order_status'=>1,'confirm_time'=>time())))
            {
                if( $store['printer_type']==3&&$store['printer_name'] ){//商家确认并打印
                    //打印订单
                    //订单商品
                    $this->load->model('diancai_order_dishes_model');
                    $order_dishes = $this->diancai_order_dishes_model->where(array('site_id'=>$this->site_id,'order_id'=>$orderDetail['id']))->find_all();
                    
                    $content = "CC!-CC!".date('Y-m-d H:i:s', $orderDetail['add_time'])."\n";
                    $content .= "--------------------------------\n";
                    $content .= '订单编号：'.$orderDetail['order_sn']."\n";
                    $content .= '门店名：'.$store['add_name']."\n地址：".$store['address']."\n";
                    $content .= '点菜人电话：'.$orderDetail['mobile']."\n";
                    $content .= '订单总价：￥'.$orderDetail['all_price']."\n";
                    $content .= '餐台：'.$orderDetail['desk_name']."\n";
                    $content .= "--------------------------------\n";
                    foreach( $order_dishes as $val ){
                        $content .= '【'.$val['dish_name'].' ￥'.$val['dish_price'].'】×'.$val['dish_num']."\n";
                    }
                    $orderDetail['mark'] && $content .= '订单备注：'.$orderDetail['mark']."\n";
                    
                    if( $orderDetail['pay_status']==0 ){
                        $partner_info = $this->get_partner_info();
                        $partner_info['partner_key'] = isset($partner_info['partner_key']) ? $partner_info['partner_key'] : '';
                        $pay_url['order_sn'] = $orderDetail['order_sn'];
                        $pay_url['relative_wxid'] = $orderDetail['relative_wxid'];
                        ksort($pay_url);
                        $pay_url['sign'] = md5( urldecode(http_build_query($pay_url)).$partner_info['partner_key'] );
                        $base_url = $this->create_url('data/diancai/scan_qrcode_pay');
                        $qr_content = $base_url.'?params='.base64_encode(json_encode($pay_url));
                        $content .= "--------------------------------\n";
                        $content .= "付款请在微信中扫描以下二维码付款\n";
                    }else{
                        $content .= "--------------------------------\n";
                        $content .= '付款单号：'.$orderDetail['payment_sn']."\n";
                        $content .= '付款方式：'.$orderDetail['payment_name']."\n";
                    }
                    if( $store['dayinji_type']==2 ){
                        $content = str_replace( "\n", "\\n", $content );
                    }
                    $store['printer_num'] = $store['printer_num'] ? intval($store['printer_num']) : 1;
                    for( $i=0;$i<$store['printer_num'];$i++ ){
                        if( $orderDetail['pay_status']==0 ){
                            $this->print_ticket($store,$content,'twin',$qr_content );
                        }else if( $orderDetail['pay_status']==1 ){
                            
                            $this->print_ticket($store,$content );
                        }
                    }
                }
                
                $result['success'] = 1;
                $result['msg'] = '修改成功';
            }
            else
            {
                $result['success'] = 0;
                $result['msg'] = '修改失败';
            }
        }
        else
        {
            $result['success'] = 0;
            $result['msg'] = '当前订单不支持修改成已付款';
        }
        echo json_encode($result);
        exit;
    }
    
    /**
     * @name 订单状态改为已完成
     * @return bool
     */
    public function order_over()
    {
        $id = $this->input->post('id');
        $orderDetail = $this->get_one_order_info($id);
        if(!$orderDetail)
        {
            $this->show_message(false, '订单不存在', '');return FALSE;
        }
        //判断订单是否可以改成已支付状态
        if($orderDetail['order_status']==1)
        {
            if($this->diancai_order_model->where(array('id'=>$id))->edit(array('order_status'=>2)))
            {
                $starttime = strtotime(date('Y-m-d',$orderDetail['add_time']));
                $this->db
                    ->where(array('site_id'=>$this->site_id,'store_id'=>$orderDetail['store_id'],'add_time'=>$starttime))
                    ->set('valid_order', 'valid_order+1', FALSE)
                    ->set('invalid_order', 'invalid_order-1', FALSE)
                    ->set('total_price','total_price+'.$orderDetail['all_price'],false)
                    ->set('avg_price','total_price/total_order',false)
                    ->update('wb_diancai_order_statistics');
                
                //修改餐台状态
                $this->load->model('diancai_desk_model');
                $this->diancai_desk_model->where(array('id'=>$orderDetail['desk_id']))->edit(array('status'=>0,'dinning_person'=>'','dinning_time'=>0));
                
                
                $result['success'] = 1;
                $result['msg'] = '修改成功';
            }
            else
            {
                $result['success'] = 0;
                $result['msg'] = '修改失败';
            }
        }
        else
        {
            $result['success'] = 0;
            $result['msg'] = '当前订单不支持修改成已完成';
        }
        echo json_encode($result);
        exit;
    }


    /**
     * 修改商家备注
     */
    public function order_cmark()
    {
        $id = $this->input->post('id');
        $orderDetail = $this->get_one_order_info($id);
        if(!$orderDetail)
        {
            $this->show_message(false, '订单不存在', '');return FALSE;
        }
        $cmark = $this->input->post('cmark');
        if($this->diancai_order_model->where(array('id'=>$id))->edit(array('cmark'=>$cmark)))
        {
            $result['success'] = 1;
            $result['msg'] = '备注修改成功';
        }
        else
        {
            $result['success'] = 0;
            $result['msg'] = '操作失败';
        }
        echo json_encode($result);
        exit;
    }
    
    //打印订单
    public function order_print()
    {
        $id = $this->input->post('id');
        
        $orderDetail = $this->get_one_order_info($id);
        if(!$orderDetail)
        {
            $this->show_message(false, '订单不存在', '');return FALSE;
        }
        $storeInfo = $this->get_store($orderDetail['store_id']);
        
        if(!$storeInfo){
            $this->show_message(false, '门店不存在', '/c/diancai_store');return FALSE;
        }
        
        $this->load->model('model_address');
        $address = $this->model_address->get_row(array('id'=>$this->data['store']['address_id']));
        if( !$address ){
            $result['success'] = 0;
            $result['msg'] = '没有找到小票打印机';
            exit(json_encode($result));
        }
        if( !$address['printer_name']||!$address['printer_secret'] ){
            $result['success'] = 0;
            $result['msg'] = '请先配置好小票打印机';
            exit(json_encode($result));
        }
        
        $content = "CC!-CC!".date('Y-m-d H:i:s', $orderDetail['add_time'])."\n";
        $content .= "--------------------------------\n";
        $content .= '订单编号：'.$orderDetail['order_sn']."\n";
        $content .= '门店名：'.$address['name']."\n地址：".$address['address']."\n";
        $content .= '点菜人电话：'.$orderDetail['mobile']."\n";
        $content .= '订单总价：￥'.$orderDetail['all_price']."\n";
        $content .= '餐台：'.$orderDetail['desk_name']."\n";
        $content .= "--------------------------------\n";
        
        //订单商品
        $this->load->model('diancai_order_dishes_model');
        $orderDishes = $this->diancai_order_dishes_model->where(array('site_id'=>$this->site_id,'order_id'=>$orderDetail['id']))->find_all();
        if( $orderDishes ){
            foreach( $orderDishes as $val ){
                $content .= '【'.$val['dish_name'].' ￥'.$val['dish_price'].'】×'.$val['dish_num']."\n";
            }
        }
        $orderDetail['mark'] && $content .= '订单备注：'.$orderDetail['mark']."\n";
        
        if( $orderDetail['pay_status']==0 ){
            $partner_info = $this->get_partner_info();
            $partner_info['partner_key'] = isset($partner_info['partner_key']) ? $partner_info['partner_key'] : '';
            $pay_url['order_sn'] = $orderDetail['order_sn'];
            $pay_url['relative_wxid'] = $orderDetail['relative_wxid'];
            ksort($pay_url);
            $pay_url['sign'] = md5( urldecode(http_build_query($pay_url)).$partner_info['partner_key'] );
            $base_url = $this->create_url('data/diancai/scan_qrcode_pay');
            $qr_content = $base_url.'?params='.base64_encode(json_encode($pay_url));
            $content .= "--------------------------------\n";
            $content .= "付款请在微信中扫描以下二维码付款\n";
        }else{
            $content .= "--------------------------------\n";
            $content .= '付款单号：'.$orderDetail['payment_sn']."\n";
            $content .= '付款方式：'.$orderDetail['payment_name']."\n";
        }
        $this->data['store']['printer_num'] = $this->data['store']['printer_num'] ? $this->data['store']['printer_num'] : 1;
        
        $this->load->model('model_address');
        $address = $this->model_address->get_row(array('id'=>$this->data['store']['address_id']));
        if( $address['dayinji_type']==2 ){
            $content = str_replace( "\n", "\\n", $content );
        }
        for( $i=0;$i<$this->data['store']['printer_num'];$i++ ){
            if( $orderDetail['pay_status']==0 ){
                $this->print_ticket($address,$content,'twin',$qr_content );
            }else if( $orderDetail['pay_status']==1 ){
                $this->print_ticket($address,$content );
            }
        }
        
        $result['success'] = 1;
        $result['msg'] = '已加入到打印队列';
        exit(json_encode($result));
    }
    
    //订单列表
    public function order_list($store_id)
    {
        $res = $this->get_store($store_id);
        if( !$res ){
            $this->show_message(false, '非法操作', '/c/diancai_store');return FALSE;
        }
        $this->load->model('diancai_order_model');
        
        $where = " site_id = '".$this->site_id."'  AND store_id = ".$store_id;
        
        $search = array();
        $search['type'] = $this->input->get('type');
        $search['keyword'] = $this->input->get('keyword');
        $search['order_status'] = $this->input->get('order_status');
        $search['pay_status'] = $this->input->get('pay_status');
        $this->data['search'] = $search;
        $search_url = site_url($this->uri->uri_string().'?'.http_build_query($search));
        
        if( $search['type']&&$search['keyword'] ){
            switch($search['type']){//手机号码/订单号
                case 1:
                    $where .= " AND mobile LIKE '%".$search['keyword']."%'";
                    break;
                case 2:
                    $where .= " AND order_sn LIKE '%".$search['keyword']."%'";
                    break;
                default:break;
            }
        }
        if( $search['order_status']!='' ){
            $where .= " AND order_status = ".intval($search['order_status']);
        }
        if( $search['pay_status']!='' ){
            $where .= " AND pay_status = ".intval($search['pay_status']);
        }
        
        $total_rows = $this->diancai_order_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$search_url));
        $list = $this->diancai_order_model
                ->select('id,order_sn,all_price,order_status,pay_status,mobile,desk_name,add_time,payment_name')
                ->where($where)
                ->order_by('id desc')
                ->limit($pager['limit']['value'], $pager['limit']['offset'])->find_all();
        
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->load->view($this->dcm, $this->data);
    }

    /**
     * 订单导出
     */
    public function order_export()
    {
        $sid = $this->input->get_post('sid');
        $res = $this->get_store($sid);
        if( !$res ){
            $this->show_message(false, '非法操作', '/c/diancai_store');return FALSE;
        }
        $this->load->model('diancai_order_model');
        
        $where = " site_id = '".$this->site_id."'  AND store_id = ".$sid;
        
        $search = array();
        $search['type'] = $this->input->get('type');
        $search['keyword'] = $this->input->get('keyword');
        $search['order_status'] = $this->input->get('order_status');
        $search['pay_status'] = $this->input->get('pay_status');
        $this->data['search'] = $search;
        $search_url = site_url($this->uri->uri_string().'?'.http_build_query($search));
        
        if( $search['type']&&$search['keyword'] ){
            switch($search['type']){//手机号码/订单号
                case 1:
                    $where .= " AND mobile LIKE '%".$search['keyword']."%'";
                    break;
                case 2:
                    $where .= " AND order_sn LIKE '%".$search['keyword']."%'";
                    break;
                default:break;
            }
        }
        if( $search['order_status']!='' ){
            $where .= " AND order_status = ".intval($search['order_status']);
        }
        if( $search['pay_status']!='' ){
            $where .= " AND pay_status = ".intval($search['pay_status']);
        }

        $orders = $this->diancai_order_model
                ->select('*')
                ->where($where)->order_by('id desc')->find_all();
        $orders = $orders ? $orders : array();
        foreach($orders as &$order) {
            $order['add_time'] = date('Y-m-d H:i:s', $order['add_time']);
            $order['pay_time'] = $order['pay_time'] ? date('Y-m-d H:i:s', $order['pay_time']) : '';
            $order['confirm_time'] = $order['confirm_time'] ? date('Y-m-d H:i:s', $order['confirm_time']) : '';
            $order['order_status'] = $order['order_status'] ? '已确认订单' : '未确认订单';
            $order['pay_status'] = $order['pay_status'] ? '已付款' : '未付款';

            //订单菜品
            $this->load->model('diancai_order_dishes_model');
            $item_list = $this->diancai_order_dishes_model->where(array('site_id'=>$this->site_id,'order_id'=>$order['id']))->find_all();

            $items = '';
            foreach($item_list as $item) {
                $items .= "菜品：".$item['dish_name'].", 单价：".$item['dish_price'].", 数量：".$item['dish_num']."; ";
            }
            $items = $items ? $items : '该订单中没有菜品';
            $order['items'] = $items;
        }

        $fields = array(
            '#'=>'#',
            'order_sn'=>'订单号',
            'add_time'=>'下单时间',
            'mobile'=>'手机号码',
            'all_price'=>'总价',
            'items'=>'订单商品',
            'order_status' => '订单状态',
            'confirm_time' => '确认订单时间',
            'pay_status' => '支付状态',    
            'payment_name'=>'支付方式',
            'pay_time'=>'付款时间',
            'mark'=>'用户备注',
            'cmark'=>'商家备注'
        );
        
        $this->excel_export($this->data['store']['address'].'订单列表', '订单列表', $fields, $orders);
    }
    
    //获取支付配置
    private function get_partner_info()
    {
        $this->load->model('user_partner_model');
        $where['site_id'] = $this->site_id;
        $partner_info = $this->user_partner_model->where($where)->find();
        return $partner_info;
    }

    //获取点菜配置
    private function get_config()
    {
        $where = array(
            'site_id' => $this->site_id
        );
        $diancai = $this->diancai_model->where($where)->find();
        $diancai = $diancai ? $diancai : array();
        $this->data['diancai'] = $diancai;
        return $diancai;
    }

    //获得一个订单详情
    private function get_one_order_info($id)
    {
        $where = array(
            'site_id'  => $this->site_id,
            'id' => $id
        );
        $orderDetail = $this->diancai_order_model
            ->select('*')
            ->where($where)->find();
        if(!$orderDetail)
        {
            return false;
        }
        else
        {
            return $orderDetail;
        }
    }
    //检查图片格式
    public function _check_image($image) {
        if ($image) {
            if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
                $this->form_validation->set_message('_check_image', '图片地址格式错误');
                return FALSE;
            }
        }
        return TRUE;
    }
} 