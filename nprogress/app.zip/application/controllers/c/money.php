<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Created by PhpStorm.
 * User: andery
 * Date: 13-12-4
 * Time: 上午11:41
 */

class Money extends C_Controller {

    protected $auto_load_model = TRUE;
    protected $model_name = 'money_record';
    protected $mongo_money = 'money';

    /**
     * 设置放在这里
     */
    public function index()
    {
        $this->load->library('Mongo_db');
        $money_setting = $this->mongo_db->where(array('site_id'=>$this->site_info['id']))->get_one($this->mongo_money);
        if($this->input->post()) {
            $data['on'] = $this->input->post('on');
            $data['min_money'] = $this->input->post('min_money') ? round($this->input->post('min_money'),2) : 0.00;
            $money = $this->input->post('money') ? $this->input->post('money') : array();
            $gift_money = $this->input->post('gift_money') ? $this->input->post('gift_money') : array();
            $accumulate = $this->input->post('accumulate') ? $this->input->post('accumulate') : array();
            $data['consume_rules'] = array();
            foreach($money as $k=>$m) {
                if(!is_numeric($m) || $m <= 0){
                    $this->show_message(FALSE, '消费金额必须是正数', '/c/money');
                    return FALSE;
                }
                if(!is_numeric($gift_money[$k]) || $gift_money[$k] <= 0){
                    $this->show_message(FALSE, '赠送金额必须是正数', '/c/money');
                    return FALSE;
                }
                $item = array();
                $item['money'] = $m;
                $item['gift_money'] = $gift_money[$k];
                $item['accumulate'] = isset($accumulate[$k]) ? $accumulate[$k] : '0';
                $data['consume_rules'][] = $item;
            }
            $money2 = $this->input->post('money2') ? $this->input->post('money2') : array();
            $gift_money2 = $this->input->post('gift_money2') ? $this->input->post('gift_money2') : array();
            $accumulate2 = $this->input->post('accumulate2') ? $this->input->post('accumulate2') : array();
            $data['recharge_rules'] = array();
            foreach($money2 as $k=>$m) {
                if(!is_numeric($m) || $m <= 0){
                    $this->show_message(FALSE, '充值金额必须是正数', '/c/money');
                    return FALSE;
                }
                if(!is_numeric($gift_money2[$k]) || $gift_money2[$k] <= 0){
                    $this->show_message(FALSE, '赠送金额必须是正数', '/c/money');
                    return FALSE;
                }
                $item = array();
                $item['money'] = $m;
                $item['gift_money'] = $gift_money2[$k];
                $item['accumulate'] = isset($accumulate2[$k]) ? $accumulate2[$k] : '0';
                $data['recharge_rules'][] = $item;
            }

            if($money_setting) { //更新
                if($this->mongo_db->where(array('site_id'=>$this->site_info['id']))->set($data)->update($this->mongo_money)) {
                    $this->show_message(TRUE, '保存成功', '/c/money');
                    return FALSE;
                } else {
                    $this->show_message(FALSE, '保存失败', '/c/money');
                    return FALSE;
                }
            } else { //添加
                $data['site_id'] = $this->site_info['id'];
                if($this->mongo_db->insert($this->mongo_money, $data)) {
                    $this->show_message(TRUE, '保存成功', '/c/money');
                    return FALSE;
                } else {
                    $this->show_message(FALSE, '保存失败', '/c/money');
                    return FALSE;
                }
            }
        } else {
            $this->data['money'] = $money_setting;
            $this->load->view($this->dcm, $this->data);
        }
    }

    /**
     * 记录
     */
    public function record($mid = 0)
    {
        $where['site_id'] = $this->site_info['id'];
        $mid && $where['mid'] = $mid;
        $search['from_time'] = $this->input->get('from_time') ? $this->input->get('from_time') : '';
        $search['to_time'] = $this->input->get('to_time') ? $this->input->get('to_time') : '';
        $search['username'] = $this->input->get('username') ? $this->input->get('username') : '';
        $search['money'] = $this->input->get('money') ? $this->input->get('money') : '';
        $this->data['search'] = $search;

        $search['from_time'] && $where['dt_record >='] = strtotime($search['from_time']);
        $search['to_time'] && $where['dt_record <='] = strtotime($search['to_time']);
        $search['money'] && $where['money'] = $search['money'];

        $this->model->where($where);
        $search['username'] && $model = $this->model->like('username', $search['username']);
        $total_rows = $this->model->count();
        $pager = $this->_pager($total_rows, array(
            'base_url' => site_url($this->uri->uri_string().'?').$_SERVER['QUERY_STRING']
        ));
        $this->model->where($where);
        $search['username'] && $model = $this->model->like('username', $search['username']);
        $list = $this->model->order_by('dt_record desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->find_all();

        $this->data['list'] = $list;
        $mid && ($this->data['mid'] = $mid);
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->load->view($this->dcm, $this->data);
    }

    public function export()
    {
        $where['site_id'] = $this->site_info['id'];
        $search['from_time'] = $this->input->get('from_time') ? $this->input->get('from_time') : '';
        $search['to_time'] = $this->input->get('to_time') ? $this->input->get('to_time') : '';
        $search['username'] = $this->input->get('username') ? $this->input->get('username') : '';
        $search['money'] = $this->input->get('money') ? $this->input->get('money') : '';
        $this->data['search'] = $search;

        $search['from_time'] && $where['dt_record >='] = strtotime($search['from_time']);
        $search['to_time'] && $where['dt_record <='] = strtotime($search['to_time']);
        $search['money'] && $where['money'] = $search['money'];

        $this->model->where($where);
        $search['username'] && $model = $this->model->like('username', $search['username']);
        $list = $this->model->order_by('dt_record desc')->find_all();
        $mlist = array();
        if($list)
        {
            foreach($list as $key=> $item)
            {
                $mlist[$key]['dt_record'] = date('Y-m-d H:i:s', $item['dt_record']);
                $mlist[$key]['username'] = $item['username'];
                $mlist[$key]['money'] = $item['money'];
                $mlist[$key]['remark'] = $item['remark'];
            }

            $fields = array(
                '#'=>'#',
                'dt_record'=>'时间',
                'username'=>'用户名',
                'money'=>'金额',
                'remark'=>'说明'
            );
            $this->excel_export('消费记录列表', '消费记录列表', $fields, $mlist);
        }
        else
        {
            $this->show_message(FALSE, '尚无消费记录可导出', '/c/money/record');
        }
    }
}