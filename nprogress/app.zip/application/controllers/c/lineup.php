<?php
/**
 * Created by PhpStorm.
 * User: songxiyao
 * Date: 2014/10/21
 * Time: 15:21
 */
class Lineup extends C_Controller {

    protected $site_id = '';
    protected $user = array();
    protected $_token_wx_server = TOKEN_WX_SERVER;
    protected $access_token = '';
    protected $data = '';
    private   $mongo_wx_lineup_set = MONGO_WX_LINEUP_SET;
    protected $wx_info;
    protected $post_data;
    protected $qudaoconfig = array();

    public function __construct() {
        parent::__construct();

        $this->load->library('wbcurl');
        $this->load->library('Mongo_db');

        $this->load->model('user_auth_model');
        $this->load->model('app_model');

        $this->site_id = $this->site_info['id'];
        $appid = $this->app_model->where(array('module' => 'c/lineup'))->find();
        $app_list = $this->user_auth_model->select('id')->where(array('user_id'=>$this->site_id,'app_id'=>$appid['id']))->find();
        if(!$app_list){
            echo "<script> alert('您还没有购买该应用');parent.location.href='http://www.bama555.com'; </script>";
            exit;
        }
        $this->post_data = $this->mongo_db->where(array('site_id'=>$this->site_id))->get_one(MONGO_WX_SET);
        $response = $this->wbcurl->simple_post($this->_token_wx_server . 'info',array('app_id' => $this->post_data['appid']) );
        $this->wx_info = json_decode($response,true);
       if($this->wx_info['ret'] == 0){
           $ability_rank = $this->wx_info['ability_rank'];
       }else{
           $ability_rank = -1;
       }
        if(!$this->post_data || $ability_rank == -1){
            echo "<script> alert('您没有高级接口权限或者帐号信息配置不正确');parent.location.href='http://www.bama555.com'; </script>";
            exit;
        }else{
            //初始化lineup数据
            $this->data['qudaoconfig'] = $this->qudaoconfig = $this->get_config();
            $this->initLineUp($this->site_id);

            $this->load->model('lineup_model');
            //查询开启信息
            $options = array(
                'select' => 'id, status',
                'where'  => array(
                    'wid' => $this->site_id
                ),
            );
            $this->status_info = $this->lineup_model->find($options);
        }


    }

    /**
     * 微信公众号 appid
     */
    private function get_config()
    {
        if(!($this->wx_info['ability_rank'] & 2)){
            $config['is_qrcode_api'] = 0;
        }else{
            $config['is_qrcode_api'] = 1;
        }

        if(!$this->wx_info['token']){
            $this->show_message(true,'appid或secret错误','/c/lineup/lineups_list');
            return false;
        }else{
            $config['token'] = $this->wx_info['token'];
        }

        return $config;

    }

    public function lineups_list() {
        if(!($this->wx_info['ability_rank'] & 2)){
            $this->show_message(TRUE, '该应用仅支持认证服务号');
            return false;
        }
        $this->data['qrcodeurl'] = 'http://www.bama555.com/c/lineup/led';
        $this->data['bigurl'] = 'http://www.bama555.com/c/Led/led?id='.$this->site_id;
        $this->data['url'] = full_url('queue', $this->site_info['domain']);
        $this->data['channelurl'] = full_url('queue/login', $this->site_info['domain']);
        $status = $this->input->get('status') ?: 0;
        $this->load->model('lineup_member_model', 'lineup_member');
        //$type_list = $this->lineup_member->where(array( 'wb_lineup_member.lineup_id' => $this->status_info['id']))->find();


        //查询类型名称
        $this->load->model('lineup_config_model', 'lineup_config');
        $type_data = $this->lineup_config->select('cfg_type')->where(array('lineup_id'=> $this->status_info['id']))->find();
        $this->data['type'] = array();
        if ($type_data) {
            $type_data = json_decode($type_data['cfg_type'], true);
            if($type_data){
                foreach ($type_data as $v) {
                    $this->data['type'][] = $v['type'] ? $v['type'] : '';
                }
                $type = $this->input->get('type') ? $this->input->get('type') : $type_data['0']['type'];
            }else{
                $type = $this->input->get('type') ? $this->input->get('type') : '';
            }
        }else{
            $type = $this->input->get('type') ? $this->input->get('type') : '';
        }

        $tmp_type = $this->input->get('type');
        $this->data['tmp_type'] = $tmp_type;
        $options = array(
            'select' => 'wb_lineup_member.id,wb_lineup_member.type,wb_lineup_member.open_id, wb_lineup_member.type_name, wb_lineup_member.number , wb_lineup_member.dt_add, wb_lineup_member.status',
            'where'  => array(
                'wb_lineup_member.status' => $status,
                'wb_lineup_member.lineup_id' => $this->status_info['id'],
                'wb_lineup_member.reset' => 0
            ),
        );

        $type && $options['where']['type'] = $type;


        $member_count_options = array(
            'where' => array(
                'wb_lineup_member.status' => 0,
                'wb_lineup_member.lineup_id' => $this->status_info['id'],
                'wb_lineup_member.reset' => 0
            )
        );

        $type && $member_count_options['where']['type'] = $type;


        $member_count = $this->lineup_member->count($member_count_options);
        $url = site_url($this->uri->uri_string().'?');
        $pager = $this->_pager($member_count,array('per_page'=>15,'base_url'=>$url));
        $this->data['list'] = $this->lineup_member->limit($pager['limit']['value'], $pager['limit']['offset'])
            //->join('account', 'wb_lineup_member.open_id = account.wxid', 'left')
            ->order_by("dt_add", "asc")
            ->find_all($options);

        if(is_array($this->data['list'])){
            foreach ($this->data['list'] as $k => $v) {
                $this->data['list'][$k]['dt_add'] = date('Y-m-d H:i', $v['dt_add']);
                if($tmp_type){
                    $this->data['list'][$k]['number'] = $tmp_type.$v['number'];
                }else{
                    $this->data['list'][$k]['number'] = $this->data['list'][0]['type'].$this->data['list'][$k]['number'];
                }

                //查询当前已经排队的多长时间
                $this->data['list'][$k]['is_waiting'] = $this->_showTime($v['dt_add']);
                //从mongoDB获取用户头像和昵称
                $ret = $this->mongo_db->where(array('open_id' => $v['open_id']))->get_one($this->mongo_wx_lineup_set);
                $this->data['list'][$k]['avatar'] = $ret['avatar'] ? $ret['avatar'] : '';
                $this->data['list'][$k]['nickname'] = $ret['nickname'] ? $ret['nickname'] : '';

            }
        }
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->data['lineup'] = $member_count;//当前正在排队人数


        //开始排号、暂停排号
        $status = $this->input->get('status');
        $lineup_id = $this->status_info['id'];
        $this->load->model('lineup_model');
        if($status == 'start'){
            $ret = $this->lineup_model->where(array('id' => $lineup_id))->set_field(array('status' => 1));
            $this->data['status'] = 1;
        }elseif($status == 'stop'){
            $ret = $this->lineup_model->where(array('id' => $lineup_id))->set_field(array('status' => 2));
            $this->data['status'] = 2;
        }else{
            $temp = $this->lineup_model->where(array('id' => $lineup_id))->find();
            $this->data['status'] = $temp['status'];
        }
        $this->load->view('/c/lineup/lineups_list', $this->data);
    }

    protected function _showTime($time) {
        $now_time = time();
        $diff_time = $now_time - $time;
        if ($diff_time < 60) {
            return $diff_time . "秒";
        } else if ($diff_time >= 60 && $diff_time < 3600) {
            return ceil($diff_time / 60) . "分钟";
        } else if ($diff_time >= 3600) {
            return ceil($diff_time / 3600) . "小时";
        }
    }

    //排号设置
    public function setting() {
        if(!($this->wx_info['ability_rank'] & 2)){
            $this->show_message(TRUE, '该应用仅支持认证服务号');
            return false;
        }
        //查询配置
        $this->load->model('lineup_config_model', 'lineup_config');
        $options = array(
            'select' => 'cfg_msg, cfg_type, cfg_other,contact_mobile,name',
            'where'  => array(
                'lineup_id' => $this->status_info['id']
            ),
        );
        $lineup_config = $this->lineup_config->find($options);
        $this->data['cfg_msg'] = json_decode($lineup_config['cfg_msg'], true);
        $cfg_type = json_decode($lineup_config['cfg_type'], true);
        $this->data['cfg_type'] = empty($cfg_type) ? array(array("type" => "A", "type_name" => "")) : $cfg_type;
        $this->data['cfg_other'] = json_decode($lineup_config['cfg_other'], true);
        $this->data['contact_mobile'] = $lineup_config['contact_mobile'] ? $lineup_config['contact_mobile'] : '';
        $this->data['name'] = $lineup_config['name'] ? $lineup_config['name'] : '';
        if ($this->input->post()) {
            $type = $this->input->post('sub_type');
            if ($type == 'cfg_msg') {
                $data = array(
                    'cfg_msg' => json_encode($this->input->post('num'))
                );
            } else if ($type == 'cfg_type') {
                $type_arr = $this->input->post('type');
                $type_name = $this->input->post('type_name');
                foreach ($type_arr as $k => $v) {
                    if ($type_name[$k] != "") {
                        $data[] = array(
                            'type'      => $v,
                            'type_name' => $type_name[$k]
                        );
                    } else {
                        $this->show_message('TRUE', '排号类型不能为空');
                        return false;
                    }
                    $data_type[$v] = '';
                }
                if (count($data_type) != count($type_arr)) {
                    $this->show_message('TRUE', '排号类型有相同项');
                    return false;
                }
                $data = array(
                    'cfg_type' => json_encode($data)
                );
            } else if ($type == 'cfg_other') {
                $data = array(
                    'cfg_other' => json_encode(array(
                        'num'   => $this->input->post('num'),
                        'intro' => $this->input->post('intro'),
                    )),
                'contact_mobile' => $this->input->post('contact_mobile'),
                'name' => $this->input->post('name'));
            }
            if (empty($options)) {
                $data['lineup_id'] = $this->status_info['id'];
                $this->lineup_config->add($data);
                $this->show_message(true,'保存成功','/c/lineup/setting');
                return ;
            } else {
                $this->lineup_config->where(array('lineup_id' => $this->status_info['id']))->edit($data);
                $this->show_message(true,'保存成功','/c/lineup/setting');
                return ;
            }
            $this->data[$type] = json_decode($data[$type], true);
        }
        $this->data['type'] = $this->input->get('type');
        $this->load->view($this->dcm, $this->data);

    }

    //成功使用
    public function lineup_used() {
        $id = $this->input->get('id');
        //查询改号码的详情
        $this->load->model('lineup_member_model', 'lineup_member');
        $options = array(
            'select' => 'lineup_id,open_id,type, status, dt_add',
            'where'  => array(
                'id' => $id,
            ),
        );
        $number_info = $this->lineup_member->find($options);
        $update_data = array(
            'status'  => 1,
            'dt_used' => time(),
        );
        if (!$number_info) {
            $this->show_message(true,'数据不存在','/c/lineup/lineups_list');
            return false;
        }

        elseif ($number_info['status'] > 0) {
            $this->show_message(true,'该号码已失效','/c/lineup/lineups_list');
            return false;
        }
        //超过一天以上，就失效
        elseif (date('Ynd') > date('Ynd', $number_info['dt_add'])) {
            $this->show_message(true,'该号码已过期','/c/lineup/lineups_list');
            return false;

        }elseif (!$this->lineup_member->where('id', $id)->edit($update_data)) {
            $this->show_message(true,'使用失败','/c/lineup/lineups_list');

        } else {
            //使用成功发送通知
            $this->_send_notice($number_info);
            $this->show_message(true,'使用成功','/c/lineup/lineups_list');
            return false;
        }
    }

    protected function _send_notice($cur_number_info) {

        $open_id = $cur_number_info['open_id'];
        //查询当前商家的配置
        $this->load->model('lineup_config_model', 'lineup_config');
        $options = array(
            'select' => 'cfg_msg, cfg_type, cfg_other,name',
            'where'  => array(
                'lineup_id' => $cur_number_info['lineup_id']
            ),
        );

        $config_info = $this->lineup_config->find($options);

        if($config_info){
            $msg_info = implode(",", json_decode($config_info['cfg_msg'], true));
        }

        //等待叫号的人
        $notice_options = array(
            'select' => 'open_id, number, dt_add,type, type_name',
            'where'  => array(
                'lineup_id' => $cur_number_info['lineup_id'],
                'status'    => 0,
                'type'      => $cur_number_info['type'],
                'reset'     => 0,
                'dt_add >=' => strtotime(date('Y-m-d', time())),
                'dt_add <'  => strtotime(date('Y-m-d', time())) + 24 * 3600, //只查询当天的排号
            ),
            'limit'  => 10 //每种类型最多到10人
        );
        $this->load->model('lineup_member_model', 'lineup_member');
        $notice_member = $this->lineup_member->order_by('dt_add', 'asc')->find_all($notice_options);

        $this->load->library('wechat', array(
            'app_id' => $this->post_data['appid'],
            'secret' => $this->post_data['appscret']));

        foreach ($notice_member as $k => $v) {
            if (strpos($msg_info, (string)$k) !== false) {
                if($k==0){
                    $msg = "恭喜您，轮到您的号码了"."\n\n" .
                        "号码：" .$v['type'] . $v['number'] . "\n" .
                        "类型：".$v['type_name']. "\n".
                        "商家：".$config_info['name']."\n".
                        "取号时间:" . date('m-d H:i',$v['dt_add']) . "\n\n".
                        "<a href=\"" . full_url('queue', $this->site_info['domain']) . "\">更多详情</a>";
                }else{
                    $msg = "您前面还有".$k."位顾客"."\n\n"  .
                        "号码：" .$v['type'] . $v['number'] . "\n" .
                        "类型：".$v['type_name']. "\n".
                        "商家：".$config_info['name']."\n".
                        "取号时间:" . date('m-d H:i',$v['dt_add']) . "\n\n".
                        "<a href=\"" . full_url('queue', $this->site_info['domain']) . "\">更多详情</a>";
                }

                //文本发送
                if(!empty($msg)) {
                    $msg = str_replace('/', '\/', str_replace('"', '\"', $msg));
                    $post = array(
                        'touser' => $v['open_id'],
                        'msgtype' => 'text',
                        'text' => array(
                            'content' => urlencode($msg)
                        )
                    );

                    $post_json = urldecode(json_encode($post));
                    //$post_json = json_encode($post);
                    $this->wechat->message_custom_post($post_json, $this->wx_info['token']);
                }

            }
        }
    }


    public function lineup_member_update() {
        $lineup_id = $this->status_info['id'];
        $this->load->model('lineup_member_model', 'lineup_member');
        $ret = $this->lineup_member->where(array('lineup_id' => $lineup_id))->set_field(array('reset' => 1));
        if($ret){
            $this->show_message(true,'重置成功','/c/lineup/lineups_list');
        }
    }


    //过号失效
    public function invalid(){
        $id = $this->input->get('id');
        $this->load->model('lineup_member_model', 'lineup_member');
        //查询改号码的详情
        $options = array(
            'select' => 'lineup_id,open_id, type, status, dt_add',
            'where'  => array(
                'id' => $id,
            ),
        );
        $number_info = $this->lineup_member->find($options);
        if (!$number_info) {

            $this->show_message(true,'数据不存在','/c/lineup/lineups_list');
            return false;
        }

        if ($number_info['status'] > 0) {

            $this->show_message(true,'该号码已失效','/c/lineup/lineups_list');
            return false;
        }
        //超过一天以上，就失效
        if (date('Ynd') > date('Ynd', $number_info['dt_add'])) {

            $this->show_message(true,'该号码已过期','/c/lineup/lineups_list');
            return false;
        }

        $update_data = array(
            'status'  => 2,
            'dt_used' => time(),
        );
        $ret = $this->lineup_member->where(array('id' => $id))->edit($update_data);
        if(!$ret){
            $this->show_message(true,'修改失败','/c/lineup/lineups_list');
        }else{
            //失效成功，发送通知
            //查询站点相关信息
            $this->load->model('lineup_config_model', 'lineup_config');
            $options = array(
                'select' => 'cfg_other',
                'where'  => array(
                    'lineup_id' => $this->status_info['id']
                ),
            );
            $config_info = $this->lineup_config->find($options);

            $other_info = json_decode($config_info['cfg_other'], true);
            //如果设置过号提醒，查询当天过号的人数

            if (isset($other_info['num']) && $other_info['num'] >= 0) {
                $post = array(
                    'touser'  => $number_info['open_id'],
                    'msgtype' => 'text',
                    'text'    => array(
                        'content' => urlencode("您已过号。过号不作废，过号" . $other_info['num'] . "位内还可使用")
                    )
                );
                //如果设置过号提醒，查询当天过号的人数
                if (isset($other['num']) && $other_info['num'] > 0) {
                    $this->_send_msg(urlencode("您已过号。过号不作废，过号" . $other_info['num'] . "位内还可使用"),$id, $number_info['open_id']);
                } else if (isset($other['num']) && $other_info['num'] == 0) {
                    $this->_send_msg(urlencode("您已经过号，请重新排号"),$id, $number_info['open_id']);
                }

                $this->_send_notice($number_info);
                $post_json = urldecode(json_encode($post));
                //$this->wechat->message_custom_post($post_json, $access_token);
            }
            $this->_send_msg("您已经过号，请重新排号",$id, $number_info['open_id']);
            $this->show_message(true,'过号失效','/c/lineup/lineups_list');
        }
    }


    public function lineup_counts() {
        if(!($this->wx_info['ability_rank'] & 2)){
            $this->show_message(TRUE, '该应用仅支持认证服务号');
            return false;
        }
        $options = array(
            'where' => array(
                'lineup_id' => $this->status_info['id']
            ),
        );

        $this->load->model('lineup_member_model', 'lineup_member');

        $response = array();
        //累计排号人数
        $_count = count($this->lineup_member->select('open_id')->distinct()->find_all($options));
        $this->data['_count'] = $_count;

        $url = site_url($this->uri->uri_string().'?');
        $pager = $this->_pager($_count,array('per_page'=>15,'base_url'=>$url));
        $open_id_arr = $this->lineup_member->select('open_id')->distinct()->limit($pager['limit']['value'], $pager['limit']['offset'])->find_all($options);
        $new_open_id_arr = array();
        if (!empty($open_id_arr)) {
            foreach ($open_id_arr as $v) {
                $new_open_id_arr[] = $v['open_id'];
            }
        }
        //累计排号总次数
        $this->data['lineup_member'] = $this->lineup_member->count($options);

        //查询黑名单列表
        $this->load->model('lineup_invalid_model', 'lineup_invalid');
        $invalid_options = array(
            'select' => 'open_id, id',
            'where'  => array(
                'wb_lineup_invalid.lineup_id' => $this->status_info['id']
            ),
        );
        $invalid_data = $this->lineup_invalid->find_all($invalid_options);
        $invalid_str = '';
        if (!empty($invalid_data)) {
            foreach ($invalid_data as $k => $v) {
                $invalid_str .= $v['open_id'] . ",";
            }
        }
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $options['select'] = 'count(wb_lineup_member.status) as status_count, wb_lineup_member.id, wb_lineup_member.open_id, wb_lineup_member.status ';
        !empty($new_open_id_arr) && $options['where_in']['wb_lineup_member.open_id'] = $new_open_id_arr;
        $lineup_member = $this->lineup_member->limit($pager['limit']['value'], $pager['limit']['offset'])
            /*->join('account', 'wb_lineup_member.open_id = account.wxid', 'left')*/
            ->group_by(array('wb_lineup_member.open_id', 'wb_lineup_member.status'))
            ->order_by('wb_lineup_member.dt_add')
            ->find_all($options);
        $list = array();
        if (!empty($lineup_member)) {
            foreach ($lineup_member as $v) {
                $ret = $this->mongo_db->where(array('open_id' => $v['open_id']))->get_one($this->mongo_wx_lineup_set);
                if (!isset($list['open_id'])) {
                    $list[$v['open_id']] = array(
                        'open_id'  => $v['open_id'],
                        'avatar'   => $ret['avatar'] ? $ret['avatar'] : '',
                        'nickname' => $ret['nickname'] ? $ret['nickname'] : '',
                        'status'   => '',
                        'success'  => 0,
                        'cancle'   => 0,
                        'over'     => 0
                    );
                }
                if (is_numeric(strpos($invalid_str, $v['open_id']))) {
                    $list[$v['open_id']]['status'] = 0;
                    $list[$v['open_id']]['status_str'] = '黑名单';
                } else {
                    $list[$v['open_id']]['status'] = 1;
                    $list[$v['open_id']]['status_str'] = '正常';
                    //$data[$v['open_id']]['id'] = $v['id'];
                }

                switch ($v['status']) {
                    case 1 :
                        $list[$v['open_id']]['success'] += $v['status_count'];
                        break;
                    case 2 :
                        $list[$v['open_id']]['over'] += $v['status_count'];
                        break;
                    case 3 :
                        $list[$v['open_id']]['cancle'] += $v['status_count'];
                        break;
                }
            }
        }
        sort($list);
        $this->data['list'] = $list;
        $this->load->view('/c/lineup/lineups_count', $this->data);
    }


    //初始化排号
    public function initLineUp($wid = ''){
        $this->load->model('lineup_model');
        if(!empty($wid)){
            $ret = $this->lineup_model->where(array('wid' => $wid))->find();
            if(!$ret){
                $qrcode = $this->get_qrcode(true);
                $image = $qrcode['image'] ? $qrcode['image'] : '未获取到二维码';
                $scene_id = $qrcode['scene_id'];
                $init = $this->lineup_model->add(array('wid' => $wid,'status' => 1,'qrcode' => $image,'scene_id' => $scene_id));
                //查询$lineup_id
                $lineup_id = $this->lineup_model->select('id')->where(array('wid' => $wid))->find();
                $this->load->model('lineup_config_model');
                $cfg_msg = json_encode(array(0,1,2,3,4 ));
                $data = array(
                    'lineup_id' => $lineup_id['id'],
                    'cfg_msg'   => $cfg_msg
                );
                $this->lineup_config_model->add($data);
            }
        }
    }

    //点对点推送方法
    protected function _send_msg($content ,$member_id,$open_id) {
        if (empty($open_id)) {
            return array('status' => FALSE , 'msg' => 'openID错误');
        }

        $this->load->library('wechat', array(
            'app_id' => $this->post_data['appid'],
            'secret' => $this->post_data['appscret']));
        $this->load->model('lineup_member_model','lineup_member');
        $this->load->model('lineup_config_model','lineup_config');
        $member = $this->lineup_member->where(array('id' => $member_id))->find();

        $name = $this->lineup_config->where(array('lineup_id' => $member['lineup_id']))->find();
        //模板消息发送失败时点对点推送
        $msg = "$content"."\n\n" .
            "号码：" .$member['type'] . $member['number'] . "\n" .
            "类型：".$member['type_name']. "\n" .
            "商家：" . $name['name'] . "\n" .
            "领号时间:" . date('m-d H:i',$member['dt_add']) . "\n\n".
            "<a href=\"" . full_url('queue', $this->site_info['domain']) . "\">更多详情</a>";
        if(!empty($msg)) {
            $msg = str_replace('/', '\/', str_replace('"', '\"', $msg));
            $post = array(
                'touser' => $open_id,
                'msgtype' => 'text',
                'text' => array(
                    'content' => urlencode($msg)
                )
            );

            $post_json = urldecode(json_encode($post));

            $ret = $this->wechat->message_custom_post($post_json, $this->wx_info['token']);

        }
    }


    /**
     * 服务号  获取二维码
     */
    public function get_qrcode($type=false)
    {
        if( $this->qudaoconfig['is_qrcode_api']==0 ){//订阅号 无此权限
            echo json_encode(array(
                'error' => 1,
                'msg'   => '您的配置信息中没有开通微信高级接口'
            ));exit;

        }
        $this->load->model('lineup_model');
        $min_scene_id = $this->lineup_model->min('scene_id');

        if($min_scene_id && $min_scene_id < 50000 ){
            echo json_encode(array(
                'error' => 1,
                'msg'   => '场景ID不能超过50000'
            ));

            //$this->show_message(true,'场景ID不能超过50000');

        }

        $this->load->library('curl');
        //echo $this->db->last_query();
        $accessToken = $this->qudaoconfig['token'];
        if(!$min_scene_id){
            $new_scene_id = 99999;
        }else{
            $new_scene_id = $min_scene_id-1;
        }

        if(isset($accessToken)){
            $ticketUrl = 'https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token='.$accessToken;
            $ticketDate = array(
                'action_name' => 'QR_LIMIT_SCENE',
                'action_info' => array(
                    'scene' => array(
                        'scene_id' => $new_scene_id
                    )
                )
            );
            $tmpTicketInfo = $this->curl->post( $ticketUrl, json_encode($ticketDate) );
            $tmpTicketInfo = json_decode( $tmpTicketInfo, true );
            if(isset($tmpTicketInfo['errcode'])){
                if(isset($this->errorCodeArr[$tmpTicketInfo['errcode']])){
                    echo json_encode(array(
                        'error' => 1,
                        'msg'   => $this->errorCodeArr[$tmpTicketInfo['errcode']]
                    ));exit;
                }else{
                    echo 'token获取失败,您的帐号可能没有高级接口权限';
                    exit;
                }
            }else{
                $ticket = $tmpTicketInfo['ticket'];
            }
            if( isset($ticket) ){

                if( $type==true ){
                    return array('image'=>'https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket='.urlencode($ticket),'scene_id'=>$new_scene_id);
                }else{
                    echo json_encode(array(
                        'error' => 0,
                        'image' => 'https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket='.$ticket,
                        'scene_id' => $new_scene_id
                    ));exit;

                }

            }else{
                echo json_encode(array(
                    'error' => 1,
                    'msg' => 'ticket获取失败'
                ));exit;
            }
        }else{
            echo json_encode(array(
                'error' => 1,
                'msg' => 'token获取失败'
            ));exit;
        }
    }

    //此方法暂时保留
    public function Led(){
        $this->load->model('lineup_config_model');
        $this->load->model('lineup_model');
        $this->load->model('user_model');
        $this->load->model('lineup_member_model');
        $wid = $this->lineup_model->select('wid,qrcode')->where(array('id' => $this->status_info['id']))->find();
        $name = $this->lineup_config_model->select('name')->where(array('lineup_id' =>$this->status_info['id']))->find();
        $this->data['name'] = $name['name'];
        $this->data['qrcode'] = $wid['qrcode'];
        $this->load->view('/c/lineup/led',$this->data);

    }

    public function refreshLed(){
        $this->load->model('lineup_config_model');
        $this->load->model('lineup_model');
        $this->load->model('user_model');
        $this->load->model('lineup_member_model');
        $setting = $this->lineup_config_model->select('*')->where(array('lineup_id' => $this->status_info['id']))->find();
        $types = json_decode($setting['cfg_type'],true);
        $list = array();
        foreach ($types as $key => $val) {
            $list[$key] = array();
            $list[$key]['type'] = $val['type'];
            $list[$key]['type_name'] = $val['type_name'];
            $list[$key]['count'] = $this->lineup_member_model->where(array('lineup_id' =>$this->status_info['id'], 'type' => $list[$key]['type'], 'status' => 0, 'reset' => 0))->count();
            // echo $this->db->last_query();
            // exit;
            //当前排到几号
            $res = $this->lineup_member_model->where(array('lineup_id' => $this->status_info['id'], 'type' => $list[$key]['type'], 'status' => 0, 'reset' => 0))
                ->order_by('number', 'asc')->find();
            if( $res['number']){
                $tmp_res = $this->lineup_member_model->limit(1,0)->where(array('lineup_id' => $this->status_info['id'], 'type' => $list[$key]['type'], 'status' => 0, 'reset' => 0,'number <' => $res['number']))->order_by('number', 'desc')->find_all();
            }
            $list[$key]['id'] = isset($res['id']) ? $res['id'] : 0;
            $list[$key]['current'] = isset($res['number']) ? $res['number'] : 0;
            $list[$key]['before'] = isset($tmp_res['number']) ? $tmp_res['number'] : 0;
        }

        $wid = $this->lineup_model->select('wid,qrcode')->where(array('id' => $this->status_info['id']))->find();
        $name = $this->lineup_config_model->select('name')->where(array('lineup_id' =>$this->status_info['id']))->find();
        $condition = array(
            'lineup_id' => $this->status_info['id']
        );
        $cfg_type = $this->lineup_config_model->select('cfg_type')->where($condition)->find();
        if($cfg_type){
            $this->data['cfg_type'] = json_decode($cfg_type['cfg_type'],true);
        }
        $this->data['list'] = $list;
        $this->data['name'] = $name['name'];
        $this->data['qrcode'] = $wid['qrcode'];
        $this->ajax_return($this->data);

    }


    public function setQrcode(){
        /*$site_id = $this->input->get('id');
        $temp = $this->mongo_db->where(array('site_id'=>$site_id))->get_one(MONGO_WX_SET);
        $response = $this->wbcurl->simple_post($this->_token_wx_server . 'info',array('app_id' => $temp['appid']) );
        $temp_wx_info = json_decode($response,true);
        $accessToken = $temp_wx_info['token'];
        $this->load->library('curl');
        $appid = $this->post_data['appid'];
        $appscret = $this->post_data['appscret'];
        $ticketUrl = 'https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token='.$accessToken;
        $ticketDate = array(
            'action_name' => 'QR_LIMIT_SCENE',
            'action_info' => array(
                'scene' => array(
                    'scene_id' => 99996
                )
            )
        );

        $tmpTicketInfo = $this->curl->post( $ticketUrl, json_encode($ticketDate) );
        $tmpTicketInfo = json_decode( $tmpTicketInfo, true );
        $ticket = $tmpTicketInfo['ticket'];
        //return array('image'=>'https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket='.urlencode($ticket),'scene_id'=>$new_scene_id);
        echo 'https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket='.urlencode($ticket);*/
       /* $this->load->model('lineup_model');
        $scene_id = $this->lineup_model->min('scene_id');
        echo $this->db->last_query();
        exit;
        if($scene_id){
            $newscene_id = $scene_id-1;
        }
        echo $newscene_id;*/

    }




}