<?php
class Bawangcan extends C_Controller{
	
	protected $auto_load_model = TRUE;
	protected $model_name = 'bawangcan_activitys';
	
	private $_tops = array(
		10	=> 10,
		20	=> 20,
		30	=> 30,
		40	=> 40,
		50	=> 50,
		60	=> 60,
		70	=> 70,
		80	=> 80,
		90	=> 90,
		100	=> 100,
	);

	public function index(){
		$this->load->library('Mongo_db');
		$userdata = $this->mongo_db->where(array('site_id'=>$this->site_info['id']))->get_one(MONGO_WX_SET);
		
		$activitys = $this->model->where(array('site'=>$this->site_info['id'], 'status'=>1))->order_by('id desc')->find_all();
		
		$this->data['userdata'] = $userdata;
		$this->data['pre_url'] = $this->site_info['all_domain'] ? $this->site_info['all_domain'] : 'http://'.$this->site_info['domain'].BASE_DOMAIN;
		$this->data['activitys'] = $activitys;
		$this->load->view($this->dcm, $this->data);
	}
	
	public function add(){
		$post = $this->input->post();
		
		if(false === empty($post)){
			#$this->show_message(true, '该应用已下架！', '/c/bawangcan/index');
			#return false;
			
			$data = array(
				'site'			=> $this->site_info['id'],
				'title'			=> $post['title'],
				'startd'		=> strtotime($post['startd']),
				'endd'			=> strtotime($post['endd']),
				'banner'		=> $post['banner'],
				'reply_img'		=> $post['reply_img'],
				'rule'			=> $post['rule'],
				'base'			=> $post['base'],
				'top'			=> $post['top'],
				'wx_keyword'	=> $post['wx_keyword'],
				'share_logo'	=> $post['share_logo'],
				'share_title'	=> $post['share_title'],
				'share_desc'	=> $post['share_desc'],
				'created'		=> time()
			);
			
			if(false === $this->_verify($data)){
				return false;
			}
			
			if($this->model->add($data)){
				$this->show_message(true, '活动添加成功！', '/c/bawangcan/index');
				return false;
			}else{
				$this->show_message(false, '活动添加失败！', '/c/bawangcan/index');
				return false;
			}
		}
		
		$this->data['tops'] = $this->_tops;
		$this->load->view($this->dcm, $this->data);
	}
	
	public function edit(){
		$id = $this->input->get('id');
		if(true === empty($id)){
			$this->show_message(false, '无效的活动！', '/c/bawangcan/index');
			return false;
		}
		
		$activity = $this->model->where(array('id'=>$id))->find();
		if(true === empty($activity)){
			$this->show_message(false, '无效的活动！', '/c/bawangcan/index');
			return false;
		}
		
		$post = $this->input->post();
		
		if(false === empty($post)){
			#$this->show_message(true, '该应用已下架！', '/c/bawangcan/index');
			#return false;
			
			$data = array(
				'id'			=> $id,
				'title'			=> $post['title'],
				'startd'		=> strtotime($post['startd']),
				'endd'			=> strtotime($post['endd']),
				'banner'		=> $post['banner'],
				'reply_img'		=> $post['reply_img'],
				'rule'			=> $post['rule'],
				'base'			=> $post['base'],
				'top'			=> $post['top'],
				'wx_keyword'	=> $post['wx_keyword'],
				'share_logo'	=> $post['share_logo'],
				'share_title'	=> $post['share_title'],
				'share_desc'	=> $post['share_desc'],
				'modified'		=> time()
			);
			
			if(false === $this->_verify($data, true)){
				return false;
			}
			
			if(true === empty($data['banner'])){
				unset($data['banner']);
			}
			
			if(true === empty($data['share_logo'])){
				unset($data['share_logo']);
			}
			
			if($this->model->where(array('id'=>$id))->edit($data)){
				$this->show_message(true, '活动编辑成功！', '/c/bawangcan/index');
				return false;
			}else{
				$this->show_message(false, '活动编辑失败！', '/c/bawangcan/index');
				return false;
			}
		}
		
		$this->data['activity'] = $activity;
		$this->data['tops'] = $this->_tops;
		$this->load->view($this->dcm, $this->data);
	}
	
	public function delete(){
		#$this->show_message(true, '该应用已下架！', '/c/bawangcan/index');
		#return false;
		
		$id = $this->uri->segment(4);
		if(true === empty($id)){
			$this->show_message(false, '无效的活动！', '/c/bawangcan/index');
			return false;
		}
		
		$activity = $this->model->where(array('id'=>$id))->find();
		if(true === empty($activity)){
			$this->show_message(false, '无效的活动！', '/c/bawangcan/index');
			return false;
		}
		
		if($this->model->where(array('id'=>$id))->edit(array('status'=>0))){
			$this->show_message(true, '活动删除成功！', '/c/bawangcan/index');
			return false;
		}else{
			$this->show_message(false, '活动删除失败！', '/c/bawangcan/index');
			return false;
		}
	}
	
	public function tongji(){
		$id = $this->input->get('id');
		if(true === empty($id)){
			$this->show_message(false, '无效的活动！', '/c/bawangcan/index');
			return false;
		}
		
		$name = $this->input->get('name');
		$mobile = $this->input->get('mobile');
		
		$where = array('activity'=>$id);
		$like = array();
		
		if(false === empty($name) || false === empty($mobile)){
			false === empty($name) && $like['name'] = $name;
			false === empty($mobile) && $like['mobile'] = $mobile;
		}else{
			$where['name !='] = '';
			$where['mobile !='] = '';
		}
		
		$base_url = '/c/bawangcan/tongji?id='.$id;
		false === empty($name) && $base_url .= $base_url.'&name='.$name;
		false === empty($mobile) && $base_url .= $base_url.'&mobile='.$mobile;
		
		$this->load->model('bawangcan_users_model');
		

        $total_rows = $this->bawangcan_users_model->where($where)->like($like)->count();

        $pager = $this->_pager($total_rows, array('per_page'=>20,'base_url'=>$base_url));
		
		$shares = $this->bawangcan_users_model->where($where)->like($like)->order_by('share desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->find_all();
		
		$perv = 0;
		$j = 1;
		$i = $pager['limit']['offset'];
		foreach($shares AS $index=>$val){
			if($perv != $val['share']){
				$i = $i+$j;
				$j = 1;
			}else{
				$j++;
			}

			$shares[$index]['rank'] = $i;
			$perv = $val['share'];

			//$shares[$index]['mobile'] = substr_replace($val['mobile'], '****', 3, 4);
		}
		
		$this->data['site'] = $this->site_info['id'];
		$this->data['id'] = $id;
		$this->data['name'] = $name;
		$this->data['mobile'] = $mobile;
		$this->data['shares'] = $shares;
		$this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
		$this->load->view($this->dcm, $this->data);
	}
	
	public function all(){	
		$title = $this->input->get('title');
		
		$like = array();
		false === empty($title) && $like['wb_bawangcan_activitys.title'] = $title;

		
		$base_url = '/c/bawangcan/all';
		$base_url .= $base_url.'?title='.$title;
		

        $total_rows = $this->model->like($like)->count();

        $pager = $this->_pager($total_rows, array('per_page'=>20,'base_url'=>$base_url));
		
		$activitys = $this->model->select('user.domain, user.all_domain, wb_bawangcan_activitys.*')->join('user', 'wb_bawangcan_activitys.site = user.id', 'left')
				->like($like)->order_by('wb_bawangcan_activitys.id desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->find_all();
		
		$this->data['title'] = $title;
		$this->data['activitys'] = $activitys;
		$this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
		$this->load->view($this->dcm, $this->data);
	}
	
	public function export(){
		$id = $this->input->get('id');
		if(true === empty($id)){
			$this->show_message(false, '无效的活动！', '/c/bawangcan/index');
			return false;
		}
		
		$where = array('activity'=>$id, 'name !='=>'', 'mobile !='=>'');
		
		$this->load->model('bawangcan_users_model');
		$shares = $this->bawangcan_users_model->select('name, mobile, share')->where($where)->order_by('share desc')->find_all();
		
		$perv = 0;
		$j = 1;
		$i = 0;
		foreach($shares AS $index=>$val){
			if($perv != $val['share']){
				$i = $i+$j;
				$j = 1;
			}else{
				$j++;
			}
			
			$shares[$index]['mobile'] = $val['mobile']." ";
			array_unshift($shares[$index], $i);
			$perv = $val['share'];
		}
		
		$field = array('rank'=>'排名', 'name'=>'姓名', 'mobile'=>'手机号码', 'share'=>'助力数');
		
		$this->excel_flush_export($field, $shares, 'wzl');
	}
	
	public function edit_share(){
		$id = $this->input->get('id');
		if(true === empty($id)){
			$this->show_message(false, '无效的会员信息！', '/c/bawangcan/index');
			return false;
		}
		
		$this->load->model('bawangcan_users_model');
		$user = $this->bawangcan_users_model->where(array('id'=>$id))->find();
		
		$post = $this->input->post();
		if(false === empty($post)){
			$share = $user['share'] - $user['virtual'];
			
			$data = array('virtual'=>$post['virtual'], 'share'=>$share+$post['virtual']);
			
			if($this->bawangcan_users_model->where(array('id'=>$id))->edit($data)){
				$this->show_message(true, '助力数编辑成功！', '/c/bawangcan/tongji?id='.$user['activity']);
				return false;
			}else{
				$this->show_message(false, '助力数编辑失败！', '/c/bawangcan/tongji?id='.$user['activity']);
				return false;
			}
		}
		
		$this->data['user'] = $user;
		$this->load->view($this->dcm, $this->data);
	}
	
	public function edit_suspend(){
		$id = $this->input->get('id');
		$suspend = $this->input->get('suspend');
		if(true === empty($id)){
			$this->show_message(false, '无效的会员信息！', '/c/bawangcan/index');
			return false;
		}
		
		$this->load->model('bawangcan_users_model');
		$user = $this->bawangcan_users_model->where(array('id'=>$id))->find();
		if($this->bawangcan_users_model->where(array('id'=>$id))->edit(array('suspend'=>$suspend, 'modified'=>time()))){
			$this->show_message(true, '暂停或开启操作成功！', '/c/bawangcan/tongji?id='.$user['activity']);
			return false;
		}else{
			$this->show_message(false, '暂停或开启操作失败！', '/c/bawangcan/tongji?id='.$user['activity']);
			return false;
		}
	}
	
	public function _verify($data=array(), $edit=false){
		$error = '';
		
		if(stristr($data['title'], '朋友圈') || stristr($data['rule'], '朋友圈') || stristr($data['share_title'], '朋友圈') || stristr($data['share_desc'], '朋友圈')){
			$this->show_message(false, '文案中不能出现“朋友圈”字眼，否则会被微信官方封杀！', '/c/bawangcan/index');
			return false;
		}
		
		if(true === empty($data['title'])){
			$error .= "<p>活动标题不能为空！</p>";
		}
		
		if(true === empty($data['startd'])){
			$error .= "<p>开始时间不能为空！</p>";
		}
		
		if(true === empty($data['endd'])){
			$error .= "<p>结束时间不能为空！</p>";
		}
		
		if(true === empty($data['rule'])){
			$error .= "<p>活动规则不能为空！</p>";
		}
		
		/*if(true === empty($data['banner']) && false === $edit){
			$error .= "<p>活动banner图不能为空！</p>";
		}
		
		if(true === empty($data['share_logo']) && false === $edit){
			$error .= "<p>活动分享logo不能为空！</p>";
		}*/
		
		if(true === empty($data['wx_keyword'])){
			$error .= "<p>微信关键字不能为空！</p>";
		}else{
			$where = array(
				'site'		=> $this->site_info['id'],
				'wx_keyword'=> $data['wx_keyword'],
				'status'	=> 1
			);
			
			if(true === $edit){
				$where['id != '] = $data['id'];
			}
			
			$activity = $this->model->where($where)->find();
			if(false === empty($activity)){
				$error .= "<p>微信关键字不能重复！</p>";
			}
		}
		
		if(true === empty($data['share_title'])){
			$error .= "<p>活动分享标题不能为空！</p>";
		}
		
		if(true === empty($data['share_desc'])){
			$error .= "<p>活动分享内容不能为空！</p>";
		}
		
		
		
		if(false === empty($error)){
			$this->show_message(false, $error, '/c/bawangcan/index');
			return false;
		}else{
			return true;
		}
	}
}
?>