<?php
/**
 * Created by PhpStorm.
 * User: along
 * Date: 13-12-2
 * Time: 下午2:21
 * @property Live_model $model
 * @property Comments_reply_model $comments_reply_model
 * @property Comments_reply_post_model $comments_reply_post_model
 */

class Comments extends C_Controller{

	protected $auto_load_model = TRUE;
	protected $model_name = 'comments';

	public function index()
	{
		$where = array('status'=>1,'wid'=>$this->site_info['id']);
		//$like = array();
		$total_rows = $this->model->where($where)->count();
		$pager = $this->_pager($total_rows, array('per_page'=>5));

		$list = $this->model->order_by('id desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->where($where)->find_all();
		$this->data['list'] = $list;
		$this->data['page'] = $pager['links'];
		$this->data['offset'] = $pager['limit']['offset'];
        $this->data['prew_url'] = $this->site_info['all_domain'] ? $this->site_info['all_domain'] : 'http://'.$this->site_info['domain'].BASE_DOMAIN;
		$this->load->view($this->dcm, $this->data);
	}


	public function add()
	{
        $post = $this->input->post();

        if($post)
        {
            $postData = $this->dataPost($post);
            if(!is_array($postData))
            {
                $this->show_message(false,$postData,'/c/comments/');
                return false;
            }
            $userInfo = $this->site_info;
            $postData['wid'] = $userInfo['id'];
            $postData['inputtime'] = time();

            if( !$id=$this->model->add($postData) )
            {
                $this->show_message(false, '添加失败', '');
                return FALSE;
            }
            else
            {
                $this->show_message(true, '添加成功', '/c/comments');
                return FALSE;
            }
        }
        else
        {
            $this->load->view($this->dcm,$this->data);
        }
	}

	public function edit($id)
	{
        $comments = $this->getOneComments($id);
        //print_r($comments);exit;
        if(!is_array($comments))
        {
            $this->show_message(false,$comments,'/c/comments/edit/'.$id);return false;
        }
        $post = $this->input->post();
        if ($post)
        {

            $postData = $this->dataPost($post);
            if(!is_array($postData))
            {
                $this->show_message(false,$postData,'/c/comments/edit/'.$id);
                return false;
            }

            if(false === $this->model->where(array('id'=>$id, 'wid'=>$comments['wid']))->edit( $postData ) )
            {
                $this->show_message(false, '编辑留言失败', '/c/comments/edit/'.$id);
            }
            else
            {
                $this->show_message(false, '编辑留言成功', '/c/comments/edit/'.$id);
            }

        }
        else
        {
            $this->data['comments'] = $comments;
            $this->load->view($this->dcm,$this->data);
        }

	}

    /**
     * 删除留言板
     * @param $id
     * @return bool
     */
    public function delcomments($id)
	{
        $comments = $this->getOneComments($id);
        if(!is_array($comments))
        {
            $this->show_message(false,$comments,'/c/comments/');return false;
        }
        $this->model->where(array('id'=>$id))->edit(array('status'=>-1));
        $this->show_message(false,'删除成功！','/c/comments/');return false;
	}

    /**
     * 回复列表
     * @return bool
     */
    public function replylist()
	{
        $cid = $this->input->get('cid');
        $comments = $this->getOneComments($cid);
        if(!is_array($comments))
        {
            $this->show_message(false,$comments,'/c/comments/');return false;
        }
        $this->data['comments'] = $comments;
        $search_url = '/c/comments/replylist/?cid='.$cid;

        /*
        $where = array(
            'site_id' => $this->site_info['id'],
            'cid' => $cid,
        );
        */

        $where = "site_id='".$this->site_info['id']."' AND cid='".$cid."'";

        $like = $search = $orlike = array();

        $search['keyword'] = $this->input->get('keyword');
        $search['from_time'] = $this->input->get('from_time');
        $search['end_time'] = $this->input->get('end_time');
        $search['prov'] = $this->input->get('prov');
        $search['city'] = $this->input->get('city');
        $search['is_reply'] = $this->input->get('is_reply');

        $this->data['search'] = $search;

        //print_r($search);
        if( $search ){
            foreach( $search as $key=>$val ){
                if( $val ){
                    $search_url .= '&'.$key.'='.$val;
                    switch ($key){
                        case 'keyword':
                            //$orlike = array('content'=>$search['keyword'],'nick'=>$search['keyword']);
                            $where .= " AND (content LIKE '%".$search['keyword']."%' OR nick LIKE '%".$search['keyword']."%')";
                            break;
                        case 'from_time':
                            //$where['add_time >='] = strtotime($search['from_time']);
                            $where .= " AND add_time >= ".strtotime($search['from_time']);
                            break;
                        case 'end_time':
                            //$where['add_time <='] = strtotime($search['end_time']);
                            $where .= " AND add_time <= ".strtotime($search['end_time']);
                            break;
                        case 'prov':
                            $like['province'] = $search['prov'];
                            $where .= " AND province LIKE '%".$search['prov']."%'";
                            break;
                        case 'city':
                            $like['city'] = $search['city'];
                            $where .= " AND city LIKE '%".$search['city']."%'";
                            break;
                        default: break;
                    }
                }
            }
        }

        if(isset($search['is_reply']))
        {
            //$where['is_reply'] = $search['is_reply'];
            $where .= " AND is_reply = ".$search['is_reply'];
            if($search['is_reply']==0)
            {
                $search_url .= '&is_reply='.$search['is_reply'];
            }
        }

        $this->load->model('comments_reply_model');

        $total_rows = $this->comments_reply_model->where($where)->count();

        $pager = $this->_pager($total_rows, array('per_page'=>20,'base_url'=>$search_url));

        $replylist = $this->comments_reply_model->where($where)->order_by('is_top desc,id desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->find_all();
        //echo $this->db->last_query();
        /*
        if($replylist)
        {
            $this->load->library('iplocation');
            foreach($replylist as &$list)
            {
                $ip_info = $this->iplocation->getlocation('211.140.18.0');
                if($ip_info['country'])
                {
                    $addressInfo = explode('省',$ip_info['country']);

                    $list['province'] = $addressInfo[0];
                    $list['city'] = $addressInfo[1];
                }
                else
                {
                    $list['province'] = $list['city'] = '未知';
                }
            }
        }
        */
        $this->data['replylist'] = $replylist;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->load->view($this->dcm,$this->data);
	}

    /**
     * 回复置顶
     * @param $id
     */
    public function replytop($id)
    {
        $this->load->model('comments_reply_model');

        $where = array(
            'site_id' => $this->site_info['id'],
            'id' => $id,
        );
        $replyInfo = $this->comments_reply_model->where($where)->find();

        $edit = array();

        if($replyInfo && $replyInfo['is_top']==1)
        {
            $edit['is_top'] = 0;
            $msg = '取消置顶成功';
        }
        else
        {
            $edit['is_top'] = 1;
            $msg = '置顶成功';
        }
        $this->comments_reply_model->where($where)->edit($edit);
        $this->show_message(false,$msg,'/c/comments/replylist/?cid='.$replyInfo['cid']);return;
    }

    /**
     * 批量显示
     */
    public function replydisplay()
    {
        $mards = $this->input->get_post('mards');
        if($mards)
        {
            $type = $this->input->get_post('type');
            $this->load->model('comments_reply_model');
            foreach($mards as $id)
            {
                $where = array(
                    'site_id' => $this->site_info['id'],
                    'id' => $id,
                );
                if($type == 'display')
                {
                    $this->comments_reply_model->where($where)->edit(array('status'=>1));
                }
                else
                {
                    $this->comments_reply_model->where($where)->edit(array('status'=>0));
                }
            }
        }
        $data['sucuss'] = 1;
        exit($this->ajax_return($data));
    }

	/**
	 * @name 批量删除
	 */
	public function replydel()
	{
        $mards = $this->input->get_post('mards');
        if($mards)
        {
            $this->load->model('comments_reply_model');
            $this->load->model('comments_reply_post_model');
            if(is_array($mards))
            {
                foreach($mards as $id)
                {
                    $where = array(
                        'site_id' => $this->site_info['id'],
                        'id' => $id,
                    );
                    $this->comments_reply_model->where($where)->delete();
                    $this->comments_reply_post_model->where(array('site_id'=>$this->site_info['id'],'rid'=>$id))->delete();
                }
            }
            else
            {
                $where = array(
                    'site_id' => $this->site_info['id'],
                    'id' => $mards,
                );
                $this->comments_reply_model->where($where)->delete();
                $this->comments_reply_post_model->where(array('site_id'=>$this->site_info['id'],'rid'=>$mards))->delete();
            }
        }
        $data['sucuss'] = 1;
        exit($this->ajax_return($data));
	}

    /**
     * 回复评论列表
     * @return bool
     */
    public function replyview()
    {
        $cid = $this->input->get('cid');
        $comments = $this->getOneComments($cid);
        if(!is_array($comments))
        {
            $this->show_message(false,$comments,'/c/comments/replylist/?cid='.$cid);return false;
        }
        $rid = $this->input->get('rid');

        $this->load->model('comments_reply_model');
        $replyInfo = $this->comments_reply_model->where(array('site_id'=>$this->site_info['id'],'id'=>$rid))->find();
        if(!$replyInfo)
        {
            $this->show_message(false,'评论不存在','/c/comments/replylist/?cid='.$cid);return false;
        }

        //print_r($replyInfo);exit;
        $this->data['comments'] = $comments;
        $this->data['reply'] = $replyInfo;

        $this->load->model('comments_reply_post_model');
        $where = array(
            'site_id' => $this->site_info['id'],
            'cid' => $cid,
            'rid' => $rid
        );
        $like = array();
        $search_url = 'c/comments/replyview/?rid='.$rid.'&cid='.$cid;
        $total_rows = $this->comments_reply_post_model->where($where)->like($like)->count();

        $pager = $this->_pager($total_rows,array('per_page'=>5,'base_url'=>$search_url));
        $postlist = $this->comments_reply_post_model->order_by('is_admin desc,id desc')->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->where($where)->like($like)->find_all();

        $this->data['postlist'] = $postlist;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->load->view($this->dcm,$this->data);

    }

    /**
     * 官方回复
     */
    public function replyPost()
    {
        $data['sucuss'] = 0;

        $cid = $this->input->post('cid');
        $comments = $this->getOneComments($cid);
        if(!is_array($comments))
        {
            $data['msg'] = $comments;
        }
        else
        {
            $rid = $this->input->post('rid');
            $this->load->model('comments_reply_model');
            $replyInfo = $this->comments_reply_model->where(array('site_id'=>$this->site_info['id'],'id'=>$rid))->find();
            if(!$replyInfo)
            {
                $data['msg'] = '回复不存在！';
            }
            else
            {
                $nick = $this->input->post('nick');
                $content = $this->input->post('content');
                if(!$nick || !$content)
                {
                    $data['msg'] = '请完整填写内容！';
                }
                else
                {
                    $this->load->model('comments_reply_post_model');
                    $ip = $this->get_client_ip();

                    $addData = array(
                        'site_id' => $this->site_info['id'],
                        'cid' => $cid,
                        'rid' => $rid,
                        'nick' => $nick,
                        'content' => $content,
                        'status' => 1,
                        'is_admin'=> 1,
                        'add_time'=>time()
                    );

                    if($ip == '0.0.0.0' || $ip == '127.0.0.1')
                    {

                    }
                    else
                    {
                        $url="http://ip.taobao.com/service/getIpInfo.php?ip=".$ip;
                        $ipInfo=json_decode(file_get_contents($url),true);
                        if(isset($ipInfo['code']) && $ipInfo['code'] != 1)
                        {
                            $addData['province'] = (isset($ipInfo['data']['region']) && $ipInfo['data']['region']) ? str_replace('省','',$ipInfo['data']['region']) : '';
                            $addData['city'] = (isset($ipInfo['data']['city']) && $ipInfo['data']['city']) ? $ipInfo['data']['city'] : '';
                        }
                        $addData['ip'] = $ip;
                    }
                    if(!$this->comments_reply_post_model->add($addData))
                    {
                        $data['msg'] = '回复失败！';
                    }
                    else
                    {
                        //设置回复状态
                        if($replyInfo['is_reply'] == 0)
                        {
							$editdata['is_reply'] = 1;
							if($replyInfo['status'] == 0)
							{
								$editdata['status'] = 1;
							}
                            $this->comments_reply_model->where(array('site_id'=>$this->site_info['id'],'id'=>$rid))->edit($editdata);
                        }
                        $data['sucuss'] = 1;
                    }
                }
            }
        }
        exit($this->ajax_return($data));
    }

    /**
     * 批量显示
     */
    public function postDisplay()
    {
        $mards = $this->input->get_post('mards');
        if($mards)
        {
            $type = $this->input->get_post('type');
            $this->load->model('comments_reply_post_model');
            foreach($mards as $id)
            {
                $where = array(
                    'site_id' => $this->site_info['id'],
                    'id' => $id,
                );
                if($type == 'display')
                {
                    $this->comments_reply_post_model->where($where)->edit(array('status'=>1));
                }
                else
                {
                    $this->comments_reply_post_model->where($where)->edit(array('status'=>0));
                }
            }
        }
        $data['sucuss'] = 1;
        exit($this->ajax_return($data));
    }

    /**
     * 批量删除回复
     */
    public function replyPostDel()
    {
        $data['sucuss'] = 0;
        $rid = $this->input->post('rid');
        $this->load->model('comments_reply_model');
        $replyInfo = $this->comments_reply_model->where(array('site_id'=>$this->site_info['id'],'id'=>$rid))->find();
        if(!$replyInfo)
        {
            $data['msg'] = '回复不存在！';
        }
        else
        {
            $ids = $this->input->post('ids');
            $this->load->model('comments_reply_post_model');
            foreach($ids as $id)
            {
                $where = array(
                    'site_id' => $this->site_info['id'],
                    'rid' => $replyInfo['id'],
                    'id' => $id,
                );
                $this->comments_reply_post_model->where($where)->delete();
            }
            $data['sucuss'] = 1;
        }
        exit($this->ajax_return($data));
    }

	//检查图片格式
	public function _check_image($image) {
		if ($image) {
			if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
				$this->form_validation->set_message('_check_image', '图片地址格式错误');
				return FALSE;
			}
		}
		return TRUE;
	}

    /**
     * 处理留言post请求
     */
    private function dataPost($post)
    {
        if(is_array($post))
        {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('title', '留言标题', 'trim|required|max_length[200]|htmlspecialchars');
            $this->form_validation->set_rules('coverpic', '顶部图片', 'trim|callback__check_image');
            $this->form_validation->set_rules('nick', '官方昵称', 'trim|required|max_length[10]|htmlspecialchars');
            $this->form_validation->set_rules('guidetitle', '留言引导语', 'trim|max_length[10]|htmlspecialchars');

            if ( $this->form_validation->run() )
            {
                $dataSet['title'] = $this->form_validation->set_value('title');
                //顶部图片
                $dataSet['coverpic'] = $this->form_validation->set_value('coverpic');
                //nick
                $dataSet['nick'] = $this->form_validation->set_value('nick');
                $dataSet['guidetitle'] = $this->form_validation->set_value('guidetitle');
                $dataSet['replacebadword'] = $this->input->post('replacebadword');
                //发布权限
                $pub_auth = $this->input->post('pub_auth');
                /*
                $tmp_auth = 0;
                if($pub_auth)
                {
                    foreach($pub_auth as $v)
                    {
                        $tmp_auth |= $v;
                    }
                }
                $dataSet['pub_auth'] = $tmp_auth;
                */
                $dataSet['pub_auth'] = $pub_auth;

                //回复设置
                $reply_set =  $this->input->post('reply_set');
                $tmp_auth = 0;
                if($reply_set)
                {
                    foreach($reply_set as $v)
                    {
                        $tmp_auth |= $v;
                    }
                }
                $dataSet['reply_set'] = $tmp_auth;
                $dataSet['display'] = $this->input->post('display');
                //模板
                $dataSet['tpl'] = $this->input->post('tpl');
                //是否开启
                $dataSet['open'] = $this->input->post('open');

                return $dataSet;
            }
            else
            {
                $errors = validation_errors();

                if ($errors) {
                   return $errors;
                }
            }
        }
    }

    /**
     * 获取一个留言是否存在
     * @param $id
     * @return string
     */
    private function getOneComments($id)
    {
        if(!$id)
        {
            return '非法参数';
        }
        $userInfo = $this->site_info;

        $comments = $this->model->where(array('id'=>$id,'wid'=>$userInfo['id'],'status'=>1))->find();
        if(!$comments)
        {
            return '该留言不存在';
        }
        else
        {
            return $comments;
        }
    }

    /**
     * 获取客户端IP地址
     * @return null|string
     */
    function get_client_ip() {
        $ip = NULL;
        if ($ip !== NULL) return $ip;
        if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $arr = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            $pos =  array_search('unknown',$arr);
            if(false !== $pos) unset($arr[$pos]);
            $ip   =  trim($arr[0]);
        }elseif (isset($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }elseif (isset($_SERVER['REMOTE_ADDR'])) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        // IP地址合法验证
        $ip = $ip ? $ip : '0.0.0.0';
        return $ip;
    }

} 