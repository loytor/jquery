<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Created by PhpStorm.
 * User: andery
 * Date: 13-12-4
 * Time: 上午11:41
 * @property User_model $user_model
 * @property Address_model $address_model
 * @property Money_record_model $money_record_model
 * @property Credit_record_model $credit_record_model
 */

class Member extends C_Controller {

    protected $auto_load_model = TRUE;
    protected $model_name = 'account';
    protected $mongo_money = 'money';
    protected $mongo_credit = 'credit';

    public function index()
    {   
        $like = $search = array();
        $search['sear_name'] = trim($this->input->get('sear_name'));
        $search['sear_mobile'] = trim($this->input->get('sear_mobile'));
        $search['sear_money_s'] = $this->input->get('sear_money_s');
        $search['sear_money_e'] = $this->input->get('sear_money_e');
        $search['sear_credit_s'] = $this->input->get('sear_credit_s');
        $search['sear_credit_e'] = $this->input->get('sear_credit_e');

        $this->data['search'] = $search;
        $search_url = site_url($this->uri->uri_string().'?');
        if( $search ){
            foreach( $search as $key=>$val ){
                if( $val ){
                    $search_url .= '&'.$key.'='.$val;
                    switch ($key){
                        case 'sear_name':
                            if($search['sear_name'] == '有')
                            {
                                $where['name !='] = '';
                            }elseif($search['sear_name'] == '无'){
                                $where['name'] = '';
                            }else{
                                $like['name'] = $search['sear_name'];
                            }
                            break;
                        case 'sear_mobile':
                            if($search['sear_mobile'] == '有')
                            {
                                $where['mobile !='] = '';
                            }elseif($search['sear_mobile'] == '无'){
                                $where['mobile'] = '';
                            }else{
                                $like['mobile'] = $search['sear_mobile'];
                            }
                            break;
                        case 'sear_money_s':
                            $where['money >='] = $search['sear_money_s'];
                            break;
                        case 'sear_money_e':
                            $where['money <='] = $search['sear_money_e'];
                            break;
                        case 'sear_credit_s':
                            $where['credit >='] = $search['sear_credit_s'];
                            break;
                        case 'sear_credit_e':
                            $where['credit <='] = $search['sear_credit_e'];
                            break;
                        default: break;
                    }
                }
            }
        }
        
        $where['wid'] = $this->site_info['id'];
        
        
        $total_rows = $this->model->where($where)->like($like)->count();
        
        $pager = $this->_pager($total_rows,array('per_page'=>10,'base_url'=>$search_url));
        $list = $this->model->order_by('id desc')->limit($pager['limit']['value'], $pager['limit']['offset'])
                ->where($where)->like($like)->find_all();

        $batchpagesize = 1000;
        $batchpage = ceil($total_rows/$batchpagesize);
        $bp = array();
        for($i=1;$i<=$batchpage;$i++)
        {
            $end = $i*$batchpagesize > $total_rows ? $total_rows : $i*$batchpagesize;
            $bp[$i-1]['k'] = ($i-1)*$batchpagesize+1 .'-'.$end;
            $bp[$i-1]['v'] = $i;
        }

        $this->data['batchpage'] = $bp;
        $batchpagesize = 100;
        $batchpage = ceil($total_rows/$batchpagesize);
        $bp = array();
        for($i=1;$i<=$batchpage;$i++)
        {
            $end = $i*$batchpagesize > $total_rows ? $total_rows : $i*$batchpagesize;
            $bp[$i-1]['k'] = ($i-1)*$batchpagesize+1 .'-'.$end;
            $bp[$i-1]['v'] = $i;
        }

        $this->data['batchpage'] = $bp;
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        
        
        $this->load->view($this->dcm, $this->data);
    }

    /**
     * 设置交易密码
     */
    public function set_pwd()
    {
        $this->load->model('user_model');
        $user = $this->user_model->where(array('id'=>$this->site_info['id']))->find();
        if(!$user) {
            $this->show_message(FALSE, '商家不存在', '/c/member/set_pwd');
            return FALSE;
        }

        $this->data['pwd'] = $pwd = $user['trading_pwd'];
        if($pwd) { //重置交易密码
            $this->form_validation->set_rules('cur_pass', '当前密码', 'trim|required|is_natural|min_length[4]|max_length[8]|callback_check_curpass');
            $this->form_validation->set_rules('password', '新密码', 'trim|required|is_natural|min_length[4]|max_length[8]');
            $this->form_validation->set_rules('conf_pass', '确认新密码', 'trim|required|is_natural|min_length[4]|max_length[8]|matches[password]');
        } else { //新设置交易密阿玛
            $this->form_validation->set_rules('password', '密码', 'trim|required|is_natural|min_length[4]|max_length[8]');
            $this->form_validation->set_rules('conf_pass', '确认新密码', 'trim|required|is_natural|min_length[4]|max_length[8]|matches[password]');
        }
        if($this->form_validation->run()) {
            $data_set['trading_pwd'] = md5($this->form_validation->set_value('password'));
            if($this->user_model->where(array('id'=>$this->site_info['id']))->edit($data_set))
            {
                $this->show_message(TRUE, '保存成功', '/c/member/set_pwd');
                return FALSE;
            }
            else
            {
                $this->show_message(FALSE, '保存失败', '/c/member/set_pwd');
                return FALSE;
            }
        } else {
            $errors = validation_errors();
            if ($errors) {
                $this->show_message(FALSE, $errors, '/c/member/set_pwd');
                return FALSE;
            }
        }

        $this->load->view($this->dcm, $this->data);
    }

    /**
     * 找回密码
     */
    public function retrieve_pwd()
    {
        $this->load->model('user_model');
        $user = $this->user_model->where(array('id'=>$this->site_info['id']))->find();
        if(!$user) {
            $this->show_message(FALSE, '商家不存在', '/c/member/set_pwd');
            return FALSE;
        }
        $to_email = $user['email'];
        if(!$to_email)
        {
            $this->show_message(FALSE, '您还未设置邮箱，请联系代理商并提供您的邮箱进行设置', '/c/member/set_pwd');
        }
        $this->load->config('email');
        $this->load->library('email');

        //$to_email = '306302160@qq.com';//'luisfigook@hotmail.com';
        $pass = rand(100000, 999999);
        $from_email = $this->config->item('smtp_user');//'support@bama555.com';
        $from_name = 'support';
        $message = "您好：\r\n您的交易密码已被重置为".$pass.",\r\n请赶快登录微网站后台重置您的新密码！";
        $this->email->from($from_email, $from_name);
        $this->email->to($to_email);
        $this->email->subject('找回交易密码');
        $this->email->message($message);

        if($this->email->send() && $this->user_model->where(array('id'=>$this->site_info['id']))->edit(array('trading_pwd'=>md5($pass))))
        {
            $this->show_message(TRUE, '请及时查看您的邮件（'.$to_email.'），并重置您的新密码', '/c/member/set_pwd');
        }
        else
        {
            $this->show_message(FALSE, '找回交易密码失败，请稍后重试', '/c/member/set_pwd');
        }
    }

    /**
     * @param $id
     * 金额调节
     */
    public function money_toggle($id){
        $member = $this->model->where(array('id'=>$id, 'wid'=>$this->site_info['id']))->find();
        if(!$member) {
            $this->show_message(FALSE, '该会员不存在', '/c/member');
            return FALSE;
        }

        $this->form_validation->set_rules('password', '交易密码', 'trim|required|is_natural|callback_check_pass');
        $this->form_validation->set_rules('money', '金额', 'trim|numeric|greater_than[0]|less_than[10000000]');

        if($this->form_validation->run())
        {
            $action = $this->input->post('action');
            $pass = $this->form_validation->set_value('password');
            $toggle_money = $this->form_validation->set_value('money');
            if($action == 'cut' && $toggle_money - $member['money'] > 0) {
                $this->show_message(FALSE, '该用户的余额不足', '/c/member/money_toggle/'.$id);
                return FALSE;
            }
            //如果是充值，判断是否需要送积分或者送现金
            $gift_money = 0;
            $gift_credit = 0;
            if($action == 'recharge') {
                $this->load->library('Mongo_db');
                //送现金
                $money_setting = $this->mongo_db->where(array('site_id'=>$this->site_info['id']))->get_one($this->mongo_money);
                if($money_setting && isset($money_setting['recharge_rules']) && $money_setting['recharge_rules']) {
                    usort($money_setting['recharge_rules'], array('Member', 'cmp'));
                    foreach($money_setting['recharge_rules'] as $rule) {
                        if($rule['money'] && ($n = floor($toggle_money/$rule['money'])) > 0) {
                            if($rule['accumulate']) { //累计
                                $gift_money = $n*$rule['gift_money'];
                            } else { //不累计
                                $gift_money = $rule['gift_money'];
                            }
                            $data_set['gift_money'] = $gift_money;
                            break;
                        }
                    }
                }
                //送积分
                $credit_setting = $this->mongo_db->where(array('site_id'=>$this->site_info['id']))->get_one($this->mongo_credit);
                if($credit_setting && isset($credit_setting['recharge_rules']) && $credit_setting['recharge_rules']) {
                    usort($credit_setting['recharge_rules'], array('Member', 'cmp'));
                    foreach($credit_setting['recharge_rules'] as $rule) {
                        if($rule['money'] && ($n = floor($toggle_money/$rule['money'])) > 0) {
                            if($rule['accumulate']) { //累计
                                $gift_credit = $n*$rule['credit'];
                            } else { //不累计
                                $gift_credit = $rule['credit'];
                            }
                            break;
                        }
                    }
                }
                $data_set['money'] = $toggle_money + $gift_money + $member['money'];
                $data_set['credit'] = $member['credit'] + $gift_credit;
                $data_set['level_credit'] = $member['level_credit'] + $gift_credit;
            }
            ($action == 'cut') && $data_set['money'] = $member['money'] - $toggle_money;

            if($this->model->where(array('id'=>$id, 'wid'=>$this->site_info['id']))->edit($data_set))
            {
                //消费记录
                $action_data = array();
                $action_data['site_id'] = $this->site_info['id'];
                $action_data['mid'] = $id;
                $action_data['username'] = $member['name'];
                if($action == 'recharge') {
                    $action_data['money'] = $toggle_money + $gift_money;
                    $remark = $this->get_pass_from($pass)."充值".$toggle_money."元";
                    $action_data['remark'] = $gift_money > 0 ? $remark.', 赠送'.$gift_money.'元' : $remark;
                } elseif ($action == 'cut') {
                    $action_data['money'] = -$toggle_money;
                    $action_data['remark'] = $this->get_pass_from($pass)."扣款".$toggle_money."元";
                }
                $action_data['dt_record'] = time();
                $this->load->model('money_record_model');
                $this->money_record_model->add($action_data);

                //如果有积分赠送，则添加积分记录
                if($gift_credit > 0) {
                    $cdata = array();
                    $cdata['site_id'] = $this->site_info['id'];
                    $cdata['mid'] = $id;
                    $cdata['username'] = $member['name'];
                    $cdata['credit'] = $gift_credit;
                    $cdata['remark'] = $this->get_pass_from($pass)."充值".$toggle_money."元, 赠送".$gift_credit."分";
                    $cdata['dt_record'] = time();

                    $this->load->model('credit_record_model');
                    $this->credit_record_model->add($cdata);

                    //添加到老的日志里, 添加积分类商家充值赠送行为scope=2, type=0, sub_type=7
                    $action_data = array();
                    $action_data['scope'] = 2;
                    $action_data['type'] = 0;
                    $action_data['sub_type'] = 7;
                    $action_data['uid'] = $id;
                    $action_data['value'] = $gift_credit;
                    $action_data['memo'] = $this->get_pass_from($pass)."充值".$toggle_money."元, 赠送".$gift_credit."分";
                    $this->action_record($action_data);
                }

                if($action == 'recharge') {
                    //添加消费类充值行为scope=1, type=0, sub_type=0
                    $action_data = array();
                    $action_data['scope'] = 1;
                    $action_data['type'] = 0;
                    $action_data['sub_type'] = 0;
                    $action_data['uid'] = $id;
                    $action_data['value'] = $toggle_money + $gift_money;
                    $memo = $this->get_pass_from($pass)."充值".$toggle_money."元";
                    $action_data['memo'] = $gift_money > 0 ? $memo.', 赠送'.$gift_money.'元' : $memo;
                    $this->action_record($action_data);
                } elseif($action == 'cut') {
                    //添加消费类商家扣款行为scope=1, type=0, sub_type=1
                    $action_data = array();
                    $action_data['scope'] = 1;
                    $action_data['type'] = 0;
                    $action_data['sub_type'] = 1;
                    $action_data['uid'] = $id;
                    $action_data['value'] = $toggle_money;
                    $this->action_record($action_data);
                }

                $msg = '操作成功';
                ($action == 'recharge') && $msg = '充值成功';
                ($action == 'cut') && $msg = '扣款成功';
                $this->show_message(TRUE, $msg, '/c/member');
                return FALSE;
            }
            else
            {
                $msg = '操作失败';
                ($action == 'recharge') && $msg = '充值失败';
                ($action == 'cut') && $msg = '扣款失败';
                $this->show_message(FALSE, $msg, '/c/member/money_toggle/'.$id);
                return FALSE;
            }
        }
        else
        {
            $errors = validation_errors();
            if ($errors) {
                $this->show_message(FALSE, $errors, '/c/member/money_toggle/'.$id);
                return FALSE;
            }
        }

        $this->load->view($this->dcm, $this->data);
    }

    /**
     * @param $id
     * 积分调节
     */
    public function credit_toggle($id)
    {
        $member = $this->model->where(array('id'=>$id, 'wid'=>$this->site_info['id']))->find();
        if(!$member) {
            $this->show_message(FALSE, '该会员不存在', '/c/member');
            return FALSE;
        }

        $this->load->model('credit_reason_model');
        $reason_list = $this->credit_reason_model->where(array('site_id'=>$this->site_info['id']))->find_all();
        $this->data['reason_list'] = $reason_list;

        $this->form_validation->set_rules('password', '交易密码', 'trim|required|is_natural|callback_check_pass');
        $this->form_validation->set_rules('credit', '积分数', 'trim|is_natural_no_zero|less_than[10000000]');

        if($this->form_validation->run())
        {
            $action = $this->input->post('action');
            $pass = $this->form_validation->set_value('password');
            $toggle_credit = (int)$this->form_validation->set_value('credit');

            if($action == 'reduce' && $toggle_credit - $member['credit'] > 0) {
                $this->show_message(FALSE, '该用户的积分不足', '/c/member/credit_toggle/'.$id);
                return FALSE;
            }

            if($action == 'add') {
                $data_set['credit'] = $toggle_credit + $member['credit'];
                $data_set['level_credit'] = $toggle_credit + $member['level_credit'];
            } elseif ($action == 'reduce') {
                $data_set['credit'] = $member['credit'] - $toggle_credit;
            }

            if($this->model->where(array('id'=>$id, 'wid'=>$this->site_info['id']))->edit($data_set))
            {
                $reason = $this->input->post('reason');
                $reason = $this->credit_reason_model->where(array('id'=>$reason))->find();
                $reason = $reason['reason'];
                $memo = $this->input->post('memo');

                $action_data = array();
                $action_data['site_id'] = $this->site_info['id'];
                $action_data['mid'] = $id;
                $action_data['username'] = $member['name'];
                ($action == 'add') && $action_data['credit'] = $toggle_credit;
                ($action == 'add') && $action_data['remark'] = $this->get_pass_from($pass)."增加".$toggle_credit."分, 操作原因：".$reason.', 备注：'.$memo;
                ($action == 'reduce') && $action_data['credit'] = -$toggle_credit;
                ($action == 'reduce') && $action_data['remark'] = $this->get_pass_from($pass)."减少".$toggle_credit."分, 操作原因：".$reason.', 备注：'.$memo;
                $action_data['dt_record'] = time();

                $this->load->model('credit_record_model');
                $this->credit_record_model->add($action_data);

                if($action == 'add') {
                    //添加积分类商家增加行为scope=2, type=0, sub_type=0
                    $action_data = array();
                    $action_data['scope'] = 2;
                    $action_data['type'] = 0;
                    $action_data['sub_type'] = 0;
                    $action_data['uid'] = $id;
                    $action_data['value'] = $toggle_credit;
                    $action_data['memo'] = $this->get_pass_from($pass)."增加".$toggle_credit."分, 操作原因：".$reason.', 备注：'.$memo;
                    $this->action_record($action_data);
                } elseif ($action = 'reduce') {
                    //添加积分类商家减少行为scope=2, type=1, sub_type=1
                    $action_data = array();
                    $action_data['scope'] = 2;
                    $action_data['type'] = 1;
                    $action_data['sub_type'] = 1;
                    $action_data['uid'] = $id;
                    $action_data['value'] = $toggle_credit;
                    $action_data['memo'] = $this->get_pass_from($pass)."增加".$toggle_credit."分, 操作原因：".$reason.', 备注：'.$memo;
                    $this->action_record($action_data);
                }

                $msg = '操作成功';
                ($action == 'add') && $msg = '增加积分成功';
                ($action == 'reduce') && $msg = '减少积分成功';
                $this->show_message(TRUE, $msg, '/c/member');
                return FALSE;
            }
            else
            {
                $msg = '操作失败';
                ($action == 'add') && $msg = '增加积分失败';
                ($action == 'reduce') && $msg = '减少积分失败';
                $this->show_message(FALSE, $msg, '/c/member/credit_toggle/'.$id);
                return FALSE;
            }
        }
        else
        {
            $errors = validation_errors();
            if ($errors) {
                $this->show_message(FALSE, $errors, '/c/member/credit_toggle/'.$id);
                return FALSE;
            }
        }

        $this->load->view($this->dcm, $this->data);
    }

    public function cash($id){
        $member = $this->model->where(array('id'=>$id, 'wid'=>$this->site_info['id']))->find();
        if(!$member) {
            $this->show_message(FALSE, '该会员不存在', '/c/member');
            return FALSE;
        }

        $this->form_validation->set_rules('password', '交易密码', 'trim|required|is_natural|callback_check_pass');
        $this->form_validation->set_rules('money', '金额', 'trim|numeric|greater_than[0]|less_than[10000000]');
        $this->form_validation->set_rules('dt_consume', '消费时间', 'trim|required');

        if($this->form_validation->run())
        {
            $pass = $this->form_validation->set_value('password');
            $money = $this->form_validation->set_value('money');
            $dt_consume = $this->form_validation->set_value('dt_consume');
            $memo = $this->input->post('memo');
            if($money - $member['money'] > 0) {
                $this->show_message(FALSE, '该用户的余额不足', '/c/member/cash/'.$id);
                return FALSE;
            }
            //判断是否需要现金消费送积分
            $gift_credit = 0;
            $this->load->library('Mongo_db');
            //送积分
            $credit_setting = $this->mongo_db->where(array('site_id'=>$this->site_info['id']))->get_one($this->mongo_credit);
            if($credit_setting && isset($credit_setting['cash_consume_rules']) && $credit_setting['cash_consume_rules']) {
                usort($credit_setting['cash_consume_rules'], array('Member', 'cmp'));
                foreach($credit_setting['cash_consume_rules'] as $rule) {
                    if($rule['money'] && ($n = floor($money/$rule['money'])) > 0) {
                        if($rule['accumulate']) { //累计
                            $gift_credit = $n*$rule['credit'];
                        } else { //不累计
                            $gift_credit = $rule['credit'];
                        }
                        break;
                    }
                }
            }
            $data_set['credit'] = $member['credit'] + $gift_credit;
            $data_set['level_credit'] = $member['level_credit'] + $gift_credit;

            $data_set['money'] = $member['money'] - $money;

            if($this->model->where(array('id'=>$id, 'wid'=>$this->site_info['id']))->edit($data_set))
            {
                $memo = $memo ? ", 备注:".$memo : $memo;
                //消费记录
                $action_data = array();
                $action_data['site_id'] = $this->site_info['id'];
                $action_data['mid'] = $id;
                $action_data['username'] = $member['name'];
                $action_data['money'] = -$money;
                $action_data['remark'] = $this->get_pass_from($pass)."现金消费".$money."元, 消费时间:".$dt_consume.$memo;

                $action_data['dt_record'] = time();
                $this->load->model('money_record_model');
                $this->money_record_model->add($action_data);

                //如果有积分赠送，则添加积分记录
                if($gift_credit > 0) {
                    $cdata = array();
                    $cdata['site_id'] = $this->site_info['id'];
                    $cdata['mid'] = $id;
                    $cdata['username'] = $member['name'];
                    $cdata['credit'] = $gift_credit;
                    $cdata['remark'] = $this->get_pass_from($pass)."现金消费".$money."元, 赠送".$gift_credit."分, 消费时间:".$dt_consume.$memo;
                    $cdata['dt_record'] = time();

                    $this->load->model('credit_record_model');
                    $this->credit_record_model->add($cdata);

                    //添加到老的日志里, 添加积分类现金消费赠送行为scope=2, type=0, sub_type=9
                    $action_data = array();
                    $action_data['scope'] = 2;
                    $action_data['type'] = 0;
                    $action_data['sub_type'] = 9;
                    $action_data['uid'] = $id;
                    $action_data['value'] = $gift_credit;
                    $action_data['memo'] = $this->get_pass_from($pass)."现金消费".$money."元, 赠送".$gift_credit."分, 消费时间:".$dt_consume.$memo;
                    $this->action_record($action_data);
                }

                //添加消费类现金消费行为scope=1, type=0, sub_type=2
                $action_data = array();
                $action_data['scope'] = 1;
                $action_data['type'] = 0;
                $action_data['sub_type'] = 2;
                $action_data['uid'] = $id;
                $action_data['value'] = $money;
                $memo = $this->get_pass_from($pass)."现金消费".$money."元, 消费时间:".$dt_consume.$memo;
                $action_data['memo'] = $gift_credit > 0 ? $memo.', 赠送'.$gift_credit.'分' : $memo;
                $this->action_record($action_data);


                $msg = '操作成功';
                $this->show_message(TRUE, $msg, '/c/member');
                return FALSE;
            }
            else
            {
                $msg = '操作失败';
                $this->show_message(FALSE, $msg, '/c/member/cash/'.$id);
                return FALSE;
            }
        }
        else
        {
            $errors = validation_errors();
            if ($errors) {
                $this->show_message(FALSE, $errors, '/c/member/cash/'.$id);
                return FALSE;
            }
        }
        $this->data['member'] = $member;
        $this->load->view($this->dcm, $this->data);
    }

    /**
     * @param $id
     * 详细
     */
    public function detail($id)
    {
        $member = $this->model->where(array('id'=>$id, 'wid'=>$this->site_info['id']))->find();
        if(!$member) {
            $this->show_message(FALSE, '该会员不存在', '/c/member');
            return FALSE;
        }

        $member['wxid'] && $member['wxid'] = substr($member['wxid'], 0, strlen($member['wxid'])-6).'******';
        $member['dt_add'] && $member['dt_add'] = date('Y-m-d H:i:s', $member['dt_add']);

        $this->load->library('Mongo_db');
        $list = $this->mongo_db->where(array('wid'=>$this->site_info['id']))->order_by(array('sort' => 'ASC'))->get('account_fields');
        $list = $list ? $list : array();
        foreach($list as &$field) {
            $fv = $this->mongo_db->where(array('wid'=>$this->site_info['id'], 'uid'=>$id))->get_one('account_field_value');
            $value = isset($fv[(string)$field['_id']]) ? $fv[(string)$field['_id']] : '';
            $field['value'] = is_array($value) ? implode(', ', $value) : $value;
        }

        $this->data['list'] = $list;
        $this->data['member'] = $member;
        $this->load->view($this->dcm, $this->data);
    }

    /**
     * 修改密码
     */
    public function reset_pass($id)
    {
        $member = $this->model->where(array('id'=>$id, 'wid'=>$this->site_info['id']))->find();
        if(!$member) {
            $this->show_message(FALSE, '该会员不存在', '/c/member');
            return FALSE;
        }

        $this->form_validation->set_rules('new_pass', '新密码', 'trim|required');
        $this->form_validation->set_rules('conf_pass', '确认新密码', 'trim|required|matches[new_pass]');
        if($this->form_validation->run())
        {
            $data_set['password'] = md5($this->form_validation->set_value('new_pass'));
            $data_set['dt_update'] = time();
            if($this->model->where(array('id'=>$id, 'wid'=>$this->site_info['id']))->edit($data_set))
            {
                $this->show_message(TRUE, '修改密码成功', '/c/member');
                return FALSE;
            }
            else
            {
                $this->show_message(FALSE, '修改密码失败', '/c/member/reset_pass/'.$id);
                return FALSE;
            }
        }
        else
        {
            $errors = validation_errors();
            if ($errors) {
                $this->show_message(FALSE, $errors, '/c/member/reset_pass/'.$id);
                return FALSE;
            }
        }

        $this->load->view($this->dcm, $this->data);
    }

    //交易密码设置里检查当前密码是否正确
    public function check_curpass($pass)
    {
        $this->load->model('user_model');
        $user = $this->user_model->where(array('id'=>$this->site_info['id'], 'trading_pwd'=>md5($pass)))->find();
        if(!$user)
        {
            $this->form_validation->set_message('check_curpass', '当前密码不正确');
            return FALSE;
        }
        return TRUE;
    }

    /**
     * @param $pass
     * 判断交易密码是否正确,是否是门店交易密码，商家交易密码
     */
    public function check_pass($pass)
    {
        $this->load->model('user_model');
        $user = $this->user_model->where(array('id'=>$this->site_info['id']))->find();
        if($user['trading_pwd'] == md5($pass)) {
            return TRUE;
        }else{
            $this->load->model('address_model');
            $address_list = $this->address_model->where(array('wid'=>$this->site_info['id'], 'status !='=>-1))->find_all();
            foreach($address_list as $ad) {
                if(md5($pass) == $ad['trading_pwd']){
                    return TRUE;
                }
            }
        }

        $this->form_validation->set_message('check_pass', '密码不正确');
        return FALSE;
    }

    /**
     * @param $pass
     */
    private function get_pass_from($pass)
    {
        $this->load->model('user_model');
        $user = $this->user_model->where(array('id'=>$this->site_info['id']))->find();
        if($user['trading_pwd'] == md5($pass)) {
            return "商家";
        }else{
            $this->load->model('address_model');
            $address_list = $this->address_model->where(array('wid'=>$this->site_info['id'], 'status !='=>-1))->find_all();
            foreach($address_list as $ad) {
                if(md5($pass) == $ad['trading_pwd']){
                    return "商家(".$ad['name'].")";
                }
            }
        }
        return "商家";
    }

    public function log($mid)
    {
        $this->load->model('action_record_model');
        $where = array(
            'wid' => $this->site_info['id'],
            'uid' => $mid,
        );
        $total_rows = $this->action_record_model->where($where)->count();
        $pager = $this->_pager($total_rows);
        $list = $this->action_record_model->order_by('id desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->where($where)->find_all();
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->load->config('action_record');
        $this->data['action_record'] = $this->config->item('action_record');
        $this->load->view($this->dcm, $this->data);
    }

    public function export()
    {
        $like = $search = array();
        $search['sear_name'] = $this->input->get('sear_name');
        $search['sear_mobile'] = $this->input->get('sear_mobile');
        $search['sear_money_s'] = $this->input->get('sear_money_s');
        $search['sear_money_e'] = $this->input->get('sear_money_e');
        $search['sear_credit_s'] = $this->input->get('sear_credit_s');
        $search['sear_credit_e'] = $this->input->get('sear_credit_e');

        $this->data['search'] = $search;
        $search_url = site_url($this->uri->uri_string().'?');
        if( $search ){
            foreach( $search as $key=>$val ){
                if( $val ){
                    $search_url .= '&'.$key.'='.$val;
                    switch ($key){
                        case 'sear_name':
                            $like['name'] = $search['sear_name'];
                            break;
                        case 'sear_mobile':
                            $like['mobile'] = $search['sear_mobile'];
                            break;
                        case 'sear_money_s':
                            $where['money >='] = $search['sear_money_s'];
                            break;
                        case 'sear_money_e':
                            $where['money <='] = $search['sear_money_e'];
                            break;
                        case 'sear_credit_s':
                            $where['credit >='] = $search['sear_credit_s'];
                            break;
                        case 'sear_credit_e':
                            $where['credit <='] = $search['sear_credit_e'];
                            break;
                        default: break;
                    }
                }
            }
        }

        $where['wid'] = $this->site_info['id'];

        //分批导出参数
        if($this->input->get('bp') == 1)
        {
            $val = $this->input->get('batch');
            $s = ($val-1)*1000;
            $list = $this->model->order_by('id desc')->where($where)->like($like)->limit(1000,$s)->find_all();
        }else{
            $list = $this->model->order_by('id desc')->where($where)->like($like)->find_all();
        }
        $mlist = array();
        if($list)
        {
            $this->load->library('Mongo_db');
            $field_list = $this->mongo_db->where(array('wid'=>$this->site_info['id']))->order_by(array('sort' => 'ASC'))->get('account_fields');
            $field_list = $field_list ? $field_list : array();

            foreach($list as $key=> $item)
            {
                $mlist[$key]['name'] = $item['name'];
                $mlist[$key]['mobile'] = $item['mobile'];
                $mlist[$key]['money'] = $item['money'];
                $mlist[$key]['credit'] = $item['credit'];

                $fv = $this->mongo_db->where(array('wid'=>$this->site_info['id'], 'uid'=>$item['id']))->get_one('account_field_value');
                foreach($field_list as $field) {
                    $value = isset($fv[(string)$field['_id']]) ? $fv[(string)$field['_id']] : '';
                    $value = is_array($value) ? implode(', ', $value) : $value;
                    $mlist[$key][(string)$field['_id']] = $value;
                }
            }

            $fields = array(
                '#'=>'#',
                'name'=>'用户名',
                'mobile'=>'手机号码',
                'money'=>'余额',
                'credit'=>'积分'
            );
            foreach($field_list as $field_item) {
                $fields[(string)$field_item['_id']] = $field_item['title'];
            }
            //$this->excel_export('会员列表', '会员列表', $fields, $mlist);
            $this->excel_flush_export($fields, $mlist, '会员列表');
        }
        else
        {
            $this->show_message(FALSE, '尚无会员记录可导出', '/c/member/index');
        }
    }

    public function cmp($item_a, $item_b) {
        if ($item_a['money'] == $item_b['money'])
            return 0;
        return ($item_a['money'] > $item_b['money']) ? -1 : 1;
    }

    /**
     * 积分一键清零
     */
    public function credit_clear($id)
    {
        $member = $this->model->where(array('id'=>$id, 'wid'=>$this->site_info['id']))->find();
        if(!$member) {
            $this->show_message(FALSE, '该会员不存在', '/c/member');
            return FALSE;
        }

        $this->form_validation->set_rules('password', '交易密码', 'trim|required|is_natural|callback_check_pass');

        if($this->form_validation->run())
        {
            $pass = $this->form_validation->set_value('password');
            $data_set['credit'] = 0;
            $data_set['level_credit'] = 0;

            if($this->model->where(array('id'=>$id, 'wid'=>$this->site_info['id']))->edit($data_set))
            {
                $memo = $this->input->post('memo');

                $action_data = array();
                $action_data['site_id'] = $this->site_info['id'];
                $action_data['mid'] = $id;
                $action_data['username'] = $member['name'];
                $action_data['remark'] = $this->get_pass_from($pass).'积分清零, 备注：'.$memo;
                $action_data['dt_record'] = time();

                $this->load->model('credit_record_model');
                $this->credit_record_model->add($action_data);

                //添加积分类商家清零积分行为scope=2, type=1, sub_type=3
                $action_data = array();
                $action_data['scope'] = 2;
                $action_data['type'] = 1;
                $action_data['sub_type'] = 3;
                $action_data['uid'] = $id;
                $action_data['memo'] = $this->get_pass_from($pass).'积分清零, 备注：'.$memo;
                $this->action_record($action_data);

                $this->show_message(TRUE, '操作成功', '/c/member');
                return FALSE;
            }
            else
            {
                $this->show_message(FALSE, '操作失败', '/c/member/credit_clear/'.$id);
                return FALSE;
            }
        }
        else
        {
            $errors = validation_errors();
            if ($errors) {
                $this->show_message(FALSE, $errors, '/c/member/credit_clear/'.$id);
                return FALSE;
            }
        }

        $this->load->view($this->dcm, $this->data);
    }

    /**
     * 批量积分清零
     */
    public function batch_credit_clear()
    {
        $ids = $this->input->get('ids');
        $ids = $ids ? explode(',', $ids) : array();
        $this->form_validation->set_rules('password', '交易密码', 'trim|required|is_natural|callback_check_pass');

        if($this->form_validation->run())
        {
            $pass = $this->form_validation->set_value('password');
            $data_set['credit'] = 0;
            $data_set['level_credit'] = 0;

            foreach($ids as $id) {
                $member = $this->model->where(array('id'=>$id, 'wid'=>$this->site_info['id']))->find();
                if($member) {
                    if($this->model->where(array('id'=>$id, 'wid'=>$this->site_info['id']))->edit($data_set))
                    {
                        $memo = $this->input->post('memo');

                        $action_data = array();
                        $action_data['site_id'] = $this->site_info['id'];
                        $action_data['mid'] = $id;
                        $action_data['username'] = $member['name'];
                        $action_data['remark'] = $this->get_pass_from($pass).'积分清零, 备注：'.$memo;
                        $action_data['dt_record'] = time();

                        $this->load->model('credit_record_model');
                        $this->credit_record_model->add($action_data);

                        //添加积分类商家清零积分行为scope=2, type=1, sub_type=3
                        $action_data = array();
                        $action_data['scope'] = 2;
                        $action_data['type'] = 1;
                        $action_data['sub_type'] = 3;
                        $action_data['uid'] = $id;
                        $action_data['memo'] = $this->get_pass_from($pass).'积分清零, 备注：'.$memo;
                        $this->action_record($action_data);


                    }
                }
            }
            $this->show_message(TRUE, '操作成功', '/c/member');
            return FALSE;
        }
        else
        {
            $errors = validation_errors();
            if ($errors) {
                $this->show_message(FALSE, $errors, '/c/member');
                return FALSE;
            }
        }

        $this->load->view($this->dcm, $this->data);
    }
}