<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 微助手
 */

class Wbhelper extends C_Controller
{
    private $site_id = '';

    public function __construct()
    {
        parent::__construct();

        $this->load->library('rest', array(
            'server' => WEIZHUSHOU_API_URL,
            'app_key' => $this->app_key,
            'secret_key' => $this->app_secret,
        ), 'rest');
    }

    public function index(){
        $this->site_id = $this->site_info['id'];

        $resp = $this->rest->get('helper',array('source_id'=>$this->site_id));

        $this->data['ret']=$resp['ret'];

       // var_dump($resp);

        if($resp['ret']>0){
            $this->data['msg']=$resp['msg'];
        }else{
            $this->data['id']=$resp['data']['id'];
            $this->data['qrcode']=$resp['data']['qrcode'];
        }

        $this->load->view($this->dcm,$this->data);
    }

    public function open_helper(){
        $this->site_id = $this->site_info['id'];

        $resp = $this->rest->post('helper',array('source_id'=>$this->site_id,'source_type'=>'bama555'));

        $this->data['ret']=$resp['ret'];



        if($resp['ret']>0){
            $this->data['msg']=$resp['msg'];
        }else{
            $this->load->model('user_model');
            //$this->user_model->find($this->site_id);
            $this->user_model->where(array('id'=>$this->site_id))->edit(array('helper_on'=>1));

            $this->data['id']=$resp['data']['id'];
            $this->data['qrcode']=$resp['data']['qrcode'];
        }

        $this->load->view($this->dcm,$this->data);
    }
}
