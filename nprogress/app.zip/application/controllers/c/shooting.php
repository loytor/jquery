<?php
/**
 * Created by PhpStorm.
 * User: along
 * Date: 14-5-28
 * Time: 下午3:06
 * @property Shooting_model $shooting_model
 * @property Shooting_member_model $shooting_member_model
 */

class Shooting extends C_Controller {

    private $site_id = '';
    protected $data = array();

    public function __construct()
    {
        parent::__construct();
        $this->load->model('shooting_model');
        $this->site_id = $this->site_info['id'];
    }

    public function index()
    {
        $where = array();
        $where['site_id'] = $this->site_id;
        $where['status'] = 1;
        $total = $this->shooting_model->where($where)->count();
        $pager = $this->_pager($total, array('per_page'=>15));

        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->data['list'] = array();
        if($total > 0)
        {
            $this->data['list'] = $this->shooting_model->where($where)->limit($pager['limit']['value'],$pager['limit']['offset'])->order_by('id desc')->find_all();
        }
        $this->data['viewurl'] = $this->create_url('shooting');
        $this->load->view($this->dcm,$this->data);
    }
    /**
     * 点球游戏设置
     */
    public function set()
    {
        $where = array();
        $id = $this->input->get_post('id');
        $shooting = array();
        if($id)
        {
            $where['id'] = $id;
            $where['site_id'] = $this->site_id;
            $shooting = $this->shooting_model->where($where)->find();
        }

        $post = $this->input->post();
        if($post)
        {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('start_time','开始时间','trim|required');
            $this->form_validation->set_rules('end_time','结束时间','trim|required');
            $this->form_validation->set_rules('title','标题','trim|required');
            $this->form_validation->set_rules('number','射门次数','trim|required|is_numeric');
            //$this->form_validation->set_rules('sharenumber','分享激励','trim|is_numeric');
            $this->form_validation->set_rules('firstrate','首次分享概率','trim|is_numeric|less_than_equal_to[100]');
            $this->form_validation->set_rules('custompic', '转发图标', 'trim');
            $this->form_validation->set_rules('customtitle', '转发标题', 'trim|max_length[200]');
            $this->form_validation->set_rules('virtual','虚拟参与人数','trim|is_numeric');
            if ( $this->form_validation->run() )
            {
                //开始时间
                $dataSet['start_time'] = strtotime($this->form_validation->set_value('start_time'));
                $dataSet['end_time'] = strtotime($this->form_validation->set_value('end_time'));
                $dataSet['title'] = $this->form_validation->set_value('title');
                $dataSet['number'] = $this->form_validation->set_value('number');
                //$dataSet['sharenumber'] = $this->form_validation->set_value('sharenumber');

                $dataSet['firstrate'] = $this->form_validation->set_value('firstrate');

                $dataSet['banner'] = $this->input->post('banner');

                //图片
                $dataSet['custompic'] = $this->form_validation->set_value('custompic');
                $dataSet['customtitle'] = $this->form_validation->set_value('customtitle');

                $dataSet['rule'] = $this->input->post('rule');
                $dataSet['prize'] = $this->input->post('prize');
                $dataSet['virtual'] = $this->input->post('virtual');

                //更新
                if($shooting)
                {
                    $this->shooting_model->where(array('id'=>$shooting['id']))->edit($dataSet);
                }
                else
                {
                    $dataSet['site_id'] = $this->site_id;
                    $this->shooting_model->add($dataSet);
                }
                $this->show_message(true, '提交成功', '/c/shooting');return false;
            }
            else
            {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(false, $errors, '');return false;
                }
            }
        }
        else
        {
            $this->data['setting'] = $shooting;
            $this->load->view($this->dcm,$this->data);
        }
    }

    public function del($id = '')
    {
        $shooting = $this->shooting_model->where(array('id'=>$id))->find();
        if(!$shooting || $shooting['site_id'] != $this->site_id)
        {
            $this->show_message(false, '该射门游戏不存在', '/c/shooting/index');return false;
        }
        $this->shooting_model->where(array('id'=>$shooting['id']))->edit(array('status'=>-1));
        $this->show_message(false, '删除成功', '/c/shooting/index');return false;
    }

    public function record($id = '')
    {
        if(!$id)
        {
            $this->show_message(false, '非法访问', '/c/shooting/index');return false;
        }
        $this->load->model('shooting_member_model');
        $where = " site_id = '".$this->site_id."'";

        $searchUrl = '/c/shooting/record/'.$id.'/?';

        $keyword = $this->input->get('keyword');
        if($keyword)
        {
            $this->data['search'] = array('keyword'=>$keyword);
            $where .= " and (username like '%".$keyword."%' or tel like '%".$keyword."%')";
            $searchUrl .= 'keyword='.$keyword;
        }

        $shooting = $this->shooting_model->where(array('site_id' => $this->site_id,'id'=>$id))->find();
        $where .= " and shoot_id = ".$shooting['id'];

        $total_rows = $this->shooting_member_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$searchUrl));

        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->data['list'] = array();
        if($total_rows > 0)
        {
            $this->data['list'] = $this->shooting_member_model->where($where)->limit($pager['limit']['value'], $pager['limit']['offset'])->order_by('score desc')->find_all();
        }
        $this->data['shoot'] = $shooting;
        $this->load->view($this->dcm,$this->data);
    }

    public function export()
    {
        $this->load->model('shooting_member_model');
        $where = " site_id = '".$this->site_id."'";
        $keyword = $this->input->get('keyword');
        if($keyword)
        {
            $this->data['search'] = array('keyword'=>$keyword);
            $where .= " and (username like '%".$keyword."%' or tel like '%".$keyword."%')";
        }
        $id = $this->input->get('id');
        $shooting = $this->shooting_model->where(array('site_id' => $this->site_id,'id'=>$id))->find();
        if(!$shooting)
        {
            $this->show_message(false,'暂无数据可以导出','');return false;
        }
        $where .= " and shoot_id = ".$shooting['id'];

        $list = $this->shooting_member_model->where($where)->order_by('score desc')->find_all();
        $shooterList = array();
        if($list)
        {
            foreach($list as $key=> $item)
            {
                $shooterList[$key]['username'] = $item['username'];
                $shooterList[$key]['tel'] = $item['tel'];
                $shooterList[$key]['shootnum'] = $item['shootnum'];
                $shooterList[$key]['score'] = $item['score'];
                $shooterList[$key]['assistsnum'] = $item['assistsnum'];
            }

            $fields = array(
                '#'=>'#',
                'username'=>'姓名',
                'tel'=>'电话',
                'shootnum'=>'射门次数',
                'score'=>'进球',
                'assistsnum'=>'助攻'
            );
            $this->excel_export('射门数据统计', '射门数据统计', $fields, $shooterList);
        }
        else
        {
            $this->show_message(false,'暂无数据可以导出','');
        }
    }



    //导原有点球数据
    public function backup()
    {
        $this->load->model('shoot_model');
        $basewhere['site_id'] = $this->site_id;
        //,joinnum,shootnum,assistsnum
        $shoot = $this->shoot_model->select('start_time,end_time,number,sharenumber,firstrate,rule,prize,banner,custompic,customtitle,virtual')->where($basewhere)->find();
        if($shoot)
        {
            $shottingdata = $shoot;
            $shottingdata['site_id'] = $this->site_id;
            if($shootingId = $this->shooting_model->add($shottingdata))
            {
                //取所有参与人数

            }
        }
    }
} 