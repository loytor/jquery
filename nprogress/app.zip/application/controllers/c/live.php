<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Created by JetBrains PhpStorm.
 * User: andery
 * Date: 13-10-23
 * Time: 下午5:06
 * 微直播
 * @property Live_model $model
 */

class Live extends C_Controller {

    const END_STATUS = 0;
    const ENABLED_STATUS = 1;

    const STATUS_NOT_START = 0;
    const STATUS_PROGRESSION = 1;
    const STATUS_END = 2;

    private $status_arr = array(
        self::STATUS_NOT_START => '未开始',
        self::STATUS_PROGRESSION => '进行中',
        self::STATUS_END => '已结束'
    );

    protected $auto_load_model = TRUE;
    protected $model_name = 'live';

    public function index()
    {
        $where = array();
        $where['site_id'] = $this->site_info['id'];
        $where['status >='] = 0;
        $like = array();
        ($title = $this->input->get('title')) && $like['title'] = $title;
        ($from_time = $this->input->get('from_time')) && $where['start_time >='] = strtotime($from_time);
        ($end_time = $this->input->get('end_time')) && $where['end_time <='] = strtotime($end_time);

        $status = $this->input->get('status');
        $status = ($status == null) ? -1 : $status;
        if($status == self::STATUS_NOT_START)
        {
            $where['start_time >'] = time();
            $where['status'] = 1;
        }
        elseif($status == self::STATUS_PROGRESSION)
        {
            $where['start_time <='] = time();
            $where['status'] = 1;
        }
        elseif($status == self::STATUS_END)
        {
            $where['status'] = 0;
        }

        $this->data['search'] = $this->input->get();

        $total_rows = $this->model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>5));
        $list = $this->model->order_by('id desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->where($where)->like($like)->find_all();
        
        foreach($list as &$_live)
        {
            if($_live['status'] == self::ENABLED_STATUS)
            {
                //未开始
                if(time() < $_live['start_time'])
                {
                    $_live['status_name'] = $this->status_arr[self::STATUS_NOT_START];
                }
                else //进行中
                {
                    $_live['status_name'] = $this->status_arr[self::STATUS_PROGRESSION];
                }
            }
            else
            {
                $_live['status_name'] = $this->status_arr[self::STATUS_END];
            }
        }

        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->data['status_arr'] = $this->status_arr;
        $this->load->view($this->dcm, $this->data);
    }

    public function add()
    {
        if ($this->input->post()) {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('title', '直播名称', 'trim|required|max_length[200]|htmlspecialchars');
            $this->form_validation->set_rules('img', '直播图片', 'trim|required|callback__check_image');
            $this->form_validation->set_rules('intro', '直播简介', 'trim|htmlspecialchars');
            $this->form_validation->set_rules('start_time', '开始时间', 'trim|required');
            $this->form_validation->set_rules('passwd', '密码设置', 'trim|required');
            if ( $this->form_validation->run() ) {

                //直播参与人员
                $identity = $this->input->post('identity');
                $name     = $this->input->post('name');
                $avatar   = $this->input->post('avatar');
                $author = array();
                foreach( $identity as $key=>$val ){
                    if( trim($val)&&trim($name[$key]) ){
                        $author[] = array(
                            'author_identity' => trim($identity[$key]),
                            'author_name'     => trim($name[$key]),
                            'author_avatar'   => trim($avatar[$key])
                        );
                    }
                }
                if( !$author ){
                    $this->show_message(false, '请填写直播参与人员', '',1);
                }
                $save_data['author_info'] = serialize($author);
                
                $save_data['site_id'] = $this->site_info['id'];
                $save_data['title'] = $this->form_validation->set_value('title');
                $save_data['img']   = $this->form_validation->set_value('img');
                $save_data['intro'] = $this->form_validation->set_value('intro');
                $save_data['start_time'] = strtotime($this->form_validation->set_value('start_time'));
                $save_data['passwd'] = md5($this->form_validation->set_value('passwd'));
                
                if( !$id=$this->model->add($save_data) ){
                    $this->show_message(false, '添加失败', '');
                    return FALSE;
                }else{
                    $this->show_message(true, '添加成功', '/c/live');
                    return FALSE;
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        } else {
            $this->load->view($this->dcm, $this->data);
        }
        return FALSE;
    }

    public function edit($id='')
    {
        !$id && $this->show_message(false, '非法参数', 1);
        
        $live = $this->model->where(array('id'=>$id,'site_id'=>$this->site_info['id']))->find();
        if( !$live ){
            $this->show_message(false, '没有该直播', 1);
        }
        
        if ($this->input->post()) {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('title', '直播名称', 'trim|required|max_length[200]|htmlspecialchars');
            $this->form_validation->set_rules('img', '直播图片', 'trim|required|callback__check_image');
            $this->form_validation->set_rules('intro', '直播简介', 'trim|htmlspecialchars');
            $this->form_validation->set_rules('start_time', '开始时间', 'trim|required');
            $this->form_validation->set_rules('passwd', '密码设置', 'trim');
            if ( $this->form_validation->run() ) {

                //直播参与人员
                $identity = $this->input->post('identity');
                $name     = $this->input->post('name');
                $avatar   = $this->input->post('avatar');
                $author = array();
                foreach( $name as $key=>$val ){
                    if( trim($val)&&trim($name[$key]) ){
                        $author[] = array(
                            'author_identity' => trim($identity[$key]),
                            'author_name'     => trim($name[$key]),
                            'author_avatar'   => trim($avatar[$key])
                        );
                    }
                }
                if( !$author ){
                    $this->show_message(false, '请填写直播参与人员', '',1);
                }
                $save_data['author_info'] = serialize($author);

                $save_data['title'] = $this->form_validation->set_value('title');
                $save_data['img']   = $this->form_validation->set_value('img');
                $save_data['intro'] = $this->form_validation->set_value('intro');
                $save_data['start_time'] = strtotime($this->form_validation->set_value('start_time'));
                $passwd=$this->form_validation->set_value('passwd');
                if( $passwd ){
                    $save_data['passwd'] = md5($passwd);
                }
                $save_data['id'] = $live['id'];
                
                if( false===$this->model->where(array('id'=>$id, 'site_id'=>$this->site_info['id']))->edit( $save_data ) ){
                    $this->show_message(false, '修改失败', '/c/live/edit/'.$live['id']);
                }else{
                    $this->show_message(true, '修改成功', '/c/live');
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '',1);
                }
            }
        }else{
            $live['author_info'] = unserialize($live['author_info']);
            $live['url'] = 'http://' . $this->site_info['domain'].BASE_DOMAIN . '/live/index?id='.$id;
            $this->data['live'] = $live;
            
            $this->load->view($this->dcm, $this->data);   
        }
    }

    public function delete($id='')
    {
        !$id && $this->show_message(false, '非法参数', 1);

        $live = $this->model->find($id);
        if( !$live ){
            $this->show_message(false, '没有该直播', 1);
        }
        
        if( false===$this->model->where(array('id'=>$id, 'site_id'=>$this->site_info['id']))->edit( array('status'=>-1) ) ){
            $this->show_message(false, '修改失败', '/c/live');
        }else{
            $this->show_message(true, '删除成功', '/c/live');
        }
    }

    public function close($id='')
    {
        !$id && $this->show_message(false, '非法参数', 1);

        $live = $this->model->find($id);
        if( !$live ){
            $this->show_message(false, '没有该直播', 1);
        }

        if( false===$this->model->where(array('id'=>$id, 'site_id'=>$this->site_info['id']))->edit( array('status'=>0) ) ){
            $this->show_message(false, '关闭失败', '/c/live');
        }else{
            $this->show_message(true, '关闭成功', '/c/live');
        }
    }

    //检查图片格式
    public function _check_image($image) {
        if ($image) {
            if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
                $this->form_validation->set_message('_check_image', '图片地址格式错误');
                return FALSE;
            }
        }
        return TRUE;
    }

    private function _check_auth($live_id)
    {
        if (!$this->session->userdata('live') && !in_array($this->router->fetch_method(), array('publish_login'))) {
            redirect('c/live/publish_login/'.$live_id);
        } else {
            $this->live = $this->session->userdata('live');
            $this->live_site = $this->user_model->find($this->live['site_id']);
        }
    }

    public function publish_login($live_id)
    {
        if ($this->session->userdata('live')) {
            redirect('c/live/publish/'.$live_id);
        }
        if ($this->input->post()) {
            $passwd = $this->input->post('passwd');
            $live = $this->model->where(array('id' => $live_id, 'passwd' => md5($passwd)))->find();
            if ($live) {
                $this->session->set_userdata('live', $live);
                redirect('c/live/publish/'.$live_id);
            } else {
                redirect('c/live/publish_login/'.$live_id);
            }
        } else {
            $this->data['live'] = $this->model->find($live_id);
            if (!$this->data['live']) {
                return $this->show_message(FALSE, '直播不存在');
            }
            $this->load->view($this->dcm, $this->data);
        }
    }

    /**
     * 发布页面
     */
    public function publish($live_id = '')
    {
        $this->_check_auth($live_id);
        $live = $this->model->find($live_id);
        if (!$live) {
            return $this->show_message(FALSE, '直播不存在');
        }
        $live['author_info'] = unserialize($live['author_info']);
        $live['url'] = prep_url($this->live_site['domain'] . BASE_DOMAIN . '/live/index?id='.$live_id);
        $this->data['live'] = $live;
        $this->load->model('live_comment_model');
        $cmt_total = $this->live_comment_model->where(array('live_id' => $live_id))->count();
        $pager = $this->_pager($cmt_total, array(
            'per_page' => 5
        ));
        $cmt_list = $this->live_comment_model->where(array('live_id' => $live_id))->order_by('id', 'desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->find_all();
        $this->data['cmt_list'] = $cmt_list;
        $this->data['cmt_page'] = $pager['links'];
        //发布页面不登录C后台也可以访问，所以这里再重新赋值给token
        $this->load->library('encrypt');
        $token_data = array('user_id' => $live['site_id'], 'time' => time());
        $this->data['token'] = $this->encrypt->encode(serialize($token_data));
        $this->load->view($this->dcm, $this->data);
    }

    public function edit_online()
    {
        $live_id = $this->input->get('live_id');
        $this->_check_auth($live_id);
        $conline = $this->input->get('conline');
        if ($this->model->where('id', $live_id)->edit(array('conline' => $conline))) {
            $this->show_message(true, '修改成功');
        }
    }

    public function publish_msg()
    {
        $live_id = $this->input->post('live_id');
        $this->_check_auth($live_id);
        $msg = $this->input->post('msg');
        $img = $this->input->post('img');
        $author_name = $this->input->post('author_name');
        $author_avatar = $this->input->post('author_avatar');
        $live = $this->model->find($live_id);
        //判断合法
        if($live)
        {
            $author_info = unserialize($live['author_info']);
            $author_info = $author_info ? $author_info : array();
            $flag = FALSE;
            foreach($author_info as $au)
            {
                if($au['author_name'] == $author_name)
                {
                    $flag = TRUE;
                    break;
                }
            }

            if(!$flag)
            {
                $author = array();
                $author['author_identity'] = '';
                $author['author_name'] = $author_name;
                $author['author_avatar'] = '';
                array_push($author_info, $author);
                if($author_info)
                {
                    $edit_data['author_info'] = serialize($author_info);
                    $this->model->where(array('id'=>$live_id))->edit( $edit_data );
                }
            }
        }

        $this->load->model('live_chart_model');
        $data = array(
            'live_id' => $live_id,
            'msg' => $msg,
            'img' => json_encode($img),
            'author_name' => $author_name,
            'author_avatar' => $author_avatar,
            'add_time' => time()
        );
        if ($this->live_chart_model->add($data)) {
            $this->show_message(true, '发布成功');
        }
    }

    public function cmt_option()
    {
        $live_id = $this->input->get('live_id');
        $this->_check_auth($live_id);
        $cmt_id = $this->input->get('cmt_id');
        $option = $this->input->get('option');
        $status = $option == 'ok' ? 1 : -1;
        $this->load->model('live_comment_model');
        if ($this->live_comment_model->where(array('live_id' => $live_id, 'id' => $cmt_id))->edit(array('status' => $status))) {
            $this->show_message(true, '修改成功');
        }
    }

}