<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: cullen
 * Date: 14-4-16
 * Time: 上午11:08
 * @property Checkin_model $checkin_model
 */

class Advert extends C_Controller {
    private $site_id = '';
    public function __construct()
    {
        parent::__construct();
        $this->site_id = $this->site_info['id'];
        $this->load->model('advert_model');
    }

    /**
     * @name 广告列表
     */
    public function index()
    {
        $where['site_id'] = $this->site_id;
        $list = $this->advert_model->where($where)->find_all();
        $total_rows = $this->advert_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>10));
        $result = $this->advert_model->where($where)->limit($pager['limit']['value'], $pager['limit']['offset'])->order_by('id desc')->find_all();
        $this->data['list'] = $result;
		$this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->load->view($this->dcm,$this->data);
    }

    /**
     * @name 广告添加
     */
    public function add(){
    	$post = $this->input->post();
    	//添加
        if($post)
        {
	    	$this->form_validation->set_rules('ad_title', '广告标题', 'trim|required|max_length[20]');
	    	$this->form_validation->set_rules('ad_url', '广告链接', 'trim');
	    	$this->form_validation->set_rules('ad_pic', '广告图片', 'trim|required|callback__check_image');
	    	$this->form_validation->set_rules('ad_intro', '备注说明', 'trim');
			if($this->form_validation->run()){
				$dataSet['site_id'] = $this->site_id;
	            $dataSet['ad_title'] = $this->form_validation->set_value('ad_title');
	            $dataSet['ad_url'] = $this->form_validation->set_value('ad_url');
	            $dataSet['ad_pic'] = $this->form_validation->set_value('ad_pic');
	            $dataSet['ad_intro'] = $this->form_validation->set_value('ad_intro');
	            $dataSet['dt_add'] = time();
	            $add_yx = $this->advert_model->add($dataSet);
	            if($add_yx){
	                $this->show_message(true, '添加成功', '/c/advert_model');
	            }else{
	                $this->show_message(false, '添加失败', '');
	            }
			}else{
				$errors = validation_errors();
                if ($errors) {
                    return $this->show_message(FALSE, $errors, '');
                }
			}
        }else{
	    	$this->load->view($this->dcm,$this->data);
        }
    }

    /**
     * @name 广告修改
     */
    public function edit($id=''){
    	$post = $this->input->post();
    	if(!$id){
    		return $this->show_message(false, '无效请求', '',1);
    	}
       	$res = $this->advert_model->where(array('id'=>$id))->find();
    	if($res['site_id']!=$this->site_id){
    		return $this->show_message(false, '无权限', '',1);
    	}
    	if($post){
	    	$this->form_validation->set_rules('ad_title', '广告标题', 'trim|required|max_length[20]');
	    	$this->form_validation->set_rules('ad_url', '广告链接', 'trim');
	    	$this->form_validation->set_rules('ad_pic', '广告图片', 'trim|required|callback__check_image');
	    	$this->form_validation->set_rules('ad_intro', '备注说明', 'trim');
			if($this->form_validation->run()){
	            $dataSet['ad_title'] = $this->form_validation->set_value('ad_title');
	            $dataSet['ad_url'] = $this->form_validation->set_value('ad_url');
	            $dataSet['ad_pic'] = $this->form_validation->set_value('ad_pic');
	            $dataSet['ad_intro'] = $this->form_validation->set_value('ad_intro');
	            $add_yx = $this->advert_model->where(array('id'=>$id))->edit($dataSet);
	            if($add_yx){
	                $this->show_message(true, '修改成功', '/c/advert');
	            }else{
	                $this->show_message(false, '修改失败', '');
	            }
			}else{
				$errors = validation_errors();
                if ($errors) {
                    return $this->show_message(FALSE, $errors, '');
                }
			}
    	}else{
	    	$this->data['list']=$res;
	    	$this->load->view($this->dcm,$this->data);
    	}
    }
    
    /**
     * @name 广告删除
     */
    public function delete($id=''){
        if(!$id){
            $this->show_message(false, '非法参数', 1);return false;
        }
        $res = $this->advert_model->where(array('id'=>$id))->find();
        if(!$res){
        	return $this->show_message(false, '不存在', '',1);
        }
    	if($res['site_id']!=$this->site_id){
    		return $this->show_message(false, '无权限', '',1);
    	}        
        
    	//删除关联数据
    	$this->load->model('advert_app_model');
    	$this->advert_app_model->where(array('advert_id'=>$id))->delete();
    	$request = $this->advert_model->where(array('id'=>$id))->delete();
        if($request){
        	 $this->show_message(true, '删除成功', '/c/advert/index');return FALSE;
        }
    }
    /**
     * @name 广告上线和下线操作
     */
    public function open($id=''){
        if(!$id){
            $this->show_message(false, '非法参数', 1);return false;
        }
        $res = $this->advert_model->where(array('id'=>$id))->find();
        if(!$res){
        	return $this->show_message(false, '不存在', '',1);
        }
    	if($res['site_id']!=$this->site_id){
    		return $this->show_message(false, '无权限', '',1);
    	}        
       	if($res['ad_status']){
    		$dataSet['ad_status']=0;
    		$info = "下线成功";
    	}else{
    		$dataSet['ad_status']=1;
    		$info = "上线成功";
    	}
        $request = $this->advert_model->where(array('id'=>$id))->edit($dataSet);
        if($request){
        	 $this->show_message(true,$info, '/c/advert');return FALSE;
        }
       
    }
    //检查图片格式
    public function _check_image($image) {
        if ($image) {
            if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
                $this->form_validation->set_message('_check_image', '图片地址格式错误');
                return FALSE;
            }
        }
        return TRUE;
    }
    
    
    //广告应用关联
    public function app($type='')
    {
        if(!$type){
            redirect('/c/advert');
        }
        
        $where['wb_advert_app.site_id'] = $this->site_id;
        $where['wb_advert_app.type'] = $type;
        $this->load->model('advert_app_model');
        $total_rows = $this->advert_app_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>10));
        $list = $this->advert_app_model
                ->select('wb_advert_app.*,wb_advert.ad_title,wb_advert.ad_pic,wb_advert.ad_status')        
                ->join('wb_advert','wb_advert.id=wb_advert_app.advert_id','left')
                ->where($where)
                ->limit($pager['limit']['value'], $pager['limit']['offset'])
                ->order_by('wb_advert_app.listorder asc,wb_advert_app.id desc')->find_all();
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        
        $this->data['left_menu_active'] = $this->router->fetch_class() .'/'. $this->router->fetch_method() .'/'. $type;
        $this->data['type'] = $type;
        
        $this->load->view($this->dcm,$this->data);
    }
    
    //应用添加广告
    public function app_add($type='')
    {
        if(!$type){
            redirect('/c/advert');
        }
        
        $this->load->model('advert_app_model');
        if( $this->input->post() ){
            $advert_id = intval($this->input->post('advert_id'));
            if( !$advert_id ){
                return $this->show_message(false, '请先选择广告', '');
            }
            $listorder = $this->input->post('listorder');
            $listorder=='' && $listorder=255;
            
            $save_data['advert_id'] = $advert_id;
            $save_data['listorder'] = $listorder;
            $save_data['site_id'] = $this->site_id;
            $save_data['type'] = $type;
            if( $this->advert_app_model->add($save_data) ){
                return $this->show_message(true, '添加成功', '/c/advert/app/'.$type);
            }else{
                return $this->show_message(false, '添加失败', '');
            }
        }else{
            
            $can_add = array();
            
            //所有的广告
            $all_adv = $this->advert_model->select('id,ad_title,ad_pic')->where(array('site_id'=>$this->site_id))->order_by('id desc')->find_all();
            //已有的广告
            $has_adv = $this->advert_app_model->select('id,advert_id')->where(array('site_id'=>$this->site_id,'type'=>$type))->find_all();
            foreach( $all_adv as $v1 ){
                $flag = true;
                foreach( $has_adv as $v2 ){
                    if( $v2['advert_id']==$v1['id'] ){
                        $flag = false;
                        break;
                    }
                }
                $flag && $can_add[] = $v1;
            }
            
            $this->data['can_adv'] = $can_add;
            
            $this->data['left_menu_active'] = $this->router->fetch_class() .'/app/'. $type;
            $this->data['type'] = $type;
            
            $this->load->view($this->dcm,$this->data);
        }
    }
    
    //修改排序
    public function app_listorder($id='')
    {
        if(!$id){
            redirect('/c/advert');
        }
        $value = $this->input->post('value');
        if( $value=='' ){ $value = 255; }
        $this->load->model('advert_app_model');
        if( $this->advert_app_model->where(array('site_id'=>$this->site_id,'id'=>$id))->edit(array('listorder'=>$value)) ){
            echo 1;
        }else{
            echo 0;
        }
    }
    
    public function app_delete($id='')
    {
        $type = $this->input->get('type');
        if(!$id||!$type){
            redirect('/c/advert');
        }
        $this->load->model('advert_app_model');
        if( $this->advert_app_model->where(array('id'=>$id,'site_id'=>$this->site_id,'type'=>$type))->delete() ){
            $this->show_message(true, '删除成功', '/c/advert/app/'.$type);return FALSE;
        }else{
            $this->show_message(true, '删除失败', '');return FALSE;
        }
    }
    
    //签到 导数据
    public function export_data()
    {
        //所有的广告
        $all_adv = $this->advert_model->select('id')->where(array('site_id'=>$this->site_id))->order_by('id desc')->find_all();
        $this->load->model('advert_app_model');
        foreach( $all_adv as $val ){
            $save_data['site_id'] = $this->site_id;
            $save_data['advert_id'] = $val['id'];
            $save_data['type'] = 'checkin';
            //TODO
            if( !$app_adv = $this->advert_app_model->where($save_data)->find() ){
                $this->advert_app_model->add($save_data);
            }
        }
        echo "同步完成";
    }
    
} 