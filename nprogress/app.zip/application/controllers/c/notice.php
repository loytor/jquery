<?php
/**
 * Created by PhpStorm.
 * User: songxiyao
 * Date: 2014/9/25
 * Time: 16:22
 */
class Notice extends C_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('model_user');
    }

    public function index() {
        $tpl_data = array();

        //获取用户信息
        $tpl_data['user'] = $user = $this->model_user->get_row(array('id'=>logged_user_id()));

        //获取代理商信息
        $agent_contact = '请联系您的代理商';
        if ($user['agent_id']) {
            $this->load->model('business_contact_model');
            $agent_contact = $this->business_contact_model->where(array('agent_id'=>$user['agent_id']))->find();
            $agent_contact = $agent_contact['business_contact'];
        }
        //!$agent_contact && $agent_contact = '请联系您的代理商';
        $tpl_data['agent_contact'] = $agent_contact;

        $this->load->view('c/notice/index', $tpl_data);
    }
}