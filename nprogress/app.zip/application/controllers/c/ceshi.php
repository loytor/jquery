<?php
/**
 * Created by PhpStorm.
 * User: along
 * Date: 14-5-21
 * Time: 上午10:21
 * @property Ceshi_model $ceshi_model
 * @property Ceshi_options_model $ceshi_options_model
 * @property Ceshi_record_model $ceshi_record_model
 */

class Ceshi extends C_Controller {

    private $site_id = '';
    protected $data = array();

    public function __construct()
    {
        parent::__construct();
        $this->load->model('ceshi_model');
        $this->site_id = $this->site_info['id'];
    }

    //测试列表
    public function index()
    {
        $where = array();
        $where['site_id'] = $this->site_info['id'];

        $total_rows = $this->ceshi_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>10));

        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $ceshiList = array();
        if($total_rows >0)
        {
            $ceshiList = $this->ceshi_model->order_by('id desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->where($where)->find_all();
        }
        $this->data['list'] = $ceshiList;
        $this->data['viewUrl'] = $this->create_url('/');

        $this->load->view($this->dcm,$this->data);
    }
    //添加一个新测试
    public function add()
    {
        $post = $this->input->post();
        if($post)
        {
            $dataSet = $this->dataPost($post);
            if(is_array($dataSet))
            {
                $dataSet['site_id'] = $this->site_id;
                $dataSet['inputtime'] = time();

                if( !$id=$this->ceshi_model->add($dataSet) )
                {
                    $this->show_message(false, '添加失败', ''); return FALSE;
                }
                else
                {
                    $this->show_message(true, '添加成功', '/c/ceshi');return FALSE;
                }
            }
            else
            {
                $this->show_message(false,$dataSet,'');return false;
            }
        }
        else
        {
            $this->load->view($this->dcm,$this->data);
        }
    }

    //编辑测试
    public function edit($id = '')
    {
        $ceshi = $this->getOneCeshi($id);
        $post = $this->input->post();
        if ($post)
        {
            $postData = $this->dataPost($post);
            if(!is_array($postData))
            {
                $this->show_message(false,$postData,'');
                return false;
            }

            if(false === $this->ceshi_model->where(array('id'=>$id, 'site_id'=>$this->site_id))->edit( $postData ) )
            {
                $this->show_message(false, '编辑失败', '/c/ceshi/edit/'.$id);
            }
            else
            {
                $this->show_message(false, '编辑成功', '/c/ceshi/edit/'.$id);
            }

        }
        else
        {
            $this->data['ceshi'] = $ceshi;
            $this->load->view($this->dcm,$this->data);
        }
    }

    //设置状态
    public function setStatus($id = '')
    {
        $ceshi = $this->getOneCeshi($id);
        $setData['status'] = ($ceshi['status'] == -1) ? 0 : -1;
        if($this->ceshi_model->where(array('id'=>$id))->edit($setData))
        {
            $this->show_message(true, '设置成功', '/c/ceshi');
        }
        else
        {
            $this->show_message(false, '设置失败', '/c/ceshi');
        }
    }

    //选项设置
    public function options($id = '')
    {
        $ceshi = $this->getOneCeshi($id);
        $this->load->model('ceshi_options_model');
        $where = array('site_id'=>$this->site_id,'cid'=>$ceshi['id']);

        $total_rows = $this->ceshi_options_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>5));

        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $options = array();
        if($total_rows >0)
        {
            $options = $this->ceshi_options_model->where($where)->limit($pager['limit']['value'], $pager['limit']['offset'])->find_all();
        }
        $this->data['ceshi'] = $ceshi;
        $this->data['options'] = $options;
        $this->load->view($this->dcm,$this->data);
    }

    //添加选项
    public function op_add()
    {
        $cid = $this->input->get('cid');
        $ceshi = $this->getOneCeshi($cid);
        $optionPost = $this->input->post();
        if($optionPost)
        {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('name', '选项名称', 'trim|required|max_length[100]');
            $this->form_validation->set_rules('pic', '选项图片', 'trim');
            $this->form_validation->set_rules('description', '选项描述', 'trim|max_length[400]');

            if ( $this->form_validation->run() )
            {
                $dataSet['name'] = $this->form_validation->set_value('name');
                //图片
                $dataSet['pic'] = $this->form_validation->set_value('pic');
                $dataSet['description'] = $this->form_validation->set_value('description');
                $dataSet['site_id'] = $this->site_id;
                $dataSet['cid'] = $cid;
                $this->load->model('ceshi_options_model');
                if($this->ceshi_options_model->add($dataSet))
                {
                    $this->show_message(true, '添加成功', '/c/ceshi/options/'.$cid);return false;
                }
                else
                {
                    $this->show_message(false, '添加失败', '');return false;
                }
            }
            else
            {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(false, $errors, '');return false;
                }
            }
        }
        else
        {
            $this->data['ceshi'] = $ceshi;
            $this->load->view($this->dcm,$this->data);
        }
    }

    //编辑选项
    public function op_edit($id = '')
    {
        $this->load->model('ceshi_options_model');
        $options = $this->ceshi_options_model->where(array('site_id'=>$this->site_id,'id'=>$id))->find();
        if(!$options)
        {
            $this->show_message(false, '该选项不存在', '');return false;
        }
        $ceshi = $this->getOneCeshi($options['cid']);
        $optionPost = $this->input->post();
        if($optionPost)
        {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('name', '选项名称', 'trim|required|max_length[100]');
            $this->form_validation->set_rules('pic', '选项图片', 'trim');
            $this->form_validation->set_rules('description', '选项描述', 'trim|max_length[400]');

            if ( $this->form_validation->run() )
            {
                $dataSet['name'] = $this->form_validation->set_value('name');
                //图片
                $dataSet['pic'] = $this->form_validation->set_value('pic');
                $dataSet['description'] = $this->form_validation->set_value('description');

                if($this->ceshi_options_model->where(array('site_id'=>$this->site_id,'id'=>$id))->edit($dataSet))
                {
                    $this->show_message(true, '编辑成功', '/c/ceshi/options/'.$ceshi['id']);return false;
                }
                else
                {
                    $this->show_message(false, '编辑失败', '');return false;
                }
            }
            else
            {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(false, $errors, '');return false;
                }
            }
        }
        else
        {
            $this->data['ceshi'] = $ceshi;
            $this->data['options'] = $options;
            $this->load->view($this->dcm,$this->data);
        }
    }

    //删除一个测试选项
    public function op_del($id = '')
    {
        $this->load->model('ceshi_options_model');
        $options = $this->ceshi_options_model->where(array('site_id'=>$this->site_id,'id'=>$id))->find();
        if(!$options)
        {
            $this->show_message(false, '该选项不存在', '');return false;
        }
        if($this->ceshi_options_model->where(array('id'=>$id))->delete())
        {
            $this->show_message(true, '删除成功', '/c/ceshi/options/'.$options['cid']);return false;
        }
        else
        {
            $this->show_message(false, '删除失败','/c/ceshi/options/'.$options['cid']);return false;
        }
    }
    //测试统计
    public function tongji($id = '')
    {
        $ceshi = $this->getOneCeshi($id);
        $this->data['ceshi'] = $ceshi;

        $this->load->model('ceshi_record_model');
        $where = array('site_id'=>$this->site_id,'cid'=>$ceshi['id']);

        $total_rows = $this->ceshi_record_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15));

        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $list = array();
        if($total_rows >0)
        {
            $this->load->model('ceshi_options_model');
            $options = $this->ceshi_options_model->where(array('site_id'=>$this->site_id,'cid'=>$ceshi['id']))->find_all();
            $optionList = array();
            foreach($options as $_option)
            {
                $optionList[$_option['id']] = $_option;
            }
            $list = $this->ceshi_record_model->where($where)->limit($pager['limit']['value'], $pager['limit']['offset'])->order_by('id desc')->find_all();
            foreach($list as &$_list)
            {
                $_list['result'] = str_replace(array("#姓名#","#选项名称#"),array($_list['name'],$optionList[$_list['op_id']]['name']),$ceshi['intro']);
            }
        }
        $this->data['list'] = $list;
        $this->load->view($this->dcm,$this->data);
    }
    //测试导出

    /**
     * 取一个测试详情
     * @param string $id
     * @return bool
     */
    private function getOneCeshi($id='')
    {
        if(!$id)
        {
            $this->show_message(false, '非法参数', '');return false;
        }
        $ceshi = $this->ceshi_model->where(array('id'=>$id,'site_id'=>$this->site_id))->find();
        if(!$ceshi)
        {
            $this->show_message(false, '不存在该测试', '');return false;
        }
        else
        {
            return $ceshi;
        }
    }
    /**
     * 处理测试post请求
     */
    private function dataPost($post)
    {
        if(is_array($post))
        {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('title', '测试名称', 'trim|required|max_length[100]');
            $this->form_validation->set_rules('pic', '背景图片', 'trim');
            $this->form_validation->set_rules('intro', '介绍语', 'trim|required|max_length[40]');
            if ( $this->form_validation->run() )
            {
                $dataSet['title'] = $this->form_validation->set_value('title');
                //图片
                $dataSet['pic'] = $this->form_validation->set_value('pic');
                $dataSet['intro'] = $this->form_validation->set_value('intro');
                return $dataSet;
            }
            else
            {
                $errors = validation_errors();

                if ($errors) {
                    return $errors;
                }
            }
        }
    }
} 