<?php
/**
 * Created by PhpStorm.
 * User: lufee(ldw1007@sina.cn)
 * Date: 14-8-18
 * Time: 下午3:04
 */

class Chief extends C_Controller
{
    protected $auto_load_model = TRUE;
    protected $model_name = 'chief';
    public function __construct()
    {
        parent::__construct();
        $this->load->model('chief_model');
        $this->site_id = $this->site_info['id'];

        $token_data = array('user_id' => logged_user_id(), 'time' => time());
        $this->data['token'] = $this->encrypt->encode(serialize($token_data));
    }

    public function index()
    {
        $where = array('site_id'=>$this->site_id,'status'=>0);
        //$like = array();
        $total_rows = $this->model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15));

        $list = $this->chief_model->order_by('id desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->where($where)->find_all();
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->data['prew_url'] = $this->site_info['all_domain'] ? $this->site_info['all_domain'] : 'http://'.$this->site_info['domain'].BASE_DOMAIN;
        $this->load->view($this->dcm, $this->data);
    }

    public function add()
    {
        $post = $this->input->post();
        if($post)
        {
            $postData = $this->dataPost($post);
            if(!is_array($postData))
            {
                $this->show_message(false,$postData,'/c/chief/add');
                return false;
            }
            $postData['site_id'] = $this->site_id;
            $postData['dt_add'] = $postData['dt_update'] = time();
            if( !$id=$this->model->add($postData) )
            {
                $this->show_message(false, '添加失败', '');
                return FALSE;
            }
            else
            {
                //添加评价项
                if($postData['is_appraise'] == 1)
                {
                    $this->load->model('chief_appraise_model');
                    $appraise_content = $this->input->post('appraise_content');
                    $appraise_listorder = $this->input->post('appraise_listorder');
                    if($appraise_content)
                    {
                        $data = array();
                        foreach($appraise_content as $k=>$v)
                        {
                            $data = array(
                                'chief_id'=>$id,
                                'name'=>$v,
                                'listorder'=>$appraise_listorder[$k]
                            );
                            $this->chief_appraise_model->add($data);
                        }
                    }
                }

                $this->show_message(true, '添加成功', '/c/chief');
                return FALSE;
            }
        }
        else
        {
            $this->load->view($this->dcm,$this->data);
        }
    }


    public function edit($id)
    {
        $chief = $this->getOneChief($id);
        //print_r($comments);exit;
        if(!is_array($chief))
        {
            $this->show_message(false,$chief,'/c/chief/edit/'.$id);
            return false;
        }
        $this->load->model('chief_appraise_model');
        $post = $this->input->post();
        if ($post)
        {
            $postData = $this->dataPost($post);
            if(!is_array($postData))
            {
                $this->show_message(false,$postData,'/c/chief/edit/'.$id);
                return false;
            }
            if(false === $this->model->where(array('id'=>$id, 'site_id'=>$this->site_id))->edit( $postData ) )
            {
                $this->show_message(false, '编辑政务失败', '/c/chief/edit/'.$id);
            }
            else
            {
                //修改评价项
                if($postData['is_appraise'] == 1)
                {
                    $appraise_content = $this->input->post('appraise_content');
                    $appraise_listorder = $this->input->post('appraise_listorder');
                    if($appraise_content)
                    {
                        $this->chief_appraise_model->where(array('chief_id'=>$id))->delete();
                        $data = array();
                        foreach($appraise_content as $k=>$v)
                        {
                            $data = array(
                                'chief_id'=>$id,
                                'name'=>$v,
                                'listorder'=>$appraise_listorder[$k]
                            );
                            $this->chief_appraise_model->add($data);
                        }
                    }
                }
                $this->show_message(false, '编辑政务成功', '/c/chief/edit/'.$id);
            }

        }
        else
        {
            $appraise = $this->chief_appraise_model->where(array('chief_id'=>$id))->order_by('listorder asc')->find_all();
            $chief['appraise_content'] = $appraise;
            $nav = json_decode($chief['nav'],true);
            foreach($nav as $v)
            {
                if($v['type'] == 1)
                {
                    $chief['nav_list_title'] = $v['title'];
                    $chief['nav_list_img'] = $v['img'];
                }elseif($v['type'] == 2)
                {
                    $chief['nav_publish_title'] = $v['title'];
                    $chief['nav_publish_img'] = $v['img'];
                }elseif($v['type'] == 3)
                {
                    $chief['nav_search_title'] = $v['title'];
                    $chief['nav_search_img'] = $v['img'];
                }
            }
            $this->data['chief'] = $chief;
            $this->load->view($this->dcm,$this->data);
        }
    }


    /**
     * 处理政务post请求
     */
    private function dataPost($post)
    {
        if(is_array($post))
        {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('title', '标题', 'trim|required|max_length[200]|htmlspecialchars');
            $this->form_validation->set_rules('nav_list', '手机页面的按钮', 'trim|required|max_length[4]');
            $this->form_validation->set_rules('nav_publish', '手机页面的按钮', 'trim|required|max_length[4]');
            $this->form_validation->set_rules('nav_search', '手机页面的按钮', 'trim|required|max_length[4]');
            //$this->form_validation->set_rules('img_url', '首页大图', 'trim|callback__check_image');

            if ( $this->form_validation->run() )
            {
                $dataSet['title'] = $this->form_validation->set_value('title');
                $nav = array(
                    0=>array(
                        'title'=>$this->form_validation->set_value('nav_list'),
                        'img'=>$this->input->post('nav_list_img'),
                        'type'=>1
                    ),
                    1=>array(
                        'title'=>$this->form_validation->set_value('nav_publish'),
                        'img'=>$this->input->post('nav_publish_img'),
                        'type'=>2
                    ),
                    2=>array(
                        'title'=>$this->form_validation->set_value('nav_search'),
                        'img'=>$this->input->post('nav_search_img'),
                        'type'=>3
                    )
                );
                $dataSet['nav'] = json_encode($nav);
                //$dataSet['img_url'] = $this->form_validation->set_value('img_url');
                $dataSet['img_url'] = $this->input->post('img_url');
                $dataSet['enable'] = $this->input->post('enable');
                $dataSet['is_open'] = $this->input->post('is_open');
                $dataSet['verify_mobile'] = $this->input->post('verify_mobile');
                $dataSet['is_appraise'] = $this->input->post('is_appraise');
                $dataSet['tips'] = htmlspecialchars($this->input->post('tips'));
                $dataSet['description'] = htmlspecialchars($this->input->post('description'));
                $dataSet['template'] = $this->input->post('template');
                $dataSet['microhelper'] = $this->input->post('microhelper');
                return $dataSet;
            }
            else
            {
                $errors = validation_errors();
                if ($errors) {
                    return $errors;
                }
            }
        }
        return false;
    }

    //检查图片格式
    public function _check_image($image) {
        if ($image) {
            if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
                $this->form_validation->set_message('_check_image', '图片地址格式错误');
                return FALSE;
            }
        }
        return TRUE;
    }

    /**
     * 获取一条政务
     * @param $id
     * @return string
     */
    private function getOneChief($id)
    {
        if(!$id)
        {
            return '非法参数';
        }
        $chief = $this->model->where(array('id'=>$id,'site_id'=>$this->site_id))->find();
        if(!$chief)
        {
            return '该政务不存在';
        }
        else
        {
            return $chief;
        }
    }


    /**
     * @param $id
     * 删除政务，删除留言，删除评价，删除回复
     *
     */
    public function delchief($id)
    {
        if(!$id)
        {
            return '非法参数';
        }
        if($this->model->where(array('id'=>$id))->edit(array('status'=>1)))
        {
            $this->show_message(false, '删除政务成功', '/c/chief');
        }else{
            $this->show_message(false, '删除政务失败', '/c/chief');
        }
    }
}