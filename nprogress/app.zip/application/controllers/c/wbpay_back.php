<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 微巴支付 配置接口
 */
class Wbpay extends C_Controller
{
    
    private $site_id = '';
    protected $data = array();
    
    protected $app_key = '5318162aac6f8745';
    protected $app_secret = '0c28536510e0b0b929750f878222d549';
    
    /**
     * 516793d2cfc3b083
     * zklun
     * 100025
     * 780d98c53bac698b836175649256186a
     */
    
    public function __construct()
    {
        parent::__construct();
        $this->site_id = $this->site_info['id'];
        
        //TODO  CASHIER_URL
        $server = 'http://cashier.69juzi.com/api/';
        //支付系统接口
        $this->load->library('rest', array(
            'server' => CASHIER_URL,
            'app_key' => $this->app_key,
            'secret_key' => $this->app_secret,
        ), 'cashier_rest');
        
        $this->load->model('user_partner_model');
        
        $this->data['has_config'] = 0;//本地是否存在商户配置
        $this->check_open();
        if( isset($this->data['partner_info'])&&$this->data['partner_info'] ){
            $this->data['has_config'] = 1;
        }
    }
	public function index(){
	    
	    if( $this->data['has_config'] ){//存在配置
	        $partner_id = $this->data['partner_info']['partner_id'];
	        $result = $this->cashier_rest->get('payment/builtins',array('partner_id'=>$partner_id));
            if( $this->cashier_rest->status()==200 ){
                $this->data['list'] = $result;
            }else{
                $this->data['list'] = array();
            }
	    }
		$this->load->view($this->dcm,$this->data);

	}
	
	//微巴支付记录
	public function log() 
	{
	    
		$this->load->model('pay_log_model');
		$search_url = site_url($this->uri->uri_string().'?');
		$where = array('site_id'=>$this->site_id);
		$total_rows = $this->pay_log_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$search_url));
		
		$list = $this->pay_log_model
		        ->limit($pager['limit']['value'], $pager['limit']['offset'])
                ->order_by('id desc')->where($where)->find_all();
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
		$this->data['list'] = $list;
		
		$this->load->view($this->dcm,$this->data);
	}	
	//开通商户
	public function open(){
		if( $this->input->post()){
			$partner_name = $this->input->get_post('partner_name',true);
			$res = $this->user_partner_model->where(array('site_id'=>$this->site_id))->find();
		    if($res){
        		return $this->show_message(false, '此商户已经开通过微巴支付');
        	}
		    if( !$partner_name ){
            	return $this->show_message(false, '请填写商户名称');
        	}
		   	$result = $this->cashier_rest->post('partner', array('name'=>$partner_name));
	        if( $this->cashier_rest->status()==201 ){
	            $save_data = array(
	                'site_id' => $this->site_id,
	                'partner_id' => $result['id'],
	                'partner_name' => $result['name'],
	                'partner_key' => $result['partner_key']
	            );
	            $this->user_partner_model->add($save_data);
	        }
	        redirect('/c/wbpay/index');
		}
		$this->load->view($this->dcm,$this->data);
	}
    
    //配置商户信息  正确则保存 OK
    public function config_partner()
    {
        if( $this->input->post() ){
            $this->form_validation->set_rules('partner_id', '商户号', 'trim|required|numeric|max_length[9]');
            $this->form_validation->set_rules('partner_key', '商户密钥', 'trim|required|max_length[64]');
            if( $this->form_validation->run() ){
                $partner_id = $this->form_validation->set_value('partner_id');
                $partner_key = $this->form_validation->set_value('partner_key');
                $result = $this->cashier_rest->get('partner',array('partner_id'=>$partner_id, 'partner_key'=>$partner_key));
                if( $this->cashier_rest->status()==200 ){
                    //保存信息
                    if( $this->data['has_config'] ){
                        if( ($this->data['partner_info']['partner_id']!=$result['id'])||($this->data['partner_info']['partner_name']!=$result['name'])||($this->data['partner_info']['partner_key']!=$result['partner_key']) ){
                            $save_data = array(
                                'site_id' => $this->site_id,
                                'partner_id' => $result['id'],
                                'partner_name' => $result['name'],
                                'partner_key' => $result['partner_key']
                            );
                            if( $this->user_partner_model->where(array('id'=>$this->data['partner_info']['id']))->edit($save_data) ){
                                redirect('/c/wbpay/index');
                            }else{
                                return $this->show_message(FALSE, '配置商户信息失败', '');
                            }
                        }
                    }else{
                        $save_data = array(
                            'site_id' => $this->site_id,
                            'partner_id' => $result['id'],
                            'partner_name' => $result['name'],
                            'partner_key' => $result['partner_key']
                        );
                        $this->user_partner_model->add($save_data);
                        redirect('/c/wbpay/index');
                    }
                }else{
                    return $this->show_message(FALSE, '没有找到该商户信息', '');
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    return $this->show_message(FALSE, $errors, '');
                }
            }
        }else{
            $this->load->view($this->dcm,$this->data);
        }
    }
    
    //配置单个支付  安装 修改
    public function config_pay($code='')
    {
        !$code && redirect('/c/wbpay/index');
        $pay_info = $this->get_single_pay($code);
        
        if( $this->input->post() ){
            $save_data['code'] = $code;
            $save_data['name'] = $this->input->post('name');
            $save_data['enabled'] = $this->input->post('enabled');
            $save_data['is_sys'] = intval($this->input->post('is_sys'));
            $save_data['listorder'] = intval($this->input->post('listorder'));
            $save_data['config'] = '';
            $temp_config = $this->input->post('config');
            if( $temp_config ){
                $temp = array();
                foreach( $temp_config as $key=>$val ){
                    $temp[] = $key.','.$val;
                }
                $save_data['config'] = implode(';', $temp);
            }
            $save_data['partner_id'] = $this->data['partner_info']['partner_id'];
            if( isset($pay_info['config']) ){
                $save_data['id'] = $pay_info['id'];
                $result = $this->cashier_rest->put('payment', $save_data );
            }else{
                //安装支付
                $result = $this->cashier_rest->post('payment', $save_data );
            }
            if( $this->cashier_rest->status()==201 ){
                redirect('/c/wbpay/index');
            }else{
                return $this->show_message(FALSE, 'Insufficient Permissions', '/c/wbpay/index');
            }
        }else{            
            $this->data['info'] = $pay_info;
            //var_dump($pay_info);
            $this->load->view($this->dcm,$this->data);
        }
    }
    
    //卸载支付配置
    public function uninstall_pay($id='')
    {
        !$id && redirect('/c/wbpay/index');
        $resp = $this->cashier_rest->delete('payment/'.$id, array('partner_id'=>$this->data['partner_info']['partner_id']));
        if ($this->cashier_rest->status() == 200) {
            redirect('/c/wbpay/index');
        } else {
            return $this->show_message(FALSE, '卸载失败', '');
        }
    }
    
    //获取单个支付信息
    private function get_single_pay($code='')
    {
        if( $this->data['has_config'] ){
            $partner_id = $this->data['partner_info']['partner_id'];
            $result = $this->cashier_rest->get('payment/builtins',array('partner_id'=>$partner_id));
            if( $this->cashier_rest->status()==200 ){
                foreach( $result as $val ){
                    if( $val['code']==$code ){
                        return $val;
                        break;
                    }
                }
            }
        }
        return false;   
    }
    
    //检测本地是否存在 已配置的商户信息 返回本地配置信息
    public function check_open()
    {
        $where['site_id'] = $this->site_id;
        $partner_info = $this->user_partner_model->where($where)->find();
        $this->data['partner_info'] = $partner_info;
    }
    
}
