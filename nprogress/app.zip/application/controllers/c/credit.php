<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Created by PhpStorm.
 * User: andery
 * Date: 13-12-4
 * Time: 上午11:41
 */

class Credit extends C_Controller {

    protected $auto_load_model = TRUE;
    protected $model_name = 'credit_record';
    protected $mongo_credit = 'credit';

    /**
     * 积分设置放在这里
     */
    public function index()
    {
        $this->load->library('Mongo_db');
        $credit_setting = $this->mongo_db->where(array('site_id'=>$this->site_info['id']))->get_one($this->mongo_credit);
        if($this->input->post()) {
            $data['on'] = $this->input->post('on');
            $data['instruction'] = $this->input->post('instruction');

            $money = $this->input->post('money') ? $this->input->post('money') : array();
            $credit = $this->input->post('credit') ? $this->input->post('credit') : array();
            $accumulate = $this->input->post('accumulate') ? $this->input->post('accumulate') : array();
            $data['consume_rules'] = array();
            foreach($money as $k=>$m) {
                if(!is_numeric($m) || $m <= 0){
                    $this->show_message(FALSE, '消费金额必须是正数', '/c/credit');
                    return FALSE;
                }
                if(!$this->form_validation->is_natural($credit[$k])){
                    $this->show_message(FALSE, '积分必须是正整数', '/c/credit');
                    return FALSE;
                }
                $item = array();
                $item['money'] = $m;
                $item['credit'] = $credit[$k];
                $item['accumulate'] = isset($accumulate[$k]) ? $accumulate[$k] : '0';
                $data['consume_rules'][] = $item;
            }

            $money2 = $this->input->post('money2') ? $this->input->post('money2') : array();
            $credit2 = $this->input->post('credit2') ? $this->input->post('credit2') : array();
            $accumulate2 = $this->input->post('accumulate2') ? $this->input->post('accumulate2') : array();
            $data['recharge_rules'] = array();
            foreach($money2 as $k=>$m) {
                if(!is_numeric($m) || $m <= 0){
                    $this->show_message(FALSE, '充值金额必须是正数', '/c/credit');
                    return FALSE;
                }
                if(!$this->form_validation->is_natural($credit2[$k])){
                    $this->show_message(FALSE, '积分必须是正整数', '/c/credit');
                    return FALSE;
                }
                $item = array();
                $item['money'] = $m;
                $item['credit'] = $credit2[$k];
                $item['accumulate'] = isset($accumulate2[$k]) ? $accumulate2[$k] : '0';
                $data['recharge_rules'][] = $item;
            }

            $money3 = $this->input->post('money3') ? $this->input->post('money3') : array();
            $credit3 = $this->input->post('credit3') ? $this->input->post('credit3') : array();
            $accumulate3 = $this->input->post('accumulate3') ? $this->input->post('accumulate3') : array();
            $data['cash_consume_rules'] = array();
            foreach($money3 as $k=>$m) {
                if(!is_numeric($m) || $m <= 0){
                    $this->show_message(FALSE, '消费金额必须是正数', '/c/credit');
                    return FALSE;
                }
                if(!$this->form_validation->is_natural($credit3[$k])){
                    $this->show_message(FALSE, '积分必须是正整数', '/c/credit');
                    return FALSE;
                }
                $item = array();
                $item['money'] = $m;
                $item['credit'] = $credit3[$k];
                $item['accumulate'] = isset($accumulate3[$k]) ? $accumulate3[$k] : '0';
                $data['cash_consume_rules'][] = $item;
            }

            if($credit_setting) { //更新
                if($this->mongo_db->where(array('site_id'=>$this->site_info['id']))->set($data)->update($this->mongo_credit)) {
                    $this->show_message(TRUE, '保存成功', '/c/credit');
                    return FALSE;
                } else {
                    $this->show_message(FALSE, '保存失败', '/c/credit');
                    return FALSE;
                }
            } else { //添加
                $data['site_id'] = $this->site_info['id'];
                if($this->mongo_db->insert($this->mongo_credit, $data)) {
                    $this->show_message(TRUE, '保存成功', '/c/credit');
                    return FALSE;
                } else {
                    $this->show_message(FALSE, '保存失败', '/c/credit');
                    return FALSE;
                }
            }
        } else {
            $this->data['credit'] = $credit_setting;
            $this->load->view($this->dcm, $this->data);
        }
    }

    /**
     * 积分记录
     */
    public function record($mid = 0)
    {
        $where = array();
        $like = array();
        ($username = $this->input->get('username')) && $like['username'] = $username;
        ($credit = $this->input->get('credit')) && $like['credit'] = $credit;
        ($from_time = $this->input->get('from_time')) && $where['dt_record >='] = strtotime($from_time);
        ($to_time = $this->input->get('to_time')) && $where['dt_record <='] = strtotime($to_time);

        $where['site_id'] = $this->site_info['id'];
        $mid && $where['mid'] = $mid;
        $total_rows = $this->model->where($where)->like($like)->count();
        $pager = $this->_pager($total_rows, array(
            'base_url' => site_url($this->uri->uri_string().'?').$_SERVER['QUERY_STRING']
        ));
        $list = $this->model->order_by('dt_record desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->where($where)->like($like)->find_all();

        $this->data['search'] = $this->input->get();
        $mid && ($this->data['mid'] = $mid);
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->load->view($this->dcm, $this->data);
    }

    public function export()
    {
        $where = array();
        $like = array();
        ($username = $this->input->get('username')) && $like['username'] = $username;
        ($credit = $this->input->get('credit')) && $like['credit'] = $credit;
        ($from_time = $this->input->get('from_time')) && $where['dt_record >='] = strtotime($from_time);
        ($to_time = $this->input->get('to_time')) && $where['dt_record <='] = strtotime($to_time);

        $where['site_id'] = $this->site_info['id'];
        $list = $this->model->order_by('dt_record desc')->where($where)->like($like)->find_all();
        $clist = array();
        if($list)
        {
            foreach($list as $key=> $item)
            {
                $clist[$key]['dt_record'] = date('Y-m-d H:i:s', $item['dt_record']);
                $clist[$key]['username'] = $item['username'];
                $clist[$key]['credit'] = $item['credit'];
                $clist[$key]['remark'] = $item['remark'];
            }

            $fields = array(
                '#'=>'#',
                'dt_record'=>'时间',
                'username'=>'用户名',
                'credit'=>'积分',
                'remark'=>'说明'
            );
            $this->excel_export('积分记录列表', '积分记录列表', $fields, $clist);
        }
        else
        {
            $this->show_message(FALSE, '尚无积分记录可导出', '/c/credit/record');
        }
    }
}