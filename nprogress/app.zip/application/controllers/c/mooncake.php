<?php
/**
 * Created by PhpStorm.
 * User: lufee(ldw1007@sina.cn)
 * Date: 14-8-25
 * Time: 上午11:35
 */

class Mooncake extends C_Controller
{
    protected $auto_load_model = TRUE;
    public function __construct()
    {
        parent::__construct();
        $this->site_id = $this->site_info['id'];
        $token_data = array('user_id' => logged_user_id(), 'time' => time());
        $this->data['token'] = $this->encrypt->encode(serialize($token_data));
    }

    public function index()
    {
        $where = array('site_id'=>$this->site_id,'status'=>0);
        //$like = array();
        $total_rows = $this->model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15));

        $list = $this->model->order_by('id desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->where($where)->find_all();
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->data['prew_url'] = $this->site_info['all_domain'] ? $this->site_info['all_domain'] : 'http://'.$this->site_info['domain'].BASE_DOMAIN;
        $this->load->view($this->dcm, $this->data);
    }

    public function add()
    {
        $post = $this->input->post();
        if($post)
        {
            $postData = $this->dataPost($post);
            if(!is_array($postData))
            {
                $this->show_message(false,$postData,'/c/mooncake/add');
                return false;
            }
            $postData['site_id'] = $this->site_id;
            $postData['dt_add'] = time();
            $postData['status'] = 0;
            if( !$id=$this->model->add($postData) )
            {
                $this->show_message(false, '添加失败', '');
                return FALSE;
            }
            else
            {
                $this->show_message(true, '添加成功', '/c/mooncake');
                return FALSE;
            }
        }
        else
        {
            $token_data = array('user_id' => logged_user_id(), 'time' => time());
            $this->data['token'] = $this->encrypt->encode(serialize($token_data));
            $this->data['auto_attention'] = $this->site_info['auto_attention'];
            $this->load->view($this->dcm,$this->data);
        }
    }

    public function edit($id)
    {
        $mooncake = $this->getOneMooncake($id);
        //print_r($comments);exit;
        if(!is_array($mooncake))
        {
            $this->show_message(false,$mooncake,'/c/mooncake/edit/'.$id);
            return false;
        }
        $post = $this->input->post();
        if ($post)
        {
            $postData = $this->dataPost($post);
            if(!is_array($postData))
            {
                $this->show_message(false,$postData,'/c/mooncake/edit/'.$id);
                return false;
            }
            if(false === $this->model->where(array('id'=>$id, 'site_id'=>$this->site_id))->edit( $postData ) )
            {
                $this->show_message(false, '编辑失败', '/c/mooncake/edit/'.$id);
            }
            else
            {
                //更新每人游戏次数
                if($postData['cgame'] > 0 && $postData['cgame'] != $mooncake['cgame'])
                {
                    $this->load->model('mooncake_member_model');
                    $this->mooncake_member_model->where(array('mooncake_id'=>$id))->set_inc('cgame',null,$postData['cgame']);
                }
                $this->show_message(false, '编辑成功', '/c/mooncake/edit/'.$id);
            }
        }
        else
        {
            $mooncake['start_time'] = date('Y-m-d H:i:s',$mooncake['start_time']);
            $mooncake['end_time'] = date('Y-m-d H:i:s',$mooncake['end_time']);
            if($mooncake['cgame'] == -1 && $mooncake['cshare'] == -1)
            {
                $mooncake['prechance'] = 0;
            }else{
                $mooncake['prechance'] = 1;
            }
            $token_data = array('user_id' => logged_user_id(), 'time' => time());
            $this->data['token'] = $this->encrypt->encode(serialize($token_data));
            $this->data['mooncake'] = $mooncake;
            $this->load->view($this->dcm,$this->data);
        }
    }

    public function del($id)
    {
        if(!$id)
        {
            $this->show_message(false, '非法参数', '/c/mooncake');
        }
        if($this->model->where(array('id'=>$id))->edit(array('status'=>1)))
        {
            $this->show_message(false, '删除成功', '/c/mooncake');
        }else{
            $this->show_message(false, '删除失败', '/c/mooncake');
        }
    }

    public function rank($id)
    {
        if(!$id)
        {
            $this->show_message(false, '非法参数', '/c/mooncake');
        }
        $mooncake = $this->model->where(array('site_id'=>$this->site_id,'id'=>$id))->find();
        if(!$mooncake)
        {
            $this->show_message(false, '该游戏不存在', '/c/mooncake');
        }
        $this->load->model('mooncake_member_model');

        $searchUrl = '/c/mooncake/rank/'.$id.'/?';
        $where = "mooncake_id = ".$id." and name != '' and mobile != ''";
        $keyword = $this->input->get('keyword');
        if($keyword)
        {
            $this->data['search'] = array('keyword'=>$keyword);
            $where .= " and (name like '%".$keyword."%' or mobile like '%".$keyword."%') ";
            $searchUrl .= 'keyword='.$keyword;
        }

        $total_rows = $this->mooncake_member_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15));

        $list = $this->mooncake_member_model->order_by('highscore desc,id desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->where($where)->find_all();
        $this->data['list'] = $list;
        $this->data['mooncake'] = $mooncake;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->data['total_rows'] = $total_rows;
        $this->data['prew_url'] = $this->site_info['all_domain'] ? $this->site_info['all_domain'] : 'http://'.$this->site_info['domain'].BASE_DOMAIN;
        $this->load->view($this->dcm,$this->data);
    }

    public function export()
    {
        $this->load->model('mooncake_member_model');
        $where = "";
        $keyword = $this->input->get('keyword');
        if($keyword)
        {
            $this->data['search'] = array('keyword'=>$keyword);
            $where .= " and (name like '%".$keyword."%' or mobile like '%".$keyword."%')";
        }
        $id = $this->input->get('id');
        $mooncake = $this->model->where(array('site_id' => $this->site_id,'id'=>$id))->find();
        if(!$mooncake)
        {
            $this->show_message(false,'暂无数据可以导出','');return false;
        }
        $where .= " mooncake_id = ".$mooncake['id']." and name != '' and mobile !=''";

        $list = $this->mooncake_member_model->where($where)->order_by('id desc')->find_all();
        $memberList = array();
        if($list)
        {
            foreach($list as $key=> $item)
            {
                $memberList[$key]['name'] = $item['name'];
                $memberList[$key]['mobile'] = $item['mobile'];
                $memberList[$key]['highscore'] = $item['highscore'];
            }

            $fields = array(
                '#'=>'#',
                'name'=>'姓名',
                'mobile'=>'电话',
                'highscore'=>'战绩'
            );
            $this->excel_export('游戏数据统计', '游戏数据统计', $fields, $memberList);
        }
        else
        {
            $this->show_message(false,'暂无数据可以导出','');
        }
    }

    /**
     * 处理post请求
     */
    private function dataPost($post)
    {
        if(is_array($post))
        {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('title', '标题', 'trim|required|max_length[30]|htmlspecialchars');
            $this->form_validation->set_rules('cgame', '每天每人机会次数', 'numeric');
            $this->form_validation->set_rules('cshare', '分享机会次数', 'numeric');
            $this->form_validation->set_rules('cvirtual', '虚拟人数', 'numeric');
            $this->form_validation->set_rules('start_time', '开始时间', 'required');
            $this->form_validation->set_rules('end_time', '结束时间', 'required');

            if ( $this->form_validation->run() )
            {
                $dataSet['title'] = $this->form_validation->set_value('title');
                //$dataSet['start_time'] = strtotime($this->input->post('start_time'));
                //$dataSet['end_time'] = strtotime($this->input->post('end_time'));
                //$dataSet['cvirtual'] = $this->input->post('cvirtual');
                $dataSet['start_time'] = strtotime($this->form_validation->set_value('start_time'));
                $dataSet['end_time'] = strtotime($this->form_validation->set_value('end_time'));
                $dataSet['cvirtual'] = $this->form_validation->set_value('cvirtual');
                $dataSet['concern'] = $this->input->post('concern');
                if($dataSet['concern'] != '')
                {
                    $dataSet['concern'] = substr($dataSet['concern'],0,7) != 'http://' ? 'http://'.$dataSet['concern'] : $this->input->post('concern');
                }else{
                    $dataSet['concern'] = $this->site_info['auto_attention'];
                }
                $dataSet['share_title'] = $this->input->post('share_title');
                $dataSet['share_desc'] = $this->input->post('share_desc');
                $dataSet['share_img'] = $this->input->post('share_img');
                if($this->input->post('prechance') == 1)
                {
                    //$dataSet['cgame'] = $this->input->post('cgame');
                    //$dataSet['cshare'] = $this->input->post('cshare');
                    $dataSet['cgame'] = $this->form_validation->set_value('cgame');
                    $dataSet['cshare'] = $this->form_validation->set_value('cshare');
                }else{
                    $dataSet['cgame'] = -1;
                    $dataSet['cshare'] = -1;
                }
                $dataSet['is_rank'] = $this->input->post('is_rank');
                $dataSet['intro'] = htmlspecialchars($this->input->post('intro'));
                $dataSet['template'] = $this->input->post('template');
                return $dataSet;
            }
            else
            {
                $errors = validation_errors();
                if ($errors) {
                    return $errors;
                }
            }
        }
        return false;
    }

    /**
     * 获取一条数据
     * @param $id
     * @return string
     */
    private function getOneMooncake($id)
    {
        if(!$id)
        {
            return '非法参数';
        }
        $chief = $this->model->where(array('id'=>$id,'site_id'=>$this->site_id))->find();
        if(!$chief)
        {
            return '该记录不存在';
        }
        else
        {
            return $chief;
        }
    }
}