<?php
/**
 * Created by PhpStorm.
 * User: 111
 * Date: 14-3-13
 * Time: 上午11:50
 * @property Model_app_config $model_app_config
 */

class Album extends C_Controller {

    protected $auto_load_model = TRUE;
    protected $model_name = 'album';
    protected $data = '';
    private $site_id = '';

    public function __construct()
    {
        parent::__construct();

        $this->site_id = $this->site_info['id'];
    }

    /**
     * 相册列表
     */
    public function index()
    {

        $where = array('site_id'=>$this->site_id);
        $search['keyword'] = $this->input->get('keyword');
        $search['keyword'] ? $where['title like '] = "%{$search['keyword']}%" : '';
        $search_url = site_url($this->uri->uri_string().'?');
        $base_url = $search_url.http_build_query($search);
        $this->data['search'] = $search;


        $list = array();
        $total = $this->model->where($where)->count();
        $pager = $this->_pager($total, array('per_page'=>15,'base_url'=>$base_url));
        $list = $this->model->where($where)->limit($pager['limit']['value'],$pager['limit']['offset'])->order_by('id', 'desc')->find_all();
        if( $list ){
            foreach( $list as &$val ){
                $val['viewurl'] = $this->create_url('xiangce/moban/?id='.$val['id']);
            }
        }
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->load->view($this->dcm, $this->data);
    }

    /**
     * 添加相册
     */
    public function add()
    {
        if( $this->input->post() ){
            $this->form_validation->set_rules('username', '用户名', 'trim|alpha|max_length[10]');
            $this->form_validation->set_rules('password', '密码', 'trim|max_length[7]');
            $this->form_validation->set_rules('title', '相册名称', 'trim|max_length[100]');
            $this->form_validation->set_rules('tpl', '相册模版', 'trim|max_length[30]');
            $this->form_validation->set_rules('share_title', '分享标题', 'trim|max_length[100]');
            $this->form_validation->set_rules('share_img', '分享图标', 'trim|max_length[255]|callback__check_image');
            $this->form_validation->set_rules('share_intro', '分享描述', 'trim|max_length[200]|htmlspecialchars');
            if ( $this->form_validation->run() ){
                $save_data['username'] = $this->form_validation->set_value('username');
                $save_data['password'] = $this->form_validation->set_value('password');
                $save_data['title'] = $this->form_validation->set_value('title');
                $save_data['tpl'] = $this->form_validation->set_value('tpl');
                $save_data['share_title'] = $this->form_validation->set_value('share_title');
                $save_data['share_img'] = $this->form_validation->set_value('share_img');
                $save_data['share_intro'] = $this->form_validation->set_value('share_intro');
                $music_is_sys = $this->input->post('music_is_sys');
                if( $music_is_sys ){
                    $save_data['music'] = $this->input->post('music_sys');
                }else{
                    $save_data['music'] = $this->input->post('music');
                }
                $save_data['music_is_sys'] = $music_is_sys ? 1 : 0;
                /*$photo = $this->input->post('photo');
                $save_data['photo'] = $photo ? json_encode($photo) : '';*/
                $save_data['dt_add'] = time();
                $save_data['site_id'] = $this->site_id;
                if($this->model->add($save_data))
                {
                    $this->show_message(true, '相册添加成功', '/c/album');return FALSE;
                }
                else
                {
                    $this->show_message(false, '相册添加失败');return FALSE;
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }
        else
        {
            $this->config->load('music');
            $this->data['musicList'] = $this->config->item('music');

            //获取模版
            $this->load->config('tpl');
            $config_tpl = $this->config->item('album_tpl');
            $this->data['album_tpl'] = $config_tpl;

            $this->load->view($this->dcm, $this->data);
        }
    }

    /**
     * @param $id
     * @return bool
     */
    public function edit($id)
    {
        $album = $this->getOneAlbum($id);
        if($album)
        {
            if($this->input->post())
            {
                $this->form_validation->set_rules('username', '用户名', 'trim|alpha|max_length[10]');
                $this->form_validation->set_rules('password', '密码', 'trim|max_length[7]');
                $this->form_validation->set_rules('title', '相册名称', 'trim|max_length[100]');
                $this->form_validation->set_rules('tpl', '相册模版', 'trim|max_length[30]');
                $this->form_validation->set_rules('share_title', '分享标题', 'trim|max_length[100]');
                $this->form_validation->set_rules('share_img', '分享图标', 'trim|max_length[255]|callback__check_image');
                $this->form_validation->set_rules('share_intro', '分享描述', 'trim|max_length[200]|htmlspecialchars');
                if ( $this->form_validation->run() ){
                    $save_data['username'] = $this->form_validation->set_value('username');
                    $save_data['password'] = $this->form_validation->set_value('password');
                    $save_data['title'] = $this->form_validation->set_value('title');
                    $save_data['tpl'] = $this->form_validation->set_value('tpl');
                    $save_data['share_title'] = $this->form_validation->set_value('share_title');
                    $save_data['share_img'] = $this->form_validation->set_value('share_img');
                    $save_data['share_intro'] = $this->form_validation->set_value('share_intro');
                    $music_is_sys = $this->input->post('music_is_sys');
                    if( $music_is_sys ){
                        $save_data['music'] = $this->input->post('music_sys');
                    }else{
                        $save_data['music'] = $this->input->post('music');
                    }
                    $save_data['music_is_sys'] = $music_is_sys ? 1 : 0;
                    /*$photo = $this->input->post('photo');
                    $save_data['photo'] = $photo ? json_encode($photo) : '';*/
                    $save_data['dt_update'] = time();
                    if($this->model->where(array('id'=>$id,'site_id'=>$this->site_id))->edit($save_data))
                    {
                        $this->show_message(true, '相册修改成功', '/c/album');return FALSE;
                    }
                    else
                    {
                        $this->show_message(false, '相册修改失败');return FALSE;
                    }
                }else{
                    $errors = validation_errors();
                    if ($errors) {
                        $this->show_message(FALSE, $errors, '');
                        return FALSE;
                    }
                }
            }
            else
            {
                if($album['photo'])
                {
                    $album['photo'] = json_decode($album['photo'],true);
                }
                $this->data['album'] = $album;
                $this->config->load('music');
                $this->data['musicList'] = $this->config->item('music');

                //获取模版
                $this->load->config('tpl');
                $config_tpl = $this->config->item('album_tpl');
                $this->data['album_tpl'] = $config_tpl;

                $this->load->view($this->dcm, $this->data);
            }
        }
        else
        {
            $this->show_message(FALSE, '相册不存在或已删除', '');
            return FALSE;
        }
    }

    public function delete($album_id)
    {
        $album= $this->model->where(array('id' => $album_id,'site_id'=>$this->site_id))->find();
        if ( ! $album) {
            $this->show_message(FALSE, '相册不存在或已删除', '');
            return FALSE;
        }

        if($this->model->where(array('id' => $album_id))->delete())
        {
            $this->show_message(false, '删除成功', '/c/album/index');return FALSE;
        }else{
            $this->show_message(false, '删除失败');return FALSE;
        }
    }


    public function unbind($album_id)
    {
        $album= $this->model->where(array('id' => $album_id,'site_id'=>$this->site_id))->find();
        if ( ! $album) {
            $this->show_message(FALSE, '相册不存在或已删除', '');
            return FALSE;
        }

        if($this->model->where(array('id' => $album_id))->edit(array('wxid'=>'')))
        {
            $this->show_message(false, '解除绑定成功');return FALSE;
        }else{
            $this->show_message(false, '解除绑定失败');return FALSE;
        }
    }

    public function set()
    {
        //获取相册配置
        $this->load->model('model_app_config');
        $albumSet = $this->model_app_config->get_row(array('user_id'=>$this->site_id, 'type'=>'album'));
        if($albumSet && $albumSet['config'])
        {
            $update = 1;
            $albumSet['config'] = json_decode($albumSet['config'],true);
        }
        else
        {
            //微网站信息
            $update = 0;
            $albumSet['coverpic'] = 'http://image.bama555.com/data/201408/30/dfd3af807cd2fc62edede7e78c65110e_480_240.jpg';
            //$albumSet['config']['mp_username'] = $this->site_info['mp_username'];
            //$albumSet['config']['mp_name'] = $this->site_info['web_name'];
            $albumSet['config']['demoid'] = '';
        }
        if( $this->input->post() )
        {
            $save_data['coverpic'] = $this->input->post('coverpic');
            if( !$save_data['coverpic'] ){
                $save_data['coverpic'] = 'http://image.bama555.com/data/201408/30/dfd3af807cd2fc62edede7e78c65110e_480_240.jpg';
            }
            //$save_data['mp_username'] = $this->input->post('mp_username');
            $save_data['mp_name'] = $this->input->post('mp_name');
            $save_data['demoid'] = $this->input->post('demoid');
            $saveData['config'] = json_encode($save_data);
            if($update == 1)
            {
                $this->model_app_config->update(array('user_id'=>$this->site_id, 'type'=>'album'), $saveData);
            }
            else
            {
                $saveData['user_id'] = $this->site_id;
                $saveData['type'] = 'album';
                $this->model_app_config->add($saveData,true);
            }
            $this->show_message(true, '保存成功', '/c/album/set');return FALSE;
        }
        else
        {
            $this->data['albumset'] = $albumSet['config'];
            $this->load->view($this->dcm, $this->data);
        }

    }

    /**
     * @name 相册业务单
     * @param $id
     * @return bool
     */
    public function detail($id)
    {
        $album = $this->getOneAlbum($id);
        if($album)
        {
            $this->data['album'] = $album;
            //相册设置
            $this->load->model('model_app_config');
            $albumSet = $this->model_app_config->get_row(array('user_id'=>$this->site_id, 'type'=>'album'));
            if($albumSet && $albumSet['config'])
            {
                $albumSet['config'] = json_decode($albumSet['config'],true);
            }
            //微网站信息
            $albumSet['config']['mp_username'] = $this->site_info['mp_username'];
            $albumSet['config']['mp_name'] = $this->site_info['web_name'];

            $this->data['albumSet'] = $albumSet['config'];

            $this->load->view($this->dcm,$this->data);
        }
        else
        {
            $this->show_message(FALSE, '相册不存在或已删除', '');return false;
        }
    }

    /**
     * @name 获取一个相册详情
     * @param $id
     * @return bool
     */
    private function getOneAlbum($id)
    {
        $result = $this->model->where(array('id'=>$id,'site_id'=>$this->site_id))->find();
        if($result)
        {
            return $result;
        }
        else
        {
            return false;
        }
    }

    /**
     * @name 图片列表
     * @param string $id
     */
    public function album_img($id='')
    {
        $album = $this->getOneAlbum($id);
        if( !$album ){
            return ($this->show_message(FALSE, '该相册不存在', '/c/album'));
        }
        $this->data['album_id'] = $album['id'];
        $this->data['album_name'] = $album['title'];
        $this->load->model('album_img_model');

        $where = "album_id=".$album['id'];
        $search_url = site_url($this->uri->uri_string().'?');
        /*$search['keyword'] = $this->input->get('keyword');
        if( $search['keyword'] ){
            $where .= " AND ( title LIKE '%".$search['keyword']."%' OR reply_keyword LIKE '%".$search['keyword']."%' ) ";
            $search_url .= '&keyword='.$search['keyword'];
        }
        $this->data['search'] = $search;*/
        $total_rows = $this->album_img_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>5,'base_url'=>$search_url));
        $list = $this->album_img_model->where($where)->limit($pager['limit']['value'], $pager['limit']['offset'])->order_by('listorder asc, id desc')->find_all();
        $this->data['list'] =  $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->load->view($this->dcm, $this->data);
    }

    public function album_img_add($id='')
    {
        $album = $this->getOneAlbum($id);
        if( !$album ){
            return ($this->show_message(FALSE, '该相册不存在', '/c/album'));
        }
        if($this->input->post()){
            $add_data = array();
            $imgs = $this->input->post('photos',true);
            if($imgs){
                foreach($imgs as $val){
                    if(strlen($val['img'])<255){
                        $add_data[] = $val;
                    }else{
                        exit( json_encode( array('ret'=>1000,'msg'=>'图片格式不合法') ) );
                    }
                }
                $this->load->model('album_img_model');
                foreach($add_data as $val){
                    $temp['album_id'] = $album['id'];
                    $temp['img'] = $val['img'];
                    $temp['title'] = $val['title'];
                    $this->album_img_model->add($temp);
                }
                exit( json_encode( array('ret'=>0,'data'=>array()) ) );
            }
        }
        exit( json_encode( array('ret'=>2000,'msg'=>'没有照片上传') ) );
    }

    /**
     * @name 批量修改图片的标题和描述
     * @param string $id
     */
    public function album_img_edit($id='')
    {
        $album = $this->getOneAlbum($id);
        if( !$album ){
            return ($this->show_message(FALSE, '该相册不存在', '/c/album'));
        }
        if($this->input->post()){
            $imgs = $this->input->post('img');
            if( $imgs ){
                $this->load->model('album_img_model');
                foreach($imgs as $key=>$val){
                    if( mb_strlen($val['title'])>20 ){
                        return ($this->show_message(FALSE, '标题不能超过20个字', ''));
                    }
                    if( mb_strlen($val['intro'])>200 ){
                        return ($this->show_message(FALSE, '描述不能超过200个字', ''));
                    }
                    if( mb_strlen($val['extra'])>8 ){
                        return ($this->show_message(FALSE, '链接名称不能超过8个字', ''));
                    }
                    if( mb_strlen($val['extra_url'])>255 ){
                        return ($this->show_message(FALSE, '链接地址不能超过255个字', ''));
                    }
                    if( !trim($val['extra'])&&($val['extra_url']) ){
                        return ($this->show_message(FALSE, '请先填写链接名称再填写链接地址', ''));
                    }
                    $this->album_img_model->where(array('id'=>$key,'album_id'=>$album['id']))->edit(array(
                        'title' => $val['title'],
                        'intro' => htmlspecialchars($val['intro']),
                        'extra' => $val['extra'],
                        'extra_url' => $val['extra_url'],
                        'listorder' => $val['listorder'],
                        'focus_share_set' => isset($val['focus_share_set']) ? $val['focus_share_set'] : 0
                    ));
                }
            }
            return ($this->show_message(TRUE, '保存成功', '/c/album/album_img/'.$album['id']));
        }else{
            return ($this->show_message(FALSE, '非法进入', '/c/album/album_img/'.$album['id']));
        }
    }

    /**
     * @name 旋转图片
     * @param string $album_id
     */
    public function album_img_rotate($album_id='')
    {
        $id = $this->input->get('id');
        if(!$id){
            exit(json_encode(array('ret'=> 20003, 'msg' => "参数不全")));
        }
        $album = $this->getOneAlbum($album_id);
        if( !$album ){
            exit(json_encode(array('ret'=> 20003, 'msg' => "该相册不存在")));
        }
        $this->load->model('album_img_model');
        $album_img = $this->album_img_model->where(array('album_id'=>$album['id'],'id'=>$id))->find();
        if( !$album_img ){
            exit(json_encode(array('ret'=> 20003, 'msg' => "该照片不存在")));
        }

        $photo = $album_img['img'];
        if( $this->img_exits($photo) ){
            exit(json_encode(array('ret'=> 20003, 'msg' => "没有找到该图片")));
        }
        $parse_url = parse_url($photo);
        $img_name = basename($photo);
        $location_dir = FCPATH.'/images/temp/' . $img_name;//本地临时保存地址
        $upload_dir = str_replace('/data', '', dirname($parse_url['path'])).'/';//图片服务器保存路径，以便覆盖原有图片

        $vals = getimagesize($photo);
        $types = array(1 => 'gif', 2 => 'jpeg', 3 => 'png');
        $mime = (isset($types[$vals['2']])) ? 'image/'.$types[$vals['2']] : 'image/jpg';
        $photo_info = array(
            'width'      => $vals[0],
            'height'     => $vals[1],
            'image_type' => $vals[2],
            'size_str'   => $vals[3],
            'mime_type'  => $mime
        );
        switch ($photo_info['image_type']){
            case 1 :
                $src_img = imagecreatefromgif($photo);break;
            case 2 :
                $src_img = imagecreatefromjpeg($photo);break;
            case 3 :
                $src_img = imagecreatefrompng($photo);break;
            default :
                exit(json_encode(array('ret'=> 2002, 'msg' => "不支持的照片格式")));
        }
        $rotate = imagerotate($src_img, -90,0);

        if( !imagejpeg($rotate,$location_dir,100) ){
            exit(json_encode(array('ret'=> 20003, 'msg' => "照片生成失败")));
        }
        imagedestroy($src_img);
        imagedestroy($rotate);

        $rotate_img = $this->rest_upload($location_dir, $upload_dir, $img_name);
        exit(json_encode(array('ret'=> 0, 'data' => $rotate_img)));
    }

    /**
     * @name 删除图片
     * @param string $album_id
     */
    public function album_img_del($album_id='')
    {
        $id = $this->input->get('id');
        if(!$id){
            return ($this->show_message(FALSE, '参数不全', '/c/album'));
        }
        $album = $this->getOneAlbum($album_id);
        if( !$album ){
            return ($this->show_message(FALSE, '该相册不存在', '/c/album'));
        }
        $this->load->model('album_img_model');
        $album_img = $this->album_img_model->where(array('album_id'=>$album['id'],'id'=>$id))->find();
        if( $album_img ){
            $this->album_img_model->where(array('id'=>$id))->delete();
            return $this->show_message(true, '删除成功', '/c/album/album_img/'.$album['id']);
        }else{
            return ($this->show_message(FALSE, '非法进入', '/c/album/album_img/'.$album['id']));
        }
    }

    //检查图片格式
    public function _check_image($image) {
        if ($image) {
            if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
                $this->form_validation->set_message('_check_image', '图片地址格式错误');
                return FALSE;
            }
        }
        return TRUE;
    }


    /**
     * @name 相册照片转换结构
     * @return bool
     */
    public function exchange_data()
    {
        $page = $this->input->get('page');
        $page = $page ? $page : 1;
        $per_page = 300;
        $albums = $this->model->select('id,photo')->limit($per_page,($page-1)*$per_page)->order_by('id asc')->find_all();
        if( $albums ){
            $this->load->model('album_img_model');
            foreach($albums as $val){
                if( $val['photo'] ){
                    $add_data['album_id'] = $val['id'];
                    $photos = json_decode($val['photo'],true);
                    foreach($photos as $img){
                        $add_data['img'] = $img;
                        $this->album_img_model->add($add_data);
                    }
                }
            }
            redirect(base_url().'c/album/exchange_data?page='.($page+1));
        }
        echo "转换完成";
    }


    /**
     *
     * @author Qianc
     * @date 2014-9-18
     * @description 批量删除
     */
    public function batch_del()
    {
        $ids = $this->input->get_post('ids');
        if($ids){
            $ret = $this->model->where_in('id', $ids)->delete();
            $rret = $ret ?  0 : 1;
            $msg = $ret ?  '操作成功' : '操作失败';
            exit($this->ajax_return(array('ret' => $rret, 'msg' => $msg)));
        }
    }


} 