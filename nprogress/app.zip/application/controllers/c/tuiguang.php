<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Created by PhpStorm.
 * User: along
 * Date: 13-12-4
 * Time: 上午11:41
 */

class Tuiguang extends C_Controller {

    protected $auto_load_model = TRUE;
    protected $model_name = 'union';

    public function index()
    {
        $this->load->view($this->dcm, $this->data);
    }

    public function lists()
    {
        //已有资源
        $time = time();
        $tuiguangList = $this->model->where(array('status'=>1,'start_time <='=>$time,'end_time >'=>$time))->order_by('id', 'desc')->find_all();
        if($tuiguangList)
        {
            $this->load->model('union_apply_model');
            foreach($tuiguangList as &$t)
            {
                $apply = $this->union_apply_model->where(array('tid'=>$t['id'],'site_id'=>$this->site_info['id']))->find();
                if($apply)
                {
                    $t['applystatus'] = $apply['status'];
                }
            }
        }
        $this->data['user'] = $this->site_info;

        $this->data['tuiguang'] = $tuiguangList;
        $this->load->view($this->dcm, $this->data);
    }

    public function detail($id)
    {
        $info = $this->model->find($id);
        $this->data['url'] = $this->create_url('/spread?id='.$id);
        $this->data['info'] = $info;
        $this->load->view($this->dcm, $this->data);
    }

    public function apply($tid)
    {
        $this->load->model('union_apply_model');
        if ($this->input->post()) {
            $tid = $this->input->post('tid');
            $mp_nickname = $this->input->post('mp_nickname');
            $cfans = $this->input->post('cfans');
            $industry = $this->input->post('industry');
            $contact = $this->input->post('contact');
            $mobile = $this->input->post('mobile');
            $fansimg = $this->input->post('fansimg');
            $statimg = $this->input->post('statimg');
            $this->union_apply_model->add(array(
                'tid' => $tid,
                'site_id' => $this->site_info['id'],
                'mp_nickname' => $mp_nickname,
                'cfans' => $cfans,
                'industry' => $industry,
                'contact' => $contact,
                'mobile' => $mobile,
                'fansimg' => $fansimg,
                'statimg' => $statimg,
                'input_time' => time(),
            ));
            $this->show_message(true,'您的申请已提交，请等待审核','/c/tuiguang/lists');
        } else {
            if ($this->union_apply_model->where(array('tid'=>$tid,'site_id'=>$this->site_info['id']))->count()) {
                $this->show_message(false,'您已经提交申请，请不要重复申请','/c/tuiguang/lists');
            }
            $this->data['tid'] = $tid;
            $this->load->view($this->dcm, $this->data);
        }
    }

    public function my()
    {
        $this->load->model('union_apply_model');
        $total_rows = $this->union_apply_model->where(array('site_id'=>$this->site_info['id']))->count();
        $pager = $this->_pager($total_rows, array(
            'base_url' => site_url($this->uri->uri_string().'?').$_SERVER['QUERY_STRING']
        ));
        $this->data['list'] = $this->union_apply_model->
            select('wb_union_apply.*,wb_union.title,wb_union.start_time,wb_union.end_time')
            ->join('wb_union', 'wb_union.id=wb_union_apply.tid')
            ->where(array('wb_union_apply.site_id'=>$this->site_info['id']))
            ->order_by('id', 'desc')
            ->find_all();
        $this->data['pager'] = $pager['links'];
        $this->load->view($this->dcm, $this->data);
    }

    public function orders($tid)
    {
        $this->load->model('union_order_model');
        $total_rows = $this->union_order_model->where(array('tid'=>$tid, 'from_site_id'=>$this->site_info['id']))->count();
        $pager = $this->_pager($total_rows, array(
            'base_url' => site_url($this->uri->uri_string().'?').$_SERVER['QUERY_STRING']
        ));
        $this->data['list'] = $this->union_order_model
            ->where(array('tid'=>$tid, 'from_site_id'=>$this->site_info['id']))
            ->order_by('id', 'desc')
            ->find_all();
        $this->data['pager'] = $pager['links'];
        $this->load->view($this->dcm, $this->data);
    }

    public function launch()
    {
        $this->load->view($this->dcm, $this->data);
    }
}