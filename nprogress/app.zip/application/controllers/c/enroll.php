<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 报名
 * @property Enroll_model $enroll_model
 * @property Enroll_record_model $enroll_record_model
 */

class Enroll extends C_Controller {
    
    private $site_id = '';
    private $normal_field_types = array(
        'gender' => '性别',
        'age' => '年龄',
        'birthday' => '生日',
        'height' => '身高',
        'weight' => '体重',
        'blood' => '血型',
        'marry' => '婚姻状况',
        'constellation' => '星座',
        'zodiac' => '生肖',
        'edu' => '学历',
        'profession' => '职业',
        'zip' => '邮编',
        'email' => '邮箱'
    );

    private $custom_field_types = array(
        'text' => '单行文本',
        'textarea' => '多行文本',
        'radio' => '单选按钮',
        'checkbox' => '复选框',
        'dropdown' => '下拉框',
        'number' => '数字',
        'datetime' => '日期和时间',
        'img' => '上传图片'
    );
    protected $mongo_table = 'enroll_fields';
    
    public function __construct()
    {
        parent::__construct();
        $this->load->library('Mongo_db');
        $this->site_id = $this->site_info['id'];
        
        $this->load->model('enroll_model');
        
        //活动结束活动
        $this->enroll_model->where(array('site_id'=>$this->site_id,'enroll_end_time <='=>time()))->edit(array('is_end'=>1));
    }
    
    //报名列表
    public function index()
    {
        $where = "site_id='".$this->site_id."' and is_delete = 0";
        $search_url = site_url($this->uri->uri_string().'?');
        $search['keyword'] = $this->input->get('keyword');
        $search['status'] = trim($this->input->get('status'));
        if( $search['status'] ){
            $search_url .= '&status='.$search['status'];
            if( $search['status']==1 ){//未开始
                $where .= " AND start_time > ".time();
            }
            if( $search['status']==2 ){//进行中
                $where .= " AND (start_time <= ".time()." AND end_time >= ".time().")";
            }
            if( $search['status']==3 ){//报名结束
                $where .= " AND end_time < ".time();
            }
        }
        if( $search['keyword'] ){
            $where .= " AND ( name LIKE '%".$search['keyword']."%' OR title LIKE '%".$search['keyword']."%' OR reply_keyword LIKE '%".$search['keyword']."%' ) ";
            $search_url .= '&keyword='.$search['keyword'];
        }
        
        $total_rows = $this->enroll_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$search_url));
        $list = $this->enroll_model
            ->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->order_by('id desc')->where($where)->find_all();
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        if( $list ){
            foreach( $list as $key=>$val ){
                //$list[$key]['url'] = $this->create_url('enroll?id='.$val['id']);
                $list[$key]['url'] = 'http://'.$this->site_info['domain'] . BASE_DOMAIN . '/' .trim('enroll?id='.$val['id'], '/');
                //$list[$key]['enter_qrcode'] = $this->createQRcode($list[$key]['url'].'&woaibeijingtiananmen=mp.weixin.qq.com', $val['id'], 'enter_enroll');
                if( $val['requir_regist']==1 ){
                    $list[$key]['regist_method'] = json_decode($val['regist_method'],true);
                    $list[$key]['regist_msg'] = '';
                    if( in_array('1', $list[$key]['regist_method']) ){
                        //$content = 'http://'.$this->site_info['domain'].'.69juzi.com/enroll/scan_qrcode_user?id='.urlencode($val['id']).'&woaibeijingtiananmen=mp.weixin.qq.com';
                        $content = $this->create_url('enroll/scan_qrcode_user?id='.urlencode($val['id']).'&woaibeijingtiananmen=mp.weixin.qq.com');
                        $url = $this->createQRcode($content,$val['id'], 'enroll');
                        $list[$key]['regist_msg'] .= "用户操作签到<br><a href='".$url."' target='_blank'>(下载二维码)</a>";
                    }
                    if( count($list[$key]['regist_method'])>1 ){
                        $list[$key]['regist_msg'] .= "<br>";
                    }
                    if( in_array('2', $list[$key]['regist_method']) ){
                        $list[$key]['regist_msg'] .= "商家操作签到";
                    }
                }
            }
        }
        
        $this->data['list'] = $list;
        
        $this->data['search'] = $search;
        
        $this->load->view($this->dcm,$this->data);
    }
    
    //添加报名
    public function add()
    {
        if( $this->input->post() ){
            $this->form_validation->set_rules('name', '活动名称', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('title', '活动标题', 'trim|required|max_length[255]');
            $this->form_validation->set_rules('enroll_end_time', '活动结束时间', 'trim|required');
            $this->form_validation->set_rules('summary', '活动描述', 'trim|required|max_length[65500]|htmlspecialchars');
            
            $this->form_validation->set_rules('reply_keyword', '活动回复关键词', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('reply_title', '活动回复标题', 'trim|required|max_length[500]');
            $this->form_validation->set_rules('reply_image', '活动回复图片', 'trim|max_length[255]|callback__check_image');
            $this->form_validation->set_rules('share_image', '分享图片', 'trim|max_length[255]|callback__check_image');

            $this->form_validation->set_rules('notice', '报名须知', 'trim|required|max_length[65500]|htmlspecialchars');
            
            $this->form_validation->set_rules('start_time', '报名开始时间', 'trim|required');
            $this->form_validation->set_rules('end_time', '报名结束时间', 'trim|required');
            
            $this->form_validation->set_rules('cover_image', '封面图片', 'trim|max_length[255]|callback__check_image');
            
            $this->form_validation->set_rules('enroll_success', '报名成功提示', 'trim|required|max_length[255]');
            $this->form_validation->set_rules('enroll_end_notice', '报名结束公告', 'trim|required|max_length[500]|htmlspecialchars');
            
            $this->form_validation->set_rules('email_notice', '信息微信提醒邮箱', 'trim|max_length[255]|valid_email');
            $this->form_validation->set_rules('regist_win_notice', '签到成功后提示', 'trim|max_length[255]');
            $this->form_validation->set_rules('manage_password', '管理密码', 'trim');
            
            $this->form_validation->set_rules('enroll_tpl', '报名模版', 'trim|required');
            if ( $this->form_validation->run() ){
                $save_data['name'] = $this->form_validation->set_value('name');
                $save_data['title'] = $this->form_validation->set_value('title');
                $save_data['enroll_end_time'] = $this->form_validation->set_value('enroll_end_time');
                $save_data['summary'] = $this->form_validation->set_value('summary');
                $save_data['reply_keyword'] = $this->form_validation->set_value('reply_keyword');
                $save_data['reply_title'] = $this->form_validation->set_value('reply_title');
                $save_data['reply_image'] = $this->form_validation->set_value('reply_image');
                $save_data['share_image'] = $this->form_validation->set_value('share_image');
                
                $save_data['show_account'] = intval($this->input->post('show_account'));
                $save_data['limit_num'] = intval($this->input->post('limit_num'));
                if( $save_data['limit_num']==1 ){
                    $save_data['limit_nums'] = $this->input->post('limit_nums');
                    if( !(preg_match("/^[1-9]+(\d*)$/", $save_data['limit_nums'])) ){
                        return $this->show_message(FALSE, '限制人数必须是大于0的整数', '');
                    }
                }
                
                $save_data['notice'] = $this->form_validation->set_value('notice');
                $save_data['start_time'] = strtotime($this->form_validation->set_value('start_time'));
                $save_data['end_time'] = strtotime($this->form_validation->set_value('end_time'));
                $save_data['enroll_end_time'] = strtotime($this->form_validation->set_value('enroll_end_time'));
                if( ($save_data['start_time']>0&&$save_data['end_time']>0&&($save_data['start_time']-$save_data['end_time']>=0)) ){
                    return $this->show_message(FALSE, '请填写报名的开始时间和结束时间，且结束时间大于开始时间', '');
                }
                if( $save_data['enroll_end_time']-$save_data['end_time']<0 ){
                    return $this->show_message(FALSE, '活动结束时间不能小于报名结束时间', '');
                }
                
                $save_data['show_cover_image'] = intval($this->input->post('show_cover_image'));
                if( $save_data['show_cover_image']==1 ){
                    $save_data['cover_image'] = $this->form_validation->set_value('cover_image');
                    if( !$save_data['cover_image'] ){
                        return $this->show_message(FALSE, '请上传封面图片', '');
                    }
                }
                
                $save_data['enroll_success'] = $this->form_validation->set_value('enroll_success');
                $save_data['enroll_end_notice'] = $this->form_validation->set_value('enroll_end_notice');
                $save_data['email_notice'] = $this->form_validation->set_value('email_notice');
                //微助手提醒
                $save_data['assistant'] = ($this->input->post('assistant',true) == 1) ? 1 : 0;
                
                $save_data['requir_regist'] = intval($this->input->post('requir_regist'));
                if( $save_data['requir_regist']==1 ){
                    $regist_method = $this->input->post('regist_method');
                    if( $regist_method ){
                        $save_data['regist_method'] = json_encode($regist_method);
                    }else{
                        return $this->show_message(FALSE, '请选择签到方式', '');
                    }
                    
                    //签到成功后提示
                    $save_data['regist_win_type'] = intval($this->input->post('regist_win_type'));
                    $save_data['regist_win_notice'] = htmlspecialchars(trim($this->input->post('regist_win_notice',true)));
                    if( $save_data['regist_win_type']==1 ){//文本内容
                        if( $save_data['regist_win_notice']=='' ){
                            return $this->show_message(FALSE, '请填写签到成功后的提示内容', '');
                        }
                    }else if( $save_data['regist_win_type']==2 ){
                        if( $save_data['regist_win_notice']=='' ){
                            return $this->show_message(FALSE, '请填写签到成功后的跳转链接', '');
                        }
                        if( !(preg_match("/\s|^http:\/\//is", $save_data['regist_win_notice']))||!(preg_match("/^http:\/\//is", $save_data['regist_win_notice'])) ){
                            return $this->show_message(FALSE, '请填写正确的链接地址', '');
                        }
                    }
                    
                    //管理密码
                    $save_data['manage_password'] = $this->form_validation->set_value('manage_password');
                    if( $save_data['manage_password'] ){
                        if( !(preg_match("/^([0-9]){4,8}$/", $save_data['manage_password'])) ){
                            return $this->show_message(FALSE, '管理密码只能是4-8位数字', '');
                        }
                    }else{
                        return $this->show_message(FALSE, '请填写管理密码', '');
                    }
                }
                
                $save_data['enroll_tpl'] = $this->form_validation->set_value('enroll_tpl');
                $save_data['site_id'] = $this->site_id;
                $save_data['add_time'] = time();
                if( $this->enroll_model->add($save_data) ){
                    return $this->show_message(TRUE, '添加成功', '/c/enroll');
                }else{
                    return $this->show_message(FALSE, '添加失败', '');
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    return $this->show_message(FALSE, $errors, '');
                }
            }
        }else{
            /*//需完善信息项1515886
            $this->load->library('Mongo_db');
            $field_list = $this->mongo_db->where(array('wid'=>$this->site_info['id']))->order_by(array('sort', 'ASC'))->get('account_fields');
            $this->data['field_list'] = $field_list;*/
            
            //获取模版
            $this->load->config('tpl');
            $config_tpl = $this->config->item('enroll_tpl');
            $this->data['enroll_tpl'] = $config_tpl;

            //是否开通了微助手
            $this->data['assistant'] = $this->check_assistant($this->site_id);
            
            $this->load->view($this->dcm, $this->data);
        } 
    }
    
    //修改报名
    public function edit($id='')
    {
        $enroll = $this->getEnrollById($id);
        if(!$enroll){
            $this->show_message(false, '报名不存在', 1);return false;
        }
        if( $this->input->post() ){
            $this->form_validation->set_rules('name', '活动名称', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('title', '活动标题', 'trim|required|max_length[255]');
            $this->form_validation->set_rules('enroll_end_time', '活动结束时间', 'trim|required');
            $this->form_validation->set_rules('summary', '活动描述', 'trim|required|max_length[65500]|htmlspecialchars');
            
            $this->form_validation->set_rules('reply_keyword', '活动回复关键词', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('reply_title', '活动回复标题', 'trim|required|max_length[500]');
            $this->form_validation->set_rules('reply_image', '活动回复图片', 'trim|max_length[255]|callback__check_image');
            $this->form_validation->set_rules('share_image', '分享图片', 'trim|max_length[255]|callback__check_image');

            $this->form_validation->set_rules('notice', '报名须知', 'trim|required|max_length[65500]|htmlspecialchars');
            
            $this->form_validation->set_rules('start_time', '报名开始时间', 'trim|required');
            $this->form_validation->set_rules('end_time', '报名结束时间', 'trim|required');
            
            $this->form_validation->set_rules('cover_image', '封面图片', 'trim|max_length[255]|callback__check_image');
            
            $this->form_validation->set_rules('enroll_success', '报名成功提示', 'trim|required|max_length[255]');
            $this->form_validation->set_rules('enroll_end_notice', '报名结束公告', 'trim|required|max_length[500]|htmlspecialchars');
            
            $this->form_validation->set_rules('email_notice', '信息微信提醒邮箱', 'trim|max_length[255]|valid_email');
            $this->form_validation->set_rules('regist_win_notice', '签到成功后提示', 'trim|max_length[255]');
            $this->form_validation->set_rules('manage_password', '管理密码', 'trim');
            
            $this->form_validation->set_rules('enroll_tpl', '报名模版', 'trim|required');
            if ( $this->form_validation->run() ){
                $save_data['name'] = $this->form_validation->set_value('name');
                $save_data['title'] = $this->form_validation->set_value('title');
                $save_data['enroll_end_time'] = $this->form_validation->set_value('enroll_end_time');
                $save_data['summary'] = $this->form_validation->set_value('summary');
                $save_data['reply_keyword'] = $this->form_validation->set_value('reply_keyword');
                $save_data['reply_title'] = $this->form_validation->set_value('reply_title');
                $save_data['reply_image'] = $this->form_validation->set_value('reply_image');
                $save_data['share_image'] = $this->form_validation->set_value('share_image');

                $save_data['show_account'] = intval($this->input->post('show_account'));
                $save_data['limit_num'] = intval($this->input->post('limit_num'));
                if( $save_data['limit_num']==1 ){
                    $save_data['limit_nums'] = $this->input->post('limit_nums');
                    if( !(preg_match("/^[1-9]+(\d*)$/", $save_data['limit_nums'])) ){
                        return $this->show_message(FALSE, '限制人数必须是大于0的整数', '');
                    }
                }
                
                $save_data['notice'] = $this->form_validation->set_value('notice');
                $save_data['start_time'] = strtotime($this->form_validation->set_value('start_time'));
                $save_data['end_time'] = strtotime($this->form_validation->set_value('end_time'));
                $save_data['enroll_end_time'] = strtotime($this->form_validation->set_value('enroll_end_time'));
                if( ($save_data['start_time']>0&&$save_data['end_time']>0&&($save_data['start_time']-$save_data['end_time']>=0)) ){
                    return $this->show_message(FALSE, '请填写报名的开始时间和结束时间，且结束时间大于开始时间', '');
                }
                if( $save_data['enroll_end_time']-$save_data['end_time']<0 ){
                    return $this->show_message(FALSE, '活动结束时间不能小于报名结束时间', '');
                }
                
                $save_data['show_cover_image'] = intval($this->input->post('show_cover_image'));
                if( $save_data['show_cover_image']==1 ){
                    $save_data['cover_image'] = $this->form_validation->set_value('cover_image');
                    if( !$save_data['cover_image'] ){
                        return $this->show_message(FALSE, '请上传封面图片', '');
                    }
                }
                
                $save_data['enroll_success'] = $this->form_validation->set_value('enroll_success');
                $save_data['enroll_end_notice'] = $this->form_validation->set_value('enroll_end_notice');
                $save_data['email_notice'] = $this->form_validation->set_value('email_notice');

                //微助手提醒
                $save_data['assistant'] = ($this->input->post('assistant',true) == 1) ? 1 : 0;
                
                $save_data['requir_regist'] = intval($this->input->post('requir_regist'));
                if( $save_data['requir_regist']==1 ){
                    $regist_method = $this->input->post('regist_method');
                    if( $regist_method ){
                        $save_data['regist_method'] = json_encode($regist_method);
                    }else{
                        return $this->show_message(FALSE, '请选择签到方式', '');
                    }
                    
                    //签到成功后提示
                    $save_data['regist_win_type'] = intval($this->input->post('regist_win_type'));
                    $save_data['regist_win_notice'] = htmlspecialchars(trim($this->input->post('regist_win_notice',true)));
                    if( $save_data['regist_win_type']==1 ){//文本内容
                        if( $save_data['regist_win_notice']=='' ){
                            return $this->show_message(FALSE, '请填写签到成功后的提示内容', '');
                        }
                    }else if( $save_data['regist_win_type']==2 ){
                        if( $save_data['regist_win_notice']=='' ){
                            return $this->show_message(FALSE, '请填写签到成功后的跳转链接', '');
                        }
                        if( !(preg_match("/\s|^http:\/\//is", $save_data['regist_win_notice']))||!(preg_match("/^http:\/\//is", $save_data['regist_win_notice'])) ){
                            return $this->show_message(FALSE, '请填写正确的链接地址', '');
                        }
                    }
                    
                    //管理密码
                    $save_data['manage_password'] = $this->form_validation->set_value('manage_password');
                    if( $save_data['manage_password'] ){
                        if( !(preg_match("/^([0-9]){4,8}$/", $save_data['manage_password'])) ){
                            return $this->show_message(FALSE, '管理密码只能是4-8位数字', '');
                        }
                    }else{
                        return $this->show_message(FALSE, '请填写管理密码', '');
                    }
                }
                
                $save_data['enroll_tpl'] = $this->form_validation->set_value('enroll_tpl');
                $save_data['site_id'] = $this->site_id;

                
                if( $this->enroll_model->where(array('id'=>$id, 'site_id'=>$this->site_id,'is_delete'=>0))->edit($save_data) ){
                    return $this->show_message(TRUE, '修改成功', '/c/enroll');
                }else{
                    return $this->show_message(FALSE, '修改失败', '');
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    return $this->show_message(FALSE, $errors, '');
                }
            }
        }else{
            /*//需完善信息项1515886
            $this->load->library('Mongo_db');
            $field_list = $this->mongo_db->where(array('wid'=>$this->site_info['id']))->order_by(array('sort', 'ASC'))->get('account_fields');
            $this->data['field_list'] = $field_list;*/
            $enroll['regist_method'] = json_decode($enroll['regist_method'],true);
            $this->data['enroll'] = $enroll;

            //是否开通了微助手
            $this->data['assistant'] = $this->check_assistant($this->site_id);

            //获取模版
            $this->load->config('tpl');
            $config_tpl = $this->config->item('enroll_tpl');
            $this->data['enroll_tpl'] = $config_tpl;
            
            $this->load->view($this->dcm, $this->data);
        }
    }
    
    //禁用
    public function disable($id='')
    {
        $enroll = $this->getEnrollById($id);
        if(!$enroll){
            $this->show_message(false, '报名不存在', 1);return false;
        }
        if( $enroll['status']==0 ){
            $this->enroll_model->where(array('id'=>$id, 'site_id'=>$this->site_id,'is_delete'=>0))->edit(array('status'=>1));
            $this->show_message(true, '禁用成功', '',1);return FALSE;
        }
        $this->show_message(false, '禁用失败', '',1);return FALSE;
    }
    
    //启用
    public function enable($id='')
    {
        $enroll = $this->getEnrollById($id);
        if(!$enroll){
            $this->show_message(false, '报名不存在', 1);return false;
        }
        if( $enroll['status']==1 ){
            $this->enroll_model->where(array('id'=>$id, 'site_id'=>$this->site_id,'is_delete'=>0))->edit(array('status'=>0));
            $this->show_message(true, '启用成功', '',1);return FALSE;
        }
        $this->show_message(false, '启用失败', '',1);return FALSE;
    }
    
    //删除
    public function delete($id='')
    {
        $enroll = $this->getEnrollById($id);
        if(!$enroll){
            $this->show_message(false, '报名不存在', 1);return false;
        }
        
        //删除报名
        $this->enroll_model->where(array('id'=>$id))->edit(array('is_delete'=>1));
        $this->show_message(true, '删除成功', '/c/enroll/index');return FALSE;
    }

    /**
     * @name 统计
     * @param $id
     * @return bool
     */
    public function sta($id = '')
    {
        $enroll = $this->getEnrollById($id);
        if($enroll)
        {
            $where = "site_id='".$this->site_id."' and enroll_id=".$id;
            $this->load->model('enroll_record_model');
            $list = $search = array();
            $search_url = site_url($this->uri->uri_string().'?');

            $search['mobile'] = $this->input->get('mobile');
            if( $search['mobile'] ){
                $where .= " AND mobile LIKE '%".$search['mobile']."%'";
                $search_url .= '&mobile='.$search['mobile'];
            }
            //报名时间范围
            $search['start_time'] = $this->input->get('start_time');
            $search['end_time'] = $this->input->get('end_time');
            if($search['start_time'])
            {
                $where .= " AND add_time >= ".strtotime($search['start_time']);
                $search_url .= '&start_time='.$search['start_time'];
            }
            if($search['end_time'])
            {
                $where .= " AND add_time <= ".strtotime($search['end_time']);
                $search_url .= '&end_time='.$search['end_time'];
            }

            $total_rows = $this->enroll_record_model->where($where)->count();
            $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$search_url));
            if($total_rows > 0)
            {
                $list = $this->enroll_record_model->where($where)->order_by('id desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->find_all();
            }
            $this->data['list'] = $list;
            $this->data['page'] = $pager['links'];
            $this->data['curr_page'] = $this->input->get('page') ? $this->input->get('page') : 0;
            $this->data['enroll'] = $enroll;
            $this->data['offset'] = $pager['limit']['offset'];
            $this->data['search'] = $search;

            $this->load->view($this->dcm, $this->data);
        }
        else
        {
            $this->show_message(false, '报名不存在', '');return false;
        }
    }

    /**
     * @name 查看报名者详情
     * @param $id
     * @return bool
     */
    public function staView($id = '')
    {
        $this->load->model('enroll_record_model');
        $record = $this->enroll_record_model->where(array('id'=>$id,'site_id'=>$this->site_id))->find();
        if($record)
        {
            $enroll = $this->getEnrollById($record['enroll_id']);
            $this->data['enroll'] = $enroll;

            $record['content'] = $record['content'] ? json_decode($record['content'],true) : '';
            $this->data['info'] = $record;
            $this->load->view($this->dcm, $this->data);
        }
        else
        {
            $this->show_message(false, '报名信息不存在', '');return false;
        }
    }

    public function export()
    {
        $id = $this->input->get('id');
        $enroll = $this->getEnrollById($id);
        if($enroll)
        {
            $where = "site_id='".$this->site_id."' and enroll_id=".$id;
            $this->load->model('enroll_record_model');
            $mobile = $this->input->get('mobile');
            if( $mobile ){
                $where .= " AND mobile LIKE '%".$mobile."%'";
            }
            //报名时间范围
            $start_time = $this->input->get('start_time');
            $end_time = $this->input->get('end_time');
            if($start_time)
            {
                $where .= " AND add_time >= ".strtotime($start_time);
            }
            if($end_time)
            {
                $where .= " AND add_time <= ".strtotime($end_time);
            }

            //所有的报名字段
            $field_list = $this->mongo_db->where(array('site_id'=>$this->site_id,'enroll_id'=>$id,'status'=>1))->order_by(array('sort'=>'desc'))->get($this->mongo_table);

            $list = $this->enroll_record_model->where($where)->order_by('id desc')->find_all();

            if( $list ){

                $exportData = array();
                $fields = array(
                    '#'=>'#',
                    'mobile'=>'手机号码',
                );
                if( $field_list ){
                    foreach($field_list as $_filed)
                    {
                        $fields[$_filed['ex_key']] = $_filed['value'];
                    }
                }

                foreach($list as $k => $_list){
                    $orther = '';
                    if($_list['content']){
                        $content = json_decode($_list['content'],true);
                        if($content){
                            foreach($content as $_item){
                                //先匹配当前活动设置的报名选项的报名结果
                                foreach($fields as $tmp_k=> $_tmp)
                                {
                                    if(isset($_item['ex_key']) && isset($fields[$_item['ex_key']]))
                                    {
                                        $exportData[$k][$_item['ex_key']] = $_item['value'];
                                    }
                                    elseif($tmp_k != '#')
                                    {
                                        $exportData[$k][$tmp_k] = '-';
                                    }
                                }

                                //匹配不上报名选项的结果，放到一个字段里面
                                if(isset($_item['ex_key']) && !isset($fields[$_item['ex_key']]) && isset($_item['value']))
                                {
                                    $orther .= (isset($_item['name']) ? $_item['name'] : 'name').'：'.$_item['value']."\r\n";
                                }
                            }
                            $fields['orther'] = '其它';
                        }
                    }
                    else
                    {
                        foreach($fields as $fk => $_f)
                        {
                            if(!in_array($fk,array('#','mobile')))
                            {
                                $exportData[$k][$fk] = '';
                            }
                        }
                    }
                    $exportData[$k]['orther'] = $orther;

                    $fields['add_time'] = '报名时间';
                    $exportData[$k]['add_time'] = date('Y-m-d H:i:s',$_list['add_time']);

                    $exportData[$k]['mobile'] = $_list['mobile'];
                }

                $this->excel_export('报名统计列表', '报名统计列表', $fields, $exportData);
            }

            else
            {
                $this->show_message(FALSE, '尚无报名记录可导出', '');
            }
        }
        else
        {
            $this->show_message(FALSE, '报名不存在或已删除', '');
        }
    }
    /**
     * @name 所有报名内容项
     * @param string $id
     * @return bool
     */
    public function fields($id = '')
    {
        //$this->mongo_db->where(array('site_id'=>$this->site_id,'enroll_id'=>$id))->delete($this->mongo_table);
        $enroll = $this->getEnrollById($id);
        if($enroll)
        {
            $total_rows = $this->mongo_db->where(array('site_id'=>$this->site_id,'enroll_id'=>$id,'status'=>1))->count($this->mongo_table);
            $pager = $this->_pager($total_rows, array('per_page'=>10));
            $list = $this->mongo_db->where(array('site_id'=>$this->site_id,'enroll_id'=>$id,'status'=>1))
                                    ->limit($pager['limit']['value'])
                                    ->offset($pager['limit']['offset'])
                                    ->order_by(array('sort'=>'desc'))
                                    ->get($this->mongo_table);
            foreach($list as &$item)
            {
                $item['name'] = isset($this->normal_field_types[$item['name']]) ? $this->normal_field_types[$item['name']] : $this->custom_field_types[$item['name']];
            }
            $this->data['list'] = $list;
            $this->data['page'] = $pager['links'];
            $this->data['curr_page'] = $this->input->get('page') ? $this->input->get('page') : 0;
            $this->data['enroll'] = $enroll;
            $this->data['offset'] = $pager['limit']['offset'];
            $this->load->view($this->dcm, $this->data);
        }
        else
        {
            $this->show_message(false, '报名不存在', '');return false;
        }
    }

    /**
     * @name 添加报名内容字段
     * @param $id
     * @return bool
     */
    public function fieldAdd($id = '')
    {
        $enroll = $this->getEnrollById($id);
        if($enroll)
        {
            if ($this->input->post())
            {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('name', '字段类型', 'trim|required');
                $this->form_validation->set_rules('value', '字段名称', 'trim|required');
                if ( $this->form_validation->run() )
                {
                    $data = $this->input->post();
                    if(isset($data['setting']) && isset($data['setting']['options'])) {
                        $data['setting']['options'] = explode(PHP_EOL, $data['setting']['options']);
                        if(isset($data['setting']) && isset($data['setting']['defaultvalue']) && $data['setting']['defaultvalue']) {
                            if(!in_array($data['setting']['defaultvalue'], $data['setting']['options'])) {
                                $this->show_message(TRUE, '默认值必须是选项里的值', '');
                                return FALSE;
                            }
                        }
                    }

                    $data['must'] = (int)$data['must'];
                    $data['sort'] = (int)$data['sort'];
                    $data['site_id'] = $this->site_id;
                    $data['enroll_id'] = $enroll['id'];
                    $data['status'] = 1;
                    //导出字段 (此处排除status，为了ex_key不重复)
                    $count = $this->mongo_db->where(array('enroll_id'=>$enroll['id'],'site_id'=>$this->site_id,'type'=>$data['type']))->count($this->mongo_table);
                    $num = $count+1;
                    $data['ex_key'] = $data['type'].$num;

                    if($this->mongo_db->insert($this->mongo_table, $data)) {
                        $this->show_message(TRUE, '添加成功', '/c/enroll/fields/'.$enroll['id']);
                        return FALSE;
                    } else {
                        $this->show_message(FALSE, '添加失败', '');
                        return FALSE;
                    }
                }
                else
                {
                    $errors = validation_errors();
                    if ($errors) {
                        $this->show_message(FALSE, $errors, '');
                        return FALSE;
                    }
                }
            }
            else
            {
                $this->data['enroll'] = $enroll;
                $this->data['normal_field_types'] = $this->normal_field_types;
                $this->data['custom_field_types'] = $this->custom_field_types;
                $this->load->view($this->dcm, $this->data);
            }
        }
        else
        {
            $this->show_message(false, '报名不存在', '');return false;
        }
    }

    /**
     * @name 编辑报名内容
     * @param $_id
     * @return bool
     */
    public function fieldEdit($_id = '')
    {
        $field = $this->mongo_db->where(array("_id"=>new MongoId("$_id"), 'site_id'=>$this->site_id))->get_one($this->mongo_table);
        if(!$field) {
            $this->show_message(FALSE, '该报名内容不存在', '');
        }

        if($this->input->post()) {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('name', '字段类型', 'trim');
            $this->form_validation->set_rules('value', '字段名称', 'trim|required');
            if ( $this->form_validation->run() ) {
                $data = $this->input->post();
                if(isset($data['setting']) && isset($data['setting']['options']))
                {
                    $data['setting']['options'] = explode(PHP_EOL, $data['setting']['options']);
                    if(isset($data['setting']) && isset($data['setting']['defaultvalue']) && $data['setting']['defaultvalue']) {
                        if(!in_array($data['setting']['defaultvalue'], $data['setting']['options'])) {
                            $this->show_message(TRUE, '默认值必须是选项里的值', '');
                            return FALSE;
                        }
                    }
                }
                $data['sort'] = (int)$data['sort'];
                $data['must'] = (int)$data['must'];

                if($this->mongo_db->where(array("_id"=>new MongoId($_id), 'site_id'=>$this->site_id))->set($data)->update($this->mongo_table)) {
                    $this->show_message(TRUE, '编辑成功', '/c/enroll/fields/'.$field['enroll_id']);
                    return FALSE;
                } else {
                    $this->show_message(FALSE, '编辑失败', '');
                    return FALSE;
                }
            } else {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }
        else
        {
            $this->data['enroll'] = $this->getEnrollById($field['enroll_id']);
            $this->data['field'] = $field;
            //print_r($field);
            $this->data['normal_field_types'] = $this->normal_field_types;
            $this->data['custom_field_types'] = $this->custom_field_types;
            $this->load->view($this->dcm, $this->data);
        }
    }

    /**
     * @name 删除一个报名内容项
     * @param $_id
     */
    public function fieldDel($_id = '')
    {
        $field = $this->mongo_db->where(array("_id"=>new MongoId("$_id"), 'site_id'=>$this->site_id))->get_one($this->mongo_table);
        if(!$field) {
            $this->show_message(FALSE, '没有该报名内容字段', '');
        }

        if($this->mongo_db->where(array("_id"=>new MongoId("$_id"), 'site_id'=>$this->site_id))->set(array('status'=>0))->update($this->mongo_table)) {
            $this->show_message(TRUE, '删除成功', '/c/enroll/fields/'.$field['enroll_id']);
        } else {
            $this->show_message(FALSE, '删除失败', '');
        }
    }

    /**
     * @name ajax请求相关参数设置
     * @param string $id
     */
    public function params($id = '')
    {
        if($id) {
            $field = $this->mongo_db->where(array("_id"=>new MongoId("$id"), 'site_id'=>$this->site_id))->get_one($this->mongo_table);
            if(!$field) {
                $this->show_message(FALSE, '没有该字段', 1);
            }
            $this->data['field'] = $field;
        }
        $type = $this->input->post('type');
        $this->data['type'] = $type;
        return $this->load->view($this->dcm, $this->data);
    }

    /**
     * @name 根据id获取一个报名详情
     * @param $id
     * @return bool
     */
    private function getEnrollById($id)
    {
        if(!$id) return false;
        $enroll = $this->enroll_model->where(array('id'=>$id,'site_id'=>$this->site_id,'is_delete'=>0))->find();
        if($enroll)
        {
            return $enroll;
        }
        else
        {
            return false;
        }
    }
    
    //检查图片格式
    public function _check_image($image) {
        if ($image) {
            if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
                $this->form_validation->set_message('_check_image', '图片地址格式错误');
                return FALSE;
            }
        }
        return TRUE;
    }
    
}
