<?php
/**
 * Created by PhpStorm.
 * User: 111
 * Date: 14-9-22
 * Time: 下午3:16
 * appoint_cat_model
 * 预约分类
 */

class Appoint_cat  extends C_Controller{

    private $site_id = '';

    public function __construct()
    {
        parent::__construct();
        $this->site_id = $this->site_info['id'];
        $this->load->model('appoint_cat_model');
    }

    public function index()
    {
        $list = $this->appoint_cat_model->where(array('site_id'=>$this->site_id))->order_by('id asc')->find_all();
        $this->data['list'] = $list;

        $this->load->view($this->dcm,$this->data);
    }

    public function add()
    {
        if( $this->input->post() ){
            $this->form_validation->set_rules('name', '分类名称', 'trim|required|max_length[10]');
            if ( $this->form_validation->run() ){
                $save_data['name'] = $this->form_validation->set_value('name');
                $save_data['site_id'] = $this->site_id;
                $save_data['add_time'] = $save_data['update_time'] = time();
                if( $this->appoint_cat_model->add( $save_data ) ){
                    return $this->show_message( TRUE, '添加成功', '/c/appoint_cat' );
                }else{
                    return $this->show_message( FALSE, '添加失败' );
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    return $this->show_message(FALSE, $errors, '');
                }
            }
        }else{
            $this->load->view( $this->dcm, $this->data );
        }
    }

    public function edit($id=0)
    {
        $cat = $this->appoint_cat_model->where(array( 'id'=>$id, 'site_id'=>$this->site_id))->find();
        if( !$cat ){
            return $this->show_message(FALSE, '非法进入', '');
        }
        $this->data['cate'] = $cat;
        if( $this->input->post() ){
            $this->form_validation->set_rules('name', '分类名称', 'trim|required|max_length[10]');
            if ( $this->form_validation->run() ){
                $save_data['name'] = $this->form_validation->set_value('name');
                $save_data['site_id'] = $this->site_id;
                $save_data['add_time'] = $save_data['update_time'] = time();
                if( $this->appoint_cat_model->where(array('id'=>$cat['id']))->edit( $save_data ) ){
                    return $this->show_message( TRUE, '编辑成功', '/c/appoint_cat' );
                }else{
                    return $this->show_message( FALSE, '编辑失败' );
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    return $this->show_message(FALSE, $errors, '');
                }
            }
        }else{
            $this->load->view( $this->dcm, $this->data );
        }
    }

}