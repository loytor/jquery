<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 渠道指标管理
 */
class Qudao_zhibiao extends C_Controller {

    protected $data = '';
    private $site_id = '';

    public function __construct()
    {
        parent::__construct();
        $this->site_id = $this->site_info['id'];
        
        $this->load->model('qudao_zhibiao_model');
    }

    public function index()
    {
        $where = array();
        $where['site_id'] = $this->site_id;

        $total_rows = $this->qudao_zhibiao_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>10));
        $list = $this->qudao_zhibiao_model->where($where)->order_by('id desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->where($where)->find_all();

        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->data['list'] = $list;
        $this->load->view($this->dcm,$this->data);
    }

    /**
     * 判断唯一性
     */
    public function check_unique( $field, $value )
    {
        $result = $this->qudao_zhibiao_model->where(array('site_id'=>$this->site_id,$field=>$value))->count();
        if( $result ){
            return false;
        }else{
            return true;
        }
    }
    


    public function add()
    {
        if( $this->input->post() ){
            $this->form_validation->set_rules('name', '指标名称', 'trim|required|max_length[100]');
            $this->form_validation->set_rules('num', '指标数值', 'trim|required|integer|intval');
            if ( $this->form_validation->run() ){
                $dataSet['name'] = $this->form_validation->set_value('name');
                $dataSet['num'] = $this->form_validation->set_value('num');
                $dataSet['site_id'] = $this->site_id;
                if( !$id=$this->qudao_zhibiao_model->add($dataSet) ){
                    $this->show_message(false, '添加失败', '');
                    return FALSE;
                }else{
                    $this->show_message(true, '添加成功', '/c/qudao_zhibiao/index');
                    return FALSE;
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            $this->load->view($this->dcm,$this->data);
        }
    }

    public function edit($id)
    {
        if(!$id){
            $this->show_message(false, '非法参数', 1);return false;
        }
        $cate = $this->qudao_zhibiao_model->where(array('id'=>$id,'site_id'=>$this->site_id))->find();
        if(!$cate){
            $this->show_message(false, '指标不存在', 1);return false;
        }

        if( $this->input->post() ){
            $this->form_validation->set_rules('name', '渠道指标名称', 'trim|required|max_length[100]');
            $this->form_validation->set_rules('num', '指标数值', 'trim|required|integer|intval');
            if ( $this->form_validation->run() ){
                $dataSet['name'] = $this->form_validation->set_value('name');
                $dataSet['num'] = $this->form_validation->set_value('num');
                if(false === $this->qudao_zhibiao_model->where(array('id'=>$id, 'site_id'=>$this->site_id))->edit($dataSet) ){
                    $this->show_message(false, '编辑失败', '',1);
                }else{
                    $this->show_message(true, '编辑成功', '',1);
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            $this->data['info'] = $cate;
            $this->load->view($this->dcm,$this->data);
        }
    }

    /**
     * 删除渠道指标
     * @param $id
     * @return bool
     */
    public function delete($id)
    {
        if(!$id){
            $this->show_message(false, '非法参数', 1);return false;
        }
        $cate = $this->qudao_zhibiao_model->where(array('id'=>$id,'site_id'=>$this->site_id))->find();
        if(!$cate){
            $this->show_message(false, '指标不存在', '/c/qudao_zhibiao/index');return false;
        }
        
        //渠道指标id清0
        $this->load->model('qudao_model');
        $this->qudao_model->where(array('zhibiao_id'=>$id,'site_id'=>$this->site_id))->edit(array('zhibiao_id'=>0));
        
        $this->qudao_zhibiao_model->where(array('id'=>$id,'site_id'=>$this->site_id))->delete();
        $this->show_message(true, '指标删除成功!', '/c/qudao_zhibiao/index');return false;
    }
    
}