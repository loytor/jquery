<?php
/**
 * Created by solaa.
 * User: solaa
 * Date: 2014/11/21 10:19
 */

class PhotoVote extends C_Controller{

    private $site_id = '';

    public function __construct()
    {
        parent::__construct();
        $this->site_id = $this->site_info['id'];
        $this->load->model('photoVote_model');
        $this->load->model('photoVote_option_model', 'vote_option');
        $this->load->model('photoVote_option_img_model', 'vote_option_img');

        $this->vote_model = $this->photoVote_model;

        //自动开始活动
        $this->db->query("UPDATE `weixin`.`wb_photoVote` SET `status` = '2' WHERE site_id = '".$this->site_id."' AND is_delete = 0 AND status = 1 AND ( (vote_stime <= ".time().") OR (upload_stime <= ".time().") )");
        //自动处理过期活动
        $this->db->query("UPDATE `weixin`.`wb_photoVote` SET `status` = '3' WHERE site_id = '".$this->site_id."' AND is_delete = 0 AND status < 3 AND vote_etime <= ".time());
    }

    public function index()
    {
        $total = $this->vote_model->totals( $this->site_id );
        $pager = $this->_pager( $total, array( 'per_page'=>15, 'base_url'=>site_url($this->uri->uri_string().'?').'&'.http_build_query( $this->input->get() ) ) );
        $list = $this->vote_model->get_list( $this->site_id, array(
                'select' => 'id, title, vote_stime, vote_etime, vote_nums, status, reply_keyword',
                'limit'  => $pager['limit']['value'].', '.$pager['limit']['offset'],
                'order'  => 'id desc'
            ));

        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->data['search'] = $this->input->get();

        $this->load->view( $this->dcm, $this->data );
    }

    public function add_vote()
    {
        $this->data['super_api'] = $this->get_site_wechat_right();//高级接口权限
        if( $this->input->post() ){
            $this->form_validation->set_rules('title', '投票标题', 'trim|required|max_length[255]');
            $this->form_validation->set_rules('vote_stime', '投票开始时间', 'trim|required');
            $this->form_validation->set_rules('vote_etime', '投票结束时间', 'trim|required');
            $this->form_validation->set_rules('banner', '活动banner图', 'trim|required|callback__check_image');

            $this->form_validation->set_rules('upload_stime', '上传开始时间', 'trim');
            $this->form_validation->set_rules('upload_etime', '上传结束时间', 'trim');
            $this->form_validation->set_rules('activity_rule', '活动规则', 'trim|required|htmlspecialchars|max_length[65535]');

            $this->form_validation->set_rules('option_show_rule', '选项顺序', 'trim|required|intval');
            $this->form_validation->set_rules('campaign', '是否支持用户拉票', 'trim|required|intval');

            $this->form_validation->set_rules('auto_attention', '一键关注页面链接', 'trim|trim');

            $this->form_validation->set_rules('reply_keyword', '回复关键词', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('reply_title', '回复标题', 'trim|required|max_length[255]');
            $this->form_validation->set_rules('reply_img', '回复图片', 'trim|required|max_length[255]');
            $this->form_validation->set_rules('reply_desc', '回复描述', 'trim|required|max_length[255]');

            $this->form_validation->set_rules('share_title', '分享标题', 'trim|max_length[50]');
            $this->form_validation->set_rules('share_desc', '分享描述', 'trim|max_length[20]');
            $this->form_validation->set_rules('share_img', '分享图标', 'trim|callback__check_image');

            if ( $this->form_validation->run() ){

                if( !$this->data['super_api'] ){
                    $save_data['auto_attention'] = $this->form_validation->set_value( 'auto_attention' );
                    if( !$save_data['auto_attention'] ){
                        return $this->show_message( FALSE, '请填写一键关注页面链接' );
                    }
                }else{
                    $save_data['auto_attention'] = '';
                }

                $save_data['vote_stime'] = strtotime( $this->form_validation->set_value( 'vote_stime' ) );
                $save_data['vote_etime'] = strtotime( $this->form_validation->set_value( 'vote_etime' ) );
                if( $save_data['vote_stime']>=$save_data['vote_etime'] ){
                    return $this->show_message( FALSE, '投票结束时间必须大于开始时间' );
                }

                //是否支持上传 规则
                $upload_rule = intval( $this->input->post('user_upload') );
                $rule[] = $upload_rule;
                if( $upload_rule ){
                    $upload_nums = intval( $this->input->post('upload_nums') );
                    if( !$upload_nums ){
                        return $this->show_message( FALSE, '限制用户上传图片的数目必须大于0' );
                    }
                    if( $upload_nums>10 ){
                        return $this->show_message( FALSE, '限制用户上传图片的数目最多10张' );
                    }
                    $rule[] = $upload_nums;
                    $save_data['upload_stime'] = strtotime( $this->form_validation->set_value( 'upload_stime' ) );
                    $save_data['upload_etime'] = strtotime( $this->form_validation->set_value( 'upload_etime' ) );
                    if( !$save_data['upload_stime']||!$save_data['upload_etime'] ){
                        return $this->show_message( FALSE, '请填写用户上传选项的时间' );
                    }
                    if( $save_data['upload_etime']<=$save_data['upload_stime'] ){
                        return $this->show_message( FALSE, '上传结束时间必须大于开始时间' );
                    }
                    if( $save_data['upload_etime']>$save_data['vote_etime'] ){
                        return $this->show_message( FALSE, '上传结束时间必须早于投票结束时间' );
                    }
                }
                $save_data['user_upload'] = serialize( $rule );

                $save_data['title'] = $this->form_validation->set_value( 'title' );

                $save_data['banner'] = $this->form_validation->set_value( 'banner' );
                $save_data['activity_rule'] = $this->form_validation->set_value( 'activity_rule' );

                //验证投票规则
                $vote_rule = $this->input->post( 'vote_rule' );
                if( !$vote_rule ){
                    return $this->show_message( FALSE, '请填写投票规则' );
                }
                $vote_rule[0] = intval($vote_rule[0]);
                $vote_rule[1] = intval($vote_rule[1]);
                if( !$vote_rule[0]||!$vote_rule[1] ){
                    return $this->show_message( FALSE, '投票规则必须是大于0的数字' );
                }
                if( $vote_rule[0]>$vote_rule[1] ){
                    return $this->show_message( FALSE, '最多投票数必须大于等于最少投票数' );
                }
                $save_data['user_vote_rule'] = serialize($vote_rule);

                $save_data['option_show_rule'] = $this->form_validation->set_value( 'option_show_rule' );
                $save_data['campaign'] = $this->form_validation->set_value( 'campaign' );


                $save_data['reply_keyword'] = $this->form_validation->set_value( 'reply_keyword' );
                $save_data['reply_title'] = $this->form_validation->set_value( 'reply_title' );
                $save_data['reply_img'] = $this->form_validation->set_value( 'reply_img' );
                $save_data['reply_desc'] = $this->form_validation->set_value( 'reply_desc' );

                $save_data['share_title'] = $this->form_validation->set_value( 'share_title' );
                $save_data['share_img'] = $this->form_validation->set_value( 'share_img' );
                $save_data['share_desc'] = $this->form_validation->set_value( 'share_desc' );

                $save_data['site_id'] = $this->site_id;
                $save_data['add_time'] = $save_data['update_time'] = time();

                if( $this->vote_model->add( $save_data ) ){
                    return $this->show_message( TRUE, '添加成功', '/c/photoVote' );
                }else{
                    return $this->show_message( FALSE, '添加失败' );
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    return $this->show_message(FALSE, $errors, '');
                }
            }
        }else{
            $this->load->view( $this->dcm, $this->data );
        }
    }

    public function edit_vote( $id='' )
    {
        $where['id'] = $id;
        $where['site_id'] = $this->site_id;
        $where['is_delete'] = 0;
        $vote = $this->vote_model->where($where)->find();
        if( !$vote ){
            return $this->show_message( FALSE, '没有找到该投票', '/c/photoVote' );
        }
        $vote['user_upload'] = unserialize( $vote['user_upload'] );
        $vote['user_vote_rule'] = unserialize( $vote['user_vote_rule'] );
        $this->data['info'] = $vote;
        $this->data['super_api'] = $this->get_site_wechat_right();//高级接口权限

        if( $this->input->post() ){
            $this->form_validation->set_rules('title', '投票标题', 'trim|required|max_length[255]');
            $this->form_validation->set_rules('vote_stime', '投票开始时间', 'trim|required');
            $this->form_validation->set_rules('vote_etime', '投票结束时间', 'trim|required');
            $this->form_validation->set_rules('banner', '活动banner图', 'trim|required|callback__check_image');

            $this->form_validation->set_rules('upload_stime', '上传开始时间', 'trim');
            $this->form_validation->set_rules('upload_etime', '上传结束时间', 'trim');
            $this->form_validation->set_rules('activity_rule', '活动规则', 'trim|required|htmlspecialchars|max_length[65535]');

            $this->form_validation->set_rules('option_show_rule', '选项顺序', 'trim|required|intval');
            $this->form_validation->set_rules('campaign', '是否支持用户拉票', 'trim|required|intval');

            $this->form_validation->set_rules('auto_attention', '一键关注页面链接', 'trim|trim');

            $this->form_validation->set_rules('reply_keyword', '回复关键词', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('reply_title', '回复标题', 'trim|required|max_length[255]');
            $this->form_validation->set_rules('reply_img', '回复图片', 'trim|required|max_length[255]');
            $this->form_validation->set_rules('reply_desc', '回复描述', 'trim|required|max_length[255]');

            $this->form_validation->set_rules('share_title', '分享标题', 'trim|max_length[50]');
            $this->form_validation->set_rules('share_desc', '分享描述', 'trim|max_length[20]');
            $this->form_validation->set_rules('share_img', '分享图标', 'trim|callback__check_image');

            if ( $this->form_validation->run() ){

                if( !$this->data['super_api'] ){
                    $save_data['auto_attention'] = $this->form_validation->set_value( 'auto_attention' );
                    if( !$save_data['auto_attention'] ){
                        return $this->show_message( FALSE, '请填写一键关注页面链接' );
                    }
                }else{
                    $save_data['auto_attention'] = '';
                }

                $save_data['vote_stime'] = strtotime( $this->form_validation->set_value( 'vote_stime' ) );
                $save_data['vote_etime'] = strtotime( $this->form_validation->set_value( 'vote_etime' ) );
                if( $save_data['vote_stime']>=$save_data['vote_etime'] ){
                    return $this->show_message( FALSE, '投票结束时间必须大于开始时间' );
                }

                //是否支持上传 规则
                $upload_rule = intval( $this->input->post('user_upload') );
                $rule[] = $upload_rule;
                if( $upload_rule ){
                    $upload_nums = intval( $this->input->post('upload_nums') );
                    if( !$upload_nums ){
                        return $this->show_message( FALSE, '限制用户上传图片的数目必须大于0' );
                    }
                    if( $upload_nums>10 ){
                        return $this->show_message( FALSE, '限制用户上传图片的数目最多10张' );
                    }
                    $rule[] = $upload_nums;
                    $save_data['upload_stime'] = strtotime( $this->form_validation->set_value( 'upload_stime' ) );
                    $save_data['upload_etime'] = strtotime( $this->form_validation->set_value( 'upload_etime' ) );
                    if( !$save_data['upload_stime']||!$save_data['upload_etime'] ){
                        return $this->show_message( FALSE, '请填写用户上传选项的时间' );
                    }
                    if( $save_data['upload_etime']<=$save_data['upload_stime'] ){
                        return $this->show_message( FALSE, '上传结束时间必须大于开始时间' );
                    }
                    if( $save_data['upload_etime']>$save_data['vote_etime'] ){
                        return $this->show_message( FALSE, '上传结束时间必须早于投票结束时间' );
                    }
                }
                $save_data['user_upload'] = serialize( $rule );

                $save_data['title'] = $this->form_validation->set_value( 'title' );

                $save_data['banner'] = $this->form_validation->set_value( 'banner' );
                $save_data['activity_rule'] = $this->form_validation->set_value( 'activity_rule' );

                //验证投票规则
                $vote_rule = $this->input->post( 'vote_rule' );
                if( !$vote_rule ){
                    return $this->show_message( FALSE, '请填写投票规则' );
                }
                $vote_rule[0] = intval($vote_rule[0]);
                $vote_rule[1] = intval($vote_rule[1]);
                if( !$vote_rule[0]||!$vote_rule[1] ){
                    return $this->show_message( FALSE, '投票规则必须是大于0的数字' );
                }
                if( $vote_rule[0]>$vote_rule[1] ){
                    return $this->show_message( FALSE, '最多投票数必须大于等于最少投票数' );
                }
                $save_data['user_vote_rule'] = serialize($vote_rule);

                $save_data['option_show_rule'] = $this->form_validation->set_value( 'option_show_rule' );
                $save_data['campaign'] = $this->form_validation->set_value( 'campaign' );


                $save_data['reply_keyword'] = $this->form_validation->set_value( 'reply_keyword' );
                $save_data['reply_title'] = $this->form_validation->set_value( 'reply_title' );
                $save_data['reply_img'] = $this->form_validation->set_value( 'reply_img' );
                $save_data['reply_desc'] = $this->form_validation->set_value( 'reply_desc' );

                $save_data['share_title'] = $this->form_validation->set_value( 'share_title' );
                $save_data['share_img'] = $this->form_validation->set_value( 'share_img' );
                $save_data['share_desc'] = $this->form_validation->set_value( 'share_desc' );

                $save_data['update_time'] = time();

                if( $this->vote_model->where(array('id'=>$vote['id']))->edit( $save_data ) ){
                    return $this->show_message( TRUE, '修改成功', '/c/photoVote' );
                }else{
                    return $this->show_message( FALSE, '修改失败' );
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    return $this->show_message(FALSE, $errors, '');
                }
            }
        }else{
            $this->load->view( $this->dcm, $this->data );
        }

    }

    public function show_result_vote( $id='' )
    {
        $where['id'] = $id;
        $where['site_id'] = $this->site_id;
        $where['is_delete'] = 0;
        $vote = $this->vote_model->select('id')->where($where)->find();
        if( !$vote ){
            return $this->show_message( FALSE, '没有找到该投票', '/c/photoVote' );
        }

        if( $vote['status']==3 ){
            if( $this->vote_model->where(array('id'=>$vote['id']))->edit(array('show_result'=>1)) ){
                return $this->show_message( TRUE, '修改成功', '/c/photoVote' );
            }else{
                return $this->show_message( FALSE, '修改失败' );
            }
        }else{
            return $this->show_message( FALSE, '该活动还未结束' );
        }

    }

    public function vote_qrcode( $id='' )
    {
        $url = 'http://'.$this->site_info['domain'].BASE_DOMAIN.'/photoVote/?id='.$id;
        $this->load->library( 'qrcode_make' );
        $this->qrcode_make->make_direct($url);
    }

    public function delete_vote( $id='' )
    {
        $where['id'] = $id;
        $where['site_id'] = $this->site_id;
        $where['is_delete'] = 0;
        $vote = $this->vote_model->select('id')->where($where)->find();
        if( !$vote ){
            return $this->show_message( FALSE, '没有找到该投票', '/c/photoVote' );
        }

        if( $this->vote_model->where(array('id'=>$vote['id']))->edit(array('is_delete'=>1)) ){
            return $this->show_message( TRUE, '删除成功', '/c/photoVote' );
        }else{
            return $this->show_message( FALSE, '删除失败' );
        }

    }

    //查看高级接口权限
    private function get_site_wechat_right()
    {
        //从token服务器获取数据
        $this->load->library('Mongo_db');
        $wx = $this->mongo_db->where(array('site_id'=>$this->site_id))->get_one(MONGO_WX_SET);
        if( !$wx ){
            exit('获取微信配置失败');
        }
        if( !isset($wx['hao'])||!$wx['hao'] ){
            exit("请配置您的微信配置信息");
        }
        $is_qrcode_api = 0;//没有高级接口权限

        if( isset($wx['appid'])&&$wx['appid'] ){
            $this->load->library('wbcurl');
            $response = $this->wbcurl->simple_post(TOKEN_WX_SERVER . 'info', array('app_id'=>$wx['appid']));
            $response = json_decode($response,true);
            if( $response['ret']==0 ){
                if( !(2&$response['ability_rank']) ){//没有高级接口权限
                    $is_qrcode_api = 0;
                }else{
                    $is_qrcode_api = 1;
                }
            }else{
                exit($response['msg']);
            }
        }
        return $is_qrcode_api;
    }

    //检查图片格式
    public function _check_image($image) {
        if ($image) {
            if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
                $this->form_validation->set_message('_check_image', '图片地址格式错误');
                return FALSE;
            }
        }
        return TRUE;
    }

    //选项设置(全部)
    public function option_set($vote_id)
    {
        if(!$vote_id) {
            return $this->show_message( FALSE, '非法请求' );
        }
        $vote = $this->_getVote($vote_id);
        if(!$vote) {
            return $this->show_message( FALSE, '非法请求' );
        }

        $where = " vote_id = {$vote_id} AND is_delete = 0 AND site_id = '{$this->site_id}' ";

        $search = array();
        $search['mobile_display'] = $this->input->get_post('mobile_display');
        if($search['mobile_display']) {
            $where .= " AND mobile_display = {$search['mobile_display']}";
        }
        $search['title'] = $this->input->get_post('title');
        if($search['title']) {
            $where .= " AND title like '%{$search['title']}%'";
        }

        $total_rows = $this->vote_option->where($where)
            ->count();
        $search_url = site_url($this->uri->uri_string().'?');
        $base_url = $search_url.http_build_query($search);
        $pager = $this->_pager($total_rows, array('per_page'=>15, 'base_url'=>$base_url));
        $list = $this->vote_option
            ->where($where)
            ->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->order_by('id desc')
            ->find_all();
        $list = $this->_option_set($list);

        $this->data['vote'] = $vote;
        $this->data['search'] = $search;
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->load->view( $this->dcm, $this->data );
    }

    //添加选项
    public function add_option($vote_id)
    {
        if(!$vote_id) {
            return $this->show_message( FALSE, '非法请求' );
        }

        $vote = $this->_getVote($vote_id);
        if(!$vote) {
            return $this->show_message( FALSE, '非法请求' );
        }

        if($vote['status']==3) {
            return $this->show_message( FALSE, '活动已结束' );
        }
        $option_sn = $this->createSn($vote_id);

        if( $this->input->post() ){
            $this->form_validation->set_rules('title', '选项名称', 'trim|required|max_length[50]');
            if ( $this->form_validation->run() ){
                $save_data['title'] = $this->form_validation->set_value('title');
                $save_data['top'] = $this->input->post('top');
                $save_data['option_sn'] = $option_sn;
                $save_data['add_time'] = time();
                $save_data['vote_id'] = $vote_id;
                $save_data['site_id'] = $this->site_id;
            }else{
                $errors = validation_errors();
                if ($errors) {
                    return $this->show_message(FALSE, $errors, '');
                }
            }
            if( !$option_id = $this->vote_option->add($save_data) ){
                //dump($this->db->last_query());exit;
                return $this->show_message( false, '添加失败' );
            }else{
                $img = $this->input->post('img');
                if( $img ){
                    foreach ($img as $k => $v){
                        $this->vote_option_img->add(array(
                            'option_id' => $option_id,
                            'img' => $v['img'],
                            'intro' => $v['intro'],
                            'media' => htmlspecialchars($v['media']),
                            'url' => prep_url($v['url'])
                        ));
                    }
                }
                return $this->show_message( TRUE, '添加成功', '/c/photoVote/option_set/'.$vote_id );
            }

        }else{
            $this->data['vote'] = $vote;
            $this->data['option_sn'] = $option_sn;
            $this->load->view($this->dcm, $this->data);
        }
    }

    /**
     *
     * @author Qianc
     * @date 2014-8-29
     * @description 生成随机邀请码
     */
    protected function createSn($vote_id)
    {
        if(intval($vote_id)){
            $randCode = null;
            $isBreak = false;
            do
            {
                $randCode = mt_rand(1000, 9999);    # 推入随机数
                $where['vote_id'] = intval($vote_id);
                $where['option_sn'] = "V".$randCode;
                $count = $this->vote_option
                    ->select('option_sn')
                    ->where($where)->count();
                $isBreak = $count > 0 ? false : true;
            }while (!$isBreak) ;
            return "V".$randCode;
        }
    }


    /**
     *
     * @author Qianc
     * @date 2014-11-21
     * @description 获取一条投票信息
     */
    protected function _getVote($vote_id, $field = "*")
    {
        $where['id'] = $vote_id;
        $where['site_id'] = $this->site_id;

        $vote = $this->vote_model->select($field)->where($where)->find();
        return $vote;
    }


    //编辑选项
    public function edit_option($option_id)
    {
        if(!$option_id) {
            return $this->show_message( FALSE, '非法请求' );
        }
        $option = $this->_getOption($option_id);
        if( !$option ){
            return $this->show_message(false, '没有找到您要操作的数据', '');
        }
        $imgs = $this->_getImgs($option_id);

        if( $this->input->post() ){
            $this->form_validation->set_rules('option_sn', '选项编号', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('title', '选项名称', 'trim|required|max_length[50]');
            if ( $this->form_validation->run() ){
                $save_data['option_sn'] = $this->form_validation->set_value('option_sn');
                $save_data['title'] = $this->form_validation->set_value('title');
                $save_data['top'] = $this->input->post('top');
            }else{
                $errors = validation_errors();
                if ($errors) {
                    return $this->show_message(FALSE, $errors, '');
                }
            }
            if( !$this->vote_option->where(array('id'=>$option_id))->edit($save_data) )  {
                return $this->show_message( false, '操作失败' );
            }else{
                $this->vote_option_img->where(array('option_id'=>$option_id))->delete();
                $img = $this->input->post('img');
                if( $img ){
                    foreach ($img as $k => $v){
                        $this->vote_option_img->add(array(
                            'option_id' => $option_id,
                            'img' => $v['img'],
                            'intro' => $v['intro'],
                            'media' => htmlspecialchars($v['media']),
                            'url' => prep_url($v['url'])
                        ));
                    }
                }
                return $this->show_message( TRUE, '操作成功', '/c/photoVote/option_set/'.$option['vote_id'] );
            }

        }else{
            $this->data['option'] = $option;
            $this->data['imgs'] = $imgs;

            $this->load->view($this->dcm, $this->data);
        }
    }


    /**
     *
     * @author Qianc
     * @date 2014-11-22
     * @description 获取一条选项信息
     */
    protected function _getOption($option_id, $field = "*")
    {
        $where['id'] = $option_id;
        $where['site_id'] = $this->site_id;
        $where['is_delete'] = 0;

        $option = $this->vote_option->select($field)->where($where)->find();
        return $option;
    }

    /**
     *
     * @author Qianc
     * @date 2014-11-22
     * @description 获取选项图片信息
     */
    protected function _getImgs($option_id, $field = "*")
    {
        $where['option_id'] = $option_id;

        $imgs = $this->vote_option_img->select($field)->where($where)->find_all();
        return $imgs;
    }

    /**
     *
     * @author Qianc
     * @date 2014-11-22
     * @description 删除选项
     */
    public function del_option($option_id = '')
    {
        if( !$option_id ){
            return $this->show_message(false, '非法请求', '');
        }

        $option = $this->_getOption($option_id);
        if( !$option ){
            return $this->show_message( false, '没有找到您要操作的数据');
        }

        if( $this->vote_option->where(array('id'=>$option_id))->edit(array('is_delete'=>1))){
            $this->vote_option_img->where(array('option_id'=>$option_id))->delete();
            return $this->show_message( TRUE, '删除成功', '/c/photoVote/option_set/'.$option['vote_id'] );
        }else{
            exit(json_encode(array('ret' => 1,'msg' => '删除失败')));
        }
    }

    /**
     *
     * @author Qianc
     * @date 2014-11-22
     * @description 处理数据
     */
    private function _option_set($list = array())
    {
        if($list){
            foreach($list as $k => $v){
                $imgs = $this->_getImgs($v['id']);
                $list[$k]['img'] = $imgs && $imgs[0] ? $imgs[0]: array();
            }
            return $list;
        }
    }


    //Option_sn检测
    public function ajaxOption_sn()
    {
        $option_sn = $this->input->post('option_sn',true);
        $option_id = $this->input->post('option_id',true);
        $vote_id = $this->input->post('vote_id',true);
        if(!$option_sn || !$option_id || !$vote_id){
            exit(json_encode(array('ret'=> 1, 'msg' => '非法访问' )));
        }


        $where['vote_id'] = intval($vote_id);
        $where['option_sn'] = $option_sn;
        $where['id !='] = $option_id;
        $count = $this->vote_option
            ->select('option_sn')
            ->where($where)->count();

        if($count >= 1){
            exit(json_encode(array('ret'=> 1, 'msg' => '编号已存在' )));
        }
        exit(json_encode(array('ret'=> 0)));
    }


}