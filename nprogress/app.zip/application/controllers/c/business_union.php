<?php
/**
 * 微商联盟活动
 */
//                            _ooOoo_
//                           o8888888o
//                           88" . "88
//                           (| -_- |)
//                            O\ = /O
//                        ____/`---'\____
//                      .   ' \\| |// `.
//                       / \\||| : |||// \
//                     / _||||| -:- |||||- \
//                       | | \\\ - /// | |
//                     | \_| ''\---/'' |_/ |
//                      \ .-\__ `-` ___/-. /
//                   ___`. .' /--.--\ `. . ___
//                ."" '< `.___\_<|>_/___.' >' "".
//               | | : `- \`.;`\ _ /`;.`/ - ` : | |
//                 \ \ `-. \_ __\ /__ _/ .-` / /
//         ======`-.____`-.___\_____/___.-`____.-'======
//                            `=---='
//         .............................................
//         ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//                     佛祖保佑       永无BUG

class business_union extends C_Controller{

    private $site_id = '';

    public function __construct()
    {
        parent::__construct();
        $this->site_id = $this->site_info['id'];
        $this->load->model('business_union_model');
        $this->load->model('business_prize_model');
        $this->load->model('business_apply_model');
        $this->load->model('business_material_model');
        $this->load->model('business_lottery_model');
    }

    /**
     *
     * @author Qianc
     * @date 2014-8-21
     * @description 活动列表(全部)
     */
    public function index()
    {
        $where = array();
        $where['is_delete'] = 0;
        //$where['online'] = 1;

        $search['start_date'] = $this->input->get('start_date');
        $search['end_date'] = $this->input->get('end_date');
        $search['province'] = $this->input->get('province');
        $search['city'] = $this->input->get('city');
        $search['keyword'] = $this->input->get('keyword');

        $search['start_date'] ? $where['end_time >='] = strtotime($search['start_date']) : '';
        $search['end_date'] ? $where['end_time <='] = strtotime($search['end_date']) : '';
        $search['province'] ? ($search['province'] == '全国' ? '' : $where['condition_province'] = $search['province']) : '';
        $search['city'] ? $where['condition_city'] = $search['city'] : '';
        $search['keyword'] ? $where['title like '] = "%{$search['keyword']}%" : '';

        $search_url = site_url($this->uri->uri_string().'?');
        $base_url = $search_url.http_build_query($search);
        $this->data['search'] = $search;

        $total_rows = $this->business_union_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$base_url));
        $this->data['page'] = $pager['links'];


        $list = $this->business_union_model
            ->select('*')
            ->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->where($where)->order_by('wb_business_union.online desc, wb_business_union.end_time desc, wb_business_union.id desc')->find_all();

        $list = $this->_index($list);
        $this->data['offset'] = $pager['limit']['offset'];
        $this->data['list'] = $list;
        $this->data['site_id'] = $this->site_id;

        $this->load->view($this->dcm,$this->data);
    }


    /**
     *
     * @author Qianc
     * @date 2014-8-25
     * @description 活动列表(我发起的)
     */
    public function sponsorMe()
    {
        $where = array();
        $where['site_id'] = $this->site_id;
        $where['is_delete'] = 0;

        $search['online'] = $this->input->get('online');
        $search['start_date'] = $this->input->get('start_date');
        $search['end_date'] = $this->input->get('end_date');
        $search['province'] = $this->input->get('province');
        $search['city'] = $this->input->get('city');
        $search['keyword'] = $this->input->get('keyword');

        $search['online'] !='' ? $where['online'] = $search['online'] : '';
        $search['start_date'] ? $where['end_time >='] = strtotime($search['start_date']) : '';
        $search['end_date'] ? $where['end_time <='] = strtotime($search['end_date']) : '';
        $search['province'] ? ($search['province'] == '全国' ? '' : $where['condition_province'] = $search['province']) : '';
        $search['city'] ? $where['condition_city'] = $search['city'] : '';
        $search['keyword'] ? $where['title like '] = "%{$search['keyword']}%" : '';

        $search_url = site_url($this->uri->uri_string().'?');
        $base_url = $search_url.http_build_query($search);
        $this->data['search'] = $search;

        $total_rows = $this->business_union_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$base_url));
        $this->data['page'] = $pager['links'];


        $list = $this->business_union_model
            ->select('*')
            ->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->where($where)->order_by('wb_business_union.online desc, wb_business_union.end_time desc, wb_business_union.id desc')->find_all();
        $this->data['offset'] = $pager['limit']['offset'];
        $list = $this->_sponsorMe($list);
        $this->data['list'] = $list;

        $this->load->view($this->dcm,$this->data);

    }

    /**
     *
     * @author Qianc
     * @date 2014-8-25
     * @description 活动列表(我参与的)
     */
    public function joinMe()
    {
        $where = array();
        $where['wb_business_union.is_delete'] = 0;
        $where['wb_business_apply.site_id'] = $this->site_id;
        //搜索
        $search['start_date'] = $this->input->get('start_date');
        $search['end_date'] = $this->input->get('end_date');
        $search['province'] = $this->input->get('province');
        $search['city'] = $this->input->get('city');
        $search['keyword'] = $this->input->get('keyword');

        $search['start_date'] ? $where['wb_business_union.end_time >='] = strtotime($search['start_date']) : '';
        $search['end_date'] ? $where['wb_business_union.end_time <='] = strtotime($search['end_date']) : '';
        $search['province'] ? ($search['province'] == '全国' ? '' : $where['condition_province'] = $search['province']) : '';
        $search['city'] ? $where['wb_business_union.condition_city'] = $search['city'] : '';
        $search['keyword'] ? $where['wb_business_union.title like '] = "%{$search['keyword']}%" : '';

        $search_url = site_url($this->uri->uri_string().'?');
        $base_url = $search_url.http_build_query($search);
        $this->data['search'] = $search;

        $total_rows = $this->business_union_model
            ->join('wb_business_apply','wb_business_union.id = wb_business_apply.activity_id')
            ->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$base_url));
        $this->data['page'] = $pager['links'];



        $list = $this->business_union_model
            ->select('wb_business_union.*, wb_business_apply.invite_code, wb_business_apply.id AS applyId')
            ->join('wb_business_apply','wb_business_union.id = wb_business_apply.activity_id')
            ->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->where($where)->order_by('wb_business_union.online desc, wb_business_union.end_time desc, wb_business_union.id desc')->find_all();
        $list = $this->_index($list);
        $this->data['list'] = $list;
        $this->data['offset'] = $pager['limit']['offset'];

        $this->load->view($this->dcm,$this->data);
    }


    //添加活动
    public function add_activity()
    {
        $this->load->model('user_model');
        $site_info = $this->user_model->find($this->site_id);
        $this->data['site_info'] = $site_info;
        if( $this->input->post() ){
            $this->form_validation->set_rules('title', '标题', 'trim|required|max_length[255]');
            $this->form_validation->set_rules('start_time', '开始时间', 'trim|required|max_length[30]');
            $this->form_validation->set_rules('end_time', '结束时间', 'trim|required|max_length[30]');
            $this->form_validation->set_rules('condition_province', '参与条件省份', 'trim|required|max_length[30]');
            $this->form_validation->set_rules('condition_city', '参与条件市', 'trim|max_length[30]');
            $this->form_validation->set_rules('lottery_days', '可抽奖天数', 'trim|required|is_natural_no_zero');
            $this->form_validation->set_rules('guide_article', '活动文章地址', 'trim|required|max_length[255]');
            $this->form_validation->set_rules('award_business', '奖品发放方', 'trim|required|max_length[255]');
            $this->form_validation->set_rules('award_name', '发奖方名称', 'trim|required|max_length[255]');
            $this->form_validation->set_rules('award_contact', '发奖方联系方式', 'trim|required|max_length[255]');
            $this->form_validation->set_rules('award_address', '发奖方地址', 'trim|max_length[255]');
            if ( $this->form_validation->run() ){
                $save_data['title'] = $this->form_validation->set_value('title');
                $start_time = $this->form_validation->set_value('start_time');
                $end_time = $this->form_validation->set_value('end_time');
                if( strtotime($start_time)&&strtotime($end_time) ){
                    $save_data['start_time'] = strtotime($start_time);
                    $save_data['end_time'] = strtotime($end_time);
                    if( $save_data['start_time']>=$save_data['end_time'] ){
                        return $this->show_message(false, '开始时间必须小于结束时间', '');
                    }
                }else{
                    return $this->show_message(false, '请填写正确的开始时间和结束时间', '');
                }

                if( $this->form_validation->set_value('award_business') == 3 && !$this->form_validation->set_value('award_address')){
                    return $this->show_message(false, '请填写活动发起方地址', '');
                }
                $save_data['condition_province'] = $this->form_validation->set_value('condition_province');
                $save_data['condition_city'] = $this->form_validation->set_value('condition_city');
                $save_data['lottery_days'] = $this->form_validation->set_value('lottery_days');
                $save_data['guide_article'] = $this->form_validation->set_value('guide_article');
                $save_data['award_business'] = $this->form_validation->set_value('award_business');
                $save_data['award_name'] = $this->form_validation->set_value('award_name');
                $save_data['award_contact'] = $this->form_validation->set_value('award_contact');
                $save_data['award_address'] = $save_data['award_business'] == 3 ? $this->form_validation->set_value('award_address') : '';

                //添加
                $save_data['site_id'] = $this->site_id;
                $save_data['add_time'] = $save_data['update_time'] = time();
                if($this->business_union_model->add($save_data)){
                }else{
                    $this->show_message(false, '添加失败', '');return FALSE;
                }
                $this->show_message(true, '添加成功', '/c/business_union/sponsorMe');return FALSE;
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            $this->load->view($this->dcm, $this->data);
        }
    }

    //修改活动
    public function edit_activity($id=0)
    {
        if( !$id ){
            return $this->show_message(false, '参数不全', '');
        }

        $where['site_id'] = $this->site_id;
        $where['id'] = $id;
        $where['is_delete'] = 0;
        $activity = $this->business_union_model->where($where)->find();
        if( !$activity ){
            return $this->show_message(false, '没有找到您要修改的活动', '');
        }
        if( $this->input->post() ){
            $this->form_validation->set_rules('title', '标题', 'trim|required|max_length[255]');
            $this->form_validation->set_rules('start_time', '开始时间', 'trim|required|max_length[30]');
            $this->form_validation->set_rules('end_time', '结束时间', 'trim|required|max_length[30]');
            $this->form_validation->set_rules('condition_province', '参与条件省份', 'trim|required|max_length[30]');
            $this->form_validation->set_rules('condition_city', '参与条件市', 'trim|max_length[30]');
            $this->form_validation->set_rules('lottery_days', '可抽奖天数', 'trim|required|is_natural_no_zero');
            $this->form_validation->set_rules('guide_article', '活动文章地址', 'trim|required|max_length[255]');
            $this->form_validation->set_rules('award_business', '奖品发放方', 'trim|required|max_length[255]');
            $this->form_validation->set_rules('award_name', '发奖方名称', 'trim|required|max_length[255]');
            $this->form_validation->set_rules('award_contact', '发奖方联系方式', 'trim|required|max_length[255]');
            $this->form_validation->set_rules('award_address', '发奖方地址', 'trim|max_length[255]');
            if ( $this->form_validation->run() ){
                $save_data['title'] = $this->form_validation->set_value('title');
                $start_time = $this->form_validation->set_value('start_time');
                $end_time = $this->form_validation->set_value('end_time');
                if( strtotime($start_time)&&strtotime($end_time) ){
                    $save_data['start_time'] = strtotime($start_time);
                    $save_data['end_time'] = strtotime($end_time);
                    if( $save_data['start_time']>=$save_data['end_time'] ){
                        return $this->show_message(false, '开始时间必须小于结束时间', '');
                    }
                }else{
                    return $this->show_message(false, '请填写正确的开始时间和结束时间', '');
                }

                if( $this->form_validation->set_value('award_business') == 3 && !$this->form_validation->set_value('award_address')){
                    return $this->show_message(false, '请填写活动发起方地址', '');
                }
                $save_data['condition_province'] = $this->form_validation->set_value('condition_province');
                $save_data['condition_city'] = $this->form_validation->set_value('condition_city');
                $save_data['lottery_days'] = $this->form_validation->set_value('lottery_days');
                $save_data['guide_article'] = $this->form_validation->set_value('guide_article');
                $save_data['award_business'] = $this->form_validation->set_value('award_business');
                $save_data['award_name'] = $this->form_validation->set_value('award_name');
                $save_data['award_contact'] = $this->form_validation->set_value('award_contact');
                $save_data['award_address'] = $save_data['award_business'] == 3 ? $this->form_validation->set_value('award_address') : '';

                //修改
                $save_data['update_time'] = time();
                if($this->business_union_model->where($where)->edit($save_data)){
                }else{
                    $this->show_message(false, '修改失败', '');return FALSE;
                }
                $this->show_message(true, '修改成功', '/c/business_union/sponsorMe');return FALSE;
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            $this->data['info'] = $activity;
            $this->load->view($this->dcm, $this->data);
        }
    }

    /**
     * 奖品列表
     * @param int $id 活动id
     */
    public function prize_list($id=0)
    {
        if( !$id ){
            return $this->show_message(false, '缺少参数', '');
        }
        $activity = $this->business_union_model->where(array('site_id'=>$this->site_id,'id'=>$id,'is_delete'=>0))->find();
        if( !$activity ){
            return $this->show_message(false, '没有找到您要修改的活动', '');
        }

        $where['activity_id'] = $activity['id'];
        $where['is_delete'] = 0;
        $total_rows = $this->business_prize_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>site_url($this->uri->uri_string().'?')));
        $this->data['page'] = $pager['links'];

        $list = $this->business_prize_model
            ->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->where($where)->order_by('id asc')->find_all();
        $this->data['offset'] = $pager['limit']['offset'];
        $this->data['list'] = $list;

        $this->data['activity'] = $activity;
        $this->load->view($this->dcm,$this->data);
    }

    /**
     * 添加奖品
     * @param int $id 活动id
     */
    public function add_activity_prize($id=0)
    {
        if( !$id ){
            return $this->show_message(false, '参数不全', '');
        }
        $where['site_id'] = $this->site_id;
        $where['id'] = $id;
        $where['is_delete'] = 0;
        $activity = $this->business_union_model->where($where)->find();
        if( !$activity ){
            return $this->show_message(false, '没有找到您要修改的活动', '');
        }
        if( $this->input->post() ){
            $this->form_validation->set_rules('name', '奖品名称', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('stock', '库存', 'trim|required|numeric');
            $this->form_validation->set_rules('rate', '中奖率', 'trim|required|numeric');
            if ( $this->form_validation->run() ){
                $save_data['name'] = $this->form_validation->set_value('name');
                $save_data['stock'] = $this->form_validation->set_value('stock');
                $save_data['rate'] = $this->form_validation->set_value('rate');
                if( !preg_match('/^[0-9]*\.?[0-9]{0,2}$/', $save_data['rate']) ){
                    return $this->show_message(FALSE, '中奖率最多两位小数', '');
                }
                if( ( ($this->countRates($activity['id']))+$save_data['rate'] )>100 ){
                    return $this->show_message(FALSE, '所有奖品的概率总和不能超过100%', '');
                }
                //添加
                $save_data['activity_id'] = $activity['id'];
                $save_data['site_id'] = $this->site_id;
                $save_data['add_time'] = time();
                if($this->business_prize_model->add($save_data)){
                }else{
                    return $this->show_message(false, '添加失败', '');
                }
                return $this->show_message(true, '添加成功', '/c/business_union/prize_list/'.$activity['id']);
            }else{
                $errors = validation_errors();
                if ($errors) {
                    return $this->show_message(FALSE, $errors, '');
                }
            }
        }else{
            $this->data['activity'] = $activity;
            $this->load->view($this->dcm, $this->data);
        }
    }

    /**
     * 修改奖品
     * @param int $id 活动id
     * int prizeId 奖品id
     */
    public function edit_activity_prize($id=0)
    {
        $prizeId = $this->input->get('prizeId');
        if( !$id||!$prizeId ){
            return $this->show_message(false, '参数不全', '');
        }
        $where['site_id'] = $this->site_id;
        $where['id'] = $id;
        $where['is_delete'] = 0;
        $activity = $this->business_union_model->where($where)->find();
        if( !$activity ){
            return $this->show_message(false, '没找到该活动', '');
        }
        $prize = $this->business_prize_model->where(array('activity_id'=>$activity['id'],'id'=>$prizeId,'is_delete'=>0))->find();
        if( !$prize ){
            return $this->show_message(false, '没有找到该奖品', '');
        }
        if( $this->input->post() ){
            $this->form_validation->set_rules('name', '奖品名称', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('stock', '库存', 'trim|required|numeric');
            $this->form_validation->set_rules('rate', '中奖率', 'trim|required|numeric');
            if ( $this->form_validation->run() ){
                $save_data['name'] = $this->form_validation->set_value('name');
                $save_data['stock'] = $this->form_validation->set_value('stock');
                $save_data['rate'] = $this->form_validation->set_value('rate');
                if( !preg_match('/^[0-9]*\.?[0-9]{0,2}$/', $save_data['rate']) ){
                    return $this->show_message(FALSE, '中奖率最多两位小数', '');
                }
                if( ( ($this->countRates($activity['id'],$prize['id']))+$save_data['rate'] )>100 ){
                    return $this->show_message(FALSE, '所有奖品的概率总和不能超过100%', '');
                }
                //修改
                if($this->business_prize_model->where(array('activity_id'=>$activity['id'],'id'=>$prize['id']))->edit($save_data)){
                }else{
                    return $this->show_message(false, '修改失败', '');
                }
                return $this->show_message(true, '修改成功', '/c/business_union/prize_list/'.$activity['id']);
            }else{
                $errors = validation_errors();
                if ($errors) {
                    return $this->show_message(FALSE, $errors, '');
                }
            }
        }else{
            $this->data['activity'] = $activity;
            $this->data['info'] = $prize;
            $this->load->view($this->dcm, $this->data);
        }
    }

    /**
     * @param int $id 活动id
     * int prizeId 奖品id
     */
    public function delete_activity_prize($id=0)
    {
        $prizeId = $this->input->get('prizeId');
        if( !$id||!$prizeId ){
            return $this->show_message(false, '参数不全', '');
        }
        $where['site_id'] = $this->site_id;
        $where['id'] = $id;
        $where['is_delete'] = 0;
        $activity = $this->business_union_model->where($where)->find();
        if( !$activity ){
            return $this->show_message(false, '没找到该活动', '');
        }
        $prize = $this->business_prize_model->where(array('activity_id'=>$activity['id'],'id'=>$prizeId,'is_delete'=>0))->find();
        if( !$prize ){
            return $this->show_message(false, '没有找到该奖品', '');
        }

        if( $this->business_prize_model->where(array('activity_id'=>$activity['id'],'id'=>$prizeId,'is_delete'=>0))->edit(array('is_delete'=>1)) ){
            return $this->show_message(true, '删除奖品成功', '/c/business_union/prize_list/'.$activity['id']);
        }else{
            return $this->show_message(false, '删除奖品失败', '');
        }
    }

    /**
     * 计算概率总和
     * @param $activityId 活动id
     * @param int $id 奖品id
     * @return mixed
     */
    private function countRates($activityId, $id=0)
    {
        $where['activity_id'] = $activityId;
        if( $id ){
            $where['id !='] = $id;
        }
        $countRates = $this->business_prize_model->where($where)->sum('rate');
        return $countRates;
    }

    //活动上线/下线
    public function on_off_line($id=0)
    {
        if( !$id ){
            exit(json_encode(array('ret' => 1,'msg' => '非法修改')));
        }

        $where['site_id'] = $this->site_id;
        $where['id'] = $id;
        $where['is_delete'] = 0;
        $activity = $this->business_union_model->where($where)->find();
        if( !$activity ){
            exit(json_encode(array('ret' => 1,'msg' => '没有找到您要修改的活动')));
        }

        $online = $activity['online'] ? 0 : 1;
        if( $this->business_union_model->where($where)->edit(array('online'=>$online)) ){
            exit(json_encode(array('ret' => 0,'msg' => '修改成功')));
        }else{
            exit(json_encode(array('ret' => 1,'msg' => '修改失败')));
        }
    }

    //活动删除
    public function delete_activity($id=0)
    {
        if( !$id ){
            exit(json_encode(array('ret' => 1,'msg' => '非法修改')));
        }

        $where['site_id'] = $this->site_id;
        $where['id'] = $id;
        $where['is_delete'] = 0;
        $activity = $this->business_union_model->where($where)->find();
        if( !$activity ){
            exit(json_encode(array('ret' => 1,'msg' => '没有找到您要修改的活动')));
        }

        if( $this->business_union_model->where($where)->edit(array('is_delete'=>1)) ){
            exit(json_encode(array('ret' => 0,'msg' => '删除成功')));
        }else{
            exit(json_encode(array('ret' => 1,'msg' => '删除失败')));
        }
    }

    //检查图片格式
    public function _check_image($image) {
        if ($image) {
            if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
                $this->form_validation->set_message('_check_image', '图片地址格式错误');
                return FALSE;
            }
        }
        return TRUE;
    }

    /**
     * 申请活动
     * @param int $id 活动id
     */
    public function apply_activity($id=0)
    {
        if( !$id ){
            return $this->show_message(false, '参数不全', '');
        }
        $where['site_id !='] = $this->site_id;
        $where['id'] = $id;
        $where['is_delete'] = 0;
        $where['online'] = 1;
        $activity = $this->business_union_model->where($where)->find();
        if( !$activity ){
            return $this->show_message(false, '没找到该活动或您不符合申请条件', '');
        }
        if( $this->check_site_apply_activity($this->site_id,$activity['id']) ){
            return $this->show_message(false, '您已申请过该活动，不能重复申请', '');
        }
        if( $this->input->post() ){
            $this->form_validation->set_rules('name', '联系人', 'trim|required|max_length[255]');
            $this->form_validation->set_rules('contact', '联系方式', 'trim|required|max_length[30]');
            $this->form_validation->set_rules('weixin', '微信号', 'trim|max_length[50]');
            $this->form_validation->set_rules('fans', '粉丝数量', 'trim|required|is_natural');
            $this->form_validation->set_rules('fans_img', '粉丝数量截图', 'trim|required|max_length[255]|callback__check_image');
            $this->form_validation->set_rules('introduction', '详细说明', 'trim|max_length[5000]|htmlspecialchars');
            if ( $this->form_validation->run() ){
                $save_data['name'] = $this->form_validation->set_value('name');
                $save_data['contact'] = $this->form_validation->set_value('contact');
                $save_data['weixin'] = $this->form_validation->set_value('weixin');
                $save_data['fans'] = $this->form_validation->set_value('fans');
                $save_data['fans_img'] = $this->form_validation->set_value('fans_img');
                $save_data['introduction'] = $this->form_validation->set_value('introduction');

                //添加
                $save_data['site_id'] = $this->site_id;
                $save_data['to_site_id'] = $activity['site_id'];
                $save_data['activity_id'] = $activity['id'];
                $save_data['add_time'] = time();
                if($this->business_apply_model->add($save_data)){
                    $this->business_union_model->where(array('id'=>$activity['id']))->set_inc('apply_nums',null,1);
                    return $this->show_message(true, '申请成功', '/c/business_union/index');
                }else{
                    $this->show_message(false, '申请失败', '');return FALSE;
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    return $this->show_message(FALSE, $errors, '');
                }
            }
        }else{
            $this->data['activity'] = $activity;
            $this->data['site_info_company'] = $this->site_info['company'];
            $this->data['site_info_contact_name'] = $this->site_info['contact_name'];
            $this->data['site_info_contact_mobile'] = $this->site_info['contact_mobile'];
            $this->load->view($this->dcm, $this->data);
        }
    }

    /**
     * @param int $id 活动id
     * @param int $applyId 申请id
     */
    public function apply_activity_edit($id=0)
    {
        $applyId = $this->input->get('applyId');
        if( !$id||!$applyId ){
            return $this->show_message(false, '参数不全', '');
        }
        $where['site_id !='] = $this->site_id;
        $where['id'] = $id;
        $where['is_delete'] = 0;
        $activity = $this->business_union_model->where($where)->find();
        if( !$activity ){
            return $this->show_message(false, '没找到该活动', '');
        }

        $apply = $this->business_apply_model->where(array('site_id'=>$this->site_id,'activity_id'=>$activity['id']))->find();
        if( $apply['status']!=1 ){
            return $this->show_message(false, '您的申请已被商家受理，不能再修改', '');
        }
        if( $this->input->post() ){
            $this->form_validation->set_rules('name', '联系人', 'trim|required|max_length[255]');
            $this->form_validation->set_rules('contact', '联系方式', 'trim|required|max_length[30]');
            $this->form_validation->set_rules('weixin', '微信号', 'trim|max_length[50]');
            $this->form_validation->set_rules('fans', '粉丝数量', 'trim|required|is_natural');
            $this->form_validation->set_rules('fans_img', '粉丝数量截图', 'trim|required|max_length[255]|callback__check_image');
            $this->form_validation->set_rules('introduction', '详细说明', 'trim|max_length[5000]|htmlspecialchars');
            if ( $this->form_validation->run() ){
                $save_data['name'] = $this->form_validation->set_value('name');
                $save_data['contact'] = $this->form_validation->set_value('contact');
                $save_data['weixin'] = $this->form_validation->set_value('weixin');
                $save_data['fans'] = $this->form_validation->set_value('fans');
                $save_data['fans_img'] = $this->form_validation->set_value('fans_img');
                $save_data['introduction'] = $this->form_validation->set_value('introduction');

                //添加
                $save_data['site_id'] = $this->site_id;
                $save_data['to_site_id'] = $activity['site_id'];
                $save_data['activity_id'] = $activity['id'];
                if($this->business_apply_model->where(array('site_id'=>$this->site_id,'activity_id'=>$activity['id'],'status'=>$apply['status']))->edit($save_data)){
                    return $this->show_message(true, '修改成功', '/c/business_union/index/3');
                }else{
                    $this->show_message(false, '修改失败', '');return FALSE;
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    return $this->show_message(FALSE, $errors, '');
                }
            }
        }else{
            $this->data['apply'] = $apply;
            $this->data['activity'] = $activity;
            $this->data['site_info_company'] = $this->site_info['company'];
            $this->load->view($this->dcm, $this->data);
        }
    }

    /**
     * 查看申请信息
     * @param int $id 活动id
     * @param int $applyId 申请信息id
     */
    public function apply_info($id=0)
    {
        $applyId = $this->input->get('applyId');
        if( !$id||!$applyId ){
            return $this->show_message(false, '参数不全', '');
        }
        $where['site_id !='] = $this->site_id;
        $where['id'] = $id;
        $where['is_delete'] = 0;
        $activity = $this->business_union_model->where($where)->find();
        if( !$activity ){
            return $this->show_message(false, '没找到该活动', '');
        }
        $apply = $this->business_apply_model->where(array('id'=>$applyId,'activity_id'=>$activity['id']))->find();
        if( !$apply ){
            return $this->show_message(false, '没有找到该申请信息', '/c/business_union/index/2');
        }
        $this->data['activity'] = $activity;
        $this->data['apply'] = $apply;
        $this->load->view($this->dcm, $this->data);
    }

    /**
     * 判断是否可以申请
     * @param $site_id 申请人的微网站id
     * @param $activity_id 活动id
     * @return bool
     */
    public function check_site_apply_activity($site_id,$activity_id, $field = "*")
    {
        $apply = $this->business_apply_model->select($field)->where(array('site_id'=>$site_id,'activity_id'=>$activity_id))->find();
        return ($apply ? $apply : false);
    }

    /**
     *
     * @author Qianc
     * @date 2014-8-25
     * @description 处理数据
     */
    private function _index($list = array())
    {
        if($list){
            $this->load->model('business_prize_model');
            foreach($list as $k => $v){
                $user = $this->_getOneUser($v['site_id'], 'company');
                $list[$k]['sponsor'] = ($user && $user['company']) ?  $user['company'] : '';
                $list[$k]['short_description'] = ($v && $v['description']) ? cut($v['description'], 8, '...') : '';
                /*$list[$k]['start_time'] = ($v && $v['start_time']) ? date("Y-m-d", $v['start_time']) : '';
                $list[$k]['end_time'] = ($v && $v['end_time']) ? date("Y-m-d", $v['end_time']) : '';*/
                $applyRs = $this->check_site_apply_activity($this->site_id, $v['id'], 'status, id');
                if($applyRs && $applyRs['status']){
                    $list[$k]['status'] = $applyRs['status'];
                    $list[$k]['applyId'] = $applyRs['id'];
                }else{
                    $list[$k]['status'] = 0;//未申请
                }

                $list[$k]['prizes'] = $this->business_prize_model->select('name,rate,stock')->where(array('activity_id'=>$v['id'],'is_delete'=>0))->order_by('id asc')->find_all();
            }
            return $list;
        }
    }

    /**
     *
     * @author Qianc
     * @date 2014-8-26
     * @description 处理数据
     */
    private function _sponsorMe($list = array())
    {
        if($list){
            foreach($list as $k => $v){
                $user = $this->_getOneUser($v['site_id'], 'company');
                $list[$k]['sponsor'] = ($user && $user['company']) ?  $user['company'] : '';
                $list[$k]['short_description'] = ($v && $v['description']) ? cut($v['description'], 8, '...') : '';
                $list[$k]['start_time'] = ($v && $v['start_time']) ? date("Y-m-d", $v['start_time']) : '';
                $list[$k]['end_time'] = ($v && $v['end_time']) ? date("Y-m-d", $v['end_time']) : '';
                $list[$k]['countApplys'] = ($v && $v['id']) ? $this->countApplys($v['id']) : '0';
            }
            return $list;
        }
    }


    /**
     *
     * @author Qianc
     * @date 2014-8-25
     * @description 待审核用户数
     */
    protected function countApplys($activity_id)
    {
        $where['activity_id'] = $activity_id;
        $where['status'] = 1;
        $where['to_site_id'] = $this->site_id;

        $count = $this->business_apply_model->where($where)->count();
        return $count;
    }


    /**
     *
     * @author Qianc
     * @date 2014-8-25
     * @description 获取一条用户信息
     */
    protected function _getOneUser($site_id, $field = "*")
    {
        $where['id'] = $site_id;

        $user = $this->user_model->select($field)->where($where)->find();
        return $user;
    }

    /**
     *
     * @author Qianc
     * @date 2014-8-25
     * @description 处理数据
     */
    private function _joinMe($list = array())
    {
        if($list){
            foreach($list as $k => $v){
                $user = $this->_getOneUser($v['site_id'], 'company');
                $list[$k]['sponsor'] = ($user && $user['company']) ?  $user['company'] : '';
                $list[$k]['short_description'] = ($v && $v['description']) ? cut($v['description'], 8, '...') : '';
                $list[$k]['start_time'] = ($v && $v['start_time']) ? date("Y-m-d", $v['start_time']) : '';
                $list[$k]['end_time'] = ($v && $v['end_time']) ? date("Y-m-d", $v['end_time']) : '';
                $applyRs = $this->check_site_apply_activity($v['site_id'], $v['id'], 'status');
                if($applyRs && $applyRs['status']){
                    $list[$k]['status'] = $applyRs['status'];
                }else{
                    $list[$k]['status'] = 0;//未申请
                }
            }
        }
    }

    //活动详情
    public function detail_activity($id=0)
    {
        if( !$id ){
            return $this->show_message(true, '非法请求', '/c/business_union/index/');
        }

        $where['id'] = $id;
        $where['is_delete'] = 0;
        $activity = $this->business_union_model->where($where)->find();
        if( !$activity ){
            return $this->show_message(true, '没有找到您要查看的活动', '/c/business_union/index/');
        }

        $this->data['info'] = $activity;

        //奖品列表
        $list = $this->business_prize_model->where(array('activity_id'=>$activity['id'],'is_delete'=>0))->order_by('id asc')->find_all();
        $this->data['prize_list'] = $list;

        //获取我的申请状态
        $myApply = $this->check_site_apply_activity($this->site_id,$activity['id'],'status');
        if( $myApply ){
            $this->data['myApply'] = $myApply['status'];
        }else{
            $this->data['myApply'] = 0;
        }

        //素材  回复内容
        if( $this->data['myApply'] ){
            $this->load->model('business_material_model');
            $reply_info = $this->business_material_model->select('keyword,reply_title,reply_img,reply_content')->where(array('activity_id'=>$activity['id']))->find();
            $this->data['reply_info'] = $reply_info;
        }

        $this->load->view($this->dcm, $this->data);
    }


    /**
     *
     * @author Qianc
     * @date 2014-8-26
     * @description 待审核商家列表
     */
    public function applyList($activity_id)
    {
        if( !intval($activity_id) ){
            return $this->show_message(true, '非法请求', '/c/business_union/index/');
        }
        $where = array();
        //$where['wb_business_apply.status'] = 1;
        $where['wb_business_apply.activity_id'] = $activity_id;
        $where['wb_business_apply.to_site_id'] = $this->site_id;

        //搜索
        $search['status'] = $this->input->get('status');
        $search['province'] = $this->input->get('province');
        $search['city'] = $this->input->get('city');
        $search['keyword'] = $this->input->get('keyword');

        $search['status'] !='' ? $where['status'] = $search['status'] : '';
        $search['province'] ? ($search['province'] == '全国' ? '' : $where['user.province'] = $search['province']) : '';
        $search['city'] ? $where['user.city'] = $search['city'] : '';
        $search['keyword'] ? $where['user.company like '] = "%{$search['keyword']}%" : '';

        $search_url = site_url($this->uri->uri_string().'?');
        $base_url = $search_url.http_build_query($search);
        $this->data['search'] = $search;

        $total_rows = $this->business_apply_model
            ->join('user','wb_business_apply.site_id = user.id')
            ->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$base_url));
        $this->data['page'] = $pager['links'];

        $list = $this->business_apply_model
            ->select('wb_business_apply.*, user.company, user.country, user.province, user.city, user.mp_username')
            ->join('user','wb_business_apply.site_id = user.id')
            ->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->where($where)->order_by('wb_business_apply.add_time desc, wb_business_apply.id desc')->find_all();
        $list = $this->_applyList($list);

        $this->data['list'] = $list;
        $this->data['offset'] = $pager['limit']['offset'];
        $this->data['activity'] = $this->_getOneActivity($activity_id);

        $this->load->view($this->dcm, $this->data);
    }

    /**
     *
     * @author Qianc
     * @date 2014-8-26
     * @description 待审核商家列表
     */
    private function _applyList($list)
    {
      if($list){
          foreach($list as $k => $v){
              $list[$k]['company'] = ($v && $v['company']) ?  $v['company'] : '';
              $country = ($v && $v['country']) ?  $v['country'] : '';
              $province = ($v && $v['province']) ?  $v['province'] : '';
              $city = ($v && $v['city']) ?  $v['city'] : '';
              $list[$k]['area'] = '';
              !$country || $country == '中国' ? $list[$k]['area'] .= '' : '';
              $province ? $list[$k]['area'] .= $province : '';
              $city ? $list[$k]['area'] .= '-'.$city : '';
              $list[$k]['weixin'] = ($v && $v['mp_username']) ?  $v['mp_username'] : '';
              $list[$k]['add_time'] = ($v && $v['add_time']) ? date("Y-m-d h:i:s", $v['add_time']) : '';
          }
          return $list;
      }
    }


    /**
     *
     * @author Qianc
     * @date 2014-8-26
     * @description 通过/不通过审核
     */
    public function on_off_pass($id=0, $status=2)
    {
        if( !intval($id) ){
            exit(json_encode(array('ret' => 1,'msg' => '非法修改')));
        }

        $where['to_site_id'] = $this->site_id;
        $where['id'] = $id;
        $apply = $this->business_apply_model->where($where)->find();
        if( !$apply ){
            exit(json_encode(array('ret' => 1,'msg' => '没有找到数据')));
        }
        $apply['status'] != 1 ? exit(json_encode(array('ret' => 0,'msg' => '非法修改'))) : '';
        if( $this->business_apply_model->where($where)->edit(array('status'=>$status, 'operate_time'=>time())) ){
            if($status == 2) {
                $where['status'] = 2;
                $this->business_apply_model->where($where)->edit(array('invite_code'=>$this->createCode($apply['activity_id'])));
            }
            exit(json_encode(array('ret' => 0,'msg' => '操作成功')));
        }else{
            exit(json_encode(array('ret' => 1,'msg' => '操作失败')));
        }
    }

    /**
     *
     * @author Qianc
     * @date 2014-8-26
     * @description 获取一条活动信息
     */
    protected function _getOneActivity($activity_id, $field = "*")
    {
        $where['id'] = $activity_id;
        $where['is_delete'] = 0;
        $where['site_id'] = $this->site_id;

        $activity = $this->business_union_model->select($field)->where($where)->find();
        return $activity;
    }



    /**
     *
     * @author Qianc
     * @date 2014-8-28
     * @description 素材管理
     */
    public function material($activity_id)
    {
        if( !intval($activity_id) ){
            return $this->show_message(false, '参数不全', '');
        }

        $material = $this->_getOneMaterial($activity_id);
        if( $this->input->post() ){
            $this->form_validation->set_rules('keyword', '活动关键词', 'trim|required|max_length[255]');
            $this->form_validation->set_rules('reply_title', '自动回复标题', 'trim|required|max_length[255]');
            $this->form_validation->set_rules('reply_img', '自动回复图片', 'trim|max_length[255]|callback__check_image');
            $this->form_validation->set_rules('reply_content', '自动回复正文', 'trim|max_length[5000]|htmlspecialchars');
            $this->form_validation->set_rules('description', '详细说明', 'trim|max_length[5000]|htmlspecialchars');

            if ( $this->form_validation->run() ){
                $save_data['keyword'] = $this->form_validation->set_value('keyword');
                $save_data['reply_title'] = $this->form_validation->set_value('reply_title');
                $save_data['reply_img'] = $this->form_validation->set_value('reply_img');
                $save_data['reply_content'] = $this->form_validation->set_value('reply_content');
                $data['description'] = $this->form_validation->set_value('description');

                if($material){
                    $save_data['update_time'] = time();
                    $ret = $this->business_material_model->where(array('site_id'=>$this->site_id,'activity_id'=>$activity_id))->edit($save_data);
                }else{
                    $save_data['activity_id'] = $activity_id;
                    $save_data['site_id'] = $this->site_id;
                    $save_data['add_time'] = time();
                    $ret = $this->business_material_model->add($save_data);
                }
                $this->business_union_model->where(array('id'=>$activity_id))->edit($data);
                $ret ? $this->show_message(true, '操作成功', '/c/business_union/sponsorMe') : $this->show_message(false, '操作失败', '/c/business_union/sponsorMe');
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            $this->data['material'] = $material;
            $this->data['activity'] = $this->_getOneActivity($activity_id);
            $this->data['activity_url'] = 'http://'.$this->site_info['domain'].BASE_DOMAIN.'/business_union?id='.$activity_id;
            $this->load->view($this->dcm, $this->data);
        }
    }


    /**
     *
     * @author Qianc
     * @date 2014-8-28
     * @description 获取一条素材信息
     */
    protected function _getOneMaterial($activity_id, $field = "*")
    {
        $where['activity_id'] = $activity_id;
        $where['site_id'] = $this->site_id;

        $material = $this->business_material_model->select($field)->where($where)->find();
        return $material;
    }


    /**
     *
     * @author Qianc
     * @date 2014-8-29
     * @description 生成随机邀请码
     */
    protected function createCode($activity_id)
    {
        if(intval($activity_id)){
            $randCode = null;
            $isBreak = false;
            do
            {
                $randCode = mt_rand(1000, 9999);    # 推入随机数
                $where['activity_id'] = intval($activity_id);
                $where['invite_code'] = $randCode;
                $count = $this->business_apply_model
                    ->select('invite_code')
                    ->where($where)->count();
                $isBreak = $count > 0 ? false : true;
            }while (!$isBreak) ;
            return $randCode;
        }
    }


    /**
     *
     * @author Qianc
     * @date 2014-9-3
     * @description 数据统计
     */
    public function stat($activity_id)
    {
        if( !intval($activity_id) ){
            return $this->show_message(false, '参数不全', '');
        }

        $activity = $this->_getOneActivity($activity_id);
        if( !$activity ){
            return $this->show_message(false, '非法请求', '');
        }


        $business_where['activity_id'] = intval($activity_id);
        $business_where['status'] = 2;
        $business_count = $this->business_apply_model->where($business_where)->count();

        $vote_where['activity_id'] = intval($activity_id);
        $vote_count = $this->business_lottery_model->where($vote_where)->count();

        $vote_where['status'] = 1;
        $prize_count = $this->business_lottery_model->where($vote_where)->count();

        $where['wb_business_lottery.activity_id'] = intval($activity_id);
        $where['wb_business_lottery.status'] = 1;
        $total_rows = $this->business_lottery_model
            ->join('user','wb_business_lottery.from_site_id = user.id')
            ->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15));


        $list = $this->business_lottery_model
            ->select('wb_business_lottery.*, user.mp_username')
            ->join('user','wb_business_lottery.from_site_id = user.id')
            ->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->where($where)->order_by('wb_business_lottery.join_time desc, wb_business_lottery.id desc')->find_all();

        $this->data['activity'] = $activity;
        $this->data['business_count'] = $business_count;
        $this->data['vote_count'] = $vote_count;
        $this->data['prize_count'] = $prize_count;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->data['list'] = $list;

        $this->load->view($this->dcm, $this->data);
    }


    /**
     *
     * @author Qianc
     * @date 2014-9-3
     * @description 数据导出
     */
    public function stat_export($activity_id)
    {
        if( !intval($activity_id) ){
            return $this->show_message(false, '参数不全', '');
        }

        $activity = $this->_getOneActivity($activity_id);
        if( !$activity ){
            return $this->show_message(false, '非法请求', '');
        }

        $where['wb_business_lottery.activity_id'] = intval($activity_id);
        $where['wb_business_lottery.status'] = 1;
        $lotterys = $this->business_lottery_model
            ->select('wb_business_lottery.*, user.mp_username')
            ->join('user','wb_business_lottery.from_site_id = user.id')
            ->where($where)->order_by('wb_business_lottery.join_time desc, wb_business_lottery.id desc')->find_all();
        $export_list = array();
        if($lotterys)
        {
            foreach($lotterys as $key=> $item)
            {
                $export_list[$key]['name'] = $item['name'];
                $export_list[$key]['mobile'] = $item['mobile'];
                $export_list[$key]['address'] = $item['address'];
                $export_list[$key]['mp_username'] = $item['mp_username'];
                $export_list[$key]['join_time'] = date("Y-m-d h:i:s", $item['join_time']);
            }

            $fields = array(
                '#'=>'#',
                'name'=>'中奖人姓名',
                'mobile'=>'手机号码',
                'address'=>'地址',
                'mp_username'=>'来自公共帐号',
                'join_time'=>'中奖时间'
            );

            $this->excel_export('中奖名单', '中奖名单', $fields, $export_list);
        }
        else
        {
            exit('尚无记录可以导出');
        }
    }


    //获取奖品列表
    public function get_prize()
    {
        $id = $this->input->post('id');
        //奖品列表
        $list = $this->business_prize_model->select('name,rate,stock')->where(array('activity_id'=>$id,'is_delete'=>0))->order_by('id asc')->find_all();
        $list = $list ? $list :  array();
        echo json_encode(array('ret'=>0,'data'=>$list));
    }


}