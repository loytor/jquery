<?php

/**
 * Created by PhpStorm.
 * User: songxiyao
 * Date: 2014/10/29
 * Time: 11:13
 */
class National_brokers extends C_Controller {

    protected $wid = '';

    public function __construct() {
        parent::__construct();
        $this->wid = $this->site_info['id'];
        $this->_check_app();
    }

    //检测应用是否购买，并且初始化数据
    protected function _check_app() {
        $this->load->model('user_auth_model');
        $this->load->model('app_model');

        $appid = $this->app_model->where(array('module' => '/c/national_brokers'))->find();
        $app_list = $this->user_auth_model->select('id')->where(array('user_id' => $this->wid, 'app_id' => $appid['id']))->find();
        $app_list = true;
        if (!$app_list) {
            echo "<script> alert('您还没有购买该应用');parent.location.href='http://www.bama555.com'; </script>";
            exit;
        } else {
            //检测是否需要初始化
            $this->load->model('nm_init_model', 'init');
            if (!$this->init->where('wid', $this->wid)->find()) {
                //产品数据，微信分享数据，客户身份信息，经纪人身份信息，注册协议
                $this->load->model('nm_product_model', 'product');
                if (!($product = $this->product->select('id')->where("wid", $this->wid)->find())) {
                    if (!($product_id = $this->product->init_proudct($this->wid))) {
                        echo "<script> alert('产品数据初始化失败');parent.location.href='http://www.bama555.com'; </script>";
                        exit;
                    }
                } else {
                    $product_id = $product['id'];
                }

                $this->load->model('nm_product_module_model', 'module');
                if (!$this->module->select('id')->where('product_id', $product_id)->find()) {
                    if (!$this->module->init_module($product_id)) {
                        echo "<script> alert('产品模块数据初始化失败');parent.location.href='http://www.bama555.com'; </script>";
                        exit;
                    }
                }

                $this->load->model('nm_setting_model', 'nm_setting');
                if (!$this->nm_setting->select('id')->where('wid', $this->wid)->find()) {
                    if (!$this->nm_setting->init_setting($this->wid)) {
                        echo "<script> alert('配置数据初始化失败');parent.location.href='http://www.bama555.com'; </script>";
                        exit;
                    }
                }

                $this->load->model('nm_customer_state_model', 'customer_state');
                if (!$this->customer_state->select('id')->where('wid', $this->wid)->find()) {
                    if (!$this->customer_state->init_state($this->wid)) {
                        echo "<script> alert('客户状态数据初始化失败');parent.location.href='http://www.bama555.com'; </script>";
                        exit;
                    }
                }

                $this->load->model('nm_broker_setting_model', 'broker_setting');
                if (!$this->broker_setting->select('id')->where('wid', $this->wid)->find()) {
                    $prodcut_brokerage = $this->broker_setting->init_setting($this->wid);
                    $this->product->where('id', $product_id)->edit(array('brokerage' => $prodcut_brokerage));
                }
                $this->load->model('nm_init_model', 'init');
                $this->init->add(array('wid' => $this->wid));
            }
        }
    }

    //客户页面
    public function index($action = '') {
        //查询客户
        $this->load->model('nm_customer_model', 'customer');
        $options = array(
            'select' => 'id, name, gender, mobile, dt_add, source, brokerage, status, broker_id, product_id',
            'where'  => array(
                'wid'    => $this->wid,
                'is_del' => 1,
            ),
        );
        $this->input->get('name') && $options['where']['name'] = $this->input->get('name');
        $this->input->get('mobile') && $options['where']['mobile'] = $this->input->get('mobile');
        $this->input->get('broker_id') && $options['where']['broker_id'] = $this->input->get('broker_id');
        $url_where = $this->input->get();
        unset($url_where['page']);
        $search_url = "?" . http_build_query($url_where);
        $this->data['where'] = $url_where;
        $count = $this->customer->count($options);

        $pager = $this->_pager($count, array('per_page' => 15, 'base_url' => $search_url));
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $customer_list = $this->customer
            ->order_by('dt_add desc')
            ->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->find_all($options);
        //遍历组装数据
        $product_id = $broker_id = array();
        if ($customer_list) {
            foreach ($customer_list as $k => $cus) {
                $customer_list[$k]['dt_add'] = date('Y-m-d', $cus['dt_add']);
                $product_id[] = $cus['product_id'];
                $broker_id[] = $cus['broker_id'];
            }
        }
        //返回产品、经纪人、状态数据
        $this->load->model('nm_product_model', 'product');
        $product = $this->product->return_product_list($product_id);

        $this->load->model('nm_broker_model', 'broker');
        $broker = $this->broker->return_broker_list($broker_id);

        $this->load->model('nm_customer_state_model', 'customer_state');
        $state = $this->customer_state->return_state_list($this->wid);

        if ($action == 'export') {
            //导出表格
            if (!empty($customer_list)) {
                $fields = array(
                    '#'         => '#',
                    'name'      => '客户名',
                    'gender'    => '性别',
                    'mobile'    => '客户电话',
                    'product'   => '产品',
                    'status'    => '状态',
                    'source'    => '来源',
                    'dt_add'    => '推荐时间',
                    'broker'    => '经纪人',
                    'brokerage' => '佣金',
                );
                foreach ($customer_list as $k => $v) {
                    $status_arr = array_filter(explode(",", $v['status']));
                    $status_str = '';
                    if (!empty($status_arr) && !empty($state)) {
                        foreach ($status_arr as $s) {
                            $status_str .= isset($state[$s]) ? $state[$s] . " " : "";
                        }
                    }
                    $export_customer[] = array(
                        'name'      => $v['name'],
                        'gender'    => $v['gender'] == 1 ? "男" : "女",
                        'mobile'    => $v['mobile'],
                        'product'   => isset($product[$v['product_id']]['name']) ? $product[$v['product_id']]['name'] : '',
                        'status'    => $status_str,
                        'source'    => $v['source'] == 1 ? "推荐" : "分享",
                        'dt_add'    => $v["dt_add"],
                        'broker'    => isset($broker[$v['broker_id']]['name']) ? $broker[$v['broker_id']]['name'] : "",
                        'brokerage' => $v['brokerage'],
                    );
                }
                $this->excel_export('客户数据统计', '客户数据统计', $fields, $export_customer);
                return false;
            } else {
                $this->show_message(false, '暂无数据可以导出');
                return false;
            }
        } else {
            $this->data['customer_list'] = $customer_list;
            $this->data['product'] = $product;
            $this->data['broker'] = $broker;
            $this->data['state'] = $state;
        }
        $this->data['domain'] = $this->site_info['domain'];
        $this->load->view('c/national_brokers/index', $this->data);
    }

    //修改客户数据
    public function edit_customer() {
        $data = $this->input->post();
        $this->load->model('nm_customer_model', 'customer');
        if (isset($data['brokerage'])) {
            $this->load->model('nm_broker_model', 'broker');
            //查询经纪人ID
            $customer = $this->customer->select('broker_id, brokerage')->where('id', $data['id'])->find();
            if ($customer['brokerage'] != $data['brokerage']) {
                $this->broker->where('id', $customer['broker_id'])->edit(array('tips' => 1));
            }
        }
        if ($this->customer->where(array('id' => $data['id'], 'wid' => $this->wid))->edit($data)) {
            $this->ajax_return(array('status' => true, 'msg' => '成功'));
            return false;
        } else {
            $this->ajax_return(array('status' => false, 'msg' => '修改失败'));
            return false;
        }
    }

    //删除客户
    public function delete_customer() {
        $id = $this->input->post('id');
        $this->load->model('nm_customer_model', 'customer');
        if (!$this->customer->where(array('id' => $id, 'wid' => $this->wid))->edit(array('is_del' => 2))) {
            $this->ajax_return(array('status' => false, 'msg' => '删除失败'));
            return false;
        } else {
            $this->ajax_return(array('status' => true, 'msg' => '成功'));
            return false;
        }
    }

    //经纪人页面
    public function brokers($id = '') {
        $this->load->model('nm_broker_model', 'broker');
        $this->load->model('nm_broker_setting_model', 'broker_setting');
        $this->load->model('nm_bank_card_model', 'bank_card');
        if ($this->input->post()) {
            $broker_data = $this->input->post('broker');
            //密码处理
            if ($broker_data['password']) {
                $broker_data['salt'] = generateSalt();
                $broker_data['password'] = md5($broker_data['password'] . $broker_data['salt']);
            } else {
                unset($broker_data['password']);
            }
            //检测账号是否为空，是否重复
            if ($broker_data['name'] == '') {
                $this->show_message(false, "请填写姓名");
                return false;
            } else if ($broker_data['tel'] == '') {
                $this->show_message(false, "请填写电话");
                return false;
            } else {
                $exists_where = array(
                    'wid'       => $this->wid,
                    'id !='     => $id,
                    'tel'       => $broker_data['tel'],
                    'status !=' => 3,
                );
                if ($this->broker->select('id')->where($exists_where)->find()) {
                    $this->show_message(false, "电话已存在");
                    return false;
                }
            }
            $ret_1 = $this->broker->where(array('id' => $id, 'wid' => $this->wid))->edit($broker_data);
            $ret_2 = $ret_3 = true;
            if ($this->input->post('bank')) {
                $ret_2 = $this->bank_card->update_set(array_merge($this->input->post('bank'), array('type' => 'bank_cards')));
            }
            if ($this->input->post('alipay')) {
                $ret_3 = $this->bank_card->update_set(array_merge($this->input->post('alipay'), array('type' => 'alipay')));
            }
            if ($ret_1 && $ret_2 && $ret_3) {
                $this->show_message(true, '保存成功', '/c/national_brokers/brokers/' . $id);
                return false;
            } else {
                $this->show_message(false, '保存失败');
                return false;
            }
        } else {
            if ($id) {
                $options = array(
                    'select' => 'id, name, tel, identity, status',
                    'where'  => array(
                        'wid' => $this->wid,
                        'id'  => $id,
                    ),
                );
                //返回经纪人的基本信息
                if (!$this->broker->find($options)) {
                    $this->show_message(false, '数据不存在', '/c/national_brokers/brokers/');
                    return false;
                } else {
                    $this->data['broker_info'] = $this->broker->find($options);
                }
                //返回经纪人的状态
                $this->data['status_list'] = array(1 => '待审核', 2 => '正常', 3 => '删除');
                //返回经纪人的所有身份
                $this->data['broker_setting'] = $this->broker_setting->return_status_list($this->wid);
                //返回经纪人绑定的银行卡或支付宝
                $bank_options = array(
                    'select' => 'id, bank_account, bank_type, bank_num, type',
                    'where'  => array(
                        'broker_id' => $this->data['broker_info']['id'],
                    ),
                );
                $bank_info = $this->bank_card->find_all($bank_options);
                $new_list = array();
                if ($bank_info) {
                    foreach ($bank_info as $v) {
                        $new_list[$v['type']] = $v;
                    }
                }
                $this->data['bank_info'] = $new_list;
                //返回提现的设置
                $this->load->model('nm_withdraw_setting_model', 'withdraw_setting');
                $this->data['withdraw'] = $this->withdraw_setting->select('support')->where('wid', $this->wid)->find();
                $this->data['nav'] = 'info';
                $this->load->view('c/national_brokers/broker_info', $this->data);
            } else {
                $options = array(
                    'select' => 'id, name, tel, identity, status, dt_add',
                    'where'  => array(
                        'wid'       => $this->wid,
                        'status !=' => 3,
                    ),
                );
                $this->input->get('name') && $options['where']['name'] = $this->input->get('name');
                $this->input->get('tel') && $options['where']['tel'] = $this->input->get('tel');
                $url_where = $this->input->get();
                unset($url_where['page']);
                $search_url = '?' . http_build_query($url_where);
                $this->data['where'] = $url_where;
                $count = $this->broker->count($options);

                $pager = $this->_pager($count, array('per_page' => 15, 'base_url' => $search_url));
                $this->data['page'] = $pager['links'];
                $this->data['offset'] = $pager['limit']['offset'];

                $broker_list = $this->broker
                    ->order_by('dt_add desc')
                    ->limit($pager['limit']['value'], $pager['limit']['offset'])
                    ->find_all($options);

                $status_list = $this->broker_setting->return_status_list($this->wid);

                $this->load->model('nm_customer_model', 'customer');
                $this->load->model('nm_withdraw_model', 'withdraw');
                if (!empty($broker_list)) {
                    foreach ($broker_list as $k => $broker) {
                        $broker_list[$k]['identity'] = isset($status_list[$broker['identity']]) ? $status_list[$broker['identity']] : '';
                        $broker_list[$k]['dt_add'] = date('Y-m-d', $broker['dt_add']);
                        $broker_list[$k]['customer_count'] = $this->customer->where(array('broker_id' => $broker['id'], 'is_del' => 1))->count();
                        $broker_list[$k]['total_withdraw'] = $this->customer->where(array('broker_id' => $broker['id'], 'is_del' => 1))->sum('brokerage');
                        $broker_list[$k]['hava_get'] = $this->withdraw->where(array('broker_id' => $broker['id'], 'is_del' => 1))->sum('money');
                    }
                }
                $this->data['broker_list'] = $broker_list;
                $this->load->view('c/national_brokers/brokers', $this->data);
            }
        }
    }

    //经纪人其他信息页面
    public function broker_other($type = '', $broker_id = '') {
        $this->data['nav'] = 'other';
        $this->data['broker_id'] = $broker_id;
        //查询客户数量、佣金总数和可提现的数量
        $this->load->model('nm_customer_model', 'customer');
        $this->load->model('nm_withdraw_model', 'withdraw');
        $this->load->model('nm_customer_model', 'customer');
        $total_withdraw = $this->customer->where(array('broker_id' => $broker_id, 'is_del' => 1))->sum('brokerage');
        $total_money = $this->withdraw->where(array('broker_id' => $broker_id, 'is_del' => 1))->sum('money');
        $total_customer = $this->customer->where(array('broker_id' => $broker_id, 'is_del' => 1))->count();
        $this->data['brokerage'] = $total_withdraw ?: 0.00;
        $this->data['get'] = $total_money ?: 0.00;
        $this->data['customer'] = $total_customer;
        if ($type == 'brokerage') {
            //查询客户
            $options = array(
                'select' => 'id, name, mobile, dt_done, brokerage, product_id',
                'where'  => array(
                    'wid'         => $this->wid,
                    'broker_id'   => $broker_id,
                    'is_del'      => 1,
                    'brokerage >' => 0,
                ),
            );
            $count = $this->customer->count($options);

            $pager = $this->_pager($count, array('per_page' => 15));
            $this->data['page'] = $pager['links'];
            $this->data['offset'] = $pager['limit']['offset'];

            $customer_list = $this->customer
                ->order_by('dt_add desc')
                ->limit($pager['limit']['value'], $pager['limit']['offset'])
                ->find_all($options);
            //遍历组装数据
            $product_id = array();
            if ($customer_list) {
                foreach ($customer_list as $k => $cus) {
                    $customer_list[$k]['dt_add'] = date('Y-m-d');
                    $product_id[] = $cus['product_id'];
                }
            }
            $this->data['customer_list'] = $customer_list;
            //返回产品、经纪人、状态数据
            $this->load->model('nm_product_model', 'product');
            $this->data['product'] = $this->product->return_product_list($product_id);

            $this->load->view('c/national_brokers/broker_brokerage', $this->data);
        } else if ($type == 'get') {
            $options = array(
                'select' => 'id, money, intro, dt_add',
                'where'  => array(
                    'broker_id' => $broker_id,
                    'is_del'    => 1,
                ),
            );

            $count = $this->withdraw->count($options);

            $pager = $this->_pager($count, array('per_page' => 15));
            $this->data['page'] = $pager['links'];
            $this->data['offset'] = $pager['limit']['offset'];

            $this->data['withdraw_list'] = $this->withdraw
                ->order_by('dt_add desc')
                ->limit($pager['limit']['value'], $pager['limit']['offset'])
                ->find_all($options);
            $this->load->view('c/national_brokers/broker_get', $this->data);
        } else if ($type == 'customer') {
            //查询客户
            $options = array(
                'select' => 'id, name, gender, mobile, dt_add, source, brokerage, status, broker_id, product_id',
                'where'  => array(
                    'wid'       => $this->wid,
                    'is_del'    => 1,
                    'broker_id' => $broker_id,
                ),
            );

            $count = $this->customer->count($options);

            $pager = $this->_pager($count, array('per_page' => 15));
            $this->data['page'] = $pager['links'];
            $this->data['offset'] = $pager['limit']['offset'];

            $customer_list = $this->customer
                ->order_by('dt_add desc')
                ->limit($pager['limit']['value'], $pager['limit']['offset'])
                ->find_all($options);
            //遍历组装数据
            $product_id = $broker_id = array();
            if ($customer_list) {
                foreach ($customer_list as $k => $cus) {
                    $customer_list[$k]['dt_add'] = date('Y-m-d');
                    $product_id[] = $cus['product_id'];
                    $broker_id[] = $cus['broker_id'];
                }
            }
            //返回产品、经纪人、状态数据
            $this->load->model('nm_product_model', 'product');
            $product = $this->product->return_product_list($product_id);

            $this->load->model('nm_broker_model', 'broker');
            $broker = $this->broker->return_broker_list($broker_id);

            $this->load->model('nm_customer_state_model', 'customer_state');
            $state = $this->customer_state->return_state_list($this->wid);

            $this->data['customer_list'] = $customer_list;
            $this->data['product'] = $product;
            $this->data['broker'] = $broker;
            $this->data['state'] = $state;
            $this->data['domain'] = $this->site_info['domain'];
            $this->load->view('c/national_brokers/broker_customer', $this->data);

        }
    }

    //增加//修改提现接口
    public function change_withdraw() {
        $this->load->model('nm_withdraw_model', 'withdraw');
        $data = $this->input->post();
        $data['dt_add'] = time();
        //修改提醒字段
        $this->load->model('nm_broker_model', 'broker');
        $this->broker->where('id', $this->input->post('broker_id'))->edit(array('tips' => 1));
        if ($this->input->post('id')) {
            if (!$this->withdraw->where("id", $this->input->post('id'))->edit($data)) {
                $this->ajax_return(array('status' => false, 'msg' => '保存失败'));
                return false;
            } else {
                $this->ajax_return(array('status' => true, 'msg' => '成功'));
                return false;
            }
        } else {
            if (!$this->withdraw->add($data)) {
                $this->ajax_return(array('status' => false, 'msg' => '保存失败'));
                return false;
            } else {
                $this->ajax_return(array('status' => true, 'msg' => '成功'));
                return false;
            }
        }
    }

    //产品页面
    public function product($action = '', $id = '') {
        $this->load->model('nm_product_model', 'product');
        $this->load->model('nm_product_module_model', 'product_module');
        if ($action) {
            $this->data['nav'] = $action == 'add' ? 'add' : 'list';
            if ($this->input->post()) {
                $product = $this->input->post('product') ? : array();
                //对空数据以及重复数据做个判断
                if (count($product) != count(array_filter($product))) {
                    $this->show_message(false, '有必填项未填');
                    return false;
                } else {
                    $exists_where = array(
                        'wid'    => $this->wid,
                        'name'   => $product['name'],
                        'is_del' => 1,
                    );
                    $action == 'edit' && $exists_where['id !='] = $id;
                    if ($this->product->select('id')->where($exists_where)->find()) {
                        $this->show_message(false, '项目名称重复');
                        return false;
                    }
                }
                //接收product表数据
                $product['brokerage'] = $this->_change_brokerage($this->input->post('brokerage'));
                if ($this->input->post('id')) {
                    $this->input->post('status') && $product['status'] = $this->input->post('status');
                    if ($this->product->where(array('id' => $this->input->post('id'), 'wid' => $this->wid))->edit($product)) {
                        //插入module信息
                        $module = $this->input->post('module');
                        //删除原来老的
                        $this->product_module->where('product_id', $this->input->post('id'))->delete();
                        if (isset($module['name']) && !empty($module['name'])) {
                            foreach ($module['name'] as $k => $v) {
                                if (empty($module['name'][$k]) || empty($module['intro'][$k])) {
                                    $this->show_message(false, '模块标题、模块描述是必填项');
                                    return false;
                                }
                                $module_data[] = array(
                                    'product_id' => $this->input->post('id'),
                                    'name'       => $module['name'][$k],
                                    'intro'      => isset($module['intro'][$k]) ? $module['intro'][$k] : '',
                                    'link'       => isset($module['link'][$k]) ? $module['link'][$k] : '',
                                    //'pic'        => mb_substr($module['pic'][$k], -1, 1) == "," ? str_replace(",", "", $module['pic'][$k]) : $module['pic'][$k],
                                    'pic'        => implode(",", array_filter(explode(",", $module['pic'][$k])))
                                );
                            }
                            $this->product_module->add($module_data);
                        }
                        $this->show_message(true, '保存成功', '/c/national_brokers/product');
                        return false;
                    } else {
                        $this->show_message(false, '保存失败');
                        return false;
                    }
                } else {
                    $product['wid'] = $this->wid;
                    $product['dt_add'] = time();
                    if ($this->product->add($product)) {
                        $product_id = $this->db->insert_id();
                        //插入module信息
                        $module = $this->input->post('module');

                        //删除原来老的
                        $this->product_module->where('product_id', $product_id)->delete();
                        if (isset($module['name']) && !empty($module['name'])) {
                            foreach ($module['name'] as $k => $v) {
                                $module_data[] = array(
                                    'product_id' => $product_id,
                                    'name'       => $module['name'][$k],
                                    'intro'      => isset($module['intro'][$k]) ? $module['intro'][$k] : '',
                                    'link'       => isset($module['link'][$k]) ? $module['link'][$k] : '',
                                    //'pic'        => mb_substr($module['pic'][$k], -1, 1) == "," ? str_replace(",", "", $module['pic'][$k]) : $module['pic'][$k],
                                    'pic'        => implode(",", array_filter(explode(",", $module['pic'][$k])))
                                );
                            }
                            $this->product_module->add($module_data);
                        }
                        $this->show_message(true, '保存成功', '/c/national_brokers/product');
                        return false;
                    } else {
                        $this->show_message(false, '保存失败');
                        return false;
                    }
                }
            } else {
                //查询经纪人类型
                $this->load->model('nm_broker_setting_model', 'broker_setting');
                $this->data['broker_status'] = $this->broker_setting->select('id, name')->where('wid', $this->wid)->find_all();
                if ($id) {
                    $options = array(
                        'select' => 'id, name, intro, mobile, pic, brokerage, brokerage_type, listorder',
                        'where'  => array(
                            'id'     => $id,
                            'wid'    => $this->wid,
                            'is_del' => 1,
                        ),
                    );
                    $this->data['product_info'] = $this->product->find($options);
                    if (!$this->data['product_info']) {
                        $this->show_message(false, '数据不存在', '/c/national_brokers/product');
                        return false;
                    }
                    $this->data['brokerage'] = json_decode($this->data['product_info']['brokerage'], true);
                    //查看product_module信息
                    $this->load->model('nm_product_module_model', 'product_module');
                    $module_options = array(
                        'select' => 'name, intro, link, pic',
                        'where'  => array(
                            'product_id' => $this->data['product_info']['id']
                        ),
                    );
                    $this->data['module_data'] = $this->product_module->find_all($module_options);
                }
                $this->load->view('c/national_brokers/product_info', $this->data);
            }
        } else {
            $this->data['nav'] = 'list';
            $options = array(
                'select' => 'id, pic, name, mobile, status',
                'where'  => array(
                    'wid'    => $this->wid,
                    'is_del' => 1,
                ),
            );
            $count = $this->product->count($options);

            $pager = $this->_pager($count, array('per_page' => 15));
            $this->data['page'] = $pager['links'];
            $this->data['offset'] = $pager['limit']['offset'];

            $this->data['product_list'] = $this->product
                ->order_by('dt_add desc')
                ->limit($pager['limit']['value'], $pager['limit']['offset'])
                ->find_all($options);
            $this->load->view('c/national_brokers/product', $this->data);
        }
    }

    //产品上下线
    public function on_off_product() {
        $id = $this->input->post('id');
        $status = $this->input->post('status');
        $this->load->model('nm_product_model', 'product');
        if ($this->product->where('id', $id)->edit(array('status' => $status))) {
            $this->ajax_return(array('status' => true, 'msg' => '成功'));
            return false;
        } else {
            $this->ajax_return(array('status' => false, 'msg' => '数据保存失败'));
            return false;
        }
    }

    //删除产品接口
    public function del_product() {
        $id = $this->input->post('id');
        $this->load->model('nm_product_model', 'product');
        if ($this->product->where(array('id' => $id, 'wid' => $this->wid))->edit(array('is_del' => 2))) {
            $this->ajax_return(array('status' => true, 'msg' => '成功'));
            return false;
        } else {
            $this->ajax_return(array('status' => false, 'msg' => '删除失败'));
            return false;
        }
    }

    //客户设置页面
    public function customer_setting($action = '', $id = '') {
        $this->data['nav'] = 'customer';
        $this->load->model('nm_customer_state_model', 'customer_state');
        if ($this->input->post()) {
            $data = array(
                'wid'  => $this->wid,
                'name' => $this->input->post('name')
            );
            if (empty($data['name'])) {
                $this->show_message(false, '状态名称不能为空');
                return false;
            } else {
                $exists_where = array(
                    'wid'  => $this->wid,
                    'name' => $this->input->post('name')
                );
                $action == 'edit' && $exists_where['id !='] = $id;
                if ($this->customer_state->select('id')->where($exists_where)->find()) {
                    $this->show_message(false, '状态名称已经存在');
                    return false;
                }
            }
            $ret = false;
            if ($this->input->post('id')) {
                $ret = $this->customer_state->where('id', $id)->edit($data);
            } else {
                $ret = $this->customer_state->add($data);
            }
            if (!$ret) {
                $this->show_message(false, '保存失败');
                return false;
            } else {
                $this->show_message(true, '保存成功', '/c/national_brokers/customer_setting');
                return false;
            }
        } else {
            if ($action == 'add' || $action == 'edit') {
                if ($id) {
                    //查询详情
                    $options = array(
                        'select' => 'id, name',
                        'where'  => array(
                            'id'  => $id,
                            'wid' => $this->wid,
                        ),
                    );
                    $this->data['state_info'] = $this->customer_state->find($options);
                }
                $this->load->view('c/national_brokers/customer_setting_add', $this->data);
            } else {
                $options = array(
                    'select' => 'id, name',
                    'where'  => array(
                        'wid' => $this->wid
                    ),
                );
                $this->data['state_list'] = $this->customer_state->order_by('id desc')->find_all($options);
                $this->load->view('c/national_brokers/customer_setting', $this->data);
            }
        }
    }

    //删除客户状态接口
    public function delete_customer_state() {
        $cate_id = $this->input->post('cate_id');
        $ret = true;

        if (isset($_POST['move_id'])) {
            //如果有转移ID
            $this->load->model('nm_customer_model', 'customer');
            $r_cate_id = ',' . $cate_id . ',';
            $r_move_id = $_POST['move_id'] ? ',' . $this->input->post('move_id') . ',' : ',';
            if (!$this->db->where('wid', $this->wid)->set('status', "replace(status, '{$r_cate_id}', '{$r_move_id}')", false)->update($this->customer->get_table())) {
                $ret = false;
            }
        }

        if ($ret == false) {
            $this->ajax_return(array('status' => false, 'msg' => '系统异常'));
            return false;
        } else {
            $this->load->model('nm_customer_state_model', 'customer_state');
            if (!$this->customer_state->where(array('wid' => $this->wid, 'id' => $cate_id))->delete()) {
                $this->ajax_return(array('status' => false, 'msg' => '系统异常'));
                return false;
            } else {
                $this->ajax_return(array('status' => true, 'msg' => ''));
                return false;
            }
        }
    }

    //活动细则设置
    public function events_setting() {
        $this->data['nav'] = 'events';
        $this->load->model('nm_setting_model', 'nm_setting');
        if ($this->input->post()) {
            $events_set = $this->input->post('events_set');
            if (!$this->nm_setting->update_set($this->wid, array('wid' => $this->wid, 'events_set' => $events_set))) {
                $this->show_message(false, '保存失败');
                return false;
            } else {
                $this->show_message(true, '保存成功', '/c/national_brokers/events_setting');
                return false;
            }
        } else {
            //查询内容
            $options = array(
                'select' => 'events_set',
                'where'  => array(
                    'wid' => $this->wid,
                ),
            );
            $this->data['setting'] = $this->nm_setting->find($options);
            $this->load->view('c/national_brokers/events_setting', $this->data);
        }
    }

    //经纪人设置
    public function broker_setting($action = '', $id = '') {
        $this->data['nav'] = 'broker';
        $this->load->model('nm_broker_setting_model', 'broker_setting');

        if ($this->input->post()) {
            $data = array(
                'wid'      => $this->wid,
                'name'     => $this->input->post('name'),
                'is_check' => $this->input->post('is_check'),
            );
            if (!$data['name']) {
                $this->show_message(false, '身份名称不能为空');
                return false;
            } else {
                $exists_where = array(
                    'wid'  => $this->wid,
                    'name' => $data['name']
                );
                $action == 'edit' && $exists_where['id !='] = $id;
                if ($this->broker_setting->select('id')->where($exists_where)->find()) {
                    $this->show_message(false, '身份名称已经存在');
                    return false;
                }
            }
            $ret = false;
            if ($this->input->post('id')) {
                $ret = $this->broker_setting->where('id', $this->input->post('id'))->edit($data);
            } else {
                $ret = $this->broker_setting->add($data);
            }

            if ($ret) {
                $this->show_message(true, '保存成功', '/c/national_brokers/broker_setting');
                return false;
            } else {
                $this->show_message(false, '保存失败');
                return false;
            }
        } else {
            if ($action == 'add' || $action == 'edit') {
                if ($id) {
                    $options = array(
                        'select' => 'id, name, is_check',
                        'where'  => array(
                            'id' => $id,
                        )
                    );
                    $this->data['set_info'] = $this->broker_setting->find($options);
                }
                $this->load->view('c/national_brokers/broker_setting_add', $this->data);
            } else {
                //查询数据
                $options = array(
                    'select' => 'id, name, is_check',
                    'where'  => array(
                        'wid' => $this->wid,
                    ),
                );
                $this->data['broker_setting'] = $this->broker_setting->order_by('id desc')->find_all($options);
                $this->load->view('c/national_brokers/broker_setting', $this->data);
            }
        }
    }

    //经纪人删除
    public function delete_broker_state() {
        $cate_id = $this->input->post('cate_id');
        $ret = true;

        if (isset($_POST['move_id'])) {
            //如果有转移ID
            $this->load->model('nm_broker_model', 'broker');
            $r_move_id = $_POST['move_id'] ? $this->input->post('move_id') : '';
            if (!$this->broker->where('wid', $this->wid)->edit(array('identity' => $r_move_id))) {
                $ret = false;
            }
        }

        if ($ret == false) {
            $this->ajax_return(array('status' => false, 'msg' => '系统异常'));
            return false;
        } else {
            $this->load->model('nm_broker_setting_model', 'broker_setting');
            if (!$this->broker_setting->where(array('wid' => $this->wid, 'id' => $cate_id))->delete()) {
                $this->ajax_return(array('status' => false, 'msg' => '系统异常'));
                return false;
            } else {
                $this->ajax_return(array('status' => true, 'msg' => ''));
                return false;
            }
        }
    }

    //提现设置
    public function withdraw() {
        $this->data['nav'] = 'withdraw';
        $this->load->model('nm_withdraw_setting_model', 'withdraw_setting');
        $this->data['bank_list'] = $this->_return_pay_config();

        if ($this->input->post()) {
            $options = array(
                'select' => 'id',
                'where'  => array(
                    'wid' => $this->wid
                )
            );
            $data = array(
                'wid'       => $this->wid,
                'is_enable' => $this->input->post('is_enable'),
                'support'   => $this->input->post('support') ? implode(",", $this->input->post('support')) : '',
            );
            $ret = false;
            if ($this->withdraw_setting->find($options)) {
                $ret = $this->withdraw_setting->where($options['where'])->edit($data);
            } else {
                $ret = $this->withdraw_setting->add($data);
            }

            if ($ret) {
                $this->show_message(true, '保存成功', '/c/national_brokers/withdraw');
                return false;
            } else {
                $this->show_message(false, '保存失败');
                return false;
            }
        } else {
            $options = array(
                'select' => 'is_enable, support',
                'where'  => array(
                    'wid' => $this->wid,
                ),
            );
            $this->data['withdraw'] = $this->withdraw_setting->find($options);
            $this->load->view('c/national_brokers/withdraw', $this->data);
        }
    }

    //注册协议
    public function reg_setting() {
        $this->data['nav'] = 'reg';
        $this->load->model('nm_setting_model', 'nm_setting');
        if ($this->input->post()) {
            $data = array(
                'reg_set' => json_encode(array('enable' => $this->input->post('enable'), 'intro' => $this->input->post('intro')))
            );
            if ($this->nm_setting->update_set($this->wid, $data)) {
                $this->show_message(true, '保存成功', '/c/national_brokers/reg_setting');
                return false;
            } else {
                $this->show_message(false, '保存失败');
                return false;
            }
        } else {
            $options = array(
                'select' => 'reg_set',
                'where'  => array(
                    'wid' => $this->wid,
                ),
            );
            $setting = $this->nm_setting->find($options);
            $this->data['reg_set'] = isset($setting['reg_set']) ? json_decode($setting['reg_set'], true) : '';
            $this->load->view('c/national_brokers/reg_setting', $this->data);
        }
    }

    //分享设置
    public function share_setting() {
        $this->data['nav'] = 'share';
        $this->load->model('nm_setting_model', 'nm_setting');
        if ($this->input->post()) {
            if (!$this->input->post('share_title')) {
                $this->show_message(false, '分享标题不能为空');
                return false;
            } else if (!$this->input->post('share_intro')) {
                $this->show_message(false, '分享描述不能为空');
                return false;
            } else if (!$this->input->post('share_icon')) {
                $this->show_message(false, '分享图标不能为空');
                return false;
            } else if (!$this->input->post('share_page_intro')) {
                $this->show_message(false, '分享页描述');
                return false;
            } else {
                $data = $this->input->post();
                if ($this->nm_setting->update_set($this->wid, $data)) {
                    $this->show_message(true, '保存成功', '/c/national_brokers/share_setting');
                    return false;
                } else {
                    $this->show_message(false, '保存失败');
                    return false;
                }
            }
        } else {
            $options = array(
                'select' => 'share_title, share_intro, share_page_intro, share_icon',
                'where'  => array(
                    'wid' => $this->wid,
                ),
            );
            $this->data['share'] = $this->nm_setting->find($options);
            $this->load->view('c/national_brokers/share_setting', $this->data);
        }
    }

    //界面风格
    public function style_setting() {
        $this->load->model('nm_setting_model', 'nm_setting');
        if ($this->input->post()) {
            $data = $this->input->post();
            if ($this->nm_setting->update_set($this->wid, $data)) {
                $this->show_message(true, '保存成功', '/c/national_brokers/style_setting');
            } else {
                $this->show_message(false, '保存失败');
            }
        } else {
            $this->data['nav'] = 'style';
            $options = array(
                'select' => 'style',
                'where'  => array(
                    'wid' => $this->wid
                ),
            );
            $this->data['setting'] = $this->nm_setting->find($options);
            $this->load->view('c/national_brokers/style_setting', $this->data);
        }
    }

    //处理提交的brokerage数据
    protected function _change_brokerage($arr) {
        if (isset($arr['id']) && !empty($arr['id'])) {
            $new_list = array();
            foreach ($arr['id'] as $k => $v) {
                $new_list[$v] = $arr['money'][$k];
            }
            return json_encode($new_list);
        }
        return json_encode(array());
    }

    //返回支付设置
    protected function _return_pay_config() {
        return array(
            'alipay'     => '支付宝',
            'bank_cards' => '银行卡'
        );
    }
}