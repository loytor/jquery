<?php
/**
 * 转发有礼
 */
class Forward extends C_Controller {

    protected $auto_load_model = TRUE;
    protected $model_name = 'forward';
    
    protected $data = '';
    
    private $site_id = '';
    
    public function __construct()
    {
        parent::__construct();
        
        $this->site_id = $this->site_info['id'];
    }
    
    public function index()
    {
        $where = array(
            'site_id' => $this->site_id,
            'status' => 0
        );
        $total_rows = $this->model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15));
        $list = $this->model->select('id,title,img,keyword,start_time,end_time')->limit($pager['limit']['value'], $pager['limit']['offset'])
                ->where($where)->order_by('id desc')->find_all();
        
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        
        $this->data['base_url'] = 'http://'.$this->site_info['domain'].BASE_DOMAIN.'/turn';
        
        $this->load->view($this->dcm, $this->data);
    }
    
    public function add()
    {
        if( $this->input->post() ){
            $this->form_validation->set_rules('title', '标题', 'trim|required|max_length[15]');
            $this->form_validation->set_rules('summary', '摘要', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('img', '图标', 'trim|required|callback__check_image');
            $this->form_validation->set_rules('forward_url', '转发地址', 'trim|required|max_length[255]|prep_url');
            $this->form_validation->set_rules('keyword', '活动关键词', 'trim|required|max_length[10]');
            $this->form_validation->set_rules('start_time', '开始时间', 'trim|required|max_length[20]');
            $this->form_validation->set_rules('end_time', '结束时间', 'trim|required|max_length[20]');
            $this->form_validation->set_rules('show_rank', '手机显示总排名', 'trim|required|numeric|greater_than_equal_to[0]');
            $this->form_validation->set_rules('rule', '奖励规则', 'trim|required|htmlspecialchars');
            $this->form_validation->set_rules('show_img', '封面图片', 'trim|required|callback__check_image');
            if ( $this->form_validation->run() ){
                
                $save_data['title'] = $this->form_validation->set_value('title');
                $save_data['summary'] = $this->form_validation->set_value('summary');
                $save_data['img'] = $this->form_validation->set_value('img');
                $save_data['forward_url'] = $this->form_validation->set_value('forward_url');
                $save_data['keyword'] = $this->form_validation->set_value('keyword');
                $save_data['start_time'] = $this->form_validation->set_value('start_time');
                $save_data['end_time'] = $this->form_validation->set_value('end_time');
                $save_data['show_rank'] = $this->form_validation->set_value('show_rank');
                $save_data['show_img'] = $this->form_validation->set_value('show_img');
                
                if( strtotime($save_data['start_time']) ){
                    $save_data['start_time'] = strtotime($save_data['start_time']);
                }else{
                    $this->show_message(false, '开始时间格式非法', '',1);return FALSE;
                }
                if( strtotime($save_data['end_time']) ){
                    $save_data['end_time'] = strtotime($save_data['end_time']);
                }else{
                    $this->show_message(false, '结束时间格式非法', '',1);return FALSE;
                }
                if( intval($save_data['start_time'])>=intval($save_data['end_time']) ){
                    $this->show_message(false, '开始时间必须小于结束时间', '',1);return FALSE;
                }
                
                $save_data['rule'] = $this->form_validation->set_value('rule');
                
                //完善信息部分
                $required_fields = $this->input->post('required_fields') ? $this->input->post('required_fields') : array();
                $save_data['required_fields'] = $required_fields;
                if( $save_data['required_fields'] ){
                    $save_data['required_fields'] = implode(',', $required_fields);
                }else{
                    $save_data['required_fields'] = '';
                }
                
                $save_data['site_id'] = $this->site_id;
                $save_data['add_time'] = time();
                
                if( !$this->check_unique($save_data['keyword']) ){
                    $this->show_message(false, '该关键词已被定义', '',1);return FALSE;
                }
                
                if( $forward_id=$this->model->add($save_data) ){
                    
                    //关键字回复
                    //$this->save_keyword($save_data['title'], $save_data['keyword'],$save_data['show_img'], $forward_id);
                    
                    $this->show_message(true, '添加成功', '/c/forward/index');return FALSE;
                }else{
                    $this->show_message(false, '添加失败', '/c/forward/index');return FALSE;
                }
                
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            //需完善信息项
            $this->load->library('Mongo_db');
            $field_list = $this->mongo_db->where(array('wid'=>$this->site_info['id']))->order_by(array('sort', 'ASC'))->get('account_fields');
            $this->data['field_list'] = $field_list;
            
            $this->load->view($this->dcm, $this->data);
        }    
    }
    
    public function edit($id='')
    {
        $where = array(
            'site_id' => $this->site_id,
            'id' => $id,
            'status' => 0
        );
        $forward = $this->model->where($where)->find();
        if( !$forward ){
            $this->show_message(false, '非法操作', '',1);return FALSE;
        }
        if( $forward['required_fields'] ){
            $forward['required_fields'] = explode(',', $forward['required_fields']);
        }
        
        if( $this->input->post() ){
            $this->form_validation->set_rules('title', '标题', 'trim|required|max_length[15]');
            $this->form_validation->set_rules('summary', '摘要', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('img', '图标', 'trim|required|callback__check_image');
            $this->form_validation->set_rules('forward_url', '转发地址', 'trim|required|max_length[255]|prep_url');
            $this->form_validation->set_rules('keyword', '活动关键词', 'trim|required|max_length[10]');
            $this->form_validation->set_rules('show_img', '封面图片', 'trim|required|callback__check_image');
            if( time()<$forward['start_time'] ){
                $this->form_validation->set_rules('start_time', '开始时间', 'trim|required|max_length[20]');
                $this->form_validation->set_rules('end_time', '结束时间', 'trim|required|max_length[20]');
            }
            $this->form_validation->set_rules('show_rank', '手机显示总排名', 'trim|required|numeric|greater_than_equal_to[0]');
            $this->form_validation->set_rules('rule', '奖励规则', 'trim|required|htmlspecialchars');
            if ( $this->form_validation->run() ){
                
                $save_data['title'] = $this->form_validation->set_value('title');
                $save_data['summary'] = $this->form_validation->set_value('summary');
                $save_data['img'] = $this->form_validation->set_value('img');
                $save_data['forward_url'] = $this->form_validation->set_value('forward_url');
                $save_data['keyword'] = $this->form_validation->set_value('keyword');
                
                if( time()<$forward['start_time'] ){
                    $save_data['start_time'] = $this->form_validation->set_value('start_time');
                    $save_data['end_time'] = $this->form_validation->set_value('end_time');
                }
                
                $save_data['show_rank'] = $this->form_validation->set_value('show_rank');
                $save_data['show_img'] = $this->form_validation->set_value('show_img');
                
                if( time()<$forward['start_time'] ){
                    if( strtotime($save_data['start_time']) ){
                        $save_data['start_time'] = strtotime($save_data['start_time']);
                    }else{
                        $this->show_message(false, '开始时间格式非法', '',1);return FALSE;
                    }
                    
                    if( strtotime($save_data['end_time']) ){
                        $save_data['end_time'] = strtotime($save_data['end_time']);
                    }else{
                        $this->show_message(false, '结束时间格式非法', '',1);return FALSE;
                    }
                    if( intval($save_data['start_time'])>=intval($save_data['end_time']) ){
                        $this->show_message(false, '开始时间必须小于结束时间', '',1);return FALSE;
                    }
                }
                
                $save_data['rule'] = $this->form_validation->set_value('rule');
                
                //完善信息部分
                $required_fields = $this->input->post('required_fields') ? $this->input->post('required_fields') : array();
                $save_data['required_fields'] = $required_fields;
                if( $save_data['required_fields'] ){
                    $save_data['required_fields'] = implode(',', $required_fields);
                }else{
                    $save_data['required_fields'] = '';
                }
                
                if( $forward['keyword'] != $save_data['keyword'] &&  !$this->check_unique($save_data['keyword']) ){
                    $this->show_message(false, '该关键词已被定义', '',1);return FALSE;
                }
                
                if( $this->model->where($where)->edit($save_data) ){
                    
/*                    $this->load->model('model_reply');
                    if( $reply_forward=$this->model_reply->forward_get($forward['id']) ){//更新
                        if( ($forward['keyword']!=$save_data['keyword'])||($forward['show_img']!=$save_data['show_img'])||($forward['title']!=$save_data['title']) ){
                            $reply_set['keyword'] = $save_data['keyword'];
                            $reply_set['content'] = json_encode(array(
                                'id'    => $forward['id'],
                                'title' => $save_data['title'],
                                'image' => $save_data['show_img'],
                                'url'   => '/turn?id='.$forward['id'],
                                'rank'  => 9999
                            ));
                            $this->model_reply->update(array('id'=>$reply_forward['reply_id']),$reply_set);
                        }
                    }else{//添加
                        $this->save_keyword($save_data['title'], $save_data['keyword'], $forward['id']);
                    }*/
                    
                    $this->show_message(true, '保存成功', '/c/forward/index');return FALSE;
                }else{
                    $this->show_message(false, '保存失败', '/c/forward/index');return FALSE;
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            //需完善信息项
            $this->load->library('Mongo_db');
            $field_list = $this->mongo_db->where(array('wid'=>$this->site_info['id']))->order_by(array('sort', 'ASC'))->get('account_fields');
            $this->data['field_list'] = $field_list;
            $this->data['forward'] = $forward;
            
            $this->load->view($this->dcm, $this->data);
        }
        
    }
    
    //保存自动回复
/*    private function save_keyword($name,$keyword,$image,$save_id)
    {
        $reply_set['keyword'] = $keyword;
        $reply_set['type']    = 'forward';
        $reply_set['user_id'] = $this->site_id;
        $reply_set['content'] = json_encode(array(
            'id'    => $save_id,
            'title' => $name,
            'image' => $image,
            'url'   => '/turn?id='.$save_id,
            'rank'  => 9999
        ));
        $this->load->model('model_reply');
        $reply_id = $this->model_reply->add($reply_set);
        if ( $reply_id ) {
            $this->model_reply->forward_add($reply_id, $save_id, 9999);
        }
    }*/
    
    
    //删除
    public function delete($id='')
    {
        $where = array(
            'site_id' => $this->site_id,
            'id' => $id,
            'status' => 0
        );
        $forward = $this->model->where($where)->find();
        if( !$forward ){
            $this->show_message(false, '非法操作', '',1);return FALSE;
        }
        if( $this->model->where($where)->edit(array('status'=>-1)) ){
            
            //删除自动回复TODO
/*            $this->load->model('model_reply');
            if( $reply_forward=$this->model_reply->forward_get($id) ){
                $this->model_reply->forward_delete($reply_forward['reply_id'],$id);
                $this->model_reply->delete(array('id'=>$reply_forward['reply_id']));
            }*/
            
            $this->show_message(true, '删除成功', '/c/forward/index');return FALSE;
        }else{
            $this->show_message(false, '删除失败', '/c/forward/index');return FALSE;
        }
    }
    
    //排名
    public function rank($id='')
    {
        $where = array(
            'site_id' => $this->site_id,
            'id' => $id,
            'status' => 0
        );
        $forward = $this->model->where($where)->find();
        if( !$forward ){
            $this->show_message(false, '非法操作', '',1);return FALSE;
        }
        
        $this->load->model('forward_statistics_model');
        
        $total_rows = $this->forward_statistics_model->where(array('site_id'=>$this->site_id,'forward_id'=>$id))->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15));
        $list = $this->forward_statistics_model
                ->where(array('site_id'=>$this->site_id,'forward_id'=>$id))
                ->limit($pager['limit']['value'], $pager['limit']['offset'])
                ->order_by('forward_num desc,last_time asc')
                ->find_all();
        $this->load->model('model_account');
        foreach( $list as $key=>$val ){
            $account = $this->model_account->get_row(array('wid'=>$this->site_id,'id'=>$val['uid']));
            if( $forward['required_name'] ){
                $list[$key]['name'] = $account['name'];
            }
            if( $forward['required_mobile'] ){
                $list[$key]['mobile'] = $account['mobile'];
            }
        }
        
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        
        $this->data['forward'] = $forward;
        $this->load->view($this->dcm, $this->data);
    }
    
    //导出
    public function export($id='')
    {
        $where = array(
            'site_id' => $this->site_id,
            'id' => $id,
            'status' => 0
        );
        $forward = $this->model->where($where)->find();
        if( !$forward ){
            $this->show_message(false, '非法操作', '',1);return FALSE;
        }
        
        $this->load->model('forward_statistics_model');
        $list = $this->forward_statistics_model
                ->where(array('site_id'=>$this->site_id,'forward_id'=>$id))
                ->order_by('forward_num desc,last_time asc')
                ->find_all();
        $this->load->model('model_account');
        foreach( $list as $key=>$val ){
            $account = $this->model_account->get_row(array('wid'=>$this->site_id,'id'=>$val['uid']));
            if( $forward['required_name'] ){
                $list[$key]['name'] = $account['name'];
            }
            if( $forward['required_mobile'] ){
                $list[$key]['mobile'] = $account['mobile'];
            }
        }
        
        $fields = array(
            'uid' => 'UID',
            'name'=>'用户名',
            'mobile'=>'手机号',
            'forward_num'=>'转发浏览量'
        );
        $this->excel_export('转发有礼排行版：'.$forward['title'], '转发排行版', $fields, $list);
    }
    
    //统计
    public function statistics($id='')
    {
        $where = array(
            'site_id' => $this->site_id,
            'id' => $id,
            'status' => 0
        );
        $forward = $this->model->where($where)->find();
        if( !$forward ){
            $this->show_message(false, '非法操作', '',1);return FALSE;
        }
        $this->data['forward'] = $forward;
        $this->load->view($this->dcm, $this->data);
    }
    
    
    //修改统计数字
    public function edit_totals()
    {
        header('Content-type: application/json');
        $id = $this->input->get_post('id');
        if( !$id ){
            echo json_encode(array(
                'success' => -1,
                'msg'  => '非法操作'
            ));exit;
        }
        $this->load->model('forward_statistics_model');
        $forward_statistics = $this->forward_statistics_model->where(array('id'=>$id, 'site_id'=>$this->site_id))->find();
        if(!$forward_statistics)
        {
            echo json_encode(array(
                'success' => -1,
                'msg'  => '非法操作'
            ));exit;
        }
        $value = intval($this->input->get('value'));
        if( $value<0 ){
            echo json_encode(array(
                'success' => -1,
                'msg'  => '非法操作'
            ));exit;
        }
        if ($this->forward_statistics_model->where(array('site_id'=>$this->site_id, 'id'=>$id))->edit(array('forward_num'=>$value))) {
            echo json_encode(array(
                'success' => 1
            ));
        }else{
            echo json_encode(array(
                'success' => -1,
                'msg'  => '修改失败'
            ));exit;
        }
    }
    
    
    //检查关键词是否在该微网站下唯一
    public function check_unique($keyword)
    {
        $where = array(
            'site_id' => $this->site_id,
            'keyword' => $keyword,
            'status' => 0
        );
        $res = $this->model->where($where)->find();
        if( $res ){
            return false;
        }else{
            return true;
        }
    }
    
    
    //检查图片格式
    public function _check_image($image) {
        if ($image) {
            if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
                $this->form_validation->set_message('_check_image', '图片地址格式错误');
                return FALSE;
            }
        }
        return TRUE;
    }
} 