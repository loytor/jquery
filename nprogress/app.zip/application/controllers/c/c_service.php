<?php
/**
 * Created by PhpStorm.
 * User: 111
 * Date: 14-5-9
 * Time: 下午2:04
 */

class C_service extends C_Controller {

    private $site_id = '';

    public function __construct()
    {
        parent::__construct();
        $this->site_id = $this->site_info['id'];
    }

    public function index()
    {
        $this->load->model('model_app_config');
        $c_service = $this->model_app_config->get_row(array('user_id'=>$this->site_id, 'type'=>'transfer_customer_service'));

        $update = 0;
        if($c_service && $c_service['config'])
        {
            $update = 1;
            $c_service['config'] = json_decode($c_service['config'],true);
        }
        if( $this->input->post() )
        {
            $open = $this->input->post('open');
            $save_data['open'] = $open ? 1 : 0;

            $keyword = trim($this->input->post('keyword'));
            if(empty($keyword))
            {
                $this->show_message(false, '关键词不能为空', '');return FALSE;
            }
            $save_data['keyword'] = $keyword;

            $saveData['config'] = json_encode($save_data);

            if($update == 1)
            {
                $this->model_app_config->update(array('user_id'=>$this->site_id, 'type'=>'transfer_customer_service'), $saveData);
            }
            else
            {

                $saveData['user_id'] = $this->site_id;
                $saveData['type'] = 'transfer_customer_service';
                $this->model_app_config->add($saveData,true);
            }
            $this->show_message(true, '保存成功', '/c/c_service');return FALSE;
        }
        else
        {
            $this->data['service'] = $c_service;
            $this->load->view($this->dcm, $this->data);
        }
    }

    public function plugin()
    {
        $this->data['viewurl'] = $this->create_url('');
        $this->load->view($this->dcm, $this->data);
    }

    public function faq()
    {
        $this->load->view($this->dcm, $this->data);
    }

    public function down()
    {
        $this->load->view($this->dcm, $this->data);
    }

    public function wxhelper()
    {
        $this->load->view($this->dcm, $this->data);
    }
} 