<?php
/**
 * Created by solaa.
 * User: solaa
 * Date: 2014/11/24 9:29
 */

class PhotoVote_apply extends C_Controller{

    private $site_id = '';
    private $vote = array();

    public function __construct()
    {

        parent::__construct();
        $this->site_id = $this->site_info['id'];

        $this->load->model( 'photoVote_apply_model' );
        $this->apply_model = $this->photoVote_apply_model;
        $this->load->model( 'photoVote_apply_img_model' );
        $this->apply_img_model = $this->photoVote_apply_img_model;

        //自动开始活动
        $this->db->query("UPDATE `weixin`.`wb_photoVote` SET `status` = '2' WHERE site_id = '".$this->site_id."' AND is_delete = 0 AND status = 1 AND ( (vote_stime <= ".time().") OR (upload_stime <= ".time().") )");
        //自动处理过期活动
        $this->db->query("UPDATE `weixin`.`wb_photoVote` SET `status` = '3' WHERE site_id = '".$this->site_id."' AND is_delete = 0 AND status < 3 AND vote_etime <= ".time());
    }

    public function index( $id='' )
    {
        if( !$id ){
            return $this->show_message( FALSE, '参数不完整', '/c/photoVote' );
        }

        $this->get_vote( $id );
        $this->data['vote'] = $this->vote;

        $where['site_id'] = $this->site_id;
        $where['vote_id'] = $this->vote['id'];
        $where['is_delete'] = 0;

        $search['status'] = $this->input->get( 'status' );
        if( $search['status'] ){
            $where['status'] = intval( $search['status'] );
        }else{
            $where['status !='] = 3;
        }
        $search['keyword'] = $this->input->get( 'keyword' );
        if( $search['keyword'] ){
            $where_str = "( (title LIKE '%".$search['keyword']."%') OR (name LIKE '%".$search['keyword']."%') OR (mobile LIKE '%".$search['keyword']."%') )";
        }
        $this->data['search'] = $this->input->get();

        $this->apply_model->where($where);
        isset($where_str) && $this->apply_model->where($where_str);
        $count = $this->apply_model->count();

        $pager = $this->_pager( $count, array('per_page'=>15) );
        $this->apply_model->where($where);
        isset($where_str) && $this->apply_model->where($where_str);
        $this->apply_model->limit( $pager['limit']['value'], $pager['limit']['offset'] );
        $list = $this->apply_model->find_all();
        if( $list ){
            foreach( $list as &$val ){
                $val['img'] = $this->apply_img_model->select('img')->where(array('apply_id'=>$val['id']))->order_by('id asc')->find();
            }
        }

        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->data['search'] = $this->input->get();

        $this->load->view( $this->dcm, $this->data );
    }

    public function detail( $apply_id )
    {
        $vote_id = $this->input->get('vote_id');
        if( !$vote_id ){
            return $this->show_message( FALSE, '参数不完整' );
        }
        $this->get_vote( $vote_id );
        $this->data['vote'] = $this->vote;

        $where['is_delete'] = 0;
        $where['site_id'] = $this->site_id;
        $where['id'] = $apply_id;
        $apply = $this->apply_model->where($where)->find();
        if( $apply ){
            $apply['img'] = $this->apply_img_model->where(array('apply_id'=>$apply['id']))->order_by('id asc')->find_all();
        }else{
            return $this->show_message( FALSE, '没有找到该申请' );
        }

        $this->data['info'] = $apply;

        $this->load->view( $this->dcm, $this->data );
    }

    public function edit_status()
    {
        $vote_id = $this->input->post('vote_id');
        if( !$vote_id ){
            exit($this->ajax_return(array('ret'=>1000,'msg'=>'参数不完整')));
        }
        $id = $this->input->post('id');
        if( !$id ){
            exit($this->ajax_return(array('ret'=>1001,'msg'=>'参数不完整')));
        }
        $status = intval( $this->input->post('status') );
        if( ($status!=2)&&($status!=3) ){
            exit($this->ajax_return(array('ret'=>1002,'msg'=>'参数不完整')));
        }
        $this->get_vote( $vote_id, TRUE );

        $apply = $this->apply_model->where(array('id'=>$id,'vote_id'=>$this->vote['id'],'status'=>1,'is_delete'=>0))->find();
        if( !$apply ){
            exit($this->ajax_return(array('ret'=>1003,'msg'=>'没找到该申请信息')));
        }

        if( $status==2){
            if( $this->apply_model->where(array('id'=>$apply['id']))->edit(array('status'=>$status)) ){
                exit($this->ajax_return(array('ret'=>0,'data'=>array())));
            }else{
                exit($this->ajax_return(array('ret'=>1003,'msg'=>'修改失败')));
            }
        }else if( $status==3 ){
            if( $this->apply_model->where(array('id'=>$apply['id']))->edit(array('status'=>$status)) ){
                $option_sn = $this->createSn( $this->vote['id'] );

                $add_data['site_id'] = $this->site_id;
                $add_data['vote_id'] = $this->vote['id'];
                $add_data['option_sn'] = $option_sn;
                $add_data['is_sys'] = 0;
                $add_data['apply_id'] = $apply['id'];
                $add_data['name'] = $apply['name'];
                $add_data['mobile'] = $apply['mobile'];
                $add_data['title'] = $apply['title'];
                $add_data['add_time'] = time();
                $add_data['user_add_time'] = $apply['add_time'];
                $this->load->model('photoVote_option_model');
                if( $new_id = $this->photoVote_option_model->add($add_data) ){

                    $sql = "INSERT INTO wb_photoVote_option_img (option_id,img,intro,media,url) SELECT ".$new_id.",img,intro,media,url FROM wb_photoVote_apply_img where apply_id = ".$apply['id'];
                    $this->db->query( $sql );
                    exit($this->ajax_return(array('ret'=>0,'data'=>array())));
                }else{
                    $this->apply_model->where(array('id'=>$apply['id']))->edit(array('status'=>1));
                    exit($this->ajax_return(array('ret'=>1003,'msg'=>'修改失败')));
                }
            }else{
                exit($this->ajax_return(array('ret'=>1003,'msg'=>'修改失败')));
            }
        }
    }

    public function delete_apply( $apply_id='' )
    {
        $apply = $this->apply_model->where(array('id'=>$apply_id,'site_id'=>$this->site_id,'is_delete'=>0))->find();
        if( !$apply ){
            exit($this->ajax_return(array('ret'=>1003,'msg'=>'没找到该申请信息')));
        }
        if( $this->apply_model->where(array('id'=>$apply['id']))->edit(array('is_delete'=>1)) ){
            exit($this->ajax_return(array('ret'=>0,'data'=>array())));
        }else{
            exit($this->ajax_return(array('ret'=>1003,'msg'=>'删除失败')));
        }


        /*if( $this->apply_model->where(array('id'=>$apply['id']))->delete() ){
            $this->load->model( 'photoVote_apply_img_model' );
            $this->photoVote_apply_img_model->where(array('apply_id'=>$apply['id']))->delete();
            exit($this->ajax_return(array('ret'=>0,'data'=>array())));
        }else{
            exit($this->ajax_return(array('ret'=>1003,'msg'=>'删除失败')));
        }*/
    }

    /**
     *
     * @author Qianc
     * @date 2014-8-29
     * @description 生成随机邀请码
     */
    protected function createSn($vote_id)
    {
        $this->load->model('photoVote_option_model');
        if(intval($vote_id)){
            $randCode = null;
            $isBreak = false;
            do
            {
                $randCode = mt_rand(1000, 9999);    # 推入随机数
                $where['vote_id'] = intval($vote_id);
                $where['option_sn'] = "V".$randCode;
                $count = $this->photoVote_option_model
                    ->select('option_sn')
                    ->where($where)->count();
                $isBreak = $count > 0 ? false : true;
            }while (!$isBreak) ;
            return "V".$randCode;
        }
    }


    private function get_vote( $vote_id='', $json=FALSE )
    {
        $this->load->model('photoVote_model');

        $where['site_id'] = $this->site_id;
        $where['id'] = $vote_id;
        $where['is_delete'] = 0;
        $vote = $this->photoVote_model->select('id,title')->where($where)->find();
        if( !$vote ){
            if( !$json ){
                return $this->show_message( FALSE, '没有找到该投票活动', '/c/photoVote' );
            }
            if( $json ){
                exit($this->ajax_return(array('ret'=>1110,'msg'=>'没有找到该投票活动')));
            }
        }
        $this->vote = $vote;
    }

} 