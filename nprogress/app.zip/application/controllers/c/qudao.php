<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 渠道管理
 * 4位  编号0001
 * 删除  加标志位
 */
class Qudao extends C_Controller {

    protected $auto_load_model = TRUE;
    protected $model_name = 'qudao';
    protected $data = '';
    private $site_id = '';
    protected $qudaoconfig = array();
    
    private $errorCodeArr = array(
        '-1' => '系统繁忙',
        '40002' => '不合法的凭证类型',
        '40013' => '不合法的APPID',
        '40014' => '不合法的access_token',
        '42001' => '请求超时',//access_token超时
        '48001' => '功能未授权',//api功能未授权
        '50001' => '用户未授权',//用户未授权该api
    );

    public function __construct()
    {
        parent::__construct();
        $this->site_id = $this->site_info['id'];
        
        $this->load->model('qudao_cate_model');
        
        $this->data['qudaoconfig'] = $this->qudaoconfig = $this->get_config();
    }
    
    /**
     * 微信公众号 appid
     */
    private function get_config()
    {
        //从token服务器获取数据
        $this->load->library('Mongo_db');
        $wx = $this->mongo_db->where(array('site_id'=>$this->site_id))->get_one(MONGO_WX_SET);
        if( !$wx ){
            exit('获取微信配置失败');
        }
        if( !isset($wx['hao'])||!$wx['hao'] ){
            exit("请配置您的微信配置信息");
        }
        $config['mp_username'] = isset($wx['hao']) ? $wx['hao'] : '';//公众账号名
        $config['is_qrcode_api'] = 0;//没有高级接口权限

        if( isset($wx['appid'])&&$wx['appid'] ){
            $this->load->library('wbcurl');
            $response = $this->wbcurl->simple_post(TOKEN_WX_SERVER . 'info', array('app_id'=>$wx['appid']));
            $response = json_decode($response,true);
            if( $response['ret']==0 ){
                if( !(2&$response['ability_rank']) ){//没有高级接口权限
                    $config['is_qrcode_api'] = 0;
                }else{
                    $config['is_qrcode_api'] = 1;
                }
                $config['token'] = $response['token'];
            }else{
                exit($response['msg']);
            }
        }
        return $config;
    }
    
    
    public function index()
    {
        $this->session->set_userdata(array('qudao_index_uri'=>$_SERVER['REQUEST_URI']));
        $where = "qudao.site_id = '".$this->site_id."' AND is_delete = 0";
        
        $this->cate_level();
        
        $search_url = site_url($this->uri->uri_string().'?');
        $search['parent_cate_id'] = $this->input->get('parent_cate_id');
        $search['cate_id'] = $this->input->get('cate_id');
        $search['status'] = $this->input->get('status');
        $search['keyword'] = $this->input->get('keyword');
        
        if( $search['status']!==''&&$search['status']!==null ){
            $where .= " AND qudao.status =".$search['status'];
            $search_url .= '&status='.$search['status'];
        }
        if( $search['parent_cate_id'] ){
            $where .= " AND qudao.parent_cate_id = ".$search['parent_cate_id'];
            $search_url .= '&parent_cate_id='.$search['parent_cate_id'];
        }
        if( $search['cate_id'] ){
            $where .= " AND qudao.cate_id = ".$search['cate_id'];
            $search_url .= '&cate_id='.$search['cate_id'];
        }
        if( $search['keyword'] ){
            $where .= " AND ( qudao.name like '%".$search['keyword']."%' ) ";
            $search_url .= '&keyword='.$search['keyword'];
        }
        
        $total_rows = $this->model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$search_url));
        $list = $this->model
            ->select('qudao.*,qudao_cate.name as cate_name')
            ->join('qudao_cate','qudao_cate.id=qudao.cate_id')
            ->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->order_by('qudao.id desc')->where($where)->find_all();
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        if( $list ){
            $this->load->model('qudao_wxid_model');
            foreach( $list as $key=>$val ){
                $list[$key]['bind_num'] = $this->qudao_wxid_model->where(array('site_id'=>$this->site_id,'qudao_id'=>$val['id']))->count();
            }
        }
        
        $this->data['list'] = $list;
        
        $this->load->model('qudao_zhibiao_model');
        $zhibiao_list = $this->qudao_zhibiao_model->where(array('site_id'=>$this->site_id))->find_all();
        $this->data['zhibiao_list'] = $zhibiao_list;
        
        $this->data['search'] = $search;
        
        $this->load->view($this->dcm,$this->data);
    }
    
    //分组分级
    public function cate_level()
    {
        $cate_level = array();
        $temp = $this->qudao_cate_model->select('id,parent_id,name,prefix')->where(array('site_id'=>$this->site_id))->order_by('id desc')->find_all();
        if( $temp ){
            foreach( $temp as $val ){
                if( $val['parent_id']==0 ){
                    $cate_level['parent'][] = $val;
                }else{
                    $cate_level['child'][$val['parent_id']][] = $val;
                }
            }
        }
        $this->data['cate_level'] = $cate_level;
    }

    /**
     * 增加渠道
     */
    public function add()
    {
        if( $this->input->post() ){
            $this->form_validation->set_rules('name', '渠道名称', 'trim|required|max_length[100]');
            $this->form_validation->set_rules('parent_cate_id', '渠道一级分组', 'trim|required|intval');
            $this->form_validation->set_rules('cate_id', '渠道二级分组', 'trim|required|intval');
            $this->form_validation->set_rules('zhibiao_id', '指标', 'trim|required|intval');
            if( $this->qudaoconfig['is_qrcode_api']==1 ){//如果是服务号
                $this->form_validation->set_rules('qrcode', '二维码', 'trim|required');
                $this->form_validation->set_rules('scene_id', '场景值', 'trim|required');
            }
            if( $this->qudaoconfig['is_qrcode_api']==0 ){//如果是订阅号
                $this->form_validation->set_rules('qrcode', '二维码', 'trim');
                $this->form_validation->set_rules('prefix', '渠道关键词前缀', 'trim|required|max_length[20]');
                $this->form_validation->set_rules('keyword', '渠道关键词', 'trim|required|max_length[20]');
            }
            $this->form_validation->set_rules('password', '查询密码', 'trim|required|integer|min_length[6]|max_length[10]');
            $this->form_validation->set_rules('memo', '渠道说明', 'trim|max_length[500]|htmlspecialchars');
            
            $this->form_validation->set_rules('reply_title', '回复标题', 'trim|max_length[50]');
            $this->form_validation->set_rules('reply_url', '链接地址', 'trim|max_length[255]');
            $this->form_validation->set_rules('reply_image', '回复图标', 'trim|callback__check_image');
            
            if ( $this->form_validation->run() ){
                $dataSet['name'] = $this->form_validation->set_value('name');
                $dataSet['parent_cate_id'] = $this->form_validation->set_value('parent_cate_id');
                $dataSet['cate_id'] = $this->form_validation->set_value('cate_id');
                $dataSet['zhibiao_id'] = $this->form_validation->set_value('zhibiao_id');
                $dataSet['qrcode'] = $this->form_validation->set_value('qrcode');
                
                if( $this->qudaoconfig['is_qrcode_api']==1 ){//服务号  判断唯一
                    $dataSet['scene_id'] = $this->form_validation->set_value('scene_id');
                    if( !$this->check_unique('scene_id', $dataSet['scene_id']) ){
                        $this->show_message(false, '该二维码已被使用', '', 1);
                        return false;
                    }
                }
                if( $this->qudaoconfig['is_qrcode_api']==0 ){//如果是订阅号 判断唯一
                    $prefix = $this->form_validation->set_value('prefix');
                    $dataSet['keyword'] = $prefix.$this->form_validation->set_value('keyword');
                    if( !$this->check_unique('keyword', $dataSet['keyword']) ){
                        $this->show_message(false, '该渠道编号已被使用', '', 1);
                        return false;
                    }
                }
                $dataSet['password'] = $this->form_validation->set_value('password');
                $dataSet['memo'] = $this->form_validation->set_value('memo');
                $dataSet['site_id'] = $this->site_id;
                $dataSet['add_time'] = time();
                
                //关联成功回复
                $reply_open = intval($this->input->post('reply_open'));
                if( $reply_open==1 ){
                    $dataSet['reply_title'] = $this->form_validation->set_value('reply_title');
                    if( $dataSet['reply_title']=='' ){
                        $this->show_message(false, '回复标题必须填写', '', 1);return false;
                    }
                    $dataSet['reply_url'] = $this->form_validation->set_value('reply_url');
                    if( $dataSet['reply_url']=='' ){
                        $this->show_message(false, '链接地址必须填写', '', 1);return false;
                    }
                    $dataSet['reply_image'] = $this->form_validation->set_value('reply_image');
                }else{
                    $dataSet['reply_title'] = '';
                    $dataSet['reply_url'] = '';
                    $dataSet['reply_image'] = '';
                }
                
                if( !$id=$this->model->add($dataSet) ){
                    if( $this->session->userdata('qudao_index_uri') ){
                        $this->show_message(false, '添加失败', $this->session->userdata('qudao_index_uri') );
                    }else{
                        $this->show_message(false, '添加失败', '',1);
                    }  
                    return FALSE;
                }else{
                    if( $this->session->userdata('qudao_index_uri') ){
                        $this->show_message(true, '添加成功', $this->session->userdata('qudao_index_uri') );
                    }else{
                        $this->show_message(true, '添加成功', '',1);
                    }
                    return FALSE;
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            
            $this->cate_level();
            
            $this->load->model('qudao_zhibiao_model');
            $zhibiao_list = $this->qudao_zhibiao_model->where(array('site_id'=>$this->site_id))->find_all();
            $this->data['zhibiao_list'] = $zhibiao_list;
            
            $total_rows = $this->model->where(array('site_id'=>$this->site_id))->count();
            $this->data['auto_count'] = intval($total_rows)+1;
            
            $this->load->view($this->dcm,$this->data);
        }
    }
    
    //批量增加渠道
    public function multi_add()
    {
        header('Content-type: application/json');
        
        $cate_id = trim($this->input->post('cate_id'));
        $num = intval(trim($this->input->post('num')));
        if( $num<=0 ){
            $data = array(
                'error' => 2,
                'msg'   => '请填写要添加的个数'
            );
            echo json_encode($data);exit;
        }
        if( $num>200 ){
            $data = array(
                'error' => 2,
                'msg'   => '批量添加，一次最多200个'
            );
            echo json_encode($data);exit;
        }
        if( !$cate_id ){
            $data = array(
                'error' => 1,
                'msg'   => '非法提交'
            );
            echo json_encode($data);exit;
        }
        $this->load->model('qudao_cate_model');
        $cate = $this->qudao_cate_model->where(array('site_id'=>$this->site_id,'id'=>$cate_id))->find();
        if( !$cate ){
            $data = array(
                'error' => 1,
                'msg'   => '非法提交'
            );
            echo json_encode($data);exit;
        }
        $parent_cate = $this->qudao_cate_model->where(array('site_id'=>$this->site_id,'id'=>$cate['parent_id']))->find();
        if( !$parent_cate ){
            $data = array(
                'error' => 1,
                'msg'   => '非法提交'
            );
            echo json_encode($data);exit;
        }
        
        $j = 1;
        for( $i=0;$i<$num;$i++ ){
            
            if( $this->qudaoconfig['is_qrcode_api']==1 ){//服务号  判断唯一
                $scene = $this->get_qrcode(true);
                $save_data['name'] = '未命名渠道';
                $save_data['site_id'] = $this->site_id;
                $save_data['parent_cate_id'] = $parent_cate['id'];
                $save_data['cate_id'] = $cate['id'];
                $save_data['password'] = '123456';
                $save_data['qrcode'] = $scene['image'];
                $save_data['scene_id'] = $scene['scene_id'];
                $save_data['zhibiao_id'] = 0;
                $save_data['status'] = 0;
                $save_data['add_time'] = time();
                $this->model->add($save_data);
            }
            if( $this->qudaoconfig['is_qrcode_api']==0 ){//如果是订阅号 判断唯一
                $prefix = $parent_cate['prefix'].''.$cate['prefix'];
                $total_rows = $this->model->where(array('site_id'=>$this->site_id))->count();
                $keyword = $prefix.''.($total_rows+$j);
                while( !$this->check_unique('keyword', $keyword) ){
                    $j++;
                    $keyword = $prefix.''.($total_rows+$j);
                }
                $save_data['name'] = '未命名渠道';
                $save_data['site_id'] = $this->site_id;
                $save_data['parent_cate_id'] = $parent_cate['id'];
                $save_data['cate_id'] = $cate['id'];
                $save_data['password'] = '123456';
                $save_data['keyword'] = $keyword;
                $save_data['zhibiao_id'] = 0;
                $save_data['status'] = 0;
                $save_data['add_time'] = time();
                $this->model->add($save_data);
            }
        }
        
        $data = array(
            'error' => 0,
            'redirect_url' => '/c/qudao/index?parent_cate_id='.$parent_cate['id'].'&cate_id='.$cate['id']
        );
        echo json_encode($data);exit;
    }

    /**
     * @name 编辑渠道
     * @param $id
     * @return bool
     */
    public function edit($id)
    {
        if(!$id){
            $this->show_message(false, '非法参数', 1);return false;
        }
        $qudao = $this->model->where(array('id'=>$id,'site_id'=>$this->site_id,'is_delete'=>0))->find();
        if(!$qudao){
            $this->show_message(false, '渠道不存在', 1);return false;
        }

        if( $this->input->post() ){
            $this->form_validation->set_rules('name', '渠道名称', 'trim|required|max_length[100]');
            $this->form_validation->set_rules('cate_id', '渠道分组', 'trim|required|intval');
            $this->form_validation->set_rules('zhibiao_id', '指标', 'trim|required|intval');
            if( $this->qudaoconfig['is_qrcode_api']==0 ){//如果是订阅号
                $this->form_validation->set_rules('prefix', '渠道关键词前缀', 'trim|required|max_length[20]');
                $this->form_validation->set_rules('keyword', '渠道关键词', 'trim|required|max_length[20]');
            }
            $this->form_validation->set_rules('password', '查询密码', 'trim|required|integer|min_length[6]|max_length[10]');
            $this->form_validation->set_rules('memo', '渠道说明', 'trim|max_length[500]|htmlspecialchars');
            
            $this->form_validation->set_rules('reply_title', '回复标题', 'trim|max_length[50]');
            $this->form_validation->set_rules('reply_image', '回复图标', 'trim|callback__check_image');
            $this->form_validation->set_rules('reply_url', '链接地址', 'trim|max_length[255]');
            if ( $this->form_validation->run() ){
                $dataSet['name'] = $this->form_validation->set_value('name');
                $dataSet['cate_id'] = $this->form_validation->set_value('cate_id');
                $dataSet['zhibiao_id'] = $this->form_validation->set_value('zhibiao_id');
                $dataSet['password'] = $this->form_validation->set_value('password');
                $dataSet['memo'] = $this->form_validation->set_value('memo');
                
                //关联成功回复
                $reply_open = intval($this->input->post('reply_open'));
                if( $reply_open==1 ){
                    $dataSet['reply_title'] = $this->form_validation->set_value('reply_title');
                    if( $dataSet['reply_title']=='' ){
                        $this->show_message(false, '回复标题必须填写', '', 1);return false;
                    }
                    $dataSet['reply_url'] = $this->form_validation->set_value('reply_url');
                    if( $dataSet['reply_url']=='' ){
                        $this->show_message(false, '链接地址必须填写', '', 1);return false;
                    }
                    $dataSet['reply_image'] = $this->form_validation->set_value('reply_image');
                }else{
                    $dataSet['reply_title'] = '';
                    $dataSet['reply_url'] = '';
                    $dataSet['reply_image'] = '';
                }
                
                if( $dataSet['cate_id'] ){
                    $qudao_cate = $this->qudao_cate_model->where(array( 'site_id'=>$this->site_id,'id'=>$dataSet['cate_id'] ))->find();
                    if( $qudao_cate ){
                        $dataSet['parent_cate_id'] = $qudao_cate['parent_id'];
                    }else{
                        $this->show_message(false, '渠道分组错误', '', 1);
                        return false;
                    }
                }
                
                if( $this->qudaoconfig['is_qrcode_api']==0 ){//如果是订阅号 判断唯一
                    $prefix = $this->form_validation->set_value('prefix');
                    $dataSet['keyword'] = $prefix.$this->form_validation->set_value('keyword');
                    if( $dataSet['keyword']!=$qudao['keyword'] ){
                        if( !$this->check_unique('keyword', $dataSet['keyword']) ){
                            $this->show_message(false, '该渠道编号已被使用', '', 1);
                            return false;
                        }
                    }
                }
                
                if(false === $this->model->where(array('id'=>$id, 'site_id'=>$this->site_id))->edit($dataSet) ){
                    $this->show_message(false, '编辑失败', '',1);return FALSE;
                }else{
                    if( $this->session->userdata('qudao_index_uri') ){
                        $this->show_message(true, '编辑成功', $this->session->userdata('qudao_index_uri') );
                    }else{
                        $this->show_message(true, '编辑成功', '',1);
                    }
                    return FALSE;
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            
            $this->cate_level();
            
            $this->load->model('qudao_zhibiao_model');
            $zhibiao_list = $this->qudao_zhibiao_model->where(array('site_id'=>$this->site_id))->find_all();
            $this->data['zhibiao_list'] = $zhibiao_list;
            
            //拆分渠道编号
            $this->data['prefix'] = '';
            if( isset($this->data['cate_level']['parent'])&&$this->data['cate_level']['parent'] ){
                foreach( $this->data['cate_level']['parent'] as $v1 ){
                    if( $v1['id']==$qudao['parent_cate_id'] ){
                        $this->data['prefix'] .= $v1['prefix'];
                        
                        //二级前缀
                        if( isset($this->data['cate_level']['child'][$v1['id']])&&$this->data['cate_level']['child'][$v1['id']] ){
                            foreach( $this->data['cate_level']['child'][$v1['id']] as $v2 ){
                                if( $v2['id']==$qudao['cate_id'] ){
                                    $this->data['prefix'] .= $v2['prefix'];
                                    break;
                                }
                            }
                        }
                        break;
                    }
                }
            }
            $qudao['keyword'] = str_replace($this->data['prefix'], '', $qudao['keyword']);
            
            $this->data['qudao'] = $qudao;
            $this->load->view($this->dcm,$this->data);
        }
    }
    
    public function offline($id)
    {
        if(!$id){
            $this->show_message(false, '非法参数', 1);return false;
        }
        $qudao = $this->model->where(array('id'=>$id,'site_id'=>$this->site_id,'is_delete'=>0))->find();
        if(!$qudao){
            $this->show_message(false, '渠道不存在', 1);return false;
        }
        if( $qudao['status']==0 ){
            $this->model->where(array('id'=>$id, 'site_id'=>$this->site_id,'is_delete'=>0))->edit(array('status'=>1));
            $this->show_message(true, '下线成功', '',1);return FALSE;
        }
        $this->show_message(false, '下线失败', '',1);return FALSE;
    }
    
    public function online($id)
    {
        if(!$id){
            $this->show_message(false, '非法参数', 1);return false;
        }
        $qudao = $this->model->where(array('id'=>$id,'site_id'=>$this->site_id,'is_delete'=>0))->find();
        if(!$qudao){
            $this->show_message(false, '渠道不存在', 1);return false;
        }
        if( $qudao['status']==1 ){
            $this->model->where(array('id'=>$id, 'site_id'=>$this->site_id,'is_delete'=>0))->edit(array('status'=>0));
            $this->show_message(true, '上线成功', '',1);return FALSE;
        }
        $this->show_message(false, '上线失败', '',1);return FALSE;
    }
    
    public function delete($id)
    {
        if(!$id){
            $this->show_message(false, '非法参数', 1);return false;
        }
        $qudao = $this->model->where(array('id'=>$id,'site_id'=>$this->site_id,'is_delete'=>0))->find();
        if(!$qudao){
            $this->show_message(false, '渠道不存在', 1);return false;
        }
        
        //删除用户渠道关系
        $this->load->model('qudao_wxid_model');
        $this->qudao_wxid_model->where(array('qudao_id'=>$id))->delete();
        
        //删除渠道
        $this->model->where(array('id'=>$id))->edit(array('is_delete'=>1));
        $this->show_message(true, '删除成功', '/c/qudao/index');return FALSE;
    }
    
    /**
     * 判断唯一性
     */
    public function check_unique( $field, $value )
    {
        $result = $this->model->where(array('site_id'=>$this->site_id,$field=>$value,'is_delete'=>0))->count();
        if( $result ){
            return false;
        }else{
            return true;
        }
    }
    
    /**
     * 渠道识别关键字
     */
    public function keyword()
    {
        $this->load->model('qudao_keyword_model');
        $info = $this->qudao_keyword_model->where(array('site_id'=>$this->site_id))->find();
        if( !$info ){
            $this->qudao_keyword_model->add(array('site_id'=>$this->site_id));
            $info['keyword'] = '';
        }
        
        if( $this->input->post() ){
            $this->form_validation->set_rules('keyword', '关键字', 'trim|required|max_length[20]');
            $this->form_validation->set_rules('linked', '已关联过回复', 'trim|required|max_length[255]');
            $this->form_validation->set_rules('link', '关联成功回复', 'trim|required|max_length[255]');
            $this->form_validation->set_rules('nolink', '关联失败回复', 'trim|required|max_length[255]');
            
            if ( $this->form_validation->run() ){
                $dataSet['keyword'] = $this->form_validation->set_value('keyword');
                $dataSet['linked'] = $this->form_validation->set_value('linked');
                $dataSet['link'] = $this->form_validation->set_value('link');
                $dataSet['nolink'] = $this->form_validation->set_value('nolink');
                
                $dataSet['manage_keyword'] = $this->form_validation->set_value('manage_keyword');
                if(false === $this->qudao_keyword_model->where(array('site_id'=>$this->site_id))->edit($dataSet) ){
                    $this->show_message(false, '修改失败', '',1);return false;
                }else{
                    $this->show_message(true, '修改成功', '',1);return false;
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }
        
        $this->data['info'] = $info;
        $this->load->view($this->dcm,$this->data);
    }
    
    /**
     * 手机管理关键字
     */
    public function mobile_keyword()
    {
        $this->load->model('qudao_keyword_model');
        $info = $this->qudao_keyword_model->where(array('site_id'=>$this->site_id))->find();
        if( !$info ){
            $this->qudao_keyword_model->add(array('site_id'=>$this->site_id));
            $info['keyword'] = '';
        }
        
        if( $this->input->post() ){
            $this->form_validation->set_rules('manage_keyword', '查寻数据关键词', 'trim|required|max_length[20]');
            if ( $this->form_validation->run() ){
                
                $dataSet['manage_keyword'] = $this->form_validation->set_value('manage_keyword');
                if(false === $this->qudao_keyword_model->where(array('site_id'=>$this->site_id))->edit($dataSet) ){
                    $this->show_message(false, '修改失败', '',1);return false;
                }else{
                    $this->show_message(true, '修改成功', '',1);return false;
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }
        
        $this->data['info'] = $info;
        $this->load->view($this->dcm,$this->data);
    }
    
    /**
     * 服务号  获取二维码
     */
    public function get_qrcode($type=false)
    {
        if( $this->qudaoconfig['is_qrcode_api']==0 ){//订阅号 无此权限
            echo json_encode(array(
                'error' => 1,
                'msg'   => '您的配置信息中没有开通微信高级接口'
            ));exit;
        }
        $max_scene_id = $this->model->select('max(scene_id) as max_scene_id')->where(array('site_id'=>$this->site_id,'is_delete'=>0))->find();
        $scene_id = $max_scene_id['max_scene_id']+1;//场景id
        if( $scene_id>50000 ){
            echo json_encode(array(
                'error' => 1,
                'msg'   => '推广二维码最多支持50000个'
            ));exit;
        }
        
        header('Content-type : application/json');
        $this->load->library('curl');

        $accessToken = $this->qudaoconfig['token'];
        
        if(isset($accessToken)){
            $ticketUrl = 'https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token='.$accessToken;
            $ticketDate = array(
                'action_name' => 'QR_LIMIT_SCENE',
                'action_info' => array(
                    'scene' => array(
                        'scene_id' => $scene_id
                    )
                )
            );
            $tmpTicketInfo = $this->curl->post( $ticketUrl, json_encode($ticketDate) );
            $tmpTicketInfo = json_decode( $tmpTicketInfo, true );
            if(isset($tmpTicketInfo['errcode'])){
                if(isset($this->errorCodeArr[$tmpTicketInfo['errcode']])){
                    echo json_encode(array(
                        'error' => 1,
                        'msg'   => $this->errorCodeArr[$tmpTicketInfo['errcode']]
                    ));exit;
                }else{
                    echo json_encode(array(
                        'error' => 1,
                        'msg'   => 'token获取失败, 腾讯微信错误代码:'.$tmpTicketInfo['errcode'].'错误详情：'.$tmpTicketInfo['errmsg']
                    ));exit;
                }
            }else{
                $ticket = $tmpTicketInfo['ticket'];
            }
            if( isset($ticket) ){
                
                if( $type==true ){
                    return array('image'=>'https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket='.$ticket,'scene_id'=>$scene_id);
                }else{
                    echo json_encode(array(
                        'error' => 0,
                        'image' => 'https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket='.$ticket,
                        'scene_id' => $scene_id
                    ));exit;
                }
                
            }else{
                echo json_encode(array(
                    'error' => 1,
                    'msg' => 'ticket获取失败'
                ));exit;
            }
        }else{
            echo json_encode(array(
                'error' => 1,
                'msg' => 'token获取失败'
            ));exit;
        }
    }
    
    public function account()
    {
        if( isset($_GET['export'])&&($_GET['export']) ){
            $this->account_export();exit;
        }
        
        $this->load->model('qudao_wxid_model');
        $bind_num = 0;
        $search_url = site_url($this->uri->uri_string().'?');
        $search['parent_cate_id'] = $this->input->get('parent_cate_id');
        $search['cate_id'] = $this->input->get('cate_id');
        $search['keyword'] = $this->input->get('keyword');
        
        $where = "qudao.site_id = '".$this->site_id."' AND qudao.is_delete = 0";
        $qudao_id = $this->input->get('id');
        $qudao = array();
        if( $qudao_id ){
            $where .= " AND qudao_wxid.qudao_id = ".$qudao_id;
            $search_url .= '&id='.$qudao_id;
            $qudao = $this->model->where(array('id'=>$qudao_id,'site_id'=>$this->site_id))->find();
            $qudao = $qudao ? $qudao : array();
            
            $qudao['bind_num'] = $this->qudao_wxid_model->where(array('site_id'=>$this->site_id,'qudao_id'=>$qudao_id))->count();
        }
        $this->data['qudao'] = $qudao;
        if( $search['parent_cate_id'] ){
            $where .= " AND qudao.parent_cate_id = ".$search['parent_cate_id'];
            $search_url .= '&parent_cate_id='.$search['parent_cate_id'];
        }
        if( $search['cate_id'] ){
            $where .= " AND qudao.cate_id = ".$search['cate_id'];
            $search_url .= '&cate_id='.$search['cate_id'];
        }
        
        if( $search['keyword'] ){
            $where .= " AND ( (account.wxid like '%".$search['keyword']."%') OR (account.name like '%".$search['keyword']."%') ) ";
            $search_url .= '&keyword='.$search['keyword'];
        }
        
        $total_rows = $this->qudao_wxid_model->where($where)
                      ->join('account','account.wxid=qudao_wxid.wxid','left')
                      ->join('qudao','qudao.id=qudao_wxid.qudao_id')
                      ->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$search_url));
        $list = $this->qudao_wxid_model
                ->select('qudao_wxid.add_time,account.id,account.name,account.wxid,account.mobile,qudao.name as qudao_name,qudao_cate.name as cate_name,qudao.parent_cate_id,qudao.cate_id')
                ->join('account','account.wxid=qudao_wxid.wxid','left')
                ->join('qudao','qudao.id=qudao_wxid.qudao_id')
                ->join('qudao_cate','qudao_cate.id=qudao.cate_id')
                ->limit($pager['limit']['value'], $pager['limit']['offset'])
                ->order_by('account.id desc')->where($where)->find_all();
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->data['total_rows'] = $total_rows;
        
        if( $list ){
            $this->load->model('mcard_member_model');
            foreach( $list as $key=>$val ){
                $list[$key]['card_num'] = '';
                if( $val['id'] ){
                    $mcard = $this->mcard_member_model->select('card_num')->where(array('site_id'=>$this->site_id,'uid'=>$val['id']))->find();
                    if( $mcard ){
                        $list[$key]['card_num'] = $mcard['card_num'];
                    }
                }
            }
        }
        $this->data['list'] = $list;
        
        $this->data['search'] = $search;
        
        $this->cate_level();
        
        $this->load->view($this->dcm,$this->data);
    }
    
    public function account_export()
    {
        $this->load->model('qudao_wxid_model');
        $bind_num = 0;
        $search['parent_cate_id'] = $this->input->get('parent_cate_id');
        $search['cate_id'] = $this->input->get('cate_id');
        $search['keyword'] = $this->input->get('keyword');
        
        $where = "qudao.site_id = '".$this->site_id."' AND qudao.is_delete = 0";
        $qudao_id = $this->input->get('id');
        $qudao = array();
        if( $qudao_id ){
            $where .= " AND qudao_wxid.qudao_id = ".$qudao_id;
            $qudao = $this->model->where(array('id'=>$qudao_id,'site_id'=>$this->site_id))->find();
            $qudao = $qudao ? $qudao : array();
            
            $qudao['bind_num'] = $this->qudao_wxid_model->where(array('site_id'=>$this->site_id,'qudao_id'=>$qudao_id))->count();
        }
        $this->data['qudao'] = $qudao;
        if( $search['parent_cate_id'] ){
            $where .= " AND qudao.parent_cate_id = ".$search['parent_cate_id'];
        }
        if( $search['cate_id'] ){
            $where .= " AND qudao.cate_id = ".$search['cate_id'];
        }
        
        if( $search['keyword'] ){
            $where .= " AND ( (account.wxid like '%".$search['keyword']."%') OR (account.name like '%".$search['keyword']."%') ) ";
        }
        
        $list = $this->qudao_wxid_model
                ->select('qudao_wxid.add_time,account.id,account.name,account.wxid,account.mobile,qudao.name as qudao_name,qudao_cate.name as cate_name,qudao.parent_cate_id,qudao.cate_id')
                ->join('account','account.wxid=qudao_wxid.wxid','left')
                ->join('qudao','qudao.id=qudao_wxid.qudao_id')
                ->join('qudao_cate','qudao_cate.id=qudao.cate_id')
                ->order_by('account.id desc')->where($where)->find_all();
        
        $this->cate_level();
        if( $list ){
            $this->load->model('mcard_member_model');
            foreach ( $list as $key=>$val ){
                
                $list[$key]['parent_cate_name'] = '';
                if( $this->data['cate_level']['parent'] ){
                    foreach( $this->data['cate_level']['parent'] as $v ){
                        if( $v['id']==$val['parent_cate_id'] ){
                            $list[$key]['parent_cate_name'] = $v['name'];
                            break;
                        }
                    }
                }
                
                $list[$key]['card_num'] = '';
                if( $val['id'] ){
                    $mcard = $this->mcard_member_model->select('card_num')->where(array('site_id'=>$this->site_id,'uid'=>$val['id']))->find();
                    if( $mcard ){
                        $list[$key]['card_num'] = $mcard['card_num'];
                    }
                }
                
                $list[$key]['cate_name'] = $list[$key]['parent_cate_name'].'->'.$val['cate_name'];
                $list[$key]['wxid'] = substr($val['wxid'],0,-6).'******';
                $list[$key]['add_time'] = date('Y-m-d H:i:s',$val['add_time']);
            }
            $fields = array(
                '#'=>'#',
                'qudao_name' => '渠道名称',
                'cate_name' => '渠道分组',
                'wxid' => '微信ID',
                'card_num' => '会员卡号',
                'name' => '名称',
                'mobile' => '手机',
                'add_time' => '关联时间'
            );
            $this->excel_export('渠道用户', '渠道用户', $fields, $list);
        }
    }
    
    //检查图片格式
    public function _check_image($image) {
        if ($image) {
            if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
                $this->form_validation->set_message('_check_image', '图片地址格式错误');
                return FALSE;
            }
        }
        return TRUE;
    }
    
    //获取二级分组
    public function get_second_cate($parent_id=0)
    {
        if( $parent_id ){
            $cate_list = $this->qudao_cate_model->select('id,parent_id,name,prefix')->where(array('site_id'=>$this->site_id,'parent_id'=>$parent_id))->order_by('name asc')->find_all();
            $cate_list = $cate_list ? $cate_list : array();
            //var_dump($cate_list);
            header('Content-type: application/json');
            echo json_encode($cate_list);
        }
    }
    
    //月统计   本月没有的应用 需要默认给个0
    public function statistics()
    {
        if( isset($_GET['export'])&&($_GET['export']) ){
            $this->statistics_export();exit;
        }
        
        $this->month_init();
        $where = "qudao.site_id = '".$this->site_id."' AND is_delete = 0";
        
        $this->cate_level();
        
        $search_url = site_url($this->uri->uri_string().'?');
        $search['month'] = $this->input->get('month');
        $search['parent_cate_id'] = $this->input->get('parent_cate_id');
        $search['cate_id'] = $this->input->get('cate_id');
        $search['keyword'] = $this->input->get('keyword');
        
        
        if($search['month'])
        {
            $month = strtotime($search['month']);
            $month = strtotime(date('Y-m',$month));
            $search['month'] = date('Y-m',$month);
        }else{
            $search['month'] = date('Y-m',time());
        }
        
        if( $search['parent_cate_id'] ){
            $where .= " AND qudao.parent_cate_id = ".$search['parent_cate_id'];
            $search_url .= '&cate_id='.$search['parent_cate_id'];
        }
        if( $search['cate_id'] ){
            $where .= " AND qudao.cate_id = ".$search['cate_id'];
            $search_url .= '&cate_id='.$search['cate_id'];
        }
        if( $search['keyword'] ){
            $where .= " AND ( qudao.name like '%".$search['keyword']."%' ) ";
            $search_url .= '&keyword='.$search['keyword'];
        }
        
        $total_rows = $this->model->where($where)->count();
        
        $search_url .= '&month='.$search['month'];
        $where .= " AND qudao_wxid_month.add_time = ".strtotime($search['month']);
        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$search_url));
        
        $list = $this->model
            ->select('qudao.id,qudao.name,qudao.parent_cate_id,qudao.cate_id,qudao.zhibiao_id,qudao_cate.name as cate_name,qudao_wxid_month.num as month_num')
            ->join('qudao_cate','qudao_cate.id=qudao.cate_id')
            ->join('qudao_wxid_month','qudao_wxid_month.qudao_id=qudao.id')
            ->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->order_by('qudao.id desc')->where($where)->find_all();
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        if( $list ){
            
            $this->load->model('qudao_zhibiao_model');
            $zhibiao_list = $this->qudao_zhibiao_model->where(array('site_id'=>$this->site_id))->find_all();
        
            $this->load->model('qudao_wxid_model');
            foreach( $list as $key=>$val ){
                //总绑定数
                $list[$key]['bind_num'] = $this->qudao_wxid_model->where(array('site_id'=>$this->site_id,'qudao_id'=>$val['id']))->count();
                
                $list[$key]['zhibiao_name'] = '默认分组';
                $list[$key]['zhibiao_num']  = 0;
                if( $val['zhibiao_id']>0 ){
                    foreach( $zhibiao_list as $v ){
                        if( $v['id']==$val['zhibiao_id'] ){
                            $list[$key]['zhibiao_name'] = $v['name'];
                            $list[$key]['zhibiao_num'] = $v['num'];
                            break;
                        }
                    }
                }
            }
        }
        $this->data['list'] = $list;
        
        $this->data['search'] = $search;
        
        $this->load->view($this->dcm,$this->data);
    }
    
    //统计导出
    public function statistics_export()
    {
        $this->month_init();
        $where = "qudao.site_id = '".$this->site_id."' AND is_delete = 0";
        
        $this->cate_level();
        
        $search['month'] = $this->input->get('month');
        $search['parent_cate_id'] = $this->input->get('parent_cate_id');
        $search['cate_id'] = $this->input->get('cate_id');
        $search['keyword'] = $this->input->get('keyword');
        
        
        if($search['month'])
        {
            $month = strtotime($search['month']);
            $month = strtotime(date('Y-m',$month));
            $search['month'] = date('Y-m',$month);
        }else{
            $search['month'] = date('Y-m',time());
        }
        $where .= " AND qudao_wxid_month.add_time = ".strtotime($search['month']);
        
        if( $search['parent_cate_id'] ){
            $where .= " AND qudao.parent_cate_id = ".$search['parent_cate_id'];
        }
        if( $search['cate_id'] ){
            $where .= " AND qudao.cate_id = ".$search['cate_id'];
        }
        if( $search['keyword'] ){
            $where .= " AND ( qudao.name like '%".$search['keyword']."%' ) ";
        }
        
        $list = $this->model
            ->select('qudao.id,qudao.name,qudao.parent_cate_id,qudao.cate_id,qudao.zhibiao_id,qudao_cate.name as cate_name,qudao_wxid_month.num as month_num')
            ->join('qudao_cate','qudao_cate.id=qudao.cate_id')
            ->join('qudao_wxid_month','qudao_wxid_month.qudao_id=qudao.id')
            ->order_by('qudao.id desc')->where($where)->find_all();
        
        if( $list ){
            
            $this->load->model('qudao_zhibiao_model');
            $zhibiao_list = $this->qudao_zhibiao_model->where(array('site_id'=>$this->site_id))->find_all();
        
            $this->load->model('qudao_wxid_model');
            foreach( $list as $key=>$val ){
                
                $list[$key]['parent_cate_name'] = '';
                if( $this->data['cate_level']['parent'] ){
                    foreach( $this->data['cate_level']['parent'] as $v ){
                        if( $v['id']==$val['parent_cate_id'] ){
                            $list[$key]['parent_cate_name'] = $v['name'];
                            break;
                        }
                    }
                }
                
                //总绑定数
                $list[$key]['bind_num'] = $this->qudao_wxid_model->where(array('site_id'=>$this->site_id,'qudao_id'=>$val['id']))->count();
                
                $list[$key]['zhibiao_name'] = '默认分组';
                $list[$key]['zhibiao_num']  = 0;
                $list[$key]['zhibiao'] = '默认分组(无限制)';
                $list[$key]['rate']  = '';
                if( $val['zhibiao_id']>0 ){
                    foreach( $zhibiao_list as $v ){
                        if( $v['id']==$val['zhibiao_id'] ){
                            $list[$key]['zhibiao_name'] = $v['name'];
                            $list[$key]['zhibiao_num'] = $v['num'];
                            if( $v['num']==0 ){
                                $list[$key]['zhibiao'] = $v['name'].'(无限制)';
                            }else if( $v['num']>0 ){
                                $list[$key]['zhibiao'] = $v['name'].'('.$v['num'].')';
                                $list[$key]['rate'] = number_format(($val['month_num']/$v['num'])*100,2,'.','').'%';
                            }
                            break;
                        }
                    }
                }
            }
            
            $fields = array(
                '#'=>'#',
                'parent_cate_name' => '一级分组名称',
                'cate_name' => '二级分组名称',
                'name' => '渠道名称',
                'zhibiao' => '指标',
                'month_num' => '完成数',
                'rate' => '完成比例',
                'bind_num' => '总关注数'
            );
            $this->excel_export('渠道统计'.$search['month'], '渠道统计'.$search['month'], $fields, $list);
        }
        
    }

    //统计导出
    public function statistics_yt_export()
    {
        $months = $this->get_month_yt(1);

        $where1 = "qudao.site_id = '".$this->site_id."' AND is_delete = 0";
        $where2 = "qudao.site_id = '".$this->site_id."' AND is_delete = 0";

        $this->cate_level();

        $search['parent_cate_id'] = $this->input->get('parent_cate_id');
        $search['cate_id'] = $this->input->get('cate_id');
        $search['keyword'] = $this->input->get('keyword');

        $where1 .= " AND qudao_wxid_month.add_time = ".$months[0];
        $where2 .= " AND qudao_wxid_month.add_time = ".$months[1];

        if( $search['parent_cate_id'] ){
            $where1 .= " AND qudao.parent_cate_id = ".$search['parent_cate_id'];
            $where2 .= " AND qudao.parent_cate_id = ".$search['parent_cate_id'];
        }
        if( $search['cate_id'] ){
            $where1 .= " AND qudao.cate_id = ".$search['cate_id'];
            $where2 .= " AND qudao.cate_id = ".$search['cate_id'];
        }
        if( $search['keyword'] ){
            $where1 .= " AND ( qudao.name like '%".$search['keyword']."%' ) ";
            $where2 .= " AND ( qudao.name like '%".$search['keyword']."%' ) ";
        }

        $list1 = $this->model
            ->select('qudao.id,qudao.name,qudao.parent_cate_id,qudao.cate_id,qudao.zhibiao_id,qudao_cate.name as cate_name,qudao_wxid_month.num as month_num')
            ->join('qudao_cate','qudao_cate.id=qudao.cate_id')
            ->join('qudao_wxid_month','qudao_wxid_month.qudao_id=qudao.id')
            ->order_by('qudao.id desc')->where($where1)->find_all();
        $list2 = $this->model
            ->select('qudao.id,qudao.name,qudao.parent_cate_id,qudao.cate_id,qudao.zhibiao_id,qudao_cate.name as cate_name,qudao_wxid_month.num as month_num')
            ->join('qudao_cate','qudao_cate.id=qudao.cate_id')
            ->join('qudao_wxid_month','qudao_wxid_month.qudao_id=qudao.id')
            ->order_by('qudao.id desc')->where($where2)->find_all();

        $list = array();
        $l1 = &$list1;
        $l2 = &$list2;
        if( count($list1)>=count($list2) ){
        }else{
            $l1 = &$list2;
            $l2 = &$list1;
        }
        if( $l1 ){
            foreach( $l1 as $v1 ){
                $list[$v1['id']] = $v1;
                foreach( $l2 as $k=>$v2 ){
                    if( $v2['id']==$v1['id'] ){
                        $list[$v1['id']]['month_num'] = $list[$v1['id']]['month_num']+$v2['month_num'];
                        unset($l2[$k]);
                        continue;
                    }
                }
            }
        }
        if( $list ){

            $this->load->model('qudao_zhibiao_model');
            $zhibiao_list = $this->qudao_zhibiao_model->where(array('site_id'=>$this->site_id))->find_all();

            $this->load->model('qudao_wxid_model');
            foreach( $list as $key=>$val ){
                $list[$key]['parent_cate_name'] = '';
                if( $this->data['cate_level']['parent'] ){
                    foreach( $this->data['cate_level']['parent'] as $v ){
                        if( $v['id']==$val['parent_cate_id'] ){
                            $list[$key]['parent_cate_name'] = $v['name'];
                            break;
                        }
                    }
                }

                //总绑定数
                $list[$key]['bind_num'] = $this->qudao_wxid_model->where(array('site_id'=>$this->site_id,'qudao_id'=>$val['id']))->count();

                $list[$key]['zhibiao_name'] = '默认分组';
                $list[$key]['zhibiao_num']  = 0;
                $list[$key]['zhibiao'] = '默认分组(无限制)';
                $list[$key]['rate']  = '';
                if( $val['zhibiao_id']>0 ){
                    foreach( $zhibiao_list as $v ){
                        if( $v['id']==$val['zhibiao_id'] ){
                            $list[$key]['zhibiao_name'] = $v['name'];
                            $list[$key]['zhibiao_num'] = $v['num'];
                            if( $v['num']==0 ){
                                $list[$key]['zhibiao'] = $v['name'].'(无限制)';
                            }else if( $v['num']>0 ){
                                $list[$key]['zhibiao'] = $v['name'].'('.$v['num'].')';
                                $list[$key]['rate'] = number_format(($val['month_num']/$v['num'])*100,2,'.','').'%';
                            }
                            break;
                        }
                    }
                }
            }

            $fields = array(
                '#'=>'#',
                'parent_cate_name' => '一级分组名称',
                'cate_name' => '二级分组名称',
                'name' => '渠道名称',
                'zhibiao' => '指标',
                'month_num' => '完成数',
                'rate' => '完成比例',
                'bind_num' => '总关注数'
            );
            $this->excel_export('渠道统计'.date('Ym',$months[0]).'-'.date('Ym',$months[1]), '渠道统计'.date('Ym',$months[0]).'-'.date('Ym',$months[1]), $fields, $list);
        }
    }
    
    //初始化月份统计表
    private function month_init()
    {
        $this->load->model('qudao_model');
        $list = $this->qudao_model->select('id')->where(array('site_id'=>$this->site_id,'is_delete'=>0))->find_all();
        if( $list ){
            $this->load->model('qudao_wxid_month_model');
            $month = mktime(0, 0 , 0,date("m"),1,date("Y"));
            foreach( $list as $val ){
                $stac = $this->qudao_wxid_month_model->where(array('site_id'=>$this->site_id,'qudao_id'=>$val['id'],'add_time'=>$month))->find();
                if( !$stac ){
                    $this->qudao_wxid_month_model->add(array('site_id'=>$this->site_id,'qudao_id'=>$val['id'],'add_time'=>$month));
                }
            }
        }
    }
    
    //银泰专用  2个月一统计
    private function get_month_yt($step=0)
    {
        $ret_month_time = array();
        $month = date('m',time());
        if( $month%2==0 ){
            $ret_month_time[] = mktime(0, 0 , 0,date("m")-1,1,date("Y"));
            $ret_month_time[] = mktime(0, 0 , 0,date("m"),1,date("Y"));
        }else{
            $ret_month_time[] = mktime(0, 0 , 0,date("m"),1,date("Y"));
            $ret_month_time[] = mktime(0, 0 , 0,date("m")+1,1,date("Y"));
        }
        if( $step>0 ){
            $re_start_m = date('m',$ret_month_time[0]);
            if( $re_start_m-1<=0 ){
                $ret_month_time[0] = mktime(0, 0 , 0,11,1,date("Y")-1);
                $ret_month_time[1] = mktime(0, 0 , 0,12,1,date("Y")-1);
            }else{
                $ret_month_time[0] = mktime(0, 0 , 0,$re_start_m-2,1,date("Y"));
                $ret_month_time[1] = mktime(0, 0 , 0,$re_start_m-1,1,date("Y"));
            }
        }
        return $ret_month_time;
    }
    
    /*//转换统计数据到   按月统计
    public function exchange()
    {
        $this->load->model('qudao_wxid_model');
        $list = $this->qudao_wxid_model->select('qudao_id,site_id,count(qudao_id) as num')
                ->group_by('qudao_id')
                ->order_by('qudao_id asc')
                ->find_all();
        if( $list ){
            $this->load->model('qudao_wxid_month_model');
            $month = mktime(0, 0 , 0,date("m"),1,date("Y"));
            foreach( $list as $val ){
                $this->qudao_wxid_month_model->add(array('qudao_id'=>$val['qudao_id'],'site_id'=>$val['site_id'],'num'=>$val['num'],'add_time'=>$month));
            }
        }
        echo "转换完成";
    }*/
    
    //转换应用
    public function exchange_application()
    {
        $this->load->model('qudao_model');
        $list = $this->qudao_model->select('site_id')->group_by('site_id')->find_all();
        
        if( $list ){
            
            $app_id = 6063;
            $this->load->model('model_user_auth');
            foreach( $list as $val ){
                if( !$this->model_user_auth->get_row(array('user_id'=>$val['site_id'],'app_id'=>$app_id)) ){
                    $add_data['user_id'] = $val['site_id'];
                    $add_data['app_id']  = $app_id;
                    $add_data['display'] = 1;
                    $this->model_user_auth->add($add_data);
                }
            }
            
        }
        echo "转换完成";
    }
    
    //数据统计  银泰
    public function base_info_yt()
    {
        $id = intval($this->input->get('id'));
        
        $qudao = $this->model->where(array('site_id'=>$this->site_id,'id'=>$id,'is_delete'=>0))->find();
        if( !$qudao ){
            if( $this->session->userdata('qudao_index_uri') ){
                redirect($this->session->userdata('qudao_index_uri'));
            }else{
                redirect('/c/qudao/index');
            }
        }
        
        $this->data['base_info'] = array();
        $this->data['base_info']['type'] = 2;
        
        $this->data['base_info']['selected_id'] = $qudao['id'];
        
        //渠道分组导航
        $this->load->model('qudao_cate_model');
        $parent_cate = $this->qudao_cate_model->where(array('site_id'=> $this->site_id,'parent_id' => 0,'id'=>$qudao['parent_cate_id']))->find();
        $cate = $this->qudao_cate_model->where(array('site_id'=> $this->site_id,'parent_id' => $qudao['parent_cate_id'],'id'=>$qudao['cate_id']))->find();
        if( $parent_cate&&$cate ){
            $this->data['base_info']['nav'][] = $parent_cate['name'];
            $this->data['base_info']['nav'][] = $cate['name'];
            $this->data['base_info']['nav'][] = $qudao['name'];
        }else{
            if( $this->session->userdata('qudao_index_uri') ){
                redirect($this->session->userdata('qudao_index_uri'));
            }else{
                redirect('/c/qudao/index');
            }
        }
        
        //月指标数
        $this->data['base_info']['zhibiao_num'] = 0;
        $this->data['base_info']['zhibiao_name'] = '默认指标';
        if( $qudao['zhibiao_id']>0 ){
            $this->load->model('qudao_zhibiao_model');
            $zhibiao = $this->qudao_zhibiao_model->where(array( 'site_id'=>$this->site_id, 'id'=>$qudao['zhibiao_id'] ))->find();
            if( $zhibiao ){
                $this->data['base_info']['zhibiao_num'] = $zhibiao['num'];
                $this->data['base_info']['zhibiao_name'] = $zhibiao['name'];
            }else{
                if( $this->session->userdata('qudao_index_uri') ){
                    redirect($this->session->userdata('qudao_index_uri'));
                }else{
                    redirect('/c/qudao/index');
                }
            }
        }
        
        //同级渠道 实际完成数
        $qudao_zhibiao_num = $this->qudao_model->qudao_zhibiao_num($this->site_id,$qudao['cate_id'],$this->get_month_yt());
        if( $qudao_zhibiao_num ){
            $this->data['base_info']['month_num'] = 0;
            foreach( $qudao_zhibiao_num as $key=>$val ){
                if( $val['id']==$qudao['id'] ){
                    $this->data['base_info']['month_num'] += $val['num'];
                }
            }
            if( !isset($this->data['base_info']['month_num'])&&!isset($this->data['base_info']['rank_num']) ){
                if( $this->session->userdata('qudao_index_uri') ){
                    redirect($this->session->userdata('qudao_index_uri'));
                }else{
                    redirect('/c/qudao/index');
                }
            }
        }else{
            if( $this->session->userdata('qudao_index_uri') ){
                redirect($this->session->userdata('qudao_index_uri'));
            }else{
                redirect('/c/qudao/index');
            }
        }
        
        if( ($qudao['parent_cate_id']==369)||$qudao['parent_cate_id']==370 ){
            
            //导出
            if( isset($_GET['export'])&&($_GET['export']) ){
                $this->base_info_export(2);exit;
            }
            
            $qudao_zhibiao_num_yt = $this->qudao_model->qudao_zhibiao_num_yt($this->site_id,369,370,$this->get_month_yt());
        }else{
            
            //导出
            if( isset($_GET['export'])&&($_GET['export']) ){
                $this->base_info_export(3,$qudao['parent_cate_id']);exit;
            }
            
            $qudao_zhibiao_num_yt = $this->qudao_model->qudao_zhibiao_num_yt($this->site_id,$qudao['parent_cate_id'],0,$this->get_month_yt());
        }
        
        $this->data['base_info']['parent_cate_id'] = $qudao['parent_cate_id'];
        if( isset($qudao_zhibiao_num_yt)&&$qudao_zhibiao_num_yt ){
            $qudao_zhibiao_num_yt_tmp1 = array();
            $qudao_zhibiao_num_yt_tmp2 = array();
            $qudao_zhibiao_num_yt_tmp3 = array();
            foreach( $qudao_zhibiao_num_yt as $key=>$val ){
                if( isset( $qudao_zhibiao_num_yt_tmp1[$val['id']] ) ){
                    $qudao_zhibiao_num_yt_tmp1[$val['id']]['num'] += $val['num'];
                    $qudao_zhibiao_num_yt_tmp2[$val['id']] += $val['num'];
                }else{
                    $qudao_zhibiao_num_yt_tmp1[$val['id']] = array(
                        'num' => $val['num'],
                        'id' => $val['id'],
                        'name' => $val['name'],
                        'parent_cate_id' => $val['parent_cate_id']
                    );
                    $qudao_zhibiao_num_yt_tmp2[$val['id']] = $val['num'];
                }
            }
        }else{
            if( $this->session->userdata('qudao_index_uri') ){
                redirect($this->session->userdata('qudao_index_uri'));
            }else{
                redirect('/c/qudao/index');
            }
        }
        $i = 1;
        arsort($qudao_zhibiao_num_yt_tmp2);
        foreach( $qudao_zhibiao_num_yt_tmp2 as $key=>$val ){
            if( $key==$qudao['id'] ){
                $this->data['base_info']['rank_num'] = $i;
            }
            $i++;
            $qudao_zhibiao_num_yt_tmp3[] = $qudao_zhibiao_num_yt_tmp1[$key];
        }
        $this->data['base_info']['paixu'] = $qudao_zhibiao_num_yt_tmp3;
        
        $this->load->view($this->dcm,$this->data);
    }
    
    //数据统计
    public function base_info()
    {
        $this->month_init();
        if( $this->site_id=='526775b1e15b4079' ){
            return $this->base_info_yt();
        }
        
        $id = intval($this->input->get('id'));
        
        $qudao = $this->model->where(array('site_id'=>$this->site_id,'id'=>$id,'is_delete'=>0))->find();
        if( !$qudao ){
            if( $this->session->userdata('qudao_index_uri') ){
                redirect($this->session->userdata('qudao_index_uri'));
            }else{
                redirect('/c/qudao/index');
            }
        }
        
        $this->data['base_info'] = array();
        $this->data['base_info']['type'] = 2;
        
        $this->data['base_info']['selected_id'] = $qudao['id'];
        
        //渠道分组导航
        $this->load->model('qudao_cate_model');
        $parent_cate = $this->qudao_cate_model->where(array('site_id'=> $this->site_id,'parent_id' => 0,'id'=>$qudao['parent_cate_id']))->find();
        $cate = $this->qudao_cate_model->where(array('site_id'=> $this->site_id,'parent_id' => $qudao['parent_cate_id'],'id'=>$qudao['cate_id']))->find();
        if( $parent_cate&&$cate ){
            $this->data['base_info']['nav'][] = $parent_cate['name'];
            $this->data['base_info']['nav'][] = $cate['name'];
            $this->data['base_info']['nav'][] = $qudao['name'];
        }else{
            if( $this->session->userdata('qudao_index_uri') ){
                redirect($this->session->userdata('qudao_index_uri'));
            }else{
                redirect('/c/qudao/index');
            }
        }
        
        //月指标数
        $this->data['base_info']['zhibiao_num'] = 0;
        $this->data['base_info']['zhibiao_name'] = '默认指标';
        if( $qudao['zhibiao_id']>0 ){
            $this->load->model('qudao_zhibiao_model');
            $zhibiao = $this->qudao_zhibiao_model->where(array( 'site_id'=>$this->site_id, 'id'=>$qudao['zhibiao_id'] ))->find();
            if( $zhibiao ){
                $this->data['base_info']['zhibiao_num'] = $zhibiao['num'];
                $this->data['base_info']['zhibiao_name'] = $zhibiao['name'];
            }else{
                if( $this->session->userdata('qudao_index_uri') ){
                    redirect($this->session->userdata('qudao_index_uri'));
                }else{
                    redirect('/c/qudao/index');
                }
            }
        }
        
        //导出
        if( isset($_GET['export'])&&($_GET['export']) ){
            $this->base_info_export(1,$qudao['cate_id']);exit;
        }
        
        //同级渠道 实际完成数
        $qudao_zhibiao_num = $this->qudao_model->qudao_zhibiao_num($this->site_id,$qudao['cate_id']);
        if( $qudao_zhibiao_num ){
            foreach( $qudao_zhibiao_num as $key=>$val ){
                if( $val['id']==$qudao['id'] ){
                    $this->data['base_info']['month_num'] = $val['num'];
                    $this->data['base_info']['rank_num'] = $key+1;
                    break;
                }
            }
            if( !isset($this->data['base_info']['month_num'])&&!isset($this->data['base_info']['rank_num']) ){
                if( $this->session->userdata('qudao_index_uri') ){
                    redirect($this->session->userdata('qudao_index_uri'));
                }else{
                    redirect('/c/qudao/index');
                }
            }
        }else{
            if( $this->session->userdata('qudao_index_uri') ){
                redirect($this->session->userdata('qudao_index_uri'));
            }else{
                redirect('/c/qudao/index');
            }
        }
        $this->data['base_info']['paixu'] = $qudao_zhibiao_num;
        $this->data['base_info']['parent_cate_id'] = $qudao['parent_cate_id'];
        
        $this->load->view($this->dcm,$this->data);
    }
    
    //详细信息  银泰
    public function details_yt()
    {
        $this->month_init();
        $this->data['detail'] = array();
        
        $id = intval($this->input->get('id'));
        
        $qudao = $this->model->where(array('site_id'=>$this->site_id,'id'=>$id,'is_delete'=>0))->find();
        if( !$qudao ){
            if( $this->session->userdata('qudao_index_uri') ){
                redirect($this->session->userdata('qudao_index_uri'));
            }else{
                redirect('/c/qudao/index');
            }
        }
        
        $search_url = site_url($this->uri->uri_string().'?');
        $search_url .= '&id='.$id;
        $paper = $this->input->get('page');
        $paper = $paper ? $paper : 1;
        $this->data['detail']['page'] = $paper;
        
        $this->data['detail']['show_type'] = 3;//显示2列数据
        $this->data['detail']['type'] = 2;
        
        $this->data['detail']['selected_id'] = $qudao['id'];
        
        //渠道分组导航
        $this->load->model('qudao_cate_model');
        $parent_cate = $this->qudao_cate_model->where(array('site_id'=> $this->site_id,'parent_id' => 0,'id'=>$qudao['parent_cate_id']))->find();
        $cate = $this->qudao_cate_model->where(array('site_id'=> $this->site_id,'parent_id' => $qudao['parent_cate_id'],'id'=>$qudao['cate_id']))->find();
        if( $parent_cate&&$cate ){
            $this->data['detail']['nav'][] = $parent_cate['name'];
            $this->data['detail']['nav'][] = $cate['name'];
            $this->data['detail']['nav'][] = $qudao['name'];
        }else{
            if( $this->session->userdata('qudao_index_uri') ){
                redirect($this->session->userdata('qudao_index_uri'));
            }else{
                redirect('/c/qudao/index');
            }
        }
        
        //导出
        if( isset($_GET['export'])&&($_GET['export']) ){
            $this->details_export(2,$qudao);exit;
        }
        
        $this->load->model('qudao_wxid_model');
        $qudao_list_num = $this->qudao_wxid_model->qudao_wxid_num($this->site_id,$qudao['id'],$this->get_month_yt());
        $this->data['detail']['list_num'] = $qudao_list_num;
        $pager_obj = $this->_pager($qudao_list_num, array('per_page'=>15,'base_url'=>$search_url));
        $list = $this->qudao_wxid_model->qudao_wxid($this->site_id,$qudao['id'],15,$paper,$this->get_month_yt());
        $list = $list ? $list : array();
        if( $list ){
            foreach( $list as $key=>$val ){
                $list[$key]['wxid'] = '******'.substr($val['wxid'],-6);
                $list[$key]['add_time'] = date('m-d H:i',$val['add_time']);
            }
        }
        $this->data['detail']['list'] = $list;
        
        $this->data['page'] = $pager_obj['links'];
        $this->data['offset'] = $pager_obj['limit']['offset'];
        
        $this->load->view($this->dcm,$this->data);
    }
    
    //详细信息
    public function details()
    {
        if( $this->site_id=='526775b1e15b4079' ){
            return $this->details_yt();
        }
        $this->month_init();
        $this->data['detail'] = array();
        
        $id = intval($this->input->get('id'));
        
        $qudao = $this->model->where(array('site_id'=>$this->site_id,'id'=>$id,'is_delete'=>0))->find();
        if( !$qudao ){
            if( $this->session->userdata('qudao_index_uri') ){
                redirect($this->session->userdata('qudao_index_uri'));
            }else{
                redirect('/c/qudao/index');
            }
        }
        
        $search_url = site_url($this->uri->uri_string().'?');
        $search_url .= '&id='.$id;
        $paper = $this->input->get('page');
        $paper = $paper ? $paper : 1;
        $this->data['detail']['page'] = $paper;
        
        $this->data['detail']['show_type'] = 3;//显示2列数据
        $this->data['detail']['type'] = 2;
        
        $this->data['detail']['selected_id'] = $qudao['id'];
        
        //渠道分组导航
        $this->load->model('qudao_cate_model');
        $parent_cate = $this->qudao_cate_model->where(array('site_id'=> $this->site_id,'parent_id' => 0,'id'=>$qudao['parent_cate_id']))->find();
        $cate = $this->qudao_cate_model->where(array('site_id'=> $this->site_id,'parent_id' => $qudao['parent_cate_id'],'id'=>$qudao['cate_id']))->find();
        if( $parent_cate&&$cate ){
            $this->data['detail']['nav'][] = $parent_cate['name'];
            $this->data['detail']['nav'][] = $cate['name'];
            $this->data['detail']['nav'][] = $qudao['name'];
        }else{
            if( $this->session->userdata('qudao_index_uri') ){
                redirect($this->session->userdata('qudao_index_uri'));
            }else{
                redirect('/c/qudao/index');
            }
        }
        
        //导出
        if( isset($_GET['export'])&&($_GET['export']) ){
            $this->details_export(1,$qudao);exit;
        }
        
        $this->load->model('qudao_wxid_model');
        
        $qudao_list_num = $this->qudao_wxid_model->qudao_wxid_num($this->site_id,$qudao['id']);
        $this->data['detail']['list_num'] = $qudao_list_num;
        $pager_obj = $this->_pager($qudao_list_num, array('per_page'=>15,'base_url'=>$search_url));
        
        $list = $this->qudao_wxid_model->qudao_wxid($this->site_id,$qudao['id'],15,$paper);
        $list = $list ? $list : array();
        if( $list ){
            foreach( $list as $key=>$val ){
                $list[$key]['wxid'] = '******'.substr($val['wxid'],-6);
                $list[$key]['add_time'] = date('m-d H:i',$val['add_time']);
            }
        }
        $this->data['detail']['list'] = $list;
        
        $this->data['page'] = $pager_obj['links'];
        $this->data['offset'] = $pager_obj['limit']['offset'];
        
        $this->load->view($this->dcm,$this->data);
    }
    
    //详细信息  导出
    public function details_export($type,$qudao)
    {
        $list = array();
        if( $type==1 ){
            $this->load->model('qudao_wxid_model');
            $list = $this->qudao_wxid_model->qudao_wxid($this->site_id,$qudao['id'],'','');
            $list = $list ? $list : array();
            if( $list ){
                foreach( $list as $key=>$val ){
                    $list[$key]['wxid'] = '******'.substr($val['wxid'],-6);
                    $list[$key]['add_time'] = date('m-d H:i',$val['add_time']);
                }
            }
        }
        if( $type==2 ){
            $this->load->model('qudao_wxid_model');
            $list = $this->qudao_wxid_model->qudao_wxid($this->site_id,$qudao['id'],'','',$this->get_month_yt());
            $list = $list ? $list : array();
            if( $list ){
                foreach( $list as $key=>$val ){
                    $list[$key]['wxid'] = '******'.substr($val['wxid'],-6);
                    $list[$key]['add_time'] = date('m-d H:i',$val['add_time']);
                }
            }
        }
        
        $fields = array(
            '#'=>'#',
            'wxid' => 'OpenID',
            'add_time' => '关注时间'
        );
        if( $list ){
            $this->excel_export('月度关注详情', '月度关注详情', $fields, $list);
        }
    }
    
    //数据统计 导出
    public function base_info_export($type,$cate_id=0)
    {
        $list = array();
        if( $type==1 ){
            $list = $this->qudao_model->qudao_zhibiao_num($this->site_id,$cate_id);
        }
        if( $type==2 ){
            $list_temp = $this->qudao_model->qudao_zhibiao_num_yt($this->site_id,369,370,$this->get_month_yt());
            if( isset($list_temp)&&$list_temp ){
                $qudao_zhibiao_num_yt_tmp1 = array();
                $qudao_zhibiao_num_yt_tmp2 = array();
                $qudao_zhibiao_num_yt_tmp3 = array();
                foreach( $list_temp as $key=>$val ){
                    if( isset( $qudao_zhibiao_num_yt_tmp1[$val['id']] ) ){
                        $qudao_zhibiao_num_yt_tmp1[$val['id']]['num'] += $val['num'];
                        $qudao_zhibiao_num_yt_tmp2[$val['id']] += $val['num'];
                    }else{
                        $qudao_zhibiao_num_yt_tmp1[$val['id']] = array(
                            'num' => $val['num'],
                            'id' => $val['id'],
                            'name' => $val['name'],
                            'parent_cate_id' => $val['parent_cate_id']
                        );
                        $qudao_zhibiao_num_yt_tmp2[$val['id']] = $val['num'];
                    }
                }
                $i = 1;
                arsort($qudao_zhibiao_num_yt_tmp2);
                foreach( $qudao_zhibiao_num_yt_tmp2 as $key=>$val ){
                    $qudao_zhibiao_num_yt_tmp3[] = $qudao_zhibiao_num_yt_tmp1[$key];
                }
                $list = $qudao_zhibiao_num_yt_tmp3;
            }
        }
        if( $type==3 ){
            $list_temp = $this->qudao_model->qudao_zhibiao_num_yt($this->site_id,$cate_id,0,$this->get_month_yt());
            if( isset($list_temp)&&$list_temp ){
                $qudao_zhibiao_num_yt_tmp1 = array();
                $qudao_zhibiao_num_yt_tmp2 = array();
                $qudao_zhibiao_num_yt_tmp3 = array();
                foreach( $list_temp as $key=>$val ){
                    if( isset( $qudao_zhibiao_num_yt_tmp1[$val['id']] ) ){
                        $qudao_zhibiao_num_yt_tmp1[$val['id']]['num'] += $val['num'];
                        $qudao_zhibiao_num_yt_tmp2[$val['id']] += $val['num'];
                    }else{
                        $qudao_zhibiao_num_yt_tmp1[$val['id']] = array(
                            'num' => $val['num'],
                            'id' => $val['id'],
                            'name' => $val['name'],
                            'parent_cate_id' => $val['parent_cate_id']
                        );
                        $qudao_zhibiao_num_yt_tmp2[$val['id']] = $val['num'];
                    }
                }
                $i = 1;
                arsort($qudao_zhibiao_num_yt_tmp2);
                foreach( $qudao_zhibiao_num_yt_tmp2 as $key=>$val ){
                    $qudao_zhibiao_num_yt_tmp3[] = $qudao_zhibiao_num_yt_tmp1[$key];
                }
                $list = $qudao_zhibiao_num_yt_tmp3;
            }
        }
        $fields = array(
            '#'=>'#',
            'name' => '分组名',
            'num' => '用户数'
        );
        if( $list ){
            $this->excel_export('详细信息', '详细信息', $fields, $list);
        }
    }
    
    /*//查找数据不准问题
    public function check_data_true()
    {
        $qudao = $this->model->where(array('site_id'=>'526775b1e15b4079','is_delete'=>0))->find_all();
        $this->load->model('qudao_wxid_model');
        $this->load->model('qudao_wxid_month_model');
        echo $total_persong = 0;
        foreach( $qudao as $v1 ){
            $wxid_num = $this->qudao_wxid_model->where(array('qudao_id'=>$v1['id']))->count();
            $wxid_month = $this->qudao_wxid_month_model->where(array('qudao_id'=>$v1['id']))->find_all();
            if( count($wxid_month)>1 ){
                var_dump($v1['id'].'-'.$wxid_num);exit;
            }
            if( $wxid_num==$wxid_month[0]['num'] ){
                echo "正确".$v1['id'].'-'.$wxid_num.'<br>';
                $total_persong += $wxid_num;
            }else{
                echo "错误".$v1['id'].'-'.$wxid_num.'<br>';exit;
            }
        }
        echo $total_persong;
        echo "检查数据";exit;
    }*/
    

}