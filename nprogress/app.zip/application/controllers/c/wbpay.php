<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 微巴支付 配置接口
 */

class Wbpay extends C_Controller {
    private $site_id = '';
    protected $data = array();
    protected $app_key = '5318162aac6f8745';
    protected $app_secret = '0c28536510e0b0b929750f878222d549';

    public function __construct() {
        parent::__construct();
        $this->site_id = $this->site_info['id'];

        //TODO  CASHIER_URL
        //$server = 'http://cashier.69juzi.com/api/';
        //支付系统接口
        $this->load->library('rest', array(
            'server'     => CASHIER_URL,
            'app_key'    => $this->app_key,
            'secret_key' => $this->app_secret,
        ), 'cashier_rest');

        $this->load->model('user_partner_model');

        $this->data['has_config'] = 0; //本地是否存在商户配置
        $this->check_open();
        if (isset($this->data['partner_info']) && $this->data['partner_info']) {
            $this->data['has_config'] = 1;
        }
    }

    public function index() {
        if ($this->data['has_config']) { //存在配置
            $partner_id = $this->data['partner_info']['partner_id'];
            $result = $this->cashier_rest->get('payment/builtins', array('partner_id' => $partner_id));
            if ($this->cashier_rest->status() == 200) {
                //对支付类型数据做处理，合并支付宝和银行卡快捷支付成微巴支付
                $new_result = array();
                if (!empty($result)) {
                    foreach ($result as $v) {
                        if ($v['code'] == 'llpay' || $v['code'] == 'alipay') {
                            $new_result['wbpay']['name'] = '微巴支付';
                            $new_result['wbpay']['desc'] = '微巴支付';
                            $new_result['wbpay']['code'] = 'wbpay';
                            $new_result['wbpay']['enabled'] = isset($v['enabled']) ? 1 : 0;
                            isset($v['config']) && $new_result['wbpay']['config'][] = $v['config'];
                            if (isset($v['id'])) {
                                $new_result['wbpay']['id'] = isset($new_result['wbpay']['id']) ? $new_result['wbpay']['id'] . "." . $v['id'] : $v['id'];
                            }
                        } else {
                            $new_result[$v['code']] = $v;
                        }
                    }
                }
                $this->data['list'] = $new_result;
            } else {
                $this->data['list'] = array();
            }

            //var_dump($this->data['list']);
        }
        $this->load->view($this->dcm, $this->data);
    }

    //微巴支付记录
    public function log() {
        $this->load->model('pay_log_model');

        $where = array('site_id' => $this->site_id);

        $order_sn = $this->input->get_post('order_sn');
        $payment_mob = $this->input->get_post('payment_mob');
        $payment_code = $this->input->get_post('payment_code');

        $search = array();

        if($order_sn)
        {
            $where['order_sn like'] = "%{$order_sn}%";
            $search['order_sn'] = $order_sn;
        }
        if($payment_mob)
        {
            $where['payment_mob like'] = "%{$payment_mob}%";
            $search['payment_mob'] = $payment_mob;
        }
        if($payment_code)
        {
            $where['payment_code'] = $payment_code;
            $search['payment_code'] = $payment_code;
        }

        $payment_list = array();  //支付方式列表

        if ($this->data['has_config']) { //存在配置
            $partner_id = $this->data['partner_info']['partner_id'];
            $result = $this->cashier_rest->get('payment/builtins', array('partner_id' => $partner_id));
            if ($this->cashier_rest->status() == 200) {
                //对支付类型数据做处理，合并支付宝和银行卡快捷支付成微巴支付
                $new_result = array();
                if (!empty($result)) {
                    foreach ($result as $v) {
                        if ($v['code'] == 'llpay' || $v['code'] == 'alipay') {
                            $new_result['wbpay']['name'] = '微巴支付';
                            $new_result['wbpay']['desc'] = '微巴支付';
                            $new_result['wbpay']['code'] = 'wbpay';
                            $new_result['wbpay']['enabled'] = isset($v['enabled']) ? 1 : 0;
                            isset($v['config']) && $new_result['wbpay']['config'][] = $v['config'];
                            if (isset($v['id'])) {
                                $new_result['wbpay']['id'] = isset($new_result['wbpay']['id']) ? $new_result['wbpay']['id'] . "." . $v['id'] : $v['id'];
                            }
                        } else {
                            $new_result[$v['code']] = $v;
                        }
                    }
                }
                $payment_list = $new_result;
            }
        }

        //var_dump($payment_list);

        $total_rows = $this->pay_log_model->where($where)->count();

        $search_url = site_url($this->uri->uri_string().'?');
        $base_url = $search_url.http_build_query($search);

        $pager = $this->_pager($total_rows, array('per_page' => 15, 'base_url' => $base_url));

        $list = $this->pay_log_model
            ->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->order_by('id desc')->where($where)->find_all();
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->data['list'] = $list;

        //echo $this->db->last_query();
        //$tpl_data['per_page'] = $this->pageSize;
        //$this->data['page'] = $pager;

        $this->data['order_sn'] = $order_sn ? $order_sn : '';
        $this->data['payment_mob'] = $payment_mob ? $payment_mob : '';
        $this->data['payment_code'] = $payment_code ? $payment_code : '';

       // $tpl_data['pagination'] = $this->pages($this->pay_log_model->total_rows($where));

        $this->data['payment_list'] = $payment_list;

        $this->load->view($this->dcm, $this->data);
    }

    protected function pages($totalNum,$url = '')
    {
        $pagination_config = array(
            'base_url'		=> $url ? $url : $this->route . $this->queryString,
            'total_rows'	=> $totalNum,
            'per_page'		=> $this->pageSize,
            'uri_segment'	=> $this->urlSegment,
            'page_query_string' => $this->pageQueryString,
        );
        $this->load->library('pagination');
        $this->pagination->initialize($pagination_config);
        return $this->pagination->create_links();
    }

    //开通商户

    public function open() {
        if ($this->input->post()) {
            $partner_name = $this->input->get_post('partner_name', true);
            $res = $this->user_partner_model->where(array('site_id' => $this->site_id))->find();
            if ($res) {
                return $this->show_message(false, '此商户已经开通过微巴支付');
            }
            if (!$partner_name) {
                return $this->show_message(false, '请填写商户名称');
            }
            $result = $this->cashier_rest->post('partner', array('name' => $partner_name));
            if ($this->cashier_rest->status() == 201 && $result) {
                $save_data = array(
                    'site_id'      => $this->site_id,
                    'partner_id'   => $result['id'],
                    'partner_name' => $result['name'],
                    'partner_key'  => $result['partner_key']
                );
                $this->user_partner_model->add($save_data);
            }
            redirect('/c/wbpay/index');
        }
        $this->load->view($this->dcm, $this->data);
    }

    //配置商户信息  正确则保存 OK
    public function config_partner() {
        if ($this->input->post()) {
            $this->form_validation->set_rules('partner_id', '商户号', 'trim|required|numeric|max_length[9]');
            $this->form_validation->set_rules('partner_key', '商户密钥', 'trim|required|max_length[64]');
            if ($this->form_validation->run()) {
                $partner_id = $this->form_validation->set_value('partner_id');
                $partner_key = $this->form_validation->set_value('partner_key');
                $result = $this->cashier_rest->get('partner', array('partner_id' => $partner_id, 'partner_key' => $partner_key));
                if ($this->cashier_rest->status() == 200 && $result) {
                    //保存信息
                    if ($this->data['has_config']) {
                        if (($this->data['partner_info']['partner_id'] != $result['id']) || ($this->data['partner_info']['partner_name'] != $result['name']) || ($this->data['partner_info']['partner_key'] != $result['partner_key'])) {
                            $save_data = array(
                                'site_id'      => $this->site_id,
                                'partner_id'   => $result['id'],
                                'partner_name' => $result['name'],
                                'partner_key'  => $result['partner_key']
                            );
                            if ($this->user_partner_model->where(array('id' => $this->data['partner_info']['id']))->edit($save_data)) {
                                redirect('/c/wbpay/index');
                            } else {
                                return $this->show_message(FALSE, '配置商户信息失败', '');
                            }
                        }
                    } else {
                        $save_data = array(
                            'site_id'      => $this->site_id,
                            'partner_id'   => $result['id'],
                            'partner_name' => $result['name'],
                            'partner_key'  => $result['partner_key']
                        );
                        $this->user_partner_model->add($save_data);
                        redirect('/c/wbpay/index');
                    }
                } else {
                    return $this->show_message(FALSE, '没有找到该商户信息', '');
                }
            } else {
                $errors = validation_errors();
                if ($errors) {
                    return $this->show_message(FALSE, $errors, '');
                }
            }
        } else {
            $this->load->view($this->dcm, $this->data);
        }
    }

    //配置单个支付  安装 修改
    public function config_pay($code = '') {
        !$code && redirect('/c/wbpay/index');
        //对于微巴支付单独处理
        $pay_info = array();
        if ($code == 'wbpay') {
            $pay_info['alipay'] = $this->get_single_pay('alipay');
            $pay_info['llpay'] = $this->get_single_pay('llpay');
        } else {
            $pay_info = $this->get_single_pay($code);
        }
        if ($this->input->post()) {
            $save_data['code'] = $code;
            if ($code == 'wbpay') {
                $alipay = $this->input->post('alipay');
                $alipay['code'] = 'alipay';

                $llpay = $this->input->post('llpay');
                $llpay['code'] = 'llpay';

                $config = $this->input->post('config');
                $alipay_config = isset($config['alipay']) ? $config['alipay'] : array();
                $llpay_config = isset($config['llpay']) ? $config['llpay'] : array();
                $alipay['config'] = $alipay_config ? $this->_build_config($alipay_config) : '';
                $llpay['config'] = $llpay_config ? $this->_build_config($llpay_config) : '';

                $alipay['partner_id'] = $llpay['partner_id'] = $this->data['partner_info']['partner_id'];
                if (isset($pay_info['alipay']['config']) && isset($pay_info['llpay']['config'])) {
                    $alipay['id'] = $pay_info['alipay']['id'];
                    $llpay['id'] = $pay_info['llpay']['id'];
                    $this->cashier_rest->put('payment', $alipay);
                    $this->cashier_rest->put('payment', $llpay);
                } else {
                    $this->cashier_rest->post('payment', $alipay);
                    $this->cashier_rest->post('payment', $llpay);
                }
            } else {
                $save_data['name'] = $this->input->post('name');
                $save_data['enabled'] = $this->input->post('enabled');
                $save_data['is_sys'] = intval($this->input->post('is_sys'));
                $save_data['listorder'] = intval($this->input->post('listorder'));
                $save_data['config'] = '';
                $temp_config = $this->input->post('config');
                if ($temp_config) {
                    /*$temp = array();
                    foreach ($temp_config as $key => $val) {
                        $temp[] = $key . ',' . $val;
                    }
                    $save_data['config'] = implode(';', $temp);*/
                    $save_data['config'] = $this->_build_config($temp_config);
                }
                $save_data['partner_id'] = $this->data['partner_info']['partner_id'];
                if (isset($pay_info['config'])) {
                    $save_data['id'] = $pay_info['id'];
                    $result = $this->cashier_rest->put('payment', $save_data);
                } else {
                    //安装支付
                    $result = $this->cashier_rest->post('payment', $save_data);
                }
            }
            if ($this->cashier_rest->status() == 201) {
                redirect('/c/wbpay/index');
            } else {
                return $this->show_message(FALSE, 'Insufficient Permissions', '/c/wbpay/index');
            }
        } else {
            $this->data['info'] = $pay_info;
            //var_dump($pay_info);
            if ($code == "wbpay") {
                $this->load->view($this->dcm . "_wbpay", $this->data);
            } else {
                $this->load->view($this->dcm, $this->data);
            }
        }
    }

    //配置重新构造
    protected function _build_config($config) {
        $temp = array();
        foreach ($config as $key => $val) {
            $temp[] = $key . ',' . $val;
        }
        return implode(';', $temp);
    }

    //卸载支付配置
    public function uninstall_pay($id = '') {
        !$id && redirect('/c/wbpay/index');

        if (is_numeric(strpos($id, '.'))) {
            $id_arr = explode(".", $id);
            foreach($id_arr as $v) {
                $this->cashier_rest->delete('payment/' . $v, array('partner_id' => $this->data['partner_info']['partner_id']));
            }
        } else {
            $resp = $this->cashier_rest->delete('payment/' . $id, array('partner_id' => $this->data['partner_info']['partner_id']));
        }

        if ($this->cashier_rest->status() == 200) {
            redirect('/c/wbpay/index');
        } else {
            return $this->show_message(FALSE, '卸载失败', '');
        }
    }

    //获取单个支付信息
    private function get_single_pay($code = '') {
        if ($this->data['has_config']) {
            $partner_id = $this->data['partner_info']['partner_id'];
            $result = $this->cashier_rest->get('payment/builtins', array('partner_id' => $partner_id));
            if ($this->cashier_rest->status() == 200) {
                foreach ($result as $val) {
                    if ($val['code'] == $code) {
                        return $val;
                        break;
                    }
                }
            }
        }
        return false;
    }

    //检测本地是否存在 已配置的商户信息 返回本地配置信息
    public function check_open() {
        $where['site_id'] = $this->site_id;
        $partner_info = $this->user_partner_model->where($where)->find();
        $this->data['partner_info'] = $partner_info;
    }

    /**
     * 导出
     */

    public function export()
    {
        $this->load->model('pay_log_model');

        $where = array('site_id' => $this->site_id);

        $order_sn = $this->input->get_post('order_sn');
        $payment_mob = $this->input->get_post('payment_mob');
        $payment_code = $this->input->get_post('payment_code');

        $search = array();

        if($order_sn)
        {
            $where['order_sn like'] = "%{$order_sn}%";
        }
        if($payment_mob)
        {
            $where['payment_mob like'] = "%{$payment_mob}%";
        }
        if($payment_code)
        {
            $where['payment_code'] = $payment_code;
        }

        $list = $this->pay_log_model
            ->select('order_sn,payment_sn,payment_mob,payment_name,pay_time,total_price')
            ->where($where)
            ->order_by('id asc')
            ->find_all();

       // var_dump($list);

        //echo $this->db->last_query();

        $fields = array(
            'order_sn'=>'订单号',
            'payment_sn'  =>'交易单号',
            'payment_mob'=>'用户手机号',
            'payment_name'=>'支付方式',
            'pay_time'=>'支付时间',
            'total_price'=>'支付金额'
        );

        $this->excel_flush_export($fields, $list,'支付记录');
    }

    public function excel_flush_export( $fields, $list, $title)
    {
        set_time_limit(0);
        ini_set ('memory_limit', '256M');
        $csv_file = $title.'_'.date('Ymd').'.csv';
        // 输出Excel文件头
        header('Content-Type: application/vnd.ms-excel;charset=gbk');
        header('Content-Disposition: attachment;filename='.$csv_file);
        header('Cache-Control: max-age=0');

        // PHP文件句柄，php://output 表示直接输出到浏览器

        $fp = fopen('php://output', 'a');

        // 输出Excel列头信息
        foreach ($fields as $k => $v) {
            // CSV的Excel支持GBK编码，一定要转换，否则乱码
            $fields[$k] = mb_convert_encoding($v, 'gbk', 'utf-8');    //iconv('utf-8', 'gbk', $v);
        }

        // 写入列头
        fputcsv($fp, $fields);

        // 计数器
        $cnt = 0;
        // 每隔$limit行，刷新一下输出buffer，节约资源
        $limit = 100000;

        //var_dump($list);exit;

        // 逐行取出数据，节约内存
        foreach($list as $lv) {
            $cnt ++;
            if ($limit == $cnt) { //刷新一下输出buffer，防止由于数据过多造成问题
                ob_flush();
                flush();
                $cnt = 0;
            }

            foreach ($lv as $ik => $iv) {
                $iv = str_replace("\n", "", str_replace("\r", "", $iv));
                //$iv = htmlspecialchars($iv);
                //$row[$ik] = iconv('utf-8', 'gbk', $iv);
                $row[$ik] = mb_convert_encoding($iv, 'gbk', 'utf-8');
            }
            fputcsv($fp, $row);
        }
    }
}
