<?php
/**
 * Created by PhpStorm.
 * User: along
 * Date: 14-3-13
 * Time: 上午11:50
 *
 */

class Printer extends C_Controller {

    protected $auto_load_model = TRUE;
    protected $model_name = 'printer';
    protected $data = '';
    private $site_id = '';
    const LOMOBASEURL = 'http://ra1.lomoment.com/v2/int/int_ext/';

    public function __construct()
    {
        parent::__construct();

        $this->site_id = $this->site_info['id'];
    }

    /**
     * 打印机列表
     */
    public function index()
    {

        $list = array();
        $where = array('site_id'=>$this->site_id,'status >= '=>0);
        $total = $this->model->where($where)->count();
        if($total > 0)
        {
            $list = $this->model->where($where)->order_by('id', 'desc')->find_all();
        }
        $pager = $this->_pager($total, array('per_page'=>10));

        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->load->view($this->dcm, $this->data);
    }

    /**
     * 添加打印机
     * @return bool
     */
    public function add()
    {
        if( $this->input->post() ){
            $this->form_validation->set_rules('token', '打印机token', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('terminal_id', '打印机序号', 'trim|required');
            $this->form_validation->set_rules('terminal_qrcode_url', '二维码图片', 'trim|required');
            $this->form_validation->set_rules('adword', '照片广告语', 'trim|max_length[40]');
            if ( $this->form_validation->run() ){

                $save_data['token'] = $this->form_validation->set_value('token');
                $save_data['terminal_id'] = $this->form_validation->set_value('terminal_id');
                //打印机是否重复
                $printer = $this->model->where(array('terminal_id'=>$save_data['terminal_id'],'status'=>1))->find();
                if($printer)
                {
                    $this->show_message(false, '添加失败，该打印机正在使用中','');return FALSE;
                }

                $terminal_ad_url = $this->input->post('image');
                $save_data['pic'] = json_encode($terminal_ad_url);
                $save_data['terminal_qrcode_url'] = $this->form_validation->set_value('terminal_qrcode_url');
                $save_data['adword'] = $this->form_validation->set_value('adword');

                $pricetype = $this->input->post('pricetype');
                $price = $this->input->post('price');
                $save_data['price'] = ($pricetype==1 && $price > 0) ? $price : 0;

                $save_data['site_id'] = $this->site_id;
                $save_data['mp_username'] = $this->site_info['mp_username'];

                $save_data['add_time'] = time();

                if( $this->model->add($save_data) ){
                    //更新打印机设置
                    $option = array('terminal_free_rcode'=>$save_data['terminal_id']);

                    $option['terminal_qrcode_url'] = (isset($save_data['terminal_qrcode_url']) && $save_data['terminal_qrcode_url']) ? $save_data['terminal_qrcode_url'] : 'delete';

                    if(isset($terminal_ad_url[0]) && $terminal_ad_url[0])
                    {
                        $option['terminal_ad_1_url'] = $terminal_ad_url[0];
                    }
                    if(isset($terminal_ad_url[1]) && $terminal_ad_url[1])
                    {
                        $option['terminal_ad_2_url'] = $terminal_ad_url[1];
                    }
                    if(isset($terminal_ad_url[2]) && $terminal_ad_url[2])
                    {
                        $option['terminal_ad_3_url'] = $terminal_ad_url[2];
                    }

                    $result = $this->getCurlResult('terminal_settings_set.php',$save_data['terminal_id'],$save_data['token'],$option);
                    if($result['status_code'] != 0)
                    {
                        if($result['status_code'] == 100)
                        {
                            $this->show_message(true, '保存成功,认证失败（签名错误）', '/c/printer');return FALSE;
                        }
                        elseif($result['status_code'] == 204)
                        {
                            $this->show_message(true, '保存成功,打印机设置失败', '/c/printer');return FALSE;
                        }
                    }
                    else
                    {
                        $this->show_message(true, '保存成功,打印机设置成功', '/c/printer');return FALSE;
                    }

                }else{
                    $this->show_message(false, '保存失败', '/c/printer');return FALSE;
                }

            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }
        else
        {
            $this->load->view($this->dcm, $this->data);
        }
    }

    /**
     * @name 编辑打印机
     * @param $id
     * @return bool
     */
    public function edit($id = '')
    {
        $printer = $this->getMyPrinter($id);
        //print_r($printer);exit;
        if(is_array($printer))
        {
            if ($this->input->post())
            {
                $this->form_validation->set_rules('terminal_qrcode_url', '二维码图片', 'trim|required');
                $this->form_validation->set_rules('adword', '照片广告语', 'trim|max_length[40]');

                if ( $this->form_validation->run() ){

                    $save_data['terminal_qrcode_url'] = $this->form_validation->set_value('terminal_qrcode_url');
                    $save_data['adword'] = $this->form_validation->set_value('adword');
                    $terminal_ad_url = $this->input->post('image');

                    $save_data['pic'] = json_encode($terminal_ad_url);

                    $pricetype = $this->input->post('pricetype');
                    $price = $this->input->post('price');

                    $save_data['price'] = ($pricetype==1 && $price > 0) ? $price : 0;

                    if( $this->model->where(array('id'=>$id,'site_id'=>$this->site_id))->edit($save_data) ){
                        //更新打印机设置
                        $option = array('terminal_free_rcode'=>$printer['terminal_id']);

                        $option['terminal_qrcode_url'] = (isset($save_data['terminal_qrcode_url']) && $save_data['terminal_qrcode_url']) ? $save_data['terminal_qrcode_url'] : 'delete';

                        $option['terminal_ad_1_url'] = (isset($terminal_ad_url[0]) && $terminal_ad_url[0]) ? $terminal_ad_url[0] : 'delete';
                        $option['terminal_ad_2_url'] = (isset($terminal_ad_url[1]) && $terminal_ad_url[1]) ? $terminal_ad_url[1] : 'delete';
                        $option['terminal_ad_3_url'] = (isset($terminal_ad_url[2]) && $terminal_ad_url[2]) ? $terminal_ad_url[2] : 'delete';

                        //var_dump($option);exit;
                        $result = $this->getCurlResult('terminal_settings_set.php',$printer['terminal_id'],$printer['token'],$option);
                        if($result['status_code'] != 0)
                        {
                            if($result['status_code'] == 100)
                            {
                                $this->show_message(true, '编辑成功,认证失败（签名错误）', '/c/printer/edit/'.$id);return FALSE;
                            }
                            elseif($result['status_code'] == 204)
                            {
                                $this->show_message(true, '编辑成功,打印机设置失败', '/c/printer/edit/'.$id);return FALSE;
                            }
                        }
                        else
                        {
                            $this->show_message(true, '编辑成功,打印机设置成功', '/c/printer/edit/'.$id);return FALSE;
                        }

                    }else{
                        $this->show_message(false, '编辑失败', '/c/printer/edit/'.$id);return FALSE;
                    }

                }else{
                    $errors = validation_errors();
                    if ($errors) {
                        $this->show_message(FALSE, $errors, '');
                        return FALSE;
                    }
                }

            }
            else
            {
                if($printer['pic'])
                {
                    $printer['pic'] = json_decode($printer['pic'],true);
                }
                $this->data['printer'] = $printer;
                $this->load->view($this->dcm,$this->data);
            }
        }
        else
        {
            $this->show_message(FALSE, $printer, '');
            return FALSE;
        }
    }

    /**
     * 微信打印机设置
     * @return bool
     */
    public function set()
    {
        $this->load->model('model_app_config');
        $printerSet = $this->model_app_config->get_row(array('user_id'=>$this->site_id, 'type'=>'printer'));

        $update = 0;
        if($printerSet && $printerSet['config'])
        {
            $update = 1;
            $printerSet['config'] = json_decode($printerSet['config'],true);
        }

        if( $this->input->post() ){
            //是否限制每个帐号的打印数量 0表示不限制
            $type = $this->input->post('type');
            $number = $this->input->post('number');
            $type = $type ? $type : 0;

            $save_data['number'] = ($type && $number) ? $number : 0;

            if(isset($printerSet['config']['interface_api']) && $printerSet['config']['interface_api'] && $printerSet['config']['interface_api']!='null')
            {
                $save_data['interface_api'] = $printerSet['config']['interface_api'];
            }
            else
            {
                $this->load->library('curl');
                $interfaceUrl = 'http://interface.bama555.com/data/add_wechat_site';
                $default_api = full_url('/api/'.$this->site_info['username'], 'w');

                $api_url = 'http://'.$this->site_info['domain'].BASE_DOMAIN.'/photoPrint/api';
                $postData = array(
                    'source'=>$this->site_info['username'],
                    'token'=>$this->site_info['token'],
                    'default_api'=>$default_api,
                    'gh_id'=>'',
                    'summary'=>'printer',
                    'api_url' =>$api_url
                );
                $return = $this->curl->post($interfaceUrl,$postData);
                if($return)
                {
                    $result = json_decode($return,true);
                    if($result['ret'] == 0)
                    {
                        $save_data['interface_api'] = $result['data']['interface_api'];
                    }
                    else
                    {
                        $this->show_message(false, $result['msg'], '/c/printer/set');return FALSE;
                    }
                }
            }

            $saveData['config'] = json_encode($save_data);

            if($update)
            {
                $this->model_app_config->update(array('user_id'=>$this->site_id, 'type'=>'printer'), $saveData);
            }
            else
            {
                $saveData['user_id'] = $this->site_id;
                $saveData['type'] = 'printer';
                $this->model_app_config->add($saveData,true);
            }
            $this->show_message(true, '保存成功', '/c/printer/set');return FALSE;
        }
        else
        {
            //print_r($printerSet);
            $this->data['set'] = $printerSet;
            $this->data['site'] = $this->site_info;
            //print_r($this->site_info);
            $this->load->view($this->dcm, $this->data);
        }
    }

    public function rtwo()
    {
        $this->load->model('model_app_config');
        $printerSet = $this->model_app_config->get_row(array('user_id'=>$this->site_id, 'type'=>'printerV2'));

        if($printerSet && $printerSet['config'])
        {
            $printerSet['config'] = json_decode($printerSet['config'],true);
        }

        //print_r($interface);
        if($this->input->post())
        {
            $keyword = $this->input->post('enter_key');
            if(empty($keyword))
            {
                $this->show_message(false, '关键词不能为空', '');return FALSE;
            }
            if($keyword == '我要打印')
            {
                $this->show_message(false, '当前关键词不能使用，请换一个', '');return FALSE;
            }
            //获取站点接口
            $interface = $this->check_interface('printerV2');
            if(!is_array($interface))
            {
                $this->show_message(false, '系统错误:'.$interface, '');return FALSE;
            }
            if((!$printerSet) || (isset($printerSet['config']) && $keyword != $printerSet['config']['keyword']))
            {
                $postdata = array(
                    'site_id' => $interface['site_id'],
                    'action'  => 0,
                    'time_out' => 120,
                    'api_type' => 0,
                    'enter_key' => $keyword,
                    'enter_msg' => '请发送你要打印的照片，2分钟内有效。退出打印状态请输入bye',
                    'exit_key'  => 'bye',
                    'exit_msg'  => '感谢您的使用，再次使用请输入\''.$keyword.'\'',
                    'api_url'   => 'http://'.$this->site_info['domain'].BASE_DOMAIN.'/newPhotoPrint/api'
                );
                if(isset($printerSet['config']))
                {
                    $postdata['api_id'] = $printerSet['config']['api_id'];
                }
                $result = $this->check_interface_api($postdata);
                if($result['ret'] != 0)
                {
                    $this->show_message(false, $result['msg'], '');return FALSE;
                }
                else
                {
                    $config = array('keyword'=>$keyword,'api_id'=>$result['data']['api_id']);
                    $saveData['config'] = json_encode($config);
                    //更新or新增
                    if(!$printerSet)
                    {
                        $saveData['user_id'] = $this->site_id;
                        $saveData['type'] = 'printerV2';
                        $this->model_app_config->add($saveData,true);
                    }
                    else
                    {
                        $this->model_app_config->update(array('user_id'=>$this->site_id, 'type'=>'printerV2'), $saveData);
                    }
                }
            }
            $this->show_message(true, '保存成功', '');return FALSE;
        }
        else
        {
            $interface = $this->check_interface('printerV2');
        }
        $printerSet['config']['interface_api'] = isset($interface['interface_api']) ? $interface['interface_api'] : '';
        $this->data['config'] = $printerSet['config'];
        $this->data['site'] = $this->site_info;

        $this->load->view($this->dcm, $this->data);
    }

    /**
     * 停用打印机
     * @param $id
     * @return bool
     */
    public function stop($id = '')
    {
        $printer = $this->getMyPrinter($id);
        if(is_array($printer))
        {
            $this->model->where(array('id'=>$printer['id'],'site_id'=>$this->site_id))->edit(array('status'=>0));
            $this->show_message(FALSE, '停用成功', '');return FALSE;
        }
        else
        {
            $this->show_message(FALSE, $printer, '/c/printer');return FALSE;
        }
    }

    /**
     * 启用打印机
     * @param $id
     * @return bool
     */
    public function open($id = '')
    {
        $printer = $this->getMyPrinter($id);
        if(is_array($printer))
        {
            //打印机是否重复
            $result = $this->model->where(array('terminal_id'=>$printer['terminal_id'],'status'=>1,'id != '=>$id))->find();
            if($result)
            {
                $this->show_message(false, '启用失败，已有相同名称的打印机正在使用中','');return FALSE;
            }

            $this->model->where(array('id'=>$printer['id'],'site_id'=>$this->site_id))->edit(array('status'=>1));
            $this->show_message(FALSE, '启用成功', '/c/printer');return FALSE;
        }
        else
        {
            $this->show_message(FALSE, $printer, '/c/printer');return FALSE;
        }
    }

    /**
     * @name 删除打印机
     * @param string $id
     * @return bool
     */
    public function del($id = '')
    {
        $printer = $this->getMyPrinter($id);
        if(is_array($printer))
        {
            $this->model->where(array('id'=>$printer['id'],'site_id'=>$this->site_id))->edit(array('status'=>-1));
            $this->show_message(FALSE, '删除成功', '/c/printer');return FALSE;
        }
        else
        {
            $this->show_message(FALSE, $printer, '/c/printer');return FALSE;
        }
    }

    /**
     * @生成消费码
     * @param $pid
     * @return bool
     */
    public function addcode($pid = '')
    {
        $printer = $this->getMyPrinter($pid);
        if(is_array($printer))
        {
            if($this->input->post())
            {
                $this->form_validation->set_rules('count', '消费码生成数量', 'trim|intval|is_natural|less_than[500]');

                if ( $this->form_validation->run() )
                {
                    $count =  $this->form_validation->set_value('count');
                    $uint = 100;
                    $ceilnum = ceil($count/$uint);

                    if($ceilnum>0)
                    {
                        $data = array();
                        $time = time();
                        $this->load->helper('string');
                        $this->load->model('printer_code_model');
                        $num = 0;
                        for($i=1;$i<=$ceilnum;$i++)
                        {
                            $fornum = $count - $i*$uint;

                            if($fornum > 0 && $fornum < $uint && $ceilnum==1)
                            {
                                $j = $fornum;
                            }
                            if($fornum < 0)
                            {
                                $j = $uint+$fornum;
                            }
                            else
                            {
                                $j = $uint;
                            }
                            for($ii=1; $ii<=$j;$ii++)
                            {
                                $randCode = random_string('numeric', 6);
                                /*
                                $code = $this->printer_code_model->where(array('code'=>$randCode,'site_id'=>$this->site_id,'pid'=>$pid))->find();
                                if(!$code)
                                {
                                    $data[] = array(
                                        'code' => $randCode,
                                        'site_id'=>$this->site_id,
                                        'pid'=>$pid,
                                        'dt_add'=>$time
                                    );
                                }
                                */
                                $code = $this->printer_code_model->where(array('code'=>$randCode,'site_id'=>$this->site_id,'pid'=>$pid))->find();
                                if(!$code)
                                {
                                    $this->printer_code_model->add(array('code'=>$randCode,'site_id'=>$this->site_id,'pid'=>$pid,'dt_add'=>$time));
                                    $num ++ ;
                                }
                            }
                        }
                        $this->show_message(true, '成功生成'.$num.'个消费码', '/c/printer/consumeCode/?pid='.$pid);return FALSE;
                    }
                }
                else
                {
                    $errors = validation_errors();
                    if ($errors) {
                        $this->show_message(FALSE, $errors, '');
                        return FALSE;
                    }
                }
            }
            else
            {
                $this->load->view($this->dcm, $this->data);
            }
        }
        else
        {
            $this->show_message(FALSE, $printer, '/c/printer');return FALSE;
        }
    }

    /**
     * 消费码
     * @return bool
     */
    public function consumeCode()
    {
        $pid = $this->input->get('pid');
        $printer = $this->getMyPrinter($pid);
        if(is_array($printer))
        {
            $search_url = '/c/printer/consumeCode/?pid='.$pid;

            $where = "site_id='".$this->site_id."' AND pid='".$pid."'";
            $search = array();

            $search['code'] = $this->input->get('code');
            $search['telephone'] = $this->input->get('tel');
            $search['status'] = $this->input->get('status');

            if( $search ){
                foreach( $search as $key=>$val ){
                    if( $val ){
                        $search_url .= '&'.$key.'='.$val;
                        switch ($key){
                            case 'code':
                                $where .= " AND code LIKE '%".$val."%'";
                                break;
                            case 'telephone':
                                $where .= " AND telephone LIKE '%".$val."%'";
                                break;
                            default: break;
                        }
                    }
                }
            }
            if($search['status'] != -1)
            {
                $search['status'] = $search['status'] == 1 ? 1 : 0;
                $where .= " AND status=".$search['status'];
            }

            $this->data['search'] = $search;

            $this->load->model('printer_code_model');
            $count = $this->printer_code_model->where($where)->count();
            $list = array();
            if($count)
            {
                $pager = $this->_pager($count, array('per_page'=>20,'base_url'=>$search_url));
                $list = $this->printer_code_model->where($where)->order_by('id desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->find_all();
            }
            $this->data['printer'] = $printer;
            $this->data['list'] = $list;

            $this->data['page'] = isset($pager) ? $pager['links'] : '';
            $this->load->view($this->dcm, $this->data);
        }
        else
        {
            $this->show_message(FALSE, $printer, '/c/printer');return FALSE;
        }

    }

    public function order()
    {
        $pid = $this->input->get('pid');
        $printer = $this->getMyPrinter($pid);
        if(is_array($printer))
        {
            $search_url = '/c/printer/order/?pid='.$pid;

            $where = "site_id='".$this->site_id."' AND pid='".$pid."'";
            $search = array();

            $search['from_time'] = $this->input->get('from_time');
            $search['end_time'] = $this->input->get('end_time');

            $search['telephone'] = $this->input->get('tel');
            $search['type'] = $this->input->get('type');

            if( $search ){
                foreach( $search as $key=>$val ){
                    if( $val ){
                        $search_url .= '&'.$key.'='.$val;
                        switch ($key){
                            case 'code':
                                $where .= " AND code LIKE '%".$val."%'";
                                break;
                            case 'from_time':
                                $where .= " AND dt_add >= ".strtotime($search['from_time']);
                                break;
                            case 'end_time':
                                $where .= " AND dt_add <= ".strtotime($search['end_time']);
                                break;
                            case 'telephone':
                                $where .= " AND telephone LIKE '%".$val."%'";
                                break;
                            default: break;
                        }
                    }
                }
            }
            if($search['type'] == 1)
            {
                $where .= " and paytype = 1";
            }
            else if($search['type'] == 2)
            {
                $where .= " and paytype = 2";
            }
            $this->data['search'] = $search;

            //echo $where;
            $this->load->model('printer_order_model');
            $count = $this->printer_order_model->where($where)->count();

            $list = array();
            if($count)
            {
                $pager = $this->_pager($count, array('per_page'=>20,'base_url'=>$search_url));
                $list = $this->printer_order_model->where($where)->order_by('id desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->find_all();
            }
            $this->data['printer'] = $printer;
            $this->data['list'] = $list;

            $this->data['page'] = isset($pager) ? $pager['links'] : '';
            $this->load->view($this->dcm, $this->data);
        }
        else
        {
            $this->show_message(FALSE, $printer, '/c/printer');return FALSE;
        }
    }

    public function export()
    {
        $pid = $this->input->get('pid');
        $printer = $this->getMyPrinter($pid);
        if(is_array($printer))
        {
            $where = "site_id='".$this->site_id."' AND pid='".$pid."'";

            $search['from_time'] = $this->input->get('from_time');
            $search['end_time'] = $this->input->get('end_time');

            $search['telephone'] = $this->input->get('tel');
            $search['type'] = $this->input->get('type');

            if( $search ){
                foreach( $search as $key=>$val ){
                    if( $val ){
                        switch ($key){
                            case 'code':
                                $where .= " AND code LIKE '%".$val."%'";
                                break;
                            case 'from_time':
                                $where .= " AND dt_add >= ".strtotime($search['from_time']);
                                break;
                            case 'end_time':
                                $where .= " AND dt_add <= ".strtotime($search['end_time']);
                                break;
                            case 'telephone':
                                $where .= " AND telephone LIKE '%".$val."%'";
                                break;
                            default: break;
                        }
                    }
                }
            }
            if($search['type'] == 1)
            {
                $where .= " and paytype = 1";
            }
            else if($search['type'] == 2)
            {
                $where .= " and paytype = 2";
            }

            //echo $where;
            $this->load->model('printer_order_model');
            $list = $this->printer_order_model->where($where)->order_by('id desc')->find_all();
            if($list)
            {
                $exportData = array();
                foreach($list as $k => $_list)
                {
                    $exportData[$k]['type'] = ($_list['paytype'] == 1) ? '消费码' : '在线支付';
                    $exportData[$k]['payname'] = $_list['payname'];
                    $exportData[$k]['price'] = ($_list['paytype'] == 2) ? $_list['price'] : '/';
                    $exportData[$k]['dt_add'] = date('Y-m-d H:i:s',$_list['dt_add']);
                    $exportData[$k]['telephone'] = $_list['telephone'];
                }
                $fields = array(
                    '#'=>'#',
                    'type'=>'类型',
                    'payname'=>'消费码/支付方式',
                    'price'=>'价格',
                    'dt_add'=>'使用/消费时间',
                    'telephone'=>'使用人的手机'
                );
                $this->excel_export('消费记录列表', '消费记录列表', $fields, $exportData);
            }
            else
            {
                $this->show_message(FALSE, '尚无消费记录可导出', '/c/printer/order/?pid='.$pid);
            }
        }
    }
    /**
     * @name 获取我的一个打印机信息
     * @param string $id
     * @return mixed
     */
    private function getMyPrinter($id='')
    {
        $result = $this->model->where(array('id'=>$id,'site_id'=>$this->site_id))->find();
        if(!$result)
        {
            return '找不到此打印机';
        }
        else
        {
            return $result;
        }
    }


    /**
     * @name 获取curl结果
     * @param $jobUrlName
     * @param $terminal_id
     * @param $token
     * @param array $option
     * @return mixed
     */
    private function getCurlResult($jobUrlName,$terminal_id,$token,$option=array())
    {
        $timestamp = time();
        $this->load->helper('string');
        $nonce = random_string('numeric',10);
        //$printer
        $signature = $this->CheckSignature($terminal_id,$token,$nonce,$timestamp);

        $curlData = array('terminal_id'=>$terminal_id,'nonce'=>$nonce,'timestamp'=>$timestamp,'signature'=>$signature);
        if($option)
        {
            foreach($option as $key=>$value)
            {
                $curlData[$key] = $value;
            }
        }

        $jobUrl = self::LOMOBASEURL.$jobUrlName.'?'.http_build_query($curlData);
        $this->load->library('curl');
        $result = $this->curl->get($jobUrl);
        $result = json_decode($result,true);
        return $result;
    }

    /**
     * @desc signature参数是 terminal_id(机器id)+terminal_token(token)+nonce(随机数)+timestamp(时间戳)几个作为字符串连接然后 sha1 得到的
     * @param string $terminal_id
     * @param string $token
     * @param $nonce
     * @param $timestamp
     * @return string
     */
    private function CheckSignature($terminal_id,$token,$nonce,$timestamp)
    {
        return sha1($terminal_id.$token.$nonce.$timestamp);
    }

    /**
     * @name 生成指定尺寸的图片
     * @param $image
     * @param $width
     * @param $height
     * @param string $mime 规定的图片类型
     * @return bool|string
     */
/*
    private function createPicBySize($image,$width,$height,$mime='image/jpeg')
    {
        if(!$image) return false;
        $imageInfo = getimagesize($image);
        if($mime && $imageInfo['mime'] != $mime)
        {
            return '图片格式不正确';
        }
        //保存的图片路径
        $pathinfo = parse_url($image);

        $createWidth = ($imageInfo[0] != $width) ? $width : $imageInfo[0];
        $createHeight = ($imageInfo[1] != $height) ? $height : $imageInfo[1];
        switch ($mime)
        {
            case 'image/jpeg':
                $im = imagecreatefromjpeg($image);
            break;
            case 'image/png':
                $im = imagecreatefrompng($image);
            break;
        }
        $srcimgW=imagesx($im);
        $srcimgH=imagesy($im);

        //生成一张白色画布
        $image=imagecreatetruecolor($createWidth,$createHeight);
        $bg=imagecolorallocate($image,255,255,255);
        imagefill($image,0,0,$bg);

        imagecopy($image,$im,40,40,0,0,$srcimgW,$srcimgH);
        imagejpeg($image,FCPATH.$pathinfo['path']);
        imagedestroy($im);
        imagedestroy($image);

        return $pathinfo['path'];
    }
*/
} 