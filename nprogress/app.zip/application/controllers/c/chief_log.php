<?php
/**
 * Created by PhpStorm.
 * User: lufee(ldw1007@sina.cn)
 * Date: 14-8-20
 * Time: 下午3:05
 */
class Chief_log extends C_Controller{
    protected $auto_load_model = TRUE;
    protected $model_name = 'chief_log';
    public function __construct()
    {
        parent::__construct();
        $this->load->model('chief_log_model');
        $this->site_id = $this->site_info['id'];
    }

    public function delete($id)
    {
        if(!$id)
        {
            exit( json_encode( array('ret'=>1000,'msg'=>'非法参数') ) );
        }
        if($this->model->where(array('id'=>$id))->delete())
        {
            exit( json_encode( array('ret'=>0,'msg'=>'删除成功') ) );
        }else{
            exit( json_encode( array('ret'=>1001,'msg'=>'删除失败') ) );
        }
    }

    public function edit($id)
    {
        if(!$id)
        {
            exit( json_encode( array('ret'=>1000,'msg'=>'非法参数') ) );
        }
        $content = htmlspecialchars($this->input->post('content'));
        if($this->model->where(array('id'=>$id))->edit(array('content'=>$content)))
        {
            exit( json_encode( array('ret'=>0,'msg'=>'编辑成功') ) );
        }else{
            exit( json_encode( array('ret'=>1001,'msg'=>'编辑失败') ) );
        }
    }
}