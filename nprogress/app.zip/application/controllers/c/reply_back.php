<?php
/**
 * Created by PhpStorm.
 * User: 111
 * Date: 13-12-26
 * Time: 下午3:59
 * @property Mongo_db $mongo_db
 * @property Marketing_model $marketing_model
 */
class Reply extends C_Controller
{
    private $mongo_reply = 'reply';
    private $reply_types = array(
        'article' => '图文',
        'text' => '文字',
        'text_vote' => '微信投票（文字版）',
        'music' => '语音',
        'marketing' => '老活动'
    );

    public function __construct()
    {
        parent::__construct();
        $this->load->library('Mongo_db');
    }

    public function index()
    {
        $total_rows = $this->mongo_db->where(array('site_id'=>$this->site_info['id']))->count($this->mongo_reply);
        $pager = $this->_pager($total_rows);

        $reply_list = $this->mongo_db->where(array('site_id'=>$this->site_info['id']))->order_by(array('default'=>'desc', 'dt_update'=>'desc'))->limit($pager['limit']['value'])->offset($pager['limit']['offset'])->get($this->mongo_reply);

        $reply_list = $reply_list ? $reply_list : array();
        $this->load->model('marketing_model');
        foreach($reply_list as &$_item) {
            if($_item['type'] == 'article'){
                $_item['content'] = is_array($_item['content']) && count($_item['content']) > 0 ? array_shift($_item['content'])['title'].'<span class="label">(共'.count($_item['content']).'项)</span>' : '';
            } elseif ($_item['type'] == 'text') {
                $_item['content'] = htmlspecialchars_decode($_item['content']);
            } elseif ($_item['type'] == 'text_vote') {
                $vote = $this->marketing_model->join('marketing_vote', 'marketing.id = marketing_vote.marketing_id', 'left')->where(array('marketing.user_id'=>$this->site_info['id'], 'marketing.id'=>$_item['content']))->find();
                $_item['content'] = strlen($vote['instruction']) > 30 ? substr($vote['instruction'], 0, 30).'...' : $vote['instruction'];
            } elseif ($_item['type'] == 'music') {
                $_item['content'] = isset($_item['content']['title']) ? $_item['content']['title'] : '';
            } elseif ($_item['type'] == 'marketing') {
                $_item['content'] = is_array($_item['content']) && count($_item['content']) > 0 ? array_shift($_item['content'])['title'].'<span class="label">(共'.count($_item['content']).'项)</span>' : '';
            } else {
                $_item['content'] = '';
            }
            $_item['keyword'] = str_replace(',',' ', $_item['keyword']);
        }
        $this->data['reply_list'] = $reply_list;
        $this->data['reply_types'] = $this->reply_types;
        $this->data['page'] = $pager['links'];
        $this->load->view($this->dcm, $this->data);
    }

    public function add()
    {
        if($this->input->post()){
            $this->form_validation->set_rules('keyword', '关键词', 'trim|required|htmlspecialchars');
            $reply_type = $this->input->post('reply_type');
            if($reply_type == 'music') {
                $this->form_validation->set_rules('mtitle', '音乐标题', 'trim|required|htmlspecialchars');
                $this->form_validation->set_rules('murl', '音乐链接', 'trim|required|htmlspecialchars');
                $this->form_validation->set_rules('mdescription', '音乐描述', 'trim|max_length[30]|htmlspecialchars');
            }
            if($this->form_validation->run()) {
                $keyword = $this->form_validation->set_value('keyword');
                $keyword_arr = explode(' ', $keyword);
                foreach($keyword_arr as &$kw){
                    $kw = trim($kw);
                }

                $items = $this->input->post('item');
                $items = $items ? $items : array();
                $data = array();
                $data['site_id'] = $this->site_info['id'];
                $data['keyword'] = $keyword_arr;
                $data['type'] = $reply_type;
                $data['content'] = '';
                if($data['type'] == 'article') {
                    $data['content'] = $items;
                } elseif($data['type'] == 'text') {
                    $data['content'] = $this->input->post('text');
                } elseif($data['type'] == 'text_vote') {
                    $data['content'] = $this->input->post('vote_id');
                } elseif($data['type'] == 'music') {
                    $music = array();
                    $music['title'] = $this->form_validation->set_value('mtitle');
                    $music['musicurl'] = $music['HQmusicurl'] = $this->form_validation->set_value('murl');
                    $music['description'] = $this->form_validation->set_value('mdescription');
                    $data['content'] = $music;
                } elseif ($data['type'] == 'marketing') {
                    $data['content'] = $items;
                }

                $data['count_match'] = 0;
                $data['dt_add'] = $data['dt_update'] = time();
                if($this->mongo_db->insert($this->mongo_reply, $data)) {
                    $this->show_message(TRUE, '保存成功', '/c/reply');
                    return FALSE;
                } else {
                    $this->show_message(FALSE, '保存失败', '');
                    return FALSE;
                }
            } else {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        } else {
            $this->data['text'] = '';
            $this->data['btype'] = $this->get_btype();
            $this->load->view($this->dcm, $this->data);
        }
    }

    public function edit($id='')
    {
        if($id)
        {
            $reply = $this->mongo_db->where(array('site_id'=>$this->site_info['id'], '_id'=>new MongoId($id)))->get_one($this->mongo_reply);
            if(!$reply) {
                $this->show_message(FALSE, '该条自动回复不存在', '/c/reply');
                return FALSE;
            }
        }
        else
        {
            $this->show_message(FALSE, 'id不能为空', '/c/reply');
            return FALSE;
        }

        if($this->input->post()){
            $this->form_validation->set_rules('keyword', '关键词', 'trim|required|htmlspecialchars');
            $reply_type = $this->input->post('reply_type');
            if($reply_type == 'music') {
                $this->form_validation->set_rules('mtitle', '音乐标题', 'trim|required|htmlspecialchars');
                $this->form_validation->set_rules('murl', '音乐链接', 'trim|required|htmlspecialchars');
                $this->form_validation->set_rules('mdescription', '音乐描述', 'trim|max_length[30]|htmlspecialchars');
            }
            if($this->form_validation->run()) {
                $keyword = $this->form_validation->set_value('keyword');
                $keyword_arr = explode(' ', $keyword);
                foreach($keyword_arr as &$kw){
                    $kw = trim($kw);
                }

                $items = $this->input->post('item');
                $items = $items ? $items : array();
                $data = array();
                $data['keyword'] = $keyword_arr;
                $data['type'] = $reply_type;
                $data['content'] = '';
                if($data['type'] == 'article') {
                    $data['content'] = $items;
                } elseif ($data['type'] == 'text') {
                    $data['content'] = $this->input->post('text');
                } elseif ($data['type'] == 'text_vote') {
                    $data['content'] = $this->input->post('vote_id');
                } elseif ($data['type'] == 'music') {
                    $music = array();
                    $music['title'] = $this->form_validation->set_value('mtitle');
                    $music['musicurl'] = $music['HQmusicurl'] = $this->form_validation->set_value('murl');
                    $music['description'] = $this->form_validation->set_value('mdescription');
                    $data['content'] = $music;
                } elseif ($data['type'] == 'marketing') {
                    $data['content'] = $items;
                }
                $data['dt_update'] = time();
                if($this->mongo_db->where(array("_id"=>new MongoId($id), 'site_id'=>$this->site_info['id']))->set($data)->update($this->mongo_reply)) {
                    $this->show_message(TRUE, '保存成功', '/c/reply');
                    return FALSE;
                } else {
                    $this->show_message(FALSE, '保存失败', '');
                    return FALSE;
                }
            } else {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        } else {
            $this->data['article_list'] = array();
            $reply['keyword'] = implode(' ', $reply['keyword']);
            $this->data['reply'] = $reply;
            if($reply['type'] == 'article') {
                $article_list = $reply['content'] ? $reply['content'] : array();
                usort($article_list, function($item_a, $item_b){
                    if ($item_a['rank'] == $item_b['rank'])
                        return 0;
                    return ($item_a['rank'] < $item_b['rank']) ? -1 : 1;
                });

                $this->data['article_list'] = $article_list;
            }
            $this->data['text'] = ($reply['type'] == 'text') ? $reply['content'] : '';
            $this->data['vote_id'] = ($reply['type'] == 'text_vote') ? $reply['content'] : '';
            $this->data['btype'] = $this->get_btype();
            $this->load->view($this->dcm, $this->data);
        }
    }

    public function delete($id)
    {
        $reply = $this->mongo_db->where(array('site_id'=>$this->site_info['id'], '_id'=>new MongoId($id)))->get_one($this->mongo_reply);
        if(!$reply) {
            $this->show_message(FALSE, '该条自动回复不存在', '/c/reply');
            return FALSE;
        }

        if($this->mongo_db->where(array('site_id'=>$this->site_info['id'], '_id'=>new MongoId($id)))->delete($this->mongo_reply)){
            $this->show_message(TRUE, '删除成功', '/c/reply');
            return FALSE;
        } else {
            $this->show_message(TRUE, '删除失败', '/c/reply');
            return FALSE;
        }
    }

    public function set_default($id)
    {
        $reply = $this->mongo_db->where(array('site_id'=>$this->site_info['id'], '_id'=>new MongoId($id)))->get_one($this->mongo_reply);
        if(!$reply) {
            $this->show_message(FALSE, '该条自动回复不存在', '/c/reply');
            return FALSE;
        }

        //先在所有记录中unset掉default
        $this->mongo_db->where(array('site_id'=>$this->site_info['id'], 'default'=>1))->unset_field('default')->update($this->mongo_reply);
        //再将当前记录设置为默认回复
        $data = array();
        $data['default'] = 1;
        $data['dt_update'] = time();
        if($this->mongo_db->where(array("_id"=>new MongoId($id), 'site_id'=>$this->site_info['id']))->set($data)->update($this->mongo_reply)) {
            $this->show_message(TRUE, '设置成功', '/c/reply');
            return FALSE;
        } else {
            $this->show_message(TRUE, '设置失败', '/c/reply');
            return FALSE;
        }
    }

    public function unset_default($id)
    {
        $reply = $this->mongo_db->where(array('site_id'=>$this->site_info['id'], '_id'=>new MongoId($id)))->get_one($this->mongo_reply);
        if(!$reply) {
            $this->show_message(FALSE, '该条自动回复不存在', '/c/reply');
            return FALSE;
        }

        $data = array();
        $data['dt_update'] = time();
        if($this->mongo_db->where(array("_id"=>new MongoId($id), 'site_id'=>$this->site_info['id']))->unset_field('default')->set($data)->update($this->mongo_reply)) {
            $this->show_message(TRUE, '取消成功', '/c/reply');
            return FALSE;
        } else {
            $this->show_message(TRUE, '取消失败', '/c/reply');
            return FALSE;
        }
    }

    public function save_article_item()
    {
        $data = array();
        $error = '';
        if(!trim($this->input->post('title'))) {
            $error .= "名称是必须的".PHP_EOL;
        }
        $item = array();
        $item['type'] = $this->input->post('type');
        if($item['type'] == 'Link') {
            if(!$this->input->post('url')) {
                $error .= '链接是必须的';
            }
        }
        $item['id'] = $this->input->post('id') ? $this->input->post('id') : (string)new MongoId();
        $item['title'] = $this->input->post('title');
        $item['desc'] = $this->input->post('desc');
        if($this->input->post('image')) {
            $item['image'] = $this->input->post('image');
        } else {
            $item['image'] = $this->input->post('selected_img') ? $this->input->post('selected_img') : '';
        }
        $item['rank'] = $this->input->post('rank') ? intval($this->input->post('rank')) : 0;
        $this->input->post('ref_id') && $item['ref_id'] = $this->input->post('ref_id');
        $item['url'] = '';
        $this->input->post('url') && $item['url'] = $this->input->post('url');
        if($error) {
            $data['success'] = 0;
            $data['msg'] = $error;
        } else {
            $data['success'] = 1;
            $data['item'] = $item;
            $data['action'] = $this->input->post('id') ? 'edit' : 'add';
        }
        echo json_encode($data);
    }

    public function article_block()
    {
        $this->data['cur_item'] = array();
        $this->data['cur_params'] = array();
        if($this->input->post()) {
            $this->data['cur_item'] = array_values($this->input->post('item'))[0];
            $cur_params = $this->data['cur_item'];
            unset($cur_params['id']);
            unset($cur_params['title']);
            unset($cur_params['desc']);
            unset($cur_params['rank']);
            //unset($cur_params['type']);
            unset($cur_params['image']);
            $this->data['cur_params'] = $cur_params;
        }
        $this->data['btype'] = $this->get_btype();
        echo $this->load->view('c/reply/article_block', $this->data);
    }

    public function vote_list()
    {
        $params = $this->input->get();
        $query_arr = array();
        foreach($params as $k=>$p) {
            if($k != 'page') {
                $query_arr[] = $k.'='.$p;
            }
        }

        $query_string = implode('&', $query_arr);
        $this->load->model('marketing_model');

        $where = array();
        $where['user_id'] = $this->site_info['id'];
        $where['marketing.type'] = 'vote_text';
        $like = array();
        isset($params['keyword']) && $params['keyword'] && $like['instruction'] = $params['keyword'];
        $total_rows = $this->marketing_model->join('marketing_vote', 'marketing.id = marketing_vote.marketing_id', 'left')->where($where)->like($like)->count();

        $per_page = isset($params['per_page']) ? $params['per_page'] : '';
        $offset = isset($params['offset']) ? $params['offset'] : '';
        $vote_list = $this->marketing_model->join('marketing_vote', 'marketing.id = marketing_vote.marketing_id', 'left')->where($where)->like($like)->limit($per_page, $offset)->find_all();

        $pager = $this->_pager($total_rows, array('base_url' => site_url($this->uri->uri_string().'?').$query_string));

        $this->data['page'] = $pager['links'];
        $this->data['params'] = $params;
        $this->data['keyword'] = $this->input->get('keyword');
        $this->data['vote_list'] = $vote_list;
        $this->data['vote_id'] = $this->input->get('vote_id') ? $this->input->get('vote_id') : '';
        echo $this->load->view($this->dcm, $this->data);
    }
}