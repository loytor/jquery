<?php
/**
 * Created by PhpStorm.
 * User: llj
 * Date: 13-12-4
 * Time: 上午11:32
 * @property Mcard_model $mcard_model
 * @property Mcard_address_model $mcard_address_model
 * @property Model_address $model_address
 * @property Mcard_member_model $mcard_member_model
 * @property Mcard_level_model $mcard_level_model
 * @property Mcard_statistics_model $mcard_statistics_model
 * @property Mongo_db $mongo_db
 */
class Mcard extends C_Controller
{
    private $mongo_reply = 'reply';
    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        if(!$this->site_info['id']) {
            $this->show_message(FALSE, '请重新登陆', '/auth/login');
            return FALSE;
        }

        $this->load->model('mcard_model');
        $mcard = $this->mcard_model->where(array('site_id'=>$this->site_info['id']))->find();

        $this->load->model('mcard_address_model');
        //读取所有地址
        $this->load->model('model_address');
        $address = $this->model_address->get_all(array('wid'=>$this->site_info['id']), '', '');

        $this->load->library('Mongo_db');
        $field_list = $this->mongo_db->where(array('wid'=>$this->site_info['id']))->order_by(array('sort', 'ASC'))->get('account_fields');

        if($mcard) {
            //适用门店
            $mcard_address = $this->mcard_address_model->where(array('site_id'=>$this->site_info['id'], 'mcard_id'=>$mcard['id']))->find_all();
            $selected_ad_ids = array();
            foreach($mcard_address as $ma) {
                $selected_ad_ids[] = $ma['address_id'];
            }

            $unselect_address = array();
            $selected_address = array();
            foreach($address as $ad) {
                if(in_array($ad['id'], $selected_ad_ids)) {
                    $selected_address[] = $ad;
                } elseif($ad['status'] == 0) {
                    $unselect_address[] = $ad;
                }
            }

            $required_fields = explode(',', $mcard['required_fields']);
            $unselect_field = array();
            $selected_field = array();
            //需完善的信息
            if($mcard['condition'] == 1) {
                foreach($field_list as $field) {
                    if(in_array((string)$field['_id'], $required_fields)) {
                        $selected_field[] = $field;
                    } else {
                        $unselect_field[] = $field;
                    }
                }
            } else {
                $unselect_field = $field_list;
            }
        } else {
            //适用门店
            $unselect_address = array();
            $selected_address = array();
            foreach($address as $ad) {
                if($ad['status'] == 0) {
                    $unselect_address[] = $ad;
                }
            }

            $unselect_field = $field_list;
            $selected_field = array();
        }

        $this->form_validation->set_rules('title', '会员卡名称', 'trim|required|max_length[30]');
        $this->form_validation->set_rules('card_num_init', '起始卡号', 'trim|required|integer');
        $this->form_validation->set_rules('instruction', '会员卡说明', 'trim|htmlspecialchars');
        $this->form_validation->set_rules('un_instruction', '未领取会员卡时提示', 'trim|htmlspecialchars');
        if($this->input->post('barcode_on')) {
            $this->form_validation->set_rules('barcode_content', '条码内容', 'trim');
        }

        if($this->form_validation->run()) {
            $data = array();
            $data['title'] = $this->form_validation->set_value('title');
            $data['on'] = $this->input->post('on');
            $data['icon'] = $this->input->post('icon');
            $data['prefix'] = $this->input->post('prefix');
            $data['card_num_init'] = $this->form_validation->set_value('card_num_init');
            $data['instruction'] = $this->form_validation->set_value('instruction');
            $data['un_instruction'] = $this->form_validation->set_value('un_instruction');
            $data['condition'] = $this->input->post('condition');
            $data['required_mobile'] = $this->input->post('required_mobile') ? $this->input->post('required_mobile') : 0;
            $data['required_name'] = $this->input->post('required_name') ? $this->input->post('required_name') : 0;
            $data['barcode_on'] = $this->input->post('barcode_on');
            $data['barcode_content'] = $this->input->post('barcode_content');

            $barcode_shape = $this->input->post('barcode_shape');

            if($barcode_shape){
                $barcode_shape=implode(",",$barcode_shape);
                if(strpos($barcode_shape,',')>-1){
                    $data['barcode_shape'] = $this->input->post('barcode_shape_s').',3';
                }else{
                    if($barcode_shape==0){
                        $data['barcode_shape'] = $this->input->post('barcode_shape_s');
                    }else{
                        $data['barcode_shape'] = 3;
                    }
                }
            }

            if($data['condition'] == 1) {
                $required_fields = $this->input->post('required_fields') ? $this->input->post('required_fields') : array();
                $data['required_fields'] = implode(',', $required_fields);
            }
            $ads = $this->input->post('address');
            $ads = $ads ? $ads : array();

            if($mcard){
                if(!$this->mcard_model->where(array('id'=>$mcard['id'], 'site_id'=>$this->site_info['id']))->edit($data)) {
                    $this->show_message(FALSE, '保存失败', '');
                    return FALSE;
                }

                $selected_ad_ids = isset($selected_ad_ids) && $selected_ad_ids ? $selected_ad_ids : array();
                $del_ids = array_diff($selected_ad_ids, $ads);
                $add_ids = array_diff($ads, $selected_ad_ids);
                foreach($del_ids as $did) {
                    $this->mcard_address_model->where(array('address_id'=>$did, 'site_id'=>$this->site_info['id'], 'mcard_id'=>$mcard['id']))->delete();
                }

                foreach($add_ids as $aid) {
                    $data_ma = array();
                    $data_ma['site_id'] = $this->site_info['id'];
                    $data_ma['address_id'] = $aid;
                    $data_ma['mcard_id'] = $mcard['id'];
                    $this->mcard_address_model->add($data_ma);
                }

                $this->show_message(TRUE, '保存成功', '');
                return FALSE;
            } else {
                $data['site_id'] = $this->site_info['id'];
                $data['dt_add'] = time();
                $mcard_id = $this->mcard_model->add($data);
                if(!$mcard_id) {
                    $this->show_message(FALSE, '保存失败', '');
                    return FALSE;
                }
                foreach($ads as $a) {
                    $ma_data = array();
                    $ma_data['site_id'] = $this->site_info['id'];
                    $ma_data['mcard_id'] = $mcard_id;
                    $ma_data['address_id'] = $a;
                    $this->mcard_address_model->add($ma_data);
                }
                //默认添加1个会员卡等级
                $this->load->model('mcard_level_model');
                $add_data = array();
                $add_data['site_id'] = $this->site_info['id'];
                $add_data['mcard_id'] = $mcard_id;
                $add_data['title'] = $data['title'];
                $add_data['enable'] = 1;
                $add_data['basic'] = 1;
                $add_data['conditions'] = 2;
                $add_data['minpoints'] = 0;
                $add_data['maxpoints'] = 999999999;
                $add_data['dt_add'] = time();
                $this->mcard_level_model->add($add_data);

                $this->show_message(TRUE, '保存成功', '');
                return FALSE;
            }

        } else {
            $errors = validation_errors();
            if ($errors) {
                $this->show_message(FALSE, $errors, '');
                return FALSE;
            }
        }

        //外链地址
        $domain = $this->session->userdata('domain');
        $url = $domain ? "http://".$domain.BASE_DOMAIN."/vip" : '';
        $this->data['url'] = $url;

        $this->data['unselect_address'] = $unselect_address;
        $this->data['selected_address'] = $selected_address;
        $this->data['unselect_field'] = $unselect_field;
        $this->data['selected_field'] = $selected_field;

        $this->data['mcard'] = $mcard;
        $this->load->view($this->dcm, $this->data);
    }

    /**
     * 会员卡用户
     */
    public function member()
    {
        $mcard = $this->check_mcard();
        if(!$mcard) {
            return FALSE;
        }

        $where = array();
        $where['mcard_member.is_deleted'] = 0;
        $where['mcard_member.site_id'] = $this->site_info['id'];
        $where['mcard_member.mcard_id'] = $mcard['id'];
        $like = array();
        ($name = $this->input->get('name')) && $like['name'] = $name;
        ($mobile = $this->input->get('mobile')) && $like['mobile'] = $mobile;
        ($card_num = $this->input->get('card_num')) && $like['card_num'] = $card_num;
        ($money = $this->input->get('money')) && $like['money'] = $money;
        ($credit = $this->input->get('credit')) && $where['credit'] = $credit;
        ($from_time = $this->input->get('from_time')) && $where['get_time >='] = strtotime($from_time);
        ($end_time = $this->input->get('to_time')) && $where['get_time <='] = strtotime($end_time);

        $this->load->model('mcard_level_model');

        $level_join = 'mcard_member.level_id = mcard_level.id';
        $level_id = $this->input->get('level_id');
        if($level_id && $level_id != -1) {
            $level = $this->mcard_level_model->where(array('site_id'=>$this->site_info['id'], 'mcard_id'=>$mcard['id'], 'id'=>$level_id))->find();
            if($level['conditions'] == 1) { //自定义
                $where['level_id'] = $level_id;
                $where['conditions'] = 1;
            } elseif ($level['conditions'] == 2) { //按积分
                $where['account.level_credit >= '] = $level['minpoints'];
                $where['account.level_credit < '] = $level['maxpoints'];
                $where['mcard_level.conditions'] = 2;
                $where['mcard_member.level_id < '] = 1;
                $level_join = 'mcard_member.mcard_id = mcard_level.mcard_id AND mcard_level.minpoints <= account.level_credit AND mcard_level.maxpoints > account.level_credit';
            }
        }

        $this->data['search'] = $this->input->get();

        $this->load->model('mcard_member_model');
        $total_rows =$this->mcard_member_model->select('mcard_member.*, account.name, account.mobile, account.money, account.credit, '.
            'account.level_credit, mcard_level.title as level')
            ->join('account', 'account.id = mcard_member.uid', 'left')->join('mcard_level', $level_join, 'left')->where($where)->like($like)->count();
        $pager = $this->_pager($total_rows, array('base_url' => site_url($this->uri->uri_string().'?').$_SERVER['QUERY_STRING']));
        $list = $this->mcard_member_model->select('mcard_member.*, account.name, account.mobile, account.money, account.credit, account.level_credit, mcard_level.title as level, mcard_level.conditions')->join('account', 'account.id = mcard_member.uid', 'left')->join('mcard_level', $level_join, 'left')->order_by('get_time desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->where($where)->like($like)->find_all();
        if($this->site_info['id'] == '53e31f6426bfb043')
        {
            //echo $this->db->last_query();
        }
        foreach($list as &$item) {
            //按积分的等级
            if(!$item['level_id']) {
                $item['level_credit'] = $item['level_credit'] ? $item['level_credit'] : 0;
                $item_level = $this->get_level_by_credit($mcard['id'], $item['level_credit']);
                $item['level'] = $item_level['title'];
                $item['conditions'] = 2;
            }
        }
        //获取所有等级
        $level_arr = $this->mcard_level_model->where(array('site_id'=>$this->site_info['id'], 'mcard_id'=>$mcard['id'], 'status != '=>-1))->find_all();
        $level_arr1 = $this->mcard_level_model->where(array('site_id'=>$this->site_info['id'], 'mcard_id'=>$mcard['id'], 'status != '=>-1, 'conditions !='=>2))->find_all();

        $this->data['level_arr'] = $level_arr;
        $this->data['level_arr1'] = $level_arr1;
        $this->data['list'] = $list ? $list : array();
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->load->view($this->dcm, $this->data);
    }

    /**
     * 会员卡导入
     */
    public function import()
    {
        $mcard = $this->check_mcard();
        if(!$mcard) {
            return FALSE;
        }
        /* 从excel文件导入会员卡 */
        if($this->input->is_ajax_request()) {
            $file_url = $this->input->post('file_url');

            $excel_data = $this->excel_import($file_url);
            $error = array();   //错误合集
            $csuccess = 0;      //导入成功数量
            //写入数据库
            if(!$excel_data) {
                    echo json_encode(array('success' => 0, 'error' => '没有导入任何数据，请检查文件内容或格式是否正确。'));
                    exit;
            }
            //验证列格式
            if(!isset($excel_data[0][0]) OR !isset($excel_data[0][1]) OR !isset($excel_data[0][2])) {
                echo json_encode(array('success' => 0, 'error' => '没有导入任何数据，Excel数据格式错误。'));
                exit;
            }
            $this->load->model('mcard_level_model');
            $this->load->model('mcard_member_model');
            $this->load->model('account_model');
            foreach($excel_data as $key => $val) {
                $line = $key + 2;
                //验证必填项
                if(!$val[0] OR !$val[1] OR !$val[2]) {
                    $error[] = '错误行：'.$line. '，【姓名】【手机】【等级】列填写不完整。';
                    continue;
                }
                //会员账号表
                $account = array(
                    'name'   => $val[0],
                    'mobile' => $val[1],
                    'money'  => $val[4],
                    'credit' => $val[5],
                    'wid'    => $this->site_info['id'],
                    'dt_add' => time(),
                );
                if(!isset($val[6]) OR empty($val[6])) {
                    $get_time = time();
                } else {
                    $get_time = strtotime($val[6]);
                }
                //会员卡表
                $mcard_member = array('mcard_id' => $mcard['id'], 'site_id'=>$this->site_info['id'], 'get_time' => $get_time);
                if(is_numeric($val[2])) {   //等级填写的是等级积分
                    $account['level_credit'] = $val[2];

                } else {                    //等级填写的是等级名
                    //查找等级ID
                    $level = $this->mcard_level_model->select('id')->where(array('title' => $val[2], 'site_id'=>$this->site_info['id']))->find();
                    if(!$level) {
                        $error[] = '错误行：'.$line. '，等级不存在。';
                        continue;
                    }
                    $mcard_member['level_id'] = $level['id'];
                }
                //验证手机号码是否重复
                if($this->account_model->where(array('wid'=>$this->site_info['id'], 'mobile' => $val[1]))->count() > 0) {
                    $error[] = '错误行：'.$line. '，手机号码已存在。';
                    continue;
                }
                //验证卡号
                if($val[3]) {
                    if($this->mcard_member_model->where(array('card_num' => $val[3], 'site_id' => $this->site_info['id']))->count() > 0) {
                        $error[] = '错误行：'.$line. '，会员卡号已存在。';
                        continue;
                    } else {
                        $mcard_member['card_num'] = $val[3];
                    }
                } else {
                    //生成卡号
                    $card_res = $this->mcard_member_model->select('card_num')->where(array('site_id' => $this->site_info['id']))
                        ->order_by('card_num', 'desc')->find();
                    if($card_res) {
                        if(intval($card_res['card_num']) == 2147483647) {
                            $mcard_member['card_num'] = rand(10000000, 99999999);
                        } else {
                            $mcard_member['card_num'] = intval($card_res['card_num']) + 1;
                        }
                    } else {
                        $mcard_member['card_num'] = $mcard['card_num_init'];
                    }
                }
                //写入account
                $uid = $this->account_model->add($account);
                //写入mcard_member
                $mcard_member['uid'] = $uid;
                $this->mcard_member_model->add($mcard_member);

                $csuccess += 1;
            }

            echo json_encode(array('success' => 1, 'csuccess' => $csuccess, 'error' => $error));
            exit;
        }

        $this->load->view($this->dcm, $this->data);
    }

    /**
     * 会员卡绑定设置
     */
    public function bind_setting()
    {
        $this->load->library('Mongo_db');
        //外链地址
        $domain = $this->session->userdata('domain');
        $url = $domain ? "http://".$domain.BASE_DOMAIN."/bind_mcard" : '';
        $this->data['url'] = $url;

        if($this->input->post()) {
            $this->form_validation->set_rules('keyword', '关键词', 'trim|required|htmlspecialchars');
            $this->form_validation->set_rules('title', '回复标题', 'trim|required|htmlspecialchars');

            if($this->form_validation->run()) {
                //如果设置过，则清除原有
                $setting_info = $this->mongo_db->where(array('data_for'=>'member_bind', 'site_id' => $this->site_info['id']))->get_one($this->mongo_reply);
                if($setting_info) {
                    $this->mongo_db->where(array('data_for'=>'member_bind', 'site_id' => $this->site_info['id']))->delete($this->mongo_reply);
                }
                $data['site_id'] = $this->site_info['id'];
                $data['count_match'] = 0;
                $data['keyword']     = array('0' =>$this->input->post('keyword'));
                $data['type']        = 'article';
                $data['data_for']    = 'member_bind';
                $data['content']     = array('0' => array(
                    'id' => (string)new MongoId(),
                    'title' => $this->input->post('title'),
                    'image' => $this->input->post('image'),
                    'url' => $url,
                    'rank' => 0,
                    'type' => 'link'
                ));
                $data['dt_add']     = $data['dt_update'] = time();
                if($this->mongo_db->insert($this->mongo_reply, $data)) {
                    $this->show_message(TRUE, '保存成功', '/c/mcard/bind_setting');
                    return FALSE;
                } else {
                    $this->show_message(FALSE, '保存失败', '');
                    return FALSE;
                }
            } else {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }

        //读取设置过的
        $setting_info = $this->mongo_db->where(array('data_for'=>'member_bind', 'site_id' => $this->site_info['id']))->get_one($this->mongo_reply);
        if(!$setting_info) {
            $this->data['cur_item'] = array(
                'image' => base_url('assets/home/images/bind_mcard.jpg'),
            );
        } else {
            $this->data['cur_item'] = array(
                'image' => $setting_info['content'][0]['image'],
                'keyword' => $setting_info['keyword'][0],
                'title' => $setting_info['content'][0]['title'],
            );
        }

        $this->data['url'] = $url;

        $this->load->view($this->dcm, $this->data);
    }

    /**
     * 会员卡导入格式文件下载
     */
    public function excel_download()
    {
        $fields = array(
            'name'=>'姓名(必填)',
            'mobile'=>'手机号(必填)',
            'level'=>'等级(必填，可填等级名或等级积分)',
            'card_num'=>'会员卡号',
            'money'=>'余额',
            'credit'=>'积分',
            'get_time'=>'领卡时间',
        );
        $memberlist = array('0'=>array(
            'name' => '张三',
            'mobile' => '13899998888',
            'level' => '微巴会员卡',
            'card_num' => '',
            'money' => '',
            'credit' => '',
            'get_time' => '2014/7/2 13:37:00',
        ));
        $this->excel_export('会员卡Excel格式文件', '会员卡列表', $fields, $memberlist);
        exit;
    }

    /**
     * 会员卡统计
     */
    public function statistics()
    {
        $mcard = $this->check_mcard();
        if(!$mcard) {
            return FALSE;
        }

        $this->load->model('mcard_statistics_model');
        $where = array('site_id'=>$this->site_info['id'], 'mcard_id'=>$mcard['id']);
        $total_rows =$this->mcard_statistics_model->where($where)->count();
        $pager = $this->_pager($total_rows);
        $list = $this->mcard_statistics_model->order_by('dt desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->where($where)->find_all();

        $this->data['list'] = $list ? $list : array();
        $this->data['page'] = $pager['links'];
        $this->load->view($this->dcm, $this->data);
    }

    /**
     * 会员卡用户导出
     */
    public function member_export()
    {
        //查询会员卡是否存在
        $mcard = $this->check_mcard();
        if(!$mcard) {
            return FALSE;
        }

        $this->load->model('mcard_member_model');
        $where = array('mcard_member.is_deleted'=>0);
        $like = array();
        ($name = $this->input->get('name')) && $like['account.name'] = $name;
        ($mobile = $this->input->get('mobile')) && $like['account.mobile'] = $mobile;
        ($card_num = $this->input->get('card_num')) && $like['mcard_member.card_num'] = $card_num;
        ($money = $this->input->get('money')) && $like['account.money'] = $money;
        ($credit = $this->input->get('credit')) && $where['account.credit'] = $credit;
        ($from_time = $this->input->get('from_time')) && $where['mcard_member.get_time >='] = strtotime($from_time);
        ($end_time = $this->input->get('to_time')) && $where['mcard_member.get_time <='] = strtotime($end_time);

        $where['mcard_member.site_id'] = $this->site_info['id'];
        $where['mcard_member.mcard_id'] = $mcard['id'];
        $list = $this->mcard_member_model->select('mcard_member.*, account.name, account.mobile, account.money, account.credit, mcard_level.title as level')->join('account', 'account.id = mcard_member.uid', 'left')->join('mcard_level', 'mcard_member.level_id = mcard_level.id', 'left')->order_by('get_time desc')->where($where)->like($like)->find_all();

        $memberlist = array();
        if($list)
        {
            $this->load->library('Mongo_db');
            $field_list = $this->mongo_db->where(array('wid'=>$this->site_info['id']))->order_by(array('sort' => 'ASC'))->get('account_fields');
            $field_list = $field_list ? $field_list : array();

            foreach($list as $key=> $item)
            {
                $memberlist[$key]['name'] = $item['name'];
                $memberlist[$key]['mobile'] = $item['mobile'];
                $memberlist[$key]['card_num'] = $item['card_num'];
                $memberlist[$key]['money'] = $item['money'];
                $memberlist[$key]['credit'] = $item['credit'];
                $memberlist[$key]['get_time'] = date('Y-m-d H:i:s', $item['get_time']);
                $memberlist[$key]['level'] = $item['level'];

                $fv = $this->mongo_db->where(array('wid'=>$this->site_info['id'], 'uid'=>$item['uid']))->get_one('account_field_value');
                foreach($field_list as $field) {
                    $value = isset($fv[(string)$field['_id']]) ? $fv[(string)$field['_id']] : '';
                    $value = is_array($value) ? implode(', ', $value) : $value;
                    $memberlist[$key][(string)$field['_id']] = $value;
                }
            }

            $fields = array(
                '#'=>'#',
                'name'=>'姓名',
                'mobile'=>'手机号',
                'card_num'=>'会员卡号',
                'money'=>'余额',
                'credit'=>'积分',
                'get_time'=>'领卡时间',
                'level'=>'等级'
            );

            foreach($field_list as $field_item) {
                if($field_item['title'] == $fields['name']) {
                    $field_item['title'] = $fields['name']."(扩展)";
                }
                if($field_item['title'] == $fields['mobile']) {
                    $field_item['title'] = $fields['mobile']."(扩展)";
                }
                $fields[(string)$field_item['_id']] = $field_item['title'];
            }

            $this->excel_export('会员卡用户列表', '会员卡用户列表', $fields, $memberlist);
        }
        else
        {
            $this->show_message(FALSE, '尚无会员卡用户可导出', '/c/mcard/member');
        }
    }

    /**
     * 保存备注
     */
    public function member_memo()
    {
        header('Content-type: application/json');
        $memo = $this->input->post('memo');
        $member_id = $this->input->post('member_id');

        $this->load->model('mcard_member_model');
        $member = $this->mcard_member_model->where(array('id'=>$member_id, 'site_id'=>$this->site_info['id']))->find();
        if($member){
            if($this->mcard_member_model->where(array('id'=>$member_id, 'site_id'=>$this->site_info['id']))->edit(array('memo'=>$memo))){
                $data = array();
                $data['success'] = 1;
                $data['member_id'] = $member_id;
                echo json_encode($data);
            }else{
                echo json_encode(array('success'=>0));
            }
        }else{
            echo json_encode(array('success'=>0));
        }
    }

    /**
     * 修改会员卡等级
     */
    public function member_level()
    {
        header('Content-type: application/json');
        $level_id = $this->input->post('level_id');
        $member_id = $this->input->post('member_id');

        $this->load->model('mcard_member_model');
        $member = $this->mcard_member_model->where(array('id'=>$member_id, 'site_id'=>$this->site_info['id']))->find();
        if($member){
            if($this->mcard_member_model->where(array('id'=>$member_id, 'site_id'=>$this->site_info['id']))->edit(array('level_id'=>$level_id, 'level_time'=>time()))){
                $data = array();
                $data['success'] = 1;
                echo json_encode($data);
            }else{
                echo json_encode(array('success'=>0));
            }
        }else{
            echo json_encode(array('success'=>0));
        }
    }
    
    //接口设置
    public function inter_set()
    {
        $this->load->model('mcard_model');
        $mcard = $this->mcard_model->where(array('site_id'=>$this->site_info['id']))->find();
        if( !$mcard ){
            $this->show_message(FALSE, '非法访问', '');
            return FALSE;
        }
        if( $this->input->post() ){
            $this->form_validation->set_rules('inter_set', '接口地址', 'trim|max_length[500]|prep_url');
            if($this->form_validation->run()) {
                $data['inter_set'] = $this->form_validation->set_value('inter_set');
                
                if(!$this->mcard_model->where(array('id'=>$mcard['id'], 'site_id'=>$this->site_info['id']))->edit($data)) {
                    $this->show_message(FALSE, '保存失败', '');
                    return FALSE;
                }else{
                    $this->show_message(FALSE, '保存成功', '/c/mcard/inter_set');
                    return FALSE;
                }
                
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }
        $this->data['mcard'] = $mcard;
        
        $this->load->view($this->dcm, $this->data);
    }

    private function check_mcard()
    {
        $this->load->model('mcard_model');
        $mcard = $this->mcard_model->where(array('site_id'=>$this->site_info['id']))->find();
        if(!$mcard) {
            $this->show_message(FALSE, '会员卡不存在，请先去设置', '');
            return FALSE;
        }
        return $mcard;
    }

    /**
     * 根据积分获取等级信息
     */
    private function get_level_by_credit($mcard_id, $credit)
    {
        //获取按积分范围划分的等级(该积分)
        $this->load->model('mcard_level_model');
        $level = $this->mcard_level_model->where(array('mcard_id'=>$mcard_id, 'site_id'=>$this->site_info['id'], 'conditions'=>2, 'status'=>1, 'minpoints <= '=>$credit))->order_by('minpoints', 'desc')->find();

        if(!$level) {
            $level = $this->mcard_level_model->where(array('site_id'=>$this->site_info['id'], 'basic'=>1, 'mcard_id'=>$mcard_id))->find();
        }
        return $level;
    }

    /**
     * 删除会员卡用户
     */
    public function member_delete($id)
    {
        $this->load->model('mcard_member_model');
        $member = $this->mcard_member_model->where(array('id'=>$id, 'site_id'=>$this->site_info['id']))->find();
        if( !$member ){
            $this->show_message(false, '没有该会员用户', 1);
        }

        if( false === $this->mcard_member_model->where(array('id'=>$id, 'site_id'=>$this->site_info['id']))->edit( array('is_deleted'=>1) ) ){
            $this->show_message(false, '删除失败', '/c/mcard/member');
        }else{
            $this->show_message(true, '删除成功', '/c/mcard/member');
        }
    }
}