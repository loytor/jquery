<?php
/**
 * Created by PhpStorm.
 * User: along
 * Date: 13-12-9
 * Time: 下午4:35
 * @property Dishes_cate_model $dishes_cate_model
 * @property Waimai_dishes_model $waimai_dishes_model
 */
class Dishes2 extends C_Controller
{
    protected $auto_load_model = TRUE;
    protected $model_name = 'dishes';


    public function __construct()
    {
        parent::__construct();
        //$this->load->library('Mongo_db');
        //所有分类
        $this->load->model('dishes_cate_model');
        $this->cateList = $this->dishes_cate_model->where(array('site_id'=>$this->site_info['id']))->find_all();
    }

    public function index()
    {
        $where = array();
        $where['site_id'] = $this->site_info['id'];

        $search = array();
        $search['cate_id'] = $this->input->get('cate_id',true);
        $search['keyword'] = $this->input->get('keyword',true);
        $this->data['search'] = $search;
        $search_url = site_url($this->uri->uri_string().'?'.http_build_query($search));
        $search['cate_id'] && $where['cid'] = $search['cate_id'];

        $this->model->where($where);
        if( $search['keyword'] ){
            $this->model->like('title',$search['keyword']);
        }
        $total_rows = $this->model->count();
        $pager = $this->_pager($total_rows, array('per_page'=>5,'base_url'=>$search_url));
        $this->model->where($where);
        if( $search['keyword'] ){
            $this->model->like('title',$search['keyword']);
        }
        $list = $this->model
            ->order_by('id desc')
            ->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->find_all();
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->data['list'] = $list;
        //分类
        $catelist = array();

        if($this->cateList){
            foreach($this->cateList as $clist){
                $catelist[$clist['id']] = $clist;
            }
        }
        $this->data['catelist'] = $catelist;

        $this->load->view($this->dcm,$this->data);
    }

    /**
     * 增加菜品
     */
    public function add()
    {
        $post = $this->input->post();
        if($post)
        {
            $dataSet = $this->dataPost($post);
            if(is_array($dataSet))
            {
                $dataSet['site_id'] = $this->site_info['id'];
                $dataSet['inputtime'] = time();

                if( !$id=$this->model->add($dataSet) )
                {
                    $this->show_message(false, '添加失败', '');
                    return FALSE;
                }
                else
                {
                    $this->show_message(true, '添加成功', '/c/dishes2');
                    return FALSE;
                }
            }
            else
            {
                $this->show_message(false,$dataSet,'');
                return false;
            }
        }
        $this->data['catelist'] = $this->cateList;

        $this->load->view($this->dcm,$this->data);
    }

    /**
     * @name 编辑菜品
     * @param $id
     * @return bool
     */
    public function edit($id)
    {
        if(!$id)
        {
            $this->show_message(false, '非法参数', 1);return false;
        }
        $dishes = $this->model->where(array('id'=>$id,'site_id'=>$this->site_info['id']))->find();
        if(!$dishes)
        {
            $this->show_message(false, '菜品不存在', 1);return false;
        }
        $post = $this->input->post();
        if ($post)
        {
            $postData = $this->dataPost($post);
            if(!is_array($postData))
            {
                $this->show_message(false,$postData,'');
                return false;
            }

            if(false === $this->model->where(array('id'=>$id, 'site_id'=>$this->site_info['id']))->edit( $postData ) )
            {
                $this->show_message(false, '编辑失败', '/c/dishes2/edit/'.$id);
            }
            else
            {
                $this->show_message(false, '编辑成功', '/c/dishes2/edit/'.$id);
            }

        }
        else
        {
            $this->data['dishes'] = $dishes;
            $this->data['catelist'] = $this->cateList;
            $this->load->view($this->dcm,$this->data);
        }
    }

    public function cate()
    {
        $where = array();
        $where['site_id'] = $this->site_info['id'];

        $total_rows = $this->dishes_cate_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>10));
        $list = $this->dishes_cate_model->order_by('id desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->where($where)->find_all();

        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->data['list'] = $list;
        $this->load->view($this->dcm,$this->data);
    }

    public function cate_add()
    {
        $dataSet['title'] = $this->input->post('title');
        if($dataSet['title'])
        {
            $dataSet['site_id'] = $this->site_info['id'];
            $dataSet['inputtime'] = time();
            if( !$id=$this->dishes_cate_model->add($dataSet) )
            {
                $this->show_message(false, '添加失败', '');
                return FALSE;
            }
            else
            {
                $this->show_message(true, '添加成功', '/c/dishes2/cate');
                return FALSE;
            }
        }
        else
        {
            $this->load->view($this->dcm,$this->data);
        }
    }

    public function cate_edit($id)
    {
        if(!$id)
        {
            $this->show_message(false, '非法参数', 1);return false;
        }
        $cate = $this->dishes_cate_model->where(array('id'=>$id,'site_id'=>$this->site_info['id']))->find();
        if(!$cate)
        {
            $this->show_message(false, '分类不存在', 1);return false;
        }
        $postData['title'] = $this->input->post('title');

        if($postData['title'] && $postData['title'] != $cate['title'])
        {
            if(false === $this->dishes_cate_model->where(array('id'=>$id, 'site_id'=>$this->site_info['id']))->edit( $postData ) )
            {
                $this->show_message(false, '编辑失败', '/c/dishes2/cate_edit/'.$id);
            }
            else
            {
                $this->show_message(false, '编辑成功', '/c/dishes2/cate');
            }
        }
        else
        {
            $this->data['cate'] = $cate;
            $this->load->view($this->dcm,$this->data);
        }
    }

    /**
     * 删除菜品分类
     * @param $id
     * @return bool
     */
    public function cateDelete($id)
    {
        if(!$id)
        {
            $this->show_message(false, '非法参数', 1);return false;
        }
        $cate = $this->dishes_cate_model->where(array('id'=>$id,'site_id'=>$this->site_info['id']))->find();
        if(!$cate)
        {
            $this->show_message(false, '分类不存在', '/c/dishes2/cate');return false;
        }
        //分类下是否有菜品
        $dishes = $this->model->where(array('cid'=>$id,'site_id'=>$this->site_info['id']))->find();
        if($dishes)
        {
            $this->show_message(false, '该分类下已有菜品，不能删除', '/c/dishes2/cate');return false;
        }
        $this->dishes_cate_model->where(array('id'=>$id,'site_id'=>$this->site_info['id']))->delete();
        $this->show_message(true, '分类删除成功!', '/c/dishes2/cate');return false;
    }


    public function delete($id)
    {
        if(!$id)
        {
            $this->show_message(false, '非法参数', '/c/dishes2/index');return false;
        }
        $dishes = $this->model->where(array('id'=>$id,'site_id'=>$this->site_info['id']))->find();
        if(!$dishes)
        {
            $this->show_message(false, '菜品不存在', '/c/dishes2/index');return false;
        }
        //门店下是否已经选了该菜品
        $this->load->model('waimai_dishes_model');

        $storeDishes = $this->waimai_dishes_model->where(array('dishes_id'=>$id,'site_id'=>$this->site_info['id']))->find();

        if($storeDishes)
        {
            $this->show_message(false, '外卖已使用该菜品，不能删除', '/c/dishes2/index');return false;
        }
        $this->model->where(array('id'=>$id,'site_id'=>$this->site_info['id']))->delete();
        $this->show_message(true, '删除成功!', '/c/dishes2/index');return false;
    }

    /**
     * @name 检查图片格式
     * @param $image
     * @return bool
     */
    public function _check_image($image) {
        if ($image) {
            if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
                $this->form_validation->set_message('_check_image', '图片地址格式错误');
                return FALSE;
            }
        }
        return TRUE;
    }

    /**
     * 处理留言post请求
     */
    private function dataPost($post)
    {
        if(is_array($post))
        {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('title', '菜品名称', 'trim|required|max_length[100]|htmlspecialchars');
            $this->form_validation->set_rules('pic', '菜品图片', 'trim|required|callback__check_image');
            $this->form_validation->set_rules('description', '菜品描述', 'trim|required|htmlspecialchars');
            $this->form_validation->set_rules('price', '价格', 'trim|htmlspecialchars');

            if ( $this->form_validation->run() )
            {
                $dataSet['title'] = $this->form_validation->set_value('title');
                $dataSet['cid'] = $post['cid'];
                    //图片
                $dataSet['pic'] = $this->form_validation->set_value('pic');
                $dataSet['description'] = $this->form_validation->set_value('description');
                $dataSet['price'] = $this->form_validation->set_value('price');

                return $dataSet;
            }
            else
            {
                $errors = validation_errors();

                if ($errors) {
                    return $errors;
                }
            }
        }
    }

}