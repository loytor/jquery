<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: 111
 * Date: 13-12-19
 * Time: 下午5:16
 */
class Common extends C_Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    public function appcall_item()
    {
        $type = $this->input->get('type');
        $this->load->library('Appcall/'.$type, NULL, 'bclass');
        $params = $this->input->get();
        $query_arr = array();
        foreach($params as $k=>$p) {
            if($k != 'page') {
                $query_arr[] = $k.'='.$p;
            }
        }

        $query_string = implode('&', $query_arr);
        $pager = $this->_pager($this->bclass->get_count($params), array('base_url' => site_url($this->uri->uri_string().'?').$query_string));
        $params['per_page'] = $pager['limit']['value'];
        $params['offset'] = $pager['limit']['offset'];
        $list = $this->bclass->get_list($params);
        if(method_exists($this->bclass, 'get_filter_list')){
            $this->data['filter_list'] = $this->bclass->get_filter_list();
        }
        if(method_exists($this->bclass, 'get_info')){
            $this->data['info'] = $this->bclass->get_info();
        }
        $this->data['page'] = $pager['links'];
        if(isset($params['type']) && $params['type'] != $type) {
            unset($params['cur_url']);
            unset($params['cur_ref_id']);
            unset($params['cur_type']);
        }
        $this->data['params'] = $params;
        $this->data['keyword'] = $this->input->get('keyword');
        $this->data['list'] = $list;
        $this->dcm = 'c/appcall/'.strtolower($type);
        $this->load->view($this->dcm, $this->data);
    }
}