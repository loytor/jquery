<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 渠道指标管理
 */
class Panorama_hp extends C_Controller {

    protected $data = '';
    private $site_id = '';

    public function __construct()
    {
        parent::__construct();
        $this->site_id = $this->site_info['id'];
        
        $this->load->model('panorama_model');
    }

    public function index()
    {
    	 $where['type'] = '0';
    	$total_rows = $this->panorama_model->where($where)->find_all();
		$dom = 'http://c'.BASE_DOMAIN;
        $this->data['list'] = $dom;
        $this->load->view($this->dcm,$this->data);
    }
    public function photo()
    {
    	$where['type'] = '0';
    	$total_rows = $this->panorama_model->where($where)->find_all();
		$dom = 'http://c'.BASE_DOMAIN;
        $this->data['list'] = $dom;
        $this->load->view($this->dcm,$this->data);

    }
    public function up()
    {
    	$where['type'] = '0';
    	$total_rows = $this->panorama_model->where($where)->find_all();
		$dom = 'http://c'.BASE_DOMAIN;
        $this->data['list'] = $dom;
        $this->load->view($this->dcm,$this->data);

    }
    public function assemble()
    {
		$this->data['list'] = "sdsdsdd";
        $this->load->view($this->dcm,$this->data);

    }
    public function asseadd()
    {
		$this->data['list'] = "sdsdsdd";
        $this->load->view($this->dcm,$this->data);

    }
}