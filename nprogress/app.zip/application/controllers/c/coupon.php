<?php
/**
 * 优惠券
 */
class Coupon extends C_Controller {

    protected $auto_load_model = TRUE;
    protected $model_name = 'coupon_config';
    
    protected $data = '';
    
    private $site_id = '';
    
    public function __construct()
    {
        parent::__construct();
        $this->site_id = $this->site_info['id'];
        
        $this->load->model('coupon_model');
        $this->load->model('coupon_record_model');
        
        //检索时间过期的优惠券 直接下线  优惠券被领完也下线(`grant_num`>0 and `grant_num`-`has_grant_num`<=0) OR 
        $this->db->query("UPDATE `weixin`.`coupon` set `online`=2 WHERE `site_id`='".$this->site_id."' AND ((`end_time`<".time()."))");
        
        //赠送的24小时后过期
        $this->coupon_record_model->update(array('site_id'=>$this->site_id,'to_forward'=>-1,'to_time <'=>(time()-24*3600)),array('to_forward'=>0,'to_time'=>0));   
              
    }
    
    public function index()
    {
        $coupon = $this->get_config();
        $base_url = '';
        if( $this->data['coupon'] ){
            $base_url = 'http://'.$this->site_info['domain'].BASE_DOMAIN.'/coupons';
            
            if( $this->data['coupon']['type']==1 ){
                $this->data['coupon']['required_fields'] = explode(',', $this->data['coupon']['required_fields']);
            }
        }

        $this->data['base_url'] = $base_url;
        
        if( $this->input->post() ){
            $this->form_validation->set_rules('title', '优惠券标题', 'trim|required|max_length[6]');
            $this->form_validation->set_rules('status', '是否开启', 'trim|required|intval');
            $this->form_validation->set_rules('title_img', '优惠券标题图', 'trim|required|callback__check_image');
            $this->form_validation->set_rules('type', '领取条件', 'trim|required|intval');
            $this->form_validation->set_rules('donation', '转赠', 'trim|required|intval');
            $this->form_validation->set_rules('required_mobile', '手机', 'trim|intval');
            $this->form_validation->set_rules('required_name', '姓名', 'trim|intval');
            $this->form_validation->set_rules('intro', '使用说明', 'trim|max_length[5000]|htmlspecialchars');

            $this->form_validation->set_rules('reply_keyword', '回复关键词', 'trim|max_length[20]');
            $this->form_validation->set_rules('reply_title', '回复标题', 'trim|max_length[50]');
            $this->form_validation->set_rules('reply_image', '回复图标', 'trim|callback__check_image');
            
            if ( $this->form_validation->run() ){
                
                $save_data['status'] = $this->form_validation->set_value('status');
                $save_data['title'] = $this->form_validation->set_value('title');
                $save_data['title_img'] = $this->form_validation->set_value('title_img');
                $save_data['type'] = $this->form_validation->set_value('type');
                $save_data['donation'] = $this->form_validation->set_value('donation');
                $save_data['intro'] = $this->form_validation->set_value('intro');

                $save_data['reply_keyword'] = $this->form_validation->set_value('reply_keyword');
                $save_data['reply_title'] = $this->form_validation->set_value('reply_title');
                $save_data['reply_image'] = $this->form_validation->set_value('reply_image');
                
                if( $save_data['type']==1 ){
                    //完善信息部分
                    $required_name = intval($this->input->post('required_name'));
                    $save_data['required_name'] = $required_name;
                    $required_mobile = intval($this->input->post('required_mobile'));
                    $save_data['required_mobile'] = $required_mobile;
                    $required_fields = $this->input->post('required_fields') ? $this->input->post('required_fields') : array();
                    $save_data['required_fields'] = implode(',', $required_fields);
                    if( !$required_name&&!$required_mobile&&!$save_data['required_fields'] ){
                        $this->show_message(false, '请选择需完善信息项', '',1);return FALSE;
                    }
                }
                
                $save_data['site_id'] = $this->site_id;

                if( $save_data['reply_keyword'] ){
                    if( !$save_data['reply_title']&&!$save_data['reply_image'] ){
                        $this->show_message(false, '请填写回复标题和回复图标', '',1);return FALSE;
                    }
                }
                
                if( $this->data['coupon'] ){
                    if( $this->model->where(array('site_id'=>$this->site_id))->edit($save_data) ){
                        $this->show_message(true, '保存成功', '/c/coupon/index');return FALSE;
                    }else{
                        $this->show_message(false, '保存失败', '/c/coupon/index');return FALSE;
                    }
                }else{//添加
                    $save_data['add_time'] = time();
                    if( $this->model->add($save_data) ){
                        $this->show_message(true, '保存成功', '/c/coupon/index');return FALSE;
                    }else{
                        $this->show_message(false, '保存失败', '/c/coupon/index');return FALSE;
                    }
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            //需完善信息项
            $this->load->library('Mongo_db');
            $field_list = $this->mongo_db->where(array('wid'=>$this->site_info['id']))->order_by(array('sort', 'ASC'))->get('account_fields');
            $this->data['field_list'] = $field_list;
            
            //获取模版
            $this->load->config('tpl');
            $config_tpl = $this->config->item('coupon_tpl');
            $this->data['coupon_tpl'] = $config_tpl;
            
            $this->load->view($this->dcm, $this->data);
        }
    }
    
    //优惠券列表
    public function quan_list()
    {
        $where['site_id'] = $this->site_id;
        $where['is_delete'] = 0;
        $search_url = site_url($this->uri->uri_string().'?');
        $is_search = 0;
        $search['status'] = $this->input->get('status');
        $search['keyword'] = $this->input->get('keyword');

        if( $search ){
            if( $search['status'] ){
                $is_search = 1;
                if( $search['status']==1 ){//未上线
                    $where['online'] = 0;
                }else if( $search['status']==2 ){
                    $where['online'] = 1;
                }else if( $search['status']==3 ){//已下线
                    $where['online'] = 2;
                }
            }
            $search['keyword'] ? $where['name like '] = "%{$search['keyword']}%" : '';
        }
        $search_url = site_url($this->uri->uri_string().'?');
        $base_url = $search_url.http_build_query($search);
        $this->data['search'] = $search;
        
        

        
        $total_rows = $this->coupon_model->where($where)->count();
        $pager = $this->_pager($total_rows,array('per_page'=>15,'base_url'=>$base_url));
        $list = $this->coupon_model->select('*')->limit($pager['limit']['value'], $pager['limit']['offset'])
                ->where($where)->order_by('sort asc,id desc')->find_all();
        
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        
        $this->load->view($this->dcm, $this->data);
    }
    
    //改排序值
    public function coupon_sort()
    {
        $ids = $this->input->get_post('a');
        $values = $this->input->get_post('b');
        
        if( $ids&&$values ){
            foreach( $ids as $key=>$val ){
                $this->coupon_model->where(array('site_id' => $this->site_id,'id' => $val,'is_delete'=>0))->edit(array('sort'=>$values[$key]));
            }
        }
        echo json_encode(array(
            'success' => 1
        ));
    }
    
    //添加优惠券
    public function quan_add()
    {
        $this->data['left_menu_active'] = 'coupon/quan_list';
        
        if( $this->input->post() ){
            $this->form_validation->set_rules('name', '优惠券名称', 'trim|required|max_length[14]');
            $this->form_validation->set_rules('img', '图标', 'trim|callback__check_image');
            $this->form_validation->set_rules('use_type', '使用方式', 'required|intval|is_natural|less_than_equal_to[3]');
            $this->form_validation->set_rules('coupon_type', '优惠类型', 'required|intval|is_natural|less_than_equal_to[4]');
            $this->form_validation->set_rules('start_time', '开始时间', 'trim|required|max_length[20]');
            $this->form_validation->set_rules('end_time', '结束时间', 'trim|required|max_length[20]');
            $this->form_validation->set_rules('accept_end_time', '领取截止时间', 'trim|max_length[20]');
            $this->form_validation->set_rules('receive_type', '优惠券价格', 'required|intval|is_natural|less_than_equal_to[3]');
            $this->form_validation->set_rules('grant_num', '发放数量', 'intval|is_natural');
            $this->form_validation->set_rules('receive_num', '领取次数', 'intval|is_natural');
            $this->form_validation->set_rules('sort', '排序', 'intval|is_natural');
            
            $this->form_validation->set_rules('intro', '优惠券描述', 'trim|required|max_length[5000]|htmlspecialchars');
            if ( $this->form_validation->run() ){
                
                $save_data['name'] = $this->form_validation->set_value('name');
                $save_data['img'] = $this->form_validation->set_value('img');
                $save_data['use_type'] = $this->form_validation->set_value('use_type');
                $save_data['coupon_type'] = $this->form_validation->set_value('coupon_type');
                if( $save_data['coupon_type']==1 ){//价格优惠
                    $save_data['coupon_rule'] = trim($this->input->post('coupon_rule1',true));//现价
                    $save_data['coupon_rule1'] = trim($this->input->post('coupon_rule11',true));//原价
                    if( $save_data['coupon_rule1'] ){
                        if( (bool) preg_match('/^[0-9]+[.]?[0-9]{0,2}$/', $save_data['coupon_rule1']) ){
                        }else{
                            $this->show_message(false, '请填写正确的价格', '',1);return FALSE;
                        }
                    }/*else{
                        $this->show_message(false, '请填写产品原价', '',1);return FALSE;
                    }*/
                    if( $save_data['coupon_rule'] ){
                        if( (bool) preg_match('/^[0-9]+[.]?[0-9]{0,2}$/', $save_data['coupon_rule']) ){
                        }else{
                            $this->show_message(false, '请填写正确的价格', '',1);return FALSE;
                        }
                    }else{
                        $this->show_message(false, '请填写优惠后的价格', '',1);return FALSE;
                    }
                }else if( $save_data['coupon_type']==2 ){//打折优惠
                    $save_data['coupon_rule'] = trim($this->input->post('coupon_rule2',true));
                    if( $save_data['coupon_rule'] ){
                        if( (bool) preg_match('/^[0-9]+[.]?[0-9]{0,2}$/', $save_data['coupon_rule']) ){
                        }else{
                            $this->show_message(false, '请填写正确的折扣信息', '',1);return FALSE;
                        }
                    }else{
                        $this->show_message(false, '请填写折扣', '',1);return FALSE;
                    }
                }else if( $save_data['coupon_type']==3 ){//抵用现金
                    $save_data['coupon_rule'] = trim($this->input->post('coupon_rule3',true));
                    $save_data['coupon_rule1'] = trim($this->input->post('coupon_rule31',true));
                    if( $save_data['coupon_rule1'] ){
                        if( (bool) preg_match('/^[0-9]+[.]?[0-9]{0,2}$/', $save_data['coupon_rule1']) ){
                        }else{
                            $this->show_message(false, '请填写消费金额', '',1);return FALSE;
                        }
                    }/*else{
                        $this->show_message(false, '请填写抵用金额', '',1);return FALSE;
                    }*/
                    if( $save_data['coupon_rule'] ){
                        if( (bool) preg_match('/^[0-9]+[.]?[0-9]{0,2}$/', $save_data['coupon_rule']) ){
                        }else{
                            $this->show_message(false, '请填写正确的抵用金额', '',1);return FALSE;
                        }
                    }else{
                        $this->show_message(false, '请填写抵用金额', '',1);return FALSE;
                    }
                }else if( $save_data['coupon_type']==4 ){//其他优惠
                    $save_data['coupon_rule'] = trim($this->input->post('coupon_rule4',true));
                    if( $save_data['coupon_rule'] ){
                        if( mb_strlen($save_data['coupon_rule'])>10 ){
                            $this->show_message(false, '优惠信息不能超过10个字', '',1);return FALSE;
                        }
                    }
                }
                
                $save_data['address_ids'] = '';
                $address_ids = $this->input->post('address_ids',true);
                if( $address_ids ){
                    $save_data['address_ids'] = implode(',', $address_ids);
                }else{
                    $this->show_message(false, '请选择适用店铺', '',1);return FALSE;
                }
                
                $save_data['start_time'] = $this->form_validation->set_value('start_time');
                $save_data['end_time'] = $this->form_validation->set_value('end_time');
                if( strtotime($save_data['start_time']) ){
                    $save_data['start_time'] = strtotime($save_data['start_time']);
                }else{
                    $this->show_message(false, '开始时间格式非法', '',1);return FALSE;
                }
                if( strtotime($save_data['end_time']) ){
                    $save_data['end_time'] = strtotime($save_data['end_time']);
                }else{
                    $this->show_message(false, '结束时间格式非法', '',1);return FALSE;
                }
                if( intval($save_data['start_time'])>=intval($save_data['end_time']) ){
                    $this->show_message(false, '开始时间必须小于结束时间', '',1);return FALSE;
                }
                $save_data['accept_end_time'] = strtotime($this->form_validation->set_value('accept_end_time'));
                
                //优惠券价格
                $save_data['receive_type'] = $this->form_validation->set_value('receive_type');
                if( $save_data['receive_type']==1 ){//免费
                    $save_data['receive_content'] = 0;
                }else if( $save_data['receive_type']==2 ){//扣积分
                    $save_data['receive_content'] = $this->input->post('receive_content1');
                    if( $save_data['receive_content'] ){
                        if( (bool) preg_match('/^[1-9]?[0-9]+$/', $save_data['receive_content']) ){
                        }else{
                            $this->show_message(false, '请填写正确的积分数', '',1);return FALSE;
                        }
                    }else{
                        $this->show_message(false, '请填写所需积分数', '',1);return FALSE;
                    }
                }else if( $save_data['receive_type']==3 ){//需金额
                    $save_data['receive_content'] = $this->input->post('receive_content2');
                    if( $save_data['receive_content'] ){
                        if( (bool) preg_match('/^[0-9]+[.]?[0-9]{0,2}$/', $save_data['receive_content']) ){
                        }else{
                            $this->show_message(false, '请填写正确的金额', '',1);return FALSE;
                        }
                    }else{
                        $this->show_message(false, '请填写所需金额', '',1);return FALSE;
                    }
                }
                
                $save_data['grant_num'] = $this->form_validation->set_value('grant_num');
                $save_data['receive_num'] = $this->form_validation->set_value('receive_num');
                
                $save_data['sort'] = $this->form_validation->set_value('sort',255);
                $save_data['intro'] = $this->form_validation->set_value('intro');
                
                $save_data['site_id'] = $this->site_id;
                $save_data['add_time'] = time();
                
                if( $coupon_id=$this->coupon_model->add($save_data) ){
                    $this->show_message(true, '添加成功', '/c/coupon/quan_list');return FALSE;
                }else{
                    $this->show_message(false, '添加失败', '/c/coupon/quan_list');return FALSE;
                }
                
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            if( !$this->address() ){//地址列表
                $this->show_message(false, '请先设置门店', '/c/coupon/quan_list');return FALSE;
            }
            
            $this->load->view($this->dcm, $this->data);
        }
    }
     
    //优惠券编辑
    public function quan_edit($id='')
    {
        $this->data['left_menu_active'] = 'coupon/quan_list';
        
        //优惠券搜索条件
        $where = array(
            'site_id' => $this->site_id,
            'id' => $id,
            'is_delete'=>0
        );
        $coupon = $this->coupon_model->where($where)->find();
        if( !$coupon ){
            $this->show_message(false, '非法操作', '/c/coupon/quan_list');return FALSE;
        }
        $is_edit = 0;
        if( $coupon['online']==0 ){
            $is_edit = $this->input->get('edit');
        }
        if( $this->input->post() ){
            if( $is_edit==0 ){
                return $this->show_message(false, '无效操作', '',1);
            }
            $this->form_validation->set_rules('name', '优惠券名称', 'trim|required|max_length[14]');
            $this->form_validation->set_rules('img', '图标', 'trim|callback__check_image');
            $this->form_validation->set_rules('use_type', '使用方式', 'required|intval|is_natural|less_than_equal_to[3]');
            $this->form_validation->set_rules('coupon_type', '优惠类型', 'required|intval|is_natural|less_than_equal_to[4]');
            $this->form_validation->set_rules('start_time', '开始时间', 'trim|required|max_length[20]');
            $this->form_validation->set_rules('end_time', '结束时间', 'trim|required|max_length[20]');
            $this->form_validation->set_rules('accept_end_time', '领取截止时间', 'trim|max_length[20]');
            $this->form_validation->set_rules('receive_type', '优惠券价格', 'required|intval|is_natural|less_than_equal_to[3]');
            $this->form_validation->set_rules('grant_num', '发放数量', 'intval|is_natural');
            $this->form_validation->set_rules('receive_num', '领取次数', 'intval|is_natural');
            $this->form_validation->set_rules('sort', '排序', 'intval|is_natural');

            $this->form_validation->set_rules('intro', '优惠券描述', 'trim|required|max_length[5000]|htmlspecialchars');
            if ( $this->form_validation->run() ){
                $save_data['name'] = $this->form_validation->set_value('name');
                $save_data['img'] = $this->form_validation->set_value('img');
                $save_data['use_type'] = $this->form_validation->set_value('use_type');
                $save_data['coupon_type'] = $this->form_validation->set_value('coupon_type');
                if( $save_data['coupon_type']==1 ){//价格优惠
                    $save_data['coupon_rule'] = trim($this->input->post('coupon_rule1',true));//现价
                    $save_data['coupon_rule1'] = trim($this->input->post('coupon_rule11',true));//原价
                    if( $save_data['coupon_rule1'] ){
                        if( (bool) preg_match('/^[0-9]+[.]?[0-9]{0,2}$/', $save_data['coupon_rule1']) ){
                        }else{
                            $this->show_message(false, '请填写正确的价格', '',1);return FALSE;
                        }
                    }/*else{
                        $this->show_message(false, '请填写产品原价', '',1);return FALSE;
                    }*/
                    if( $save_data['coupon_rule'] ){
                        if( (bool) preg_match('/^[0-9]+[.]?[0-9]{0,2}$/', $save_data['coupon_rule']) ){
                        }else{
                            $this->show_message(false, '请填写正确的价格', '',1);return FALSE;
                        }
                    }else{
                        $this->show_message(false, '请填写优惠后的价格', '',1);return FALSE;
                    }
                }else if( $save_data['coupon_type']==2 ){//打折优惠
                    $save_data['coupon_rule'] = trim($this->input->post('coupon_rule2',true));
                    if( $save_data['coupon_rule'] ){
                        if( (bool) preg_match('/^[0-9]+[.]?[0-9]{0,2}$/', $save_data['coupon_rule']) ){
                        }else{
                            $this->show_message(false, '请填写正确的折扣信息', '',1);return FALSE;
                        }
                    }else{
                        $this->show_message(false, '请填写折扣', '',1);return FALSE;
                    }
                }else if( $save_data['coupon_type']==3 ){//抵用现金
                    $save_data['coupon_rule'] = trim($this->input->post('coupon_rule3',true));
                    $save_data['coupon_rule1'] = trim($this->input->post('coupon_rule31',true));
                    if( $save_data['coupon_rule1'] ){
                        if( (bool) preg_match('/^[0-9]+[.]?[0-9]{0,2}$/', $save_data['coupon_rule1']) ){
                        }else{
                            $this->show_message(false, '请填写消费金额', '',1);return FALSE;
                        }
                    }/*else{
                        $this->show_message(false, '请填写抵用金额', '',1);return FALSE;
                    }*/
                    if( $save_data['coupon_rule'] ){
                        if( (bool) preg_match('/^[0-9]+[.]?[0-9]{0,2}$/', $save_data['coupon_rule']) ){
                        }else{
                            $this->show_message(false, '请填写正确的抵用金额', '',1);return FALSE;
                        }
                    }else{
                        $this->show_message(false, '请填写抵用金额', '',1);return FALSE;
                    }
                }else if( $save_data['coupon_type']==4 ){//其他优惠
                    $save_data['coupon_rule'] = trim($this->input->post('coupon_rule4',true));
                    if( $save_data['coupon_rule'] ){
                        if( mb_strlen($save_data['coupon_rule'])>10 ){
                            $this->show_message(false, '优惠信息不能超过10个字', '',1);return FALSE;
                        }
                    }
                }

                $save_data['address_ids'] = '';
                $address_ids = $this->input->post('address_ids',true);
                if( $address_ids ){
                    $save_data['address_ids'] = implode(',', $address_ids);
                }else{
                    $this->show_message(false, '请选择适用店铺', '',1);return FALSE;
                }

                $save_data['start_time'] = $this->form_validation->set_value('start_time');
                $save_data['end_time'] = $this->form_validation->set_value('end_time');
                if( strtotime($save_data['start_time']) ){
                    $save_data['start_time'] = strtotime($save_data['start_time']);
                }else{
                    $this->show_message(false, '开始时间格式非法', '',1);return FALSE;
                }
                if( strtotime($save_data['end_time']) ){
                    $save_data['end_time'] = strtotime($save_data['end_time']);
                }else{
                    $this->show_message(false, '结束时间格式非法', '',1);return FALSE;
                }
                if( intval($save_data['start_time'])>=intval($save_data['end_time']) ){
                    $this->show_message(false, '开始时间必须小于结束时间', '',1);return FALSE;
                }
                $save_data['accept_end_time'] = strtotime($this->form_validation->set_value('accept_end_time'));

                //优惠券价格
                $save_data['receive_type'] = $this->form_validation->set_value('receive_type');
                if( $save_data['receive_type']==1 ){//免费
                    $save_data['receive_content'] = 0;
                }else if( $save_data['receive_type']==2 ){//扣积分
                    $save_data['receive_content'] = $this->input->post('receive_content1');
                    if( $save_data['receive_content'] ){
                        if( (bool) preg_match('/^[1-9]?[0-9]+$/', $save_data['receive_content']) ){
                        }else{
                            $this->show_message(false, '请填写正确的积分数', '',1);return FALSE;
                        }
                    }else{
                        $this->show_message(false, '请填写所需积分数', '',1);return FALSE;
                    }
                }else if( $save_data['receive_type']==3 ){//需金额
                    $save_data['receive_content'] = $this->input->post('receive_content2');
                    if( $save_data['receive_content'] ){
                        if( (bool) preg_match('/^[0-9]+[.]?[0-9]{0,2}$/', $save_data['receive_content']) ){
                        }else{
                            $this->show_message(false, '请填写正确的金额', '',1);return FALSE;
                        }
                    }else{
                        $this->show_message(false, '请填写所需金额', '',1);return FALSE;
                    }
                }

                $save_data['grant_num'] = $this->form_validation->set_value('grant_num');
                $save_data['receive_num'] = $this->form_validation->set_value('receive_num');

                $save_data['sort'] = $this->form_validation->set_value('sort',255);
                $save_data['intro'] = $this->form_validation->set_value('intro');

                $save_data['site_id'] = $this->site_id;
                
                if( $this->coupon_model->where($where)->edit($save_data) ){
                    $this->show_message(true, '修改成功', '/c/coupon/quan_list');return FALSE;
                }else{
                    $this->show_message(false, '修改失败', '/c/coupon/quan_list');return FALSE;
                }
                
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            if( !$this->address() ){//地址列表
                $this->show_message(false, '请先设置门店', '/c/coupon/quan_list');return FALSE;
            }
            
            $coupon['address_id'] = explode(',', $coupon['address_ids']);
            $this->data['coupon'] = $coupon;
            if( $is_edit ){
                $this->load->view($this->dcm.'_edit', $this->data);
            }else{
                $this->load->view($this->dcm, $this->data);
            }
        }
    }
    
    //上线  下线
    public function quan_line($id='')
    {
        //优惠券搜索条件
        $where = array(
            'site_id' => $this->site_id,
            'id' => $id,
            'is_delete'=>0

        );
        $coupon = $this->coupon_model->where($where)->find();
        if( !$coupon ){
            $this->show_message(false, '非法操作', '/c/coupon/quan_list');return FALSE;
        }
        
        if( $coupon['online']==0 ){
            $save_data['online'] = 1;
        }else if( $coupon['online']==1 ){
            $save_data['online'] = 2;
        }else if( $coupon['online']==2 ){
            if( time()<$coupon['end_time'] ){
                $save_data['online'] = 1;
            }else{
                $this->show_message(false, '非法操作', '/c/coupon/quan_list');return FALSE;
            }
        }else{
            $this->show_message(false, '非法操作', '/c/coupon/quan_list');return FALSE;
        }
        if( $this->coupon_model->where($where)->edit($save_data) ){
            $this->show_message(true, '修改成功', '/c/coupon/quan_list');return FALSE;
        }else{
            $this->show_message(false, '修改失败', '/c/coupon/quan_list');return FALSE;
        }
    }
    
    //删除优惠券
    public function quan_delete($id='')
    {
        //优惠券搜索条件
        $where = array(
            'site_id' => $this->site_id,
            'id' => $id,
            'is_delete'=>0
        );
        $coupon = $this->coupon_model->where($where)->find();
        if( !$coupon ){
            $this->show_message(false, '非法操作', '/c/coupon/quan_list');return FALSE;
        }
        if( $coupon['online']==2&&(time()>$coupon['end_time']) ){
            if( $this->coupon_model->where($where)->edit(array('is_delete'=>1)) ){
                $this->show_message(true, '修改成功', '/c/coupon/quan_list');return FALSE;
            }else{
                $this->show_message(false, '修改失败', '/c/coupon/quan_list');return FALSE;
            }
        }else{
            $this->show_message(false, '不符合删除条件', '/c/coupon/quan_list');return FALSE;
        }
    }
    
    //单个优惠券的历史流程   优惠券编号
    public function quan_history()
    {
        $this->data['left_menu_active'] = 'coupon/statistics';
        $code = htmlspecialchars(trim($this->input->get_post('code')));
        $this->data['search']['code'] = $code;
        
        $info['name'] = ''; //优惠券名称
        $info['grant'] = ''; //领取时间 和 领取人
        $info['forward'] = array(); //转赠时间和转赠人
        $info['forward_ing'] = array(); //转赠时间
        $info['use'] = ''; //使用时间和使用人
        
        $list = $this->coupon_record_model->where(array('code'=>$code))->order_by('id asc')->find_all();
        if( $list ){
            $this->load->model('account_model');
            foreach( $list as $val ){
                if( empty($info['name']) ){
                    $coupon = $this->coupon_model->where(array('site_id'=>$this->site_id,'id'=>$val['coupon_id']))->find();
                    $info['name'] = $coupon['name'];
                }
                
                if( empty($info['grant']) ){
                    $user = $this->account_model->where(array('wid'=>$this->site_id,'id'=>$val['uid']))->find();
                    $info['grant'] = date('Y-m-d H:i:s',$val['add_time']).' '.$user['name'];
                }
                
                if( $val['to_forward']==-1 ){//已领取，转赠中
                    $info['forward_ing'][] = date('Y-m-d H:i:s',$val['to_time']);
                    break;
                }
                
                if( $val['to_forward']>0 ){//已领取，已转赠
                    $user = $this->account_model->where(array('wid'=>$this->site_id,'id'=>$val['to_forward']))->find();
                    $info['forward'][] = date('Y-m-d H:i:s',$val['to_time']).' '.$user['name'];
                    continue;
                }
                
                if( $val['is_used']==1 ){//已使用
                    $user = $this->account_model->where(array('wid'=>$this->site_id,'id'=>$val['uid']))->find();
                    $info['use'] = date('Y-m-d H:i:s',$val['use_time']).' '.$user['name'];
                    if( $val['address_id'] ){
                        $this->load->model('model_address');
                        $address = $this->model_address->get_row(array('wid'=>$this->site_id, 'status'=>0,'id'=>$val['address_id']));
                        if($address){
                            $info['use'] .= ' '.$address['name'];
                        }
                    }else{
                        $info['use'] .= ' '.$this->site_info['company'];
                    }
                    break;
                }
            }
        }
        
        $info['level'] = count($info['forward']);
        if( count($info['forward_ing'])>$info['level'] ){
            $info['level'] = count($info['forward_ing']);
        }
        
        $this->data['info'] = $info;

        $this->load->view($this->dcm, $this->data);
    }
    
    //统计报表  领取赠送统计
    public function statistics()
    {
        if( isset($_GET['export']) ){
            $this->statistics_export();exit;
        }
        $this->data['left_menu_active'] = 'coupon/statistics';
        
        $search_url = site_url($this->uri->uri_string().'?');
        $where = "site_id = '".$this->site_id."'";
        $is_search = 0;
        $search['sear_start_time'] = $this->input->get('sear_start_time');
        $search['sear_end_time'] = $this->input->get('sear_end_time');
        if( $search ){
            if( $search['sear_start_time'] ){
                $is_search = 1;
                $where .= " AND add_time >= ".strtotime($search['sear_start_time']);
                $search_url .= '&sear_start_time='.$search['sear_start_time'];
            }
            if( $search['sear_end_time'] ){
                $is_search = 1;
                $where .= " AND add_time <= ".(strtotime($search['sear_end_time'])+24*3600);
                $search_url .= '&sear_end_time='.$search['sear_end_time'];
            }
        }
        $this->data['search'] = $search;
        
        $total_rows = $this->coupon_model->where(array('site_id'=>$this->site_id))->count();
        $pager = $this->_pager($total_rows,array('per_page'=>15,'base_url'=>$search_url));
        
        $list = $this->coupon_model
                ->select('id,name,forward_num,coupon.receive_type,coupon.receive_content,coupon.has_grant_num')
                ->where(array('site_id'=>$this->site_id))
                ->order_by('sort asc,id desc')
                ->limit($pager['limit']['value'], $pager['limit']['offset'])
                ->find_all();
        
        if( $list ){
            foreach( $list as $key=>$val ){
                if( $is_search==1 ){
                    $has_grant_num_temp = $this->coupon_record_model
                                ->where($where." AND coupon_id = ".$val['id']." AND to_forward <= 0")
                                ->count();
                    $list[$key]['has_grant_num'] = $has_grant_num_temp;//已领取数
                    
                    $forward_num_temp = $this->coupon_record_model
                                ->where($where." AND coupon_id = ".$val['id']." AND to_forward > 0")
                                ->count();
                    $list[$key]['forward_num'] = $forward_num_temp;//已转赠数
                }
                $list[$key]['credit_num'] = 0;
                $list[$key]['money_num'] = 0;
                if( $val['receive_type']==2 ){
                    $list[$key]['credit_num'] = $list[$key]['has_grant_num']*$val['receive_content'];
                }else if( $val['receive_type']==3 ){
                    $list[$key]['money_num'] = $list[$key]['has_grant_num']*$val['receive_content'];
                }  
                
            }
        }
        //file_put_contents('coupon.txt', print_r($list));
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        
        /*************/
        $num['credit_num'] = $num['money_num'] = 0;
        $list_temp = $this->coupon_model
                ->select('id,name,forward_num,coupon.receive_type,coupon.receive_content,coupon.has_grant_num')
                ->where(array('site_id'=>$this->site_id))
                ->order_by('id desc')
                ->find_all();
        if( $list_temp ){
            foreach( $list_temp as $val ){
                if( $is_search==1 ){
                    $has_grant_num_temp = $this->coupon_record_model
                                ->where($where." AND coupon_id = ".$val['id']." AND to_forward <= 0")
                                ->count();
                    if( $val['receive_type']==2 ){
                        $num['credit_num'] += $has_grant_num_temp*$val['receive_content'];
                    }else if( $val['receive_type']==3 ){
                        $num['money_num']  += $has_grant_num_temp*$val['receive_content'];
                    }
                }else{
                    if( $val['receive_type']==2 ){
                        $num['credit_num'] += $val['has_grant_num']*$val['receive_content'];
                    }else if( $val['receive_type']==3 ){
                        $num['money_num']  += $val['has_grant_num']*$val['receive_content'];
                    }
                }
            }
        }
        /*************/
        
        $num['has_grant_num'] = $num['forward_num'] = 0;
        if( $is_search==1 ){
            $num_temp = $this->coupon_record_model
                        ->select('count(id) as num')
                        ->where($where." AND to_forward <= 0")
                        ->group_by('coupon_id')
                        ->find_all();
            
            if( $num_temp ){
                foreach( $num_temp as $val ){
                    $num['has_grant_num'] += $val['num'];
                }
            }
            
            $num_temp = $this->coupon_record_model
                        ->select('count(id) as num')
                        ->where($where." AND to_forward > 0")
                        ->group_by('coupon_id')
                        ->find_all();
            if( $num_temp ){
                foreach( $num_temp as $val ){
                    $num['forward_num'] += $val['num'];
                }
            }
        }else{
            $num_temp = $this->coupon_model
                        ->select('sum(has_grant_num) as has_grant_num,sum(forward_num) as forward_num')
                        ->where(array('site_id'=>$this->site_id))
                        ->find();
            $num['has_grant_num'] = $num_temp['has_grant_num'];
            $num['forward_num'] = $num_temp['forward_num'];
        }
        $this->data['num'] = $num;
        
        $this->load->view($this->dcm, $this->data);
    }
    
    //统计报表  领取赠送统计
    public function statistics_export()
    {
        $where = "site_id = '".$this->site_id."'";
        $is_search = 0;
        $search['sear_start_time'] = $this->input->get('sear_start_time');
        $search['sear_end_time'] = $this->input->get('sear_end_time');
        if( $search ){
            if( $search['sear_start_time'] ){
                $is_search = 1;
                $where .= " AND add_time >= ".strtotime($search['sear_start_time']);
            }
            if( $search['sear_end_time'] ){
                $is_search = 1;
                $where .= " AND add_time <= ".(strtotime($search['sear_end_time'])+24*3600);
            }
        }
        
        
        $num['credit_num'] = $num['money_num'] = 0;
        $list = $this->coupon_model
                ->select('id,name,forward_num,coupon.receive_type,coupon.receive_content,coupon.has_grant_num')
                ->where(array('site_id'=>$this->site_id))
                ->order_by('sort asc')
                ->find_all();
        if( $list ){
            foreach( $list as $key=>$val ){
                /*if( $is_search==1 ){
                    $has_grant_num_temp = $this->coupon_record_model
                                ->where($where." AND coupon_id = ".$val['id']." AND to_forward <= 0")
                                ->count();
                    if( $val['receive_type']==2 ){
                        $num['credit_num'] += $has_grant_num_temp*$val['receive_content'];
                    }else if( $val['receive_type']==3 ){
                        $num['money_num']  += $has_grant_num_temp*$val['receive_content'];
                    }
                }else{
                    if( $val['receive_type']==2 ){
                        $num['credit_num'] += $val['has_grant_num']*$val['receive_content'];
                    }else if( $val['receive_type']==3 ){
                        $num['money_num']  += $val['has_grant_num']*$val['receive_content'];
                    }
                }*/
                if( $is_search==1 ){
                    $has_grant_num_temp = $this->coupon_record_model
                                ->where($where." AND coupon_id = ".$val['id']." AND to_forward <= 0")
                                ->count();
                    $list[$key]['has_grant_num'] = $has_grant_num_temp;
                    
                    $forward_num_temp = $this->coupon_record_model
                                ->where($where." AND coupon_id = ".$val['id']." AND to_forward > 0")
                                ->count();
                    $list[$key]['forward_num'] = $forward_num_temp;
                }
                $list[$key]['credit_num'] = 0;
                $list[$key]['money_num'] = 0;
                if( $val['receive_type']==2 ){
                    $list[$key]['credit_num'] = $list[$key]['has_grant_num']*$val['receive_content'];
                }else if( $val['receive_type']==3 ){
                    $list[$key]['money_num'] = $list[$key]['has_grant_num']*$val['receive_content'];
                }  
            }
        }
        
        /*$num['has_grant_num'] = $num['forward_num'] = 0;
        if( $is_search==1 ){
            $num_temp = $this->coupon_record_model
                        ->select('count(id) as num')
                        ->where($where." AND to_forward <= 0")
                        ->group_by('coupon_id')
                        ->find_all();
            
            if( $num_temp ){
                foreach( $num_temp as $val ){
                    $num['has_grant_num'] += $val['num'];
                }
            }
            
            $num_temp = $this->coupon_record_model
                        ->select('count(id) as num')
                        ->where($where." AND to_forward > 0")
                        ->group_by('coupon_id')
                        ->find_all();
            if( $num_temp ){
                foreach( $num_temp as $val ){
                    $num['forward_num'] += $val['num'];
                }
            }
        }else{
            $num_temp = $this->coupon_model
                        ->select('sum(has_grant_num) as has_grant_num,sum(forward_num) as forward_num')
                        ->where(array('site_id'=>$this->site_id))
                        ->find();
            $num['has_grant_num'] = $num_temp['has_grant_num'];
            $num['forward_num'] = $num_temp['forward_num'];
        }*/
        
        /*$export = array();
        $export[0]['name'] = '';
        $export[0]['has_grant_num'] = $num['has_grant_num'];
        $export[0]['forward_num'] = $num['forward_num'];
        $export[0]['credit_num'] = $num['credit_num'];
        $export[0]['money_num'] = $num['money_num'];
        
        $result = array_merge($export,$list);*/
        
        $fields = array(
            '#'=>'#',
            'name'=>'优惠券名称',
            'has_grant_num'=>'共计领取',
            'forward_num'=>'共计转赠',
            'credit_num'=>'回收积分',
            'money_num'=>'回收金额'
        );
        $this->excel_export('领取/回收统计', '领取/回收统计', $fields, $list);
    }
    
    //统计报表    使用/回收
    public function statistics1()
    {
        if( isset($_GET['export']) ){
            $this->statistics1_export();exit;
        }
        
        $this->data['left_menu_active'] = 'coupon/statistics';
        
        $where = "coupon_record.site_id='".$this->site_id."' AND coupon_record.is_used=1";
        
        $search_url = site_url($this->uri->uri_string().'?');
        $search['sear_start_time'] = $this->input->get('sear_start_time');
        $search['sear_end_time'] = $this->input->get('sear_end_time');
        $search['keyword'] = trim($this->input->get('keyword',true));
        if( $search ){
            if( $search['sear_start_time'] ){
                $where .= " AND coupon_record.use_time >= ".strtotime($search['sear_start_time']);
                $search_url .= '&sear_start_time='.$search['sear_start_time'];
            }
            if( $search['sear_end_time'] ){
                $where .= " AND coupon_record.use_time <= ".(strtotime($search['sear_end_time'])+24*3600);
                $search_url .= '&sear_end_time='.$search['sear_end_time'];
            }
            if( $search['keyword'] ){
                $where .= " AND coupon.name LIKE '%".$search['keyword']."%' ";
                $search_url .= '&keyword='.$search['keyword'];
            }
        }
        $this->data['search'] = $search;
        
        $total_rows_temp = $this->coupon_record_model
                ->select('count(coupon_record.id) as num')
                ->where($where)
                ->join('coupon','coupon.id=coupon_record.coupon_id')
                ->group_by('coupon_record.address_id,coupon_record.coupon_id')
                ->find_all();
        $total_rows = count($total_rows_temp);
        $num['use_num'] = 0;
        if( $total_rows_temp ){
            foreach( $total_rows_temp as $val ){
                 $num['use_num'] += $val['num'];
            }
        }
        $this->data['num'] = $num;
        
        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$search_url));        
        $list = $this->coupon_record_model
                ->select('coupon.name,count(coupon_record.id) as num,coupon_record.address_id')
                ->where($where)
                ->join('coupon','coupon.id=coupon_record.coupon_id')
                ->group_by('coupon_record.address_id,coupon_record.coupon_id')
                ->limit($pager['limit']['value'], $pager['limit']['offset'])
                ->find_all();
        
        if( $list ){
            $this->load->model('model_address');
            foreach( $list as $key=>$val ){
                if( $val['address_id'] ){
                    $address = $this->model_address->get_row(array('wid'=>$this->site_id, 'status'=>0,'id'=>$val['address_id']));
                    $list[$key]['address'] = $address['name'];
                }else{
                    $list[$key]['address'] = '';
                }
            }
        }
              
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        
        $this->data['site_company'] = $this->site_info['company'];
        
        $this->load->view($this->dcm, $this->data);
    }
    
    //统计报表    使用/回收 导出export
    public function statistics1_export()
    {
        $where = "coupon_record.site_id='".$this->site_id."' AND coupon_record.is_used=1";
        
        $search['sear_start_time'] = $this->input->get('sear_start_time');
        $search['sear_end_time'] = $this->input->get('sear_end_time');
        $search['keyword'] = trim($this->input->get('keyword',true));
        if( $search ){
            if( $search['sear_start_time'] ){
                $where .= " AND coupon_record.use_time >= ".strtotime($search['sear_start_time']);
            }
            if( $search['sear_end_time'] ){
                $where .= " AND coupon_record.use_time <= ".(strtotime($search['sear_end_time'])+24*3600);
            }
            if( $search['keyword'] ){
                $where .= " AND coupon.name LIKE '%".$search['keyword']."%' ";
            }
        }
        
        /*$total_rows_temp = $this->coupon_record_model
                ->select('count(coupon_record.id) as num')
                ->where($where)
                ->join('coupon','coupon.id=coupon_record.coupon_id')
                ->group_by('coupon_record.address_id,coupon_record.coupon_id')
                ->find_all();
        $total_rows = count($total_rows_temp);
        $num['use_num'] = 0;
        if( $total_rows_temp ){
            foreach( $total_rows_temp as $val ){
                 $num['use_num'] += $val['num'];
            }
        }*/

        $list = $this->coupon_record_model
                ->select('coupon.name,count(coupon_record.id) as num,coupon_record.address_id')
                ->where($where)
                ->join('coupon','coupon.id=coupon_record.coupon_id')
                ->group_by('coupon_record.address_id,coupon_record.coupon_id')
                ->find_all();
        
        if( $list ){
            $this->load->model('model_address');
            foreach( $list as $key=>$val ){
                if( $val['address_id'] ){
                    $address = $this->model_address->get_row(array('wid'=>$this->site_id, 'status'=>0,'id'=>$val['address_id']));
                    $list[$key]['address'] = $address['name'];
                }else{
                    $list[$key]['address'] = $this->site_info['company'];
                }
            }
        }else{
            $list = array();
        }
        
        /*$export = array();
        $export[0]['name'] = '';
        $export[0]['address'] = '';
        $export[0]['num'] = $num['use_num'];
        
        $result = array_merge($export,$list);*/
        
        $fields = array(
            '#'=>'#',
            'name'=>'优惠券名称',
            'address'=>'共计领取',
            'num'=>'共计使用'
        );
        $this->excel_export('使用统计', '使用统计', $fields, $list);
    }
    
    //使用情况
    public function use_statistics()
    {
        if( isset($_GET['export']) ){
            $this->use_statistics_export();exit;
        }
        $this->data['left_menu_active'] = 'coupon/statistics';
        
        $where = "coupon_record.site_id = '".$this->site_id."' AND coupon.site_id = '".$this->site_id."' AND account.wid = '".$this->site_id."'";
        
        $search_url = site_url($this->uri->uri_string().'?');
        $is_search = 0;
        $search['sear_start_time'] = $this->input->get('sear_start_time');
        $search['sear_end_time'] = $this->input->get('sear_end_time');
        $search['address_id'] = trim($this->input->get('address_id'));
        $search['status'] = 2;
        $search['keyword'] = trim($this->input->get('keyword',true));
        
        if( $search ){
            if( $search['sear_start_time'] ){
                $is_search = 1;
                $where .= " AND coupon_record.use_time >= ".strtotime($search['sear_start_time']);
                $search_url .= '&sear_start_time='.$search['sear_start_time'];
            }
            if( $search['sear_end_time'] ){
                $is_search = 1;
                $where .= " AND coupon_record.use_time <= ".(strtotime($search['sear_end_time'])+24*3600);
                $search_url .= '&sear_end_time='.$search['sear_end_time'];
            }
            if( $search['address_id']!=0 ){
                if( $search['address_id']==-1 ){
                    $address_id = 0;
                }else{
                    $address_id = $search['address_id'];
                }
                $is_search = 1;
                $where .= " AND coupon_record.address_id = ".$address_id;
                $search_url .= '&address_id='.$search['address_id'];
                $search['status'] = 2;
            }
            if( $search['status'] ){
                $search_url .= '&status='.$search['status'];
                if( $search['status']==1 ){//已领取
                    $where .= " AND coupon_record.is_used = 0";
                    $where .= " AND coupon_record.to_forward = 0";
                }
                if( $search['status']==2 ){//已使用
                    $where .= " AND coupon_record.is_used = 1";
                }
                if( $search['status']==3 ){//已转赠
                    $where .= " AND coupon_record.is_used = 0";
                    $where .= " AND coupon_record.to_forward > 0";
                }
                if( $search['status']==4 ){//转赠中
                    $where .= " AND coupon_record.is_used = 0";
                    $where .= " AND coupon_record.to_forward = -1";
                }
            }
            if( $search['keyword'] ){
                $is_search = 1;
                $where .= " AND (coupon_record.code LIKE '%".$search['keyword']."%' OR coupon.name LIKE '%".$search['keyword']."%' )";
                $search_url .= '&keyword='.$search['keyword'];
            }
        }
        $this->data['search'] = $search;
        
        $total_rows = $this->coupon_record_model->where($where)
                ->join('coupon','coupon.id=coupon_record.coupon_id')
                ->join('account','account.id=coupon_record.uid')->count();
            
        /*if( $is_search==0 ){
            $num_temp = $this->coupon_model->select('sum(has_grant_num) as has_grant_num,sum(forward_num) as forward_num,sum(use_num) as use_num')->where(array('site_id'=>$this->site_id))->find();
            $num['has_grant_num'] = $num_temp['has_grant_num'];
            $num['forward_num'] = $num_temp['forward_num'];
            $num['use_num']     = $num_temp['use_num'];
        }else{
            //已领取
            $num_temp = $this->coupon_record_model->select('coupon_record.id')->where($where)
                ->join('coupon','coupon.id=coupon_record.coupon_id')
                ->join('account','account.id=coupon_record.uid')
                ->group_by('coupon_record.id,coupon_record.to_forward')
                ->having('coupon_record.to_forward >=0')
                ->find_all();
            $num['has_grant_num'] = count($num_temp);
            
            //已使用
            $num_temp = $this->coupon_record_model->select('count(*) as use_num')->where($where)
                ->join('coupon','coupon.id=coupon_record.coupon_id')
                ->join('account','account.id=coupon_record.uid')
                ->group_by('coupon_record.is_used')
                ->having('coupon_record.is_used = 1')
                ->find();
            $num['use_num'] = intval($num_temp['use_num']);
            
            //已转赠
            $num_temp = $this->coupon_record_model->select('coupon_record.id')->where($where)
                ->join('coupon','coupon.id=coupon_record.coupon_id')
                ->join('account','account.id=coupon_record.uid')
                ->group_by('coupon_record.id,coupon_record.to_forward')
                ->having('coupon_record.to_forward >0')
                ->find_all();
            $num['forward_num'] = count($num_temp);
        }*/
        $num['use_num'] = $total_rows;
        $this->data['num'] = $num;
            
        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$search_url));
        
        
        $list = $this->coupon_record_model
                ->select('coupon_record.*,coupon.name,account.name as username,account.mobile')
                ->where($where)
                ->join('coupon','coupon.id=coupon_record.coupon_id')
                ->join('account','account.id=coupon_record.uid')
                ->order_by('coupon_record.use_time desc,coupon_record.id desc')
                ->limit($pager['limit']['value'], $pager['limit']['offset'])
                ->find_all();
        if( $list ){
            $this->load->model('address_model');
            foreach( $list as $key=>$val ){
                $list[$key]['address'] = '';
                if( $val['is_used']&&$val['address_id'] ){
                    $address = $this->address_model->where(array('wid'=>$this->site_id, 'status'=>0,'id'=>$val['address_id']))->find();
                    $list[$key]['address'] = $address['name'];
                }
            }
        }
        
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        
        $this->address();
        
        $this->data['site_company'] = $this->site_info['company'];
        
        $this->load->view($this->dcm, $this->data);
    }
    
    //使用情况  导出export
    public function use_statistics_export()
    {
        $where = "coupon_record.site_id = '".$this->site_id."' AND coupon.site_id = '".$this->site_id."' AND account.wid = '".$this->site_id."'";
        
        $is_search = 0;
        $search['sear_start_time'] = $this->input->get('sear_start_time');
        $search['sear_end_time'] = $this->input->get('sear_end_time');
        $search['address_id'] = trim($this->input->get('address_id'));
        $search['status'] = 2;
        $search['keyword'] = trim($this->input->get('keyword',true));
        
        if( $search ){
            if( $search['sear_start_time'] ){
                $is_search = 1;
                $where .= " AND coupon_record.use_time >= ".strtotime($search['sear_start_time']);
            }
            if( $search['sear_end_time'] ){
                $is_search = 1;
                $where .= " AND coupon_record.use_time <= ".(strtotime($search['sear_end_time'])+24*3600);
            }
            if( $search['address_id']!=0 ){
                if( $search['address_id']==-1 ){
                    $address_id = 0;
                }else{
                    $address_id = $search['address_id'];
                }
                $is_search = 1;
                $where .= " AND coupon_record.address_id = ".$address_id;
                $search['status'] = 2;
            }
            if( $search['status'] ){
                if( $search['status']==1 ){//已领取
                    $where .= " AND coupon_record.is_used = 0";
                    $where .= " AND coupon_record.to_forward = 0";
                }
                if( $search['status']==2 ){//已使用
                    $where .= " AND coupon_record.is_used = 1";
                }
                if( $search['status']==3 ){//已转赠
                    $where .= " AND coupon_record.is_used = 0";
                    $where .= " AND coupon_record.to_forward > 0";
                }
                if( $search['status']==4 ){//转赠中
                    $where .= " AND coupon_record.is_used = 0";
                    $where .= " AND coupon_record.to_forward = -1";
                }
            }
            if( $search['keyword'] ){
                $is_search = 1;
                $where .= " AND (coupon_record.code LIKE '%".$search['keyword']."%' OR coupon.name LIKE '%".$search['keyword']."%' )";
            }
        }
        $this->data['search'] = $search;
        
        $list = $this->coupon_record_model
                ->select('coupon_record.*,coupon.name,account.name as username,account.mobile')
                ->where($where)
                ->join('coupon','coupon.id=coupon_record.coupon_id')
                ->join('account','account.id=coupon_record.uid')
                ->order_by('coupon_record.use_time desc,coupon_record.id desc')
                ->find_all();
        if( $list ){
            $this->load->model('address_model');
            foreach( $list as $key=>$val ){
                $list[$key]['use_time'] = date('Y-m-d H:i:s',$val['use_time']);
                $list[$key]['address'] = '';
                if( $val['is_used']&&$val['address_id'] ){
                    $address = $this->address_model->where(array('wid'=>$this->site_id, 'status'=>0,'id'=>$val['address_id']))->find();
                    $list[$key]['address'] = $address['name'];
                }
                if( $val['is_used']&&!$val['address_id'] ){
                    $list[$key]['address'] = $this->site_info['company'];
                }
            }
        }else{
            $list = array();
        }
        
        $fields = array(
            '#'=>'#',
            'name'=>'优惠券名称',
            'code'=>'优惠券编号',
            'use_time'=>'使用时间',
            'address' => '店铺',
            'username' => '使用人',
            'mobile' => '手机号码'
        );
        $this->excel_export('使用统计', '使用统计', $fields, $list);
    }

    //领取优惠券
    public function receive_coupon()
    {
        $this->data['left_menu_active'] = 'coupon/statistics';
        if( isset($_GET['export']) ){
            $this->receive_coupon_export();
        }
        $where = "coupon_record.site_id = '".$this->site_id."' AND coupon_record.to_forward = 0";

        $search['sear_start_time'] = $this->input->get('sear_start_time');
        $search['sear_end_time'] = $this->input->get('sear_end_time');
        $search['keyword'] = trim($this->input->get('keyword',true));

        if( $search['sear_start_time'] ){
            $where .= " AND coupon_record.add_time >= ".strtotime($search['sear_start_time']);
        }
        if( $search['sear_end_time'] ){
            $where .= " AND coupon_record.add_time <= ".(strtotime($search['sear_end_time'])+24*3600);
        }
        if( $search['keyword'] ){
            $where .= " AND (coupon_record.code LIKE '%".$search['keyword']."%' OR coupon.name LIKE '%".$search['keyword']."%' )";
        }

        $search_url = site_url($this->uri->uri_string().'?').http_build_query($search);

        $total_rows = $this->coupon_record_model->where($where)->join('coupon','coupon.id=coupon_record.coupon_id')->join('account','account.id=coupon_record.uid')->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$search_url));
        $list = $this->coupon_record_model
            ->select('coupon_record.*,coupon.name,account.name as username,account.mobile')
            ->where($where)
            ->join('coupon','coupon.id=coupon_record.coupon_id')
            ->join('account','account.id=coupon_record.uid')
            ->order_by('coupon_record.id desc')
            ->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->find_all();

        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->data['total_rows'] = $total_rows;
        $this->data['search'] = $search;

        $this->load->view($this->dcm, $this->data);
    }

    //领取优惠券导出
    public function receive_coupon_export()
    {
        $where = "coupon_record.site_id = '".$this->site_id."' AND coupon_record.to_forward = 0";

        $search['sear_start_time'] = $this->input->get('sear_start_time');
        $search['sear_end_time'] = $this->input->get('sear_end_time');
        $search['keyword'] = trim($this->input->get('keyword',true));

        if( $search['sear_start_time'] ){
            $where .= " AND coupon_record.add_time >= ".strtotime($search['sear_start_time']);
        }
        if( $search['sear_end_time'] ){
            $where .= " AND coupon_record.add_time <= ".(strtotime($search['sear_end_time'])+24*3600);
        }
        if( $search['keyword'] ){
            $where .= " AND (coupon_record.code LIKE '%".$search['keyword']."%' OR coupon.name LIKE '%".$search['keyword']."%' )";
        }

        $list = $this->coupon_record_model
            ->select('coupon_record.*,coupon.name,account.name as username,account.mobile')
            ->where($where)
            ->join('coupon','coupon.id=coupon_record.coupon_id')
            ->join('account','account.id=coupon_record.uid')
            ->order_by('coupon_record.id desc')
            ->find_all();

        if( $list ){
            $fields = array(
                '#'=>'#',
                'name'=>'优惠券名称',
                'code'=>'优惠券编号',
                'username' => '领取人',
                'mobile' => '手机号码'
            );
            $this->excel_export('优惠券领取统计', '优惠券领取统计', $fields, $list);
        }
    }
    
    //获取优惠券
    private function get_config()
    {
        $where = array(
            'site_id' => $this->site_id
        );
        $coupon = $this->model->where($where)->find();
        $coupon = $coupon ? $coupon : array();
        $this->data['coupon'] = $coupon;
        return $coupon;
    }
    
    /**
     * 默认单位  联系方式里的
     */
    private function address()
    {
        //分店
        $this->load->model('model_address');
        $address_list = $this->model_address->get_all(array('wid'=>$this->site_id, 'status'=>0), '', '');
        $address_list = $address_list ? $address_list : array();
        $this->data['address_list'] = $address_list;
        if( !$address_list ){
            return false;
        }
        return true;
    }
    
    //检查图片格式
    public function _check_image($image) {
        if ($image) {
            if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
                $this->form_validation->set_message('_check_image', '图片地址格式错误');
                return FALSE;
            }
        }
        return TRUE;
    }
} 