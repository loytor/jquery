<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: 111
 * Date: 14-8-20
 * Time: 上午10:42
 */

class Als extends C_Controller{

    private $site_id = '';
    private $zishi = array(
        1 => array(
            'id' => 1,
            'title' => '盖茨式',
            'img' => 'http://image.bama555.com/data/201408/20/c732c5f309c21d227d9d931db6e996a1_600_450.jpg',
            'icon' => 'http://image.bama555.com/data/201408/20/0d15a7f71569ce11146edba03d5554ca_200_150.jpg'
        ),
        2 => array(
            'id' => 2,
            'title' => '刘德华式',
            'img' => 'http://image.bama555.com/data/201408/20/754fd04700172c2489a83179430f8b56_600_450.jpg',
            'icon' => 'http://image.bama555.com/data/201408/20/ca974124d6bea1bbae69b5a8a1d61245_200_150.jpg'
        ),
        3 => array(
            'id' => 3,
            'title' => '周杰伦式',
            'img' => 'http://image.bama555.com/data/201408/20/9b41f412480515ec192ae949d5f27afc_600_450.jpg',
            'icon' => 'http://image.bama555.com/data/201408/20/4485af69ebe36b77051b071d36fbc60f_200_150.jpg'
        ),
        4 => array(
            'id' => 4,
            'title' => '奥尼尔式',
            'img' => 'http://image.bama555.com/data/201408/20/3f61d9c1f6236ec34a4ec4fa03a1e7b9_600_450.jpg',
            'icon' => 'http://image.bama555.com/data/201408/20/093070a5578e93a7fb3443c7212e968f_200_150.jpg'
        ),
        5 => array(
            'id' => 5,
            'title' => '邓紫棋式',
            'img' => 'http://image.bama555.com/data/201408/20/2e80d82f99362172cfdedc10ffa5c672_600_450.jpg',
            'icon' => 'http://image.bama555.com/data/201408/20/3a3a562f4b37770c4676bcadb09f26fd_200_150.jpg'
        ),
        6 => array(
            'id' => 6,
            'title' => '詹姆斯式',
            'img' => 'http://image.bama555.com/data/201408/20/a80c0719f335d4034f76b8b7305556e1_600_450.jpg',
            'icon' => 'http://image.bama555.com/data/201408/20/38e34740582dc87185e6b5e4ed4c877f_200_150.jpg'
        )
    );

    public function __construct()
    {
        parent::__construct();
        $this->site_id = $this->site_info['id'];
        $this->load->model('als_model');
        $this->load->model('als_statistics_model');
    }

    public function index()
    {
        $where['site_id'] = $this->site_id;
        $where['is_delete'] = 0;
        $total_rows = $this->als_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>10));
        $list = $this->als_model->where($where)->limit($pager['limit']['value'], $pager['limit']['offset'])->order_by('id desc')->find_all();
        $this->data['list'] =  $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->data['view_url'] = $this->create_url('als/index');

        $this->load->view($this->dcm, $this->data);
    }

    public function add()
    {
        if( $this->input->post() ){
            $this->form_validation->set_rules('title', '标题', 'trim|required|max_length[255]');
            $this->form_validation->set_rules('declaration', '公益宣言', 'trim|max_length[255]');
            if ( $this->form_validation->run() ){
                $save_data['title'] = $this->form_validation->set_value('title');
                $save_data['declaration'] = $this->form_validation->set_value('declaration');

                //添加
                $save_data['site_id'] = $this->site_id;
                $save_data['add_time'] = time();
                if($this->als_model->add($save_data)){
                }else{
                    $this->show_message(false, '添加失败', '/c/als');return FALSE;
                }
                $this->show_message(true, '添加成功', '/c/als');return FALSE;
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            $this->data['webInfo'] = $this->site_info;
            $this->load->view($this->dcm, $this->data);
        }
    }

    public function edit($id='')
    {
        if( !$id ){
            return $this->show_message(false, '非法操作', '/c/als');
        }
        $als = $this->als_model->where(array('site_id'=>$this->site_id,'id'=>$id,'is_delete'=>0))->find();
        if( !$als ){
            return $this->show_message(false, '没有找到该挑战', '/c/als');
        }
        $this->data['info'] = $als;
        if( $this->input->post() ){
            $this->form_validation->set_rules('declaration', '公益宣言', 'trim|max_length[255]');
            $this->form_validation->set_rules('title', '标题', 'trim|required|max_length[255]');
            if ( $this->form_validation->run() ){
                $save_data['title'] = $this->form_validation->set_value('title');
                $save_data['declaration'] = $this->form_validation->set_value('declaration');

                //修改
                if($this->als_model->where(array('site_id'=>$this->site_id,'id'=>$id,'is_delete'=>0))->edit($save_data)){
                }else{
                    $this->show_message(false, '修改失败', '');return FALSE;
                }
                $this->show_message(true, '修改成功', '/c/als');return FALSE;
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            $this->data['webInfo'] = $this->site_info;
            $this->load->view($this->dcm, $this->data);
        }
    }

    /**
     *
     * @author Qianc
     * @date 2014-8-20
     * @description 统计
     */
    public function statistics($als_id)
    {
        $search['start_date'] = $this->input->get('start_date');
        $search['end_date'] = $this->input->get('end_date');
        $this->data['search'] = $search;

        $where = array();
        $where['als_id'] = intval($als_id);

        $search_url = site_url($this->uri->uri_string().'?');
        $search['start_date'] ? $where['action_time >='] = strtotime($search['start_date']) : '';
        $search['end_date'] ? $where['action_time <='] = strtotime($search['end_date']) : '';

        $total_rows = $this->als_statistics_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$search_url.http_build_query($search)));
        $this->data['page'] = $pager['links'];

        $list = $this->als_statistics_model
            ->select('*')
            ->limit($pager['limit']['value'], $pager['limit']['offset'])
            ->where($where)->order_by('action_time desc,id desc')->find_all();
        if($list) $list = $this->_statistics($list);

        $this->data['list'] = $list;
        $als = $this->_get_als(intval($als_id), 'title, id');
        $this->data['als'] = $als;
        //$this->data['posture'] = $this->zishi;
        $this->load->view($this->dcm,$this->data);

    }

    //得到邀请者名字 姿势
    private function _statistics($list)
    {
        foreach($list as $k => $v){
            if($v['from_open_id']){
                $where['open_id'] = $v['from_open_id'];
                $als_statistics = $this->als_statistics_model->select('player')->where($where)->find();
                $list[$k]['invite_player'] = $als_statistics ? $als_statistics['player'] : $this->site_info['web_name'];
            }else{
                $list[$k]['invite_player'] = $this->site_info['web_name'];
            }
            $list[$k]['posture'] = $this->zishi[$v['posture']]['title'];
        }
        return $list;
    }

    //获取单个比赛信息
    private function _get_als($id, $field = "*")
    {
        $where['id'] = $id;
        $als = $this->als_model->select($field)->where($where)->find();
        return $als;
    }

    public function delete($id='')
    {
        if( !$id ){
            return $this->show_message(false, '非法操作', '/c/als');
        }
        $als = $this->als_model->where(array('site_id'=>$this->site_id,'id'=>$id,'is_delete'=>0))->find();
        if( !$als ){
            return $this->show_message(false, '没有找到该挑战', '/c/als');
        }
        if($this->als_model->where(array('site_id'=>$this->site_id,'id'=>$id,'is_delete'=>0))->edit(array('is_delete'=>1))){
        }else{
            $this->show_message(false, '删除失败', '');return FALSE;
        }
        $this->show_message(true, '删除成功', '/c/als');return FALSE;
    }


    /**
     *
     * @author Qianc
     * @date 2014-8-20
     * @description 导出excel
     */
    public function stat_export($als_id)
    {
        if( !$als_id ){
            return $this->show_message(false, '非法操作', '/c/als');exit;
        }

        $where = array();
        $where['als_id'] = intval($als_id);
        $list = $this->als_statistics_model
            ->select('*')
            ->where($where)->order_by('action_time desc,id desc')->find_all();
        if($list) $list = $this->_statistics($list);

        $export_list = array();
        if($list)
        {
            foreach($list as $key=> $item)
            {
                $export_list[$key]['invite_player'] = $item['invite_player'];
                $export_list[$key]['player'] = $item['player'];
            }

            $fields = array(
                '#'=>'#',
                'invite_player'=>'邀请者',
                'player'=>'挑战者',
                'posture'=>'姿势',
                'action_time'=>'挑战日期'
            );

            $this->excel_export('挑战数据', '挑战数据', $fields, $export_list);
        }
        else
        {
            $this->show_message(false, '非法操作', '/c/als');return FALSE;
        }
    }

    /**
     *
     * @author Qianc
     * @date 2014-8-20
     * @description 显示、隐藏
     */
    public function hide()
    {
        $statistics_id = intval($this->input->get('statistics_id'));
        $hide = intval($this->input->get('hide')) >= 1 ? 1 : 0 ;

        $save_data['is_hide'] = $hide;
        $where = array('id' => $statistics_id);
        if($this->als_statistics_model->where($where)->edit($save_data)){
            $als_id = intval($this->input->get('als_id'));
            $this->show_message(true, '修改成功', '/c/als/statistics/'.$als_id);return FALSE;
        }
        $this->show_message(false, '修改失败', '');return FALSE;
    }

} 