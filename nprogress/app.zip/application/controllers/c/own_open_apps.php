<?php

/**
 * Created by PhpStorm.
 * User: songxiyao
 * Date: 2014/10/10
 * Time: 11:04
 */
class Own_open_apps extends C_Controller {

    protected $site_id = '';

    public function __construct() {
        parent::__construct();
        $this->site_id = $this->site_info['id'];
    }

    public function index() {
        //获取用户开放平台应用列表
        $this->load->model('site_client_model');
        $tpl_data['client_list'] = $this->site_client_model->get_user_clients($this->site_id);
        $tpl_data['client_list'] = $tpl_data['client_list'] ? $tpl_data['client_list'] : array();
        //echo json_encode($tpl_data['client_list']);exit;
        $tpl_data['title'] = '已购应用';
        $this->load->view('c/own_open_apps/index', $tpl_data);
    }

    public function test() {
        $this->load->model('developer_bind_model');
        $this->load->model('oauth_client_model');
        //关联的开发者id
        $bind = $this->developer_bind_model->get_user_bind_developer_id($this->site_id);
        //获取开发者测试应用列表
        $oauth_client_list = $this->oauth_client_model->get_client_list(array('developer_id' => $bind['developer_id']), '', 100);
        if ($oauth_client_list) {
            foreach ($oauth_client_list as $k => $_client_list) {
                $oauth_client_list[$k]['client_id'] = $_client_list['id'];
                $oauth_client_list[$k]['client_name'] = $_client_list['name'];
                $oauth_client_list[$k]['client_icon'] = $_client_list['icon'];
                $oauth_client_list[$k]['client_manage_url'] = $_client_list['manage_url'];
            }
        }
        $tpl_data['client_list'] = $oauth_client_list;
        $tpl_data['title'] = '测试应用';
        $this->load->view('c/own_open_apps/index', $tpl_data);
    }
}