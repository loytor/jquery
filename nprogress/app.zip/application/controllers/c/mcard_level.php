<?php
/**
 * Created by PhpStorm.
 * User: andery
 * Date: 13-12-5
 * Time: 上午9:43
 * @property Mcard_model $mcard_model
 */

class Mcard_level extends C_Controller {
    protected $auto_load_model = TRUE;
    protected $model_name = 'mcard_level';

    public function index()
    {
        //获取会员卡
        $mcard = $this->getMcard();
        if(!$mcard)
        {
            return false;
        }
        $where['site_id'] = $mcard['site_id'];
        $where['mcard_id'] = $mcard['id'];
        $where['site_id'] = $mcard['site_id'];
        $where['status'] = 1;
        $total_rows = $this->model->where($where)->count();
        $pager = $this->_pager($total_rows);
        $list = $this->model->order_by('basic desc,id desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->where($where)->find_all();
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        //print_r($this->data);
        $this->load->view($this->dcm, $this->data);
    }


    public function add()
    {
        $mcard= $this->getMcard();
        if(!$mcard)
        {
            return false;
        }
        if($this->input->post())
        {
            $this->form_validation->set_rules('title', '等级名称', 'trim|required|max_length[50]|htmlspecialchars');
            $this->form_validation->set_rules('instruction', '等级说明', 'trim|htmlspecialchars');
            if ( $this->form_validation->run() )
            {
                $dataSet['title'] = $this->form_validation->set_value('title');
                //有效期处理
                $validday = $this->input->post('validday');
                if($validday == 1)
                {
                    $day = $this->input->post('day');
                    if(!is_numeric($day) || $day <=0)
                    {
                        $this->show_message(FALSE, '有效期必须大于0', '');
                        return false;
                    }
                    $dataSet['validday'] = $day;
                }
                else
                {
                    $dataSet['validday'] = 0;
                }
                //等级条件处理
                $conditions = $this->input->post('conditions');
                //自定义
                if($conditions == 1)
                {
                    $diytitle = $this->input->post('diytitle');
                    if(!$diytitle)
                    {
                        $this->show_message(FALSE, '自定义等级条件不能为空！', '');
                        return false;
                    }
                    $dataSet['conditions'] = 1;
                    $dataSet['diytitle'] = $diytitle;
                }
                else if($conditions == 2)
                {
                    $minpoints = $this->input->post('minpoints');
                    if(!$this->form_validation->is_natural_no_zero($minpoints))
                    {
                        $this->show_message(FALSE, '积分条件必须是正整数', '');
                        return false;
                    }
                    if($this->model->where(array('minpoints'=>$minpoints, 'site_id'=>$mcard['site_id'], 'mcard_id'=>$mcard['id'], 'status'=>1))->find())
                    {
                        $this->show_message(FALSE, '积分条件不能重复', '');
                        return false;
                    }

                    $dataSet['conditions'] = 2;
                    $dataSet['minpoints'] = $minpoints;
                    //获取离该分数最近的最大值
                    $last_level = $this->model->where(array('site_id'=>$mcard['site_id'], 'mcard_id'=>$mcard['id'], 'maxpoints >'=>$minpoints, 'conditions'=>2, 'status'=>1))->order_by('maxpoints', 'asc')->find();
                    $dataSet['maxpoints'] =  $last_level && $last_level['maxpoints'] ? $last_level['maxpoints'] : 999999999;
                }
                //等级说明
                $dataSet['instruction'] = $this->form_validation->set_value('instruction');
                /*
                //是否生效
                $dataSet['enabled'] = $this->input->post('enabled');
                if($dataSet['enabled'] == 1)
                {
                    $dataSet['enabledtime'] = time();
                }
                */
                $dataSet['site_id'] = $mcard['site_id'];
                $dataSet['mcard_id'] = $mcard['id'];
                $dataSet['dt_add'] = time();

                //默认卡片样式
                if($levelid = $this->model->add($dataSet))
                {
                    //更新前一等级的最大值
                    if(isset($minpoints) && $minpoints){
                        $ml = $this->model->where(array('site_id'=>$mcard['site_id'], 'mcard_id'=>$mcard['id'], 'minpoints <'=>$minpoints, 'conditions'=>2, 'status'=>1))->order_by('minpoints', 'desc')->find();
                        $this->model->where(array('site_id'=>$mcard['site_id'], 'mcard_id'=>$mcard['id'], 'id'=>$ml['id']))->edit(array('maxpoints'=>$minpoints));
                    }

                    $this->show_message(true, '保存成功', '/c/mcard_level');
                    return false;
                }
                else
                {
                    $this->show_message(FALSE, '保存失败', '');
                    return false;
                }
            }
            else
            {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }
        $this->load->view($this->dcm, $this->data);
    }

    /**
     * @name 编辑
     * @param $id
     * @return bool
     */
    public function edit($id)
    {
        $mcard = $this->getMcard();
        if(!$mcard)
        {
            return false;
        }
        //查找会员卡等级是否存在
        $mcardLevel = $this->model->where(array('id'=>$id,'site_id'=>$mcard['site_id'],'mcard_id'=>$mcard['id'],'status'=>1))->find();
        if(!$mcardLevel)
        {
            $this->show_message(FALSE, '会员卡等级不存在', '/c/mcard_level');
            return false;
        }

        if($this->input->post())
        {
            $this->form_validation->set_rules('title', '等级名称', 'trim|required|max_length[50]|htmlspecialchars');
            $this->form_validation->set_rules('instruction', '等级说明', 'trim|htmlspecialchars');
            if ( $this->form_validation->run() )
            {
                $dataSet['title'] = $this->form_validation->set_value('title');
                //有效期处理
                $validday = $this->input->post('validday');
                if($validday == 1)
                {
                    $day = $this->input->post('day');
                    if(!is_numeric($day) || $day <=0)
                    {
                        $this->show_message(FALSE, '有效期必须大于0', '');
                        return false;
                    }
                    $dataSet['validday'] = $day;
                }
                else
                {
                    $dataSet['validday'] = 0;
                }
                //等级条件处理
                $conditions = $this->input->post('conditions');
                //自定义
                if($conditions == 1)
                {
                    $diytitle = $this->input->post('diytitle');
                    if(!$diytitle)
                    {
                        $this->show_message(FALSE, '自定义等级条件不能为空！', '');
                        return false;
                    }
                    $dataSet['conditions'] = 1;
                    $dataSet['diytitle'] = $diytitle;
                }
                else if($conditions == 2)
                {
                    $minpoints = $this->input->post('minpoints');
                    if(!$this->form_validation->is_natural_no_zero($minpoints))
                    {
                        $this->show_message(FALSE, '积分条件必须是正整数', '');
                        return false;
                    }
                    if($minpoints != $mcardLevel['minpoints'] && $this->model->where(array('minpoints'=>$minpoints, 'site_id'=>$mcard['site_id'], 'mcard_id'=>$mcard['id'], 'status'=>1))->find())
                    {
                        $this->show_message(FALSE, '积分条件不能重复', '');
                        return false;
                    }
                    //积分设置判断

                    $dataSet['conditions'] = 2;
                    $dataSet['minpoints'] = $minpoints;
                    //获取离该分数最近的最大值
                    $last_level = $this->model->where(array('site_id'=>$mcard['site_id'], 'mcard_id'=>$mcard['id'], 'maxpoints >'=>$mcardLevel['minpoints'], 'conditions'=>2, 'status'=>1))->order_by('maxpoints', 'asc')->find();
                    $dataSet['maxpoints'] =  $last_level && $last_level['maxpoints'] ? $last_level['maxpoints'] : 999999999;
                }

                //等级说明
                $dataSet['instruction'] = $this->form_validation->set_value('instruction');

                /*
                //是否生效
                $dataSet['enabled'] = $this->input->post('enabled');
                if($dataSet['enabled'] == 1)
                {
                    $dataSet['enabledtime'] = time();
                }
                */
                $cur_maxpoints = $mcardLevel['maxpoints'];
                //先更新前一条的等级最大值
                if($cur_maxpoints){
                    $ml = $this->model->where(array('site_id'=>$mcard['site_id'], 'mcard_id'=>$mcard['id'], 'maxpoints <'=>$cur_maxpoints, 'conditions'=>2, 'status'=>1))->order_by('maxpoints', 'desc')->find();
                    $this->model->where(array('site_id'=>$mcard['site_id'], 'mcard_id'=>$mcard['id'], 'id'=>$ml['id']))->edit(array('maxpoints'=>$cur_maxpoints));
                }

                if( false===$this->model->where(array('id'=>$mcardLevel['id']))->edit($dataSet) )
                {
                    $this->show_message(FALSE, '保存失败', '');
                    return false;
                }
                else
                {
                    //更新前一等级的最大值
                    if(isset($minpoints) && $minpoints){
                        $ml = $this->model->where(array('site_id'=>$mcard['site_id'], 'mcard_id'=>$mcard['id'], 'minpoints <'=>$minpoints, 'conditions'=>2, 'status'=>1))->order_by('minpoints', 'desc')->find();
                        $this->model->where(array('site_id'=>$mcard['site_id'], 'mcard_id'=>$mcard['id'], 'id'=>$ml['id']))->edit(array('maxpoints'=>$minpoints));
                    }
                    $this->show_message(FALSE, '保存成功', '/c/mcard_level');
                    return false;
                }
            }
            else
            {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }
        $this->data['mcard_level'] = $mcardLevel;
        $this->load->view($this->dcm, $this->data);
    }

    /**
     * @name 编辑卡片
     * @param $id
     * @return bool
     */
    public function editcard($id)
    {
        $mcard = $this->getMcard();
        if(!$mcard)
        {
            return false;
        }
        //查询会员等级卡是否存在
        $cardlevel = $this->model->where(array('id'=>$id,'site_id'=>$mcard['site_id'],'status'=>1))->find();
        if(!$cardlevel)
        {
            $this->show_message(FALSE, '没有该等级的会员卡', '/c/mcard_level');
            return false;
        }
        if($this->input->post())
        {
            $this->form_validation->set_rules('titlecolor', '标题名称颜色', 'trim|max_length[50]|htmlspecialchars');
            $this->form_validation->set_rules('leveltitlecolor', '等级名称颜色', 'trim|max_length[50]|htmlspecialchars');
            $this->form_validation->set_rules('logo', 'LOGO', 'trim|callback__check_image');
            $this->form_validation->set_rules('titlecolor', '名称背景', 'trim|callback__check_color');
            $this->form_validation->set_rules('numbercolor', '卡号背景', 'trim|callback__check_color');
            $this->form_validation->set_rules('c_background', '自定义背景', 'trim|callback__check_image');
            if($this->form_validation->run())
            {
                $dataSet['tpl'] = $this->input->post('tpl');
                //会员卡logo
                $dataSet['logo'] = $this->form_validation->set_value('logo');
                //标题颜色
                $dataSet['titlecolor'] = $this->form_validation->set_value('titlecolor');
                //等级名颜色
                $dataSet['leveltitlecolor'] = $this->form_validation->set_value('leveltitlecolor');

                //卡号颜色
                $dataSet['numbercolor'] = $this->form_validation->set_value('numbercolor');
                //自定义背景
                $dataSet['c_background'] = $this->form_validation->set_value('c_background');

                $style = $this->input->post('style') ? $this->input->post('style') : array();

                $dataSet['style'] = $style ? implode("," , $style) : '';

                if(!$dataSet['c_background'])
                {
                    $dataSet['background'] = $this->input->post('background');
                }
                if( false===$this->model->where(array('id'=>$id))->edit($dataSet) )
                {
                    $this->show_message(FALSE, '保存失败', '');
                    return false;
                }
                else
                {
                    $this->show_message(FALSE, '保存成功', '');
                    return false;
                }
            }
            else
            {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }
        $this->data['mcard_level'] = $cardlevel;
        $this->load->view($this->dcm, $this->data);
    }

    /**
     * @name 删除一个等级
     * @param $id
     * @return bool
     */
    public function delete($id)
    {
        $mcard = $this->getMcard();
        if(!$mcard)
        {
            return false;
        }
        $cardlevel = $this->model->where(array('id'=>$id,'site_id'=>$this->site_info['id'],'status'=>1))->find();
        if(!$cardlevel)
        {
            $this->show_message(FALSE, '没有该等级的会员卡', '/c/mcard_level');
            return false;
        }
        if($cardlevel['basic'] == 1)
        {
            $this->show_message(FALSE, '该等级的会员卡不允许删除', '/c/mcard_level');
            return false;
        }
        //是否有会员领取

        if( false===$this->model->where(array('id'=>$id))->edit(array('status'=>-1)))
        {
            $this->show_message(false, '删除失败', '/c/mcard_level');
        }
        else
        {
            $cur_maxpoints = $cardlevel['maxpoints'];
            //更新前一条的等级最大值
            if($cur_maxpoints){
                $ml = $this->model->where(array('site_id'=>$this->site_info['id'], 'mcard_id'=>$mcard['id'], 'maxpoints <'=>$cur_maxpoints, 'conditions'=>2, 'status'=>1))->order_by('maxpoints', 'desc')->find();
                $this->model->where(array('site_id'=>$mcard['site_id'], 'mcard_id'=>$mcard['id'], 'id'=>$ml['id']))->edit(array('maxpoints'=>$cur_maxpoints));
            }

            $this->load->model('mcard_member_model');
            $this->mcard_member_model->where(array('site_id'=>$this->site_info['id'], 'mcard_id'=>$cardlevel['mcard_id'], 'level_id'=>$id))->edit(array('level_id'=>0));
            $this->show_message(false, '删除成功', '/c/mcard_level');
        }
    }

    /**
     * @name 查询会员卡设置
     * @return bool
     */
    private function getMcard()
    {
        $where['site_id'] = $this->site_info['id'];
        $this->load->model('mcard_model');
        $mcard = $this->mcard_model->where(array('site_id'=>$where['site_id']))->find();

        if(!$mcard)
        {
            $this->show_message(FALSE, '请先创建会员卡', '/c/mcard');
            return false;
        }
        else
        {
            return $mcard;
        }
    }

    //检查图片格式
    public function _check_image($image) {
        if ($image) {
            if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
                $this->form_validation->set_message('_check_image', '图片地址格式错误');
                return FALSE;
            }
        }
        return TRUE;
    }

    public function _check_color($color)
    {

        if($color) {
            if ( ! preg_match('/#[0-9a-fA-F]{3}|#[0-9a-fA-F]{6}$/i', $color)) {
                $this->form_validation->set_message('_check_color', '颜色格式错误');
                return FALSE;
            }
        }
        return TRUE;
    }
}