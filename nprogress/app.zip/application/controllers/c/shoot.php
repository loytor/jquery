<?php
/**
 * Created by PhpStorm.
 * User: along
 * Date: 14-5-28
 * Time: 下午3:06
 * @property Shoot_model $shoot_model
 * @property Shooter_model $shooter_model
 */

class Shoot extends C_Controller {

    private $site_id = '';
    protected $data = array();

    public function __construct()
    {
        parent::__construct();
        $this->load->model('shoot_model');
        $this->site_id = $this->site_info['id'];
    }

    /**
     * 点球游戏设置
     */
    public function index()
    {
        $where = array();
        $where['site_id'] = $this->site_id;
        $this->data['setting'] = $this->shoot_model->where($where)->find();

        $post = $this->input->post();
        if($post)
        {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('start_time','开始时间','trim|required');
            $this->form_validation->set_rules('end_time','结束时间','trim|required');
            $this->form_validation->set_rules('number','射门次数','trim|required|is_numeric');
            //$this->form_validation->set_rules('sharenumber','分享激励','trim|is_numeric');
            $this->form_validation->set_rules('firstrate','首次分享概率','trim|is_numeric|less_than_equal_to[100]');
            $this->form_validation->set_rules('custompic', '转发图标', 'trim');
            $this->form_validation->set_rules('customtitle', '转发标题', 'trim|max_length[200]');
            $this->form_validation->set_rules('virtual','虚拟参与人数','trim|is_numeric');
            if ( $this->form_validation->run() )
            {
                //开始时间
                $dataSet['start_time'] = strtotime($this->form_validation->set_value('start_time'));
                $dataSet['end_time'] = strtotime($this->form_validation->set_value('end_time'));

                $dataSet['number'] = $this->form_validation->set_value('number');
                //$dataSet['sharenumber'] = $this->form_validation->set_value('sharenumber');

                $dataSet['firstrate'] = $this->form_validation->set_value('firstrate');

                $dataSet['banner'] = $this->input->post('banner');

                //图片
                $dataSet['custompic'] = $this->form_validation->set_value('custompic');
                $dataSet['customtitle'] = $this->form_validation->set_value('customtitle');

                $dataSet['rule'] = $this->input->post('rule');
                $dataSet['prize'] = $this->input->post('prize');
                $dataSet['virtual'] = $this->input->post('virtual');

                //更新
                if($this->data['setting'])
                {
                    $this->shoot_model->where(array('site_id'=>$this->site_id))->edit($dataSet);
                }
                else
                {
                    $dataSet['site_id'] = $this->site_id;
                    $this->shoot_model->add($dataSet);
                }
                $this->show_message(true, '提交成功', '/c/shoot');return false;
            }
            else
            {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(false, $errors, '');return false;
                }
            }
        }
        else
        {
            $this->data['viewurl'] = $this->create_url('shoot');
            $this->load->view($this->dcm,$this->data);
        }

    }

    public function score()
    {
        $this->load->model('shooter_model');
        $where = " site_id = '".$this->site_id."'";
        $keyword = $this->input->get('keyword');
        $baseUrl = '/c/shoot/score/?';
        if($keyword)
        {
            $this->data['search'] = array('keyword'=>$keyword);
            $where .= " and (username like '%".$keyword."%' or tel like '%".$keyword."%')";
            $baseUrl .= 'keyword='.$keyword;
        }
        $this->data['shoot'] = $this->shoot_model->where(array('site_id' => $this->site_id))->find();

        $total_rows = $this->shooter_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$baseUrl));

        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->data['list'] = array();
        if($total_rows > 0)
        {
            $this->data['list'] = $this->shooter_model->where($where)->limit($pager['limit']['value'], $pager['limit']['offset'])->order_by('score desc')->find_all();
        }
        $this->load->view($this->dcm,$this->data);
    }

    public function export()
    {
        $this->load->model('shooter_model');
        $where = " site_id = '".$this->site_id."'";
        $keyword = $this->input->get('keyword');
        if($keyword)
        {
            $this->data['search'] = array('keyword'=>$keyword);
            $where .= " and (username like '%".$keyword."%' or tel like '%".$keyword."%')";
        }
        $list = $this->shooter_model->where($where)->order_by('score desc')->find_all();
        $shooterList = array();
        if($list)
        {
            foreach($list as $key=> $item)
            {
                $shooterList[$key]['username'] = $item['username'];
                $shooterList[$key]['tel'] = $item['tel'];
                $shooterList[$key]['shootnum'] = $item['shootnum'];
                $shooterList[$key]['score'] = $item['score'];
                $shooterList[$key]['assistsnum'] = $item['assistsnum'];
            }

            $fields = array(
                '#'=>'#',
                'username'=>'姓名',
                'tel'=>'电话',
                'shootnum'=>'射门次数',
                'score'=>'进球',
                'assistsnum'=>'助攻'
            );
            $this->excel_export('点球大战数据统计', '点球大战数据统计', $fields, $shooterList);
        }
        else
        {
            $this->show_message(false,'暂无数据可以导出','');
        }
    }
} 