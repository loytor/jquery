<?php
/**
 * Created by PhpStorm.
 * User: songxiyao
 * Date: 2014/9/19
 * Time: 16:06
 */
class Common_apps extends C_Controller {
    protected $site_id = '';
    public function __construct()
    {
        parent::__construct();
        $this->site_id = $this->site_info['id'];
        $this->load->model('common_apps_model', 'common_apps');
    }

    public function index() {
        //查询常用功能列表
        $options = array(
            'where'  => array('wid' => $this->site_id),
        );
        $this->data['common_apps_list'] = $this->common_apps->join('wb_app', 'wb_app.id = wb_common_apps.app_id', 'left')->find_all($options);
        $this->load->view($this->dcm, $this->data);
    }

    public function add() {
        $app_id = $this->input->post('app_id');
        if (!$app_id) {
            echo json_encode(array('ret' => 1, 'msg' => '缺少参数'));
            return false;
        }
        //查询是否已经添加
        $options = array(
            'select' => 'wid',
            'where'  => array('app_id' => $app_id, 'wid' => $this->site_id),
        );
        if ($this->common_apps->find($options)) {
            echo json_encode(array('ret' => 2, 'msg' => '数据已经添加'));
            return false;
        }
        $data = array(
            'wid' => $this->site_id,
            'app_id'  => $app_id
        );
        if ($this->common_apps->add($data)) {
            echo json_encode(array('ret' => 0, 'msg' => ''));
            return false;
        } else {
            echo json_encode(array('ret' => 3, 'msg' => '系统异常，添加失败'));
            return false;
        }
    }

    public function delete() {
        $app_id = $this->input->post('app_id');
        if (!$app_id) {
            echo json_encode(array('ret' => 1, 'msg' => '缺少参数'));
            return false;
        }

        $where = array(
            'wid' => $this->site_id,
            'app_id'  => $app_id
        );
        if ($this->common_apps->where($where)->delete()) {
            echo json_encode(array('ret' => 0, 'msg' => ''));
            return false;
        } else {
            echo json_encode(array('ret' => 3, 'msg' => '系统异常，删除失败'));
            return false;
        }
    }
}