<?php
/**
 * Created by solaa.
 * User: solaa
 * Date: 2014/11/21 10:19
 */

class PhotoVote_option extends C_Controller{

    public function __construct()
    {
        parent::__construct();

        $this->load->model('photoVote_model');
        $this->load->model('photoVote_option_model');

        $this->vote_model = $this->photoVote_option_model;
    }

    //投票选项列表
    public function index()
    {
        //接受参数
        $vote_id = $this->input->get('vote_id');

        //获得投票总信息
        $info = $this->photoVote_model->where(array('id' => $vote_id, 'site_id'=>$this->site_info['id']))->find();

        //获得总票数
        $total_nums = $this->vote_model->where(array('vote_id' => $vote_id, 'site_id'=>$this->site_info['id']))->sum('view_nums');

        //组织查询条件
        $list = $this->vote_model->get_list( $vote_id,$this->site_info['id']);

        //输出页面数据
        $this->data['list'] = $list;
        $this->data['search'] = $this->input->get();
        $this->data['title_name'] = $info['title'];
        $this->data['total_nums'] = $total_nums;
        $this->data['vote_id'] = $vote_id;

        //加载页面
        $this->load->view( $this->dcm, $this->data );
    }

    //修改投票数
    public function edit()
    {
        //接受参数
        $id = $this->input->get('id');
        $vote_id = $this->input->get('vote_id');
        $option_id = $this->input->post('id');
        $action = $this->input->post('action');
        $add_nums = (int) $this->input->post('add_nums');

        if($action == 'edit')
        {
            //组织相关数据
            $param = $where = array();
            $where['id'] = $option_id;
            $where['site_id'] = $this->site_info['id'];
            $param['add_nums'] = $add_nums;


            //查询原有数据
            $info = $this->vote_model->where($where)->find();
            if (!$info) {
                echo json_encode(array('status'=>'error', 'msg'=>'找不到投票选项数据'));
                exit;
            }

            //组织相关数据
            $param['view_nums'] = $info['real_nums'] + $param['add_nums'];
            if( $param['view_nums'] < 0 )
            {
                echo json_encode(array('status'=>'error', 'msg'=>'真实票数与调整票数的和不能小于零'));
                exit;
            }

            //返回结果
            $status = $this->vote_model->where($where)->edit($param);
            if( $status > 0 )
            {
                $url = '/c/photoVote_option/index/?vote_id=' . $info['vote_id'];
                echo json_encode(array('status'=>'ok', 'msg'=>'修改成功', 'url' => $url));
                exit;
            }else {
                echo json_encode(array('status'=>'error', 'msg'=>'未修改或数据错误，修改失败'));
                exit;
            }

        }

        //取得投票项数据
        $info = $this->vote_model->where(array('id' => $id))->find();

        //页面赋值
        $this->data['info'] = $info;
        $this->data['vote_id'] = $vote_id;

        //加载页面
        $this->load->view( $this->dcm, $this->data );
    }

    //导出数据
    public function export()
    {
        $vote_id = $this->input->get('vote_id');

        $where['vote_id'] = $vote_id;
        $list = $this->vote_model->get_list($vote_id, $this->site_info['id']);
        //获得总票数
        $total_nums = $this->vote_model->where(array('vote_id' => $vote_id, 'site_id'=>$this->site_info['id']))->sum('view_nums');

        if($list)
        {
            foreach($list as $key=> $item)
            {
                $mlist[$key]['index'] = $key + 1;
                $mlist[$key]['option_sn'] = $item['option_sn'];
                $mlist[$key]['title'] = $item['title'];
                $mlist[$key]['real_nums'] = $item['real_nums'];
                $mlist[$key]['view_nums'] = $item['view_nums'];
                $mlist[$key]['pre'] = round($item['view_nums'] * 100 / $total_nums) . '%' ;
            }

            $fields = array(
                'index' => '票数排名',
                'option_sn' => '选项编码',
                'title' => '选项名称',
                'real_nums' => '实际票数',
                'view_nums' => '显示票数',
                'pre' => '投票率',
            );
            $this->excel_export('投票统计', '投票统计', $fields, $mlist);
        }
        else
        {
            $this->show_message(FALSE, '尚无投票记录可导出', '/c/photoVote');
        }
    }

    //显示投票详情
    public function detail()
    {
        //显示投票人
        $option_id = $this->input->get('id');
        $vote_id = $this->input->get('vote_id');

        //查询投票选项信息
        $this->load->model('photoVote_option_model');
        $option_info = $this->photoVote_option_model->where(array('id'=> $option_id,'site_id'=> $this->site_info['id']))->find();
        if( !$option_info )
        {
            $this->show_message(FALSE, '投票选项不存在', '/c/photoVote');

        }

        //查询投票人
        $this->load->model('photoVote_user_select_model');
        $where['option_id'] = $option_id;
        $where['vote_id'] = $vote_id;
        $total = $this->photoVote_user_select_model->where($where)->count();

        //列举投票人
        $pager = $this->_pager( $total, array( 'per_page'=>15, 'base_url'=>site_url($this->uri->uri_string().'?').'&'.http_build_query( $this->input->get() ) ) );
        $list = $this->photoVote_user_select_model->get_list( $where,
            array(
                'select' => 'super_api,uid,add_time ',
                'limit'  => $pager['limit']['value'].', '.$pager['limit']['offset'],
                'order'  => 'add_time desc'
            )
        );
        //查询投票人手机号码、姓名
        $this->load->model('account_model');
        $this->load->model('member_model');
        $this->member_model->setTable($this->site_info['id']);
        foreach ($list as $key => $val) {

            //设定默认
            $list[$key]['name'] = '';
            $list[$key]['mobile'] = '';

            //组织where条件
            $info = array();
            //取出数据
            if( $val['super_api'] == 0 )
            {
                $info = $this->account_model
                    ->select('name,mobile')
                    ->where(array('id' => $val['uid']))
                    ->find();
            }
            else if( $val['super_api'] == 1   ){
                $info = $this->member_model
                    ->select('name,mobile')
                    ->where(array('id'=>$val['uid'], 'site_id'=>$this->site_info['id']))
                    ->find();
            }
            if ($info) {
                $list[$key]['name'] = $info['name'];
                $list[$key]['mobile'] = $info['mobile'];
            }
        }

        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->data['search'] = $this->input->get();
        $this->data['info'] = $option_info;

        //加载页面
        $this->load->view( $this->dcm, $this->data );
    }

    //导出投票人数据
    function export_user(){

        //显示投票人
        $option_id = $this->input->get('id');
        $vote_id = $this->input->get('vote_id');

        //查询投票选项信息
        $this->load->model('photoVote_option_model');
        $option_info = $this->photoVote_option_model->where(array('id'=> $option_id,'site_id'=> $this->site_info['id']))->find();
        if( !$option_info )
        {
            $this->show_message(FALSE, '投票选项不存在', '/c/photoVote');

        }

        //查询投票人
        $this->load->model('photoVote_user_select_model');
        $where['option_id'] = $option_id;
        $where['vote_id'] = $vote_id;
        $total = $this->photoVote_user_select_model->where($where)->count();

        //列举投票人
        $pager = $this->_pager( $total, array( 'per_page'=>15, 'base_url'=>site_url($this->uri->uri_string().'?').'&'.http_build_query( $this->input->get() ) ) );
        $list = $this->photoVote_user_select_model->get_list( $where,
            array(
                'select' => 'super_api,uid,add_time ',
                'limit'  => $pager['limit']['value'].', '.$pager['limit']['offset'],
                'order'  => 'add_time desc'
            )
        );
        //查询投票人手机号码、姓名
        $this->load->model('account_model');
        $this->load->model('member_model');
        foreach ($list as $key => $val) {

            //设定默认
            $list[$key]['name'] = '';
            $list[$key]['mobile'] = '';

            //组织where条件
            $info = array();
            //取出数据
            if( $val['super_api'] == 0 )
            {
                $info = $this->account_model
                    ->select('name,mobile')
                    ->where(array('id' => $val['uid']))
                    ->find();
            }
            else if( $val['super_api'] == 1   ){
                $this->member_model->setTable($this->site_info['id']);
                $info = $this->member_model
                    ->select('name,mobile')
                    ->where(array('id'=>$val['uid'], 'site_id'=>$this->site_info['id']))
                    ->find();
            }
            if ($info) {
                $list[$key]['name'] = $info['name'];
                $list[$key]['mobile'] = $info['mobile'];
            }
        }

        //显示文档名称抬头
        $option_sn = $option_info['option_sn'];

        //导出数据
        if($list)
        {
            foreach($list as $key=> $item)
            {
                $mlist[$key]['index'] = $key + 1;
                $mlist[$key]['name'] = $item['name'];
                $mlist[$key]['mobile'] = $item['mobile'];
                $mlist[$key]['add_time'] = date('Y-m-d H:i:s', $item['add_time']);
            }

            $fields = array(
                'index' => '序号',
                'name' => '投票人',
                'mobile' => '电话',
                'add_time' => '时间'
            );
            $this->excel_export($option_sn.'投票人信息', $option_sn.'投票人信息', $fields, $mlist);
        }
        else
        {
            $this->show_message(FALSE, '尚无投票记录可导出', '/c/photoVote');
        }

    }
}