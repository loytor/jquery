<?php
/**
 * Created by PhpStorm.
 * User: llj
 * Date: 13-12-18
 * Time: 下午10:36
 * @property Mongo_db $mongo_db
 */
class Welcome extends C_Controller
{
    private $mongo_welcome = 'welcome';

    public function __construct()
    {
        parent::__construct();
        $this->load->library('Mongo_db');
    }

    public function index()
    {
        $welcome = $this->mongo_db->where(array('site_id'=>$this->site_info['id']))->get_one($this->mongo_welcome);
        if($this->input->post()){
            $type = $this->input->post('type');
            $type = $type ? $type : 2;
            $data = array();
            if($type == 2)
            {
                $data['text'] = $this->input->post('text');
                $data['type'] = 2;
            }
            else if($type == 3)
            {
                $data['type'] = 3;
                $content['title'] = $this->input->post('m_title');
                $m_url = $this->input->post('m_url');
                if(!$m_url)
                {
                    $this->show_message(FALSE, '请上传语音或者直接填写语音链接', '');
                    return FALSE;
                }
                $content['HQmusicurl'] = $content['musicurl'] = $m_url;
                $content['description'] = $this->input->post('m_description');
                $data['musicInfo'] = json_encode($content);
            }

            if($welcome){
                $data['dt_update'] = time();
                if($this->mongo_db->where(array('site_id'=>$this->site_info['id']))->set($data)->update($this->mongo_welcome)){
                    $this->show_message(TRUE, '保存成功', '/c/welcome');
                    return FALSE;
                } else {
                    $this->show_message(FALSE, '保存失败', '');
                    return FALSE;
                }
            } else {
                $data['site_id'] = $this->site_info['id'];
                $data['type'] = 2;
                $data['dt_add'] = $data['dt_update'] = time();
                $data['content'] = '';
                if($this->mongo_db->insert($this->mongo_welcome, $data)){
                    $this->show_message(TRUE, '保存成功', '/c/welcome');
                    return FALSE;
                } else {
                    $this->show_message(FALSE, '保存失败', '');
                    return FALSE;
                }
            }
        } else {
            if($welcome && isset($welcome['content']) && $welcome['content']){
                usort($welcome['content'], array('Welcome', 'cmp'));
            }
            $this->data['welcome'] = $welcome;
            $this->data['text'] = isset($welcome['text']) && $welcome['text'] ? $welcome['text'] : '';
            $this->data['musicInfo'] = isset($welcome['musicInfo']) && $welcome['musicInfo'] ? json_decode($welcome['musicInfo'],true) : '';
            $this->load->view($this->dcm, $this->data);
        }
    }

    public function add()
    {
        if($this->input->post()){
            $this->form_validation->set_rules('title', '名称', 'required|trim|htmlspecialchars');
            $this->form_validation->set_rules('desc', '描述', 'trim|htmlspecialchars');
            if($this->form_validation->run()) {
                $item = array();
                $item['type'] = $this->input->post('type');
                if($item['type'] == 'Link') {
                    if(!$this->input->post('url')) {
                        $this->show_message(FALSE, '请填写链接', '');
                        return FALSE;
                    }
                }
                $item['id'] = new MongoId();
                $item['title'] = $this->form_validation->set_value('title');
                $item['desc'] = $this->form_validation->set_value('desc');
                if($this->input->post('image')) {
                    $item['image'] = $this->input->post('image');
                } else {
                    $item['image'] = $this->input->post('selected_img') ? $this->input->post('selected_img') : '';
                }
                $item['rank'] = $this->input->post('rank') ? intval($this->input->post('rank')) : 0;
                $this->input->post('ref_id') && $item['ref_id'] = $this->input->post('ref_id');
                $item['url'] = '';
                $this->input->post('url') && $item['url'] = $this->input->post('url');

                $welcome = $this->mongo_db->where(array('site_id'=>$this->site_info['id']))->get_one($this->mongo_welcome);
                if($welcome) {
                    $content = isset($welcome['content']) && is_array($welcome['content']) && $welcome['content'] ? $welcome['content'] : array();
                    if(count($content) > 9) {
                        $this->show_message(FALSE, '最多只能填10项', '/c/welcome');
                        return FALSE;
                    }
                    $content[] = $item;
                    if($this->mongo_db->where(array('site_id'=>$this->site_info['id']))->set(array('content'=>$content, 'dt_update'=>time()))->update($this->mongo_welcome)){
                        $this->show_message(TRUE, '保存成功', '/c/welcome');
                        return FALSE;
                    } else {
                        $this->show_message(FALSE, '保存失败', '');
                        return FALSE;
                    }
                } else {
                    $data = array();
                    $data['site_id'] = $this->site_info['id'];
                    $data['text'] = '';
                    $data['type'] = 1;
                    $data['dt_add'] = $data['dt_update'] = time();
                    $data['content'][] = $item;
                    if($this->mongo_db->insert($this->mongo_welcome, $data)){
                        $this->show_message(TRUE, '保存成功', '/c/welcome');
                        return FALSE;
                    } else {
                        $this->show_message(FALSE, '保存失败', '');
                        return FALSE;
                    }
                }
            } else {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        } else {
            $this->data['btype'] = $this->get_btype();
            $this->load->view($this->dcm, $this->data);
        }
    }

    public function edit($id='')
    {
        $welcome = $this->mongo_db->where(array('site_id'=>$this->site_info['id']))->get_one($this->mongo_welcome);
        if($this->input->post()){
            $this->form_validation->set_rules('title', '名称', 'required|trim|htmlspecialchars');
            $this->form_validation->set_rules('desc', '描述', 'trim|htmlspecialchars');
            if($this->form_validation->run()) {
                if($welcome['type'] == 1) {
                    if(isset($welcome['content']) && is_array($welcome['content'])) {
                        foreach($welcome['content'] as &$wc) {
                            if($wc['id'].'' == $id) {
                                if(isset($wc['type']) && $wc['type']) {
                                    $wc['type'] = $this->input->post('type');
                                    if($wc['type'] == 'Link') {
                                        if(!$this->input->post('url')) {
                                            $this->show_message(FALSE, '请填写链接', '');
                                            return FALSE;
                                        }
                                    }
                                    $wc['title'] = $this->form_validation->set_value('title');
                                    $wc['desc'] = $this->form_validation->set_value('desc');
                                    $wc['image'] = $this->input->post('image');
                                    if($this->input->post('image')) {
                                        $wc['image'] = $this->input->post('image');
                                    } else {
                                        $wc['image'] = $this->input->post('selected_img') ? $this->input->post('selected_img') : '';
                                    }
                                    $wc['rank'] = $this->input->post('rank') ? intval($this->input->post('rank')) : 0;
                                    $this->input->post('ref_id') && $wc['ref_id'] = $this->input->post('ref_id');
                                    $wc['url'] = '';
                                    $this->input->post('url') && $wc['url'] = $this->input->post('url');
                                } else {
                                    $wc['title'] = $this->form_validation->set_value('title');
                                    $wc['desc'] = $this->form_validation->set_value('desc');
                                    $wc['image'] = $this->input->post('image');
                                    $wc['rank'] = $this->input->post('rank') ? intval($this->input->post('rank')) : 0;
                                    $wc['rurl'] = $this->input->post('rurl');
                                    unset($wc['type']);
                                }
                                break;
                            }
                        }
                    }
                }
                if($this->mongo_db->where(array('site_id'=>$this->site_info['id']))->set(array('content'=>$welcome['content'], 'dt_update'=>time()))->update($this->mongo_welcome)){
                    $this->show_message(TRUE, '保存成功', '/c/welcome');
                    return FALSE;
                } else {
                    $this->show_message(FALSE, '保存失败', '');
                    return FALSE;
                }
            } else {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        } else {
            $this->data['cur_item'] = array();
            $bol = FALSE;
            if($welcome['type'] == 1) {
                if(isset($welcome['content']) && is_array($welcome['content'])) {
                    foreach($welcome['content'] as $wc) {
                        if($wc['id'].'' == $id) {
                            $this->data['cur_item'] = $wc;
                            $bol = TRUE;
                            break;
                        }
                    }
                }
            }
            if(!$bol) {
                $this->show_message(FALSE, '该项不存在', '/c/welcome');
                return FALSE;
            }
            $this->data['btype'] = $this->get_btype();
            if($this->data['cur_item']) {
                $cur_params = $this->data['cur_item'];
                unset($cur_params['id']);
                unset($cur_params['title']);
                unset($cur_params['rank']);
                //unset($cur_params['type']);
                unset($cur_params['image']);
                $this->data['cur_params'] = $cur_params;
            }

            $this->load->view($this->dcm, $this->data);
        }
    }

    public function toggle_type()
    {
        $type = $this->input->post('type');
        $type = $type ? $type : 1;

        $welcome = $this->mongo_db->where(array('site_id'=>$this->site_info['id']))->get_one($this->mongo_welcome);
        if($welcome) {
            if($this->mongo_db->where(array('site_id'=>$this->site_info['id']))->set(array('type'=>$type, 'dt_update'=>time()))->update($this->mongo_welcome)){
                $data['success'] = 1;
            } else {
                $data['success'] = 0;
            }
        } else {
            $data['site_id'] = $this->site_info['id'];
            $data['text'] = '';
            $data['type'] = $type;
            $data['dt_add'] = $data['dt_update'] = time();
            $data['content'] = '';
            if($this->mongo_db->insert($this->mongo_welcome, $data)){
                $data['success'] = 1;
            } else {
                $data['success'] = 0;
            }
        }

        echo json_encode($data);
    }

    public function delete($id='')
    {
        $welcome = $this->mongo_db->where(array('site_id'=>$this->site_info['id']))->get_one($this->mongo_welcome);
        $bol = FALSE;
        if($welcome['type'] == 1) {
            if(isset($welcome['content']) && is_array($welcome['content'])) {
                foreach($welcome['content'] as $wk=>&$wc) {
                    if($wc['id'].'' == $id) {
                        unset($welcome['content'][$wk]);
                        $bol = TRUE;
                        break;
                    }
                }
            }
        }
        if(!$bol) {
            $this->show_message(FALSE, '该项不存在', '/c/welcome');
            return FALSE;
        }
        if($this->mongo_db->where(array('site_id'=>$this->site_info['id']))->set(array('content'=>$welcome['content'], 'dt_update'=>time()))->update($this->mongo_welcome)){
            $this->show_message(TRUE, '删除成功', '/c/welcome');
            return FALSE;
        } else {
            $this->show_message(FALSE, '删除失败', '');
            return FALSE;
        }
    }

    public function cmp($item_a, $item_b) {
        if ($item_a['rank'] == $item_b['rank'])
            return 0;
        return ($item_a['rank'] < $item_b['rank']) ? -1 : 1;
    }
}