<?php
/**
 * Created by PhpStorm.
 * User: lufee(ldw1007@sina.cn)
 * Date: 14-8-19
 * Time: 下午6:23
 */

class Ip_black extends C_Controller{
    protected $auto_load_model = TRUE;
    protected $model_name = 'ip_blacklist';
    private $ip_black_chief = 'chief';
    public function __construct()
    {
        parent::__construct();
        $this->load->model('ip_blacklist_model');
        $this->site_id = $this->site_info['id'];
    }

    public function index()
    {
        $where = array('site_id'=>$this->site_id,'type'=>$this->ip_black_chief);
        $total_rows = $this->model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15));

        $list = $this->model->order_by('id desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->where($where)->find_all();
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->data['prew_url'] = $this->site_info['all_domain'] ? $this->site_info['all_domain'] : 'http://'.$this->site_info['domain'].BASE_DOMAIN;
        $this->load->view($this->dcm, $this->data);
    }

    public function ipforbid()
    {
        $ip = trim($this->input->post('ip'));
        $lasttime = trim($this->input->post('lasttime'));
        $ipstatus = trim($this->input->post('ipstatus'));
        if(!$ip)
        {
            exit( json_encode( array('ret'=>1000,'msg'=>'IP地址错误') ) );
        }
        $ipinfo = $this->ip_blacklist_model->where(array('ip'=>$ip,'site_id'=>$this->site_id,'type'=>$this->ip_black_chief))->find();
        if(!$ipinfo)
        {
            $data['site_id'] = $this->site_id;
            $data['ip'] = $ip;
            $data['type'] = $this->ip_black_chief;
            $data['inputtime'] = time();
            $data['last_action_time'] = $lasttime;  //最后操作时间
            $data['status'] = 0;
            $this->ip_blacklist_model->add($data);
        }else{
            if($ipinfo['status'] == 0)
            {
                //解封
                $dataedit = array(
                    'status'=>1,
                    'relieve_time'=>time()
                );
            }else{
                //封禁
                $dataedit = array(
                    'status'=>0,
                    'last_action_time'=>$lasttime,
                    'inputtime'=>time()
                );
            }
            $this->ip_blacklist_model->where(array('ip'=>$ip,'site_id'=>$this->site_id,'type'=>$this->ip_black_chief))->edit($dataedit);
        }
        exit( json_encode( array('ret'=>0,'msg'=>'设置成功') ) );
    }

    public function edit($id)
    {
        if(!$id)
        {
            exit( json_encode( array('ret'=>1000,'msg'=>'非法参数') ) );
        }
        $ipinfo = $this->ip_blacklist_model->where(array('id'=>$id))->find();
        if($ipinfo['status'] == 0)
        {
            //解封
            $dataedit = array(
                'status'=>1,
                'relieve_time'=>time()
            );
        }else{
            //封禁
            $dataedit = array(
                'status'=>0,
                'inputtime'=>time()
            );
        }
        $this->ip_blacklist_model->where(array('id'=>$id))->edit($dataedit);
        $this->show_message(false, '操作成功', '/c/ip_black');
    }
}