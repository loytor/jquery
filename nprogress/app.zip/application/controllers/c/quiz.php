<?php
/**
 * Created by PhpStorm.
 * User: along
 * Date: 14-6-10
 * Time: 下午12:30
 * @property Quiz_model $quiz_model
 * @property Quiz_option_model $quiz_option_model
 * @property Quiz_record_model $quiz_record_model
 */

class Quiz extends C_Controller {


    public function __construct()
    {
        parent::__construct();
        $this->site_id = $this->site_info['id'];
        $this->load->model('quiz_model');
        $this->load->model('quiz_option_model');
    }

    public function index()
    {
        $where = array();
        $where['site_id'] = $this->site_id;
        //$where['status'] = 1;
        $total = $this->quiz_model->where($where)->count();
        $pager = $this->_pager($total, array('per_page'=>15));

        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->data['list'] = array();
        if($total > 0)
        {
            $this->data['list'] = $this->quiz_model->where($where)->limit($pager['limit']['value'],$pager['limit']['offset'])->order_by('id desc')->find_all();
        }
        $this->data['viewurl'] = $this->create_url('jingcai');
        $this->load->view($this->dcm,$this->data);
    }

    public function set()
    {
        $id = $this->input->get_post('id');
        $quiz = array();
        if($id)
        {
            $quiz = $this->getOneQuiz($id);
        }

        if($this->input->post())
        {
            $this->form_validation->set_rules('title', '竞猜标题', 'trim|required|max_length[20]');
            $this->form_validation->set_rules('description', '竞猜描述', 'trim|max_length[400]');
            $this->form_validation->set_rules('rules', '竞猜规则', 'trim|required');
            $this->form_validation->set_rules('background', '背景图片', 'trim');
            $this->form_validation->set_rules('custompic', '自定义图片', 'trim');
            $this->form_validation->set_rules('customtitle', '自定义标题', 'trim|max_length[100]');
            $this->form_validation->set_rules('virtual','虚拟参与人数','trim|is_numeric');
            if ( $this->form_validation->run() )
            {
                $data['title'] = $this->form_validation->set_value('title');
                $data['description'] = $this->form_validation->set_value('description');
                $data['rules'] = $this->form_validation->set_value('rules');
                $data['background'] = $this->form_validation->set_value('background');
                $data['custompic'] = $this->form_validation->set_value('custompic');
                $data['customtitle'] = $this->form_validation->set_value('customtitle');
                $data['virtual'] = $this->input->post('virtual');
                if($quiz)
                {
                    $this->quiz_model->where(array('id'=>$quiz['id']))->edit($data);
                }
                else
                {
                    $data['site_id'] = $this->site_id;
                    $data['dt_add'] = time();
                    $this->quiz_model->add($data);
                }
                $this->show_message(true, '提交成功', '/c/quiz');return false;
            }
            else
            {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(false, $errors, '');return false;
                }
            }
        }
        else
        {
            $this->data['quiz'] = $quiz;
            $this->load->view($this->dcm,$this->data);
        }
    }

    public function op_list()
    {
        $where['site_id'] = $this->site_id;
        $qid = $this->input->get('qid');
        if($qid)
        {
            $where['qid'] = $qid;
        }
        $total_rows = $this->quiz_option_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15));

        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->data['list'] = array();
        if($total_rows > 0)
        {
            $this->data['list'] = $this->quiz_option_model->where($where)->limit($pager['limit']['value'],$pager['limit']['offset'])->order_by('id desc')->find_all();
        }
        $this->data['qid'] = $qid;
        $this->load->view($this->dcm,$this->data);
    }

    public function opAdd()
    {
        $qid = $this->input->get('qid');
        $quiz = $this->getOneQuiz($qid);
        if(!$quiz)
        {
            $this->show_message(false, '请先添加竞猜', '/c/quiz');return false;
        }
        $post = $this->input->post();
        if($post)
        {
            $this->form_validation->set_rules('firstpic', '选项图片', 'trim|required');
            $this->form_validation->set_rules('firstplayer', '选项名', 'trim|required');
            $this->form_validation->set_rules('secondpic', '选项图片', 'trim|required');
            $this->form_validation->set_rules('secondplayer', '选项名', 'trim|required');
            $this->form_validation->set_rules('end_time', '截止时间', 'trim|required');
            $this->form_validation->set_rules('rule', '竞猜规则', 'trim|required');
            if ( $this->form_validation->run() )
            {
                $data['firstpic'] = $this->form_validation->set_value('firstpic');
                $data['firstplayer'] = $this->form_validation->set_value('firstplayer');
                $data['secondpic'] = $this->form_validation->set_value('secondpic');
                $data['secondplayer'] = $this->form_validation->set_value('secondplayer');
                $data['end_time'] = strtotime($this->form_validation->set_value('end_time'));
                $data['rule'] = $this->form_validation->set_value('rule');
                $data['qid'] = $qid;
                $data['site_id'] = $this->site_id;
                $data['dt_add'] = time();
                $this->quiz_option_model->add($data);
                $this->show_message(true, '添加成功', '/c/quiz/op_list/?qid='.$qid);return false;
            }
            else
            {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(false, $errors, '');return false;
                }
            }
        }
        else
        {
            $this->load->view($this->dcm,$this->data);
        }
    }

    public function opEdit($id = '')
    {
        $op = $this->quiz_option_model->where(array('id'=>$id))->find();
        if(!$op || $op['site_id'] != $this->site_id)
        {
            $this->show_message(false, '该选项不存在', '');return false;
        }
        //$quiz = $this->getOneQuiz($op['qid']);

        if($this->input->post())
        {
            $this->form_validation->set_rules('firstpic', '选项图片', 'trim|required');
            $this->form_validation->set_rules('firstplayer', '选项名', 'trim|required');
            $this->form_validation->set_rules('secondpic', '选项图片', 'trim|required');
            $this->form_validation->set_rules('secondplayer', '选项名', 'trim|required');
            $this->form_validation->set_rules('end_time', '截止时间', 'trim|required');
            $this->form_validation->set_rules('rule', '竞猜规则', 'trim|required');
            if ( $this->form_validation->run() )
            {
                $data['firstpic'] = $this->form_validation->set_value('firstpic');
                $data['firstplayer'] = $this->form_validation->set_value('firstplayer');
                $data['secondpic'] = $this->form_validation->set_value('secondpic');
                $data['secondplayer'] = $this->form_validation->set_value('secondplayer');
                $data['rule'] = $this->form_validation->set_value('rule');
                $data['end_time'] = strtotime($this->form_validation->set_value('end_time'));

                $this->quiz_option_model->where(array('id'=>$op['id']))->edit($data);
                $this->show_message(true, '编辑成功', '');return false;
            }
            else
            {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(false, $errors, '');return false;
                }
            }
        }
        $this->data['option'] = $op;
        $this->load->view($this->dcm,$this->data);
    }

    public function opDis($id = '')
    {
        $op = $this->quiz_option_model->where(array('id'=>$id))->find();
        if(!$op || $op['site_id'] != $this->site_id)
        {
            $this->show_message(false, '该选项不存在', '');return false;
        }
        if($op['status'] == -1)
        {
            //是否已公布结果
            if($op['results'])
            {
                $this->show_message(false, '已公布结果，不能上线', '/c/quiz/op_list/?qid='.$op['qid']);return false;
            }
            $editdata['status'] = 1;
        }
        else
        {
            $editdata['status'] = -1;
        }
        $this->quiz_option_model->where(array('id'=>$id))->edit($editdata);
        $this->show_message(false, '操作成功', '/c/quiz/op_list/?qid='.$op['qid']);return false;
    }

    public function setResult($id = '')
    {
        $op = $this->quiz_option_model->where(array('id'=>$id))->find();
        if(!$op || $op['site_id'] != $this->site_id)
        {
            $this->show_message(false, '该选项不存在', '/c/quiz/op_list/?qid='.$op['qid']);return false;
        }
        //$quiz = $this->getOneQuiz();
        if($op['results'])
        {
            $this->show_message(false, '已公布结果，请不要重复操作', '/c/quiz/op_list/?qid='.$op['qid']);return false;
        }
        if($this->input->post())
        {
            $winResult = $this->input->post('result');
            if(!$winResult)
            {
                $this->show_message(false, '请选择要公布的结果', '');return false;
            }
            /*
            //是否在截止时间内
            if(time() < $op['end_time'])
            {
                $this->show_message(false, '竞猜还在截止时间内，请先结束竞猜！', '/c/quiz/opEdit/'.$op['id']);return false;
            }
            */
            $editData['results'] = $winResult;
            //竞猜结束
            $editData['status'] = -1;
            if( $this->quiz_option_model->where(array('id'=>$id))->edit($editData) ){
                //更新榜单
                $this->load->model('quiz_record_model');
                $record = $this->quiz_record_model->select('id,open_id,option_id,result')->where(array('qid'=>$op['qid'],'option_id'=>$op['id']))->find_all();
                if( $record ){
                    $this->load->model('quiz_bangdan_model');
                    foreach( $record as $val ){
                        if( $val['result']==$winResult ){
                            if( $bangdan=$this->quiz_bangdan_model->where(array('qid'=>$op['qid'],'open_id'=>$val['open_id']))->find() ){
                                $save_data['win_num'] = $bangdan['win_num']+1;
                                $this->quiz_bangdan_model->where(array('id'=>$bangdan['id']))->edit($save_data);
                            }else{
                                $add_data['win_num'] = 1;
                                $add_data['site_id'] = $this->site_id;
                                $add_data['qid'] = $op['qid'];
                                $add_data['open_id'] = $val['open_id'];
                                $this->quiz_bangdan_model->add($add_data);
                            }
                        }
                    }
                }
            }

            $this->show_message(true, '公布结果成功', '/c/quiz/op_list/?qid='.$op['qid']);return false;
        }
        else
        {
            //$this->data['quiz'] = $quiz;
            $this->data['op'] = $op;
            $this->load->view($this->dcm,$this->data);
        }
    }

    public function del($id = '')
    {
        $quiz = $this->getOneQuiz($id);
        if(!$quiz)
        {
            $this->show_message(false, '该竞猜不存在', '/c/quiz/index');return false;
        }
        $edit['status'] = ($quiz['status'] == 1) ? -1 : 1;
        $this->quiz_model->where(array('id'=>$quiz['id']))->edit($edit);
        $this->show_message(false, '操作成功', '/c/quiz/index');return false;
    }

    public function opSta()
    {
        $id = $this->input->get('id',true);
        $op = $this->quiz_option_model->where(array('id'=>$id))->find();
        if(!$op || $op['site_id'] != $this->site_id)
        {
            $this->show_message(false, '竞猜选项不存在', '');return false;
        }
        $this->data['option'] = $op;
        $search = array();
        $this->load->model('quiz_record_model');
        $where = " wb_quiz_record.site_id = '".$this->site_id."' and wb_quiz_record.option_id = ".$id;

        $search_url = '/c/quiz/opSta/?id='.$id;

        $results = $this->input->get('results');
        if($results)
        {
            $search['results'] = $results;
            $where .= " and wb_quiz_record.result = ".$results;
            $search_url .= '&results='.$results;
        }
        $keyword = $this->input->get('keyword');
        if($keyword)
        {
            $search['keyword'] = $keyword;
            $where .= " and (wb_quiz_user.username like '%".$keyword."%' or wb_quiz_user.mobile like '%".$keyword."%')";
            $search_url .= '&keyword='.$keyword;
        }
        //$where .= " and wb_quiz_user.qid = ".$op['qid'];
        $this->data['search'] = $search;

        $total = $this->quiz_record_model
                       ->join('wb_quiz_user','wb_quiz_record.open_id=wb_quiz_user.open_id and wb_quiz_user.qid = '.$op['qid'],'left')
                       ->where($where)
                       ->count();

        $pager = $this->_pager($total, array('per_page'=>15,'base_url'=>$search_url));

        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->data['list'] = array();
        if($total > 0)
        {
            $this->data['list'] = $this->quiz_record_model
                ->select('wb_quiz_user.username,wb_quiz_user.mobile,wb_quiz_record.result,wb_quiz_record.dt_add')
                ->join('wb_quiz_user','wb_quiz_record.open_id=wb_quiz_user.open_id and wb_quiz_user.qid = '.$op['qid'],'left')
                ->where($where)
                ->limit($pager['limit']['value'], $pager['limit']['offset'])
                ->find_all();
            foreach($this->data['list'] as &$_list)
            {
                //精彩选项
                if($_list['result'] == 1)
                {
                    $_list['jc_option'] = $op['firstplayer'];
                }
                elseif($_list['result'] == 2)
                {
                    $_list['jc_option'] = '平局';
                }
                elseif($_list['result'] == 3)
                {
                    $_list['jc_option'] = $op['secondplayer'];
                }
                //竞猜结果
                if($op['results'] == 0)
                {
                    $_list['jc_result'] = '未公布';
                }
                else
                {
                    $_list['jc_result'] = ($op['results'] == $_list['result']) ? '<span class="label label-success">正确</span>' : '<span class="label label-important">错误</span>';
                }
                $_list['dt_add'] = date('Y-m-d H:i:s',$_list['dt_add']);
            }

        }
        $this->load->view($this->dcm,$this->data);
    }

    public function opExport()
    {
        $id = $this->input->get('id',true);
        $op = $this->quiz_option_model->where(array('id'=>$id))->find();
        if(!$op || $op['site_id'] != $this->site_id)
        {
            $this->show_message(false, '竞猜选项不存在', '');return false;
        }

        $this->load->model('quiz_record_model');
        $where = " wb_quiz_record.site_id = '".$this->site_id."' and wb_quiz_record.option_id = ".$id;

        $results = $this->input->get('results');
        if($results)
        {
            $where .= " and wb_quiz_record.result = ".$results;
        }
        $keyword = $this->input->get('keyword');
        if($keyword)
        {
            $where .= " and (wb_quiz_user.username like '%".$keyword."%' or wb_quiz_user.mobile like '%".$keyword."%')";
        }

        $list = $this->quiz_record_model
            ->select('wb_quiz_user.username,wb_quiz_user.mobile,wb_quiz_record.result,wb_quiz_record.dt_add')
            ->join('wb_quiz_user','wb_quiz_record.open_id=wb_quiz_user.open_id and wb_quiz_user.qid = '.$op['qid'],'left')
            ->where($where)
            ->find_all();
        $opList = array();
        if($list)
        {
            foreach($list as $key=> $_list)
            {
                $opList[$key]['username'] = $_list['username'] ? $_list['username'] : '-';
                $opList[$key]['mobile'] = $_list['mobile'] ? $_list['mobile'] : '-';
                //精彩选项
                if($_list['result'] == 1)
                {
                    $opList[$key]['jc_option'] = $op['firstplayer'];
                }
                elseif($_list['result'] == 2)
                {
                    $opList[$key]['jc_option'] = '平局';
                }
                elseif($_list['result'] == 3)
                {
                    $opList[$key]['jc_option'] = $op['secondplayer'];
                }
                //竞猜结果
                if($op['results'] == 0)
                {
                    $opList[$key]['jc_result'] = '未公布';
                }
                else
                {
                    $opList[$key]['jc_result'] = ($op['results'] == $_list['result']) ? '正确' : '错误';
                }
                $opList[$key]['dt_add'] = date('Y-m-d H:i:s',$_list['dt_add']);
            }

            $fields = array(
                '#'=>'#',
                'username'=>'姓名',
                'mobile'=>'手机号',
                'jc_option'=>'竞猜项',
                'jc_result'=>'竞猜结果',
                'dt_add' => '竞猜时间'
            );
            $this->excel_export($op['firstplayer'].'VS'.$op['secondplayer'].'竞猜结果统计', '竞猜结果数据统计', $fields, $opList);
        }
        else
        {
            $this->show_message(false,'暂无数据可以导出','');
        }
    }

    private function getOneQuiz($id)
    {
        //默认根据site_id取
        $quiz = $this->quiz_model->where(array('id'=>$id))->find();
        if(!$quiz || $quiz['site_id'] != $this->site_id)
        {
            return false;
        }
        else
        {
            return $quiz;
        }
    }

    //榜单
    public function bangdan($id='')
    {
        $quiz = $this->getOneQuiz($id);
        if( !$quiz ){
            $this->show_message(false, '竞猜不存在', '');return false;
        }

        $where['wb_quiz_bangdan.site_id'] = $this->site_id;
        $where['wb_quiz_bangdan.qid'] = $quiz['id'];
        $this->load->model('quiz_bangdan_model');

        $bangdan_list = $this->quiz_bangdan_model->select('wb_quiz_bangdan.open_id,wb_quiz_bangdan.win_num,wb_quiz_user.username,wb_quiz_user.mobile')
            ->join('wb_quiz_user','wb_quiz_user.open_id=wb_quiz_bangdan.open_id AND wb_quiz_user.qid='.$quiz['id'],'left')
            ->where($where)
            ->order_by('wb_quiz_bangdan.win_num desc')
            ->find_all();

        if( $bangdan_list ){

            $this->load->model('quiz_record_model');

            $i = $j = 1;
            $score_num = 0;
            foreach( $bangdan_list as &$val ){
                if( $score_num==0 ){
                    $score_num = $val['win_num'];
                }
                if( $score_num==$val['win_num'] ){
                    $val['paiming'] = $j;
                }else{
                    $score_num = $val['win_num'];
                    $val['paiming'] = $i;
                    $j = $i;
                }
                $i++;

                if( !$val['username'] ){
                    $val['username'] = '---';
                }
                if( !$val['mobile'] ){
                    $val['mobile'] = '---';
                }
            }
            if( isset($_GET['export']) ){
                $this->bangdan_export($bangdan_list);
            }
        }

        $pager = $this->_pager(count($bangdan_list), array('per_page'=>15));
        $page = intval($this->input->get('page',true));
        $page = $page ? $page : 1;
        $start = ($page-1)*15;
        $this->data['list'] = array_slice($bangdan_list,$start,15);
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->load->view($this->dcm, $this->data);
    }

    //导出榜单
    public function bangdan_export($list='')
    {
        $fields = array(
            '#'=>'#',
            'paiming'=>'排名',
            'username'=>'姓名',
            'mobile'=>'手机号'
        );
        $this->excel_export('竞猜榜单', '竞猜榜单', $fields, $list);
    }

}