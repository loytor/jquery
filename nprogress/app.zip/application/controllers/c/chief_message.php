<?php
/**
 * Created by PhpStorm.
 * User: lufee(ldw1007@sina.cn)
 * Date: 14-8-18
 * Time: 下午6:26
 */

class Chief_message extends C_Controller
{
    protected $auto_load_model = TRUE;
    protected $model_name = 'chief_message';
    public function __construct()
    {
        parent::__construct();
        $this->load->model('chief_message_model');
        $this->site_id = $this->site_info['id'];
    }

    public function index($chiefid)
    {
        if(!$chiefid)
        {
            $this->show_message(false, '非法参数', '/c/chief');
            return FALSE;
        }
        $this->load->model('chief_model');
        $chief = $this->chief_model->where(array('id'=>$chiefid))->find();
        if(!$chief)
        {
            $this->show_message(false, '政务不存在', '/c/chief');
            return FALSE;
        }
        $where = array('chief_id'=>$chiefid);
        $like = array();
        ($id = $this->input->get('id')) && $like['id'] = $id;
        ($name= $this->input->get('name')) && $like['name'] = $name;
        ($mobile= $this->input->get('mobile')) && $like['mobile'] = $mobile;
        ($from_time = $this->input->get('from_time')) && $where['dt_add >='] = strtotime($from_time);
        ($to_time = $this->input->get('to_time')) && $where['dt_add <='] = strtotime($to_time);
        $reply_status = $this->input->get('reply_status');
        if($reply_status == 1 || $reply_status == 2)
        {
            $where['reply_status'] = $reply_status-1;
        }
        ($appraise_status = $this->input->get('appraise_status')) && $where['appraise_status'] = $appraise_status;
        $handle_status = $this->input->get('handle_status');
        if($handle_status == 1 || $handle_status == 2 || $handle_status == 3)
        {
            $where['handle_status'] = $handle_status-1;
        }

        $total_rows = $this->model->where($where)->like($like)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15));

        $list = $this->model->order_by('id desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->where($where)->like($like)->find_all();

        //获取评论选项
        $this->load->model('chief_appraise_model');
        $appraiselist = $this->chief_appraise_model->where(array('chief_id'=>$chiefid))->find_all();

        $this->data['chiefid'] = $chiefid;
        $this->data['appraise'] = $appraiselist;
        $this->data['search'] = $this->input->get();
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->data['prew_url'] = $this->site_info['all_domain'] ? $this->site_info['all_domain'] : 'http://'.$this->site_info['domain'].BASE_DOMAIN;
        $this->load->view($this->dcm, $this->data);
    }

    public function detail($id)
    {
        $logged_user_id = logged_user_id();
        if ( ! $logged_user_id) {
            redirect_return('/auth/login');
        }
        if(!$id)
        {
            $this->show_message(false, '非法参数', '/c/chief');
            return FALSE;
        }
        $chiefMessage = $this->model->where(array('id'=>$id))->find();
        if(!$chiefMessage)
        {
            $this->show_message(false, '不存在该留言', '/c/chief');
            return FALSE;
        }
        $this->load->model('chief_log_model');
        $post = $this->input->post();
        if($post)
        {
            //添加受理记录
            $data['chief_message_id'] = $id;
            $data['dt_add'] = time();
            $data['status'] = 0;
            $messageData = array('reply_status'=>1);
            $hasHandle = $this->chief_log_model->where(array('chief_message_id'=>$id,'handle_status'=>1))->find();
            if(!$hasHandle)
            {
                $data['content'] = '设为已处理';
                $data['handle_status'] = 1;
                $this->chief_log_model->add($data);
                //改变状态
                $messageData['handle_status'] = 1;
            }
            if($hasHandle && !$this->chief_log_model->where(array('chief_message_id'=>$id,'handle_status'=>2))->find())
            {
                $data['content'] = '设为处理完毕';
                $data['handle_status'] = 2;
                $this->chief_log_model->add($data);
                $messageData['handle_status'] = 2;
            }
            if($this->input->post('content'))
            {
                $data['content'] = htmlspecialchars($this->input->post('content'));
                $data['handle_status'] = 0;
                $this->chief_log_model->add($data);
            }
            $this->model->where('id',$id)->edit($messageData);
            $this->show_message(false, '操作成功', '/c/chief_message/detail/'.$id);
        }else{
            //读取受理记录
            $logList = $this->chief_log_model->where(array('chief_message_id'=>$id))->find_all();
            if($logList)
            {
                foreach($logList as &$v)
                {
                    $v['dt_add'] = date('Y-m-d H:i:s',$v['dt_add']);
                    $v['content'] = htmlspecialchars_decode($v['content']);
                }
            }
            $this->data['loglist'] = $logList;
            $chiefMessage['ip'] = $chiefMessage['ip'];
            $this->load->model('ip_blacklist_model');
            $ipinfo = $this->ip_blacklist_model->where(array('site_id'=>$this->site_id,'ip'=>$chiefMessage['ip'],'type'=>'chief'))->find();
            if(!$ipinfo || $ipinfo['status'] == 1)
            {
                $chiefMessage['ip_status'] = 1;
            }else{
                $chiefMessage['ip_status'] = 0;
            }
            //最后操作时间TODO
            $lastdata = $this->model->where(array('mobile'=>$chiefMessage['mobile']))->limit(1)->order_by('id desc')->find();
            $chiefMessage['img_url'] = explode(",",$chiefMessage['img_url']);
            if($chiefMessage['img_url'])
            {
                foreach($chiefMessage['img_url'] as &$img)
                {
                    $img = $img ? image_full_url($img) : '';
                }
            }
            $this->data['lasttime'] = $lastdata['dt_add'];
            $this->data['data'] = $chiefMessage;
            $token_data = array('user_id' => $logged_user_id, 'time' => time());
            $this->data['token'] = $this->encrypt->encode(serialize($token_data));
            $this->load->view($this->dcm, $this->data);
        }
    }

    //更改是否隐藏状态
    public function set_status($id)
    {
        if(!$id)
        {
            exit( json_encode( array('ret'=>1000,'msg'=>'非法参数') ) );
        }
        $status = $this->input->post('status') == 1 ? 0 : 1;
        if($this->model->where(array('id'=>$id))->edit(array('status'=>$status)))
        {
            exit( json_encode( array('ret'=>0,'msg'=>'设置成功') ) );
        }else{
            exit( json_encode( array('ret'=>1001,'msg'=>'管理员，出错啦..') ) );
        }
    }

    //更改处理状态,设置成已处理
    public function set_handle_status($id)
    {
        if(!$id)
        {
            exit( json_encode( array('ret'=>1000,'msg'=>'非法参数') ) );
        }
        if($this->model->where(array('id'=>$id))->edit(array('handle_status'=>1)))
        {
            $this->load->model('chief_log_model');
            $this->chief_log_model->where(array('chief_message_id'=>$id,'handle_status'=>2))->delete();
            exit( json_encode( array('ret'=>0,'msg'=>'设置成功') ) );
        }else{
            exit( json_encode( array('ret'=>1001,'msg'=>'管理员，出错啦..') ) );
        }
    }

    //导出
    public function export()
    {
        $chiefid = $this->input->get('chiefid');
        if(!$chiefid)
        {
            $this->show_message(false, '非法参数', '/c/chief');
            return FALSE;
        }
        $this->load->model('chief_model');
        $chief = $this->chief_model->where(array('id'=>$chiefid))->find();
        if(!$chief)
        {
            $this->show_message(false, '政务不存在', '/c/chief');
            return FALSE;
        }
        $where = array('chief_id'=>$chiefid);
        $like = array();
        ($id = $this->input->get('id')) && $like['id'] = $id;
        ($name= $this->input->get('name')) && $like['name'] = $name;
        ($mobile= $this->input->get('mobile')) && $like['mobile'] = $mobile;
        ($from_time = $this->input->get('from_time')) && $where['dt_add >='] = strtotime($from_time);
        ($to_time = $this->input->get('to_time')) && $where['dt_add <='] = strtotime($to_time);
        $reply_status = $this->input->get('reply_status');
        if($reply_status == 1 || $reply_status == 2)
        {
            $where['reply_status'] = $reply_status-1;
        }
        ($appraise_status = $this->input->get('appraise_status')) && $where['appraise_status'] = $appraise_status;
        $handle_status = $this->input->get('handle_status');
        if($handle_status == 1 || $handle_status == 2 || $handle_status == 3)
        {
            $where['handle_status'] = $handle_status-1;
        }

        $total_rows = $this->model->where($where)->like($like)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>15));

        $list = $this->model->order_by('id desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->where($where)->like($like)->find_all();
        $chiefList = array();
        if($list)
        {
            foreach($list as $key=> $item)
            {
                $chiefList[$key]['id'] = $item['id'];
                $chiefList[$key]['name'] = $item['name'];
                $chiefList[$key]['mobile'] = $item['mobile'];
                $chiefList[$key]['dt_add'] = date('Y-m-d H:i:s',$item['dt_add']);
                $chiefList[$key]['content'] = $item['content'];
                $chiefList[$key]['reply_status'] = $item['reply_status'] == 1 ? '已回复' : '待回复';
                $chiefList[$key]['handle_status'] = $item['handle_status'] == 2 ? '受理完毕' : $item['handle_status'] == 1 ? '已受理' : '未受理';
                $chiefList[$key]['status'] = $item['status'] == 1 ? '公开' : '隐藏';
            }

            $fields = array(
                'id'=>'受理码',
                'name'=>'姓名',
                'mobile'=>'电话',
                'dt_add'=>'提交时间',
                'content'=>'内容',
                'reply_status'=>'回复状态',
                'handle_status'=>'处理状态',
                'status'=>'公开状态'
            );
            $this->excel_flush_export( $fields, $chiefList,'留言数据导出');
        }
        else
        {
            $this->show_message(false,'暂无数据可以导出','');
        }
    }
}