<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 全景组图管理
 */
class Panorama_ap extends C_Controller {

    protected $data = '';
    private $site_id = '';

    public function __construct()
    {
        parent::__construct();
        $this->site_id = $this->site_info['id'];

        $this->load->model('panorama_model');
        $this->load->model('user_model');
    }

    public function index()
    {
        $where['type'] = '1';
        $where['site_id'] = $this->site_id;
        $total_rows = $this->panorama_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>10));
        $total_rows = $this->panorama_model->where($where)->limit($pager['limit']['value'], $pager['limit']['offset'])->order_by('id asc')->find_all();
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->data['list'] = $total_rows;
        if($this->data['list'])
        {
            foreach($this->data['list'] as &$mscat)
            {
                $site_id = $mscat['site_id'];
                $url = $this->create_url('panorama?id='.$mscat['id']);
                $mscat['url']= $url;
            }
        }
        $this->load->view($this->dcm,$this->data);
    }
    public function add()
    {
        $where['type'] = '0';
        $alls = $this->panorama_model->where($where)->find_all();
        $this->data['list'] = $alls;
        $where_o['type'] = '0';
        $where_o['site_id'] = $this->site_id;
        $total_rowss = $this->panorama_model->where($where_o)->find_all();
        $html = '';
        foreach ($total_rowss as $key => &$row) {
            if($key==0){
                $html .= '<option value="'.$row['id'].'" selected="selected">'.$row['title'].'</option>';
            }else{
                $html .= '<option value="'.$row['id'].'">'.$row['title'].'</option>';
            }
        }
        $this->data['html'] = $html;
        $this->load->view($this->dcm,$this->data);

    }
    /*
     * 编辑组合全景
     */
    public function adds()
    {
        if($this->input->post('title')){
            $title = $this->input->post('title');
        }
        if($this->input->post('pan_id')){
            $id = $this->input->post('pan_id');
        }
        if($this->input->post('title_name')){
            $title_name = $this->input->post('title_name');
            $save_all['title'] = $title_name;
            if($this->panorama_model->where(array('id'=>$id))->edit($save_all)){
            }else{
                $this->show_message(false, '添加失败', '');
            }
        }
        $all_id=array();
        if($this->input->post('ass')){
            $assp = $this->input->post('ass');
            foreach ($assp as $key => &$row){
                if(!$row['title'] || !$row['order'] || !$row['selects']){
                    $this->show_message(false, '修改失败', '');
                    return FALSE;
                }
                $save_data['type'] = 2;
                $save_data['site_id'] = $this->site_id;
                $save_data['title'] = $row['title'];
                $save_data['order'] = $row['order'];
                $save_data['address'] = $row['selects'];
                $save_data['parent_id'] = $id;
                $save_data['add_time'] = time();
                if($this->panorama_model->where(array('id'=>$row['id']))->edit($save_data)){
                    array_push($all_id,$row['id']);
                }else{
                    $this->show_message(false, '修改失败', '');
                    return FALSE;
                }
            }

            $where_ass['parent_id']=$id;
            $querys = $this->panorama_model->where_not_in('id',$all_id)->where($where_ass)->find_all();
            $counts = count($querys);
            $del_id=array();
            if($counts){
                foreach ($querys as $key => &$row){
                    array_push($del_id,$row['id']);
                }
                if(!$this->input->post('menu')){
                    $this->panorama_model->where_in('id',$del_id)->delete();
                }
            }

        }else{
            if(!$this->input->post('menu')){
                $where_all['parent_id']=$id;
                $query = $this->panorama_model->where($where_all)->delete();
                if($query){
                    $this->show_message(true, '修改成功', '/c/panorama_ap/index');
                }else{
                    $this->show_message(false, '添加失败', '');
                    return FALSE;
                }
            }
        }
        if($this->input->post('ass') && !$this->input->post('menu')){
            $this->show_message(true, '修改成功', '/c/panorama_ap/index');
        }
        $res=false;
        if($this->input->post('menu')){
            $menus = $this->input->post('menu');
            foreach ($menus as $key => &$row) {
                if(!$row['title'] || !$row['order'] || !$row['selects']){
                    $this->show_message(false, '添加失败', '');
                    return FALSE;
                }
                $save_data['type'] = 2;
                $save_data['site_id'] = $this->site_id;
                $save_data['title'] = $row['title'];
                $save_data['order'] = $row['order'];
                $save_data['address'] = $row['selects'];
                $save_data['parent_id'] = $id;
                $save_data['add_time'] = time();
                if($this->panorama_model->add($save_data)){
                    $res=true;
                }
            }
            if($res){
                $this->show_message(true, '添加成功', '/c/panorama_ap/index');
            }
        }else{
        }
    }
    public function edit($id = '')
    {
        if(!$id){
            $this->show_message(false, '非法参数', '');return false;
        }
        $cate = $this->panorama_model->where(array('id'=>$id))->find();
        if(!$cate){
            $this->show_message(false, '指标不存在', '');return false;
        }else{
            if($cate['site_id']!=$this->site_id){
                $this->show_message(false, '无权限', '');return false;
            }
            if($cate['type']!=1){
                $this->show_message(false, '指标不存在', '');return false;
            }
        }
        $where_o['type'] = '0';
        $where_o['site_id'] = $this->site_id;
        $total_rowss = $this->panorama_model->where($where_o)->find_all();
        $html = '';
        foreach ($total_rowss as $key => &$row) {
            if($key==0){
                $html .= '<option value="'.$row['id'].'" selected="selected">'.$row['title'].'</option>';
            }else{
                $html .= '<option value="'.$row['id'].'">'.$row['title'].'</option>';
            }
        }
        $this->data['html'] = $html;
        $where_ass['type']=0;
        $where_ass['site_id']=$this->site_id;
        $where['parent_id'] = $id;
        $where['site_id'] = $this->site_id;
        $wheres['id'] = $id;
        $total = $this->panorama_model->where($wheres)->find();
        $total_rows = $this->panorama_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>10));
        $total_rows = $this->panorama_model->where($where)->limit($pager['limit']['value'], $pager['limit']['offset'])->order_by('order  ASC')->find_all();
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->data['list'] = $total_rows;
        if($this->data['list'])
        {
            foreach($this->data['list'] as &$mscat)
            {
                $site_id = $mscat['site_id'];
                $url = $this->create_url('panorama?id='.$mscat['address']);
                $mscat['url']= $url;
            }
        }
        foreach ($this->data['list'] as $key => &$goods) {
            if($goods['address']){
                $where_p['id'] = $goods['address'];
                $where_p['site_id'] = $this->site_id;
                $totals = $this->panorama_model->where($where_p)->find();
                $pin = array();
                array_push($pin,$totals['id']);
                $querys = $this->panorama_model->where_not_in('id',$pin)->where($where_ass)->find_all();
                $goods['s'] = $querys;
                $goods['op'] = $totals['id'];
                $goods['val'] = $totals['title'];
            }
        }
        $this->data['name'] = $total['title'];
        $this->data['id'] = $id;
        if( $this->input->post() ){
            $this->form_validation->set_rules('title', '标题', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('p_back', 'back', 'trim|required|callback__check_image');
            $this->form_validation->set_rules('p_bottom', 'bottom', 'trim|required|callback__check_image');
            $this->form_validation->set_rules('p_front', 'front', 'trim|required|callback__check_image');
            $this->form_validation->set_rules('p_left', 'left', 'trim|required|callback__check_image');
            $this->form_validation->set_rules('p_right', 'right', 'trim|required|callback__check_image');
            $this->form_validation->set_rules('p_top', 'top', 'trim|required|callback__check_image');
            if ( $this->form_validation->run() ){
                $save_data['title'] = $this->form_validation->set_value('title');
                $save_data['pic_back'] = $this->form_validation->set_value('p_back');
                $save_data['pic_bottom'] = $this->form_validation->set_value('p_bottom');
                $save_data['pic_front'] = $this->form_validation->set_value('p_front');
                $save_data['pic_left'] = $this->form_validation->set_value('p_left');
                $save_data['pic_right'] = $this->form_validation->set_value('p_right');
                $save_data['pic_top'] = $this->form_validation->set_value('p_top');
                if(false === $this->panorama_model->where(array('id'=>$id))->edit($save_data) ){
                    $this->show_message(false, '编辑失败', '');
                }else{
                    $this->show_message(true, '编辑成功', '/c/panarama_ap');
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            $this->data['info'] = $cate;
            $this->load->view($this->dcm,$this->data);
        }
    }
    /*
     * 添加组合全景
     */
    public function puts()
    {
        if($this->input->post('title_name')){
            $title_name = $this->input->post('title_name');
            $save_all['site_id'] = $this->site_id;
            $save_all['type'] = 1;
            $save_all['title'] = $title_name;
            $save_all['add_time'] = time();
            if($ids=$this->panorama_model->add($save_all)){
                $all_id = $this->db->insert_id();
            }else{
                $this->show_message(false, '添加失败', '');
            }
        }else{
            $this->show_message(false, '组合全景名称为空', '');
        }
        $res=false;
        if($this->input->post('menu')){
            $menus = $this->input->post('menu');
            foreach ($menus as $key => &$row) {
                if(!$row['title'] || !$row['order'] || !$row['selects']){
                    $this->show_message(false, '添加失败', '');
                    return FALSE;
                }
                $save_data['type'] = 2;
                $save_data['site_id'] = $this->site_id;
                $save_data['title'] = $row['title'];
                $save_data['order'] = $row['order'];
                $save_data['address'] = $row['selects'];
                $save_data['parent_id'] = $all_id;
                $save_data['add_time'] = time();
                if($this->panorama_model->add($save_data)){
                    $res=true;
                }
            }
            if($res){
                $this->show_message(true, '添加成功', '/c/panorama_ap/index');
            }
        }else{
            $this->show_message(false, '添加失败', '');
            return FALSE;
        }

    }
    /**
     * @name 删除
     * @param string $id
     * @return bool
     */
    public function deletes($id = '')
    {
        if(!$id){
            $this->show_message(false, '非法参数', '');return false;
        }
        $cate = $this->panorama_model->where(array('id'=>$id))->find();
        if(!$cate){
            $this->show_message(false, '全景图不存在', '/c/panorama_ap/index');return false;
        }
        $this->panorama_model->where(array('id'=>$id))->delete();
        $this->show_message(true, '删除成功!', '/c/panorama_ap/index');return false;
    }
    public function options(){
        $where['type'] = '0';
        $total_rows = $this->panorama_model->where($where)->find_all();
        $html = '';
        foreach ($total_rows as $key => &$row) {
            if($key==0){
                $html .= '<option value="'.$row['id'].'" selected="selected">'.$row['title'].'</option>';
            }else{
                $html .= '<option value="'.$row['id'].'">'.$row['title'].'</option>';
            }
        }
        echo $html;
    }
    //检查名称
    public function _check_title($title) {
        if ($title) {
            $cate = $this->panorama_model->like('title',$title)->where(array('type'=>2))->count();
            if($cate)
            {
                $this->form_validation->set_message('_check_title', '名称已经存在');
                return FALSE;
            }
        }
        return TRUE;
    }
    //检查名称
    public function _check_alltitle($title) {
        if ($title) {
            $cate = $this->panorama_model->like('title',$title)->where(array('type'=>1))->count();
            if($cate)
            {
                $this->form_validation->set_message('_check_alltitle', '名称已经存在');
                return FALSE;
            }
        }
        return TRUE;
    }
}