<?php
/**
 * Created by PhpStorm.
 * User: lufee ldw1007@sina.cn
 * Date: 14-7-16
 * Time: 下午4:51
 */

class Wxstore extends C_Controller {
    public function index(){
        $this->load->view($this->dcm,$this->data);
    }
}