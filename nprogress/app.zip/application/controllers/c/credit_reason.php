<?php
/**
 * Created by PhpStorm.
 * User: llj
 * Date: 14-2-24
 * Time: 下午6:18
 */
//操作原因设置
class Credit_reason extends C_Controller {

    public function index() {
        $where['site_id'] = $this->site_info['id'];
        $this->load->model('credit_reason_model');
        $list = $this->credit_reason_model->order_by('sort asc')->where($where)->find_all();
        $this->data['list'] = $list;
        $this->load->view($this->dcm, $this->data);
    }

    public function add() {
        if($this->input->post()){
            $this->form_validation->set_rules('reason', '操作原因', 'trim|required|htmlspecialchars');
            if($this->form_validation->run()) {
                $data['site_id'] = $this->site_info['id'];
                $data['reason'] = $this->form_validation->set_value('reason');
                $data['sort'] = $this->input->post('sort') ? $this->input->post('sort') : 255;
                $this->load->model('credit_reason_model');
                if($this->credit_reason_model->add($data)) {
                    $this->show_message(TRUE, '添加成功', '/c/credit_reason');
                    return FALSE;
                } else {
                    $this->show_message(FALSE, '添加失败', '');
                    return FALSE;
                }
            } else {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        } else {
            $this->load->view($this->dcm, $this->data);
        }
    }

    public function edit($id)
    {
        $this->load->model('credit_reason_model');
        $reason = $this->credit_reason_model->where(array('id'=>$id, 'site_id'=>$this->site_info['id']))->find();
        if(!$reason) {
            $this->show_message(FALSE, '没有该操作原因', '/c/credit_reason');
            return FALSE;
        }

        if ($this->input->post())
        {
            $this->form_validation->set_rules('reason', '操作原因', 'trim|required|htmlspecialchars');
            if($this->form_validation->run()) {
                $data['reason'] = $this->form_validation->set_value('reason');
                $data['sort'] = $this->input->post('sort') ? $this->input->post('sort') : 255;
                if($this->credit_reason_model->where(array('id'=>$id, 'site_id'=>$this->site_info['id']))->edit($data)) {
                    $this->show_message(TRUE, '编辑成功', '/c/credit_reason');
                    return FALSE;
                } else {
                    $this->show_message(FALSE, '编辑失败', '');
                    return FALSE;
                }
            } else {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }
        else
        {
            $this->data['reason'] = $reason;
            $this->load->view($this->dcm,$this->data);
        }
    }

    public function delete($id) {
        $this->load->model('credit_reason_model');
        $reason = $this->credit_reason_model->where(array('id'=>$id, 'site_id'=>$this->site_info['id']))->find();
        if(!$reason) {
            $this->show_message(FALSE, '没有该操作原因', '/c/credit_reason');
            return FALSE;
        }

        if( $this->credit_reason_model->where(array('id'=>$id, 'site_id'=>$this->site_info['id']))->delete() ){
            $this->show_message(TRUE, '删除成功', '/c/credit_reason');
            return FALSE;
        } else {
            $this->show_message(FALSE, '删除失败', '/c/credit_reason');
            return FALSE;
        }
    }
}