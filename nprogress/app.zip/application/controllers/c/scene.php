<?php
/**
 * Created by PhpStorm.
 * User: llj
 * Date: 14-1-4
 * Time: 上午11:30
 * 微现场
 * @property Mongo_db $mongo_db
 * @property Scene_model $scene_model
 * @property Scene_member_model $scene_member_model
 * @property Scene_wall_model $scene_wall_model
 * @property Scene_wall_msg_model $scene_wall_msg_model
 * @property Scene_lottery_model $scene_lottery_model
 * @property Scene_shake_model $scene_shake_model
 */
class Scene extends C_Controller
{
    protected $mongo_table = 'scene_fields';

    public function __construct()
    {
        parent::__construct();
        $this->load->library('Mongo_db');
    }

    public function index()
    {
        //删除所有自定义字段
        //$this->mongo_db->where(array('site_id'=>$this->site_info['id']))->delete_all($this->mongo_table);

        $this->load->model('scene_model');
        $total_rows = $this->scene_model->where(array('site_id'=>$this->site_info['id']))->count();
        $pager = $this->_pager($total_rows);
        $list = $this->scene_model->where(array('site_id'=>$this->site_info['id']))->order_by('dt_start asc')->limit($pager['limit']['value'], $pager['limit']['offset'])->find_all();

        $this->data['list'] = $list ? $list : array();
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->data['scene_url'] = $this->site_info['all_domain'] ? $this->site_info['all_domain'] : 'http://'.$this->site_info['domain'].BASE_DOMAIN;;
        $this->load->view($this->dcm, $this->data);
    }

    public function add()
    {
        if($this->input->post()) {
            $this->form_validation->set_rules('title', '标题', 'required|trim|max_length[20]|htmlspecialchars');
            $this->form_validation->set_rules('code', '活动关键词', 'required|trim|max_length[30]|callback_code_check');
            $this->form_validation->set_rules('func[]', '功能', 'required');
            $this->form_validation->set_rules('dt_start', '活动开始时间', 'required');
            $this->form_validation->set_rules('dt_end', '活动结束时间', 'required');
            $this->form_validation->set_rules('password', '场控密码', 'required|min_length[6]|max_length[8]');
            if($this->input->post('set') == 1){
                $this->form_validation->set_rules('appid', 'appid', 'required|trim|htmlspecialchars');
                $this->form_validation->set_rules('appsecret', 'appsecret', 'required|trim|htmlspecialchars');
            }

            if($this->form_validation->run()) {
                $data = array();
                $data['site_id'] = $this->site_info['id'];
                $data['title'] = $this->form_validation->set_value('title');
                $data['code'] = $this->form_validation->set_value('code');
                $func = array('wall'=>0, 'lottery'=>0, 'shake'=>0, 'pairup'=>0, 'vote'=>0);
                $post_func = $this->input->post('func') ? $this->input->post('func') : array();
                $func = array_merge($func, $post_func);
                $data['func'] = json_encode($func);
                $navbar = $func;
                if (isset($navbar['lottery']) && $navbar['lottery']) {
                    $navbar['lottery_free'] = 1;
                }
                if (isset($navbar['shake']) && $navbar['shake']) {
                    $navbar['shake_free'] = 1;
                }
                $data['navbar'] = json_encode($navbar);
                $data['dt_start'] = strtotime($this->form_validation->set_value('dt_start'));
                $data['dt_end'] = strtotime($this->form_validation->set_value('dt_end'));
                $data['password'] = md5($this->form_validation->set_value('password'));
                $data['condition'] = 0;
                $data['required_mobile'] = $this->input->post('required_mobile') ? $this->input->post('required_mobile') : 0;
                $data['required_name'] = $this->input->post('required_name') ? $this->input->post('required_name') : 0;

                $data['on'] = $this->input->post('on');
                $data['is_plaintext'] = $this->input->post('is_plaintext') ? $this->input->post('is_plaintext') : 0;
                $data['dt_add'] = time();
                $data['set'] =  $this->input->post('set') ? $this->input->post('set') : 0;
                if($this->input->post('set') == 1){
                    $data['appid'] = $this->input->post('appid');
                    $data['appsecret'] = $this->input->post('appsecret');
                }


                $this->load->model('scene_model');
                if($scene_id = $this->scene_model->add($data)) {

                    $this->mongo_db->where(array("scene_id"=>'','site_id'=>$this->site_info['id']))->set(array('scene_id'=>(int)$scene_id))->update_all($this->mongo_table);
                    $this->show_message(TRUE, '添加成功', '/c/scene');
                    return FALSE;
                } else {
                    $this->show_message(FALSE, '添加失败', '');
                    return FALSE;
                }
            } else {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        } else {

            $this->load->view($this->dcm, $this->data);
        }
    }

    public function edit($id)
    {
        $this->load->model('scene_model');
        $scene = $this->scene_model->where(array('site_id'=>$this->site_info['id'], 'id'=>$id))->find();
        if(!$scene) {
            $this->show_message(FALSE, '该微现场不存在', '/c/scene');
            return FALSE;
        }

        if($this->input->post()) {
            $this->form_validation->set_rules('title', '标题', 'required|trim|max_length[20]|htmlspecialchars');
            $this->form_validation->set_rules('code', '活动关键词', 'required|trim|max_length[30]|callback_code_check['.$scene['code'].']');
            $this->form_validation->set_rules('func[]', '功能', 'required');
            if($this->input->post('dt_start')) {
                $this->form_validation->set_rules('dt_start', '活动开始时间', 'required');
            }
            if($this->input->post('dt_end')) {
                $this->form_validation->set_rules('dt_end', '活动结束时间', 'required');
            }
            if($this->input->post('password')) {
                $this->form_validation->set_rules('password', '场控密码', 'required|min_length[6]|max_length[8]');
            }
            if($this->input->post('set') == 1){
                $this->form_validation->set_rules('appid', 'appid', 'required|trim|htmlspecialchars');
                $this->form_validation->set_rules('appsecret', 'appsecret', 'required|trim|htmlspecialchars');
            }
            $this->form_validation->set_rules('memo', '备注', 'max_length[100]');
            if($this->form_validation->run()) {
                $data = array();
                $data['title'] = $this->form_validation->set_value('title');
                $data['code'] = $this->form_validation->set_value('code');
                $func = array('wall'=>0, 'lottery'=>0, 'shake'=>0, 'pairup'=>0, 'vote'=>0);
                $post_func = $this->input->post('func') ? $this->input->post('func') : array();
                $func = array_merge($func, $post_func);
                $data['func'] = json_encode($func);
                $navbar = $func;
                if (isset($navbar['lottery']) && $navbar['lottery']) {
                    $navbar['lottery_free'] = 1;
                } else {
                    //$navbar['lottery_free'] = 0;
                }
                if (isset($navbar['shake']) && $navbar['shake']) {
                    $navbar['shake_free'] = 1;
                } else {
                    //$navbar['shake_free'] = 0;
                }
                $data['navbar'] = json_encode($navbar);
                $this->input->post('dt_start') && $data['dt_start'] = strtotime($this->form_validation->set_value('dt_start'));
                $this->input->post('dt_end') && $data['dt_end'] = strtotime($this->form_validation->set_value('dt_end'));
                $this->input->post('password') && $data['password'] = md5($this->form_validation->set_value('password'));

                $data['required_mobile'] = $this->input->post('required_mobile') ? $this->input->post('required_mobile') : 0;
                $data['required_name'] = $this->input->post('required_name') ? $this->input->post('required_name') : 0;

                $data['on'] = $this->input->post('on');
                $data['is_plaintext'] = $this->input->post('is_plaintext') ? $this->input->post('is_plaintext') : 0;
                $data['set'] =  $this->input->post('set') ? $this->input->post('set') : 0;
                if($this->input->post('set') == 1){
                    $data['appid'] = $this->input->post('appid');
                    $data['appsecret'] = $this->input->post('appsecret');
                }
                if($this->scene_model->where(array('site_id'=>$this->site_info['id'], 'id'=>$id))->edit($data)) {
                    $this->show_message(TRUE, '编辑成功', '/c/scene');
                    return FALSE;
                } else {
                    $this->show_message(FALSE, '编辑失败', '');
                    return FALSE;
                }
            } else {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }
        else
        {
            $scene['func'] = json_decode($scene['func'], TRUE);
            $this->data['scene'] = $scene;
            $this->load->view($this->dcm, $this->data);
        }
    }


    public function delete($id)
    {
        $this->load->model('scene_model');
        $scene = $this->scene_model->where(array('site_id'=>$this->site_info['id'], 'id'=>$id))->find();
        if(!$scene) {
            $this->show_message(FALSE, '该微现场不存在', '/c/scene');
            return FALSE;
        }

        if($this->scene_model->where(array('site_id'=>$this->site_info['id'], 'id'=>$id))->delete()) {
            //删除对于摇一摇的过滤表记录
            $this->load->model('scene_shake_parter_filter_model');
            $this->scene_shake_parter_filter_model->where(array('scene_id'=>(int)$id))->delete();

            //删除完善信息的自定义字段
            $this->mongo_db->where(array("scene_id"=>$id, 'site_id'=>$this->site_info['id']))->delete($this->mongo_table);

            $this->show_message(TRUE, '删除成功', '/c/scene');
            return FALSE;
        } else {
            $this->show_message(FALSE, '删除失败', '/c/scene');
            return FALSE;
        }
    }

    public function statistics($id)
    {
        $this->load->model('scene_model');
        $scene = $this->scene_model->where(array('site_id'=>$this->site_info['id'], 'id'=>$id))->find();
        if(!$scene) {
            $this->show_message(FALSE, '该微现场不存在', '/c/scene');
            return FALSE;
        }
        $this->load->model('scene_member_model');
        $where['scene_id'] = $scene['id'];
        $where['nick_name != '] = '';
        $total_rows = $this->scene_member_model->where($where)->count();
        $pager = $this->_pager($total_rows);
        $list = $this->scene_member_model->where($where)->order_by('dt_join desc')->limit($pager['limit']['value'], $pager['limit']['offset'])->find_all();
        foreach($list as $k => $v){
            if(!empty($list[$k]['fields'])){
                $list[$k]['fields'] = json_decode($v['fields'],true);
                $arr = $list[$k]['fields'];
                foreach($list[$k]['fields'] as $key => $val){
                    $list[$k]['new_field'] = isset($list[$k]['new_field']) ? $list[$k]['new_field'] . '<br/>' .$val['name'].':'.$val['value'] : $val['name'].':'.$val['value'];
                }
            }else{
                $list[$k]['new_field'] = '-';
            }

        }
        $this->data['list'] = $list ? $list : array();
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        $this->data['total'] = $total_rows;
        $this->data['scene'] = $scene;
        $this->load->view($this->dcm, $this->data);
    }

    public function wall()
    {
        $this->load->model('scene_model');
        $this->load->model('scene_wall_model');
        $this->load->model('scene_member_model');
        $this->load->model('scene_wall_msg_model');
        $scenes = $this->scene_model->select('id')->where(array('site_id'=>$this->site_info['id']))->find_all();
        if ($scenes) {
            $sids = array();
            foreach($scenes as $s) {
                $sids[] = $s['id'];
            }

            $total_rows = $this->scene_wall_model->where_in('scene_id', $sids)->count();
            $pager = $this->_pager($total_rows);
            $list = $this->scene_wall_model->where_in('scene_id', $sids)->limit($pager['limit']['value'], $pager['limit']['offset'])->order_by('dt_add desc')->find_all();
            $list = $list ? $list : array();
            foreach($list as &$item) {
                $item['join_count'] = $this->scene_member_model->where(array('scene_id'=>$item['scene_id']))->count();
                $item['msg_count'] = $this->scene_wall_msg_model->where(array('wall_id'=>$item['id']))->count();
            }

            $this->data['list'] = $list;
            $this->data['page'] = $pager['links'];
            $this->data['offset'] = $pager['limit']['offset'];
        } else {
            $this->data['list'] = array();
            $this->data['page'] = '';
            $this->data['offset'] = 0;
        }
        $this->load->view($this->dcm, $this->data);
    }

    public function lottery()
    {
        $this->load->model('scene_model');
        $this->load->model('scene_lottery_model');
        $this->load->model('scene_member_model');
        $scenes = $this->scene_model->select('id')->where(array('site_id'=>$this->site_info['id']))->find_all();
        if ($scenes) {
            $sids = array();
            foreach($scenes as $s) {
                $sids[] = $s['id'];
            }

            $total_rows = $this->scene_lottery_model->where_in('scene_id', $sids)->count();
            $pager = $this->_pager($total_rows);
            $list = $this->scene_lottery_model->where_in('scene_id', $sids)->limit($pager['limit']['value'], $pager['limit']['offset'])->order_by('dt_add desc')->find_all();
            $list = $list ? $list : array();
            foreach($list as &$item) {
                $item['join_count'] = $this->scene_member_model->where(array('scene_id'=>$item['scene_id']))->count();
            }

            $this->data['list'] = $list;
            $this->data['page'] = $pager['links'];
            $this->data['offset'] = $pager['limit']['offset'];
        } else {
                $this->data['list'] = array();
                $this->data['page'] = '';
                $this->data['offset'] = 0;
        }
        $this->load->view($this->dcm, $this->data);
    }

    public function shake()
    {
        $this->load->model('scene_model');
        $this->load->model('scene_shake_model');
        $this->load->model('scene_member_model');
        $scenes = $this->scene_model->select('id')->where(array('site_id'=>$this->site_info['id']))->find_all();
        if ($scenes) {
            $sids = array();
            foreach($scenes as $s) {
                $sids[] = $s['id'];
            }

            $total_rows = $this->scene_shake_model->where_in('scene_id', $sids)->count();
            $pager = $this->_pager($total_rows);
            $list = $this->scene_shake_model->where_in('scene_id', $sids)->limit($pager['limit']['value'], $pager['limit']['offset'])->order_by('dt_add desc')->find_all();
            $list = $list ? $list : array();
            foreach($list as &$item) {
                $item['join_count'] = $this->scene_member_model->where(array('scene_id'=>$item['scene_id']))->count();
            }

            $this->data['list'] = $list;
            $this->data['page'] = $pager['links'];
            $this->data['offset'] = $pager['limit']['offset'];
        } else {
            $this->data['list'] = array();
            $this->data['page'] = '';
            $this->data['offset'] = 0;
        }
        $this->load->view($this->dcm, $this->data);
    }

    //对对碰
    public function pairup()
    {
        $this->load->model('scene_model');
        $this->load->model('scene_pairup_model');
        $this->load->model('scene_member_model');
        $scenes = $this->scene_model->select('id')->where(array('site_id'=>$this->site_info['id']))->find_all();
        if ($scenes) {
            $sids = array();
            foreach($scenes as $s) {
                $sids[] = $s['id'];
            }

            $total_rows = $this->scene_pairup_model->where_in('scene_id', $sids)->count();
            $pager = $this->_pager($total_rows);
            $list = $this->scene_pairup_model->where_in('scene_id', $sids)->limit($pager['limit']['value'], $pager['limit']['offset'])->order_by('dt_add desc')->find_all();
            $list = $list ? $list : array();
            $this->load->model('scene_pairup_parter_model');
            foreach($list as &$item) {
                $item['join_count'] = $this->scene_pairup_parter_model->where(array('pairup_id'=>$item['id']))->count();
            }

            $this->data['list'] = $list;
            $this->data['page'] = $pager['links'];
            $this->data['offset'] = $pager['limit']['offset'];
        } else {
            $this->data['list'] = array();
            $this->data['page'] = '';
            $this->data['offset'] = 0;
        }
        $this->load->view($this->dcm, $this->data);
    }

    //投票
    public function vote()
    {
        $this->load->model('scene_model');
        $this->load->model('scene_vote_model');
        $this->load->model('scene_member_model');
        $scenes = $this->scene_model->select('id')->where(array('site_id'=>$this->site_info['id']))->find_all();
        if ($scenes) {
            $sids = array();
            foreach($scenes as $s) {
                $sids[] = $s['id'];
            }

            $total_rows = $this->scene_vote_model->where_in('scene_id', $sids)->count();
            $pager = $this->_pager($total_rows);
            $list = $this->scene_vote_model->where_in('scene_id', $sids)->limit($pager['limit']['value'], $pager['limit']['offset'])->order_by('dt_add desc')->find_all();
            $list = $list ? $list : array();
            $this->load->model('scene_vote_parter_model');
            foreach($list as &$item) {
                $item['join_count'] = $this->scene_vote_parter_model->where(array('vote_id'=>$item['id']))->count();
            }

            $this->data['list'] = $list;
            $this->data['page'] = $pager['links'];
            $this->data['offset'] = $pager['limit']['offset'];
        } else {
            $this->data['list'] = array();
            $this->data['page'] = '';
            $this->data['offset'] = 0;
        }
        $this->load->view($this->dcm, $this->data);
    }

    public function code_check($code, $cur_code='')
    {
        $this->load->model('scene_model');
        $where['site_id'] = $this->site_info['id'];
        $where['code'] = $code;
        $cur_code && $where['code != '] = $cur_code;
        $scene = $this->scene_model->where($where)->find();
        if($scene) {
            $this->form_validation->set_message('code_check', '%s不能重复');
            return FALSE;
        }
        return TRUE;
    }
}