<?php
/**
 * Created by PhpStorm.
 * User: llj
 * Date: 13-11-28
 * Time: 上午11:58
 * @property Mongo_db $mongo_db
 */
class Field_manager extends C_Controller
{
    private $normal_field_types = array(
        'gender' => '性别',
        'age' => '年龄',
        'birthday' => '生日',
        'height' => '身高',
        'weight' => '体重',
        'blood' => '血型',
        'marry' => '婚姻状况',
        'constellation' => '星座',
        'zodiac' => '生肖',
        'edu' => '学历',
        'profession' => '职业',
        'zip' => '邮编',
        'email' => '邮箱'
    );

    private $custom_field_types = array(
        'text' => '单行文本',
        'textarea' => '多行文本',
        'radio' => '单选按钮',
        'checkbox' => '复选框',
        'dropdown' => '下拉框',
        'number' => '数字',
        'datetime' => '日期和时间'
    );

    protected $mongo_table = 'account_fields';

    public function __construct()
    {
        parent::__construct();
        $this->load->library('Mongo_db');
    }
    /**
     * 基本设置
     */
    public function index()
    {
        $total_rows = $this->mongo_db->where(array('wid'=>$this->site_info['id']))->count($this->mongo_table);
        $pager = $this->_pager($total_rows, array('per_page'=>5));
        $list = $this->mongo_db->where(array('wid'=>$this->site_info['id']))->limit($pager['limit']['value'])->offset($pager['limit']['offset'])->order_by(array('sort', 'ASC'))->get($this->mongo_table);
        foreach($list as &$item)
        {
            $item['type'] = isset($this->normal_field_types[$item['type']]) ? $this->normal_field_types[$item['type']] : $this->custom_field_types[$item['type']];
        }
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['curr_page'] = $this->input->get('page') ? $this->input->get('page') : 0;
        $this->data['offset'] = $pager['limit']['offset'];
        $this->load->view($this->dcm, $this->data);
    }

    /**
     * 添加字段
     */
    public function add()
    {
        if ($this->input->post()) {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('type', '字段类型', 'trim|required');
            $this->form_validation->set_rules('title', '字段名称', 'trim|required');
            if ( $this->form_validation->run() ) {
                $data = $this->input->post();
                if(isset($data['setting']) && isset($data['setting']['options'])) {
                    $data['setting']['options'] = explode(PHP_EOL, $data['setting']['options']);
                    if(isset($data['setting']) && isset($data['setting']['defaultvalue']) && $data['setting']['defaultvalue']) {
                        if(!in_array($data['setting']['defaultvalue'], $data['setting']['options'])) {
                            $this->show_message(TRUE, '默认值必须是选项里的值', '/c/field_manager/add');
                            return FALSE;
                        }
                    }
                }
                $data['sort'] = (int)$data['sort'];
                $data['wid'] = $this->site_info['id'];
                if($this->mongo_db->insert($this->mongo_table, $data)) {
                    $this->show_message(TRUE, '添加成功', '/c/field_manager');
                    return FALSE;
                } else {
                    $this->show_message(FALSE, '添加失败', '/c/field_manager/add');
                    return FALSE;
                }
            } else {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        } else {
            $this->data['normal_field_types'] = $this->normal_field_types;
            $this->data['custom_field_types'] = $this->custom_field_types;
            $this->load->view($this->dcm, $this->data);
        }
    }

    /**
     * 编辑字段
     */
    public function edit($id, $curr_page)
    {
        $field = $this->mongo_db->where(array("_id"=>new MongoId("$id"), 'wid'=>$this->site_info['id']))->get_one($this->mongo_table);
        if(!$field) {
            $this->show_message(FALSE, '没有该字段', 1);
        }
        if($this->input->post()) {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('type', '字段类型', 'trim|required');
            $this->form_validation->set_rules('title', '字段名称', 'trim|required');
            if ( $this->form_validation->run() ) {
                $data = $this->input->post();
                if(isset($data['setting']) && isset($data['setting']['options']))
                {
                    $data['setting']['options'] = explode(PHP_EOL, $data['setting']['options']);
                    if(isset($data['setting']) && isset($data['setting']['defaultvalue']) && $data['setting']['defaultvalue']) {
                        if(!in_array($data['setting']['defaultvalue'], $data['setting']['options'])) {
                            $this->show_message(TRUE, '默认值必须是选项里的值', '/c/field_manager/edit/'.$id.'/'.$curr_page);
                            return FALSE;
                        }
                    }
                }
                $data['sort'] = (int)$data['sort'];
                if($this->mongo_db->where(array("_id"=>new MongoId($id), 'wid'=>$this->site_info['id']))->set($data)->update($this->mongo_table)) {
                    $this->show_message(TRUE, '编辑成功', '/c/field_manager?page='.$curr_page);
                    return FALSE;
                } else {
                    $this->show_message(FALSE, '编辑失败', '/c/field_manager/edit/'.$id.'/'.$curr_page);
                    return FALSE;
                }
            } else {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        } else {
            $this->data['field'] = $field;
            //print_r($field);
            $this->data['normal_field_types'] = $this->normal_field_types;
            $this->data['custom_field_types'] = $this->custom_field_types;
            $this->load->view($this->dcm, $this->data);
        }
    }

    /**
     * @param string $id
     */
    public function delete($id='', $curr_page=0)
    {
        $field = $this->mongo_db->where(array("_id"=>new MongoId("$id"), 'wid'=>$this->site_info['id']))->get_one($this->mongo_table);
        if(!$field) {
            $this->show_message(FALSE, '没有该字段', 1);
        }
        if($this->mongo_db->where(array("_id"=>new MongoId("$id"), 'wid'=>$this->site_info['id']))->delete($this->mongo_table)) {
            $this->show_message(TRUE, '删除成功', '/c/field_manager?page='.$curr_page);
        } else {
            $this->show_message(FALSE, '删除失败', '/c/field_manager?page='.$curr_page);
        }
    }

    /**
     * ajax请求相关参数设置
     */
    public function params($id='')
    {
        if($id) {
            $field = $this->mongo_db->where(array("_id"=>new MongoId("$id"), 'wid'=>$this->site_info['id']))->get_one($this->mongo_table);
            if(!$field) {
                $this->show_message(FALSE, '没有该字段', 1);
            }
            $this->data['field'] = $field;
        }

        $type = $this->input->post('type');
        $this->data['type'] = $type;
        return $this->load->view($this->dcm, $this->data);
    }

/*    public function convert()
    {
        $table = 'account_field_value';
        $new_table = 'account_field_value_new';
        $this->load->library('Mongo_db');
        $list = $this->mongo_db->order_by(array('sort' => 'ASC'))->get($table);
        $list = $list ? $list : array();
        //$tmpArr = array();
        //$i = 1;
        foreach($list as $item)
        {
            $fv = $this->mongo_db->where(array('wid'=>$item['wid'], 'uid'=>$item['uid']))->get_one($new_table);
            if($fv) { //更新
                var_dump($fv);
                $this->mongo_db->where(array('wid'=>$item['wid'], 'uid'=>$item['uid']))->set($item['field_id'], $item['value'])->update($new_table);
                echo "update:<br>";var_dump($this->mongo_db->last_query());
            } else {
                //$data['_id'] = $i;
                $data = array();
                $data['wid'] = $item['wid'];
                $data['uid'] = $item['uid'];
                $data[$item['field_id']] = $item['value'];
                //var_dump($data);

                $this->mongo_db->insert($new_table, $data);
                var_dump($data);
                //$i++;
                //echo "insert:<br>";
                //var_dump($this->mongo_db->last_query());
            }
        }
    }*/
}