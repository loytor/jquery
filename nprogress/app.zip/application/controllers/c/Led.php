<?php
/**
 * Created by PhpStorm.
 * User: 111
 * Date: 14-11-5
 * Time: 下午7:51
 */
class Led extends WB_Controller{
    protected $status_info;
    protected $id;
    public function __construct() {
        parent::__construct();
        $this->id = $this->input->get('id');

        $this->load->model('lineup_model');
        //查询开启信息
        $options = array(
            'select' => 'id, status',
            'where'  => array(
                'wid' => $this->id
            ),
        );
        $this->status_info = $this->lineup_model->find($options);
    }


    //此方法暂时保留
    public function Led(){
        $this->load->model('lineup_config_model');
        $this->load->model('lineup_model');
        $this->load->model('user_model');
        $this->load->model('lineup_member_model');
        $wid = $this->lineup_model->select('wid,qrcode')->where(array('id' => $this->status_info['id']))->find();
        $name = $this->lineup_config_model->select('name')->where(array('lineup_id' => $this->status_info['id']))->find();
        $this->data['name'] = $name['name'];
        $this->data['qrcode'] = $wid['qrcode'];
        $this->data['id'] = $this->status_info['id'];
        $this->load->view('/c/lineup/led',$this->data);

    }

    public function refreshLed(){
        $id = $this->input->get('wid');
        $this->load->model('lineup_config_model');
        $this->load->model('lineup_model');
        $this->load->model('user_model');
        $this->load->model('lineup_member_model');
        $setting = $this->lineup_config_model->select('*')->where(array('lineup_id' => $id))->find();
        $types = json_decode($setting['cfg_type'],true);
        $list = array();
        foreach ($types as $key => $val) {
            $list[$key] = array();
            $list[$key]['type'] = $val['type'];
            $list[$key]['type_name'] = $val['type_name'];
            $list[$key]['count'] = $this->lineup_member_model->where(array('lineup_id' =>$id, 'type' => $list[$key]['type'], 'status' => 0, 'reset' => 0))->count();
            // echo $this->db->last_query();
            // exit;
            //当前排到几号
            $res = $this->lineup_member_model->where(array('lineup_id' => $id, 'type' => $list[$key]['type'], 'status' => 0, 'reset' => 0))
                ->order_by('number', 'asc')->find();
            if( $res['number']){
                $tmp_res = $this->lineup_member_model->limit(1,0)->where(array('lineup_id' => $id, 'type' => $list[$key]['type'], 'status' => 0, 'reset' => 0,'number <' => $res['number']))->order_by('number', 'desc')->find_all();
            }
            $list[$key]['id'] = isset($res['id']) ? $res['id'] : 0;
            $list[$key]['current'] = isset($res['number']) ? $res['number'] : 0;
            $list[$key]['before'] = isset($tmp_res['number']) ? $tmp_res['number'] : 0;
        }

        $wid = $this->lineup_model->select('wid,qrcode')->where(array('id' => $id))->find();
        $name = $this->lineup_config_model->select('name')->where(array('lineup_id' => $id))->find();
        $condition = array(
            'lineup_id' => $this->status_info['id']
        );
        $cfg_type = $this->lineup_config_model->select('cfg_type')->where($condition)->find();
        if($cfg_type){
            $this->data['cfg_type'] = json_decode($cfg_type['cfg_type'],true);
        }
        $this->data['list'] = $list;
        $this->data['name'] = $name['name'];
        $this->data['qrcode'] = $wid['qrcode'];
        $this->ajax_return($this->data);

    }
}