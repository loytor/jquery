<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Class Convert
 * 海外服务器迁移程序
 */
class Convert extends C_Controller
{
    protected $dtb;

    public function __construct()
    {
        exit;
        parent::__construct();
        //$this->dtb = mysql_connect('127.0.0.1','root','') or die("Database error");
        $this->dtb = mysql_connect('10.66.101.23:3306','root','!QAZ@WSX') or die("Database error");
        mysql_select_db('guowai_weixin', $this->dtb) or die(mysql_error());
        mysql_query("Set names 'utf8'");
    }

    /**
     *
     */
    public function user()
    {
        //$db = mysql_connect('192.168.20.8','weixin','weixin@weiba6') or die("Database error");

        $sql = "SELECT * FROM user";
        $result = mysql_query($sql, $this->dtb) or die(mysql_error());
        $i = 0;
        $j = 0;
        $this->load->model('user_model');
        while ($row = mysql_fetch_array($result)) {
            unset($row['admin_id']);
            if($row['city'] == '奥克兰') {
                $row['country'] = '新西兰';
                $row['province'] = '奥克兰';
            }
            if($row['city'] == '马来西亚') {
                $row['country'] = '马来西亚';
                $row['province'] = '马来西亚';
            }
            if(!$this->user_model->where(array('id'=>$row['id']))->find()) {
                if($this->user_model->add($row)) {
                    $i++;
                }
            } else {
                if($this->user_model->where(array('id'=>$row['id']))->edit($row)) {
                    $j++;
                }
            }
        }
        echo '导入用户:添加'.$i.'条,更新'.$j.'条';
    }

    /**
     * UPDATE `user` SET agent_id = 1136 WHERE `country` LIKE '新西兰' AND `province` LIKE '奥克兰' AND `city` LIKE '奥克兰'
     * UPDATE `user` SET agent_id = 1137 WHERE `country` LIKE '马来西亚' AND `province` LIKE '马来西亚' AND `city` LIKE '马来西亚'
     */
    public function agent()
    {
        $sql = "SELECT * FROM agent";
        $result = mysql_query($sql, $this->dtb) or die(mysql_error());
        $i = 0;
        $this->load->model('agent_model');
        $this->load->model('agentadmin_model');
        while ($row = mysql_fetch_array($result)) {
            unset($row['id']);
            $row['admin_id'] = 3;
            if($row['city'] == '奥克兰') {
                $row['country'] = '新西兰';
                $row['province'] = '奥克兰';
            }
            if($row['city'] == '马来西亚') {
                $row['country'] = '马来西亚';
                $row['province'] = '马来西亚';
            }
            $row['price'] = 1100;
            $row['dt_login'] = strtotime($row['dt_login']);
            $row['dt_add'] = strtotime($row['dt_add']);
            $row['dt_update'] = strtotime($row['dt_update']);
            if($agent_id=$this->agent_model->add($row)) {
                //添加默认代理商管理员账号
                $ad['agent_id'] = $agent_id;
                $ad['role_id'] = 0;
                $ad['username'] = $row['username'];
                $ad['password'] = $row['password'];
                $ad['dt_login'] = $row['dt_login'];
                $ad['dt_add'] = $row['dt_add'];
                $ad['dt_update'] = $row['dt_update'];
                $this->agentadmin_model->add($ad);
                $i++;
            }
        }
        echo '导入代理商'.$i.'条';
    }

    /**
     * UPDATE `user_auth` SET agent_id = 1137 WHERE id <= 588433 AND id > 587663 AND agent_id = 535 马来西亚
     * UPDATE `user_auth` SET agent_id = 1136 WHERE id <= 588433 AND id > 587663 AND agent_id = 52 奥克兰
     */
    public function user_auth()
    {
        $sql = "SELECT * FROM user_auth";
        $result = mysql_query($sql, $this->dtb) or die(mysql_error());
        $i = 0;
        $this->load->model('user_auth_model');
        while ($row = mysql_fetch_array($result)) {
            unset($row['id']);
            if($this->user_auth_model->where(array('user_id'=>$row['user_id'], 'app_id'=>$row['app_id']))->find()) {
                $this->user_auth_model->where(array('user_id'=>$row['user_id'], 'app_id'=>$row['app_id']))->delete();
            }
            if($this->user_auth_model->add($row)) {
                $i++;
            }
        }
        echo '导入用户应用关联表'.$i.'条';
    }

    /**
     * 给代理商添加应用,插入agent_app表
     */

    /**
     * 导入栏目
     * 图片可能要从国外服务器移到图片服务器
     * UPDATE cate SET image = REPLACE(image, 'c.bama555.net', 'c.bama555.com') WHERE `image` LIKE  '%c.bama555.net%';
     */
    public function cate()
    {
        $sql = "SELECT * FROM cate";
        $result = mysql_query($sql, $this->dtb) or die(mysql_error());
        $i = 0;
        $j = 0;
        $this->load->model('cate_model');
        while ($row = mysql_fetch_array($result)) {
            if(!$this->cate_model->where(array('id'=>$row['id']))->find()) {
                if($this->cate_model->add($row)) {
                    $i++;
                }
            } else {
                if($this->cate_model->where(array('id'=>$row['id']))->edit($row)) {
                    $j++;
                }
            }
        }
        echo '导入栏目:添加'.$i.'条,更新'.$j.'条';
    }

    /**
     * 导入栏目列表关联表
     */
    public function cate_lists()
    {
        $sql = "SELECT * FROM cate_lists";
        $result = mysql_query($sql, $this->dtb) or die(mysql_error());
        $i = 0;
        $j = 0;
        $this->load->model('cate_lists_model');
        while ($row = mysql_fetch_array($result)) {
            if(!$this->cate_lists_model->where(array('id'=>$row['id']))->find()) {
                if($this->cate_lists_model->add($row)) {
                    $i++;
                }
            } else {
                if($this->cate_lists_model->where(array('id'=>$row['id']))->edit($row)) {
                    $j++;
                }
            }
        }
        echo '导入栏目列表:添加'.$i.'条,更新'.$j.'条';
    }

    /**
     * 导入文章
     * UPDATE article SET image = REPLACE(image, 'c.bama555.net', 'c.bama555.com') WHERE `image` LIKE  '%c.bama555.net%';
     */
    public function article()
    {
        $sql = "SELECT * FROM article";
        $result = mysql_query($sql, $this->dtb) or die(mysql_error());
        $i = 0;
        $j = 0;
        $this->load->model('article_model');
        while ($row = mysql_fetch_array($result)) {
            if(!$this->article_model->where(array('id'=>$row['id']))->find()) {
                if($this->article_model->add($row)) {
                    $i++;
                }
            } else {
                if($this->article_model->where(array('id'=>$row['id']))->edit($row)) {
                    $j++;
                }
            }
        }
        echo '导入文章:添加'.$i.'条,更新'.$j.'条';
    }

    /**
     * 导入cate_banner
     * UPDATE cate_banner SET image = REPLACE(image, 'c.bama555.net', 'c.bama555.com') WHERE `image` LIKE  '%c.bama555.net%';
     */
    public function cate_banner()
    {
        $sql = "SELECT * FROM cate_banner";
        $result = mysql_query($sql, $this->dtb) or die(mysql_error());
        $i = 0;
        $j = 0;
        $this->load->model('cate_banner_model');
        while ($row = mysql_fetch_array($result)) {
            if(!$this->cate_banner_model->where(array('id'=>$row['id']))->find()) {
                if($this->cate_banner_model->add($row)) {
                    $i++;
                }
            } else {
                if($this->cate_banner_model->where(array('id'=>$row['id']))->edit($row)) {
                    $j++;
                }
            }
        }
        echo '导入栏目广告:添加'.$i.'条,更新'.$j.'条';
    }

    /**
     * 导入辅助
     * UPDATE assist SET icon = REPLACE(icon, 'c.bama555.net', 'c.bama555.com') WHERE `icon` LIKE  '%c.bama555.net%';
     */
    public function assist()
    {
        $sql = "SELECT * FROM assist";
        $result = mysql_query($sql, $this->dtb) or die(mysql_error());
        $i = 0;
        $this->load->model('assist_model');
        while ($row = mysql_fetch_array($result)) {
            unset($row['id']);
            if($this->assist_model->add($row)) {
                $i++;
            }
        }
        echo '导入辅助:添加'.$i.'条';
    }

    public function app_config()
    {
        $sql = "SELECT * FROM app_config WHERE type != 'menu'";
        $result = mysql_query($sql, $this->dtb) or die(mysql_error());
        $i = 0;
        $this->load->model('app_config_model');
        while ($row = mysql_fetch_array($result)) {
            unset($row['id']);
            if($this->app_config_model->add($row)) {
                $i++;
            }
        }
        echo '导入配置:添加'.$i.'条';
    }

    /**
     * 导入地址表
     * UPDATE address SET icon = REPLACE(icon, 'c.bama555.net', 'c.bama555.com') WHERE `icon` LIKE  '%c.bama555.net%';
     * id 先去某个字段保留下，待全部导完再删除
     */
    public function address()
    {
        $sql = "SELECT * FROM address";
        $result = mysql_query($sql, $this->dtb) or die(mysql_error());
        $i = 0;
        $this->load->model('address_model');
        while ($row = mysql_fetch_array($result)) {
            unset($row['id']);
            if($this->address_model->add($row)) {
                $i++;
            }
        }
        echo '导入地址:添加'.$i.'条';
    }

    /**
     * tpl, tpl_css导入
     */

    /**
     * 导入会员用户表
     * account_address, action_record表导入
     */
    public function account($limit=1000, $offset=0)
    {
        $sql = "SELECT * FROM account LIMIT ".$offset.", ".$limit;
        $result = mysql_query($sql, $this->dtb) or die(mysql_error());
        $i = 0;
        $j = 0;
        $this->load->model('account_model');
        while ($row = mysql_fetch_array($result)) {
            unset($row['id']);
            if(!$this->account_model->where(array('wid'=>$row['wid'], 'wxid'=>$row['wxid']))->find()) {
                if($this->account_model->add($row)) {
                    $i++;
                }
            } else {
                if($this->account_model->where(array('wid'=>$row['wid'], 'wxid'=>$row['wxid']))->edit($row)) {
                    $j++;
                }
            }
        }
        echo '导入会员用户:添加'.$i.'条,更新'.$j.'条';
    }

    public function enroll()
    {
        $sql = "SELECT * FROM marketing WHERE type = 'enroll'";
        $result = mysql_query($sql, $this->dtb) or die(mysql_error());
        $i = 0;
        $j = 0;
        $this->load->model('marketing_model');
        while ($row = mysql_fetch_array($result)) {
            if(!$this->marketing_model->where(array('id'=>$row['id']))->find()) {
                if($this->marketing_model->add($row)) {
                    $i++;
                }
            } else {
                if($this->marketing_model->where(array('id'=>$row['id']))->edit($row)) {
                    $j++;
                }
            }
        }
        echo '导入报名:添加'.$i.'条,更新'.$j.'条';
    }

    public function marketing_enroll()
    {
        $sql = "SELECT * FROM marketing_enroll";
        $result = mysql_query($sql, $this->dtb) or die(mysql_error());
        $i = 0;
        $j = 0;
        $this->load->model('marketing_enroll_model');
        while ($row = mysql_fetch_array($result)) {
            unset($row['mid']);
            if(!$this->marketing_enroll_model->where(array('marketing_id'=>$row['marketing_id']))->find()) {
                if($this->marketing_enroll_model->add($row)) {
                    $i++;
                }
            } else {
                if($this->marketing_enroll_model->where(array('marketing_id'=>$row['marketing_id']))->edit($row)) {
                    $j++;
                }
            }
        }
        echo '导入报名:添加'.$i.'条,更新'.$j.'条';
    }

    public function marketing_enroll_record()
    {
        $sql = "SELECT * FROM marketing_enroll_record";
        $result = mysql_query($sql, $this->dtb) or die(mysql_error());
        $i = 0;
        $j = 0;
        $this->load->model('marketing_enroll_record_model');
        while ($row = mysql_fetch_array($result)) {
            unset($row['mid']);
            if(!$this->marketing_enroll_record_model->where(array('marketing_id'=>$row['marketing_id']))->find()) {
                if($this->marketing_enroll_record_model->add($row)) {
                    $i++;
                }
            } else {
                if($this->marketing_enroll_record_model->where(array('marketing_id'=>$row['marketing_id']))->edit($row)) {
                    $j++;
                }
            }
        }
        echo '导入报名:添加'.$i.'条,更新'.$j.'条';
    }
    /**
    1.action_record导入,要更新相应uid字段

    2.老商城相关信息导入 id 先去某个字段保留下，待全部导完再删除

    3.会员卡相关导入 id 先去某个字段保留下，待全部导完再删除
    */
}