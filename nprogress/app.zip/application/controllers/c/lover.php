<?php
/**
 * Created by PhpStorm.
 * User: along
 * Date: 14-5-28
 * Time: 下午3:06
 * @property Shooting_model $shooting_model
 * @property Shooting_member_model $shooting_member_model
 */

class Lover extends C_Controller {

    private $site_id = '';
    protected $data = array();

    public function __construct()
    {
        parent::__construct();
        $this->load->model('lover_model');
        $this->site_id = $this->site_info['id'];
    }

    public function index()
    {
        $where = array();
        $where['site_id'] = $this->site_id;
        $where['status'] = 1;
        $total = $this->lover_model->where($where)->count();
        $pager = $this->_pager($total, array('per_page'=>15));

        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->data['list'] = array();
        if($total > 0)
        {
            $this->data['list'] = $this->lover_model->where($where)->limit($pager['limit']['value'],$pager['limit']['offset'])->order_by('id desc')->find_all();
        }
        $this->data['viewurl'] = $this->create_url('seventh_evening');
        $this->load->view($this->dcm,$this->data);
    }

    /**
     * 游戏设置
     */

    public function set()
    {
        $where = array();
        $id = $this->input->get_post('id');
        $lover = array();

        if($id)
        {
            $where['id'] = $id;
            $where['site_id'] = $this->site_id;
            $lover = $this->lover_model->where($where)->find();
        }

        $post = $this->input->post();

        if($post)
        {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('start_time','开始时间','trim|required');
            $this->form_validation->set_rules('end_time','结束时间','trim|required');
            $this->form_validation->set_rules('title','标题','trim|required');
            $this->form_validation->set_rules('gamenumber','每天可玩次数','trim|required|is_numeric');
            $this->form_validation->set_rules('sharenumber','分享激励','trim|is_numeric');
            $this->form_validation->set_rules('custompic', '转发图标', 'trim');
            $this->form_validation->set_rules('customtitle', '转发标题', 'trim|max_length[200]');
            $this->form_validation->set_rules('virtual','虚拟参与人数','trim|is_numeric');

            if ( $this->form_validation->run() )
            {
                //开始时间
                $dataSet['start_time'] = strtotime($this->form_validation->set_value('start_time'));
                $dataSet['end_time'] = strtotime($this->form_validation->set_value('end_time'));
                $dataSet['title'] = $this->form_validation->set_value('title');
                $dataSet['gamenumber'] = $this->form_validation->set_value('gamenumber');
                $dataSet['sharenumber'] = $this->form_validation->set_value('sharenumber');

                $dataSet['firstrate'] = $this->form_validation->set_value('firstrate');
                $dataSet['bgcolor'] = $this->input->post('bgcolor');
                $dataSet['banner'] = $this->input->post('banner');

                //图片
                $dataSet['custompic'] = $this->form_validation->set_value('custompic');
                $dataSet['customtitle'] = $this->form_validation->set_value('customtitle');
                $dataSet['transmit'] = $this->input->post('transmit');

                //echo $this->input->post('transmit');exit;

                $dataSet['rule'] = $this->input->post('rule');
                $dataSet['prize'] = $this->input->post('prize');
                $dataSet['virtual'] = $this->input->post('virtual');

                //更新
                if($lover)
                {
                    $this->lover_model->where(array('id'=>$lover['id']))->edit($dataSet);
                }
                else
                {
                    $dataSet['site_id'] = $this->site_id;
                    $this->lover_model->add($dataSet);
                }
                $this->show_message(true, '提交成功', '/c/lover');return false;
            }
            else
            {
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(false, $errors, '');return false;
                }
            }
        }
        else
        {
            if(isset($lover['banner']) && $lover['banner']) {
                $lover['banner_img'] = image_full_url($lover['banner']);
            }
            if(isset($lover['custompic']) && $lover['custompic']) {
                $lover['custompic_img'] = image_full_url($lover['custompic']);
            }
            $this->data['setting'] = $lover;
            $this->load->view($this->dcm,$this->data);
        }
    }

    public function del($id = '')
    {
        $lover = $this->lover_model->where(array('id'=>$id))->find();
        if(!$lover || $lover['site_id'] != $this->site_id)
        {
            $this->show_message(false, '该游戏不存在', '/c/lover/index');return false;
        }
        $this->lover_model->where(array('id'=>$lover['id']))->edit(array('status'=>-1));
        $this->show_message(false, '删除成功', '/c/lover/index');return false;
    }

    public function record($id = '')
    {
        if(!$id)
        {
            $this->show_message(false, '非法访问', '/c/lover/index');return false;
        }
        $this->load->model('lover_member_model');
        $where = " site_id = '".$this->site_id."'";

        $searchUrl = '/c/lover/record/'.$id.'/?';

        $keyword = $this->input->get('keyword');
        if($keyword)
        {
            $this->data['search'] = array('keyword'=>$keyword);
            $where .= " and (username like '%".$keyword."%' or tel like '%".$keyword."%') ";
            $searchUrl .= 'keyword='.$keyword;
        }

        $lover = $this->lover_model->where(array('site_id' => $this->site_id,'id'=>$id))->find();
        $where .= " and lover_id = ".$lover['id']." and username != '' and tel !=''";

        $total_rows = $this->lover_member_model->where($where)->count();
        //echo $this->db->last_query();
        $pager = $this->_pager($total_rows, array('per_page'=>15,'base_url'=>$searchUrl));

        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->data['list'] = array();
        if($total_rows > 0)
        {
            $list = $this->lover_member_model->where($where)->limit($pager['limit']['value'], $pager['limit']['offset'])->order_by('zgf desc')->find_all();

            //echo $this->db->last_query();

            foreach($list as &$_item) {
                $_item['zgf'] = $this->format_mictime($_item['zgf']);
            }
            $this->data['list'] = $list;
        }

        $this->data['lover'] = $lover;
        $this->load->view($this->dcm,$this->data);
    }

    public function export()
    {
        $this->load->model('lover_member_model');
        $where = " site_id = '".$this->site_id."'";
        $keyword = $this->input->get('keyword');
        if($keyword)
        {
            $this->data['search'] = array('keyword'=>$keyword);
            $where .= " and (username like '%".$keyword."%' or tel like '%".$keyword."%')";
        }
        $id = $this->input->get('id');
        $lover = $this->lover_model->where(array('site_id' => $this->site_id,'id'=>$id))->find();
        if(!$lover)
        {
            $this->show_message(false,'暂无数据可以导出','');return false;
        }
        $where .= " and lover_id = ".$lover['id']." and username != '' and tel !=''";

        $list = $this->lover_member_model->where($where)->order_by('id desc')->find_all();
        $memberList = array();
        if($list)
        {
            foreach($list as $key=> $item)
            {
                $memberList[$key]['username'] = $item['username'];
                $memberList[$key]['tel'] = $item['tel'];
                $memberList[$key]['zgf'] = $this->format_mictime($item['zgf']);
            }

            $fields = array(
                '#'=>'#',
                'username'=>'姓名',
                'tel'=>'电话',
                'zgf'=>'战绩'
            );
            $this->excel_export('游戏数据统计', '游戏数据统计', $fields, $memberList);
        }
        else
        {
            $this->show_message(false,'暂无数据可以导出','');
        }
    }

    //导原有点球数据

    public function backup()
    {
        $this->load->model('shoot_model');
        $basewhere['site_id'] = $this->site_id;
        //,joinnum,shootnum,assistsnum
        $shoot = $this->shoot_model->select('start_time,end_time,number,sharenumber,firstrate,rule,prize,banner,custompic,customtitle,virtual')->where($basewhere)->find();
        if($shoot)
        {
            $shottingdata = $shoot;
            $shottingdata['site_id'] = $this->site_id;
            if($shootingId = $this->shooting_model->add($shottingdata))
            {
                //取所有参与人数

            }
        }
    }

    private function format_mictime($mictime) {
        $time = $mictime/1000;
        if($time >= 60){
            $m = floor($time/60);
            $s = $time%60;
            $format_time = $m."'".$s.'"';
        }
        else{
            $s_g = $mictime % 1000;
            $s_g = str_pad($s_g, 3, "0", STR_PAD_LEFT);
            $s = floor($mictime/1000);
            $format_time = $s.".".$s_g.'"';
        }
        return $format_time;
    }
} 