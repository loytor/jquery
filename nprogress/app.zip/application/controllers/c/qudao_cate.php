<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 渠道分组
 * 1级分组  A-Z
 * 2级分组 00-99
 * 3级分组 000-999
 */
class Qudao_cate extends C_Controller {

    protected $auto_load_model = TRUE;
    protected $model_name = 'qudao';
    protected $data = '';
    private $site_id = '';
    protected $qudaoconfig = array();
    
    protected $level_first = array();

    public function __construct()
    {
        parent::__construct();
        $this->site_id = $this->site_info['id'];
        
        //$this->level_first = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
        
        $this->load->model('qudao_cate_model');
    }
    
    //指标
    public function index()
    {
        $this->cate_level();
        
        $this->load->model('qudao_model');
        
        $list = array();
        $zhibiao_num = array();
        if( $this->data['cate_level'] ){
            if( $this->data['cate_level']['parent'] ){
                foreach( $this->data['cate_level']['parent'] as $v1 ){
                    $v1['level'] = 1;
                    $list[] = $v1;
                    $zhibiao_num[$v1['id']] = 0;
                    if( isset($this->data['cate_level']['child'][$v1['id']])&&$this->data['cate_level']['child'][$v1['id']] ){
                        foreach( $this->data['cate_level']['child'][$v1['id']] as $v2 ){
                            $v2['level'] = 2;
                            $list[] = $v2;
                            
                            //二级分组下的渠道
                            $child_qudao = $this->qudao_model->select('sum(qudao_zhibiao.num) as num')
                                           ->join('qudao_zhibiao','qudao_zhibiao.id=qudao.zhibiao_id')
                                           ->where(array('qudao.site_id'=>$this->site_id,'qudao.zhibiao_id >'=>0,'qudao.cate_id'=>$v2['id'],'qudao.is_delete'=>0))
                                           ->find();
                            $zhibiao_num[$v1['id']] += intval($child_qudao['num']);
                            $zhibiao_num[$v2['id']] = intval($child_qudao['num']);
                        }
                    }
                }
            }
        }
        $this->data['zhibiao_num'] = $zhibiao_num;
        $this->data['list'] = $list;
        
        $this->load->view($this->dcm,$this->data);
    }

    public function add()
    {
        $send_parent_id = $this->input->get('send_parent_id');
        $this->data['send_parent_id'] = $send_parent_id;
        if( $this->input->post() ){
            $this->form_validation->set_rules('name', '渠道分组名称', 'trim|required|max_length[100]');
            $this->form_validation->set_rules('parent_id', '上级分组', 'trim|required|intval');
            $this->form_validation->set_rules('password', '查询密码', 'trim|required|integer|min_length[5]|max_length[5]');
            $this->form_validation->set_rules('prefix', ' 分组前缀', 'trim|required|max_length[10]');
            if ( $this->form_validation->run() ){
                $dataSet['name'] = $this->form_validation->set_value('name');
                $dataSet['parent_id'] = $this->form_validation->set_value('parent_id');
                $dataSet['password'] = $this->form_validation->set_value('password');
                $dataSet['prefix'] = $this->form_validation->set_value('prefix');
                if( $dataSet['parent_id']==0 ){//第一级分组
                    if( !$this->check_unique('name', $dataSet['name'], 0) ){
                        $this->show_message(false, '该分组名称已被使用', '', 1);
                        return false;
                    }
                    if( !$this->check_unique('prefix', $dataSet['prefix'], 0) ){
                        $this->show_message(false, '该前缀已被使用', '', 1);
                        return false;
                    }
                    
                    /*$last_id = $this->qudao_cate_model->where(array('parent_id'=>0,'site_id'=>$this->site_id))->order_by('prefix desc')->find();
                    if( $last_id ){
                        $key = array_search($last_id['prefix'], $this->level_first);
                        if( $key!==false ){
                            $key = $key+1;
                            if( $key<26 ){
                                $prefix = $this->level_first[$key];
                                $dataSet['prefix'] = $prefix;
                            }else{
                                $this->show_message(false, '您最多添加26个一级分组', '');return false;
                            }
                        }else{
                            $this->show_message(false, '未知错误，请联系代理商', '');return false;
                        }
                    }else{
                        $dataSet['prefix'] = 'A';
                    }*/
                }else{//第二级分组
                    
                    if( !$this->check_unique('name', $dataSet['name'], $dataSet['parent_id']) ){
                        $this->show_message(false, '该分组名称已被使用', '', 1);
                        return false;
                    }
                    
                    if( !$this->check_unique('prefix', $dataSet['prefix'], $dataSet['parent_id']) ){
                        $this->show_message(false, '该前缀已被使用', '', 1);
                        return false;
                    }
                    
                    /*$last_id = $this->qudao_cate_model->where(array('parent_id >'=>0,'site_id'=>$this->site_id))->order_by('prefix desc')->find();
                    if( $last_id ){
                        $par_prefix = intval($last_id['prefix']);
                        if( $par_prefix<100 ){
                            $prefix = $par_prefix+1;
                            if( $prefix<10 ){
                                $dataSet['prefix'] = '0'.$prefix;
                            }else{
                                $dataSet['prefix'] = $prefix;
                            }
                        }else{
                            $this->show_message(false, '您最多添加100个二级分组', '');return false;
                        }
                    }else{
                        $dataSet['prefix'] = '00';
                    }*/
                }
                
                $dataSet['site_id'] = $this->site_id;
                if( !$id=$this->qudao_cate_model->add($dataSet) ){
                    $this->show_message(false, '添加失败', '',1);
                    return FALSE;
                }else{
                    $this->show_message(true, '添加成功', '',1);
                    return FALSE;
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            $this->cate_level();
            $this->load->view($this->dcm,$this->data);
        }
    }
    
    /**
     * 判断唯一性
     */
    public function check_unique( $field, $value, $parent_id=0 )
    {
        if( $parent_id==0 ){
            $result = $this->qudao_cate_model->where(array('site_id'=>$this->site_id,$field=>$value,'parent_id'=>0))->count();
        }else{
            $result = $this->qudao_cate_model->where(array('site_id'=>$this->site_id,$field=>$value,'parent_id'=>$parent_id))->count();
        }
        if( $result ){
            return false;
        }else{
            return true;
        }
    }
    
    //分组分级
    public function cate_level()
    {
        $cate_level = array();
        $temp = $this->qudao_cate_model->select('id,parent_id,name,prefix')->where(array('site_id'=>$this->site_id))->order_by('id desc')->find_all();
        if( $temp ){
            foreach( $temp as $val ){
                if( $val['parent_id']==0 ){
                    $cate_level['parent'][] = $val;
                }else{
                    $cate_level['child'][$val['parent_id']][] = $val;
                }
            }
        }
        $this->data['cate_level'] = $cate_level;
    }

    
    
    public function edit($id)
    {
        if(!$id){
            $this->show_message(false, '非法参数', 1);return false;
        }
        $cate = $this->qudao_cate_model->where(array('id'=>$id,'site_id'=>$this->site_id))->find();
        if(!$cate){
            $this->show_message(false, '分组不存在', 1);return false;
        }
        if( $cate['parent_id']==0 ){
            $cate['parent_cate'] = '顶级分组';
        }elseif( $cate['parent_id']>0 ){
            $parent_cate = $this->qudao_cate_model->where(array('id'=>$cate['parent_id'],'site_id'=>$this->site_id))->find();
            $cate['parent_cate'] = $parent_cate['name'];
        }

        if( $this->input->post() ){
            $this->form_validation->set_rules('name', '渠道分组名称', 'trim|required|max_length[100]');
            $this->form_validation->set_rules('password', '查询密码', 'trim|required|integer|min_length[5]|max_length[5]');
            if ( $this->form_validation->run() ){
                $dataSet['name'] = $this->form_validation->set_value('name');
                $dataSet['password'] = $this->form_validation->set_value('password');
                
                if( $cate['parent_id']==0 ){//第一级分组
                    if( $cate['name']!=$dataSet['name'] ){
                        if( !$this->check_unique('name', $dataSet['name'], 0) ){
                            $this->show_message(false, '该分组名称已被使用', '', 1);
                            return false;
                        }
                    }
                }elseif( $cate['parent_id']>0 ){//第二级分组
                    if( $cate['name']!=$dataSet['name'] ){
                        if( !$this->check_unique('name', $dataSet['name'], 1) ){
                            $this->show_message(false, '该分组名称已被使用', '', 1);
                            return false;
                        }
                    }
                }
                
                if(false === $this->qudao_cate_model->where(array('id'=>$id, 'site_id'=>$this->site_id))->edit($dataSet) ){
                    $this->show_message(false, '编辑失败', '',1);
                }else{
                    $this->show_message(true, '编辑成功', '',1);
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            $this->data['cate'] = $cate;
            $this->load->view($this->dcm,$this->data);
        }
    }

    /**
     * 删除渠道分组
     * @param $id
     * @return bool
     */
    public function delete($id)
    {
        if(!$id){
            $this->show_message(false, '非法参数', 1);return false;
        }
        $cate = $this->qudao_cate_model->where(array('id'=>$id,'site_id'=>$this->site_id))->find();
        if(!$cate){
            $this->show_message(false, '分组不存在', '/c/qudao_cate/index');return false;
        }
        //分组下是否有渠道
        if( $cate['parent_id']==0 ){
            $qudao = $this->model->where(array('parent_cate_id'=>$id,'site_id'=>$this->site_id,'is_delete'=>0))->find();
            if($qudao){
                $this->show_message(false, '该分组下已有渠道，不能删除', '/c/qudao_cate/index');return false;
            }
            $this->qudao_cate_model->where(array('parent_id'=>$id,'site_id'=>$this->site_id))->delete();
            
        }else{
            $qudao = $this->model->where(array('cate_id'=>$id,'site_id'=>$this->site_id,'is_delete'=>0))->find();
            if($qudao){
                $this->show_message(false, '该分组下已有渠道，不能删除', '/c/qudao_cate/index');return false;
            }
        }
        $this->qudao_cate_model->where(array('id'=>$id,'site_id'=>$this->site_id))->delete();
        $this->show_message(true, '分组删除成功!', '/c/qudao_cate/index');return false;
    }
    
    //数据统计银泰
    public function base_info_yt()
    {
        $this->data['base_info'] = array();
        
        $parent_cate_id = intval($this->input->get('parent_cate_id'));
        $cate_id = intval($this->input->get('cate_id'));
        $this->data['nav']['parent_cate_id'] = $parent_cate_id;
        $this->data['nav']['cate_id'] = $cate_id;
        
        //分组导航
        $this->data['base_info']['nav'] = array();
        $this->load->model('qudao_cate_model');
        $parent_cate = $this->qudao_cate_model->where(array('site_id'=>$this->site_id,'id'=>$parent_cate_id,'parent_id'=>0))->find();
        if( !$parent_cate ){
            redirect('/c/qudao_cate/index');
        }
        $this->data['base_info']['nav'][] = $parent_cate['name'];
        $this->load->model('qudao_model');
        if( $cate_id ){//二级分组
            $this->data['base_info']['type'] = 11;//有渠道排名数据
            $this->data['base_info']['selected_id'] = $cate_id;
            $child_cate = $this->qudao_cate_model->where(array('site_id'=>$this->site_id,'id'=>$cate_id,'parent_id'=>$parent_cate['id']))->find();
            if( !$child_cate ){
                redirect('/c/qudao_cate/index');
            }
            $this->data['base_info']['nav'][] = $child_cate['name'];
            $this->cate_level();
            $child_cates = $this->data['cate_level']['child'][$parent_cate_id];
            if( $child_cates ){
                //月度指标  //实际完成
                $zhibiao_num = $month_num = array();
                $paixu_temp = array();
                foreach( $child_cates as $val ){
                    $temp1 = $this->qudao_model->get_zhibiao_num($this->site_id,$val['id'],'child');
                    $zhibiao_num[$val['id']] = intval($temp1['num']);
                    
                    if( isset($_GET['re_m'])&&($_GET['re_m']) ){
                        $temp2 = $this->qudao_model->zhibiao_month_num($this->site_id,$val['id'],'child',$this->get_month_yt(1));
                    }else{
                        $temp2 = $this->qudao_model->zhibiao_month_num($this->site_id,$val['id'],'child',$this->get_month_yt());
                    }
                    $month_num[$val['id']] = intval($temp2['num']);
                    $paixu_temp[$val['id']] = $val['name'];
                }
                if( !isset($zhibiao_num[$cate_id])||!isset($month_num[$cate_id]) ){
                    redirect('/c/qudao_cate/index');
                }
                
                if( $parent_cate_id==370 ){//银泰C馆  关联B馆
                    $child_cates2 = $this->data['cate_level']['child']['369'];
                    if( $child_cates2 ){
                        //实际完成
                        foreach( $child_cates2 as $val ){
                            if( isset($_GET['re_m'])&&($_GET['re_m']) ){
                                $temp2 = $this->qudao_model->zhibiao_month_num($this->site_id,$val['id'],'child',$this->get_month_yt(1));
                            }else{
                                $temp2 = $this->qudao_model->zhibiao_month_num($this->site_id,$val['id'],'child',$this->get_month_yt());
                            }
                            $month_num[$val['id']] = intval($temp2['num']);
                        }
                    }else{
                        redirect('/c/qudao_cate/index');
                    }
                }
                if( $parent_cate_id==369 ){//银泰B馆   关联C馆
                    $child_cates2 = $this->data['cate_level']['child']['370'];
                    if( $child_cates2 ){
                        //实际完成
                        foreach( $child_cates2 as $val ){
                            if( isset($_GET['re_m'])&&($_GET['re_m']) ){
                                $temp2 = $this->qudao_model->zhibiao_month_num($this->site_id,$val['id'],'child',$this->get_month_yt(1));
                            }else{
                                $temp2 = $this->qudao_model->zhibiao_month_num($this->site_id,$val['id'],'child',$this->get_month_yt());
                            }
                            $month_num[$val['id']] = intval($temp2['num']);
                        }
                    }else{
                        redirect('/c/qudao_cate/index');
                    }
                }
            }else{
                redirect('/c/qudao_cate/index');
            }
            
            $this->data['base_info']['zhibiao_num'] = $zhibiao_num[$cate_id];
            //实际完成
            $this->data['base_info']['month_num'] = $month_num[$cate_id];
            arsort($month_num);
            $i = 1;
            foreach( $month_num as $key=>$val ){
                if( $cate_id==$key ){
                    $this->data['base_info']['rank_num'] = $i;
                    break;
                }
                $i++;
            }
            
            //银泰查看二级分组下的  各个渠道的双月 完成额
            $qudaos_num = $this->qudao_model->qudao_zhibiao_num($this->site_id,$cate_id,$this->get_month_yt());
            if( !$qudaos_num ){
                redirect('/c/qudao_cate/index');
            }
            
            //TODO
            $qudaos_num_tmp1 = array();
            $qudaos_num_tmp2 = array();
            $qudaos_num_tmp3 = array();
            foreach( $qudaos_num as $val ){
                if( isset( $qudaos_num_tmp1[$val['id']] ) ){
                    $qudaos_num_tmp1[$val['id']]['num'] += $val['num'];
                    $qudaos_num_tmp2[$val['id']] += $val['num'];
                }else{
                    $qudaos_num_tmp1[$val['id']] = $val;
                    $qudaos_num_tmp2[$val['id']] = $val['num'];
                }
            }
            $i = 1;
            arsort($qudaos_num_tmp2);
            foreach( $qudaos_num_tmp2 as $key=>$val ){
                $qudaos_num_tmp3[] = $qudaos_num_tmp1[$key];
            }

            $this->data['base_info']['qudaos_num'] = $qudaos_num_tmp3;
            
            //渠道排名  导出
            if( isset($_GET['export1'])&&($_GET['export1']) ){
                $fields = array(
                    '#'=>'#',
                    'name' => '渠道名',
                    'num' => '用户数'
                );
                if( $qudaos_num_tmp3 ){
                    $this->excel_export('渠道排名', '渠道排名', $fields, $qudaos_num_tmp3);exit;
                }
            }
            
        }else{
            $this->data['base_info']['type'] = 1;//没有渠道排名数据
            $this->data['base_info']['selected_id'] = $parent_cate_id;
            //月度指标  //实际完成
            $zhibiao_num = $month_num = array();
            $paixu_temp = array();
            $this->cate_level();
            $first_cate = $this->data['cate_level']['parent'];
            if( $first_cate ){
                foreach( $first_cate as $val ){
                    $temp1 = $this->qudao_model->get_zhibiao_num($this->site_id,$val['id'],'parent');
                    $zhibiao_num[$val['id']] = intval($temp1['num']);
                    
                    $temp2 = $this->qudao_model->zhibiao_month_num($this->site_id,$val['id'],'parent',$this->get_month_yt());
                    $month_num[$val['id']] = intval($temp2['num']);
                    $paixu_temp[$val['id']] = $val['name'];
                }
                
                if( !isset($zhibiao_num[$parent_cate_id])||!isset($month_num[$parent_cate_id]) ){
                    redirect('/c/qudao_cate/index');
                }
            }else{
                redirect('/c/qudao_cate/index');
            }
            $this->data['base_info']['zhibiao_num'] = $zhibiao_num[$parent_cate_id];
            //实际完成
            $this->data['base_info']['month_num'] = $month_num[$parent_cate_id];
            arsort($month_num);
            $i = 1;
            foreach( $month_num as $key=>$val ){
                if( $parent_cate_id==$key ){
                    $this->data['base_info']['rank_num'] = $i;
                    break;
                }
                $i++;
            }
        }
        //数据统计部分 排序
        $paixu = array();
        foreach( $month_num as $key=>$val ){
            if( isset($paixu_temp[$key])&&$paixu_temp[$key] ){
                $paixu[] = array(
                    'id' => $key,
                    'name' => $paixu_temp[$key],
                    'num' => $val
                );    
            }
        }
        $this->data['base_info']['paixu'] = $paixu;
        
        //数据统计  导出
        if( isset($_GET['export'])&&($_GET['export']) ){
            $fields = array(
                '#'=>'#',
                'name' => '分组名称',
                'num' => '用户数'
            );
            if( $paixu ){
                $this->excel_export('分组排名', '分组排名', $fields, $paixu);exit;
            }
        }
        
        $this->load->view('c/qudao_cate/base_info.php',$this->data);
    }
    
    //数据统计
    public function base_info()
    {
        $this->month_init();
        if( $this->site_id=='526775b1e15b4079' ){
            return $this->base_info_yt();
        }
        
        $this->data['base_info'] = array();
        
        $parent_cate_id = intval($this->input->get('parent_cate_id'));
        $cate_id = intval($this->input->get('cate_id'));
        $this->data['nav']['parent_cate_id'] = $parent_cate_id;
        $this->data['nav']['cate_id'] = $cate_id;
        
        //分组导航
        $this->data['base_info']['nav'] = array();
        $this->load->model('qudao_cate_model');
        $parent_cate = $this->qudao_cate_model->where(array('site_id'=>$this->site_id,'id'=>$parent_cate_id,'parent_id'=>0))->find();
        if( !$parent_cate ){
            redirect('/c/qudao_cate/index');
        }
        $this->data['base_info']['nav'][] = $parent_cate['name'];
        $this->load->model('qudao_model');
        
        if( $cate_id ){//二级分组
            $this->data['base_info']['type'] = 11;//有渠道排名数据
            $this->data['base_info']['selected_id'] = $cate_id;
            $child_cate = $this->qudao_cate_model->where(array('site_id'=>$this->site_id,'id'=>$cate_id,'parent_id'=>$parent_cate['id']))->find();
            if( !$child_cate ){
                redirect('/c/qudao_cate/index');
            }
            $this->data['base_info']['nav'][] = $child_cate['name'];
            $this->cate_level();
            $child_cates = $this->data['cate_level']['child'][$parent_cate_id];
            if( $child_cates ){
                //月度指标  //实际完成
                $zhibiao_num = $month_num = array();
                $paixu_temp = array();
                foreach( $child_cates as $val ){
                    $temp1 = $this->qudao_model->get_zhibiao_num($this->site_id,$val['id'],'child');
                    $zhibiao_num[$val['id']] = intval($temp1['num']);
                    
                    $temp2 = $this->qudao_model->zhibiao_month_num($this->site_id,$val['id'],'child');
                    $month_num[$val['id']] = intval($temp2['num']);
                    $paixu_temp[$val['id']] = $val['name'];
                }
                if( !isset($zhibiao_num[$cate_id])||!isset($month_num[$cate_id]) ){
                    redirect('/c/qudao_cate/index');
                }
            }else{
                redirect('/c/qudao_cate/index');
            }
            $this->data['base_info']['zhibiao_num'] = $zhibiao_num[$cate_id];
            //实际完成
            $this->data['base_info']['month_num'] = $month_num[$cate_id];
            arsort($month_num);
            $i = 1;
            foreach( $month_num as $key=>$val ){
                if( $cate_id==$key ){
                    $this->data['base_info']['rank_num'] = $i;
                    break;
                }
                $i++;
            }
            
            //银泰查看二级分组下的  各个渠道的双月 完成额
            $qudaos_num = $this->qudao_model->qudao_zhibiao_num($this->site_id,$cate_id);
            if( !$qudaos_num ){
                redirect('/c/qudao_cate/index');
            }
            $this->data['base_info']['qudaos_num'] = $qudaos_num;
            
            //渠道排名  导出
            if( isset($_GET['export1'])&&($_GET['export1']) ){
                $fields = array(
                    '#'=>'#',
                    'name' => '渠道名',
                    'num' => '用户数'
                );
                if( $qudaos_num ){
                    $this->excel_export('渠道排名', '渠道排名', $fields, $qudaos_num);exit;
                }
            }
            
        }else{
            $this->data['base_info']['type'] = 1;//没有渠道排名数据
            $this->data['base_info']['selected_id'] = $parent_cate_id;
            //月度指标  //实际完成
            $zhibiao_num = $month_num = array();
            $paixu_temp = array();
            $this->cate_level();
            $first_cate = $this->data['cate_level']['parent'];
            if( $first_cate ){
                foreach( $first_cate as $val ){
                    $temp1 = $this->qudao_model->get_zhibiao_num($this->site_id,$val['id'],'parent');
                    $zhibiao_num[$val['id']] = intval($temp1['num']);
                    
                    $temp2 = $this->qudao_model->zhibiao_month_num($this->site_id,$val['id'],'parent');
                    $month_num[$val['id']] = intval($temp2['num']);
                    $paixu_temp[$val['id']] = $val['name'];
                }
                
                if( !isset($zhibiao_num[$parent_cate_id])||!isset($month_num[$parent_cate_id]) ){
                    redirect('/c/qudao_cate/index');
                }
            }else{
                redirect('/c/qudao_cate/index');
            }
            $this->data['base_info']['zhibiao_num'] = $zhibiao_num[$parent_cate_id];
            //实际完成
            $this->data['base_info']['month_num'] = $month_num[$parent_cate_id];
            arsort($month_num);
            $i = 1;
            foreach( $month_num as $key=>$val ){
                if( $parent_cate_id==$key ){
                    $this->data['base_info']['rank_num'] = $i;
                    break;
                }
                $i++;
            }
        }
        
        //数据统计部分 排序
        $paixu = array();
        foreach( $month_num as $key=>$val ){
            if( isset($paixu_temp[$key])&&$paixu_temp[$key] ){
                $paixu[] = array(
                    'id' => $key,
                    'name' => $paixu_temp[$key],
                    'num' => $val
                );    
            }
        }
        $this->data['base_info']['paixu'] = $paixu;
        
        
        //数据统计  导出
        if( isset($_GET['export'])&&($_GET['export']) ){
            $fields = array(
                '#'=>'#',
                'name' => '分组名称',
                'num' => '用户数'
            );
            if( $paixu ){
                $this->excel_export('分组排名', '分组排名', $fields, $paixu);exit;
            }
        }
        
        $this->load->view($this->dcm,$this->data);
    }
    
    //详细信息  银泰
    public function details_yt()
    {   
        $this->month_init();
        $this->data['detail'] = array();
        
        $search_url = site_url($this->uri->uri_string().'?');
        
        $paper = $this->input->get('page');
        $paper = $paper ? $paper : 1;
        $this->data['detail']['page'] = $paper;
        
        $parent_cate_id = intval($this->input->get('parent_cate_id'));
        $cate_id = intval($this->input->get('cate_id'));
        $this->data['nav']['parent_cate_id'] = $parent_cate_id;
        $this->data['nav']['cate_id'] = $cate_id;
        $search_url .= '&parent_cate_id='.$parent_cate_id;
        $search_url .= '&cate_id='.$cate_id;
        
        $this->load->model('qudao_cate_model');
        
        if( $parent_cate_id ){//分组管理
            $this->data['detail']['type'] = 1;
            //分组导航
            $this->data['detail']['nav'] = array();
            
            $parent_cate = $this->qudao_cate_model->where(array('site_id'=>$this->site_id,'id'=>$parent_cate_id,'parent_id'=>0))->find();
            if( !$parent_cate ){
                redirect('/c/qudao_cate/index');
            }
            $this->data['detail']['nav'][] = $parent_cate['name'];
            
            if( $cate_id ){//二级定位
                $this->data['detail']['show_type'] = 2;//显示2列数据
                $child_cate = $this->qudao_cate_model->where(array('site_id'=>$this->site_id,'id'=>$cate_id,'parent_id'=>$parent_cate['id']))->find();
                if( !$child_cate ){
                    redirect('/c/qudao_cate/index');
                }
                
                $this->data['detail']['nav'][] = $child_cate['name'];
                
                //导出
                if( isset($_GET['export'])&&($_GET['export']) ){
                    $this->details_export(4,$cate_id);exit;
                }
                
                $qudao_list_num = $this->qudao_model->qudao_account_num($this->site_id,$cate_id,'child',$this->get_month_yt());
                $this->data['detail']['list_num'] = $qudao_list_num;
                $pager_obj = $this->_pager($qudao_list_num, array('per_page'=>15,'base_url'=>$search_url));
                
                $qudao_list = $this->qudao_model->qudao_account($this->site_id,$cate_id,'child',15,$paper,$this->get_month_yt());
                $qudao_list = $qudao_list ? $qudao_list : array();
                if( $qudao_list ){
                    foreach( $qudao_list as $key=>$val ){
                        $qudao_list[$key]['add_time'] = date('m-d H:i',$val['add_time']);
                    }
                }
                $this->data['detail']['list'] = $qudao_list;
                $this->data['page'] = $pager_obj['links'];
                $this->data['offset'] = $pager_obj['limit']['offset'];
                
            }else{
                $this->data['detail']['show_type'] = 1;//显示3列数据
                
                $qudao_list_num = $this->qudao_model->qudao_account_num($this->site_id,$parent_cate_id,'parent',$this->get_month_yt());
                $this->data['detail']['list_num'] = $qudao_list_num;
                $pager_obj = $this->_pager($qudao_list_num, array('per_page'=>15,'base_url'=>$search_url));
                
                //导出
                if( isset($_GET['export'])&&($_GET['export']) ){
                    $this->details_export(3,$parent_cate_id);exit;
                }
                
                $qudao_list = $this->qudao_model->qudao_account($this->site_id,$parent_cate_id,'parent',15,$paper,$this->get_month_yt());
                $qudao_list = $qudao_list ? $qudao_list : array();
                if( $qudao_list ){
                    foreach( $qudao_list as $key=>$val ){
                        $qudao_list[$key]['add_time'] = date('m-d H:i',$val['add_time']);
                    }
                }
                $this->data['detail']['list'] = $qudao_list;
                $this->data['page'] = $pager_obj['links'];
                $this->data['offset'] = $pager_obj['limit']['offset'];
            }
        }else{
            redirect('/c/qudao_cate/index');
        }
        
        $this->load->view($this->dcm, $this->data);
    }
    
    //详细信息
    public function details()
    {
        if( $this->site_id=='526775b1e15b4079' ){
            return $this->details_yt();
        }
        $this->month_init();
        $this->data['detail'] = array();
        
        $search_url = site_url($this->uri->uri_string().'?');
        
        $paper = $this->input->get('page');
        $paper = $paper ? $paper : 1;
        $this->data['detail']['page'] = $paper;
        
        $parent_cate_id = intval($this->input->get('parent_cate_id'));
        $cate_id = intval($this->input->get('cate_id'));
        $this->data['nav']['parent_cate_id'] = $parent_cate_id;
        $this->data['nav']['cate_id'] = $cate_id;
        $search_url .= '&parent_cate_id='.$parent_cate_id;
        $search_url .= '&cate_id='.$cate_id;
        
        $this->load->model('qudao_cate_model');
        
        if( $parent_cate_id ){//分组管理
            $this->data['detail']['type'] = 1;
            //分组导航
            $this->data['detail']['nav'] = array();
            
            $parent_cate = $this->qudao_cate_model->where(array('site_id'=>$this->site_id,'id'=>$parent_cate_id,'parent_id'=>0))->find();
            if( !$parent_cate ){
                redirect('/c/qudao_cate/index');
            }
            $this->data['detail']['nav'][] = $parent_cate['name'];
            
            if( $cate_id ){//二级定位
                $this->data['detail']['show_type'] = 2;//显示2列数据
                $child_cate = $this->qudao_cate_model->where(array('site_id'=>$this->site_id,'id'=>$cate_id,'parent_id'=>$parent_cate['id']))->find();
                if( !$child_cate ){
                    redirect('/c/qudao_cate/index');
                }
                
                $this->data['detail']['nav'][] = $child_cate['name'];
                
                //导出
                if( isset($_GET['export'])&&($_GET['export']) ){
                    $this->details_export(2,$cate_id);exit;
                }
                
                $qudao_list_num = $this->qudao_model->qudao_account_num($this->site_id,$cate_id,'child');
                $this->data['detail']['list_num'] = $qudao_list_num;
                $pager_obj = $this->_pager($qudao_list_num, array('per_page'=>15,'base_url'=>$search_url));
                
                $qudao_list = $this->qudao_model->qudao_account($this->site_id,$cate_id,'child',15,$paper);
                $qudao_list = $qudao_list ? $qudao_list : array();
                if( $qudao_list ){
                    foreach( $qudao_list as $key=>$val ){
                        $qudao_list[$key]['add_time'] = date('m-d H:i',$val['add_time']);
                    }
                }
                $this->data['detail']['list'] = $qudao_list;
                $this->data['page'] = $pager_obj['links'];
                $this->data['offset'] = $pager_obj['limit']['offset'];
                
            }else{
                $this->data['detail']['show_type'] = 1;//显示3列数据
                
                $qudao_list_num = $this->qudao_model->qudao_account_num($this->site_id,$parent_cate_id,'parent');
                $this->data['detail']['list_num'] = $qudao_list_num;
                $pager_obj = $this->_pager($qudao_list_num, array('per_page'=>15,'base_url'=>$search_url));
                
                //导出
                if( isset($_GET['export'])&&($_GET['export']) ){
                    $this->details_export(1,$parent_cate_id);exit;
                }
                
                $qudao_list = $this->qudao_model->qudao_account($this->site_id,$parent_cate_id,'parent',15,$paper);
                $qudao_list = $qudao_list ? $qudao_list : array();
                if( $qudao_list ){
                    foreach( $qudao_list as $key=>$val ){
                        $qudao_list[$key]['add_time'] = date('m-d H:i',$val['add_time']);
                    }
                }
                $this->data['detail']['list'] = $qudao_list;
                $this->data['page'] = $pager_obj['links'];
                $this->data['offset'] = $pager_obj['limit']['offset'];
            }
        }else{
            redirect('/c/qudao_cate/index');
        }
        
        $this->load->view($this->dcm, $this->data);
    }
    
    //详细信息  导出
    public function details_export($type,$cate_id)
    {
        $list = array();
        if( $type==1 ){
            $list = $this->qudao_model->qudao_account($this->site_id,$cate_id,'parent');
            if( $list ){
                foreach( $list as $key=>$val ){
                    $list[$key]['add_time'] = date('m-d H:i',$val['add_time']);
                }
            }
            $fields = array(
                '#'=>'#',
                'cate_name' => '分组名称',
                'name' => '渠道名称',
                'add_time' => '关注时间'
            );
        }
        if( $type==2 ){
            $list = $this->qudao_model->qudao_account($this->site_id,$cate_id,'child');
            if( $list ){
                foreach( $list as $key=>$val ){
                    $list[$key]['add_time'] = date('m-d H:i',$val['add_time']);
                }
            }
            $fields = array(
                '#'=>'#',
                'name' => '渠道名称',
                'add_time' => '关注时间'
            );
        }
        if( $type==3 ){
            $list = $this->qudao_model->qudao_account($this->site_id,$cate_id,'parent','','',$this->get_month_yt());
            if( $list ){
                foreach( $list as $key=>$val ){
                    $list[$key]['add_time'] = date('m-d H:i',$val['add_time']);
                }
            }
            $fields = array(
                '#'=>'#',
                'cate_name' => '分组名称',
                'name' => '渠道名称',
                'add_time' => '关注时间'
            );
        }
        if( $type==4 ){
            $list = $this->qudao_model->qudao_account($this->site_id,$cate_id,'child','','',$this->get_month_yt());
            if( $list ){
                foreach( $list as $key=>$val ){
                    $list[$key]['add_time'] = date('m-d H:i',$val['add_time']);
                }
            }
            $fields = array(
                '#'=>'#',
                'name' => '渠道名称',
                'add_time' => '关注时间'
            );
        }
        
        if( $list ){
            $this->excel_export('月度关注详情', '月度关注详情', $fields, $list);
        }
    }
    
    
    //初始化月份统计表
    private function month_init()
    {
        $this->load->model('qudao_model');
        $list = $this->qudao_model->get_all(array('site_id'=>$this->site_id,'is_delete'=>0),'','','id desc','','id');
        if( $list ){
            $this->load->model('qudao_wxid_month_model');
            $month = mktime(0, 0 , 0,date("m"),1,date("Y"));
            foreach( $list as $val ){
                $stac = $this->qudao_wxid_month_model->get_row(array('site_id'=>$this->site_id,'qudao_id'=>$val['id'],'add_time'=>$month));
                if( !$stac ){
                    $this->qudao_wxid_month_model->add(array('site_id'=>$this->site_id,'qudao_id'=>$val['id'],'add_time'=>$month));
                }
            }
        }
    }
    
    //银泰专用  2个月一统计
    private function get_month_yt($step=0)
    {
        $ret_month_time = array();
        $month = date('m',time());
        if( $month%2==0 ){
            $ret_month_time[] = mktime(0, 0 , 0,date("m")-1,1,date("Y"));
            $ret_month_time[] = mktime(0, 0 , 0,date("m"),1,date("Y"));
        }else{
            $ret_month_time[] = mktime(0, 0 , 0,date("m"),1,date("Y"));
            $ret_month_time[] = mktime(0, 0 , 0,date("m")+1,1,date("Y"));
        }
        if( $step>0 ){
            $re_start_m = date('m',$ret_month_time[0]);
            if( $re_start_m-1<=0 ){
                $ret_month_time[0] = mktime(0, 0 , 0,11,1,date("Y")-1);
                $ret_month_time[1] = mktime(0, 0 , 0,12,1,date("Y")-1);
            }else{
                $ret_month_time[0] = mktime(0, 0 , 0,$re_start_m-2,1,date("Y"));
                $ret_month_time[1] = mktime(0, 0 , 0,$re_start_m-1,1,date("Y"));
            }
        }
        return $ret_month_time;
    }
    
    /*//老的分组  兼容新分组
    public function extend_data()
    {
        $this->qudao_cate_model->where(array('password'=>''))->edit(array('password'=>md5('123456')));
        
        $group_site = $this->qudao_cate_model
                      ->where(array('parent_id'=>0,'name !='=>'默认分组'))
                      ->group_by('site_id')->find_all();
        
        if( $group_site ){
            foreach( $group_site as $val ){
                
                //二级分组补充前缀
                $temp_list = $this->qudao_cate_model->where(array('site_id'=>$val['site_id'],'prefix'=>''))->find_all();
                if( $temp_list&&( count($temp_list<100) ) ){
                    $i = 0;
                    if( $i<100 ){
                        foreach( $temp_list as $v ){
                            if( $i<10 ){
                                $b = '0'.$i;
                            }else{
                                $b = $i;
                            }
                            $this->qudao_cate_model->where(array('id'=>$v['id']))->edit(array('prefix'=>$b));
                            $i++;
                        }
                    }
                }
                //添加默认分组
                $in_data = array(
                    'site_id'   => $val['site_id'],
                    'parent_id' => 0,
                    'name'      => '默认分组',
                    'prefix'    => 'A',
                    'password'  => '12345',
                    'rank'      => 255
                );
                if( $insert_id=$this->qudao_cate_model->add($in_data) ){
                    $this->qudao_cate_model
                        ->where(array('site_id'=>$val['site_id'],'id <'=>$insert_id))
                        ->edit(array('parent_id'=>$insert_id));
                    $erji_cate = $this->qudao_cate_model->where(array('site_id'=>$val['site_id'],'parent_id'=>$insert_id))->find_all();
                    if( $erji_cate ){
                        $this->load->model('qudao_model');
                        foreach( $erji_cate as $v ){
                            $this->qudao_model
                            ->where(array('site_id'=>$val['site_id'],'cate_id <'=>$v['id']))
                            ->edit(array('parent_cate_id'=>$insert_id));
                        }
                    }
                }
                
            }
        }
        echo "转换完成";
    }*/
    
}