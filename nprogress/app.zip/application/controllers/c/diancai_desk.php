<?php
/**
 * 点菜餐台
 * Enter description here ...
 * @author Administrator
 *
 */
class Diancai_desk extends C_Controller {
    
    protected $data = '';
    private $site_id = '';
    
    public function __construct()
    {
        parent::__construct();
        
        $this->site_id = $this->site_info['id'];
        
        $this->load->model('diancai_desk_model');
        $this->load->model('diancai_store_model');
    }

    public function index()
    {
        $search['sid'] = $this->input->get('sid');
        $search['name'] = $this->input->get('name');
        $search['status'] = $this->input->get('status');
        
        $store = $this->diancai_store_model->select('id')->where(array('id'=>$search['sid'],'site_id'=>$this->site_id))->find();
        if( !$store ){
            return $this->show_message(false, '没有找到该门店', '/c/diancai');
        }
        $this->data['store'] = $store;
        
        $where = "site_id = '".$this->site_id."' AND store_id = ".$search['sid'];
        $search['name'] && $where .= " AND name LIKE '%".$search['name']."%'";
        $search['status']!='' && $where .= " AND status = ".$search['status'];
        
        $total_rows = $this->diancai_desk_model->where($where)->count();
        $search_url = site_url($this->uri->uri_string().'?'.http_build_query($search));
        $pager = $this->_pager($total_rows,array('per_page'=>15,'base_url'=>$search_url));
        
        $list = $this->diancai_desk_model->select('id,name,contain,dinning_person,status,listorder')
                ->where($where)
                ->limit($pager['limit']['value'], $pager['limit']['offset'])
                ->find_all();
        $this->data['list'] = $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        
        $this->load->view($this->dcm, $this->data);
    }
    
    public function add()
    {
        $sid = $this->input->get('sid');
        if( !$sid ){
            return $this->show_message(false, '请求非法', '/c/diancai_store');
        }
        
        $store = $this->diancai_store_model->select('id')->where(array('id'=>$sid,'site_id'=>$this->site_id))->find();
        if( !$store ){
            return $this->show_message(false, '没有找到该门店', '/c/diancai_store');
        }
        $this->data['store'] = $store;
        
        if( $this->input->post() ){
            $this->form_validation->set_rules('name', '餐桌名', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('contain', '容纳人数', 'trim|required|is_natural_no_zero');
            $this->form_validation->set_rules('listorder', '排序', 'trim|is_natural');
            if ( $this->form_validation->run() ){
                
                $save_data['name'] = $this->form_validation->set_value('name');
                $save_data['contain'] = $this->form_validation->set_value('contain');
                $save_data['listorder'] = $this->form_validation->set_value('listorder');
                
                $save_data['site_id'] = $this->site_id;
                $save_data['store_id'] = $store['id'];
                
                if( $this->diancai_desk_model->add($save_data) ){
                    return $this->show_message(true, '添加成功', '/c/diancai_desk/index?sid='.$store['id']);
                }else{
                    return $this->show_message(false, '添加失败', '/c/diancai_desk/index?sid='.$store['id']);
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            $this->load->view($this->dcm, $this->data);
        }
        
    }
    
    public function edit()
    {
        $sid = $this->input->get('sid');
        if( !$sid ){
            return $this->show_message(false, '请求非法', '/c/diancai_store');
        }
        $id = $this->input->get('id');
        if( !$id ){
            return $this->show_message(false, '请求非法', '/c/diancai_store');
        }
        
        $store = $this->diancai_store_model->select('id')->where(array('id'=>$sid,'site_id'=>$this->site_id))->find();
        if( !$store ){
            return $this->show_message(false, '没有找到该门店', '/c/diancai_store');
        }
        $this->data['store'] = $store;
        
        $desk = $this->diancai_desk_model->where(array('id'=>$id,'store_id'=>$store['id']))->find();
        if( !$desk ){
            return $this->show_message(false, '请求非法', '/c/diancai_store');
        }
        $this->data['desk'] = $desk;
        
        if( $this->input->post() ){
            $this->form_validation->set_rules('name', '餐桌名', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('contain', '容纳人数', 'trim|required|is_natural_no_zero');
            $this->form_validation->set_rules('listorder', '排序', 'trim|is_natural');
            if ( $this->form_validation->run() ){
                
                $save_data['name'] = $this->form_validation->set_value('name');
                $save_data['contain'] = $this->form_validation->set_value('contain');
                $save_data['listorder'] = $this->form_validation->set_value('listorder');
                
                $save_data['site_id'] = $this->site_id;
                $save_data['store_id'] = $store['id'];
                
                if( $this->diancai_desk_model->where(array('id'=>$desk['id']))->edit($save_data) ){
                    return $this->show_message(true, '修改成功', '/c/diancai_desk/index?sid='.$store['id']);
                }else{
                    return $this->show_message(false, '修改失败', '/c/diancai_desk/index?sid='.$store['id']);
                }
            }else{
                $errors = validation_errors();
                if ($errors) {
                    $this->show_message(FALSE, $errors, '');
                    return FALSE;
                }
            }
        }else{
            $this->load->view($this->dcm, $this->data);
        }
    }
    
    //餐台二维码
    public function desk_qrcode()
    {
        $sid = $this->input->get('sid');
        if( !$sid ){
            return $this->show_message(false, '请求非法', '/c/diancai_store');
        }
        $id = $this->input->get('id');
        if( !$id ){
            return $this->show_message(false, '请求非法', '/c/diancai_store');
        }
        
        $store = $this->diancai_store_model->select('id')->where(array('id'=>$sid,'site_id'=>$this->site_id))->find();
        if( !$store ){
            return $this->show_message(false, '没有找到该门店', '/c/diancai_store');
        }
        $this->data['store'] = $store;
        
        $desk = $this->diancai_desk_model->where(array('id'=>$id,'store_id'=>$store['id']))->find();
        if( !$desk ){
            return $this->show_message(false, '请求非法', '/c/diancai_store');
        }
        
        $content = $this->create_url('diancai/stuffList').'?id='.$store['id'].'&desk='.$desk['id'];
        $this->load->library('Qrcode_make');
        $this->qrcode_make->make_direct($content);
    }
    
    public function delete()
    {
        $sid = $this->input->get('sid');
        if( !$sid ){
            return $this->show_message(false, '请求非法', '/c/diancai_store');
        }
        $id = $this->input->get('id');
        if( !$id ){
            return $this->show_message(false, '请求非法', '/c/diancai_store');
        }
        
        $store = $this->diancai_store_model->select('id')->where(array('id'=>$sid,'site_id'=>$this->site_id))->find();
        if( !$store ){
            return $this->show_message(false, '没有找到该门店', '/c/diancai_store');
        }
        $this->data['store'] = $store;
        
        $desk = $this->diancai_desk_model->where(array('id'=>$id,'store_id'=>$store['id']))->find();
        if( !$desk ){
            return $this->show_message(false, '请求非法', '/c/diancai_store');
        }
        if( $desk['dinning_person'] ){
            return $this->show_message(false, '该餐台正有人在吃饭，不能删除', '/c/diancai_desk/index?sid='.$store['id']);
        }
        
        if( $this->diancai_desk_model->where(array('id'=>$desk['id']))->delete() ){
            return $this->show_message(true, '删除成功', '/c/diancai_desk/index?sid='.$store['id']);
        }else{
            return $this->show_message(false, '请求非法', '/c/diancai_desk/index?sid='.$store['id']);
        }
        
    }
    
}