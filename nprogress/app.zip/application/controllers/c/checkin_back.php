<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: cullen
 * Date: 14-4-16
 * Time: 上午11:08
 * @property Checkin_model $checkin_model
 */

class Checkin extends C_Controller {
    private $site_id = '';
    public function __construct()
    {
        parent::__construct();
        $this->site_id = $this->site_info['id'];
        $this->load->model('checkin_model');
    }

    /**
     * @name 签到列表
     */
    public function index()
    {
        $where = "site_id='".$this->site_id."'";
        $search_url = site_url($this->uri->uri_string().'?');
        $search['keyword'] = $this->input->get('keyword');
        if( $search['keyword'] ){
            $where .= " AND ( title LIKE '%".$search['keyword']."%' OR reply_keyword LIKE '%".$search['keyword']."%' ) ";
            $search_url .= '&keyword='.$search['keyword'];
        }

        $total_rows = $this->checkin_model->where($where)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>10,'base_url'=>$search_url));
        $list = $this->checkin_model->where($where)->limit($pager['limit']['value'], $pager['limit']['offset'])->order_by('id desc')->find_all();
        $this->data['list'] =  $list;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->data['search'] = $search;
        $this->load->view($this->dcm, $this->data);
    }

    /**
     * 添加签到
     * @return bool|void
     */
    public function add()
    {
        $post = $this->input->post();
        if($post)
        {
            $result = $this->dataPosts($post);
            if(is_array($result))
            {
            	$stime = substr($result['start_time'],0,13).":00:00";
	           	$dtime = substr($result['end_time'],0,13).":00:00";
	           	$result['start_time'] = strtotime($stime);
	            $result['end_time'] = strtotime($dtime);
            	$res = $this->getKeyword($result['reply_keyword']);
				if($res){
					$this->show_message(false, '关键字已经存在', '');
					return FALSE;
				}
                $result['site_id'] = $this->site_id;
                $result['dt_add'] = time();
                $checkinid = $this->checkin_model->add($result);
                if($checkinid)
                {
                    return $this->show_message(true, '添加成功', '/c/checkin');
                }
                else
                {
                    return $this->show_message(false, '添加失败', '');
                }
            }
            else
            {
                return $this->show_message(false,$result,'');
                
            }
        }
        else
        {
            $this->load->view($this->dcm, $this->data);
        }
    }

    /**
     * @name 处理签到post请求
     * @param $post
     * @return bool|string
     */
    private function dataPost($post)
    {
        if(is_array($post))
        {
            $this->load->library('form_validation');

            $this->form_validation->set_rules('title', '签到名称', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('reply_keyword', '回复关键词', 'trim|required');
            $this->form_validation->set_rules('reply_title', '关键词回复标题', 'trim|required');
            $this->form_validation->set_rules('reply_image', '关键词回复图片', 'trim|required|callback__check_image');
            $this->form_validation->set_rules('s_time', '签到开始时间', 'trim|required');
            $this->form_validation->set_rules('d_time', '签到结束时间', 'trim|required');
            $this->form_validation->set_rules('exchange_intro', '兑换说明', 'trim|htmlspecialchars');
            $this->form_validation->set_rules('youxi_intro', '游戏说明', 'trim|htmlspecialchars');
            $this->form_validation->set_rules('yx_duihuan', '兑换内容', 'trim|required');
            $this->form_validation->set_rules('yx_jingpin', '游戏奖品', 'trim|required');
            $this->form_validation->set_rules('ad_status', '广告开启', 'trim|required');

            if ( $this->form_validation->run() )
            {
                $dataSet['title'] = $this->form_validation->set_value('title');
                $dataSet['reply_keyword'] = $this->form_validation->set_value('reply_keyword');
                $dataSet['reply_title'] = $this->form_validation->set_value('reply_title');
                $dataSet['reply_image'] = $this->form_validation->set_value('reply_image');
                $dataSet['start_time'] = $this->form_validation->set_value('s_time');
                $dataSet['end_time'] = $this->form_validation->set_value('d_time');
                $dataSet['ex_status'] = $this->form_validation->set_value('yx_duihuan');
                $dataSet['yx_status'] = $this->form_validation->set_value('yx_jingpin');
                $dataSet['ad_status'] = $this->form_validation->set_value('ad_status');
                //积分规则
                $rule = (isset($post['rule']) && is_array($post['rule'])) ? $post['rule'] : array();
                if(!$rule)
                {
                    return "<p>积分规则不能为空</p>";
                }
                foreach($rule as $_rule)
                {
                    if(!is_numeric($_rule['number']) || $_rule['number'] <1 )
                    {
                        return "<p>积分必须大于0</p>";
                    }
                }
                $dataSet['check_rules'] = json_encode($post['rule']);
                $dataSet['exchange_intro'] = $this->form_validation->set_value('exchange_intro');
                $dataSet['youxi_intro'] = $this->form_validation->set_value('youxi_intro');
                
                $dataSet['error'] = 0;
                return $dataSet;
            }
            else
            {
            	$errors = validation_errors();
                if ($errors) {
                    return $errors;
                }
            }
        }
        else
        {
            return false;
        }
    }

    /**
     * 编辑签到
     * @param string $id
     * @return bool|void
     */
    public function edit($id=''){
	    $this->load->model('checkin_model');
    	$post = $this->input->post();
    	if(!$id){
    		return $this->show_message(false, '无效请求', '',1);
    	}
       	$res = $this->checkin_model->where(array('id'=>$id))->find();
    	if($res['site_id']!=$this->site_id){
    		return $this->show_message(false, '无权限', '',1);
    	}
		$result = $this->getCheckin($id);
		$this->data['list']=$result;
	    if($post)
        {
            $result = $this->dataPosts($post);
            if(is_array($result))
            {
            	$stime = substr($result['start_time'],0,13).":00:00";
	           	$dtime = substr($result['end_time'],0,13).":00:00";
	           	$result['start_time'] = strtotime($stime);
	            $result['end_time'] = strtotime($dtime);
            	$res = $this->getKeyword($result['reply_keyword'],$id);
				if($res){
					$this->show_message(false, '关键字已经存在', '');
					return FALSE;
				}
                $checkinid = $this->checkin_model->where(array('id'=>$id))->edit($result);;
                if($checkinid)
                {
                    return $this->show_message(true, '修改成功', '/c/checkin');
                }
                else
                {
                    return $this->show_message(false, '添加失败', '');
                }
            }
            else
            {
                return $this->show_message(false,$result,'');
            }
        }
        else
        {
            $this->load->view($this->dcm, $this->data);
        }
	}

    /**
     * 删除签到
     * @param string $id
     * @return bool|void
     */
    public function delete($id=''){
    	$this->load->model('checkin_model');
        if(!$id){
            $this->show_message(false, '非法参数', 1);return false;
        }
        $res = $this->checkin_model->where(array('id'=>$id))->find();
        if(!$res){
        	return $this->show_message(false, '不存在', '',1);
        }
    	if($res['site_id']!=$this->site_id){
    		return $this->show_message(false, '无权限', '',1);
    	}        
        $request = $this->checkin_model->where(array('id'=>$id))->delete();
        if($request){
        	 $this->show_message(true, '删除成功', '');return FALSE;
        }
       
    }
    /**
     * @name 处理签到post请求
     * @param $post
     * @return bool|string
     */
    private function dataPosts($post)
    {
        if(is_array($post))
        {
            $this->load->library('form_validation');

            $this->form_validation->set_rules('title', '活动标题', 'trim|required|max_length[50]');
            $this->form_validation->set_rules('reply_keyword', '回复关键词', 'trim|required');
            $this->form_validation->set_rules('reply_title', '关键词回复标题', 'trim|required');
            $this->form_validation->set_rules('reply_image', '关键词回复图片', 'trim|required|callback__check_image');
            $this->form_validation->set_rules('s_time', '签到开始时间', 'trim|required');
            $this->form_validation->set_rules('d_time', '签到结束时间', 'trim|required');
            $this->form_validation->set_rules('exchange_intro', '兑换说明', 'trim|htmlspecialchars');
            $this->form_validation->set_rules('youxi_intro', '游戏说明', 'trim|htmlspecialchars');
            $this->form_validation->set_rules('yx_duihuan', '兑换内容', 'trim|required');
            $this->form_validation->set_rules('yx_jingpin', '游戏奖品', 'trim|required');
            //$this->form_validation->set_rules('ad_status', '广告开启', 'trim|required');
            if ( $this->form_validation->run() )
            {
                $dataSet['title'] = $this->form_validation->set_value('title');
                $dataSet['reply_keyword'] = $this->form_validation->set_value('reply_keyword');
                $dataSet['reply_title'] = $this->form_validation->set_value('reply_title');
                $dataSet['reply_image'] = $this->form_validation->set_value('reply_image');
                $dataSet['start_time'] = $this->form_validation->set_value('s_time');
                $dataSet['end_time'] = $this->form_validation->set_value('d_time');
                $dataSet['ex_status'] = $this->form_validation->set_value('yx_duihuan');
                $dataSet['yx_status'] = $this->form_validation->set_value('yx_jingpin');
                //$dataSet['ad_status'] = $this->form_validation->set_value('ad_status');
                //积分规则
                $rule = (isset($post['rule']) && is_array($post['rule'])) ? $post['rule'] : array();
                if(!$rule)
                {
                    return "<p>积分规则不能为空</p>";
                }
                foreach($rule as $_rule)
                {
                    if(!is_numeric($_rule['number']) || $_rule['number'] <1 )
                    {
                        return "<p>积分必须大于0</p>";
                    }
                }
                $dataSet['check_rules'] = json_encode($post['rule']);
                $dataSet['exchange_intro'] = $this->form_validation->set_value('exchange_intro');
                $dataSet['youxi_intro'] = $this->form_validation->set_value('youxi_intro');
                return $dataSet;
            }
            else
            {
                $errors = validation_errors();
                if ($errors) {
                    return $errors;
                }
            }
        }
        else
        {
            return false;
        }
    }
    /**
     * @name 获取一个签到详情
     * @param string $id
     * @return array
     */
    private function getCheckin($id = '')
    {
        $result = $this->checkin_model->where(array('site_id'=>$this->site_id,'id'=>$id))->find();
        $result = $result ? $result : array();
        return $result;
    }

     /**
     * @name 游戏列表
     */
    public function youxi($checkin_id=''){
    	$this->load->model('checkin_yx_model');
    	$wheres['checkin_id'] = $checkin_id;
        $wheres['site_id'] = $this->site_id;
    	$total_rows = $this->checkin_yx_model->where($wheres)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>10));
        
    	if(!$checkin_id){
    		return $this->show_message(false, '无效请求', '',1);
    	}

    	$opArray = array('1'=>'会员积分','2'=>'实物','3'=>'再来一次','4'=>'谢谢参与');
    	$where['site_id'] = $this->site_id;
    	$where['checkin_id'] = $checkin_id;
    	$result = $this->checkin_yx_model->where($where)->limit($pager['limit']['value'], $pager['limit']['offset'])->order_by('id desc')->find_all();
        foreach($result as &$value)
        {
        	$yx_status = $value['yx_status'];
            $value['options']= $opArray[$yx_status];
        }
        $checkinfo = $this->get_checkinfo($checkin_id);
        $this->data['checkinfo'] = $checkinfo;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
    	$this->data['list'] = $result;
    	$this->data['checkin_id'] = $checkin_id;
    	$this->load->view($this->dcm,$this->data);
    }
    
     /**
     * @name 添加游戏
     */
    public function yx_add($checkin_id=''){
    	$post = $this->input->post();
    	$this->load->model('checkin_yx_model');
    	if(!$checkin_id){
    		return $this->show_message(false, '无效请求', '',1);
    	}
    	$checkinfo = $this->get_checkinfo($checkin_id);
        $this->data['checkinfo'] = $checkinfo;
    	//添加游戏
        if($post)
        {
        	$this->load->library('form_validation');
        	$wheres['checkin_id'] = $checkin_id;
      		$wheres['site_id'] = $this->site_id;
    		$total_rows = $this->checkin_yx_model->where($wheres)->count();
            if($total_rows>=8){
	    		$this->show_message(false, '奖项最多8个', '');
	    		return false;
	    	}
	    	$this->form_validation->set_rules('yx_title', '项目名称', 'trim|required');
	    	$this->form_validation->set_rules('yx_num', '数量', 'trim|required|numeric');
            $this->form_validation->set_rules('stock', '库存', 'trim|required|numeric');
	    	$this->form_validation->set_rules('yx_chance', '中奖率', 'trim|required|numeric');
	    	$this->form_validation->set_rules('image', '示例图片', 'trim|required|callback__check_image');
	    	$this->form_validation->set_rules('yx_status', '奖项类型', 'trim|required');
			if($this->form_validation->run()){
				$yx_chance = $this->form_validation->set_value('yx_chance');
				$all_chance = $this->getChance($checkin_id);
				$v = $yx_chance+$all_chance;
				if($v>100){
					$this->show_message(FALSE, '总中奖率不能大于100', '');
					return FALSE;
				}
				$dataSet['site_id'] = $this->site_id;
				$dataSet['checkin_id'] = $checkin_id;
				$dataSet['yx_title'] = $this->form_validation->set_value('yx_title');
				$dataSet['yx_num'] = $this->form_validation->set_value('yx_num');
                $dataSet['stock'] = $this->form_validation->set_value('stock');
                if( $dataSet['stock']<-1 ){
                    return $this->show_message(FALSE, '库存必须大于等于-1', '');
                }
				$dataSet['yx_pic'] = $this->form_validation->set_value('image');
				$dataSet['yx_chance'] = $this->form_validation->set_value('yx_chance');
				if( !preg_match('/^[0-9]*\.?[0-9]{0,2}$/', $dataSet['yx_chance']) ){
                   return $this->show_message(FALSE, '中奖率最多两位小数', '');
                }
				$dataSet['yx_status'] = $this->form_validation->set_value('yx_status');
				$dataSet['add_time'] = time();
	            $add_yx = $this->checkin_yx_model->add($dataSet);
	            if($add_yx){
	                $this->show_message(true, '添加成功', '/c/checkin/youxi/'.$checkin_id);
	            }else{
	                $this->show_message(false, '添加失败', '');
	            }
			}else{
				$errors = validation_errors();
                if ($errors) {
                    return $this->show_message(FALSE, $errors, '');
                }
			}
        }else{
	    	$this->load->view($this->dcm,$this->data);
        }
    }

     /**
     * @name 游戏修改
     */
    public function yx_edit($id=''){
    	$this->load->model('checkin_yx_model');
    	$post = $this->input->post();
    	if(!$id){
    		return $this->show_message(false, '无效请求', '',1);
    	}
       	$res = $this->checkin_yx_model->where(array('id'=>$id))->find();
    	if($res['site_id']!=$this->site_id){
    		return $this->show_message(false, '无权限', '',1);
    	}
    	$checkin_id = $res['checkin_id'];
    	$checkinfo = $this->get_checkinfo($checkin_id);
        $this->data['checkinfo'] = $checkinfo;
    	if($post){
    		$this->form_validation->set_rules('yx_title', '项目名称', 'trim|required');
    		$this->form_validation->set_rules('yx_num', '数量', 'trim|required|numeric');
            $this->form_validation->set_rules('stock', '库存', 'trim|required|numeric');
	    	$this->form_validation->set_rules('yx_chance', '中奖率', 'trim|required|numeric');
	    	$this->form_validation->set_rules('image', '示例图片', 'trim|required|callback__check_image');
	    	$this->form_validation->set_rules('yx_status', '奖项类型', 'trim|required');
			if($this->form_validation->run()){
				$yx_chance = $this->form_validation->set_value('yx_chance');
				$all_chance = $this->getChance($checkin_id,$id);
				$v = $yx_chance+$all_chance;
				if($v>100){
					$this->show_message(FALSE, '总中奖率不能大于100', '');
					return FALSE;
				}
				$dataSet['yx_title'] = $this->form_validation->set_value('yx_title');
				$dataSet['yx_num'] = $this->form_validation->set_value('yx_num');
                $dataSet['stock'] = $this->form_validation->set_value('stock');
                if( $dataSet['stock']<-1 ){
                    return $this->show_message(FALSE, '库存必须大于等于-1', '');
                }
				$dataSet['yx_pic'] = $this->form_validation->set_value('image');
				$dataSet['yx_chance'] = $this->form_validation->set_value('yx_chance');
				if( !preg_match('/^[0-9]*\.?[0-9]{0,2}$/', $dataSet['yx_chance']) ){
                   return $this->show_message(FALSE, '中奖率最多两位小数', '');
                }
				$dataSet['yx_status'] = $this->form_validation->set_value('yx_status');
	            $add_yx = $this->checkin_yx_model->where(array('id'=>$id))->edit($dataSet);
	            if($add_yx){
	                $this->show_message(true, '修改成功', '/c/checkin/yx_edit/'.$id);
	            }else{
	                $this->show_message(false, '修改失败', '');
	            }
			}else{
				$errors = validation_errors();
                if ($errors) {
                    return $this->show_message(FALSE, $errors, '');
                }
			}
    	}else{
	    	$this->data['list']=$res;
	    	$this->load->view($this->dcm,$this->data);
    	}
    }
    
     /**
     * @name 游戏删除
     */
    public function yx_delete($id=''){
    	$this->load->model('checkin_yx_model');
        if(!$id){
            $this->show_message(false, '非法参数', 1);return false;
        }
        $res = $this->checkin_yx_model->where(array('id'=>$id))->find();
        if(!$res){
        	return $this->show_message(false, '不存在', '',1);
        }
    	if($res['site_id']!=$this->site_id){
    		return $this->show_message(false, '无权限', '',1);
    	}        
        $request = $this->checkin_yx_model->where(array('id'=>$id))->delete();
        if($request){
        	 $this->show_message(true, '删除成功', '');return FALSE;
        }
       
    }
    /*
     * 兑换设置部分
     */
    public function duihuan($checkin_id=''){
        $this->load->model('checkin_ex_model');
    	$wheres['checkin_id'] = $checkin_id;
        $wheres['site_id'] = $this->site_id;
    	$total_rows = $this->checkin_ex_model->where($wheres)->count();
        $pager = $this->_pager($total_rows, array('per_page'=>10));
        
    	if(!$checkin_id){
    		return $this->show_message(false, '无效请求', '',1);
    	}
    	$checkinfo = $this->get_checkinfo($checkin_id);
    	$opArray = array('1'=>'会员积分','2'=>'实物','3'=>'抽奖次数');
    	$where['site_id'] = $this->site_id;
    	$where['checkin_id'] = $checkin_id;
    	$result = $this->checkin_ex_model->where($where)->limit($pager['limit']['value'], $pager['limit']['offset'])->order_by('id desc')->find_all();
        foreach($result as &$value)
        {
        	$yx_status = $value['type'];
            $value['options']= $opArray[$yx_status];
        }
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
    	$this->data['list'] = $result;
    	$this->data['checkinfo'] = $checkinfo;
    	$this->data['checkin_id'] = $checkin_id;
    	$this->load->view($this->dcm,$this->data);
    }
    public function dh_add($checkin_id=''){
    	$post = $this->input->post();
    	$this->load->model('checkin_ex_model');
    	if(!$checkin_id){
    		return $this->show_message(false, '无效请求', '',1);
    	}
    	//添加兑换
        if($post)
        {
        	$wheres['checkin_id'] = $checkin_id;
      		$wheres['site_id'] = $this->site_id;
    		$total_rows = $this->checkin_ex_model->where($wheres)->count();
            if($total_rows>=9){
	    		$this->show_message(false, '奖项最多9个', '');
	    		return false;
	    	}
	    	$this->form_validation->set_rules('score', '签到积分', 'trim|required|numeric');
	    	$this->form_validation->set_rules('image', '示例图片', 'trim|required|callback__check_image');
	    	$this->form_validation->set_rules('type', '兑换项目', 'trim|required');
	    	$this->form_validation->set_rules('num', '数值', 'trim|required|numeric');
	    	$this->form_validation->set_rules('stock', '库存', 'trim|required|numeric');
	    	$this->form_validation->set_rules('name', '项目名称', 'trim|required');
			if($this->form_validation->run()){
				$dataSet['site_id'] = $this->site_id;
				$dataSet['checkin_id'] = $checkin_id;
	            $dataSet['score'] = $this->form_validation->set_value('score');
	            $dataSet['image'] = $this->form_validation->set_value('image');
	            $dataSet['type'] = $this->form_validation->set_value('type');
	            $dataSet['num'] = $this->form_validation->set_value('num');
	            $dataSet['stock'] = $this->form_validation->set_value('stock');
	            $dataSet['name'] = $this->form_validation->set_value('name');
	            $dataSet['add_time'] = time();
	            $add_yx = $this->checkin_ex_model->add($dataSet);
	            if($add_yx){
	                $this->show_message(true, '添加成功', '/c/checkin/duihuan/'.$checkin_id);
	            }else{
	                $this->show_message(false, '添加失败', '');
	            }
			}else{
				$errors = validation_errors();
                if ($errors) {
                    return $this->show_message(FALSE, $errors, '');
                }
			}
        }else{
            $checkin_info = $this->get_checkinfo($checkin_id);
            $this->data['checkin_info']=$checkin_info;

	    	$this->load->view($this->dcm,$this->data);
        }
    }
    public function dh_edit($id=''){
    	$this->load->model('checkin_ex_model');
    	$post = $this->input->post();
    	if(!$id){
    		return $this->show_message(false, '无效请求', '',1);
    	}
       	$res = $this->checkin_ex_model->where(array('id'=>$id))->find();
    	if($res['site_id']!=$this->site_id){
    		return $this->show_message(false, '无权限', '',1);
    	}
    	$exinfo = $this->get_exinfo($id);
    	if($post){
    		$this->form_validation->set_rules('score', '签到积分', 'trim|required|numeric');
	    	$this->form_validation->set_rules('image', '示例图片', 'trim|required|callback__check_image');
	    	$this->form_validation->set_rules('type', '兑换项目', 'trim|required');
	    	$this->form_validation->set_rules('num', '数值', 'trim|required|numeric');
	    	$this->form_validation->set_rules('stock', '库存', 'trim|required|numeric');
	    	$this->form_validation->set_rules('name', '项目名称', 'trim|required');
			if($this->form_validation->run()){
	            $dataSet['score'] = $this->form_validation->set_value('score');
	            $dataSet['image'] = $this->form_validation->set_value('image');
	            $dataSet['type'] = $this->form_validation->set_value('type');
	            $dataSet['num'] = $this->form_validation->set_value('num');
	            $dataSet['stock'] = $this->form_validation->set_value('stock');
	            $dataSet['name'] = $this->form_validation->set_value('name');
	            $add_yx = $this->checkin_ex_model->where(array('id'=>$id))->edit($dataSet);
	            if($add_yx){
	                $this->show_message(true, '修改成功', '/c/checkin/dh_edit/'.$id);
	            }else{
	                $this->show_message(false, '修改失败', '');
	            }
			}else{
				$errors = validation_errors();
                if ($errors) {
                    return $this->show_message(FALSE, $errors, '');
                }
			}
    	}else{
	    	$this->data['exinfo']=$exinfo;
	    	$this->data['list']=$res;
	    	$this->load->view($this->dcm,$this->data);
    	}
    }

     /**
     * @name 兑换删除
     * @param string $id
     * @return array
     */
    public function dh_delete($id=''){
    	$this->load->model('checkin_ex_model');
        if(!$id){
            $this->show_message(false, '非法参数', 1);return false;
        }
        $res = $this->checkin_ex_model->where(array('id'=>$id))->find();
        if(!$res){
        	return $this->show_message(false, '不存在', '',1);
        }
    	if($res['site_id']!=$this->site_id){
    		return $this->show_message(false, '无权限', '',1);
    	}        
        $request = $this->checkin_ex_model->where(array('id'=>$id))->delete();
        if($request){
        	 $this->show_message(true, '删除成功', '');return FALSE;
        }
       
    }
    
     /**
     * @name 签到详情
     * @param string $id
     * @return array
     */
    public function statis($id=''){
        if( isset($_GET['export']) ){
            $this->statis_export($id);
        }
    	$where['id'] = $id;
        $where['site_id'] = $this->site_id;
        $this->load->model('checkin_info_model');
        $this->load->model('checkin_record_model');
        $this->load->model('checkin_ex_record_model');
    	if(!$id){
    		return $this->show_message(false, '无效请求', '',1);
    	}
    	$search = array();
        $search['keyword'] = $keyword = $this->input->get('keyword');
    	if($keyword){
    		$this->load->model('checkin_yx_record_model');
    		$where_seach['code'] = $keyword;
    		$where_seach['site_id'] = $this->site_id;
    		$where_seach['checkin_id'] = $id;
    		//$recordInfo = $this->checkin_yx_record_model->where($where_seach)->find();
    		$recordInfo = $this->checkin_ex_record_model->where($where_seach)->find();
    		if($recordInfo){
	    		$uid = $recordInfo['uid'];
	    		$checkin_id = $recordInfo['checkin_id'];
	    		$url = "/c/checkin/exinfo/".$uid."/".$checkin_id."?keyword=".$keyword;
	    		header("Location:".$url);
    		}else{
    			$this->show_message(false, 'SN码不存在或还未兑换!', 1);return false;
    		}
    	}
    	$checkinfo = $this->get_checkinfo($id);
    	$wheres['checkin_id'] = $id;
    	$wheres['site_id'] = $this->site_id;
    	$total_rows = $this->checkin_info_model->where($wheres)->count();
        $search_url = site_url($this->uri->uri_string().'?').http_build_query($search);
        $pager = $this->_pager($total_rows, array('per_page'=>10,'base_url'=>$search_url));
    	$result = $this->checkin_info_model->where($wheres)->limit($pager['limit']['value'], $pager['limit']['offset'])->order_by('id asc')->find_all();
        foreach($result as &$mscat)
        {
        	$where_s['uid'] = $mscat['uid'];
        	$where_s['site_id'] = $this->site_id;
        	$where_s['checkin_id'] = $id;
        	$res1 = $this->checkin_record_model->select('min(add_time) as add_time')->where($where_s)->find();
        	$res2 = $this->checkin_record_model->select('max(add_time) as add_time')->where($where_s)->find();
            $mscat['min']= $res1['add_time'];
            $mscat['max']= $res2['add_time'];
            $mscat['openid']= $this->getSubStr($mscat['openid']);
        }
        $jifen = $this->get_jifen($id);
        $jiangpin = $this->get_jiangpin($id);
        $choujiang = $this->get_choujiang($id);
        //$renshu = $this->get_renshu($id);
        $this->data['jifen'] = $jifen;
        $this->data['jiangpin'] = $jiangpin;
        $this->data['choujiang'] = $choujiang;
        $this->data['renshu'] = $total_rows;
        $this->data['checkinfo'] = $checkinfo;
    	$this->data['list'] = $result;
    	$this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        
        $this->data['search'] = $search;
        
        $this->load->view($this->dcm,$this->data);     	
    }

    /**
     * @name 签到详情导出
     * @param string $id
     * @return array
     */
    public function statis_export($id='')
    {
        $where['id'] = $id;
        $where['site_id'] = $this->site_id;
        $this->load->model('checkin_info_model');
        $this->load->model('checkin_record_model');
        $this->load->model('checkin_ex_record_model');
        if(!$id){
            return $this->show_message(false, '无效请求', '',1);
        }
        $search = array();
        $search['keyword'] = $keyword = $this->input->get('keyword');
        if($keyword){
            $this->load->model('checkin_yx_record_model');
            $where_seach['code'] = $keyword;
            $where_seach['site_id'] = $this->site_id;
            $where_seach['checkin_id'] = $id;
            //$recordInfo = $this->checkin_yx_record_model->where($where_seach)->find();
            $recordInfo = $this->checkin_ex_record_model->where($where_seach)->find();
            if($recordInfo){
                $uid = $recordInfo['uid'];
                $checkin_id = $recordInfo['checkin_id'];
                $url = "/c/checkin/exinfo/".$uid."/".$checkin_id."?keyword=".$keyword;
                header("Location:".$url);
            }else{
                $this->show_message(false, 'SN码不存在或还未兑换!', 1);return false;
            }
        }
        $checkinfo = $this->get_checkinfo($id);
        $wheres['checkin_id'] = $id;
        $wheres['site_id'] = $this->site_id;

        $result = $this->checkin_info_model->where($wheres)->order_by('id asc')->find_all();
        if( $result ){
            foreach($result as &$mscat){
                $where_s['uid'] = $mscat['uid'];
                $where_s['site_id'] = $this->site_id;
                $where_s['checkin_id'] = $id;
                $res1 = $this->checkin_record_model->select('min(add_time) as add_time')->where($where_s)->find();
                $res2 = $this->checkin_record_model->select('max(add_time) as add_time')->where($where_s)->find();
                $mscat['min']= $res1['add_time'] ? date('Y-m-d',$res1['add_time']) : '';
                $mscat['max']= $res2['add_time'] ? date('Y-m-d',$res2['add_time']) : '';
                $mscat['openid']= $this->getSubStr($mscat['openid']);
            }


            $fields = array(
                '#'=>'#',
                'openid' => '用户openid',
                'total_num' => '签到天数',
                'last_score' => '签到余额',
                'ex_num' => '兑奖次数',
                'min' => '首次签到',
                'max' => '最近签到'
            );
            $this->excel_export('签到详情', '签到详情', $fields, $result);
        }
    }

    /**
     * 兑换人员列表
     * @param string $id
     */
    public function ex_list($id='')
    {
        if(!$id){
            return $this->show_message(false, '无效请求', '',1);
        }
        if( isset($_GET['export']) ){
            $this->ex_list_export($id);
        }

        $search = array();
        $search['keyword'] = $keyword = $this->input->get('keyword');
        if($keyword){
            $where['code'] = $keyword;
        }
        $checkinfo = $this->get_checkinfo($id);
        $where['site_id'] = $this->site_id;
        $where['checkin_id'] = $id;
        $this->load->model('checkin_info_model');
        $this->load->model('checkin_ex_record_model');
        $total_rows = $this->checkin_ex_record_model->where($where)->count();
        $search_url = site_url($this->uri->uri_string().'?').http_build_query($search);
        $pager = $this->_pager($total_rows, array('per_page'=>10,'base_url'=>$search_url));
        $result = $this->checkin_ex_record_model->where($where)->limit($pager['limit']['value'], $pager['limit']['offset'])->order_by('id desc')->find_all();
        foreach($result as &$mscat){
            $where_s['uid'] = $mscat['uid'];
            $res = $this->checkin_info_model->select('openid')->where($where_s)->find();
            $mscat['openid']= $this->getSubStr($res['openid']);
        }

        $jifen = $this->get_jifen($id);
        $jiangpin = $this->get_jiangpin($id);
        $choujiang = $this->get_choujiang($id);
        $renshu = $this->get_renshu($id);
        $this->data['jifen'] = $jifen;
        $this->data['jiangpin'] = $jiangpin;
        $this->data['choujiang'] = $choujiang;
        $this->data['renshu'] = $renshu;
        $this->data['checkinfo'] = $checkinfo;
        $this->data['list'] = $result;
        $this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];

        $this->data['search'] = $search;

        $this->load->view($this->dcm,$this->data);
    }


    public function ex_list_export($id='')
    {
        $search = array();
        $search['keyword'] = $keyword = $this->input->get('keyword');
        if($keyword){
            $where['code'] = $keyword;
        }
        $checkinfo = $this->get_checkinfo($id);
        $where['site_id'] = $this->site_id;
        $where['checkin_id'] = $id;
        $this->load->model('checkin_info_model');
        $this->load->model('checkin_ex_record_model');
        $total_rows = $this->checkin_ex_record_model->where($where)->count();
        $search_url = site_url($this->uri->uri_string().'?').http_build_query($search);
        $result = $this->checkin_ex_record_model->where($where)->order_by('id desc')->find_all();
        if( $result ){
            foreach($result as &$mscat){
                $where_s['uid'] = $mscat['uid'];
                $res = $this->checkin_info_model->select('openid')->where($where_s)->find();
                $mscat['openid']= $this->getSubStr($res['openid']);
                if($mscat['status']){
                    $mscat['status'] = "已领取";
                }else{
                    $mscat['status'] = "未领取";
                }
                $mscat['ex_time'] = $mscat['ex_time'] ? date('Y-m-d',$mscat['ex_time']) : '';
            }
            $fields = array(
                '#'=>'#',
                'openid' => '用户openid',
                'ex_name' => '兑换项目',
                'code' => '兑换SN码',
                'status' => '状态',
                'ex_time' => '兑换时间'
            );
            $this->excel_export('兑换记录', '兑换记录', $fields, $result);
        }
    }

    /**
     * 兑换奖品 兑换掉
     * @param string $id
     */
    public function ex_open($id=''){
        $this->load->model('checkin_ex_record_model');
        if(!$id){
            $this->show_message(false, '非法参数', 1);return false;
        }
        $res = $this->checkin_ex_record_model->where(array('id'=>$id))->find();
        if(!$res){
            return $this->show_message(false, '不存在', '',1);
        }
        if($res['site_id']!=$this->site_id){
            return $this->show_message(false, '无权限', '',1);
        }
        $dataSet['status']=1;
        $dataSet['ex_time']=time();
        $request = $this->checkin_ex_record_model->where(array('id'=>$id))->edit($dataSet);
        if($request){
            $this->show_message(true,"设置成功", '/c/checkin/ex_list/'.$res['checkin_id']);return FALSE;
        }
    }


    /**
     * 兑奖详情
     * @param string $uid
     * @param string $id
     */
    public function exinfo($uid='',$id=''){
        if( isset($_GET['export']) ){
            return $this->exinfo_export($uid,$id);
        }
        if(!$id){
    		return $this->show_message(false, '无效请求', '',1);
    	}
        if(!$uid){
    		return $this->show_message(false, '无效请求', '',1);
    	}
    	$search = array();
    	$search['keyword'] = $keyword = $this->input->get('keyword');
    	if($keyword){
    		$where['code'] = $keyword;
    	}
    	$checkinfo = $this->get_checkinfo($id);
    	$where['site_id'] = $this->site_id;
    	$where['checkin_id'] = $id;
    	$where['uid'] = $uid;
    	$this->load->model('checkin_info_model');
    	$this->load->model('checkin_ex_record_model');
    	$total_rows = $this->checkin_ex_record_model->where($where)->count();
        $search_url = site_url($this->uri->uri_string().'?').http_build_query($search);
        $pager = $this->_pager($total_rows, array('per_page'=>10,'base_url'=>$search_url));
    	$result = $this->checkin_ex_record_model->where($where)->limit($pager['limit']['value'], $pager['limit']['offset'])->order_by('id asc')->find_all();
       	foreach($result as &$mscat)
        {
        	$where_s['uid'] = $mscat['uid'];
        	$res = $this->checkin_info_model->select('openid')->where($where_s)->find();
            $mscat['openid']= $this->getSubStr($res['openid']);
        }
        $jifen = $this->get_jifen($id);
        $jiangpin = $this->get_jiangpin($id);
        $choujiang = $this->get_choujiang($id);
        $renshu = $this->get_renshu($id);
        $this->data['jifen'] = $jifen;
        $this->data['jiangpin'] = $jiangpin;
        $this->data['choujiang'] = $choujiang;
        $this->data['renshu'] = $renshu;
        $this->data['checkinfo'] = $checkinfo;
        $this->data['list'] = $result;
    	$this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
    	
        $this->data['search'] = $search;
        
    	$this->load->view($this->dcm,$this->data);
    }

    //签到兑换详情
    public function exinfo_export($uid='',$id='')
    {
        if(!$id){
            return $this->show_message(false, '无效请求', '',1);
        }
        if(!$uid){
            return $this->show_message(false, '无效请求', '',1);
        }
        $search = array();
        $search['keyword'] = $keyword = $this->input->get('keyword');
        if($keyword){
            $where['code'] = $keyword;
        }
        $checkinfo = $this->get_checkinfo($id);
        $where['site_id'] = $this->site_id;
        $where['checkin_id'] = $id;
        $where['uid'] = $uid;
        $this->load->model('checkin_info_model');
        $this->load->model('checkin_ex_record_model');
        $result = $this->checkin_ex_record_model->where($where)->order_by('id asc')->find_all();
        if( $result ){
            foreach($result as &$mscat)
            {
                $where_s['uid'] = $mscat['uid'];
                $res = $this->checkin_info_model->select('openid')->where($where_s)->find();
                $mscat['openid']= $this->getSubStr($res['openid']);
                if($mscat['status']){
                    $mscat['status'] = "已领取";
                }else{
                    $mscat['status'] = "未领取";
                }
                $mscat['ex_time'] = $mscat['ex_time'] ? date('Y-m-d',$mscat['ex_time']) : '';
            }
            $fields = array(
                '#'=>'#',
                'openid' => '用户openid',
                'ex_name' => '兑换项目',
                'code' => '兑换SN码',
                'status' => '状态',
                'ex_time' => '兑换时间'
            );
            $this->excel_export('兑换记录', '兑换记录', $fields, $result);
        }
    }

    /**
     * 中奖记录
     * @param string $id
     */
    public function record($id=''){
        
        if(!$id){
    		return $this->show_message(false, '无效请求', '',1);
    	}
        if( isset($_GET['export']) ){
            $this->record_export($id);
        }
        
    	$where['id'] = $id;
        $where['site_id'] = $this->site_id;
        $this->load->model('checkin_yx_record_model');
        $this->load->model('checkin_info_model');
        $search = array();
        $search['s_time'] = $s_time = $this->input->get('s_time');
        $search['d_time'] = $d_time = $this->input->get('d_time');
        $search['type'] = $type = $this->input->get('type');
        $search['keyword'] = $keyword = $this->input->get('keyword');
        if($s_time){
        	$wheres['add_time >='] = strtotime($s_time);
        }
        if($d_time){
        	$wheres['add_time <='] = strtotime($d_time);
        }
        if($type){
        	$wheres['yx_type'] = $type;
        }
        if($keyword){
        		$wheres['username'] = $keyword;
        		$where_m['mobile'] = $keyword;
        		$wheres_c['code'] = $keyword;
        }
    	
    	$checkinfo = $this->get_checkinfo($id);
    	$wheres['checkin_id'] = $id;
    	$wheres['site_id'] = $this->site_id;
    	
    	
    	$total_rows = $this->checkin_yx_record_model->where($wheres)->count();
    	$search_url = site_url($this->uri->uri_string().'?').http_build_query($search);
        $pager = $this->_pager($total_rows, array('per_page'=>10,'base_url'=>$search_url));
    	if($keyword){
        	$result = $this->checkin_yx_record_model->where($wheres)->or_where($where_m)->or_where($wheres_c)->limit($pager['limit']['value'], $pager['limit']['offset'])->order_by('id asc')->find_all();
    	}else{
        	$result = $this->checkin_yx_record_model->where($wheres)->limit($pager['limit']['value'], $pager['limit']['offset'])->order_by('id asc')->find_all();
    	}
    	if($result){
	        foreach($result as &$mscat)
	        {
	        	$where_s['uid'] = $mscat['uid'];
	        	$res = $this->checkin_info_model->where($where_s)->find();
	            $mscat['openid']= $this->getSubStr($res['openid']);
	        }
    	}
    	
        $jifen = $this->get_jifen($id);
        $jiangpin = $this->get_jiangpin($id);
        $choujiang = $this->get_choujiang($id);
        $renshu = $this->get_renshu($id);
        $this->data['jifen'] = $jifen;
        $this->data['jiangpin'] = $jiangpin;
        $this->data['choujiang'] = $choujiang;
        $this->data['renshu'] = $renshu;
        $this->data['checkinfo'] = $checkinfo;
    	$this->data['list'] = $result;
    	$this->data['page'] = $pager['links'];
        $this->data['offset'] = $pager['limit']['offset'];
        
        $this->data['search'] = $search;
        
        $this->load->view($this->dcm,$this->data);     	
    }
    
    //中奖记录 导出
    private function record_export($id='')
    {
    	$checkinfo = $this->get_checkinfo($id);
        $this->load->model('checkin_yx_record_model');
        $this->load->model('checkin_info_model');
        
        $s_time = $this->input->get('s_time');
        $d_time = $this->input->get('d_time');
        $type = $this->input->get('type');
        $keyword = $this->input->get('keyword');
        if($s_time){
        	$wheres['add_time >='] = strtotime($s_time);
        }
        if($d_time){
        	$wheres['add_time <='] = strtotime($d_time);
        }
        if($type){
        	$wheres['yx_type'] = $type;
        }
        if($keyword){
        		$wheres['username'] = $keyword;
        		$where_m['mobile'] = $keyword;
        		$wheres_c['code'] = $keyword;
        }
    	$wheres['checkin_id'] = $id;
    	$wheres['site_id'] = $this->site_id;
    	
        if($keyword){
        	$result = $this->checkin_yx_record_model->where($wheres)->or_where($where_m)->or_where($wheres_c)->order_by('id asc')->find_all();
    	}else{
        	$result = $this->checkin_yx_record_model->where($wheres)->order_by('id asc')->find_all();
    	}
    	if($result){
    	    $option = array('1'=>'会员积分','2'=>'实物','3'=>'抽奖次数');
	        foreach($result as &$mscat)
	        {
	        	$where_s['uid'] = $mscat['uid'];
	        	$res = $this->checkin_info_model->where($where_s)->find();
	            $mscat['openid']= $this->getSubStr($res['openid']);
	            $mscat['type'] = $option[$mscat['yx_type']];
	            $mscat['add_time'] = date('Y-m-d H:i:s',$mscat['add_time']);
	            if( $mscat['status'] ){
	                $mscat['status'] = '已领取';
	                $mscat['ex_time'] = $mscat['ex_time'] ? date('Y-m-d H:i:s',$mscat['ex_time']) : '';
	            }else{
	                $mscat['status'] = '未领取';
	                $mscat['ex_time'] = '';
	            }
	        }
	        
	        $fields = array(
                '#'=>'#',
	            'openid' => '用户openid',
	            'username' => '姓名',
	            'mobile' => '电话',
	            'address' => '地址',
	            'type' => '抽中奖项',
	            'yx_name' => '奖品名称',
	            'yx_num' => '数值',
	            'code' => 'SN码',
	            'add_time' => '抽中时间',
	            'status' => '状态',
	            'ex_time' => '兑换时间',
            );
            $this->excel_export($checkinfo['title'].'-中奖记录', $checkinfo['title'].'-中奖记录', $fields, $result);
    	}
    }

    /**
     * @param string $id
     * @return bool|void
     */
    public function open($id=''){
    	$this->load->model('checkin_ex_record_model');
        if(!$id){
            $this->show_message(false, '非法参数', 1);return false;
        }
        $res = $this->checkin_ex_record_model->where(array('id'=>$id))->find();
        if(!$res){
        	return $this->show_message(false, '不存在', '',1);
        }
    	if($res['site_id']!=$this->site_id){
    		return $this->show_message(false, '无权限', '',1);
    	}        
    	$dataSet['status']=1;
    	$dataSet['ex_time']=time();
        $request = $this->checkin_ex_record_model->where(array('id'=>$id))->edit($dataSet);
        if($request){//TODO
        	 $this->show_message(true,"设置成功", '/c/checkin/exinfo/'.$res['uid'].'/'.$res['checkin_id']);return FALSE;
        }
       
    }

    /**
     * @param string $id
     * @return bool|void
     */
    public function opens($id=''){
    	$this->load->model('checkin_yx_record_model');
        if(!$id){
            $this->show_message(false, '非法参数', 1);return false;
        }
        $res = $this->checkin_yx_record_model->where(array('id'=>$id))->find();
        if(!$res){
        	return $this->show_message(false, '不存在', '',1);
        }
    	if($res['site_id']!=$this->site_id){
    		return $this->show_message(false, '无权限', '',1);
    	}        
    	$dataSet['status']=1;
    	$dataSet['ex_time']=time();
        $request = $this->checkin_yx_record_model->where(array('id'=>$id))->edit($dataSet);
        if($request){
        	 $this->show_message(true,"设置成功", '');return FALSE;
        }
       
    }

    /**
     * 查询关键字是否存在
     * @param $keyword
     * @param string $id
     * @return mixed
     */
    private function getKeyword($keyword,$id=''){
    	$this->load->model('checkin_model');
        if($id){
    		$where['id !='] = $id;
    		$where['site_id'] = $this->site_id;
            $where['reply_keyword'] = $keyword;
    		$request = $this->checkin_model->where($where)->count();
    	}else{
    	    $where['site_id'] = $this->site_id;
            $where['reply_keyword'] = $keyword;
            $request = $this->checkin_model->where($where)->count();
    	}
    	return $request;
    }

    /**
     * 查询总的中奖率
     * @param $checkin_id
     * @param string $id
     * @return mixed
     */
    private function getChance($checkin_id,$id=''){
    	$this->load->model('checkin_yx_model');
    	if($id){
    		$where['id !='] = $id;
    	}
    	$where['checkin_id'] = $checkin_id;
    	$requests = $this->checkin_yx_model
    	->select('sum(yx_chance) as yx_chance')
    	->where($where)
    	->find_all();
    	$request = $requests[0]['yx_chance'];
    	return $request;
    }
    
    /**
     * @name 多出的字符用*代替
     * @param string $s
     * @return array
     */
	private function getSubStr($s){
	    $substr=strlen($s)>20?substr($s,0,20).'***':$s;
	    return $substr;
	}
	  
    /**
     * @name 根据签到ID获取签到详细信息
     * @param string $id
     * @return array
     */
    private function get_checkinfo($id){
    	$where['id']=$id;
    	$request = $this->checkin_model->where($where)->find();
    	return $request;
    }
    
    /**
     * @name 根据兑换ID获取签到详细信息
     * @param string $id
     * @return array
     */
    private function get_exinfo($id){
    	$this->load->model('checkin_ex_model');
    	$where['wb_checkin_ex.id']=$id;
    	$request = $this->checkin_ex_model
    	->join('wb_checkin','wb_checkin_ex.checkin_id=wb_checkin.id','left')
    	->where($where)
    	->find();
    	return $request;
    }
    
    /**
     * @name 根据签到ID获取兑换积分的人数
     * @param string $id
     * @return array
     */
    private function get_jifen($id){
    	$this->load->model('checkin_ex_record_model');
    	$where['checkin_id']=$id;
    	$where['site_id']=$this->site_id;
    	$where['ex_type']=1;
    	$requests = $this->checkin_ex_record_model
    	->select('uid')
    	->where($where)
    	->group_by('uid')
    	->find_all();
    	$request = count($requests);
    	$request =$request?$request:0;
    	return $request;
    }
    
    /**
     * @name 根据签到ID获取兑奖品的次数
     * @param string $id
     * @return array
     */
    private function get_jiangpin($id){
    	$this->load->model('checkin_ex_record_model');
    	$where['checkin_id']=$id;
    	$where['site_id']=$this->site_id;
    	$where['ex_type']=2;
    	$requests = $this->checkin_ex_record_model
    	->select('uid')
    	->where($where)
    	->find_all();
    	$request = count($requests);
    	$request =$request?$request:0;
    	return $request;
    }
    
    /**
     * @name 根据签到ID获取兑奖品的次数
     * @param string $id
     * @return array
     */
    private function get_choujiang($id){
    	$this->load->model('checkin_ex_record_model');
    	$where['checkin_id']=$id;
    	$where['site_id']=$this->site_id;
    	$where['ex_type']=3;
    	$requests = $this->checkin_ex_record_model
    	->select('uid')
    	->where($where)
    	->find_all();
    	$request = count($requests);
    	$request =$request?$request:0;
    	return $request;
    }
    
    /**
     * @name 根据签到ID获取参与人数
     * @param string $id
     * @return array
     */
    private function get_renshu($id){
    	/*
        $this->load->model('checkin_ex_record_model');
    	$where['checkin_id']=$id;
    	$where['site_id']=$this->site_id;
    	$requests = $this->checkin_ex_record_model
    	->select('uid')
    	->where($where)
    	->group_by('uid')
    	->find_all();
    	$request = count($requests);
    	$request =$request?$request:0;
    	return $request;
        */
        $wheres['checkin_id'] = $id;
        $wheres['site_id'] = $this->site_id;
        $this->load->model('checkin_info_model');
        $total_rows = $this->checkin_info_model->where($wheres)->count();
        $request =$total_rows?$total_rows:0;
        return $request;
    }
    
    //检查图片格式
    public function _check_image($image) {
        if ($image) {
            if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
                $this->form_validation->set_message('_check_image', '图片地址格式错误');
                return FALSE;
            }
        }
        return TRUE;
    }
} 