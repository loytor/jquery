<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Created by PhpStorm.
 * User: andery
 * Date: 13-12-4
 * Time: 上午11:41
 */

class Payment extends C_Controller {

    protected $auto_load_model = TRUE;
    protected $model_name = 'payment';

    public function index()
    {
        //支付白名单
        $white_list = $this->model->get_white_list();
        //过滤
        $payments = $this->model->get_builtin($white_list);
        //已经安装的
        $installed = $this->model->get_installed($this->site_info['id']);
        foreach ($payments as $key => $value) {
            foreach ($installed as $installed_payment) {
                if ($installed_payment['code'] == $key) {
                    $payments[$key]['status']    = $installed_payment['status'];
                    $payments[$key]['installed']  = 1;
                    $payments[$key]['id'] = $installed_payment['id'];
                }
            }
        }
        $this->data['payments'] = $payments;
        $this->load->view($this->dcm, $this->data);
    }

    public function install($code)
    {
        $payment = $this->model->get_builtin_info($code);
        if ($this->input->post()) {
            $config = serialize($this->input->post('config'));
            if ($this->model->in_white_list($payment['code'])) {
                $this->model->add(array(
                    'site_id' => $this->site_info['id'],
                    'code' => $payment['code'],
                    'name' => $payment['name'],
                    'config' => $config,
                    'online' => $payment['online'],
                    'sort' => $this->input->post('sort'),
                    'status' => $this->input->post('status'),
                ));
                $this->show_message(TRUE, '更新成功', '/c/payment');
            } else {
                $this->show_message(FALSE, '更新失败', '/c/payment');
            }
        } else {
            $this->data['payment'] = $payment;
            $this->load->view($this->dcm, $this->data);
        }
    }

    public function config($payment_id)
    {
        $payment_info = $this->model->find($payment_id);
        $payment = $this->model->get_builtin_info($payment_info['code']);
        if ($this->input->post()) {
            $config = serialize($this->input->post('config'));
            if ($this->model->in_white_list($payment['code'])) {
                $this->model->where(array('id' => $payment_id, 'site_id' => $this->site_info['id']))->edit(array(
                    'is_sys' => $this->input->post('is_sys') ? 1 : 0,
                    'config' => $config,
                    'sort' => $this->input->post('sort'),
                    'status' => $this->input->post('status'),
                ));
                $this->show_message(TRUE, '更新成功', '/c/payment');
            } else {
                $this->show_message(FALSE, '更新失败', '/c/payment');
            }
        } else {
            $payment['id']     = $payment_info['id'];
            $payment['status'] = $payment_info['status'];
            $payment['sort']   = $payment_info['sort'];
            $payment['is_sys'] = $payment_info['is_sys'];
            $payment_config = unserialize($payment_info['config']);

            foreach ($payment['config'] as $key=>$val) {
                $payment['config'][$key]['value'] = isset($payment_config[$key]) ? $payment_config[$key] : '';
            }
            $this->data['payment'] = $payment;
            $this->load->view($this->dcm, $this->data);
        }
    }

    public function uninstall($payment_id)
    {
        if ($this->model->where(array('id' => $payment_id, 'site_id' => $this->site_info['id']))->delete()) {
            $this->show_message(TRUE, '删除成功', '/c/payment');
        } else {
            $this->show_message(TRUE, '删除失败', '/c/payment');
        }
    }

    /**
     * 支付记录
     */
    public function log()
    {
        $this->load->model('payment_log_model');
        $list = $this->payment_log_model->where(array('site_id'=>$this->site_info['id']))->find_all();
        $this->data['list'] = $list;
        $this->load->view($this->dcm, $this->data);
    }
}