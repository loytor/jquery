<?php
/**
 * Created by JetBrains PhpStorm.
 * User: llj
 * Date: 13-10-14
 * Time: 下午6:27
 * To change this template use File | Settings | File Templates.
 * @property Model_app_config $model_app_config
 */
class Reserve_form extends MY_Controller
{
	private $types_arr;

	public function __construct()
	{
		parent::__construct();
		$this->load->model('model_app_config');
		$this->load->config('reserve');
		$this->types_arr = $this->config->item('reserve_types');
	}

	/**
	 * @param $type
	 * 基本设置
	 */
	public function index($type)
	{
		$reserve_form_config = $this->config->item('reserve_form');

		$config = $this->model_app_config->get_row(array('user_id'=>User::$user_id, 'type'=>'reserve_form_'.$type));
		$collection = json_decode($config['config'], TRUE);
		$used_fields = array();
		if($collection)
		{
			foreach($collection as &$item)
			{
				if(isset($item['items']))
				{
					$item['items'] = implode(',', $item['items']);
				}

				$used_fields[$item['type']][] = $item['id'];
			}
		}
		$tpl_data['collection'] = $collection ? $collection : array();

		$reserve_form_config = (array)$reserve_form_config;
		foreach($reserve_form_config as $key=>&$rfc)
		{
			if(isset($rfc['fields']))
			{
				$new_fields = array();
				foreach($rfc['fields'] as $fd)
				{
					if(!isset($used_fields[$key]))
					{
						$new_fields[] = $fd;
					}
					else if(!in_array($fd, $used_fields[$key]))
					{
						$new_fields[] = $fd;
					}
				}
				$rfc['fields'] = $new_fields;
			}
		}

//print_r($tpl_data['collection']);
//print_r($reserve_form_config);
		if($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			$collection = isset($_POST['collection']) ? $_POST['collection'] : array();
			foreach($collection as &$value)
			{
				if(!$value['name'])
				{
					$this->show_message(FALSE, '字段名称是必须的', '/reserve_form/'.$type);
				}
				if(isset($value['items']))
				{
					$value['items'] = explode(',', str_replace('，', ',', $value['items']));
				}
				$value['required'] = isset($value['required']) ? $value['required'] : 0;
			}

			if($config)//更新配置
			{
				$where['user_id'] = User::$user_id;
				$where['type'] = 'reserve_form_'.$type;
				$data_set['config'] = json_encode($collection);
				if($this->model_app_config->update($where, $data_set))
				{
					$this->show_message(TRUE, '保存成功', '/reserve_form/'.$type);
				}
				else
				{
					$this->show_message(FALSE, '保存失败', '/reserve_form/'.$type);
				}
			}
			else//添加配置
			{
				$data_set['user_id'] = User::$user_id;
				$data_set['type'] = 'reserve_form_'.$type;
				$data_set['config'] = json_encode($collection);
				if($this->model_app_config->add($data_set))
				{
					$this->show_message(TRUE, '保存成功', '/reserve_form/'.$type);
				}
				else
				{
					$this->show_message(FALSE, '保存失败', '/reserve_form/'.$type);
				}
			}
		}

		$tpl_data['reserve_form_config'] = $reserve_form_config;
		$tpl_data['reserve_form_config_arr'] = json_encode($reserve_form_config);
		$tpl_data['type'] = $type;
		$tpl_data['type_info'] = $this->types_arr[$type];
		$tpl_data['cur_nav'] = 'member_sys';
		$tpl_data['reserve_nav'] = 'form';
		$this->twig->display('reserve/form', $tpl_data);
	}
}