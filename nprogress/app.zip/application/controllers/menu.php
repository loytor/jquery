<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Class Menu
 * @property Model_menu $model_menu
 * @property Model_app_config $model_app_config
 * @property Curl $curl
 */

class Menu extends MY_Controller {

	private $errorCodeArr = array(
		'-1' => '系统繁忙',
		'40013' => '不合法的APPID',
		'40014' => '不合法的access_token',
		'40016' => '不合法的主菜单按钮个数',
		'40017' => '不合法的子菜单按钮个数',
		'40018' => '不合法的按钮名字长度',
		'40025' => '不合法的子菜单按钮名字长度'
	);

	public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('model_menu');
		$this->load->model('model_app_config');
	}

	public function index() {
		$app_config = $this->model_app_config->get_row(array('type'=>'menu', 'user_id'=>User::$user_id));
		$menu_config = json_decode($app_config['config'], TRUE);
		if(!$menu_config){
			$menu_config['appid'] = '';
			$menu_config['appsecret'] = '';
			$menu_config['button'] = array();
		}
        if( !isset($menu_config['appid']) ){
            $menu_config['appid'] = '';
            $menu_config['appsecret'] = '';
        }
		$tpl_data['menu_config'] = $menu_config;
		$used_key = array();

		if($_POST){
			$config = $this->input->post('config');

			$menu = array();
			$button = array();
			if($this->input->post('menu')){

				$menu = $this->input->post('menu');
				//这次循环为了排序
				$rank = array();
				foreach ($menu as $key => &$row) {
					$rank[$key] = (isset($row['rank']) && $row['rank']) ? $row['rank'] : $key;
					if(isset($row['sub_menu'])){
						$srank = array();
						foreach($row['sub_menu'] as $sk=>$sr) {
							$srank[$sk] = ($sr['rank'] == '') ? $sk : $sr['rank'];
						}
						array_multisort($srank, SORT_ASC, $row['sub_menu']);
					}
				}
				array_multisort($rank, SORT_ASC, $menu);

				//这次循环为了弄成可以直接用的格式
				foreach($menu as $mk=>&$mr){
					$button[$mk]['name'] = isset($mr['name']) ? $mr['name'] : '';


					if(isset($mr['key'])){
						$main_menu = $this->model_menu->get_row(array('id'=>$mr['key'], 'user_id'=>User::$user_id));
						if($main_menu){
							$key = $mr['key'];
							$update_set['dt_update'] = date('Y-m-d H:i:s');
							$update_set['keyword'] = $mr['keyword'];
							$this->model_menu->update(array('id'=>$key, 'user_id'=>User::$user_id), $update_set);
						}else{
							//插入一条新记录到menu表
							$add_set['user_id'] = User::$user_id;
							$add_set['dt_add'] = $add_set['dt_update'] = date('Y-m-d H:i:s');
							if(isset($mr['keyword'])){
								$add_set['keyword'] = $mr['keyword'];
							}
							$key = $this->model_menu->add($add_set, TRUE);
						}
					}else{
						//插入一条新记录到menu表
						$add_set['user_id'] = User::$user_id;
						$add_set['dt_add'] = $add_set['dt_update'] = date('Y-m-d H:i:s');
						if(isset($mr['keyword'])){
							$add_set['keyword'] = $mr['keyword'];
						}
						$key = $this->model_menu->add($add_set, TRUE);
					}

					if(isset($mr['sub_menu'])){
						foreach($mr['sub_menu'] as $sk=>&$sr) {
							if(isset($sr['key'])){
								$sub_menu = $this->model_menu->get_row(array('id'=>$sr['key'], 'user_id'=>User::$user_id));
								if($sub_menu)
								{
									$key = $sr['key'];
									$update_set['dt_update'] = date('Y-m-d H:i:s');
									$update_set['keyword'] = $sr['keyword'];
									$this->model_menu->update(array('id'=>$key, 'user_id'=>User::$user_id), $update_set);
								}else{
									//插入一条新记录到menu表
									$add_set['user_id'] = User::$user_id;
									$add_set['dt_add'] = $add_set['dt_update'] = date('Y-m-d H:i:s');
									if(isset($sr['keyword'])){
										$add_set['keyword'] = $sr['keyword'];
									}
									$key = $this->model_menu->add($add_set, TRUE);
								}
							}else{
								//插入一条新记录到menu表
								$add_set['user_id'] = User::$user_id;
								$add_set['dt_add'] = $add_set['dt_update'] = date('Y-m-d H:i:s');
								if(isset($sr['keyword'])){
									$add_set['keyword'] = $sr['keyword'];
								}
								$key = $this->model_menu->add($add_set, TRUE);
							}
							if($this->is_url($sr['keyword'])) //判断是否是外链
							{
								$button[$mk]['sub_button'][$sk]['type'] = 'view';
								$button[$mk]['sub_button'][$sk]['name'] =  $sr['name'];
								$button[$mk]['sub_button'][$sk]['url'] = $sr['keyword'];
								$sr['is_url'] = 1;
							}
							else
							{
								$button[$mk]['sub_button'][$sk]['type'] = ($this->is_url($sr['keyword'])) ? 'view' : 'click';
								$button[$mk]['sub_button'][$sk]['name'] =  $sr['name'];
								$button[$mk]['sub_button'][$sk]['key'] = $key;
								$sr['key'] = $key;
								$used_key[] = $key;
							}
						}
					}else{
						if(isset($mr['keyword']) && $this->is_url($mr['keyword']))
						{
							$button[$mk]['type'] = 'view';
							$button[$mk]['url'] = $mr['keyword'];
							$mr['is_url'] = 1;
						}
						else
						{
							$button[$mk]['type'] = (isset($mr['keyword']) && $this->is_url($mr['keyword'])) ? 'view' : 'click';
							$button[$mk]['key'] = $key;
							$mr['key'] = $key;
							$used_key[] = $key;
						}
					}
				}
			}

			//根据used_key删除未用到的menu
			if(count($used_key) > 0){
				$where_set['notin:id'] = $used_key;
				$where_set['user_id'] = User::$user_id;
				$this->model_menu->delete($where_set);
			}

			$config['menu'] = $menu;
			$config['button'] = $button;

			//微信公众平台创建菜单开始

            //利用curl发送get/post请求 微信公众平台接口
            $this->load->library('curl');
            $config['appid'] = trim($config['appid']);
            $config['appsecret'] = trim($config['appsecret']);

            $tokenUrl = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$config['appid'].'&secret='.$config['appsecret'];
            $tmpTokenInfo = $this->curl->get($tokenUrl);
            $tmpTokenInfo = json_decode($tmpTokenInfo,true);

            if(isset($tmpTokenInfo['errcode']))
            {
                if(isset($this->errorCodeArr[$tmpTokenInfo['errcode']])){
                    $this->show_message(false, $this->errorCodeArr[$tmpTokenInfo['errcode']], '/menu', 1);
                }else{
                    $this->show_message(false, 'token获取失败, 腾讯微信错误代码:'.$tmpTokenInfo['errcode'].'错误详情：'.$tmpTokenInfo['errmsg'], '/menu', 1);
                }
            }
            $accessToken = $tmpTokenInfo['access_token'];
			if($button)
			{
				$postData['button'] = $config['button'];
                //查询菜单
                //$getMenuUrl = 'https://api.weixin.qq.com/cgi-bin/menu/get?access_token='.$accessToken;
                //$tmpMenuInfo = $this->curl->get($getMenuUrl);

                if($postData['button'])
                {
                    $postData = urldecode(json_encode($this->var_url_encode($postData)));
                    if(User::$user_id == '537ef7e16c523041')
                    {
                        //echo $accessToken;print_r($postData);exit;
                    }
                    //file_put_contents('menu.txt', print_r($postData, TRUE));
                    /*
                    if(User::$user_id == '51e75f20713e0028')
                    {
                        print_r($postData);exit;
                    }
                    */
                    $tmpCreateInfo = $this->curl->post("https://api.weixin.qq.com/cgi-bin/menu/create?access_token=".$accessToken,$postData);
                    $tmpCreateInfo = json_decode($tmpCreateInfo,true);
                    if($tmpCreateInfo['errcode'] !=0 )
                    {
                        if(isset($this->errorCodeArr[$tmpCreateInfo['errcode']])){
                            $this->show_message(false, $this->errorCodeArr[$tmpCreateInfo['errcode']], '/menu', 1);
                        }else{
                            $this->show_message(false, '菜单创建失败，腾讯微信错误代码:'.$tmpCreateInfo['errcode'].'错误详情:'.$tmpCreateInfo['errmsg'], '/menu', 1);
                        }
                    }
                }
			}
            else
            {
                //删除菜单
                $this->curl->get('https://api.weixin.qq.com/cgi-bin/menu/delete?access_token='.$accessToken);
            }

			if($app_config){
				$this->model_app_config->update(array('type'=>'menu', 'user_id'=>User::$user_id), array('config'=>json_encode($config, JSON_UNESCAPED_UNICODE)));
			}else{
				$data_set['config'] = json_encode($config, JSON_UNESCAPED_UNICODE);
				$data_set['type'] = 'menu';
				$data_set['user_id'] = User::$user_id;
				$this->model_app_config->add($data_set);
			}

			/*
			//用md5加密原先的菜单数据用于和修改过后的数据对比
			$menuInfoByMd5 = md5(serialize($tpl_data['menu_config']['button']));

			//用md5加密需要提交的数据和原来的数据对比
			$newMenuMd5 = md5(serialize($postData['button']));

			//判断AppId和AppSecret是否修改
			$jsonAppConfig = json_decode($app_config['config'],true);
			$oldAppInfo['appid'] = $jsonAppConfig['appid'];
			$oldAppInfo['appsecret'] = $jsonAppConfig['appsecret'];
			$oldAppInfo = md5(serialize($oldAppInfo));

			$newAppInfo['appid'] = $config['appid'];
			$newAppInfo['appsecret'] = $config['appsecret'];
			$newAppInfo = md5(serialize($newAppInfo));

			if($menuInfoByMd5 != $newMenuMd5 || $newAppInfo != $oldAppInfo)
			{
				$tokenUrl = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$config['appid'].'&secret='.$config['appsecret'];
				$tmpTokenInfo = $this->curl->get($tokenUrl);
				$tmpTokenInfo = json_decode($tmpTokenInfo,true);

				if(isset($tmpTokenInfo['errcode']))
				{
					$this->show_message(false, 'token获取失败,错误代码:'.$tmpTokenInfo['errcode'].'错误详情：'.$tmpTokenInfo['errmsg'], '/menu');
				}
				else
				{
					$accessToken = $tmpTokenInfo['access_token'];
				}

				if(isset($accessToken))
				{
					//删除菜单
					$deleteUrl = "https://api.weixin.qq.com/cgi-bin/menu/delete?access_token=".$accessToken;

					$tmpDelInfo = $this->curl->get($deleteUrl);
					$tmpDelInfo = json_decode($tmpDelInfo,true);
					if($tmpDelInfo['errcode'] != 0)
					{
						$this->show_message(false, '菜单删除失败，错误代码:'.$tmpDelInfo['errcode'].'错误详情:'.$tmpDelInfo['errmsg'], '/menu');
					}

					//如果是修改菜单 则重新创建菜单
					if($postData['button'])
					{
						$postData = urldecode(json_encode($this->var_url_encode($postData)));

						$tmpCreateInfo = $this->curl->post("https://api.weixin.qq.com/cgi-bin/menu/create?access_token=".$accessToken,$postData);
						$tmpCreateInfo = json_decode($tmpCreateInfo,true);
						if($tmpCreateInfo['errcode'] !=0 )
						{
							$this->show_message(false, '菜单创建失败，错误代码:'.$tmpCreateInfo['errcode'].'错误详情:'.$tmpCreateInfo['errmsg'], '/menu');
						}
					}

				}
			}
			*/
			$this->show_message(TRUE, '保存成功', '/menu');
		}
		$tpl_data['cur_nav'] = 'menu';
		$this->twig->display('menu/index', $tpl_data);
	}


	private function var_url_encode($var) {
		if (is_array ( $var )) {
			foreach ( $var as $k => $v ) {
				if (is_scalar ( $v ))
				{
					$var [$k] = urlencode ( $v );
				}
				else {
					$var [$k] = $this->var_url_encode ( $v );
				}
			}
		}
		else {
			$var = urlencode ( $var );
		}
		return $var;
	}

	/**
	 * @param $str
	 * 判断是否是外链
	 */
	private function is_url($str)
	{
		return preg_match("/^(http|https):\/\/[A-Za-z0-9\-\_]+\.[A-Za-z0-9]+[\/=\?%\-&_~`@[\]\’:+!]*([^<>\"])*$/", $str);
	}
}