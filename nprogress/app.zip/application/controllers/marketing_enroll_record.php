<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Marketing_enroll_record extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('model_marketing');
        $this->load->model('model_marketing_enroll_record');
	}

	public function index($marketing_id='',$current_page=1){

        //echo strlen('Ｆ❤ r E v eｒ');
	    $logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
        $tpl_data['cur_nav'] = 'marketing';
        
        $where_set = array('marketing_id' => $marketing_id);
		$this->load->library('pagination');
        
        //总数量 
        $tpl_data['count'] = $this->model_marketing_enroll_record->total_rows($where_set);
		$pagination_config = array(
				'base_url'		=> '/marketing_enroll_record/index/'.$marketing_id,
				'total_rows'	=> $tpl_data['count'],
				'per_page'		=> 15,
				'uri_segment'	=> 4,
		);
		$this->pagination->initialize($pagination_config);
		$tpl_data['pagination'] = $this->pagination->create_links();
        
        $enroll_result_arr = $this->model_marketing_enroll_record->get_all($where_set, $pagination_config['per_page'], intval($this->uri->segment($pagination_config['uri_segment'], 1)));
		foreach ($enroll_result_arr as &$_record) {
            $_record['content'] = @unserialize($_record['content']);
		}
        $tpl_data['marketing_id'] = $marketing_id;
        $tpl_data['enroll_result_arr'] = $enroll_result_arr;
		$this->twig->display('marketing_enroll_record/index', $tpl_data);
	}
    
    public function export() {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
        $this->load->model('model_marketing_enroll');
        
		//查询报名活动信息
        $marketing_id = $this->input->get('mid');
        $marketing_info = $this->model_marketing_enroll->get_row(array('marketing_id'=>$marketing_id));
        $marketing_setting_info = unserialize($marketing_info['enroll_setting']);

        $limit_to = $this->input->get('limit_to');
        $limit_from = $this->input->get('limit_from');

        $enroll_record_arr = $this->model_marketing_enroll_record->get_limit(array('marketing_id'=>$marketing_id),$limit_to,$limit_from);
        
        if($enroll_record_arr){
            
            
            $this->load->library('PHPExcel');
    		$this->load->library('PHPExcel/IOFactory');
    		
    		$objPHPExcel = new PHPExcel();
    		$objPHPExcel->getProperties()->setTitle("导出预约报名信息")->setDescription("预约报名信息");
    		
    		$objPHPExcel->setActiveSheetIndex(0);
            
            $fields = array();
	        $fields[] = '报名时间';
            foreach($marketing_setting_info as $info){
                $fields[] = $info['name'];
            }
            $col = 0;
    		foreach ($fields as $field)
    		{
    			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col, 1, $field);
                
    			$col++;
    		}
            $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
            $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
            $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
            $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
    		$results = array();
            
    		foreach($enroll_record_arr as $record) {
                $result = array();
                if($record['content'])
                {
                    $content = @unserialize($record['content']);
                    if(is_array($content) && $content)
                    {
                        foreach($content as $v){
                            $result['报名时间'] = $record['dt_add'];
                            $v['name'] = isset($v['name']) ? $v['name'] : '';
                            $result[$v['name']] = isset($v['value']) ? $v['value'] : '';
                        }
                        $results[] = $result;
                    }
                }
    		}

    		$row = 2;
    		foreach($results as $data)
    		{
    			$col = 0;
    			foreach ($fields as $field)
    			{
    				$objPHPExcel->getActiveSheet()->setCellValueExplicitByColumnAndRow($col, $row, isset($data[$field]) ? $data[$field] : '',PHPExcel_Cell_DataType::TYPE_STRING);
    				$col++;
    			}
    		
    			$row++;
    		}
    		
    		$objPHPExcel->setActiveSheetIndex(0);
    		
    		$objWriter = IOFactory::createWriter($objPHPExcel, 'Excel5');
    		
    		// Sending headers to force the user to download the file
    		header('Content-Type: application/vnd.ms-excel');
    		header('Content-Disposition: attachment;filename="预约报名者信息_'.date('dMy').'.xls"');
    		header('Cache-Control: max-age=0');
    		
    		$objWriter->save('php://output');
        
        }	 
		
	}
}