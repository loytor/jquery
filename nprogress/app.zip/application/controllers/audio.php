<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Audio extends CI_Controller {
    
    protected $app_key = '5318162aac6f0086';
    protected $app_secret = '0c28536510e0b0b429750f478222d549';
    
	public function __construct() {
		parent::__construct();
	}
    
    public function index(){
        
    }
    
    public function upload(){
        
        $this->load->library('encrypt');
		$token = trim($this->input->get_post('token', TRUE));
		$token_decoded = $this->encrypt->decode($token);
		if ( ! $token_decoded) {
			header('Content-type: application/json');
			echo json_encode(array('success' => 0, 'message' => '请通过正常途径上传'));
			exit;
		}
		$token_data = unserialize($token_decoded);
		if ( ! isset($token_data['time']) OR ! isset($token_data['user_id']) OR (time() - $token_data['time']) > 3600) {
			header('Content-type: application/json');
			echo json_encode(array('success' => 0, 'message' => '页面停留时间过长，请刷新页面重新上传'));
			exit;
		}
		$upload_config = array(
			'upload_path'	=> FCPATH.'images/'.$token_data['user_id'].'/'.date('Ym').'/',
			'allowed_types'	=> 'mp3',
			'max_size'		=> 1024 * 10,
			'encrypt_name'     => TRUE
		);
		$this->load->library('upload', $upload_config);

        if(!is_dir($upload_config['upload_path'])){
            mkdir($upload_config['upload_path'], 0777, TRUE);
        }

		if ( ! $this->upload->do_upload('userfile')) {
		    header('Content-type: application/json');
			echo json_encode(array('success' => 0, 'message' => $this->upload->display_errors('', '')));
			exit;
		} else {
            $local_file = $this->upload->data();
            $temp_file = $local_file['file_path'].$local_file['file_name'];
            $PageEncoding = 'UTF-8';
            $this->load->library('getid3/getID3');
            $this->getid3->setOption(array('encoding' => $PageEncoding));
            $ThisFileInfo = $this->getid3->analyze($temp_file);
            if( isset($ThisFileInfo['error']) ){
                unlink($temp_file);
                header('Content-type: application/json');
                echo json_encode(array('success' => 0, 'message' => '文件类型与格式不符'));
                exit;
            }
            if( isset($ThisFileInfo['audio']) ){
                if( isset($ThisFileInfo['audio']['dataformat'])&&($ThisFileInfo['audio']['dataformat']=='mp3') ){
                }else{
                    unlink($temp_file);
                    header('Content-type: application/json');
                    echo json_encode(array('success' => 0, 'message' => '您传的不是MP3'));
                    exit;
                }
            }

			$image = $this->rest_upload($this->upload->data());
            echo json_encode(array(
                'success'     => 1,
                'mp3'         => image_url($image)
            ));
            exit;
		}
	}
	
    /**
     * @name 上传到图片服务器,并返回图片相对路径
     * @param $image
     * @param array $size example: array(array('width'=>80, 'height'=>80), array('width'=>640, 'height'=>320), array('width'=>640, 'height'=>640))
     * @return mixed
     */
    private function rest_upload($image, $size=array())
    {
        $this->load->library('rest', array(
            'server' => "http://".IMAGE_SERVER."/api",
            'app_key' => $this->app_key,
            'secret_key' => $this->app_secret,
        ));

        $data = array(
            'img' => '@'.$image['full_path'],
            'size' => json_encode($size)
        );
        //var_dump($data);exit;
        $result = $this->rest->post('upload/img', $data);
        @unlink($image['full_path']);
        //$this->rest->debug();
        //print_r($result);exit;
        if(isset($result['error']) || !isset($result['img'])) {
            $msg = isset($result['error']) ? $result['error'] : '上传失败';
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => $msg));
            exit;
        } else {
            return $result['img'];
        }
    }
    
    
}