<?php
/**
 * Created by JetBrains PhpStorm.
 * User: llj
 * Date: 13-9-12
 * Time: 下午2:17
 * To change this template use File | Settings | File Templates.
 * @property Model_reserve_order $model_reserve_order
 * @property Model_reserve_store $model_reserve_store
 * @property Model_app_config $model_app_config
 * @property Model_reserve_stuff $model_reserve_stuff
 * @property Model_address $model_address
 * @property Model_reserve_order_stuff $model_reserve_order_stuff
 * @property Model_collection_data $model_collection_data
 * @property Sms $sms
 */
class Reserve_order extends MY_Controller
{
	const DELETE_STATUS = -2;
	const CANCEL_STATUS = -1;
	const CONFIRM_STATUS = 1;
	const USER_PROCESSED_STATUS = 1;
	const DATE_TYPE = 2;
	const DATETIME_TYPE = 3;

	public function __construct()
	{
		parent::__construct();
		$this->load->model('model_reserve_order');
		$this->load->model('model_reserve_store');
		//$this->load->model('model_reserve_stuff');
		$this->load->model('model_app_config');
		$this->load->model('model_address');
		$this->load->model('model_reserve_order_stuff');
		$this->load->model('model_collection_data');
		$this->load->config('reserve');
		$this->types_arr = $this->config->item('reserve_types');
	}

	/**
	 * 订单列表
	 */
	public function index($type)
	{
		$this->has_reserve_auth($type);

		$id = $this->input->get('id');
		$store = $this->model_reserve_store->get_store_row(array('reserve_store.id'=>$id, 'type'=>$this->types_arr[$type]['type'], 'reserve_store.wid'=>User::$user_id));
		if(!$store)
		{
			$this->show_message(FALSE, '该门店不存在', '/reserve_store/'.$type);
		}
		$tpl_data['store'] = $store;

		$order_id = $this->input->get_post('order_id');
		$name = $this->input->get_post('name');
		$mobile = $this->input->get_post('mobile');
		$from_time = $this->input->get_post('from_time');
		$to_time = $this->input->get_post('to_time');
		$status = $this->input->get_post('status');
		$status = $status === null ? 'all' : $status;
		$user_status = $this->input->get_post('user_status');
		$user_status = $user_status === null ? 'all' : $user_status;
		//$store_name = $this->input->get_post('store_name');

		$tpl_data['order_id'] = $order_id ? $order_id : '';
		$tpl_data['name'] = $name ? $name : '';
		$tpl_data['mobile'] = $mobile ? $mobile : '';
		$tpl_data['from_time'] = $from_time ? $from_time : '';
		$tpl_data['to_time'] = $to_time ? $to_time : '';
		$tpl_data['status'] = $status;
		$tpl_data['user_status'] = $user_status;
		//$tpl_data['store_name'] = $store_name;

		$status_arr = $this->config->item('order_status');
		$status_arr = $status_arr ? $status_arr : array();
		$new_status_arr = array();
		foreach($status_arr as $sk=>$sa)
		{
			if($sk != self::DELETE_STATUS)
			{
				$tmp_arr = array();
				$tmp_arr['value'] = $sk;
				$tmp_arr['title'] = $sa;
				if((string)$sk == $status)
				{
					$tmp_arr['selected'] = 1;
				}
				else
				{
					$tmp_arr['selected'] = 0;
				}
				$new_status_arr[] = $tmp_arr;
			}
		}
		$user_status_arr = $this->config->item('order_user_status');
		$user_status_arr = $user_status_arr ? $user_status_arr : array();
		$new_user_status_arr = array();
		foreach($user_status_arr as $usk=>$usa)
		{
			$tmp_arr = array();
			$tmp_arr['value'] = $usk;
			$tmp_arr['title'] = $usa;
			if((string)$usk == $user_status)
			{
				$tmp_arr['selected'] = 1;
			}
			else
			{
				$tmp_arr['selected'] = 0;
			}
			$new_user_status_arr[] = $tmp_arr;
		}

		$tpl_data['status_arr'] = $new_status_arr;
		$tpl_data['user_status_arr'] = $new_user_status_arr;

		$page = (int)$this->input->get('per_page');
		$page = $page ? $page : self::CUR_PAGE;
		$this->pageQueryString = true;

		$where = array('reserve_order.wid'=>User::$user_id, 'address_id'=>$store['address_id'], 'type'=>$this->types_arr[$type]['type'], 'reserve_order.status != '=>self::DELETE_STATUS);

		//用于过滤查找
		$qs = array();
/*		if($store_name)
		{
			$address_arr = $this->model_address->get_all(array('name'=>'like:'.$store_name, 'wid'=>User::$user_id));
			if($address_arr)
			{
				foreach($address_arr as $ad)
				{
					$where['in:address_id'][] = $ad['id'];
				}
			}
			else
			{
				$where['1'] = 2;
			}
			$qs[] = 'store_name='.$store_name;
		}*/
		if($order_id)
		{
			$where['reserve_order.id'] = 'like:'.$order_id;
			$qs[] = 'order_id='.$order_id;
		}
		if($name)
		{
			$where['reserve_order.name'] = 'like:'.$name;
			$qs[] = 'name='.$name;
		}
		if($mobile)
		{
			$where['mobile'] = 'like:'.$mobile;
			$qs[] = 'mobile='.$mobile;
		}
		if($from_time)
		{
			$where['order_time >= '] = strtotime($from_time);
			$qs[] = 'from_time='.$from_time;
		}
		if($to_time)
		{
			$where['order_time <= '] = strtotime($to_time);
			$qs[] = 'to_time='.$to_time;
		}
		if(($status && $status !== 'all') || (string)$status == '0')
		{
			$where['reserve_order.status'] = $status;
			$qs[] = 'status='.$status;
		}
		if(($user_status && $user_status !== 'all') || (string)$user_status == '0')
		{
			$where['user_status'] = $user_status;
			$qs[] = 'user_status='.$user_status;
		}

		$queryStr = implode('&', $qs);
		$this->queryString = '?id=' . $id . $queryStr;

		$list = $this->model_reserve_order->get_all($where, $this->pageSize, $page, 'id', 'desc');

		$property_config = $this->get_property_config($type);

		foreach($list as &$item)
		{
			$item['order_time'] = date('Y-m-d H:i:s', $item['order_time']);
			$item['status'] = $status_arr[$item['status']];
			$item['user_status'] = $user_status_arr[$item['user_status']];
		}
		$tpl_data['list'] = $list;


		$tpl_data['type'] = $type;
		$tpl_data['type_info'] = $this->types_arr[$type];
		$tpl_data['per_page'] = $this->pageSize;
		$tpl_data['page'] = $page;
		$tpl_data['pagination'] = $this->pages($this->model_reserve_order->total_rows($where));
		$tpl_data['property_config'] = $property_config;
		$tpl_data['cur_nav'] = 'member_sys';
		$tpl_data['reserve_nav'] = 'order';
		$this->twig->display('reserve_order/index', $tpl_data);
	}

	/**
	 * @param $type
	 * @param $store_id
	 * @param $id
	 * 查看详情
	 */
	public function detail($type, $store_id, $id)
	{
		$this->has_reserve_auth($type);

		$store = $this->model_reserve_store->get_store_row(array('reserve_store.id'=>$store_id, 'type'=>$this->types_arr[$type]['type'], 'reserve_store.wid'=>User::$user_id));
		if(!$store)
		{
			$this->show_message(FALSE, '该门店不存在', '/reserve_store/'.$type);
		}
		$tpl_data['store'] = $store;

		$status_arr= $this->config->item('order_status');
		$user_status_arr = $this->config->item('order_user_status');

		$order = $this->model_reserve_order->get_row(array('id'=>$id, 'type'=>$this->types_arr[$type]['type'], 'wid'=>User::$user_id));
		$order['order_time'] = date('Y-m-d H:i:s', $order['order_time']);
		$order['status_title'] = $status_arr[$order['status']];
		$order['user_status_title'] = $user_status_arr[$order['user_status']];
		$tpl_data['order'] = $order;

		$stuffs = $this->model_reserve_order_stuff->get_order_stuffs(array('reserve_order_stuff.wid'=>User::$user_id, 'order_id'=>$id));
		$order_stuff = array();
		foreach($stuffs as $stuff)
		{
			$order_stuff[] = $stuff;
		}
		$tpl_data['order_stuff'] = $order_stuff;

		$property_config = $this->get_property_config($type);
		$tpl_data['property_config'] = $property_config;

		$property = json_decode($order['property'], TRUE);
		$new_property = array();
		if($property_config)
		{
			foreach($property_config as $pk=>$pc)
			{
				if(isset($property[$pk]))
				{
					if($pk == 'out_time')
					{
						$new_property[$pk] = date('Y-m-d H:i:s', $property[$pk]);
					}
					else
					{
						$new_property[$pk] = $property[$pk];
					}
				}
			}
		}
		$tpl_data['property'] = $new_property;

		//获取预订表单自定义设置字段和值
		$tpl_data['form_fields'] = $this->getFormFields($type, $store_id, $order['collection_id']);
		//获取基本设置
		$config = $this->model_app_config->get_row(array('user_id'=>User::$user_id, 'type'=>'reserve_'.$type));
		$config = json_decode($config['config'], TRUE);
		$stuff_name  = $config && isset($config['stuff_name']) && $config['stuff_name'] ? $config['stuff_name'] :  $this->types_arr[$type]['stuff'];
		$tpl_data['stuff_name'] = $stuff_name;
		$tpl_data['type'] = $type;
		$tpl_data['type_info'] = $this->types_arr[$type];
		$tpl_data['cur_nav'] = 'member_sys';
		$this->twig->display('reserve_order/detail', $tpl_data);
	}

	/**
	 * 订单导出
	 */
	public function export($type,$id)
	{
		//查询订单是否存在
		$store = $this->model_reserve_store->get_store_row(array('reserve_store.id'=>$id, 'type'=>$this->types_arr[$type]['type'], 'reserve_store.wid'=>User::$user_id));

		if(!$store)
		{
			$this->show_message(FALSE, '该门店不存在', '/reserve_order/'.$type.'?id='.$id);
		}
		$where = array('reserve_order.wid'=>User::$user_id, 'address_id'=>$store['address_id'], 'type'=>$this->types_arr[$type]['type'], 'reserve_order.status != '=>self::DELETE_STATUS);

		$list = $this->model_reserve_order->get_all($where, $this->pageSize, '', 'id', 'desc');

		$orderlist = array();
		if($list)
		{
			$status_arr = $this->config->item('order_status');
			$status_arr = $status_arr ? $status_arr : array();

			$user_status_arr = $this->config->item('order_user_status');
			$user_status_arr = $user_status_arr ? $user_status_arr : array();

            $property_config = $this->get_property_config($type);

			foreach($list as $key=> $item)
			{
				$orderlist[$key]['id'] = $item['id'];
				$orderlist[$key]['name'] = $item['name'];
				$orderlist[$key]['mobile'] = $item['mobile'];
				$orderlist[$key]['order_time'] = date('Y-m-d H:i:s', $item['order_time']);
				$orderlist[$key]['status'] = $status_arr[$item['status']];
				$orderlist[$key]['user_status'] = $user_status_arr[$item['user_status']];

                $property = json_decode($item['property'], TRUE);
                $new_property = array();
                if($property_config)
                {
                    foreach($property_config as $pk=>$pc)
                    {
                        if(isset($property[$pk]))
                        {
                            if($pk == 'out_time')
                            {
                                $orderlist[$key][$pk] = date('Y-m-d H:i:s', $property[$pk]);
                            }
                            else
                            {
                                $orderlist[$key][$pk] = $property[$pk];
                            }
                        }
                    }
                }
            }

            $fields['#'] = '#';
            $fields['id'] = '订单号';
            $fields['name'] = '预订人姓名';
			$fields['mobile'] = '联系电话';
            $fields['order_time'] = '订单时间';

            if($property_config) {
                foreach($property_config as $_pk=>$_pc) {
                    $fields[$_pk] = $_pc;
                }
            }

            $fields['status'] = '商家操作状态';
            $fields['user_status'] ='预定人操作状态';

			$this->excel_export($store['name'].'所有订单列表', $store['name'].'所有订单列表', $fields, $orderlist);
		}
        else
        {
            $this->show_message(FALSE, '尚无订单记录可导出', '/reserve_order/'.$type.'?id='.$id);
        }
	}

	private function getFormFields($type, $store_id, $collection_id)
	{
		$config = $this->model_app_config->get_row(array('user_id'=>User::$user_id, 'type'=>'reserve_form_'.$type));
		$form_fields = json_decode($config['config'], TRUE);
		$form_fields = $form_fields ? $form_fields : array();

		$store = $this->model_reserve_store->get_store_row(array('reserve_store.id'=>$store_id, 'type'=>$type, 'reserve_store.wid'=>User::$user_id));
		$store_form_fields = json_decode($store['form_fields'], TRUE);
		$store_form_fields = $store_form_fields ? $store_form_fields : array();

		//结合门店设置和预订表单设置
		if($form_fields && $store_form_fields)
		{
			foreach($form_fields as &$ff)
			{
				foreach($store_form_fields as $sff)
				{
					if($ff['id'] == $sff['id'])
					{
						$ff['items'] = $sff['items'];
					}
				}
			}
		}

		if($form_fields)
		{
			$collection_data = $this->model_collection_data->get_row(array('wid'=>User::$user_id, 'id'=>$collection_id, 'app_type'=>'reserve'));
			foreach($form_fields as &$f)
			{
				$f['value'] = (isset($collection_data[$f['id']]) && $collection_data[$f['id']]) ? $collection_data[$f['id']] : '';
				if($f['type'] == self::DATE_TYPE && $f['value'])
				{
					$f['value'] = date('Y-m-d', $f['value']);
				}
				if($f['type'] == self::DATETIME_TYPE && $f['value'])
				{
					$f['value'] = date('Y-m-d H:i:s', $f['value']);
				}
			}
		}
		return $form_fields;
	}

	/**
	 * @param $type
	 * @param $store_id
	 * @param $id
	 * 确认订单
	 */
	public function confirm($type, $store_id, $id)
	{
		$this->has_reserve_auth($type);

		$store = $this->model_reserve_store->get_store_row(array('reserve_store.id'=>$store_id, 'type'=>$this->types_arr[$type]['type'], 'reserve_store.wid'=>User::$user_id));
		if(!$store)
		{
			$this->show_message(FALSE, '该门店不存在', '/reserve_store/'.$type);
		}

		$order = $this->model_reserve_order->get_row(array('id'=>$id, 'type'=>$this->types_arr[$type]['type'], 'wid'=>User::$user_id));
		if(!$order)
		{
			$this->show_message(FALSE, '该订单不存在', '/reserve_order/'.$type.'?id='.$store_id);
		}
		$data_set['status'] = self::CONFIRM_STATUS;
		$data_set['user_status'] = self::USER_PROCESSED_STATUS;
		if($this->model_reserve_order->update(array('id'=>$id, 'type'=>$this->types_arr[$type]['type'], 'wid'=>User::$user_id), $data_set))
		{
            $msg = '确认订单成功';
            if($store['confirm_sms_on']) {
                //添加商家确认订单短信提醒
                //$content = '您的订单已经确认。下单时间：'.date('Y年m月d日 H点i分', $order['create_time']).', 订单号:'.$order['id'].', 预订电话:'.$store['reserve_tel'];
                $content = '您的订单已经确认。下单时间:'.date('Y年m月d日 H点i分', $order['create_time']).'， 订单号:'.$order['id'].', 预订电话:'.$store['reserve_tel'].'-'.$store['name'];
                /*
                if($this->session->userdata('web_name')) {
                    $content .= '【'.$this->session->userdata('web_name').'】';
                }
                */
/*                $this->load->library('Sms');
                $out = $this->sms->send_text($order['mobile'], $content);
                $smsExp = explode(',',$out);
                if($smsExp[0] == 0)
                {
                    $msg .= ',短信发送成功。';
                }
                else
                {
                    $msg .= ',短信发送失败，错误信息：'.$smsExp[1];
                }*/
                $result = $this->send_msg(User::$user_id, $order['mobile'], $content);
                if ($result['ret'] == 0) {
                    $msg .= ',短信发送成功。';
                } else {
                    $msg .= ',短信发送失败，错误信息：'.$result['msg'];
                }
            }
			$this->show_message(TRUE, $msg, '/reserve_order/'.$type.'?id='.$store_id);
		}
		else
		{
			$this->show_message(FALSE, '确认订单失败', '/reserve_order/detail/'.$type.'/'.$store_id.'/'.$id);
		}
	}

	/**
	 * @param $type
	 * @param $store_id
	 * @param $id
	 * 取消订单
	 */
	public function cancel($type, $store_id, $id)
	{
		$this->has_reserve_auth($type);

		$store = $this->model_reserve_store->get_store_row(array('reserve_store.id'=>$store_id, 'type'=>$this->types_arr[$type]['type'], 'reserve_store.wid'=>User::$user_id));
		if(!$store)
		{
			$this->show_message(FALSE, '该门店不存在', '/reserve_store/'.$type);
		}

		$order = $this->model_reserve_order->get_row(array('id'=>$id, 'type'=>$this->types_arr[$type]['type'], 'wid'=>User::$user_id));
		if(!$order)
		{
			$this->show_message(FALSE, '该订单不存在', '/reserve_order/'.$type.'?id='.$store_id);
		}
		$data_set['status'] = self::CANCEL_STATUS;
		if($this->model_reserve_order->update(array('id'=>$id, 'type'=>$this->types_arr[$type]['type'], 'wid'=>User::$user_id), $data_set))
		{
			$this->show_message(TRUE, '取消订单成功', '/reserve_order/'.$type.'?id='.$store_id);
		}
		else
		{
			$this->show_message(FALSE, '取消订单失败', '/reserve_order/detail/'.$type.'/'.$store_id.'/'.$id);
		}
	}

	/**
	 * @param $type
	 * @param $store_id
	 * @param $id
	 * 删除订单
	 */
	public function delete($type, $store_id, $id)
	{
		$this->has_reserve_auth($type);

		$store = $this->model_reserve_store->get_store_row(array('reserve_store.id'=>$store_id, 'type'=>$this->types_arr[$type]['type'], 'reserve_store.wid'=>User::$user_id));
		if(!$store)
		{
			$this->show_message(FALSE, '该门店不存在', '/reserve_store/'.$type);
		}

		$order = $this->model_reserve_order->get_row(array('id'=>$id, 'type'=>$this->types_arr[$type]['type'], 'wid'=>User::$user_id));
		if(!$order)
		{
			$this->show_message(FALSE, '该订单不存在', '/reserve_order/'.$type.'?id='.$store_id);
		}
		if($order['status'] != self::CANCEL_STATUS)
		{
			$this->show_message(FALSE, '请先取消订单', '/reserve_order/detail/'.$type.'/'.$store_id.'/'.$id);
		}
		$data_set['status'] = self::DELETE_STATUS;
		if($this->model_reserve_order->update(array('id'=>$id, 'type'=>$this->types_arr[$type]['type'], 'wid'=>User::$user_id), $data_set))
		{
			$this->show_message(TRUE, '删除订单成功', '/reserve_order/'.$type.'?id='.$store_id);
		}
		else
		{
			$this->show_message(FALSE, '删除订单失败', '/reserve_order/detail/'.$type.'/'.$store_id.'/'.$id);
		}
	}

	/**
	 * 获取订单的property设置
	 */
	private function get_property_config($type)
	{
		$config = $this->model_app_config->get_one(array('user_id'=>User::$user_id, 'type'=>'reserve_order_'.$type), 'config');
		$config = json_decode($config, TRUE);
		$property = $config['property'];
		if(!$property)
		{
			$default_config = $this->config->item($type.'_order');
			$property = isset($default_config['property']) ? $default_config['property'] : array();
		}
		return $property;
	}
}