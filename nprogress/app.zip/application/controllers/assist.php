<?php
/**
 * Created by JetBrains PhpStorm.
 * User: llj
 * Date: 13-10-22
 * Time: 下午2:34
 * To change this template use File | Settings | File Templates.
 * @property Model_assist $model_assist
 * @property Model_app_config $model_app_config
 */
class Assist extends MY_Controller
{
	private $types = array(
		0 => '电话',
		1 => '外链'
	);

	public function __construct()
	{
		parent::__construct();
		$this->load->model('model_assist');
		$this->load->model('model_app_config');
	}

	public function index()
	{
		$title = $this->input->get_post('title');
		$type = $this->input->get_post('type');
		$content = $this->input->get_post('content');
		$rank = $this->input->get_post('rank');

		$type = (!is_null($type)) ? $type : -1;
		$rank = (!is_null($rank)) ? $rank : 0;
		$tpl_data['title'] = $title ? $title : '';
		$tpl_data['type'] = $type;
		$tpl_data['content'] = $content ? $content : '';
		$tpl_data['rank'] = $rank;

		$page = (int)$this->input->get('per_page');
		$page = $page ? $page : self::CUR_PAGE;
		$this->pageQueryString = true;

		$where_set = array('wid'=>User::$user_id);
		//用于过滤查找
		$qs = array();
		if($title)
		{
			$where_set['title'] = 'like:'.$title;
			$qs[] = 'title='.$title;
		}
		if($type != -1)
		{
			$where_set['type'] = $type;
			$qs[] = 'type='.$type;
		}
		if($content)
		{
			$where_set['content'] = 'like:'.$content;
			$qs[] = 'content='.$content;
		}
		if($rank != '')
		{
			$where_set['rank'] = $rank;
			$qs[] = 'rank='.$rank;
		}

		$queryStr = implode('&', $qs);
		$this->queryString = '?' . $queryStr;
		$list = $this->model_assist->get_all($where_set, $this->pageSize, $page, 'rank', 'asc');
		foreach($list as &$row)
		{
			$row['type_name'] = $this->types[$row['type']];
		}

		$tpl_data['list'] = $list;
		$tpl_data['per_page'] = $this->pageSize;
		$tpl_data['page'] = $page;
		$tpl_data['pagination'] = $this->pages($this->model_assist->total_rows($where_set));
		$tpl_data['types'] = $this->types;
		$tpl_data['cur_nav'] = 'cate';
		$this->twig->display('assist/index', $tpl_data);
	}

	public function add()
	{
		$this->form_validation->set_rules('title', '标题', 'trim|required|max_length[20]');
		$this->form_validation->set_rules('icon', '图标', 'trim|required|max_length[255]');
		if($this->form_validation->run())
		{
			$data_set['wid'] = User::$user_id;
			$data_set['title'] = $this->form_validation->set_value('title');
			$data_set['icon'] = $this->form_validation->set_value('icon');
			$data_set['type'] = $this->input->post('type');
			$data_set['content'] = $this->input->post('content');
			$rank = $this->input->post('rank');
			$data_set['rank'] = $rank ? (int)$rank : 0;

			if($this->model_assist->add($data_set))
			{
				$this->show_message(TRUE, '添加成功', '/assist');
			}
			else
			{
				$this->show_message(FALSE, '添加失败', '/assist/add');
			}
		}
		else
		{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/assist/add');
			}
		}

		$tpl_data['types'] = $this->types;
		$tpl_data['token'] = $this->token;
		$tpl_data['cur_nav'] = 'cate';
		$this->twig->display('assist/add', $tpl_data);
	}

	public function edit($id)
	{
		$assist = $this->model_assist->get_row(array('id'=>$id, 'wid'=>User::$user_id));
		if(!$assist)
		{
			$this->show_message(FALSE, '该辅助按钮不存在', '/assist');
		}

		$this->form_validation->set_rules('title', '标题', 'trim|required|max_length[20]');
		$this->form_validation->set_rules('icon', '图标', 'trim|required|max_length[255]');
		if($this->form_validation->run())
		{
			$data_set['title'] = $this->form_validation->set_value('title');
			$data_set['icon'] = $this->form_validation->set_value('icon');
			$data_set['type'] = $this->input->post('type');
			$data_set['content'] = $this->input->post('content');
			$rank = $this->input->post('rank');
			$data_set['rank'] = $rank ? (int)$rank : 0;

			if($this->model_assist->update(array('id'=>$id, 'wid'=>User::$user_id), $data_set))
			{
				$this->show_message(TRUE, '编辑成功', '/assist');
			}
			else
			{
				$this->show_message(FALSE, '编辑失败', '/assist/edit/'.$id);
			}
		}
		else
		{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/assist/edit/'.$id);
			}
		}

		$tpl_data['assist'] = $assist;
		$tpl_data['types'] = $this->types;
		$tpl_data['token'] = $this->token;
		$tpl_data['cur_nav'] = 'cate';
		$this->twig->display('assist/edit', $tpl_data);
	}

	public function delete($id)
	{
		$assist = $this->model_assist->get_row(array('id'=>$id, 'wid'=>User::$user_id));
		if(!$assist)
		{
			$this->show_message(FALSE, '该辅助按钮不存在', '/assist');
		}
		if($this->model_assist->delete(array('id'=>$id, 'wid'=>User::$user_id)))
		{
			$this->show_message(TRUE, '删除辅助按钮成功', '/assist');
		}
		else
		{
			$this->show_message(FALSE, '删除辅助按钮失败', '/assist');
		}
	}

	public function setting_back()//TODO 旧
	{
		$assist_config = $this->model_app_config->get_row(array('user_id'=>User::$user_id, 'type'=>'assist'));
		$config = json_decode($assist_config['config'], TRUE);
		$tpl_data['config'] = $config ? $config : array();

		$this->form_validation->set_rules('config[display]', '显示', 'trim|required|integer');
		if($this->form_validation->run())
		{
			$config = $this->input->post('config');
			$data_set['config'] = $config ? json_encode($config) : '';

			if(!$assist_config)
			{
				$data_set['user_id'] = User::$user_id;
				$data_set['type'] = 'assist';
				if($this->model_app_config->add($data_set, true))
				{
					$this->show_message(TRUE, '保存成功', '/assist/setting');
				}
				else
				{
					$this->show_message(FALSE, '保存失败', '/assist/setting');
				}
			}
			else
			{
				if($this->model_app_config->update(array('user_id'=>User::$user_id, 'type'=>'assist'), $data_set))
				{
					$this->show_message(TRUE, '保存成功', '/assist/setting');
				}
				else
				{
					$this->show_message(FALSE, '保存失败', '/assist/setting');
				}
			}
		}
		else
		{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/assist/setting');
			}
		}
		$tpl_data['cur_nav'] = 'cate';
		$this->twig->display('assist/setting', $tpl_data);
	}

    private function token()
    {
        $this->load->library('encrypt');
        $token_data = array('user_id' => User::$user_id, 'time' => time());
        return $token = $this->encrypt->encode(serialize($token_data));
    }

    public function setting()
    {
        $assist_config = $this->model_app_config->get_row(array('user_id'=>User::$user_id, 'type'=>'assist'));
        $config = json_decode($assist_config['config'], TRUE);
        $tpl_data['config'] = $config ? $config : array();


        $this->form_validation->set_rules('config[display]', '显示', 'trim|required|integer');
        $this->form_validation->set_rules('config[menu]', '自定义菜单', 'trim');


        if($this->form_validation->run())
        {
            $config = $this->input->post('config');

            if(($config['type'] == 3 || $config['type'] == 4) && !$config['menu'] ){
                $this->show_message(FALSE, '请填写自定义菜单', '/assist/setting');exit;
            }
            if(isset($config['menu']) && $config['menu']){
                $config['menu'] = array_sort($config['menu'], 'rank', 'asc');
                foreach($config['menu'] as $k => $v){
                    if ($v['name'] == '') {
                        unset($config['menu'][$k]);
                    }
                    if(isset($v['name']) && !empty($v['name'])){
                        if( mb_strlen($v['name']) > 4 ){
                            $this->show_message(FALSE, '菜单名称不能大于4个字符', '/assist/setting');
                            break;
                            exit;
                        }
                        $config['menu'][$k]['name'] = trim($v['name']);
                        isset($v['keyword']) ? $config['menu'][$k]['link'] = trim($v['keyword']) : '';
                        if(isset($v['keyword'])) unset($config['menu'][$k]['keyword']);
                        $config['menu'][$k]['rank'] = isset($v['rank']) ? $v['rank'] : $k+1;
                        if(isset($v['sub_menu'])){
                            foreach($v['sub_menu'] as $kk => $vv){
                                if(isset($vv['name']) && !empty($vv['name'])){
                                    if( mb_strlen($vv['name']) > 4 ){
                                        $this->show_message(FALSE, '菜单名称不能大于4个字符', '/assist/setting');
                                        break;
                                        exit;
                                    }
                                    $config['menu'][$k]['sub_menu'][$kk]['name'] = trim($vv['name']);
                                    isset($vv['keyword']) ? $config['menu'][$k]['sub_menu'][$kk]['link'] = trim($vv['keyword']) : '';
                                    if(isset($vv['keyword'])) unset($config['menu'][$k]['sub_menu'][$kk]['keyword']);
                                    if(isset($vv['key'])) unset($config['menu'][$k]['sub_menu'][$kk]['key']);
                                    $config['menu'][$k]['sub_menu'][$kk]['rank'] = $vv['rank'] ? $vv['rank'] : $kk+1;
                                }else{
                                    unset($config['menu'][$k]['sub_menu'][$kk]);
                                }
                                /*else{
                                    $this->show_message(FALSE, '菜单名称不能为空', '/assist/setting');
                                    break;
                                    exit;
                                }*/
                            }
                            $subMenu = array_sort($config['menu'][$k]['sub_menu'], 'rank', 'asc');
                            sort($subMenu);
                            $config['menu'][$k]['sub_menu'] = $subMenu;
                        }
                    }/*else{
                        $this->show_message(FALSE, '菜单名称不能为空', '/assist/setting');
                        break;
                        exit;
                    }*/
                }
                sort($config['menu']);
            }

            $data_set['config'] = $config ? json_encode($config) : '';


            $this->model_app_config->delete(array('user_id'=>User::$user_id, 'type'=>'assist'));

            $data_set['user_id'] = User::$user_id;
            $data_set['type'] = 'assist';
            if($this->model_app_config->add($data_set, true))
            {
                $this->show_message(TRUE, '保存成功', '/assist/setting');
            }
            else
            {
                $this->show_message(FALSE, '保存失败', '/assist/setting');
            }

            /*
            if(!$assist_config)
            {
                $data_set['user_id'] = User::$user_id;
                $data_set['type'] = 'assist';
                if($this->model_app_config->add($data_set, true))
                {
                    $this->show_message(TRUE, '保存成功', '/assist/setting');
                }
                else
                {
                    $this->show_message(FALSE, '保存失败', '/assist/setting');
                }
            }
            else
            {
                if($this->model_app_config->update(array('user_id'=>User::$user_id, 'type'=>'assist'), $data_set))
                {
                    $this->show_message(TRUE, '保存成功', '/assist/setting');
                }
                //else
                {
                    $this->show_message(FALSE, '保存失败', '/assist/setting');
                }
            }
            */
        }
        else
        {
            $errors = validation_errors();
            if ($errors) {
                $this->show_message(FALSE, $errors, '/assist/setting');
            }
        }
        $tpl_data['token'] = $this->token();
        $tpl_data['cur_nav'] = 'cate';
        $this->twig->display('assist/setting', $tpl_data);
    }

}