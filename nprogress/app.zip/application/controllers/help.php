<?php
/**
 * Created by JetBrains PhpStorm.
 * User: along
 * Date: 13-9-29
 * Time: 上午10:46
 * To change this template use File | Settings | File Templates.
 */


class Help extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
	}
	public function index()
	{
		$this->load->model('model_user');
		$logged_user_id = logged_user_id();
		$userinfo = $this->model_user->get_row(array('id'=>$logged_user_id));
		//if($userinfo['agent_id'] != '5210556554f58021')
        if($userinfo['agent_id'] != 203)
		{
			$type = $this->input->get('type');
			$data['type'] = $type ? $type : 'room';
			$this->twig->display('help/index', $data);
		}
		else
		{
			$this->twig->display('help/error');
		}
	}
}