<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Vipcard extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('model_vipcard');
		$this->load->model('model_cate');
		$this->load->model('model_cate_lists');
	}

	public function index(){
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$vipcard = $this->model_vipcard->get_row(array('user_id' => $logged_user_id));
		if($vipcard['image']){
			$vipcard['image'] = $vipcard['image'];
			$vipcard['image_preview'] = image_url($vipcard['image'], 640, 320);
		}

		$cate_arr = array();
		$_cate_arr = $this->model_cate->get_all(array('user_id' => $logged_user_id), 100, 1);
		foreach ($_cate_arr as $_cate) {
			$cate_arr[$_cate['id']] = $_cate;
		}
		$tpl_data['cate_arr'] = $cate_arr;
		
		$this->load->library('form_validation');
		$this->load->helper('form');
		$this->form_validation->set_rules('cate_id', '栏目', 'trim');
		$this->form_validation->set_rules('logo', 'logo图片', 'trim|required|max_length[255]|htmlspecialchars');
		$this->form_validation->set_rules('name', '会员卡名称', 'trim|required|max_length[10]|htmlspecialchars');
		$this->form_validation->set_rules('background', '会员卡颜色底纹', 'trim|required|max_length[255]|htmlspecialchars');
		$this->form_validation->set_rules('address_name', '地址名称', 'trim|required|max_length[50]|htmlspecialchars');
		$this->form_validation->set_rules('address_details', '详细地址', 'trim|required|max_length[100]|htmlspecialchars');
		$this->form_validation->set_rules('tel_name', '电话名称', 'trim|required|max_length[50]|htmlspecialchars');
		$this->form_validation->set_rules('tel_number', '电话号码', 'trim|required|max_length[20]|htmlspecialchars');
		$this->form_validation->set_rules('welcome_msg', '欢迎辞', 'trim|required|max_length[20]|htmlspecialchars');
		
		if ($this->form_validation->run()) {
			$cate_id = $this->form_validation->set_value('cate_id');
			if ($cate_id AND ! isset($cate_arr[$cate_id])) {
				$this->show_message(FALSE, '栏目不存在', '/vipcarde/index');
			}
							
			$data_set['user_id'] = $logged_user_id;	
			$data_set['name'] = $this->form_validation->set_value('name');
			$data_set['image'] = $this->input->post('image');
			$data_set['cate_id'] = $cate_id;
			$data_set['logo'] = $this->form_validation->set_value('logo');
			$data_set['background'] = $this->form_validation->set_value('background');
			$data_set['selected_bg'] = $this->input->post('selected_bg');
			$data_set['address_name'] = $this->form_validation->set_value('address_name');
			$data_set['address_details'] = $this->form_validation->set_value('address_details');
			$data_set['tel_name'] = $this->form_validation->set_value('tel_name');
			$data_set['tel_number'] = $this->form_validation->set_value('tel_number');
			$data_set['tel_name2'] = $this->input->post('tel_name2');
			$data_set['tel_number2'] = $this->input->post('tel_number2');
			$data_set['welcome_msg'] = $this->form_validation->set_value('welcome_msg');
            $data_set['instruction'] = ($this->input->post('instruction')) ? $this->input->post('instruction') : '';
            
			if ( !$vipcard ) {//添加
				$vipcard_id = $this->model_vipcard->add($data_set);
				//栏目表count_vipcard +1, cate_lists增加记录
				if ($cate_id) {
					$this->model_cate->count_step($cate_id, 'count_vipcard', 1);
					$data_cate_lists['user_id'] = $logged_user_id;
					$data_cate_lists['cate_id'] = $cate_id;
					$data_cate_lists['type'] = 'vipcard';
					$data_cate_lists['lists_id'] = $vipcard_id;
					$data_cate_lists['rank'] = 9999;
					$this->model_cate_lists->add($data_cate_lists);
				}
								
				if($vipcard_id){
                    $reply_data = array();
                    $reply_data['keyword'][] = '会员卡';
                    $reply_data['type'] = 'article';
                    $reply_data['site_id'] = $logged_user_id;
                    $reply_data['count_match'] = 0;
                    $reply_data['dt_add'] = $reply_data['dt_update'] = time();
                    $item_id = (string)new MongoId();
                    $reply_data['content'][$item_id] = array(
                        'id'    => $item_id,
                        'type'  => 'Vipcard',
                        'title' => $data_set['name'],
                        'desc'  => $data_set['welcome_msg'],
                        'image' => $data_set['image'],
                        'ref_id'=> $vipcard_id,
                        'url'   => '/vipcard/view/'.$vipcard_id,
                        'rank'  => 9999
                    );
                    $this->load->library('Mongo_db');
                    $this->mongo_db->insert('reply', $reply_data);
				}
			}else{ //编辑
				$this->model_vipcard->update(array('user_id'=>$logged_user_id), $data_set);
				//判断自动回复里的会员卡是否存在，如果不存在，自动添加
				/*if( isset($vipcard['id']) && $vipcard['id'] ){
					$exist_vipcard = $this->model_reply->exist_vipcard($logged_user_id, $vipcard['id']);
					if(!$exist_vipcard){
                        $reply_data = array();
                        $reply_data['keyword'][] = '会员卡';
                        $reply_data['type'] = 'article';
                        $reply_data['site_id'] = $logged_user_id;
                        $reply_data['count_match'] = 0;
                        $reply_data['dt_add'] = $reply_data['dt_update'] = time();
                        $item_id = (string)new MongoId();
                        $reply_data['content'][$item_id] = array(
                            'id'    => $item_id,
                            'type'  => 'Vipcard',
                            'title' => $data_set['name'],
                            'desc'  => $data_set['welcome_msg'],
                            'image' => $data_set['image'],
                            'ref_id'=> $vipcard['id'],
                            'url'   => '/vipcard/view/'.$vipcard['id'],
                            'rank'  => 9999
                        );
                        $this->load->library('Mongo_db');
                        $this->mongo_db->insert('reply', $reply_data);
					}
				}*/				
				if ($vipcard['cate_id'] != $cate_id) {
					if ($cate_id) {
						$this->model_cate->count_step($cate_id, 'count_vipcard', 1);
						$data_cate_lists['user_id'] = $logged_user_id;
						$data_cate_lists['cate_id'] = $cate_id;
						$data_cate_lists['type'] = 'vipcard';
						$data_cate_lists['lists_id'] = $vipcard['id'];
						$data_cate_lists['rank'] = 9999;
						$this->model_cate_lists->add($data_cate_lists);						
					}
					if ($vipcard['cate_id']) {
						$this->model_cate->count_step($vipcard['cate_id'], 'count_vipcard', -1);
						$del_data_cate_lists['user_id'] = $logged_user_id;
						$del_data_cate_lists['cate_id'] = $vipcard['cate_id'];
						$del_data_cate_lists['type'] = 'vipcard';
						$del_data_cate_lists['lists_id'] = $vipcard['id'];						
						$this->model_cate_lists->delete($del_data_cate_lists);
					}
				}				
			}
			$this->show_message(TRUE, '更新成功', '/vipcard');
		} else {
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/vipcard');
			}
		}

		if ( !$vipcard ) {//添加
			$vipcard['name'] = '';
			$vipcard['image'] = c_image_url('/assets/img/vip.jpg');
			$vipcard['cate_id'] = '';
			$vipcard['image_preview'] = c_image_url('/assets/img/vip.jpg', 640, 320);
			$vipcard['logo'] = c_image_url('/assets/img/KFC.png');
			$vipcard['background'] = c_image_url('/assets/img/vipcard/vip-bg01.png');
			$vipcard['selected_bg'] = 'bg01';
			$vipcard['address_name'] = '';
			$vipcard['address_details'] = '';
			$vipcard['tel_name'] = '';
			$vipcard['tel_number'] = '';
			$vipcard['tel_name2'] = '';
			$vipcard['tel_number2'] = '';
			$vipcard['welcome_msg'] = '';
            $vipcard['instruction'] = '';
		}
		
		$placeholder['name'] = '如：微信会员卡';
		$placeholder['address_name'] = '如：地址';
		$placeholder['address_details'] = '请输入您企业的地址';
		$placeholder['tel_name'] = '如：电话';
		$placeholder['tel_number'] = '请输入您企业的电话';
		$placeholder['tel_name2'] = '如：电话';
		$placeholder['tel_number2'] = '请输入您企业的电话';
		$placeholder['welcome_msg'] = '如：欢迎使用微信会员卡';
		
		$tpl_data['placeholder'] = $placeholder;
		
		$tpl_data['vipcard'] = $vipcard;
		
		$bg_arr = array(
			array('id'=>'bg01', 'img'=>c_image_url('/assets/img/vipcard/vip-bg01.png')),
			array('id'=>'bg02', 'img'=>c_image_url('/assets/img/vipcard/vip-bg02.png')),
			array('id'=>'bg03', 'img'=>c_image_url('/assets/img/vipcard/vip-bg03.png')),
			array('id'=>'bg04', 'img'=>c_image_url('/assets/img/vipcard/vip-bg04.png')),
			array('id'=>'bg05', 'img'=>c_image_url('/assets/img/vipcard/vip-bg05.png')),
			array('id'=>'bg06', 'img'=>c_image_url('/assets/img/vipcard/vip-bg06.png')),
			array('id'=>'bg07', 'img'=>c_image_url('/assets/img/vipcard/vip-bg07.png')),
			array('id'=>'bg08', 'img'=>c_image_url('/assets/img/vipcard/vip-bg08.png')),
			array('id'=>'bg09', 'img'=>c_image_url('/assets/img/vipcard/vip-bg09.png')),
			array('id'=>'bg10', 'img'=>c_image_url('/assets/img/vipcard/vip-bg10.png'))
		);
		$tpl_data['bg_arr'] = $bg_arr;
		
		$this->load->library('encrypt');
		$token_data = array('user_id' => $logged_user_id, 'time' => time());
		$tpl_data['token'] = $this->encrypt->encode(serialize($token_data));		
		$tpl_data['cur_nav'] = 'marketing';
		$this->twig->display('vipcard/index', $tpl_data);	
	}
	
	private function show_message($success, $message, $redirect) {
		if ($this->input->is_ajax_request()) {
			$data = array(
					'success'	=> $success ? 1 : 0,
					'message'	=> strip_tags($message),
			);
			header('Content-type: application/json');
			echo json_encode($data);
		} else {
			$tpl_data = array(
					'message'	=> $message,
					'redirect'	=> $redirect,
			);
			$this->twig->display('show_message', $tpl_data);
		}
		exit;
	}
	
	public function welcome(){
		$logged_user_id = logged_user_id();
		$vipcard = $this->model_vipcard->get_row(array('user_id' => $logged_user_id));
		$vipcard['image_preview'] = image_url($vipcard['image'], 80, 80);
		header('Content-type: application/json');
		echo json_encode($vipcard);
	}
}