<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Xitie extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('model_wedding_invitation');
		$this->load->config('baidu');
	}

	public function index() {
		$id = $this->session->userdata('xitie_id');
		$token = $this->session->userdata('xitie_token');
		if($id && $token){//已经登录了
			$wedding_invitation = $this->model_wedding_invitation->get_row(array('id' => strtoupper($id), 'token' => $token));
			if (!$wedding_invitation) {
				$this->session->unset_userdata('xitie_id');
				$this->session->unset_userdata('xitie_token');
				$this->show_message(FALSE, '找不到该喜帖', '/xitie');
			}
			if ($wedding_invitation['token'] != $token) {
				$this->session->unset_userdata('xitie_id');
				$this->session->unset_userdata('xitie_token');
				$this->show_message(FALSE, '密码不正确', '/xitie');
			}

			$wedding_invitation['photo_arr'] = json_decode($wedding_invitation['photo'], TRUE);
			$wedding_invitation['date'] = ($wedding_invitation['date'] == '0000-00-00 00:00:00') ? '' : $wedding_invitation['date'];
			//print_r($wedding_invitation);
			$tpl_data['wedding_invitation'] = $wedding_invitation;

			$this->load->library('form_validation');
			$this->load->helper('form');
			$this->form_validation->set_rules('token', '密码', 'trim|required|max_length[10]|htmlspecialchars');
			$this->form_validation->set_rules('groom_name', '新郎名字', 'trim|required|max_length[20]|htmlspecialchars');
			$this->form_validation->set_rules('bride_name', '新娘名字', 'trim|required|max_length[20]|htmlspecialchars');
			//$this->form_validation->set_rules('video_url', '视频链接', 'trim|htmlspecialchars');

			if ($this->form_validation->run()) {
				$data_set['token'] = $this->form_validation->set_value('token');
				$data_set['cover_type'] = $this->input->post('cover_type');
				$data_set['groom_name'] = $this->form_validation->set_value('groom_name');
				$data_set['bride_name'] = $this->form_validation->set_value('bride_name');
				$data_set['cover_img'] = $this->input->post('cover_img');
				$data_set['thumb'] = $this->input->post('cover_img');//封面图作为头像图
				$data_set['music'] = $this->input->post('music');
				//$data_set['video_url'] = $this->form_validation->set_value('video_url');
				$video_url = preg_replace('/(width=(?:(?:[\'|"])?[^\s]+(?:[\'|"])?)+)/i', 'width="100%" ', $this->input->post('video_url'));
				$video_url = preg_replace('/(height=(?:(?:[\'|"])?[^\s]+(?:[\'|"])?)+)/i', 'height="100%" ', $video_url);
				$data_set['video_url'] = $video_url;
				$data_set['photo'] = json_encode($this->input->post('photo'));
				$data_set['declarations'] = $this->input->post('declarations');
				if($this->input->post('date')){
					$data_set['date'] = $this->input->post('date');
				}
				$data_set['address'] = $this->input->post('address');
				$data_set['lat'] = $this->input->post('lat');
				$data_set['lng'] = $this->input->post('lng');
				$data_set['telephone'] = $this->input->post('telephone');

				$this->model_wedding_invitation->update($id, $data_set);
				$this->show_message(TRUE, '更新成功', '/xitie');
			} else {
				$errors = validation_errors();
				if ($errors) {
					$this->show_message(FALSE, $errors, '/xitie');
				}
			}
			$this->load->library('encrypt');
			$token_data = array('user_id' => $wedding_invitation['user_id'], 'time' => time());
			$tpl_data['token'] = $this->encrypt->encode(serialize($token_data));

			$this->config->load('music');
			$tpl_data['music_arr'] = $this->config->item('music');
			$tpl_data['ak'] = $this->config->item('baidu_token');
			$this->twig->display('xitie/edit', $tpl_data);
		}else{//未登录
			$this->load->library('form_validation');
			$this->load->helper('form');
			$this->form_validation->set_rules('id', '喜帖获取码', 'trim|required');
			$this->form_validation->set_rules('token', '密码', 'trim|required');
			if ($this->form_validation->run()) {
				$id = $this->form_validation->set_value('id');
				$token = $this->form_validation->set_value('token');
				$wedding_invitation = $this->model_wedding_invitation->get_row(array('id' => strtoupper($id), 'token' => $token));
				if ( ! $wedding_invitation) {
					$this->show_message(FALSE, '找不到该喜帖', '/xitie');
				}
				if ($wedding_invitation['token'] != $token) {
					$this->show_message(FALSE, '密码不正确', '/xitie');
				}

				$sess_arr = array(
						'xitie_id' => $id,
						'xitie_token' => $token
				);

				$this->session->set_userdata($sess_arr);
                header("Location: /xitie");
				//$this->show_message(TRUE, '登录成功', auto_redirect('/xitie', TRUE));
			} else {
				$errors = validation_errors();
				if ($errors) {
					$this->show_message(FALSE, $errors, '/xitie');
				}
			}
			$this->twig->display('xitie/login');
		}
	}

    public function logout()
    {
        $this->session->unset_userdata(array(
            'xitie_id'	=> '',
            'xitie_token'	=> '',
        ));

        $this->session->sess_destroy();
    }

	private function show_message($success, $message, $redirect) {
		if ($this->input->is_ajax_request()) {
			$data = array(
					'success'	=> $success ? 1 : 0,
					'message'	=> strip_tags($message),
			);
			header('Content-type: application/json');
			echo json_encode($data);
		} else {
			$tpl_data = array(
					'message'	=> $message,
					'redirect'	=> $redirect,
			);
			$this->twig->display('show_message', $tpl_data);
		}
		exit;
	}
}