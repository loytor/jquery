<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Class Home
 * @property Model_affiche $model_affiche
 * @property Model_app $model_app
 * @property Model_user $model_user
 */
class Home extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('model_app');
        $this->load->model('model_user');
    }

    /**
     * 新版商家后台
     */
    public function index() {

        $tpl_data = array();

        //获取用户信息
        $tpl_data['user'] = $user = $this->model_user->get_row(array('id'=>User::$user_id));

        //获取代理商信息
        $agent_contact = '请联系您的代理商';
        if ($user['agent_id']) {
            $this->load->model('business_contact_model');
            $agent_contact = $this->business_contact_model->where(array('agent_id'=>$user['agent_id']))->find();
            $agent_contact = $agent_contact['business_contact'];
        }
        //!$agent_contact && $agent_contact = '请联系您的代理商';
        $tpl_data['agent_contact'] = $agent_contact;

        //区分用户类型 is_dev为1为开发者，2为开发者兼微网站用户

        if($tpl_data['user']['is_dev'] > 0)
        {
            $this->load->model('developer_bind_model');
            //关联的开发者id
            $bind = $this->developer_bind_model->get_user_bind_developer_id(User::$user_id);
            if($bind && $bind['developer_id'])
            {
                //测试应用
                $this->load->model('oauth_client_model');
                /*
                $testClient = $this->oauth_client_model->get_client_list(array('developer_id'=>$bind['developer_id'],'status != '=>2));
                $tpl_data['testClient'] = $testClient;
                //正式应用
                */
                $testClient = $oauthClient = array();
                $oauth_client_list = $this->oauth_client_model->get_client_list(array('developer_id'=>$bind['developer_id']),'',100);
                if($oauth_client_list)
                {
                    foreach($oauth_client_list as $_client_list)
                    {
                        //正式应用
                        if($_client_list['status'] == 2)
                        {
                            $oauthClient[$_client_list['id']] = $_client_list;
                        }
                        else
                        {
                            $testClient[$_client_list['id']] = $_client_list;
                        }
                    }
                    $tpl_data['testClient'] = $testClient;
                    //print_r($testClient);
                    $tpl_data['oauthClient'] = $oauthClient;
                }
            }
        }

        if($tpl_data['user']['is_dev'] == 1)
        {
            $this->load->view('home/dev_index', $tpl_data);
        }
        else
        {
            //公告
            $this->load->model('affiche_model');
            $tpl_data['affiche_list'] = $this->affiche_model->where('status=1 and (type=0 or type=1)')->limit(6,0)->order_by('top desc,id desc')->find_all();
            //print_r($tpl_data['affiche_list']);exit;

            //查询应用类别
            $this->load->model('app_cate_model', 'app_cate');
            $cate_options = array(
                'select' => 'id, name, icon',
            );
            $tpl_data['cate_list'] = $this->app_cate->find_all($cate_options);

            //获取当前用户桌面app列表
            $app_list = $this->model_app->get_user_apps(User::$user_id, 1);
            $new_app_list = array();
            if (!empty($app_list)) {
                //重构app列表
                foreach($app_list as $app) {
                    if (!isset($new_app_list[$app['cate_id']])) {
                        $new_app_list[$app['cate_id']] = array();
                    }
                    $new_app_list[$app['cate_id']][] = $app;
                }
            }
            $tpl_data['app_list'] = $new_app_list;
            //echo json_encode($new_app_list);exit;
            $tpl_data['old_app_list'] = $this->model_app->get_user_old_apps(User::$user_id, 1);

            //获取用户开放平台应用列表
            $this->load->model('site_client_model');
            $tpl_data['client_list'] = $this->site_client_model->get_user_clients(User::$user_id);
            $tpl_data['client_list'] = $tpl_data['client_list'] ? $tpl_data['client_list'] : array();

            if($user['free_trial'] == 1) {
                $this->load->model('free_trial_model');
                $tpl_data['free_trial'] = $this->free_trial_model->where(array('username'=>$user['username']))->find();
            }
            $this->load->view('home/index', $tpl_data);
        }
    }

    public function app_loading()
    {
        $this->load->view('home/app_loading');
    }

    /**
     * POST给应用的数据
     */
    public function app_signed_request()
    {
        $this->load->model('oauth_client_model');
        $this->load->model('site_client_model');
        $data = array();
        $payload = array(
            'algorithm' => 'HMAC-SHA256',
            'issued_at' => time(),
            'site_id' => User::$user_id
        );
        $app_id = intval($this->input->get('app_id'));
        if (!$client = $this->oauth_client_model->where(array('id'=>$app_id, 'deleted'=>0))->find()) {
            $this->response_error('100001', 'app not such!');
        }
        //是否已购买
        if ($this->site_client_model->where(array('client_id'=>$app_id, 'site_id'=>User::$user_id))->find()) {
            $this->load->library('wbcurl');
            $response = $this->wbcurl->simple_post(WB_API_URL.'/oauth2/access_token', array(
                'grant_type' => 'client_credential',
                'site_id' => User::$user_id,
                'client_id' => $client['id'],
                'client_secret' => $client['secret'],
            ));
            //$this->wbcurl->debug();
            $response = json_decode($response, TRUE);

            if (isset($response['error'])) {
                $this->response_error('100002', 'get access token faild!');
            }
            $payload['expires'] = time()+$response['expires_in'];
            $payload['oauth_token'] = $response['access_token'];
            $payload['refresh_token'] = $response['refresh_token'];
            $data['signed_request'] = $this->make_signed_request($payload, $client['secret']);
            $this->response($data);
        } else {
            //查询是否有开发测试\上线应用
            $this->load->model('developer_bind_model');
            $bind = $this->developer_bind_model->get_user_bind_developer_id(User::$user_id);
            $oauth_client_list = $this->oauth_client_model->where(array('developer_id' => $bind['developer_id'], 'id' => $app_id, 'deleted'=>0))->find();
            if ($oauth_client_list) {
                $this->load->library('wbcurl');
                $response = $this->wbcurl->simple_post(WB_API_URL.'/oauth2/access_token', array(
                    'grant_type' => 'client_credential',
                    'site_id' => User::$user_id,
                    'client_id' => $oauth_client_list['id'],
                    'client_secret' => $oauth_client_list['secret'],
                ));
                //$this->wbcurl->debug();
                $response = json_decode($response, TRUE);

                if (isset($response['error'])) {
                    $this->response_error('100002', 'get access token faild!');
                }
                $payload['expires'] = time()+$response['expires_in'];
                $payload['oauth_token'] = $response['access_token'];
                $payload['refresh_token'] = $response['refresh_token'];
                $data['signed_request'] = $this->make_signed_request($payload, $client['secret']);
                $this->response($data);
            } else {
                $this->response_error('100003', 'no purchase!');
            }
        }
    }

    /**
     * 试用
     */
    public function trial_client()
    {
        $client_id = intval($this->input->get('app_id'));
        $this->load->model('oauth_client_model');
        $this->load->model('site_client_model');
        if (!$client = $this->oauth_client_model->where(array('id'=>$client_id, 'status'=>2, 'deleted'=>0))->find()) {
            $this->response_error('100001', 'app not such!');
        }
        if ($client['trial_day']<=0) {
            $this->response_error('100005', 'app does not support the trial!');
        }
        if (!$this->site_client_model->where(array('client_id'=>$client_id, 'site_id'=>User::$user_id))->find()) {
            $this->site_client_model->add(array(
                'site_id' => User::$user_id,
                'client_id' => $client_id,
                'type' => 0,
                'expires' => time() + 3600*24*$client['trial_day'],
            ));
            $this->response(true);
        } else {
            $this->response_error('100006', 'activationed or trialing!');
        }
    }

    /**
     * 激活
     */
    public function activation_client()
    {
        $this->load->model('oauth_client_model');
        $this->load->model('site_client_model');
        $this->load->model('client_activation_model');
        $client_id = intval($this->input->get('app_id'));
        $activation = trim($this->input->get('activation'));
        if (!$client = $this->oauth_client_model->where(array('id'=>$client_id, 'status'=>2, 'deleted'=>0))->find()) {
            $this->response_error('100001', 'app not such!');
        }
        if ($activation_row = $this->client_activation_model->where(array(
            'client_id'=>$client_id,
            'activation'=>$activation,
            'used' => 0
        ))->find()) {
            if ($this->site_client_model->add(array(
                'site_id' => User::$user_id,
                'client_id' => $client_id,
                'type' => 1,
                'expires' => time() + 3600*24*365,
            ))) {
                $this->client_activation_model->where(array('id'=>$activation_row['id']))->edit(array('used'=>time(),'site_id'=>User::$user_id));
            }
            $this->response(true);
        } else {
            $this->response_error('100004', 'activation invalid!');
        }
    }

    public static function make_signed_request(array $payload, $app_secret)
    {
        $payload['algorithm'] = 'HMAC-SHA256';
        $payload['issued_at'] = time();
        $encoded_payload = static::base64_url_encode(json_encode($payload));
        $hashed_sig = static::hash_signature($encoded_payload, $app_secret);
        $encoded_sig = static::base64_url_encode($hashed_sig);
        return $encoded_sig.'.'.$encoded_payload;
    }

    public static function base64_url_encode($input)
    {
        return strtr(base64_encode($input), '+/', '-_');
    }

    public static function hash_signature($encoded_data, $app_secret)
    {
        return hash_hmac(
            'sha256', $encoded_data, $app_secret, $raw_output = true
        );
    }



}