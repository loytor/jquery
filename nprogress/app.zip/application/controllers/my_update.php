<?php defined('BASEPATH') OR exit('No direct script access allowed');

class My_update extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('model_article');
		$this->load->model('model_cate');
        $this->load->model('model_cate_lists');
	}
	
	public function index() {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			$this->show_message(FALSE, '请先登录', '/auth/login');
		}
		$acs = $this->model_article->get_all(array('type' => 'contact'), 1000, 0);
		//print_r($acs);
		
		foreach($acs as $ac){
			$content = json_decode($ac['content'], TRUE);
			$depth = $this->array_depth($content);
			$new_content_arr = array();
			if($depth == 1){
				$tels = explode('<br />',nl2br($content['tel']));
				foreach($tels as &$tel){
					$tel = trim($tel);
				}
				$new_content_arr[0]['no'] = -1;
				$new_content_arr[0]['address'] = $content['address'];
				$new_content_arr[0]['tels'] = $tels;
				$new_content = json_encode($new_content_arr);
				if($this->model_article->update(array('id'=>$ac['id'], 'type'=>'contact'), array('content'=>$new_content))){
					echo 'success, '.$ac['id'];
					echo '<br />';
				}else{
					echo 'failure, '.$ac['id'];
					echo '<br />';
				}
			}else{
				echo '没有什么好更新的';
			}
		}
	}
	
	private function array_depth($array) {
		$max_depth = 1;
	
		foreach ($array as $value) {
			if (is_array($value)) {
				$depth = $this->array_depth($value) + 1;
	
				if ($depth > $max_depth) {
					$max_depth = $depth;
				}
			}
		}
		return $max_depth;
	}	
}