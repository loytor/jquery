<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Class Reply
 * @property Model_reply $model_reply
 * @property Model_cate $model_cate
 * @property Model_article $model_article
 * @property Model_marketing $model_marketing
 * @property Model_vipcard $model_vipcard
 * @property Model_game $model_game
 */
class Reply extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('model_reply');
		$this->load->model('model_article');
		$this->load->model('model_marketing');
		$this->load->model('model_cate');
		$this->load->model('model_vipcard');
		$this->load->model('model_game');
	}

	public function index() {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$where_set = array('user_id' => $logged_user_id);
		$this->load->library('pagination');
		$pagination_config = array(
			'base_url'		=> '/reply/index/',
			'total_rows'	=> $this->model_reply->total_rows($where_set),
			'per_page'		=> 8,
			'uri_segment'	=> 3,
		);
		$this->pagination->initialize($pagination_config);
		$tpl_data['pagination'] = $this->pagination->create_links();
		$reply_arr = $this->model_reply->get_all($where_set, $pagination_config['per_page'], intval($this->uri->segment($pagination_config['uri_segment'], 1)));
		foreach ($reply_arr as $key=>&$_reply) {
			$_reply['keyword'] = str_replace(',', ' ', $_reply['keyword']);
			if ($_reply['type'] == 'article') {
				$_article_arr = json_decode($_reply['content'], TRUE);
                if($_article_arr){
                    $_reply['count_article'] = count($_article_arr);
	                $first_article =  array_shift($_article_arr);
    				$_reply['content'] = $first_article['title'];
                }
			}
			if ($_reply['type'] == 'marketing') {
				$_marketing_arr = json_decode($_reply['content'], TRUE);
				$_reply['count_marketing'] = count($_marketing_arr);
				$first_marketting =  array_shift($_marketing_arr);
				$_reply['content'] = $first_marketting['title'];
			}
			if ($_reply['type'] == 'marketing_vote_text') {//文字版投票
				$_marketing_vote_text = json_decode($_reply['content'], TRUE);
				$first_marketing_vote_text = array_shift($_marketing_vote_text);
				$_reply['content'] = $first_marketing_vote_text['title'];
			}
			if ($_reply['type'] == 'vipcard') {//会员卡
				$_reply['content'] = '';
			}
			if ($_reply['type'] == 'game') {
				$_reply['count_game'] = count((array)json_decode($_reply['content'], TRUE));
				$content = json_decode($_reply['content'], TRUE);
				if($content)
				{
					$first_game =  array_shift($content);
					$_reply['content'] = $first_game['title'];
				}
			}
			if ($_reply['type'] == 'cate') {
				$_article_arr = json_decode($_reply['content'], TRUE);

				if($_article_arr){
					$_reply['count_article'] = count($_article_arr);
					$first_article =  array_shift($_article_arr);
					$_reply['content'] = $first_article['title'];
				}
			}
			if($_reply['type'] == 'music')
			{
				$content = json_decode($_reply['content'], TRUE);
				$_reply['content'] = $content['title'];

			}
		    if($_reply['type'] == 'emigrated')
            {
                $content = json_decode($_reply['content'], TRUE);
                $_reply['content'] = $content['title'].' '.$content['url'];

            }
		    if($_reply['type'] == 'forward')
            {
                $content = json_decode($_reply['content'], TRUE);
                $_reply['content'] = $content['title'].' '.$content['url'];
                $_reply['content_id'] = $content['id'];
            }
		}
		$tpl_data['reply_arr'] = $reply_arr;
		$tpl_data['cur_nav'] = 'reply';
		$this->twig->display('reply/index', $tpl_data);
	}

	public function add() {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$type = $this->input->post('type');
		$this->load->library('form_validation');
		$this->load->helper('form');
		if($type == ''){
			$this->form_validation->set_rules('text-keyword', '关键词', 'trim|required|max_length[255]|htmlspecialchars');
		}
		elseif($type == 'article'){
			$this->form_validation->set_rules('article-keyword', '关键词', 'trim|required|max_length[255]|htmlspecialchars');
		}
		elseif($type == 'marketing'){
			$this->form_validation->set_rules('marketing-keyword', '关键词', 'trim|required|max_length[255]|htmlspecialchars');
		}
		elseif($type == 'game'){
			$this->form_validation->set_rules('game-keyword', '关键词', 'trim|required|max_length[255]|htmlspecialchars');
		}

		if ($this->form_validation->run()) {
			$data_set['user_id'] = $logged_user_id;			
			
			if($type == '') { //文字
				$data_set['keyword'] = $this->form_validation->set_value('text-keyword');
				$keyword_arr = explode(' ', $data_set['keyword']);
				foreach($keyword_arr as &$keyword){
					$keyword = trim($keyword);
				}
				$data_set['keyword'] = implode(',', $keyword_arr);
				
				$content = $this->input->post('content');
				if (empty($content)) {
					$this->show_message(FALSE, '请填写回复内容', '/reply/add');
				}

				$data_set['content'] = $content;
				$data_set['type'] = '';
				$this->model_reply->add($data_set);
			}
			elseif($type == 'article') { //文章
				$data_set['keyword'] = $this->form_validation->set_value('article-keyword');
				$keyword_arr = explode(' ', $data_set['keyword']);
				foreach($keyword_arr as &$keyword){
					$keyword = trim($keyword);
				}
				$data_set['keyword'] = implode(',', $keyword_arr);
				
				$article_arr = array();
				$_articles = $this->input->post('articles');
				if (is_array($_articles) AND ! empty($_articles)) {
					foreach ($_articles as $article_id => $rank) {
						$_articles[$article_id] = empty($rank) ? 99999 : intval($rank);
					}
					asort($_articles);
					foreach ($_articles as $article_id => $rank) {
						$_article = $this->model_article->get_row(array('id' => $article_id, 'user_id' => $logged_user_id), 'id, type, title, url, description, image');
						if ($_article) {
							$_article['rank'] = $rank;
							$article_arr[] = $_article;
						}
					}
				}

				if (empty($content) AND empty($article_arr)) {
					$this->show_message(FALSE, '至少选择一种回复方式', '/reply/add');
				}
				$data_set['content'] = json_encode($article_arr);
				$data_set['type'] = 'article';
				$reply_id = $this->model_reply->add($data_set);
				if ($reply_id AND ! empty($article_arr)) {
					foreach ($article_arr as $_article) {
						$this->model_reply->article_add($reply_id, $_article['id'], $_article['rank']);
					}
				}
			}
			elseif($type == 'marketing') { //活动
				$data_set['keyword'] = $this->form_validation->set_value('marketing-keyword');
				$keyword_arr = explode(' ', $data_set['keyword']);
				foreach($keyword_arr as &$keyword){
					$keyword = trim($keyword);
				}
				$data_set['keyword'] = implode(',', $keyword_arr);
				
				$marketing_arr = array();
				$_marketings= $this->input->post('marketings');
                
				if (is_array($_marketings) AND !empty($_marketings)) {
					foreach ($_marketings as $marketing_id => $m) {
						$_marketings[$marketing_id]['rank'] = empty($m['rank']) ? 99999 : intval($m['rank']);
					}
					asort($_marketings);
					foreach ($_marketings as $marketing_id => $m) {
						$_marketing = $this->model_marketing->get_marketing(array('id' => $marketing_id, 'user_id' => $logged_user_id), $m['type'],'id, type, title, description, image_start');
						if ($_marketing) {
							$_marketing['rank'] = $m['rank'];
							$marketing_arr[] = $_marketing;
						}
					}
				}

				if (empty($content) AND empty($marketing_arr)) {
					$this->show_message(FALSE, '至少选择一种回复方式', '/reply/add');
				}
				$data_set['content'] = json_encode($marketing_arr);
				$data_set['type'] = 'marketing';
				$reply_id = $this->model_reply->add($data_set);
				if ($reply_id AND ! empty($marketing_arr)) {
					foreach ($marketing_arr as $_marketing) {
						$this->model_reply->marketing_add($reply_id, $_marketing['id'], $_marketing['rank']);
					}
				}
			}
			elseif ($type == 'game') {
				$keyword = $this->form_validation->set_value('game-keyword');
				$keyword = explode(' ', $keyword);
				foreach ($keyword as &$v) {
					$v = trim($v);
				}
				$data_set['keyword'] = implode(',', $keyword);

				$data = array();
				$game= $this->input->post('game');

				if (is_array($game) AND !empty($game)) {
					foreach ($game as $id => $m) {
						$game[$id]['rank'] = empty($m['rank']) ? 99999 : intval($m['rank']);
					}
					asort($game);
					foreach ($game as $id => $m) {
						$row = $this->model_game->get_row(array('id' => $id, 'wid' => $logged_user_id), 'id, title, desc, cover_img');
						if ($row) {
							$cover_img = json_decode($row['cover_img'], true);
							unset($row['cover_img']);
							$row['image_start'] = $cover_img['image_start'];
							$row['rank'] = $m['rank'];
							$data[] = $row;
						}
					}
				}

				if (empty($content) AND empty($data)) {
					$this->show_message(FALSE, '至少选择一种回复方式', '/reply/add');
				}
				$data_set['content'] = json_encode($data);
				$data_set['type'] = 'game';
				$this->model_reply->add($data_set);
			}
			$this->show_message(TRUE, '添加成功', '/reply');
		}
		else {
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/reply/add');
			}
		}
		$cate_arr = array();
		$_cate_arr = $this->model_cate->get_all(array('user_id' => $logged_user_id), 100, 1);
		foreach ($_cate_arr as $_cate) {
			$cate_arr[$_cate['id']] = $_cate;
		}
		$tpl_data['cate_arr'] = $cate_arr;
		$tpl_data['cur_nav'] = 'reply';
		$this->twig->display('reply/add', $tpl_data);
	}

	public function update($reply_id = '') {

		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$reply = $this->model_reply->get_row(array('id' => $reply_id, 'user_id' => $logged_user_id));

		if ( ! $reply) {
			$this->show_message(FALSE, '找不到自定义回复', '/reply');
		}
		if ($reply['keyword'] == '__default__') {
			redirect('/reply/setting');
		}

		$reply['keyword'] = str_replace(',', ' ', $reply['keyword']);
		$tpl_data['reply'] = $reply;
		$this->load->library('form_validation');
		$this->form_validation->set_rules('keyword', '关键词', 'trim|required|max_length[255]|htmlspecialchars');
		if ($this->form_validation->run()) {
			if( $reply['type'] == '' ){
				$content = $this->input->post('content');
				if (empty($content)) {
					$this->show_message(FALSE, '请填写回复', '/reply/update/'.$reply['id']);
				}
				$data_set['content'] = $content;
				$data_set['type'] = '';
			}
			elseif( $reply['type'] == 'article') {
				$article_arr = array();
				$_articles = $this->input->post('articles');
				if (is_array($_articles) AND ! empty($_articles)) {
					foreach ($_articles as $article_id => $rank) {
						$_articles[$article_id] = empty($rank) ? 99999 : intval($rank);
					}
					asort($_articles);
					foreach ($_articles as $article_id => $rank) {
						$_article = $this->model_article->get_row(array('id' => $article_id, 'user_id' => $logged_user_id), 'id, type, title, url, description, image');
						if ($_article) {
							$_article['rank'] = $rank;
							$article_arr[] = $_article;
						}
					}
				}
				if (empty($article_arr)) {
					$this->show_message(FALSE, '至少选择一种回复图文', '/reply/update/'.$reply['id']);
				}
				
				$data_set['content'] = json_encode($article_arr);
				$data_set['type'] = 'article';
			}
			elseif($reply['type'] == 'cate')
			{
				$r_cate = $this->input->post('r_cate');
				if($r_cate)
				{
					foreach($r_cate as $id => $r)
					{
						$r_cate[$id] = empty($r) ? 99 : intval($r);
					}
					asort($r_cate);
					foreach ($r_cate as $id => $rank) {
						$cateInfo = $this->model_cate->get_row(array('id'=>$id,'user_id' => $logged_user_id),'id, cate_name, url,description, image');
						if($cateInfo)
						{
							$cateInfo['rank'] = $rank;
							$cateInfo['title'] = $cateInfo['cate_name'];
							unset($cateInfo['cate_name']);
							$cateArr[] = $cateInfo;
						}
					}

					$data_set['content'] = json_encode($cateArr);
				}
			}
			elseif($reply['type'] == 'music')
			{
				$content['title'] = $this->input->post('title');
				$content['musicurl'] = $this->input->post('musicurl');
				//$content['HQmusicurl'] = $this->input->post('HQmusicurl');
				$content['HQmusicurl'] = $content['musicurl'];
				$content['description'] = $this->input->post('description');
				$data_set['content'] = json_encode($content);
			}
			elseif( $reply['type'] == 'marketing') {
				$marketing_arr = array();
				$_marketings = $this->input->post('marketings');
				if (is_array($_marketings) AND ! empty($_marketings)) {
					foreach ($_marketings as $marketing_id => $m) {
						$_marketings[$marketing_id]['rank'] = empty($m['rank']) ? 99999 : intval($m['rank']);
					}
					asort($_marketings);
					foreach ($_marketings as $marketing_id => $m) {
						$_marketing = $this->model_marketing->get_marketing(array('id' => $marketing_id, 'user_id' => $logged_user_id), $m['type'], 'id, type, title, description, image_start');
						if ($_marketing) {
							$_marketing['rank'] = $m['rank'];
							$marketing_arr[] = $_marketing;
						}
					}
				}
				if (empty($marketing_arr)) {
					$this->show_message(FALSE, '至少选择一种回复活动', '/reply/update/'.$reply['id']);
				}
				
				$data_set['content'] = json_encode($marketing_arr);
				$data_set['type'] = 'marketing';
			}elseif( $reply['type'] == 'marketing_vote_text') {
				$instruction = $this->input->post('content');
				$content = json_decode($reply['content'], TRUE);
				$content = $content[0];
				if($content)
				{
					$content['title'] = $instruction;
					$content['instruction'] = $instruction;
				}
				$new_content[0] = $content;
				$data_set['content'] = json_encode($new_content);
			}
			elseif ($reply['type'] == 'game') {

				$data = array();
				$game= $this->input->post('game');

				if (is_array($game) AND !empty($game)) {
					foreach ($game as $id => $m) {
						$game[$id]['rank'] = empty($m['rank']) ? 99999 : intval($m['rank']);
					}
					asort($game);
					foreach ($game as $id => $m) {
						$row = $this->model_game->get_row(array('id' => $id, 'wid' => $logged_user_id), 'id, title, desc, cover_img');
						if ($row) {
							$cover_img = json_decode($row['cover_img'], true);
							unset($row['cover_img']);
							$row['image_start'] = $cover_img['image_start'];
							$row['rank'] = $m['rank'];
							$data[] = $row;
						}
					}
				}

				if (empty($content) AND empty($data)) {
					$this->show_message(FALSE, '至少选择一种回复方式', '/reply/add');
				}
				$data_set['content'] = json_encode($data);
				$data_set['type'] = 'game';
			}

			//$data_set['user_id'] = $logged_user_id;
			$data_set['keyword'] = $this->form_validation->set_value('keyword');
			$keyword_arr = explode(' ', $data_set['keyword']);
		    foreach($keyword_arr as $key=>&$keyword){
                if( !$keyword ){
                    unset($keyword_arr[$key]);
                }
            }
			$data_set['keyword'] = implode(',', $keyword_arr);

			$this->model_reply->update($reply['id'], $data_set);
			
			if ($reply['type'] == 'article') {
				$this->model_reply->article_delete($reply['id']);
				if (! empty($article_arr)) {
					foreach ($article_arr as $_article) {
						$this->model_reply->article_add($reply['id'], $_article['id'], $_article['rank']);
					}
				}
			}
			elseif($reply['type'] == 'marketing') {
				$this->model_reply->marketing_delete($reply['id']);
				if (! empty($marketing_arr)) {
					foreach ($marketing_arr as $_marketing) {
						$this->model_reply->marketing_add($reply['id'], $_marketing['id'], $_marketing['rank']);
					}
				}
			}
			elseif( $reply['type'] == 'emigrated' ){
			    $content = json_decode($reply['content'],true);
			    $emigrated_id = $content['id'];
			    $this->load->model('model_emigrated');
			    $this->model_emigrated->update(array('id'=>$emigrated_id),array('keyword'=>str_replace(',', ' ', $data_set['keyword'])));
			}

			$this->show_message(TRUE, '更新成功', '/reply');
		}
		else {
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/reply/update/'.$reply['id']);
			}
		}

		if($reply['type'] == 'music' || $reply['type'] == 'cate')
		{
			$tpl_data['content'] = json_decode($reply['content'], true);

			$this->load->library('encrypt');
			$token_data = array('user_id' => $logged_user_id, 'time' => time());
			$tpl_data['token'] = $this->encrypt->encode(serialize($token_data));

			$this->twig->display('reply/'.$reply['type'], $tpl_data);
			exit;
		}
		if ($reply['type'] == 'article') {
			$article_arr = $this->model_reply->article_list($reply['id']);

			foreach ($article_arr as &$_article) {
				$_article['rank'] = $_article['article_rank'] == 99999 ? '' : $_article['article_rank'];
			}
			$tpl_data['article_arr'] = $article_arr;
		}

		if ($reply['type'] == 'marketing') {
			$marketing_arr = $this->model_reply->marketing_list($reply['id']);
			foreach ($marketing_arr as &$_marketing) {
				$_marketing['rank'] = $_marketing['rank'] == 99999 ? '' : $_marketing['rank'];
			}
			$tpl_data['marketing_arr'] = $marketing_arr;
		}

		if ($reply['type'] == 'marketing_vote_text') {
			$tpl_data['marketing_vote_text'] = json_decode($reply['content'], TRUE);
		}

		if($reply['type'] == 'vipcard') {
			$vipcard_id = $reply['content'];
			$tpl_data['vipcard'] = $this->model_vipcard->get_row(array('id'=>$vipcard_id));		
		}

		if ($reply['type'] == 'game') {
			$tpl_data['game_arr'] = json_decode($reply['content'], true);
		}

	    if ($reply['type'] == 'emigrated') {
            $tpl_data['content'] = json_decode($reply['content'], TRUE);
        }

		$cate_arr = array();
		$_cate_arr = $this->model_cate->get_all(array('user_id' => $logged_user_id), 100, 1);
		foreach ($_cate_arr as $_cate) {
			$cate_arr[$_cate['id']] = $_cate;
		}

		$tpl_data['cate_arr'] = $cate_arr;
		$tpl_data['cur_nav'] = 'reply';
		$this->twig->display('reply/update', $tpl_data);
	}

	public function delete($reply_id = '') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$reply = $this->model_reply->get_row(array('id' => $reply_id, 'user_id' => $logged_user_id));
		if ( ! $reply) {
			$this->show_message(FALSE, '找不到自定义回复', '/reply');
		}

	    if( $reply['type'] == 'emigrated' ){
            $content = json_decode($reply['content'],true);
            $emigrated_id = $content['id'];
            $this->load->model('model_emigrated');
            $this->model_emigrated->update(array('id'=>$emigrated_id),array('keyword'=>''));
            $this->model_reply->emigrated_delete($reply['id'],$emigrated_id);
	    }

		$this->model_reply->delete($reply['id']);
		$this->show_message(TRUE, '删除成功', '/reply');
	}

	public function cate()
	{
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}

		$this->load->library('form_validation');
		$this->form_validation->set_rules('keyword', '关键词', 'trim|required|max_length[255]|htmlspecialchars');
		if ($this->form_validation->run()) {
			$cateArr = array();
			$keyword = $this->form_validation->set_value('keyword');
			$reply = $this->input->post('r_cate');
			if($reply)
			{
				foreach($reply as $id => $r)
				{
					$reply[$id] = empty($r) ? 99 : intval($r);
				}
				asort($reply);
				foreach ($reply as $id => $rank) {
					$cateInfo = $this->model_cate->get_row(array('id'=>$id,'user_id' => $logged_user_id),'id, cate_name, url,description, image');
					if($cateInfo)
					{
						$cateInfo['rank'] = $rank;
						$cateInfo['title'] = $cateInfo['cate_name'];
						unset($cateInfo['cate_name']);
						if(empty($cateInfo['url']))
						{
							$cateInfo['url'] = '/cate?id='.$cateInfo['id'];
						}
						$cateArr[] = $cateInfo;
					}
				}
			}
			if($cateArr)
			{
				$data_set['keyword'] = $keyword;
				$data_set['content'] = json_encode($cateArr);
				$data_set['type'] = 'cate';
				$data_set['user_id'] = $logged_user_id;
				$this->model_reply->add($data_set);
				$this->show_message(FALSE, '添加成功', '/reply');
			}
			else
			{
				$this->show_message(FALSE, '添加失败', '/reply/cate');
			}
		}
		else {
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/reply/cate');
			}
		}
		$this->twig->display('reply/cate');
	}

	public function music()
	{
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}

		$this->load->library('form_validation');
		$this->form_validation->set_rules('keyword', '关键词', 'trim|required|max_length[255]|htmlspecialchars');
		$this->form_validation->set_rules('title', '音乐标题', 'trim|required|max_length[255]|htmlspecialchars');
		$this->form_validation->set_rules('musicurl', '音乐链接', 'trim|required|max_length[255]|htmlspecialchars');
		//$this->form_validation->set_rules('HQmusicurl', '音乐高品质链接', 'trim|required|max_length[255]|htmlspecialchars');
		$this->form_validation->set_rules('description', '音乐描述信息', 'trim|max_length[255]|htmlspecialchars');
		if ($this->form_validation->run()) {
			$content['title'] = $this->form_validation->set_value('title');
			$content['musicurl'] = $this->form_validation->set_value('musicurl');
			//$content['HQmusicurl'] = $this->form_validation->set_value('HQmusicurl');
			$content['HQmusicurl'] = $content['musicurl'];
			$content['description'] = $this->form_validation->set_value('description');
			$data_set['content'] = json_encode($content);

			$data_set['keyword'] = $this->form_validation->set_value('keyword');
			$data_set['type'] = 'music';
			$data_set['user_id'] = $logged_user_id;
			$this->model_reply->add($data_set);
			$this->show_message(FALSE, '添加成功', '/reply');
		}
		else
		{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/reply/music');
			}
		}
		$this->load->library('encrypt');
		$token_data = array('user_id' => $logged_user_id, 'time' => time());
		$tpl_data['token'] = $this->encrypt->encode(serialize($token_data));

		$this->twig->display('reply/music',$tpl_data);
	}
	public function setting() {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$tpl_data['reply'] = $reply = $this->model_reply->get_row(array('user_id' => $logged_user_id, 'keyword' => '__default__'));
		if ($this->input->post()) {
			$article_arr = array();
			$_articles = $this->input->post('articles');
			if (is_array($_articles) AND ! empty($_articles)) {
				foreach ($_articles as $article_id => $rank) {
					$_articles[$article_id] = empty($rank) ? 99999 : intval($rank);
				}
				asort($_articles);
				foreach ($_articles as $article_id => $rank) {
					$_article = $this->model_article->get_row(array('id' => $article_id, 'user_id' => $logged_user_id), 'id, type, title,url, description, image');
					if ($_article) {
						$_article['rank'] = $rank;
						$article_arr[] = $_article;
					}
				}
			}
			$content = $this->input->post('content');
			if (empty($content) AND empty($article_arr)) {
				$this->show_message(FALSE, '至少选择一种回复方式', '/reply/setting');
			}
			$data_set['user_id'] = $logged_user_id;
			$data_set['keyword'] = '__default__';
			if ( ! empty($article_arr)) {
				$data_set['content'] = json_encode($article_arr);
				$data_set['type'] = 'article';
			} else {
				$data_set['content'] = $content;
				$data_set['type'] = '';
			}
			if ($reply) {
				$this->model_reply->update($reply['id'], $data_set);
				if ($reply['type'] == 'article') {
					$this->model_reply->article_delete($reply['id']);
				}
				if (! empty($article_arr)) {
					foreach ($article_arr as $_article) {
						$this->model_reply->article_add($reply['id'], $_article['id'], $_article['rank']);
					}
				}
			} else {
				$reply_id = $this->model_reply->add($data_set);
				if ($reply_id AND ! empty($article_arr)) {
					foreach ($article_arr as $_article) {
						$this->model_reply->article_add($reply_id, $_article['id'], $_article['rank']);
					}
				}
			}
			$this->show_message(TRUE, '设置成功', '/reply');
		}
		if ($reply AND $reply['type'] == 'article') {
			$article_arr = $this->model_reply->article_list($reply['id']);
			foreach ($article_arr as &$_article) {
				$_article['rank'] = $_article['rank'] == 99999 ? '' : $_article['rank'];
			}
			$tpl_data['article_arr'] = $article_arr;
		}
		$cate_arr = array();
		$_cate_arr = $this->model_cate->get_all(array('user_id' => $logged_user_id), 100, 1);
		foreach ($_cate_arr as $_cate) {
			$cate_arr[$_cate['id']] = $_cate;
		}
		$tpl_data['cate_arr'] = $cate_arr;
		$tpl_data['cur_nav'] = 'reply';
		$this->twig->display('reply/setting', $tpl_data);
	}

	private function show_message($success, $message, $redirect) {
		if ($this->input->is_ajax_request()) {
			$data = array(
				'success'	=> $success ? 1 : 0,
				'message'	=> strip_tags($message),
			);
			header('Content-type: application/json');
			echo json_encode($data);
		} else {
			$tpl_data = array(
				'message'	=> $message,
				'redirect'	=> $redirect,
			);
			$this->twig->display('show_message', $tpl_data);
		}
		exit;
	}

}