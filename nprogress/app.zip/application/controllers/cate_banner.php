<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Cate_banner extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('model_cate_banner');
	}

	public function index() {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		
		$where_set = array('user_id' => $logged_user_id);
		$this->load->library('pagination');
		$pagination_config = array(
			'base_url'		=> '/cate_banner/index',
			'total_rows'	=> $this->model_cate_banner->total_rows($where_set),
			'per_page'		=> 8,
			'uri_segment'	=> 3,
		);
		$this->pagination->initialize($pagination_config);
		$tpl_data['pagination'] = $this->pagination->create_links();
		$cate_banner_arr = $this->model_cate_banner->get_all($where_set, $pagination_config['per_page'], intval($this->uri->segment($pagination_config['uri_segment'], 1)), 'rank', 'asc');
        foreach($cate_banner_arr as &$cate_banner){
            $cate_banner['url'] = htmlentities($cate_banner['url']);
        }
		$tpl_data['cate_banner_arr'] = $cate_banner_arr;
		$tpl_data['cur_nav'] = 'cate';
		$this->twig->display('cate_banner/index', $tpl_data);
	}

	public function add() {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}

		$this->load->library('form_validation');
		$this->load->helper('form');
		$this->form_validation->set_rules('title', '标题', 'trim|max_length[255]|htmlspecialchars');
		$this->form_validation->set_rules('url', '外部链接', 'trim');
		$this->form_validation->set_rules('image', '图片', 'trim|required|callback__check_image');
		if ($this->form_validation->run()) {
			$data_set['user_id'] = $logged_user_id;
			$data_set['title'] = $this->form_validation->set_value('title');
			$data_set['url'] = $this->form_validation->set_value('url');
			$data_set['image'] = $this->form_validation->set_value('image');
			$data_set['rank'] = $this->input->post('rank');
			$data_set['rank'] = $data_set['rank'] ? $data_set['rank'] : 99999;
			$this->model_cate_banner->add($data_set);
			$this->show_message(TRUE, '添加成功', '/cate_banner');
		} else {
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/cate_banner/add');
			}
		}
		$this->load->library('encrypt');
		$token_data = array('user_id' => $logged_user_id, 'time' => time());
		$tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
		$tpl_data['cur_nav'] = 'cate';
		$this->twig->display('cate_banner/add', $tpl_data);
	}

	public function update($cate_banner_id = '') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$cate_banner = $this->model_cate_banner->get_row(array('id' => $cate_banner_id, 'user_id' => $logged_user_id));
		if ( ! $cate_banner) {
			$this->show_message(FALSE, '找不到该广告', '/cate_banner');
		}
		$cate_banner['image_preview'] = image_url($cate_banner['image'], 640, 320);
		$tpl_data['cate_banner'] = $cate_banner;

		$this->load->library('form_validation');
		$this->load->helper('form');
		$this->form_validation->set_rules('title', '标题', 'trim|max_length[255]|htmlspecialchars');
		$this->form_validation->set_rules('url', '外部链接', 'trim');
		$this->form_validation->set_rules('image', '图片', 'trim|required|callback__check_image');
		if ($this->form_validation->run()) {
			$data_set['title'] = $this->form_validation->set_value('title');
			$data_set['url'] = $this->form_validation->set_value('url');
			$data_set['image'] = $this->form_validation->set_value('image');
			$data_set['rank'] = $this->input->post('rank');
			$data_set['rank'] = $data_set['rank'] ? $data_set['rank'] : 99999;
			$this->model_cate_banner->update($cate_banner_id, $data_set);

			$this->show_message(TRUE, '更新成功', '/cate_banner');
		} else {
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/cate_banner/update/'.$cate_banner_id);
			}
		}
		$this->load->library('encrypt');
		$token_data = array('user_id' => $logged_user_id, 'time' => time());
		$tpl_data['token'] = $this->encrypt->encode(serialize($token_data));
		$tpl_data['cur_nav'] = 'cate';
		$this->twig->display('cate_banner/update', $tpl_data);
	}

	public function delete($cate_banner_id = '') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			redirect_return('/auth/login');
		}
		$cate_banner = $this->model_cate_banner->get_row(array('id' => $cate_banner_id, 'user_id' => $logged_user_id));
		if ( ! $cate_banner) {
			$this->show_message(FALSE, '找不到该广告', '/cate_banner');
		}

		$this->model_cate_banner->delete($cate_banner_id);
		$this->show_message(TRUE, '删除成功', '/cate_banner');
	}

	public function update_rank($cate_banner_id = '') {
		$logged_user_id = logged_user_id();
		if ( ! $logged_user_id) {
			$this->show_message(FALSE, '请先登录', '/auth/login');
		}
		$cate_banner = $this->model_cate_banner->get_row(array('id' => $cate_banner_id, 'user_id' => $logged_user_id));
		if ( ! $cate_banner) {
			$this->show_message(FALSE, '找不到该广告', '/cate_banner');
		}
		$this->load->library('form_validation');
		$this->load->helper('form');
		$this->form_validation->set_rules('rank', '排序', 'trim');
		if ($this->form_validation->run()) {
			$rank = $this->form_validation->set_value('rank');
			$data_set['rank'] = $rank ? intval($rank) : 99999;
			$this->model_cate_banner->update($cate_banner_id, $data_set);
			$this->show_message(TRUE, '更新成功', '/cate_banner');
		} else {
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/cate_banner');
			}
		}
	}
		
	public function _check_image($image) {
		if ($image) {
			if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
				$this->form_validation->set_message('_check_image', '图片地址格式错误');
				return FALSE;
			}
		}
		return TRUE;
	}

    private function show_message($success, $message, $redirect) {
		if ($this->input->is_ajax_request()) {
			$data = array(
				'success'	=> $success ? 1 : 0,
				'message'	=> strip_tags($message),
			);
			header('Content-type: application/json');
			echo json_encode($data);
		} else {
			$tpl_data = array(
				'message'	=> $message,
				'redirect'	=> $redirect,
			);
			$this->twig->display('show_message', $tpl_data);
		}
		exit;
	}

}