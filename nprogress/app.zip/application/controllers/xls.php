<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Xls extends CI_Controller {

	public function __construct() {
		parent::__construct();
	}
    
    public function index(){
        
    }
    
    public function upload(){
        
        $this->load->library('encrypt');
		$token = trim($this->input->get_post('token', TRUE));
		$token_decoded = $this->encrypt->decode($token);
		if ( ! $token_decoded) {
			header('Content-type: application/json');
			echo json_encode(array('success' => 0, 'message' => '请通过正常途径上传'));
			exit;
		}
		$token_data = unserialize($token_decoded);
		if ( ! isset($token_data['time']) OR ! isset($token_data['user_id']) OR (time() - $token_data['time']) > 3600) {
			header('Content-type: application/json');
			echo json_encode(array('success' => 0, 'message' => '请通过正常途径上传'));
			exit;
		}
		$upload_config = array(
			'upload_path'	=> FCPATH.'images/'.$token_data['user_id'].'/',
			'allowed_types'	=> 'xls|xlsx',
			'max_size'		=> 1024 * 2,
			'encrypt_name'     => TRUE
		);
		$this->load->library('upload', $upload_config);
        
        if(!is_dir($upload_config['upload_path'])){
            mkdir($upload_config['upload_path'], 0777, TRUE);
        }
        
		if ( ! $this->upload->do_upload('userfile')) {
			header('Content-type: application/json');
			echo json_encode(array('success' => 0, 'message' => $this->upload->display_errors('', '')));
			exit;
		} else {
			$xlsinfo = $this->upload->data();
			
            $filePath = $xlsinfo['full_path'];
            
            $this->load->library('PHPExcel');
            
            /**默认用excel2007读取excel，若格式不对，则用之前的版本进行读取*/
            $PHPReader = new PHPExcel_Reader_Excel2007();
            
            if(!$PHPReader->canRead($filePath)){
                $PHPReader = new PHPExcel_Reader_Excel5();
                if(!$PHPReader->canRead($filePath)){
                    header('Content-type: application/json');
        			echo json_encode(array('success' => 0, 'message' => '读取xls出错'));
        			exit;
                }
            }
            $PHPExcel = $PHPReader->load($filePath);
        
            /**读取excel文件中的第一个工作表*/
            
            $currentSheet = $PHPExcel->getSheet(0);
            
            /**取得最大的列号*/
            
            $allColumn = $currentSheet->getHighestColumn();
            
            /**取得一共有多少行*/
            
            $allRow = $currentSheet->getHighestRow();
            
            
            $sheet = $PHPExcel->getSheet(0); // 读取第一个工作表从0读起
            $highestRow = $sheet->getHighestRow(); // 取得总行数
            $highestColumn = $sheet->getHighestColumn(); // 取得总列数
            
            // 根据自己的数据表的大小修改
            $arr = array(0=>'A',1=>'B',2=>'C');
            
            // 每次读取一行，再在行中循环每列的数值
            for ($row = 1; $row <= $highestRow; ++$row) {
                for ($column=0; $arr[$column] != 'C'; ++$column) {
                    $val = $sheet->getCellByColumnAndRow($column, $row)->getValue();
                    $list[$row-1][] = $val;
                }
            }
			header('Content-type: application/json');
			echo json_encode(array(
				'success'		=> 1,
				'data'			=> $list,
			));

            exit;
		}
	}

	public function marketing_vote()
	{
        header('Content-type: application/json');
        echo json_encode(array(
            'success'       => 1,
            'data'          => $this->get_file(),
        ));
        exit;
	}

    //答题闯关 系统题库
    public function exam_excel()
    {
        $exams = $this->get_file();

        $where_set = array(
            'wid'    => '',
            'day_id' => null
        );
        $this->load->model('model_emigrated_question');

        $data_set_exam = array();
        for( $i=1;$i<count($exams);$i++ ){
            //超过5000后不再保存
            $total = $this->model_emigrated_question->total_rows($where_set);
            if( $total+1>=5000 ){
                break;
            }

            $data_set_exam['title'] = $exams[$i][0];
            $data_set_exam['title_img'] = $exams[$i][1];
            $options = array();
            for( $k=2,$l=0;$k<count($exams[$i]);$k+=3 ){
                if( $exams[$i][$k] ){
                    $options[$l]['id'] = $l+1;
                    $options[$l]['title'] = $exams[$i][$k];
                    $options[$l]['title_img'] = $exams[$i][$k+1] ? $exams[$i][$k+1] : '';
                    $options[$l]['correct'] = intval($exams[$i][$k+2]);
                    $l++;
                }
            }
            $data_set_exam['options'] = json_encode($options);
            $data_set_exam['add_time'] = time();
            $this->model_emigrated_question->add($data_set_exam);
        }

        header('Content-type: application/json');
        echo json_encode(array(
            'success'       => 1,
            'msg'          => '导入成功',
        ));
        exit;
    }


    //读取excel文件，组成数组形式返回
    private function get_file()
    {
        $this->load->library('encrypt');
        $token = trim($this->input->get_post('token', TRUE));
        $token_decoded = $this->encrypt->decode($token);
        if ( ! $token_decoded) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => '请通过正常途径上传'));
            exit;
        }
        $token_data = unserialize($token_decoded);
        if ( ! isset($token_data['time']) OR ! isset($token_data['user_id']) OR (time() - $token_data['time']) > 3600) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => '请通过正常途径上传'));
            exit;
        }
        $upload_config = array(
            'upload_path'   => FCPATH.'images/'.$token_data['user_id'].'/',
            'allowed_types' => 'xls|xlsx',
            'max_size'      => 1024 * 2,
            'encrypt_name'     => TRUE
        );
        $this->load->library('upload', $upload_config);

        if(!is_dir($upload_config['upload_path'])){
            mkdir($upload_config['upload_path'], 0777, TRUE);
        }

        if ( ! $this->upload->do_upload('userfile')) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => $this->upload->display_errors('', '')));
            exit;
        } else {
            $file = $this->upload->data();
            $filePath = $file['full_path'];

            $this->load->library('PHPExcel');

            /**默认用excel2007读取excel，若格式不对，则用之前的版本进行读取*/
            $PHPReader = new PHPExcel_Reader_Excel2007();

            if(!$PHPReader->canRead($filePath)){
                $PHPReader = new PHPExcel_Reader_Excel5();
                if(!$PHPReader->canRead($filePath)){
                    header('Content-type: application/json');
                    echo json_encode(array('success' => 0, 'message' => '读取xls出错'));
                    exit;
                }
            }
            $PHPExcel = $PHPReader->load($filePath);

            /**读取excel文件中的第一个工作表*/

            $currentSheet = $PHPExcel->getSheet(0);

            $sheet = $PHPExcel->getSheet(0); //读取第一个工作表从0读起

            $content = $sheet->toArray();
            //删除上传文件
            unlink($filePath);

            return $content;
        }
    }

}