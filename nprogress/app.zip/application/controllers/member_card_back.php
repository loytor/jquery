<?php
/**
 * Created by JetBrains PhpStorm.
 * User: along
 * Date: 13-8-20
 * Time: 下午2:55
 * To change this template use File | Settings | File Templates.
 * @property Model_member_card $model_member_card
 * @property Model_member_user_card $modelObj
 * @property Model_account $model_account
 * @property Model_cate $model_cate
 * @property Model_cate_lists $model_cate_lists
 * @property Model_action_record $model_action_record
 * @property Model_user $model_user
 */

class Member_card extends MY_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('model_member_card');
		$this->load->model('model_member_user_card', 'modelObj');
		$this->load->model('model_action_record');
		$this->load->model('model_user');
	}

	/**
	 * 领取会员卡列表
	 */
	public function index()
	{
		$mobile = $this->input->get_post('mobile');
		$cardNum = $this->input->get_post('cardNum');
		$money = $this->input->get_post('money');
		$credit = $this->input->get_post('credit');
		$fromTime = $this->input->get_post('fromTime');
		$toTime = $this->input->get_post('toTime');

		$tpl['mobile'] = $mobile ? $mobile : '';
		$tpl['cardNum'] = $cardNum ? $cardNum : '';
		$tpl['money'] = $money ? $money : '';
		$tpl['credit'] = $credit ? $credit : '';
		$tpl['fromTime'] = $fromTime ? $fromTime : '';
		$tpl['toTime'] = $toTime ? $toTime : '';

		$this->load->model('model_account');
		//列表
		$where = array(
			'wid' => User::$user_id
		);
		//用于筛选过滤
		$qs = array();
		if($mobile)
		{
			$rows = $this->model_account->get_all(array('wid'=>User::$user_id, 'mobile'=>'like:'.$mobile));
			if($rows){
				foreach($rows as $r)
				{
					$where['in:uid'][] = $r['id'];
				}
			}
			else
			{
				$where['1'] = 2;
			}
			$qs[] = 'mobile='.$mobile;
		}
		if($cardNum)
		{
			$where['cardNum'] = 'like:'.$cardNum;
			$qs[] = 'cardNum='.$cardNum;
		}
		if($money)
		{
			$where['money'] = $money;
			$qs[] = 'money='.$money;
		}
		if($credit)
		{
			$where['credit'] = $credit;
			$qs[] = 'credit='.$credit;
		}
		if($fromTime)
		{
			$where['inputtime >= '] = strtotime($fromTime);
			$qs[] = 'fromTime='.$fromTime;
		}
		if($toTime)
		{
			$where['inputtime <= '] = strtotime($toTime);
			$qs[] = 'toTime='.$toTime;
		}

		$page = $this->input->get('per_page');
		$page = $page ? $page : self::CUR_PAGE;
		$queryStr = implode('&', $qs);
		$this->queryString = '?' . $queryStr;
		$this->pageQueryString = true;

		$list = $this->modelObj->get_all($where, $this->pageSize, $page);
		$whereUid = '';
		foreach ($list as &$row) {
			$row['inputtime'] = date('Y-m-d H:i:s', $row['inputtime']);
			$whereUid['in:id'][] = $row['uid'];
		}
		//查询用户
		$userList = array();
		if (!empty($whereUid)) {
			$rows = $this->model_account->get_all($whereUid);
			foreach ($rows as $rs) {
				$userList[$rs['id']] = $rs;
			}
		}

		$tpl['userList'] = $userList;
		$tpl['list'] = $list;
		$tpl['page'] = $page;
		$tpl['pages'] = $this->pages($this->modelObj->total_rows($where));

		$tpl['cur_nav'] = 'member_sys';
		$tpl['curtitle'] = '会员卡领取列表';
		$this->twig->display('member_card/cardlist', $tpl);
	}
	
	
    //检查图片格式
    public function _check_image($image) {
        if ($image) {
            if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
                $this->form_validation->set_message('_check_image', '图片地址格式错误');
                return FALSE;
            }
        }
        return TRUE;
    }
	
    
	/**
	 * 会员卡设置 
	 * 企业logo  会员卡背景图 260X140
	 */
	public function setting()
	{
		$tpl_data['cur_nav'] = 'member_sys';
		$tpl_data['card'] = '';

		//查询是否创建了会员卡
		$cardInfo = $this->checkCard();
		if(!$cardInfo)
		{
			$this->form_validation->set_rules('password', '交易密码', 'trim|required|is_natural|min_length[4]|max_length[8]');
		}
		//获取所有栏目
		$this->load->model('model_cate');
		$cate_arr = array();
		$_cate_arr = $this->model_cate->get_all(array('user_id' => User::$user_id));
		foreach ($_cate_arr as $_cate) {
			$cate_arr[$_cate['id']] = $_cate;
		}
		$tpl_data['cate_arr'] = $cate_arr;

		$this->form_validation->set_rules('cate_id', '栏目', 'trim');
		$this->form_validation->set_rules('prefix', '卡号前缀', 'trim|required');
		$this->form_validation->set_rules('name', '会员卡名', 'trim|required');
		$this->form_validation->set_rules('instruction', '特权说明', 'trim|required');
		$this->form_validation->set_rules('logo', '会员卡logo', 'trim|callback__check_image');
		$this->form_validation->set_rules('background', '会员卡背景图', 'trim|callback__check_image');
		if($this->form_validation->run())
		{
			$cate_id = $dataSet['cate_id'] = $this->form_validation->set_value('cate_id');
			$dataSet['prefix'] = $this->form_validation->set_value('prefix');
			$dataSet['name'] = $this->form_validation->set_value('name');
			$dataSet['instruction'] = $this->form_validation->set_value('instruction');
			$dataSet['logo'] = $this->form_validation->set_value('logo');
			$dataSet['background'] = $this->form_validation->set_value('background');
			$this->load->model('model_cate_lists');
			if($cardInfo)
			{
				$dataSet['id'] = $cardInfo['id'];
				//修改 判断是否有更新
				$doPos = 0;

				foreach($dataSet as $key=> $data)
				{
					if($cardInfo[$key] != $data)
					{
						$doPos = 1;
						break;
					}
				}
				if($doPos == 1)
				{
					if($this->model_member_card->update(array('wid'=>User::$user_id), $dataSet))
					{
						//更改cate_lists表的记录
						if ($cardInfo['cate_id'] != $cate_id) {
							if ($cate_id) {
								$this->model_cate->count_step($cate_id, 'count_vip', 1);
								$data_cate_lists['user_id'] = User::$user_id;
								$data_cate_lists['cate_id'] = $cate_id;
								$data_cate_lists['type'] = 'vip';
								$data_cate_lists['lists_id'] = $cardInfo['id'];
								$data_cate_lists['rank'] = 9999;
								$this->model_cate_lists->add($data_cate_lists);
							}
							if ($cardInfo['cate_id']) {
								$this->model_cate->count_step($cardInfo['cate_id'], 'count_marketing', -1);
								$del_data_cate_lists['user_id'] = User::$user_id;
								$del_data_cate_lists['cate_id'] = $cardInfo['cate_id'];
								$del_data_cate_lists['type'] = 'vip';
								$del_data_cate_lists['lists_id'] = $cardInfo['id'];
								$this->model_cate_lists->delete($del_data_cate_lists);
							}
						}
						$this->show_message(TRUE, '会员卡修改成功', '/member_card/setting');
					}
				}
				else
				{
					$this->show_message(TRUE, '会员卡修改成功', '/member_card/setting');
				}
			}
			else
			{
				//增加
				$dataSet['wid'] = User::$user_id;
				$dataSet['password'] = md5($this->form_validation->set_value('password'));
				$dataSet['dt_add'] = time();
				$new_card_id = $this->model_member_card->add($dataSet, TRUE);
				if($new_card_id)
				{
					$this->model_cate->count_step($cate_id, 'count_vip', 1);
					$data_cate_lists['user_id'] = User::$user_id;
					$data_cate_lists['cate_id'] = $cate_id;
					$data_cate_lists['type'] = 'vip';
					$data_cate_lists['lists_id'] = $new_card_id;
					$data_cate_lists['rank'] = 9999;
					$this->model_cate_lists->add($data_cate_lists);
					$this->show_message(TRUE, '会员卡创建成功', '/member_card/setting');
				}
				else
				{
					$this->show_message(FALSE, '会员卡创建出错', '/member_card/setting');
				}
			}
		}
		else
		{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/member_card/setting');
			}
		}

		$cardInfo = $cardInfo ? $cardInfo : array('cate_id'=>'');
		
		//token
		$this->load->library('encrypt');
        $tpl_data['token1'] = $this->encrypt->encode(serialize(array('user_id' => User::$user_id, 'time' => time())));
        $tpl_data['token2'] = $this->encrypt->encode(serialize(array('user_id' => User::$user_id, 'time' => time())));
		
		$tpl_data['card'] = $cardInfo;
		
		//会员卡背景选择
        $bg_arr = array(
            array('id'=>'bg00', 'img'=>image_url('http://c.bama555.com/assets/img/card_bg_default.png')),
            array('id'=>'bg01', 'img'=>image_url('http://c.bama555.com/assets/img/vipcard/vip-bg01.png')),
            array('id'=>'bg02', 'img'=>image_url('http://c.bama555.com/assets/img/vipcard/vip-bg02.png')),
            array('id'=>'bg03', 'img'=>image_url('http://c.bama555.com/assets/img/vipcard/vip-bg03.png')),
            array('id'=>'bg04', 'img'=>image_url('http://c.bama555.com/assets/img/vipcard/vip-bg04.png')),
            array('id'=>'bg05', 'img'=>image_url('http://c.bama555.com/assets/img/vipcard/vip-bg05.png')),
            array('id'=>'bg06', 'img'=>image_url('http://c.bama555.com/assets/img/vipcard/vip-bg06.png')),
            array('id'=>'bg07', 'img'=>image_url('http://c.bama555.com/assets/img/vipcard/vip-bg07.png')),
            array('id'=>'bg08', 'img'=>image_url('http://c.bama555.com/assets/img/vipcard/vip-bg08.png')),
            array('id'=>'bg09', 'img'=>image_url('http://c.bama555.com/assets/img/vipcard/vip-bg09.png')),
            array('id'=>'bg10', 'img'=>image_url('http://c.bama555.com/assets/img/vipcard/vip-bg10.png')),
            array('id'=>'custom','img'=>'')
        );
        if( isset($tpl_data['card']['background']) && $tpl_data['card']['background'] ){
            $flag = true;
            foreach( $bg_arr as $key=>$value ){
                if( $tpl_data['card']['background']==$value['img'] ){
                    $flag = false;break;
                }
            }
            $flag && $bg_arr[11] = array('id'=>'custom','img'=>image_url($tpl_data['card']['background']));
            $tpl_data['card']['sbackground'] = $tpl_data['card']['background'];
        }else{
            $tpl_data['card']['sbackground'] = $bg_arr[0]['img'];
        }
        $tpl_data['bg_arr'] = $bg_arr;
		
		$tpl_data['curtitle'] = '会员卡设置';
		$this->twig->display('member_card/setting',$tpl_data);
	}

	/**
	 * 重置密码
	 */
	public function setpwd()
	{
		$mc = $this->checkCard();
		if(!$mc)
		{
			$this->show_message(FALSE, '该会员卡不存在', '/member_card');
		}
		$mc_id = $mc['id'];
		$this->form_validation->set_rules('cur_pass', '当前密码', 'trim|required|is_natural|min_length[4]|max_length[8]|callback_check_curpass['.$mc_id.']');
		$this->form_validation->set_rules('password', '新密码', 'trim|required|is_natural|min_length[4]|max_length[8]');
		$this->form_validation->set_rules('conf_pass', '确认新密码', 'trim|required|is_natural|min_length[4]|max_length[8]|matches[password]');
		if($this->form_validation->run())
		{
			$data_set['password'] = md5($this->form_validation->set_value('password'));
			if($this->model_member_card->update(array('id'=>$mc_id), $data_set))
			{
				$this->show_message(TRUE, '重置交易密码成功', '/member_card/setpwd');
			}
			else
			{
				$this->show_message(FALSE, '重置交易密码失败', '/member_card/setpwd');
			}
		}
		else
		{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/member_card/setpwd');
			}
		}
		$tpl_data['cur_nav'] = 'member_sys';
		$tpl_data['curtitle'] = '交易密码重置';
		$this->twig->display('member_card/setpwd', $tpl_data);
	}

	/**
	 * 积分规则
	*/
	public function creditrule()
	{
		$mc = $this->checkCard();
		if(!$mc)
		{
			$this->show_message(FALSE, '该会员卡不存在', '/member_card');
		}
		$mc_id = $mc['id'];
		$tpl_data['rules'] = json_decode($mc['creditrule'], TRUE);

		$this->form_validation->set_rules('money[]', '金额', 'trim|is_natural_no_zero');
		$this->form_validation->set_rules('credit[]', '积分', 'trim|is_natural');
		if($this->form_validation->run())
		{
			$rule = array();
			$money = $this->input->post('money');
			$credit = $this->input->post('credit');
			foreach($money as $k=>$m)
			{
				$rule[$k]['money'] = $m;
			}
			foreach($credit as $ck=>$cd)
			{
				$rule[$ck]['credit'] = $cd;
			}
			$data_set['creditrule'] = json_encode($rule);
			if($this->model_member_card->update(array('id'=>$mc_id), $data_set))
			{
				$this->show_message(TRUE, '积分规则设置成功', '/member_card/creditrule');
			}
			else
			{
				$this->show_message(FALSE, '积分规则设置成功', '/member_card/creditrule');
			}
		}
		else
		{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/member_card/creditrule');
			}
		}

		$tpl_data['cur_nav'] = 'member_sys';
		$tpl_data['curtitle'] = '消费积分规则';
		$this->twig->display('member_card/creditrule', $tpl_data);
	}

	/**
	 * 转发积分规则
	 */
	public function forwardrule()
	{
		$mc = $this->checkCard();
		if(!$mc)
		{
			$this->show_message(FALSE, '该会员卡不存在', '/member_card');
		}

		$this->form_validation->set_rules('credit', '积分', 'trim|is_natural');
		$this->form_validation->set_rules('num', '转发次数', 'trim|is_natural');
		if($this->form_validation->run())
		{

			$forwardrule['forward']['credit'] = $this->form_validation->set_value('credit');
			$forwardrule['forward']['num'] = $this->form_validation->set_value('num');
			$dataSet['getcreditrule'] = json_encode($forwardrule);
			if($this->model_member_card->update(array('id'=>$mc['id']), $dataSet))
			{
				$this->show_message(TRUE, '转发积分规则设置成功', '/member_card/forwardrule');
			}
			else
			{
				$this->show_message(FALSE, '转发积分规则设置失败', '/member_card/forwardrule');
			}
		}
		else
		{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/member_card/forwardrule');
			}
		}

		$tpl_data['forwadrule'] = json_decode($mc['getcreditrule'], TRUE);

		$tpl_data['cur_nav'] = 'member_sys';
		$tpl_data['curtitle'] = '转发积分规则';
		$this->twig->display('member_card/forwardrule', $tpl_data);
	}

	/**
	 * name 增加会员卡积分
	 * @param string $id
	 */
	public function addcardcredit($id='')
	{
		$userCardInfo = $this->modelObj->get_row(array('id'=>$id));

		//是否是当前商家的会员卡
		if(!$userCardInfo || $userCardInfo['wid'] != User::$user_id)
		{
			$this->show_message(FALSE, '当前用户会员卡不存在', '/member_card');
		}
		$this->form_validation->set_rules('password', '交易密码', 'trim|required|is_natural|callback_check_curpass['.$userCardInfo['cardId'].']');
		$this->form_validation->set_rules('credit', '积分', 'trim|is_natural|less_than[100000000]');

		if($this->form_validation->run())
		{
			$data_set['credit'] = (int)$this->form_validation->set_value('credit') + $userCardInfo['credit'];

			if($this->modelObj->update(array('id'=>$id), $data_set))
			{
				//添加积分类商家增加行为scope=2, type=0, sub_type=0
				$action_data = array();
				$action_data['scope'] = 2;
				$action_data['type'] = 0;
				$action_data['sub_type'] = 0;
				$action_data['uid'] = $userCardInfo['uid'];
				$action_data['value'] = (int)$this->form_validation->set_value('credit');
				$this->action_record($action_data);

				$this->show_message(TRUE, '增加积分成功', '/member_card');
			}
			else
			{
				$this->show_message(FALSE, '增加积分失败', '/member_card/addcardcredit/'.$id);
			}
		}
		else
		{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/member_card/addcardcredit/'.$id);
			}
		}

		$tpl_data['cur_nav'] = 'member_sys';
		$tpl_data['curtitle'] = '增加积分';
		$this->twig->display('member_card/addcardcredit', $tpl_data);
	}

	/**
	 * 给会员卡充值
	 * @param string $id
	 */
	public function addmoney($id='')
	{
		$userCardInfo = $this->modelObj->get_row(array('id'=>$id));

		//是否是当前商家的会员卡
		if(!$userCardInfo || $userCardInfo['wid'] != User::$user_id)
		{
			$this->show_message(FALSE, '当前用户会员卡不存在', '/member_card');
		}
		$this->form_validation->set_rules('password', '交易密码', 'trim|required|is_natural|callback_check_curpass['.$userCardInfo['cardId'].']');
		$this->form_validation->set_rules('money', '充值金额', 'trim|is_natural|less_than[10000000]');

		if($this->form_validation->run())
		{
			$data_set['money'] = (int)$this->form_validation->set_value('money') + $userCardInfo['money'];
			//$data_set['money'] = (int)$data_set['money'] + $userCardInfo['money'];

			if($this->modelObj->update(array('id'=>$id), $data_set))
			{
				//添加消费类充值行为scope=1, type=0, sub_type=0
				$action_data = array();
				$action_data['scope'] = 1;
				$action_data['type'] = 0;
				$action_data['sub_type'] = 0;
				$action_data['uid'] = $userCardInfo['uid'];
				$action_data['value'] = (int)$this->form_validation->set_value('money');
				$this->action_record($action_data);

				$this->show_message(TRUE, '充值成功', '/member_card');
			}
			else
			{
				$this->show_message(FALSE, '充值失败', '/member_card/addmoney/'.$id);
			}
		}
		else
		{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/member_card/addmoney/'.$id);
			}
		}

		$tpl_data['cur_nav'] = 'member_sys';
		$tpl_data['curtitle'] = '充值';
		$this->twig->display('member_card/addmoney', $tpl_data);
	}

	/**
	 * @param string $uid
	 * @param int $page
	 * 消费记录
	 */
	public function consumerecord($uid='')
	{
		$tpl_data['uid'] = $uid;

		$this->load->config('action_record');
		$config_action_record = $this->config->item('action_record');
		$consume_type_arr = $this->config->item('consume_type');

		$action_type = $this->input->get_post('action_type');
		$value = $this->input->get_post('value');
		$memo = $this->input->get_post('memo');
		$from_time = $this->input->get_post('from_time');
		$to_time = $this->input->get_post('to_time');

		$tpl_data['action_type'] = $action_type ? $action_type : '';
		$tpl_data['value'] = $value ? $value : '';
		$tpl_data['memo'] = $memo ? $memo : '';
		$tpl_data['from_time'] = $from_time ? $from_time : '';
		$tpl_data['to_time'] = $to_time ? $to_time : '';

		//scope=1，消费类
		$where = array('uid'=>$uid, 'wid'=>User::$user_id, 'scope'=>1);
		$qs = array();
		if($action_type)
		{
			$action_type_arr = explode('_', $action_type);
			$where['type'] = $action_type_arr[0];
			$where['sub_type'] = $action_type_arr[1];
			$qs[] = 'action_type='.$action_type;
		}
		if($value)
		{
			$where['value'] = 'like:'.$value;
			$qs[] = 'value='.$value;
		}
		if($memo)
		{
			$where['memo'] = 'like:'.$memo;
			$qs[] = 'memo='.$memo;
		}
		if($from_time)
		{
			$where['action_time >= '] = strtotime($from_time);
			$qs[] = 'from_time='.$from_time;
		}
		if($to_time)
		{
			$where['action_time <= '] = strtotime($to_time);
			$qs[] = 'to_time='.$to_time;
		}

		$page = $this->input->get('per_page');
		$page = $page ? $page : self::CUR_PAGE;
		$queryStr = implode('&', $qs);
		$this->queryString = '/'.$uid.'?' . $queryStr;
		$this->pageQueryString = true;

		$consumerecord = $this->model_action_record->get_all($where, $this->pageSize, $page, 'action_time', 'DESC');
		foreach($consumerecord as &$record)
		{
			$record['action_time'] = date('Y-m-d H:i:s', $record['action_time']);
			$record['action_type'] = $config_action_record[$record['scope']][$record['type']][$record['sub_type']];
		}

		$tpl_data['per_page'] = $this->pageSize;
		$tpl_data['page'] = $page;
		$tpl_data['pagination'] = $this->pages($this->model_action_record->total_rows($where));

		$tpl_data['consumerecord'] = $consumerecord;
		$tpl_data['consume_type_arr'] = $consume_type_arr;
		$tpl_data['cur_nav'] = 'member_sys';
		$tpl_data['curtitle'] = '消费记录';
		$this->twig->display('member_card/consumerecord', $tpl_data);
	}

	/**
	 * @param string $uid
	 * @param int $page
	 * 积分记录
	 */
	public function creditrecord($uid='')
	{
		$tpl_data['uid'] = $uid;

		$this->load->config('action_record');
		$config_action_record = $this->config->item('action_record');
		$credit_type_arr = $this->config->item('credit_type');

		$action_type = $this->input->get_post('action_type');
		$value = $this->input->get_post('value');
		$memo = $this->input->get_post('memo');
		$from_time = $this->input->get_post('from_time');
		$to_time = $this->input->get_post('to_time');

		$tpl_data['action_type'] = $action_type ? $action_type : '';
		$tpl_data['value'] = $value ? $value : '';
		$tpl_data['memo'] = $memo ? $memo : '';
		$tpl_data['from_time'] = $from_time ? $from_time : '';
		$tpl_data['to_time'] = $to_time ? $to_time : '';

		//scope=2,积分类
		$where = array('uid'=>$uid, 'wid'=>User::$user_id, 'scope'=>2);
		$qs = array();
		if($action_type)
		{
			$action_type_arr = explode('_', $action_type);
			$where['type'] = $action_type_arr[0];
			$where['sub_type'] = $action_type_arr[1];
			$qs[] = 'action_type='.$action_type;
		}
		if($value)
		{
			$where['value'] = 'like:'.$value;
			$qs[] = 'value='.$value;
		}
		if($memo)
		{
			$where['memo'] = 'like:'.$memo;
			$qs[] = 'memo='.$memo;
		}
		if($from_time)
		{
			$where['action_time >= '] = strtotime($from_time);
			$qs[] = 'from_time='.$from_time;
		}
		if($to_time)
		{
			$where['action_time <= '] = strtotime($to_time);
			$qs[] = 'to_time='.$to_time;
		}

		$page = $this->input->get('per_page');
		$page = $page ? $page : self::CUR_PAGE;
		$queryStr = implode('&', $qs);
		$this->queryString = '/'.$uid.'?' . $queryStr;
		$this->pageQueryString = true;

		$creditrecord = $this->model_action_record->get_all($where, $this->pageSize, $page, 'action_time', 'DESC');
		foreach($creditrecord as &$record)
		{
			$record['action_time'] = date('Y-m-d H:i:s', $record['action_time']);
			$record['action_type'] = $config_action_record[$record['scope']][$record['type']][$record['sub_type']];
		}

		$tpl_data['per_page'] = $this->pageSize;
		$tpl_data['page'] = $page;
		$tpl_data['pagination'] = $this->pages($this->model_action_record->total_rows($where));

		$tpl_data['creditrecord'] = $creditrecord;
		$tpl_data['credit_type_arr'] = $credit_type_arr;
		$tpl_data['cur_nav'] = 'member_sys';
		$tpl_data['curtitle'] = '积分记录';
		$this->twig->display('member_card/creditrecord', $tpl_data);
	}

	/**
	 * 消费报表
	 */
	public function consumereport()
	{
		$this->load->config('action_record');

		$from_time = $this->input->post('from_time');
		$to_time = $this->input->post('to_time');

		$tpl_data['from_time'] = $from_time ? $from_time : date('Y-m-d 00:00:00', time());
		$tpl_data['to_time'] = $to_time ? $to_time : date('Y-m-d 00:00:00', strtotime('+1 day'));

		//scope=1，消费类
		$where = array('action_record.wid'=>User::$user_id, 'scope'=>1);
		if($from_time)
		{
			$where['action_time >= '] = strtotime($from_time);
		}
		else
		{
			$where['action_time >= '] = strtotime(date('Y-m-d 00:00:00', time()));
		}
		if($to_time)
		{
			$where['action_time <= '] = strtotime($to_time);
		}
		else
		{
			$where['action_time <= '] = strtotime(date('Y-m-d 00:00:00', strtotime('+1 day')));
		}

		$report_list = $this->model_action_record->get_consume_report($where, 'action_time', 'DESC');
		$addmoney_list = array();
		$reducemoney_list = array();
		$ticket_list = array();
		foreach($report_list as &$report_item)
		{
			$report_item['action_time'] = date('Y-m-d H:i:s', $report_item['action_time']);
			if($report_item['type'] == 0)
			{
				$addmoney_list[] = $report_item;
			}
			else if($report_item['type'] == 1)
			{
				$reducemoney_list[] = $report_item;
			}
			else if($report_item['type'] == 2)
			{
				$ticket_list[] = $report_item;
			}
		}
		//获取充值总额
		$am_where = $where;
		$am_where['type'] = 0;
		$am_where['sub_type'] = 0;
		$addmoney_sum = $this->model_action_record->get_sum($am_where);
		//获取付费总额
		$rm_where = $where;
		$rm_where['type'] = 1;
		$rm_where['sub_type'] = 0;
		$reducemoney_sum = $this->model_action_record->get_sum($rm_where);

		$tpl_data['addmoney_sum'] = $addmoney_sum;
		$tpl_data['reducemoney_sum'] = $reducemoney_sum;
		$tpl_data['addmoney_list'] = $addmoney_list;
		$tpl_data['reducemoney_list'] = $reducemoney_list;
		$tpl_data['cur_nav'] = 'member_sys';
		$tpl_data['curtitle'] = '消费报表';
		$this->twig->display('member_card/consumereport', $tpl_data);
	}

	/**
	 *代金券报表
	 */
	public function ticketreport()
	{
		$this->load->config('action_record');

		$from_time = $this->input->post('from_time');
		$to_time = $this->input->post('to_time');

		$tpl_data['from_time'] = $from_time ? $from_time : date('Y-m-d 00:00:00', time());
		$tpl_data['to_time'] = $to_time ? $to_time : date('Y-m-d 00:00:00', strtotime('+1 day'));

		$where = array('action_record.wid'=>User::$user_id);
		if($from_time)
		{
			$where['action_time >= '] = strtotime($from_time);
		}
		else
		{
			$where['action_time >= '] = strtotime(date('Y-m-d 00:00:00', time()));
		}
		if($to_time)
		{
			$where['action_time <= '] = strtotime($to_time);
		}
		else
		{
			$where['action_time <= '] = strtotime(date('Y-m-d 00:00:00', strtotime('+1 day')));
		}

		//获取‘使用代金券’列表
		$ut_where = $where;
		$ut_where['scope'] = 1;
		$ut_where['type'] = 2;
		$ut_where['sub_type'] = 0;
		$useticket_list = $this->model_action_record->get_consume_report($ut_where, 'action_time', 'DESC');
		foreach($useticket_list as &$ut_item)
		{
			$ut_item['action_time'] = date('Y-m-d H:i:s', $ut_item['action_time']);
		}

		//获取‘兑换代金券’列表
		$et_where = $where;
		$et_where['scope'] = 2;
		$et_where['type'] = 1;
		$et_where['sub_type'] = 0;
		$exchangeticket_list = $this->model_action_record->get_consume_report($et_where, 'action_time', 'DESC');
		foreach($exchangeticket_list as &$et_item)
		{
			$et_item['action_time'] = date('Y-m-d H:i:s', $et_item['action_time']);
		}

		$tpl_data['useticket_list'] = $useticket_list;
		$tpl_data['exchangeticket_list'] = $exchangeticket_list;
		$tpl_data['cur_nav'] = 'member_sys';
		$tpl_data['curtitle'] = '代金券报表';
		$this->twig->display('member_card/ticketreport', $tpl_data);
	}

	//领取会员卡列表导出
	public function export()
	{
		$mobile = $this->input->get('mobile');
		$cardNum = $this->input->get('cardNum');
		$money = $this->input->get('money');
		$credit = $this->input->get('credit');
		$fromTime = $this->input->get('fromTime');
		$toTime = $this->input->get('toTime');

		$this->load->model('model_account');

		$where = array(
			'wid' => User::$user_id
		);
		//用于筛选过滤
		if($mobile)
		{
			$rows = $this->model_account->get_all(array('wid'=>User::$user_id, 'mobile'=>'like:'.$mobile));
			if($rows){
				foreach($rows as $r)
				{
					$where['in:uid'][] = $r['id'];
				}
			}
			else
			{
				$where['1'] = 2;
			}
		}
		if($cardNum)
		{
			$where['cardNum'] = 'like:'.$cardNum;
		}
		if($money)
		{
			$where['money'] = $money;
		}
		if($credit)
		{
			$where['credit'] = $credit;
		}
		if($fromTime)
		{
			$where['inputtime >= '] = strtotime($fromTime);
		}
		if($toTime)
		{
			$where['inputtime <= '] = strtotime($toTime);
		}

		$list = $this->modelObj->get_card_list($where, 'inputtime', 'DESC');
		foreach ($list as &$row) {
			$row['inputtime'] = date('Y-m-d H:i:s', $row['inputtime']);
		}

		$fields = array(
			'#'=>'#',
			'mobile'=>'会员手机号',
			'cardNum'=>'会员卡号',
			'money'=>'余额',
			'credit'=>'积分',
			'inputtime'=>'领卡时间'
		);
		$this->excel_export('会员卡领取列表', '会员卡领取列表信息', $fields, $list);
	}

	//消费报表或者代金券报表导出
	public function report_export()
	{
		$scope = $this->input->get('scope');
		$type = $this->input->get('type');
		$sub_type = $this->input->get('sub_type');
		$from_time = $this->input->get('from_time');
		$to_time = $this->input->get('to_time');

		$where = array('action_record.wid'=>User::$user_id);
		$where['scope'] = $scope ? $scope : 0;
		$where['type'] = $type ? $type : 0;
		$where['sub_type'] = $sub_type ? $sub_type : 0;

		if($from_time)
		{
			$where['action_time >= '] = strtotime($from_time);
		}
		if($to_time)
		{
			$where['action_time <= '] = strtotime($to_time);
		}

		$report_list = $this->model_action_record->get_consume_report($where, 'action_time', 'DESC');
		foreach($report_list as &$report_item)
		{
			$report_item['action_time'] = date('Y-m-d H:i:s', $report_item['action_time']);
		}

		//充值或者付费
		if($scope == 1 && ($type == 0 || $type == 1))
		{
			$title = ($type == 0) ? '充值汇总' : '付费汇总';
			$des = ($type == 0) ? '充值汇总信息' : '付费汇总信息';
			$fields = array(
				'#'=>'#',
				'mobile'=>'会员手机号',
				'cardNum'=>'会员卡号',
				'value'=>'变化金额',
				'action_time'=>'时间'
			);
			$this->excel_export($title, $des, $fields, $report_list);
		}
		elseif($scope == 1 && $type == 2) //使用代金券
		{
			$title = '使用代金券汇总';
			$des = '使用代金券汇总信息';
			$fields = array(
				'#'=>'#',
				'mobile'=>'会员手机号',
				'cardNum'=>'会员卡号',
				'memo' => '备注',
				'action_time'=>'时间'
			);
			$this->excel_export($title, $des, $fields, $report_list);
		}
		elseif($scope == 2 && $type == 1 && $sub_type == 0) //兑换代金券
		{
			$title = '兑换代金券汇总';
			$des = '兑换代金券汇总信息';
			$fields = array(
				'#'=>'#',
				'mobile'=>'会员手机号',
				'cardNum'=>'会员卡号',
				'memo' => '备注',
				'value' => '消耗积分',
				'action_time'=>'时间'
			);
			$this->excel_export($title, $des, $fields, $report_list);
		}
	}

	/**
	 * 找回支付密码
	 */
	public function retrieve()
	{
		$mc = $this->checkCard();
		if(!$mc)
		{
			$this->show_message(FALSE, '该会员卡不存在', '/member_card');
		}
		$to_email = $this->model_user->get_one(array('id'=>User::$user_id), 'email');
		if(!$to_email)
		{
			$this->show_message(FALSE, '您还未设置邮箱，请联系代理商并提供您的邮箱进行设置', '/member_card/setpwd');
		}
		$this->load->config('email');
		$this->load->library('email');


		//$to_email = '306302160@qq.com';//'luisfigook@hotmail.com';
		$pass = rand(100000, 999999);
		$from_email = $this->config->item('smtp_user');//'support@bama555.com';
		$from_name = 'support';
		$message = "您好：\r\n您的交易密码已被重置为".$pass.",\r\n请赶快登录微网站后台重置您的新密码！";
		$this->email->from($from_email, $from_name);
		$this->email->to($to_email);
		$this->email->subject('找回密码');
		$this->email->message($message);

		if($this->email->send() && $this->model_member_card->update(array('id'=>$mc['id']), array('password'=>md5($pass))))
		{
			$this->show_message(TRUE, '请及时查看您的邮件（'.$to_email.'），并重置您的新密码', '/member_card/setpwd');
		}
		else
		{
			$this->show_message(FALSE, '找回密码失败，请稍后重试', '/member_card/setpwd');
		}

		//echo $this->email->print_debugger();
	}

	private function checkCard($where=array())
	{
		$where['wid'] = User::$user_id;

		$cardInfo = $this->model_member_card->get_row($where);
		if($cardInfo)
		{
			return $cardInfo;
		}
		else
		{
			return false;
		}
	}

	//交易密码设置里检查当前密码是否正确
	public function check_curpass($pass, $mc_id)
	{
		$mc = $this->model_member_card->get_row(array('id'=>$mc_id, 'password'=>md5($pass)));
		if(!$mc)
		{
			$this->form_validation->set_message('check_curpass', '当前密码不正确');
			return FALSE;
		}
		return TRUE;
	}
}