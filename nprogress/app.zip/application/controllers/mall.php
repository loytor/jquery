<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Created by JetBrains PhpStorm.
 * User: andery
 * Date: 13-10-23
 * Time: 下午5:06
 * 微商城
 * @property Model_mall $model_mall
 * @property Model_cate $model_cate
 * @property Model_address $model_address
 * @property Model_item_cate $model_item_cate
 * @property Model_item $model_item
 * @property Model_mall_order $model_mall_order
 * @property Model_mall_order_item $model_mall_order_item
 * @property Model_account $model_account
 * @property Model_payment $model_payment
 * @property Model_cate_lists $model_cate_lists
 * @property Model_payment_log $model_payment_log
 */

class Mall extends MY_Controller {

	const PAYED_STATUS1 = 1; //已付款/到店自提
	const PAYED_STATUS0 = 2; //已付款/送货上门
	const FACEPAY_STATUS0 = 3; //当面付款/到店自提
	const FACEPAY_STATUS1 = 4; //当面付款/送货上门
	const SENT_STATUS = 5; //已发货
	const RECEIVED_STATUS = 6;//已收货
	const CANCEL_STATUS = 7; //已取消

	private $item_status_list = array(
		0 => '未发布',
		1 => '已发布'
	);

    public function __construct()
    {
        parent::__construct();
        $this->load->model('model_mall');
        $this->mall = $this->model_mall->get_row(array('wid'=>User::$user_id));
        if (!$this->mall) {
            //添加一条商城的记录
	        $mall['wid'] = User::$user_id;
	        $this->model_mall->add($mall);
	        $this->mall = $this->model_mall->get_row(array('wid'=>User::$user_id));
        }
	    $this->mall['ship_method'] = json_decode($this->mall['ship_method'], TRUE);
    }

    /**
     * 基本配置
     */
    public function index()
    {
        $this->load->model('model_cate');
	    $this->load->model('model_cate_lists');
        $this->load->model('model_address');

        if ($this->input->post()) {
            $this->form_validation->set_rules('title', '标题', 'trim|required|max_length[50]');
	        $this->form_validation->set_rules('ship_method[]', '配送方式', 'trim|required');
            if ($this->form_validation->run()) {
                $mall['title'] = $this->form_validation->set_value('title');
	            $mall['icon'] = $this->input->post('icon');
	            $mall['ship_method'] = json_encode($this->input->post('ship_method'));
                $mall['cate_id'] = $cate_id = $this->input->post('cate_id');
                $mall['status'] = $this->input->post('status');
                $mall['tpl'] = $this->input->post('theme');
                $mall['desc'] = htmlspecialchars(trim($this->input->post('desc')));

                if ($this->model_mall->update(array('id'=>$this->mall['id'], 'wid'=>User::$user_id), $mall)) {
                    $adr_ids = $this->input->post('adr_ids') ? $this->input->post('adr_ids') : array();
                    $address = array();
                    foreach ($adr_ids as $val) {
                        $address[] = array('address_id' => $val);
                    }
                    $this->model_mall->set_branch($this->mall['id'], $this->mall['wid'], $address);

	                //更改cate_lists表的记录
	                if ($this->mall['cate_id'] != $cate_id) {
		                if ($cate_id) {
			                $data_cate_lists['user_id'] = User::$user_id;
			                $data_cate_lists['cate_id'] = $cate_id;
			                $data_cate_lists['type'] = 'mall';
			                $data_cate_lists['lists_id'] = 0;
			                $data_cate_lists['rank'] = 9999;
			                $this->model_cate_lists->add($data_cate_lists);
		                }
		                if ($this->mall['cate_id']) {
			                $del_data_cate_lists['user_id'] = User::$user_id;
			                $del_data_cate_lists['cate_id'] = $this->mall['cate_id'];
			                $del_data_cate_lists['type'] = 'mall';
			                $del_data_cate_lists['lists_id'] = 0;
			                $this->model_cate_lists->delete($del_data_cate_lists);
		                }
	                }

                    $this->show_message(TRUE, '保存设置成功', '/mall/');
                } else {
                    $this->show_message(FALSE, '保存设置失败', '/mall/');
                }
            } else {
                $this->show_message(FALSE, validation_errors(), '/mall/');
            }
        } else {
            //获取所有栏目
            $cate_arr = array();
            $_cate_arr = $this->model_cate->get_all(array('user_id' => User::$user_id));
            foreach ($_cate_arr as $_cate) {
                $cate_arr[$_cate['id']] = $_cate;
            }
            $tpl_data['cate_arr'] = $cate_arr;

            //外链地址
            $domain = $this->session->userdata('domain');
            $url = $domain ? "http://".$domain.".bama555.com/mall" : '';
            $tpl_data['url'] = $url;

            //分店
            $address_list = $this->model_address->get_all(array('wid'=>User::$user_id, 'status'=>0), '', '');
            $open_ids = array();
            $open_address = $this->model_mall->get_branch($this->mall['id']);
            foreach ($open_address as $val) {
                $open_ids[] = $val['address_id'];
            }
            $unselect_address = array();
            $selected_address = array();
            foreach($address_list as $val) {
                if(in_array($val['id'], $open_ids)) {
                    $selected_address[] = $val;
                } else {
                    $unselect_address[] = $val;
                }
            }
            $tpl_data['unselect_address'] = $unselect_address;
            $tpl_data['selected_address'] = $selected_address;
            $tpl_data['mall'] = $this->mall;

	        $this->load->config('mall');
	        $tpl_data['ship_method'] = $this->config->item('ship_method');

            $this->load->config('tpl');
            $tpl_data['mall_tpl'] = $this->config->item('mall_tpl');

            $tpl_data['type_info'] = '基本配置';
            $tpl_data['cur_nav'] = 'member_sys';
            $tpl_data['nav'] = 'setting';
	        $tpl_data['token'] = $this->token;
            $this->twig->display('mall/setting', $tpl_data);
        }
    }

    /**
     * 支付方式配置
     */
    public function payment()
    {
        $this->load->model('model_payment');
        //支付白名单
        $white_list = $this->model_payment->get_white_list();
        //过滤
        $payments = $this->model_payment->get_builtin($white_list);
        //已经安装的
        $installed = $this->model_payment->get_installed($this->mall['id']);
        foreach ($payments as $key => $value) {
            foreach ($installed as $installed_payment) {
                if ($installed_payment['code'] == $key) {
                    $payments[$key]['status']    = $installed_payment['status'];
                    $payments[$key]['installed']  = 1;
                    $payments[$key]['id'] = $installed_payment['id'];
                }
            }
        }
        $tpl_data['payments'] = $payments;
        $tpl_data['mall'] = $this->mall;
        $tpl_data['type_info'] = '支付方式';
        $tpl_data['cur_nav'] = 'member_sys';
        $tpl_data['nav'] = 'payment';
        $this->twig->display('mall/payment', $tpl_data);
    }

    public function payment_install($code)
    {
        $this->load->model('model_payment');
        $payment = $this->model_payment->get_builtin_info($code);
        if ($this->input->post()) {
            $config = serialize($this->input->post('config'));
            if ($this->model_payment->in_white_list($payment['code'])) {
                $this->model_payment->add(array(
                    'mall_id' => $this->mall['id'],
                    'code' => $payment['code'],
                    'name' => $payment['name'],
                    'config' => $config,
                    'online' => $payment['online'],
                    'sort' => $this->input->post('sort'),
                    'status' => $this->input->post('status'),
                ));
                $this->show_message(TRUE, '更新成功', '/mall/payment');
            } else {
                $this->show_message(FALSE, '更新失败', '/mall/payment');
            }
        } else {
            $tpl_data['payment'] = $payment;
            $tpl_data['type_info'] = '支付方式';
            $tpl_data['cur_nav'] = 'member_sys';
            $tpl_data['nav'] = 'payment';
            $this->twig->display('mall/payment_install', $tpl_data);
        }
    }

    public function payment_config($payment_id)
    {
        $this->load->model('model_payment');
        $payment_info = $this->model_payment->get_row(array('id' => $payment_id));
        $payment = $this->model_payment->get_builtin_info($payment_info['code']);
        if ($this->input->post()) {
            $config = serialize($this->input->post('config'));
            if ($this->model_payment->in_white_list($payment['code'])) {
                $this->model_payment->update(array('id' => $payment_id, 'mall_id' => $this->mall['id']), array(
                    'is_sys' => $this->input->post('is_sys') ? $this->input->post('is_sys') : 0,
                    'config' => $config,
                    'sort' => $this->input->post('sort'),
                    'status' => $this->input->post('status'),
                ));
                $this->show_message(TRUE, '更新成功', '/mall/payment');
            } else {
                $this->show_message(FALSE, '更新失败', '/mall/payment');
            }
        } else {
            $payment['id']     = $payment_info['id'];
            $payment['status'] = $payment_info['status'];
            $payment['sort']   = $payment_info['sort'];
            $payment['is_sys'] = $payment_info['is_sys'];
            $payment_config = unserialize($payment_info['config']);

            foreach ($payment['config'] as $key=>$val) {
                $payment['config'][$key]['value'] = isset($payment_config[$key]) ? $payment_config[$key] : '';
            }

            $tpl_data['payment'] = $payment;
            $tpl_data['type_info'] = '支付方式';
            $tpl_data['cur_nav'] = 'member_sys';
            $tpl_data['nav'] = 'payment';
            $this->twig->display('mall/payment_config', $tpl_data);
        }
    }

    public function payment_uninstall($payment_id)
    {
        $this->load->model('model_payment');
        if ($this->model_payment->delete(array('id' => $payment_id, 'mall_id' => $this->mall['id']))) {
            $this->show_message(TRUE, '删除成功', '/mall/payment');
        } else {
            $this->show_message(TRUE, '删除失败', '/mall/payment');
        }
    }

    /**
     * 分类管理
     */
    public function cate()
    {
        $this->load->model('model_item_cate');
        $page = (int)$this->input->get('per_page');
        $page = $page ? $page : self::CUR_PAGE;
        $this->pageQueryString = true;
        $this->queryString = '?' . $this->queryString;

        $where = array('mall_id' => $this->mall['id']);
        $list = $this->model_item_cate->get_all($where, $this->pageSize, $page);

        $tpl_data['type_info'] = '商品分类';
        $tpl_data['nav'] = 'cate';
        $tpl_data['list'] = $list;
        $tpl_data['page'] = $page;
        $tpl_data['per_page'] = $this->pageSize;
        $tpl_data['pagination'] = $this->pages($this->model_item_cate->total_rows($where));
        $this->twig->display('mall/cate', $tpl_data);
    }

    public function cate_add()
    {
        if ($this->input->post()) {
            $this->load->model('model_item_cate');
            $this->form_validation->set_rules('name', '分类名称', 'trim|required|max_length[50]');
            if ($this->form_validation->run()) {
                $cate['name'] = $this->form_validation->set_value('name');
	            $cate['img'] = $this->input->post('img');
	            $cate['desc'] = $this->input->post('desc');
                $cate['rank'] = intval($this->input->post('rank')) ? $this->input->post('rank') : 999;
                $cate['mall_id'] = $this->mall['id'];
                if ($this->model_item_cate->add($cate)) {
                    $this->show_message(TRUE, '添加商品分类成功', '/mall/cate');
                } else {
                    $this->show_message(FALSE, '添加商品分类失败', '/mall/cate_add');
                }
            } else {
                $this->show_message(FALSE, validation_errors(), '/mall/cate_add');
            }
        } else {
            $tpl_data['type_info'] = '添加商品分类';
            $tpl_data['nav'] = 'cate';
	        $tpl_data['token'] = $this->token;
            $this->twig->display('mall/cate_add', $tpl_data);
        }
    }

    public function cate_edit($id = '')
    {
        $this->load->model('model_item_cate');
        $item_cate = $this->model_item_cate->get_row(array('id'=>$id, 'mall_id'=>$this->mall['id']));
	    if(!$item_cate)
	    {
		    $this->show_message(FALSE, '该分类不存在', '/mall/cate');
	    }
	    if ($this->input->post()) {
            $this->form_validation->set_rules('name', '分类名称', 'trim|required|max_length[32]');
            if ($this->form_validation->run()) {
	            $cate['name'] = $this->form_validation->set_value('name');
	            $cate['img'] = $this->input->post('img');
	            $cate['desc'] = $this->input->post('desc');
	            $cate['rank'] = intval($this->input->post('rank')) ? $this->input->post('rank') : 999;
                if ($this->model_item_cate->update(array('mall_id'=>$this->mall['id'], 'id'=>$id), $cate)) {
                    $this->show_message(TRUE, '修改商品分类成功', '/mall/cate');
                } else {
                    $this->show_message(FALSE, '修改商品分类失败', '/mall/cate');
                }
            } else {
                $this->show_message(FALSE, validation_errors(), '/mall/cate');
            }
        } else {
            $tpl_data['row'] = $item_cate;
            $tpl_data['type_info'] = '修改商品分类';
            $tpl_data['cur_nav'] = 'member_sys';
            $tpl_data['nav'] = 'cate';
		    $tpl_data['token'] = $this->token;
            $this->twig->display('mall/cate_edit', $tpl_data);
        }
    }

	public function cate_del($id)
	{
		$this->load->model('model_item_cate');
		$this->load->model('model_item');
		$item_cate = $this->model_item_cate->get_row(array('id'=>$id, 'mall_id'=>$this->mall['id']));
		if(!$item_cate)
		{
			$this->show_message(FALSE, '该分类不存在', '/mall/cate');
		}
		if($this->model_item_cate->delete(array('id'=>$id, 'mall_id'=>$this->mall['id'])))
		{
			//更新商品表的分类字段
			$this->model_item->update(array('cate_id'=>$item_cate['id']), array('cate_id'=>0));

			$this->show_message(TRUE, '删除分类成功', '/mall/cate');
		}
		else
		{
			$this->show_message(FALSE, '删除分类失败', '/mall/cate');
		}
	}

    /**
     * 商品列表
     */
    public function lists()
    {
        $this->load->model('model_item_cate');
        $this->load->model('model_item');
        $cate_kv_list = $this->model_item_cate->get_kv_list($this->mall['id']);
        $page = (int)$this->input->get('per_page');
        $page = $page ? $page : self::CUR_PAGE;
        $this->pageQueryString = true;

        $tpl_data['title'] = $title = $this->input->get_post('title');
        $tpl_data['mprice'] = $mprice = $this->input->get_post('mprice');
        $tpl_data['price'] = $price = $this->input->get_post('price');
	    $tpl_data['stock'] = $stock = $this->input->get_post('stock');
	    $tpl_data['csale'] = $csale = $this->input->get_post('csale');
        $tpl_data['cate_id'] = $cate_id = $this->input->get_post('cate_id');

	    $status = $this->input->get_post('status');

	    $item_status_list = is_array($this->item_status_list) ? $this->item_status_list : array();
	    $isl = array();
	    foreach($item_status_list as $ik=>$is)
	    {
		    $isl[$ik]['name'] = $is;
		    if((string)$ik == (string)$status)
		    {
			    $isl[$ik]['selected'] = 1;
		    }
		    else
		    {
			    $isl[$ik]['selected'] = 0;
		    }
	    }
	    $tpl_data['item_status_list'] = $isl;

	    $status = $status == null ? 'all' : $status;
	    $tpl_data['status'] = $status;

        $qs = array();
        if($title) {
            $where['title'] = 'like:'.$title;
            $qs[] = 'title='.$title;
        }
        if($mprice) {
            $where['mprice'] = 'like:'.$mprice;
            $qs[] = 'mprice='.$mprice;
        }
        if($price) {
            $where['price'] = 'like:'.$price;
            $qs[] = 'price='.$price;
        }
	    if($stock) {
		    $where['stock'] = 'like:'.$stock;
		    $qs[] = 'stock='.$stock;
	    }
	    if($csale) {
		    $where['csale'] = 'like:'.$csale;
		    $qs[] = 'csale='.$csale;
	    }
        if($cate_id) {
            $where['cate_id'] = $cate_id;
            $qs[] = 'cate_id='.$cate_id;
        }
	    if($status != null && $status != 'all') {
		    $where['status'] = $status;
		    $qs[] = 'status='.$status;
	    }

        $queryStr = implode('&', $qs);
        $this->queryString = '?' . $queryStr;

        $where['mall_id'] = $this->mall['id'];
        $list = $this->model_item->get_all($where, $this->pageSize, $page, 'rank', 'asc');
	    foreach($list as &$item)
	    {
		    $item['img_arr'] = json_decode($item['img'], TRUE);
		    $item['status_name'] = isset($this->item_status_list[$item['status']]) ?  $this->item_status_list[$item['status']] : '';
	    }

        $tpl_data['type_info'] = '商品列表';
        $tpl_data['nav'] = 'lists';
        $tpl_data['list'] = $list;
        $tpl_data['per_page'] = $this->pageSize;
        $tpl_data['page'] = $page;
        $tpl_data['pagination'] = $this->pages($this->model_item->total_rows($where));
        $tpl_data['cate_kv_list'] = $cate_kv_list;
        $this->twig->display('mall/lists', $tpl_data);
    }
    
    /**
     * 修改销量
     */
    public function edit_csale()
    {
        $id = $this->input->get_post('item_id');
        if( !$id ){
            echo json_encode(array(
                'success' => -1,
                'msg'  => '非法操作'
            ));
        }
        $this->load->model('model_item');
        $item = $this->model_item->get_row(array('id'=>$id, 'mall_id'=>$this->mall['id']));
        if(!$item)
        {
            echo json_encode(array(
                'success' => -1,
                'msg'  => '非法操作'
            ));
        }
        $value = intval($this->input->get('value'));
        if( $value<0 ){
            echo json_encode(array(
                'success' => -1,
                'msg'  => '非法操作'
            ));
        }
        if ($this->model_item->update(array('mall_id'=>$this->mall['id'], 'id'=>$id), array('csale'=>$value))) {
            echo json_encode(array(
                'success' => 1
            ));
        }else{
            echo json_encode(array(
                'success' => -1,
                'msg'  => '修改失败'
            ));
        }
    }

    public function item_add()
    {
        $this->load->model('model_item_cate');
        $this->load->model('model_item');

        if ($this->input->post()) {
	        $this->form_validation->set_rules('title', '商品长标题', 'trim|required|max_length[255]');
	        $this->form_validation->set_rules('title_short', '商品短标题', 'trim|required|max_length[50]');
	        $this->form_validation->set_rules('price', '现价', 'trim|required|numeric');
	        $this->form_validation->set_rules('mprice', '原价', 'trim|numeric');
	        $this->form_validation->set_rules('stock', '总库存量', 'trim|required|is_natural');
	        $this->form_validation->set_rules('quota', '单人限购', 'trim|is_natural|greater_than_equal_to[0]');
            if ($this->form_validation->run()) {
	            $item['mall_id'] = $this->mall['id'];
                $item['cate_id'] = $this->input->post('cate_id');
	            $item['title'] = $this->form_validation->set_value('title');
	            $item['title_short'] = $this->form_validation->set_value('title_short');
	            $image = $this->input->post('image');
                if( !$image ){
                    $this->show_message(FALSE, '请上传商品图片', '',1);exit;
                }
                $item['img'] = json_encode($image);
	            $item['price'] = $this->form_validation->set_value('price');
	            $item['mprice'] = $this->form_validation->set_value('mprice');
	            $item['stock'] = $this->form_validation->set_value('stock');
	            $item['desc'] = $this->input->post('desc');
	            $item['dt_add'] = time();
	            $item['status'] = $this->input->post('status') ? $this->input->post('status') : 0;
	            $item['rank'] = intval($this->input->post('rank')) ? $this->input->post('rank') : 999;
	            
	            $item['quota'] = $this->form_validation->set_value('quota');

	            $item_id = $this->model_item->add($item, TRUE);
                if ($item_id) {
	                //添加商品和地址关联的记录
	                $address = $this->input->post('address');
	                $address_data = array();
	                if($address)
	                {
		                foreach ($address as $val) {
			                $address_data[] = array('address_id' => $val);
		                }
	                }
	                $this->model_item->set_branch($item_id, $this->mall['wid'], $address_data);

                    $this->show_message(TRUE, '添加商品成功', '/mall/lists');
                } else {
                    $this->show_message(FALSE, '添加商品失败', '/mall/item_add');
                }
            } else {
                $this->show_message(FALSE, validation_errors(), '/mall/item_add');
            }
        } else {
            $tpl_data['address_list'] = $this->model_mall->get_branch_full($this->mall['id']);
            $tpl_data['cate_kv_list'] = $this->model_item_cate->get_kv_list($this->mall['id']);
            $tpl_data['type_info'] = '添加商品';
	        $tpl_data['nav'] = 'lists';
            $tpl_data['token'] = $this->token;
            $this->twig->display('mall/item_add', $tpl_data);
        }
    }

    public function item_edit($id)
    {
        $this->load->model('model_item_cate');
	    $this->load->model('model_item');

	    $item = $this->model_item->get_row(array('id'=>$id, 'mall_id'=>$this->mall['id']));
	    if(!$item)
	    {
		    $this->show_message(FALSE, '该商品不存在', '/mall/lists');
	    }
	    $item['img_arr'] = $item['img'] ? json_decode($item['img'], TRUE) : array();
	    $tpl_data['item'] = $item;

        if ($this->input->post()) {
	        $this->form_validation->set_rules('title', '商品长标题', 'trim|required|max_length[255]');
	        $this->form_validation->set_rules('title_short', '商品短标题', 'trim|required|max_length[50]');
	        $this->form_validation->set_rules('price', '现价', 'trim|required|numeric');
	        $this->form_validation->set_rules('mprice', '原价', 'trim|numeric');
	        $this->form_validation->set_rules('stock', '总库存量', 'trim|required|is_natural');
	        $this->form_validation->set_rules('quota', '每人限购', 'trim|is_natural|greater_than_equal_to[0]');
            if ($this->form_validation->run()) {
	            $item_data['cate_id'] = $this->input->post('cate_id');
	            $item_data['title'] = $this->form_validation->set_value('title');
	            $item_data['title_short'] = $this->form_validation->set_value('title_short');
	            $image = $this->input->post('image');
                if( !$image ){
                    $this->show_message(FALSE, '请上传商品图片', '',1);exit;
                }
                $item_data['img'] = json_encode($image);
	            $item_data['price'] = $this->form_validation->set_value('price');
	            $item_data['mprice'] = $this->form_validation->set_value('mprice');
	            $item_data['stock'] = $this->form_validation->set_value('stock');
	            $item_data['desc'] = $this->input->post('desc');
	            $item_data['status'] = $this->input->post('status') ? $this->input->post('status') : 0;
	            $item_data['rank'] = intval($this->input->post('rank')) ? $this->input->post('rank') : 999;
	            
	            $item_data['quota'] = $this->form_validation->set_value('quota');

                if ($this->model_item->update(array('mall_id'=>$this->mall['id'], 'id'=>$id), $item_data)) {
	                $address = $this->input->post('address');
	                $address_data = array();
	                if($address)
	                {
		                foreach ($address as $val) {
			                $address_data[] = array('address_id' => $val);
		                }
	                }
	                $this->model_item->set_branch($id, $this->mall['wid'], $address_data);

                    $this->show_message(TRUE, '修改商品成功', '/mall/lists');
                } else {
                    $this->show_message(FALSE, '修改商品失败', '/mall/item_edit/'.$id);
                }
            } else {
                $this->show_message(FALSE, validation_errors(), '/mall/item_edit/'.$id);
            }
        } else {
	        $item_branch = $this->model_item->get_branch($id);
	        $open_ids = array();
	        foreach ($item_branch as $val) {
		        $open_ids[] = $val['address_id'];
	        }
	        $address_list = $this->model_mall->get_branch_full($this->mall['id']);
	        $unselect_address = array();
	        $selected_address = array();
	        foreach($address_list as $val)
	        {
		        if(in_array($val['id'], $open_ids)) {
			        $selected_address[] = $val;
		        } else {
			        $unselect_address[] = $val;
		        }
	        }
	        $tpl_data['unselect_address'] = $unselect_address;
	        $tpl_data['selected_address'] = $selected_address;

	        $tpl_data['address_list'] = $address_list;
	        $tpl_data['cate_kv_list'] = $this->model_item_cate->get_kv_list($this->mall['id']);
            $tpl_data['type_info'] = '修改商品';
            $tpl_data['nav'] = 'lists';
            $tpl_data['token'] = $this->token;
            $this->twig->display('mall/item_edit', $tpl_data);
        }
    }

	public function item_del($id)
	{
		$this->load->model('model_item');
		$item = $this->model_item->get_row(array('id'=>$id, 'mall_id'=>$this->mall['id']));
		if(!$item)
		{
			$this->show_message(FALSE, '该商品不存在', '/mall/lists');
		}
		if($this->model_item->delete(array('id'=>$id, 'mall_id'=>$this->mall['id'])))
		{
			$this->show_message(TRUE, '删除商品成功', '/mall/lists');
		}
		else
		{
			$this->show_message(FALSE, '删除商品你失败', '/mall/lists');
		}
	}

	/**
	 * 订单列表
	 */
	public function order()
	{
		$this->load->config('mall');
		$order_status = $this->config->item('order_status');
		$order_status_list = $this->config->item('order_status_list');

		$this->load->model('model_mall_order');
		$this->load->model('model_account');

		$tpl_data['order_sn'] = $order_sn = $this->input->get_post('order_sn');
/*		$tpl_data['account_name'] = $account_name = $this->input->get_post('account_name');*/
		$tpl_data['account_mobile'] = $account_mobile = $this->input->get_post('account_mobile');
		$tpl_data['from_time'] = $from_time = $this->input->get_post('from_time');
		$tpl_data['to_time'] = $to_time = $this->input->get_post('to_time');
		$status = $this->input->get_post('status');

		$order_status_list = is_array($order_status_list) ? $order_status_list : array();
		$osl = array();
		foreach($order_status_list as $ok=>$os)
		{
			$osl[$ok]['name'] = $os;
			if((string)$ok == (string)$status)
			{
				$osl[$ok]['selected'] = 1;
			}
			else
			{
				$osl[$ok]['selected'] = 0;
			}
		}
		$tpl_data['order_status_list'] = $osl;

		$status = ($status != null) ? $status : 'all';
		$tpl_data['status'] = $status;
		$tpl_data['order_amount'] = $order_amount = $this->input->get_post('order_amount');

		$qs = array();
		if($order_sn) {
			$where['order_sn'] = 'like:'.$order_sn;
			$qs[] = 'order_sn='.$order_sn;
		}
/*		if($account_name) {
			$accounts = $this->model_account->get_all(array('name'=>'like:'.$account_name, 'wid'=>User::$user_id));
			if($accounts)
			{
				foreach($accounts as $ac)
				{
					$where['in:account_id'][] = $ac['id'];
				}
			}
			else
			{
				$where['1'] = 2;
			}
			$qs[] = 'account_name='.$account_name;
		}*/
		if($account_mobile) {
			$accounts = $this->model_account->get_all(array('mobile'=>'like:'.$account_mobile, 'wid'=>User::$user_id));
			if($accounts)
			{
				foreach($accounts as $ac)
				{
					$where['in:account_id'][] = $ac['id'];
				}
			}
			else
			{
				$where['1'] = 2;
			}
			$qs[] = 'account_mobile='.$account_mobile;
		}
		if($from_time)
		{
			$where['create_time >= '] = strtotime($from_time);
			$qs[] = 'from_time='.$from_time;
		}
		if($to_time)
		{
			$where['create_time <= '] = strtotime($to_time);
			$qs[] = 'to_time='.$to_time;
		}
		if($status != null && $status != 'all') {
			$status_arr = explode(',', $status);
			foreach($status_arr as $sa)
			{
				$where['in:status'][] = $sa;
			}
			$qs[] = 'status='.$status;
		}
		if($order_amount) {
			$where['order_amount'] = 'like:'.$order_amount;
			$qs[] = 'order_amount='.$order_amount;
		}

		$page = (int)$this->input->get('per_page');
		$page = $page ? $page : self::CUR_PAGE;
		$this->pageQueryString = true;
		$queryStr = implode('&', $qs);
		$this->queryString = '?' . $queryStr;

		$where['mall_id'] = $this->mall['id'];
		$order_list = $this->model_mall_order->get_order_list($where, $this->pageSize, $page, 'create_time', 'desc');
		foreach($order_list as &$ol)
		{
			$ol['create_time'] = date('Y-m-d H:i:s', $ol['create_time']);
			$ol['pay_time'] = date('Y-m-d H:i:s', $ol['pay_time']);
			$ol['status_name'] = $order_status[$ol['status']];
		}

		$tpl_data['order_list'] = $order_list;

		$tpl_data['type_info'] = '订单列表';
		$tpl_data['nav'] = 'order';
		$tpl_data['per_page'] = $this->pageSize;
		$tpl_data['page'] = $page;
		$tpl_data['pagination'] = $this->pages($this->model_mall_order->total_rows($where));
		$this->twig->display('mall/order', $tpl_data);
	}

	/**
	 * @param $id
	 * 订单查看
	 */
	public function order_view($id)
	{
		$this->load->config('mall');
		$order_status = $this->config->item('order_status');
		$ship_method = $this->config->item('ship_method');
		$delivery_method = $this->config->item('delivery_method');

		$this->load->model('model_mall_order');
		$this->load->model('model_mall_order_item');
		$this->load->model('model_payment');

		$order = $this->model_mall_order->get_order(array('mall_order.id'=>$id, 'mall_order.mall_id'=>$this->mall['id']));
		if(!$order)
		{
			$this->show_message(TRUE, '该订单不存在', '/mall/order');
		}
		$order['create_time'] = date('Y-m-d H:i:s', $order['create_time']);
		$order['pay_time'] = date('Y-m-d H:i:s', $order['pay_time']);
		$order['status_name'] = $order_status[$order['status']];
		$order['ship_method_name'] = $ship_method && isset($ship_method[$order['ship_method']]) ? $ship_method[$order['ship_method']] : '';
		$ship_data = json_decode($order['ship_data'], TRUE);
		$new_ship_data = '';
		if($ship_data)
		{
			$new_ship_data .= isset($delivery_method[$ship_data['type']]) ? $delivery_method[$ship_data['type']] : '';
			$new_ship_data .= isset($ship_data['name']) ? ', 快递名称:'.$ship_data['name'] : '';
			$new_ship_data .= isset($ship_data['num']) ? ', 快递单号:'.$ship_data['num'] : '';
		}
		$order['ship_data'] = $new_ship_data ? '（'.$new_ship_data.'）' : '';
		$item_list = $this->model_mall_order_item->get_all(array('order_id'=>$id, 'mall_id'=>$this->mall['id']));

		//获取发货门店
		$store_list = $this->model_mall->get_branch_full($this->mall['id']);
		$tpl_data['store_list'] = $store_list ? $store_list : array();

		$tpl_data['order'] = $order;
		$tpl_data['item_list'] = $item_list;
		$tpl_data['type_info'] = '查看订单';
		$tpl_data['nav'] = 'order';
		$this->twig->display('mall/order_view', $tpl_data);
	}

	public function order_edit()
	{
		$this->load->model('model_mall_order');

		$id = $this->input->post('id');
		$mall_id = $this->input->post('mall_id');
		$data = $this->input->post('data');

		$order = $this->model_mall_order->get_row(array('id'=>$id, 'mall_id'=>$mall_id));
		if(!$order)
		{
			$result['success'] = 0;
			$result['msg'] = '该订单不存在';
			echo json_encode($result);
		}

		if($this->model_mall_order->update(array('id'=>$id, 'mall_id'=>$mall_id), $data))
		{
			$result['success'] = 1;
			$result['msg'] = '修改成功';
			$result['data'] = $data;
			echo json_encode($result);
		}
		else
		{
			$result['success'] = 0;
			$result['msg'] = '修改失败';
			echo json_encode($result);
		}
	}

	/**
	 * 取消订单
	 */
	public function order_cancel()
	{
		$this->load->model('model_mall_order');

		$id = $this->input->post('id');
		$mall_id = $this->input->post('mall_id');

		$order = $this->model_mall_order->get_row(array('id'=>$id, 'mall_id'=>$mall_id));
		if(!$order)
		{
			$result['success'] = 0;
			$result['msg'] = '该订单不存在';
			echo json_encode($result);
		}
		if($this->model_mall_order->update(array('id'=>$id, 'mall_id'=>$mall_id), array('status'=>self::CANCEL_STATUS)))
		{
			//相关商品库存还原
			$this->load->model('model_item');
			$this->load->model('model_mall_order_item');
			$order_item_list = $this->model_mall_order_item->get_all(array('mall_id'=>$mall_id, 'order_id'=>$id));
			foreach($order_item_list as $item)
			{
				$this->model_item->count_step($item['item_id'], 'stock', $item['quantity']);
			}

            //如果在mall_order_item_quantity表(限购记录表)中有记录，则删除
            $this->load->model('model_mall_order_item_quantity');
            $this->model_mall_order_item_quantity->delete(array('order_id'=>$id, 'uid'=>$order['account_id'], 'mall_id'=>$mall_id));

			$result['success'] = 1;
			$result['msg'] = '取消订单成功';
			echo json_encode($result);
		}
		else
		{
			$result['success'] = 0;
			$result['msg'] = '取消订单失败';
			echo json_encode($result);
		}
	}

	/**
	 * 已付款
	 */
	public function order_payed()
	{
		$this->load->model('model_mall_order');

		$id = $this->input->post('id');
		$mall_id = $this->input->post('mall_id');

		$order = $this->model_mall_order->get_row(array('id'=>$id, 'mall_id'=>$mall_id));
		if(!$order)
		{
			$result['success'] = 0;
			$result['msg'] = '该订单不存在';
			echo json_encode($result);
		}
		$status = $order['ship_method'] ?  self::PAYED_STATUS1 : self::PAYED_STATUS0;

		if($this->model_mall_order->update(array('id'=>$id, 'mall_id'=>$mall_id), array('status'=>$status, 'pay_time'=>time())))
		{
			$result['success'] = 1;
			$result['msg'] = '订单状态更改成功';

            //记录日志
            $this->load->model('model_payment');
            $payment_info = $this->model_payment->get_row(array('id' => $order['payment_id'], 'mall_id' => $this->mall['id']));

            $this->load->model('model_account');
            $account_info = $this->model_account->get_row(array('id' => $order['account_id']));

            $this->load->model('model_payment_log');
            $this->model_payment_log->add(array(
                'mall_id' => $this->mall['id'],
                'order_id' => $order['id'],
                'order_sn' => $order['order_sn'],
                'account_id' => $order['account_id'],
                'account_mob' => $account_info['mobile'],
                'payment_code' => $payment_info['code'],
                'payment_name' => $payment_info['name'],
                'amount' => $order['order_amount'],
                'log_time' => time(),
                'trade_no' => '',
                'trade_data' => ''
            ));

			echo json_encode($result);
		}
		else
		{
			$result['success'] = 0;
			$result['msg'] = '订单状态更改失败';
			echo json_encode($result);
		}
	}

	/**
	 * 发货
	 */
	public function order_send()
	{
		$this->load->model('model_mall_order');

		$id = $this->input->post('id');
		$mall_id = $this->input->post('mall_id');
		$data = $this->input->post('data');
		$data = $data ? $data : array();

		$order = $this->model_mall_order->get_row(array('id'=>$id, 'mall_id'=>$mall_id));
		if(!$order)
		{
			$result['success'] = 0;
			$result['msg'] = '该订单不存在';
			echo json_encode($result);
		}

		$data['status'] = self::SENT_STATUS;
		if(isset($data['ship_data']))
		{
			$data['ship_data'] = json_encode($data['ship_data']);
		}
		if($this->model_mall_order->update(array('id'=>$id, 'mall_id'=>$mall_id), $data))
		{
			$result['success'] = 1;
			$result['msg'] = '发货成功';
			echo json_encode($result);
		}
		else
		{
			$result['success'] = 0;
			$result['msg'] = '发货失败';
			echo json_encode($result);
		}
	}

	/**
	 * 已收货
	 */
	public function order_received()
	{
		$this->load->model('model_mall_order');

		$id = $this->input->post('id');
		$mall_id = $this->input->post('mall_id');

		$order = $this->model_mall_order->get_row(array('id'=>$id, 'mall_id'=>$mall_id));
		if(!$order)
		{
			$result['success'] = 0;
			$result['msg'] = '该订单不存在';
			echo json_encode($result);
		}

		if($this->model_mall_order->update(array('id'=>$id, 'mall_id'=>$mall_id), array('status'=>self::RECEIVED_STATUS)))
		{
			//相关商品销量增加
			$this->load->model('model_item');
			$this->load->model('model_mall_order_item');
			$order_item_list = $this->model_mall_order_item->get_all(array('mall_id'=>$mall_id, 'order_id'=>$id));
			foreach($order_item_list as $item)
			{
				$this->model_item->count_step($item['item_id'], 'csale', $item['quantity']);
			}

			$result['success'] = 1;
			$result['msg'] = '订单状态更改成功';
			echo json_encode($result);
		}
		else
		{
			$result['success'] = 0;
			$result['msg'] = '订单状态更改失败';
			echo json_encode($result);
		}
	}

	/**
	 * 数据统计
	 */
	public function statistics()
	{
		$this->load->model('model_mall_order');

		$tab = $this->input->get_post('tab');
		$tpl_data['tab'] = $tab ? $tab : 'tab1';

		//商城统计时间
		$from_time1 = $this->input->get_post('from_time1');
		$from_time1 = $from_time1 ? $from_time1 : date('Y-m-d H:i:s', strtotime('-7 days'));
		$to_time1 = $this->input->get_post('to_time1');
		$to_time1 = $to_time1 ? $to_time1 : date('Y-m-d H:i:s');
		//分店统计时间
		$from_time2 = $this->input->get_post('from_time2');
		$from_time2 = $from_time2 ? $from_time2 : date('Y-m-d H:i:s', strtotime('-7 days'));
		$to_time2 = $this->input->get_post('to_time2');
		$to_time2 = $to_time2 ? $to_time2 : date('Y-m-d H:i:s');

		$tpl_data['from_time1'] = $from_time1;
		$tpl_data['to_time1'] = $to_time1;
		$tpl_data['from_time2'] = $from_time2;
		$tpl_data['to_time2'] = $to_time2;

		$from_time1 = strtotime($from_time1);
		$to_time1 = strtotime($to_time1);
		$from_time2 = strtotime($from_time2);
		$to_time2 = strtotime($to_time2);

		$statistics = $this->model_mall_order->get_statistics($this->mall['id'], $from_time1, $to_time1, array());

		$undealt_status = array(self::PAYED_STATUS1, self::PAYED_STATUS0, self::FACEPAY_STATUS0, self::FACEPAY_STATUS1);
		$undealt_statistics = $this->model_mall_order->get_statistics($this->mall['id'], $from_time1, $to_time1, $undealt_status);

		foreach($statistics as &$st)
		{
			$st['undealt_count'] = 0;
			foreach($undealt_statistics as $us)
			{
				if($st['dt'] == $us['dt'])
				{
					$st['undealt_count'] = $us['order_count'];
					break;
				}
			}
		}
		$tpl_data['statistics'] = $statistics;

		$store_statistics = $this->model_mall_order->get_statistics_by_store($this->mall['id'], $from_time2, $to_time2);
		$tpl_data['store_statistics'] = $store_statistics;

		$tpl_data['type_info'] = '数据统计';
		$tpl_data['nav'] = 'statistics';
		$this->twig->display('mall/statistics', $tpl_data);
	}

	/**
	 * 支付记录
	 */
	public function payment_log()
	{
		$this->load->model('model_payment_log');

		$tpl_data['order_sn'] = $order_sn = $this->input->get_post('order_sn');
		$tpl_data['account_mob'] = $account_mob = $this->input->get_post('account_mob');
		$tpl_data['payment_name'] = $payment_name = $this->input->get_post('payment_name');
		$tpl_data['from_time'] = $from_time = $this->input->get_post('from_time');
		$tpl_data['to_time'] = $to_time = $this->input->get_post('to_time');
		$tpl_data['amount'] = $amount = $this->input->get_post('amount');

		$qs = array();
		if($order_sn) {
			$where['order_sn'] = 'like:'.$order_sn;
			$qs[] = 'order_sn='.$order_sn;
		}
		if($account_mob) {
			$where['account_mob'] = 'like:'.$account_mob;
			$qs[] = 'account_mob='.$account_mob;
		}
		if($from_time)
		{
			$where['log_time >= '] = strtotime($from_time);
			$qs[] = 'from_time='.$from_time;
		}
		if($to_time)
		{
			$where['log_time <= '] = strtotime($to_time);
			$qs[] = 'to_time='.$to_time;
		}
		if($amount) {
			$where['amount'] = 'like:'.$amount;
			$qs[] = 'amount='.$amount;
		}

		$page = (int)$this->input->get('per_page');
		$page = $page ? $page : self::CUR_PAGE;
		$this->pageQueryString = true;
		$queryStr = implode('&', $qs);
		$this->queryString = '?' . $queryStr;

		$where['mall_id'] = $this->mall['id'];
		$log_list = $this->model_payment_log->get_all($where, $this->pageSize, $page, 'log_time', 'desc');
		foreach($log_list as &$log)
		{
			$log['log_time'] = date('Y-m-d H:i:s', $log['log_time']);
		}

		$tpl_data['list'] = $log_list;
		$tpl_data['per_page'] = $this->pageSize;
		$tpl_data['page'] = $page;
		$tpl_data['pagination'] = $this->pages($this->model_payment_log->total_rows($where));
		$tpl_data['type_info'] = '支付记录';
		$tpl_data['nav'] = 'payment_log';
		$this->twig->display('mall/payment_log', $tpl_data);
	}

	/**
	 * 导出支付记录
	 */
	public function log_export()
	{
		$this->load->model('model_payment_log');

		$tpl_data['order_sn'] = $order_sn = $this->input->get_post('order_sn');
		$tpl_data['account_mob'] = $account_mob = $this->input->get_post('account_mob');
		$tpl_data['payment_name'] = $payment_name = $this->input->get_post('payment_name');
		$tpl_data['from_time'] = $from_time = $this->input->get_post('from_time');
		$tpl_data['to_time'] = $to_time = $this->input->get_post('to_time');
		$tpl_data['amount'] = $amount = $this->input->get_post('amount');

		$qs = array();
		if($order_sn) {
			$where['order_sn'] = 'like:'.$order_sn;
			$qs[] = 'order_sn='.$order_sn;
		}
		if($account_mob) {
			$where['account_mob'] = 'like:'.$account_mob;
			$qs[] = 'account_mob='.$account_mob;
		}
		if($from_time)
		{
			$where['log_time >= '] = strtotime($from_time);
			$qs[] = 'from_time='.$from_time;
		}
		if($to_time)
		{
			$where['log_time <= '] = strtotime($to_time);
			$qs[] = 'to_time='.$to_time;
		}
		if($amount) {
			$where['amount'] = 'like:'.$amount;
			$qs[] = 'amount='.$amount;
		}

		$where['mall_id'] = $this->mall['id'];
		$list = $this->model_payment_log->get_all($where, '', '', 'log_time', 'desc');
		foreach ($list as &$row) {
			$row['log_time'] = date('Y-m-d H:i:s', $row['log_time']);
		}

		$fields = array(
			'#'=>'#',
			'order_sn'=>'订单号',
			'account_mob'=>'用户手机号',
			'payment_name'=>'支付方式',
			'log_time'=>'支付时间',
			'amount'=>'支付金额'
		);
		$this->excel_export('支付记录列表', '支付记录列表信息', $fields, $list);
	}

    /**
     * 导出全部订单
     */
    public function order_export()
    {
        $this->load->config('mall');
        $order_status = $this->config->item('order_status');
        $ship_method = $this->config->item('ship_method');
        $delivery_method = $this->config->item('delivery_method');

        $this->load->model('model_mall_order');
        $this->load->model('model_mall_order_item');
        $this->load->model('model_payment');
        $this->load->model('model_account');

        $order_sn = $this->input->get_post('order_sn');
        $account_mobile = $this->input->get_post('account_mobile');
        $from_time = $this->input->get_post('from_time');
        $to_time = $this->input->get_post('to_time');
        $status = $this->input->get_post('status');
        $status = ($status != null) ? $status : 'all';
        $order_amount = $this->input->get_post('order_amount');

        if($order_sn) {
            $where['order_sn'] = 'like:'.$order_sn;
        }
        if($account_mobile) {
            $accounts = $this->model_account->get_all(array('mobile'=>'like:'.$account_mobile, 'wid'=>User::$user_id));
            if($accounts)
            {
                foreach($accounts as $ac)
                {
                    $where['in:account_id'][] = $ac['id'];
                }
            }
            else
            {
                $where['1'] = 2;
            }
        }
        if($from_time)
        {
            $where['create_time >= '] = strtotime($from_time);
        }
        if($to_time)
        {
            $where['create_time <= '] = strtotime($to_time);
        }
        if($status != null && $status != 'all') {
            $status_arr = explode(',', $status);
            foreach($status_arr as $sa)
            {
                $where['in:mall_order.status'][] = $sa;
            }
        }
        if($order_amount) {
            $where['order_amount'] = 'like:'.$order_amount;
        }
        $where['mall_order.mall_id'] = $this->mall['id'];

        $orders = $this->model_mall_order->get_orders($where, 'create_time', 'desc');
        $orders = $orders ? $orders : array();
        foreach($orders as &$order) {
            $order['create_time'] = date('Y-m-d H:i:s', $order['create_time']);
            $order['pay_time'] = $order['pay_time'] ? date('Y-m-d H:i:s', $order['pay_time']) : '';
            $order['status_name'] = $order_status[$order['status']];
            $order['ship_method_name'] = $ship_method && isset($ship_method[$order['ship_method']]) ? $ship_method[$order['ship_method']] : '';
            $ship_data = json_decode($order['ship_data'], TRUE);
            $new_ship_data = '';
            if($ship_data)
            {
                $new_ship_data .= isset($delivery_method[$ship_data['type']]) ? $delivery_method[$ship_data['type']] : '';
                $new_ship_data .= isset($ship_data['name']) ? ', 快递名称:'.$ship_data['name'] : '';
                $new_ship_data .= isset($ship_data['num']) ? ', 快递单号:'.$ship_data['num'] : '';
            }
            $order['ship_data'] = $new_ship_data ? '（'.$new_ship_data.'）' : '';
            $order['shipping_way'] = $order['ship_method_name'].$order['ship_data'];
            $item_list = $this->model_mall_order_item->get_all(array('order_id'=>$order['id'], 'mall_id'=>$this->mall['id']));
            $items = '';
            foreach($item_list as $item) {
                $items .= "名称：".$item['item_title'].", 单价：".$item['price'].", 数量：".$item['quantity']."; ";
            }
            $items = $items ? $items : '尚无订单商品';
            $order['items'] = $items;
            $order['consignee_info'] = $order['ship_method'] == 0 ? '姓名：'. $order['consignee'] .', 地址：'. $order['address'] .', 手机：' . $order['phone_mob'] : '';
        }

        $fields = array(
            '#'=>'#',
            'order_sn'=>'订单号',
            'create_time'=>'订单时间',
            'account_mobile'=>'手机号码',
            'order_amount'=>'总价',
            'payment_name'=>'支付方式',
            'pay_time'=>'付款时间',
            'status_name'=>'订单状态',
            'items'=>'订单商品',
            'store_name'=>'发货门店',
            'shipping_way'=>'配送方式',
            'consignee_info'=>'收货人信息',
            'mark'=>'备注'
        );
        $this->excel_export('订单列表', '订单列表', $fields, $orders);
    }
}