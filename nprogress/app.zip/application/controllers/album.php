<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Album extends CI_Controller {

    private $album = array();

    public function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->model('album_model');
    }

    public function index($album_id='')
    {
        $this->checklogin($album_id);

        $tpl_data['album'] = $this->album;

        $this->load->library('form_validation');
        $this->form_validation->set_rules('title', '相册名称', 'trim|required|max_length[20]|htmlspecialchars');
        $this->form_validation->set_rules('password', '密码', 'trim|required|max_length[7]');
        $this->form_validation->set_rules('tpl', '相册模版', 'trim|max_length[30]');
        $this->form_validation->set_rules('share_title', '分享标题', 'trim|max_length[100]');
        $this->form_validation->set_rules('share_img', '分享图标', 'trim|max_length[255]|callback__check_image');
        $this->form_validation->set_rules('share_intro', '分享描述', 'trim|max_length[200]|htmlspecialchars');
        if ($this->input->post()&&$this->form_validation->run()) {
            $data_set['password'] = $this->form_validation->set_value('password');
            $data_set['title'] = $this->form_validation->set_value('title');
            $data_set['share_title'] = $this->form_validation->set_value('share_title');
            $data_set['tpl'] = $this->form_validation->set_value('tpl');
            $data_set['share_img'] = $this->form_validation->set_value('share_img');
            $data_set['share_intro'] = $this->form_validation->set_value('share_intro');
            $music_is_sys = $this->input->post('music_is_sys');
            if( $music_is_sys ){
                $data_set['music'] = $this->input->post('music_sys');
            }else{
                $data_set['music'] = $this->input->post('music');
            }

            $data_set['music_is_sys'] = $music_is_sys ? 1 : 0;

            $this->album_model->where(array('id'=>$this->album['id']))->edit($data_set);
            if($data_set['password'] != $this->album['password'])
            {
                $this->session->unset_userdata(array(
                    'album_id'	     => '',
                    'album_username' => '',
                    'album_password' => '',
                ));
            }
            $this->show_message(TRUE, '更新成功', '/album/index/'.$album_id);
        } else {
            $errors = validation_errors();
            if ($errors) {
                $this->show_message(FALSE, $errors, '/album/index/'.$album_id);
            }
        }
        $this->load->library('encrypt');
        $token_data = array('user_id' => $this->album['site_id'], 'time' => time());
        $tpl_data['token'] = $this->encrypt->encode(serialize($token_data));

        $this->config->load('music');
        $tpl_data['music_arr'] = $this->config->item('music');

        //获取模版
        $this->load->config('tpl');
        $config_tpl = $this->config->item('album_tpl');
        $tpl_data['album_tpl'] = $config_tpl;

        $this->twig->display('album/edit', $tpl_data);
    }

    private function checklogin($album_id='')
    {
        $id = $this->session->userdata('album_id');
        $username = $this->session->userdata('album_username');
        $token = $this->session->userdata('album_password');
        if($id && $username && $token){//已经登录了
            if( $album_id!=$id ){
                redirect('/album/login/'.$album_id);
            }
            $album = $this->album_model->where(array('id'=>$id,'username' => strtoupper($username), 'password' => $token))->find();
            if (!$album) {
                $this->show_message(FALSE, '找不到该相册', '/album/login/'.$album_id);
            }
            $this->album = $album;
        }else{
            redirect('/album/login/'.$album_id);
        }
    }

    public function login($album_id='')
    {
        if( !$album_id ){
            exit('请重新获取一次地址！！！');
        }
        //登录
        $this->load->library('form_validation');
        $this->form_validation->set_rules('username', '用户名', 'trim|required');
        $this->form_validation->set_rules('password', '密码', 'trim|required');
        if ($this->input->post()&&$this->form_validation->run()) {
            $username = $this->form_validation->set_value('username');
            $password = $this->form_validation->set_value('password');
            $album = $this->album_model->where(array('id'=>$album_id,'username' => strtoupper($username), 'password' => $password))->find();
            if (!$album) {
                $this->show_message(FALSE, '用户名或密码错误', '/album/login/'.$album_id);
            }

            $sess_arr = array(
                'album_id'       => $album_id,
                'album_username' => $username,
                'album_password' => $password
            );
            $this->session->set_userdata($sess_arr);
            redirect("/album/index/".$album_id);
        } else {
            $errors = validation_errors();
            if ($errors) {
                $this->show_message(FALSE, $errors, '/album/login/'.$album_id);
            }
        }
        $this->twig->display('album/login');
    }

    public function album_img()
    {
        $id = $album_id = $this->session->userdata('album_id');
        $username = $this->session->userdata('album_username');
        $token = $this->session->userdata('album_password');
        if($id && $username && $token){//已经登录了
            $album = $this->album_model->where(array('id'=>$id,'username' => strtoupper($username), 'password' => $token))->find();
            if (!$album) {
                $this->show_message(FALSE, '找不到该相册', '/album/login/'.$album_id);
            }
            $this->album = $album;
        }else{
            redirect('/album/login/'.$album_id);
        }

        $tpl_data['album'] = $album;
        $tpl_data['album_id'] = $album['id'];
        $tpl_data['album_name'] = $album['title'];

        $this->load->model('album_img_model');
        $where['album_id'] = $album['id'];

        $this->load->library('pagination');
        $pagination_config = array(
            'base_url'		=> '/album/album_img/',
            'total_rows'	=> $this->album_img_model->where($where)->count(),
            'per_page'		=> 5,
            'uri_segment'	=> 3,
        );
        $this->pagination->initialize($pagination_config);
        $tpl_data['pagination'] = $this->pagination->create_links();
        $cur_page = $this->pagination->cur_page ? $this->pagination->cur_page : 1;
        $limit_offset = ($cur_page - 1) * $pagination_config['per_page'];
        $list = $this->album_img_model->where($where)->limit($pagination_config['per_page'], $limit_offset)->order_by('listorder ASC, id desc')->find_all();
        $tpl_data['list'] =  $list;
        $tpl_data['offset'] = $limit_offset;

        $this->load->library('encrypt');
        $token_data = array('user_id' => $album['site_id'], 'time' => time());
        $tpl_data['token'] = $this->encrypt->encode(serialize($token_data));

        $this->twig->display('album/album_img', $tpl_data);
    }

    public function album_img_add($album_id='')
    {
        $this->checklogin($album_id);
        $album = $this->album;
        if($this->input->post()){
            $add_data = array();
            $imgs = $this->input->post('photos',true);
            if($imgs){
                foreach($imgs as $val){
                    if(strlen($val['img'])<255){
                        $add_data[] = $val;
                    }else{
                        exit( json_encode( array('ret'=>1000,'msg'=>'图片格式不合法') ) );
                    }
                }
                $this->load->model('album_img_model');
                foreach($add_data as $val){
                    $temp['album_id'] = $album['id'];
                    $temp['img'] = $val['img'];
                    $temp['title'] = $val['title'];
                    $this->album_img_model->add($temp);
                }
                exit( json_encode( array('ret'=>0,'data'=>array()) ) );
            }
        }
        exit( json_encode( array('ret'=>2000,'msg'=>'没有照片上传') ) );
    }

    /**
     * @name 批量修改图片的标题和描述
     * @param string $id
     */
    public function album_img_edit($id='')
    {
        $id = $album_id = $this->session->userdata('album_id');
        $username = $this->session->userdata('album_username');
        $token = $this->session->userdata('album_password');
        if($id && $username && $token){//已经登录了
            $album = $this->album_model->where(array('id'=>$id,'username' => strtoupper($username), 'password' => $token))->find();
            if (!$album) {
                $this->show_message(FALSE, '找不到该相册', '/album/login/'.$album_id);
            }
            $this->album = $album;
        }else{
            redirect('/album/login/'.$album_id);
        }

        if($this->input->post()){
            $imgs = $this->input->post('img',true);
            if( $imgs ){
                $this->load->model('album_img_model');
                $save_img = array();
                foreach($imgs as $key=>$val){
                    if( mb_strlen($val['title'])>20 ){
                        return ($this->show_message(FALSE, '标题不能超过20个字', '/album/album_img/'));
                    }
                    if( mb_strlen($val['intro'])>200 ){
                        return ($this->show_message(FALSE, '描述不能超过200个字', '/album/album_img/'));
                    }
                    if( mb_strlen($val['extra'])>8 ){
                        return ($this->show_message(FALSE, '链接名称不能超过8个字', ''));
                    }
                    if( mb_strlen($val['extra_url'])>255 ){
                        return ($this->show_message(FALSE, '链接地址不能超过255个字', ''));
                    }
                    if( !trim($val['extra'])&&($val['extra_url']) ){
                        return ($this->show_message(FALSE, '请先填写链接名称再填写链接地址', ''));
                    }
                    $this->album_img_model->where(array('id'=>$key,'album_id'=>$album['id']))->edit(array(
                        'title' => $val['title'],
                        'intro' => htmlspecialchars($val['intro']),
                        'extra' => $val['extra'],
                        'extra_url' => $val['extra_url'],
                        'listorder' => $val['listorder'],
                        'focus_share_set' => isset($val['focus_share_set']) ? $val['focus_share_set'] : 0
                    ));
                }
            }
            return ($this->show_message(TRUE, '保存成功', '/album/album_img/'));
        }else{
            return ($this->show_message(FALSE, '非法进入', '/album/album_img/'));
        }
    }

    /**
     * @name 旋转图片
     * @param string $album_img_id
     */
    public function album_img_rotate($album_img_id='')
    {
        $id = $album_id = $this->session->userdata('album_id');
        $username = $this->session->userdata('album_username');
        $token = $this->session->userdata('album_password');
        if($id && $username && $token){//已经登录了
            $album = $this->album_model->where(array('id'=>$id,'username' => strtoupper($username), 'password' => $token))->find();
            if (!$album) {
                $this->show_message(FALSE, '找不到该相册', '/album/login/'.$album_id);
            }
            $this->album = $album;
        }else{
            redirect('/album/login/'.$album_id);
        }

        $this->load->model('album_img_model');
        $album_img = $this->album_img_model->where(array('album_id'=>$album['id'],'id'=>$album_img_id))->find();
        if( !$album_img ){
            exit(json_encode(array('ret'=> 20003, 'msg' => "该照片不存在")));
        }

        $photo = $album_img['img'];
        if( $this->img_exits($photo) ){
            exit(json_encode(array('ret'=> 20003, 'msg' => "没有找到该图片")));
        }
        $parse_url = parse_url($photo);
        $img_name = basename($photo);
        $location_dir = FCPATH.'/images/temp/' . $img_name;//本地临时保存地址
        $upload_dir = str_replace('/data', '', dirname($parse_url['path'])).'/';//图片服务器保存路径，以便覆盖原有图片

        $vals = getimagesize($photo);
        $types = array(1 => 'gif', 2 => 'jpeg', 3 => 'png');
        $mime = (isset($types[$vals['2']])) ? 'image/'.$types[$vals['2']] : 'image/jpg';
        $photo_info = array(
            'width'      => $vals[0],
            'height'     => $vals[1],
            'image_type' => $vals[2],
            'size_str'   => $vals[3],
            'mime_type'  => $mime
        );
        switch ($photo_info['image_type']){
            case 1 :
                $src_img = imagecreatefromgif($photo);break;
            case 2 :
                $src_img = imagecreatefromjpeg($photo);break;
            case 3 :
                $src_img = imagecreatefrompng($photo);break;
            default :
                exit(json_encode(array('ret'=> 2002, 'msg' => "不支持的照片格式")));
        }
        $rotate = imagerotate($src_img, -90,0);

        if( !imagejpeg($rotate,$location_dir,100) ){
            exit(json_encode(array('ret'=> 20003, 'msg' => "照片生成失败")));
        }
        imagedestroy($src_img);
        imagedestroy($rotate);

        $rotate_img = $this->rest_upload($location_dir, $upload_dir, $img_name);
        exit(json_encode(array('ret'=> 0, 'data' => $rotate_img)));
    }

    /**
     * @name 删除图片
     * @param string $album_id
     */
    public function album_img_del($album_img_id='')
    {
        $id = $album_id = $this->session->userdata('album_id');
        $username = $this->session->userdata('album_username');
        $token = $this->session->userdata('album_password');
        if($id && $username && $token){//已经登录了
            $album = $this->album_model->where(array('id'=>$id,'username' => strtoupper($username), 'password' => $token))->find();
            if (!$album) {
                $this->show_message(FALSE, '找不到该相册', '/album/login/'.$album_id);
            }
            $this->album = $album;
        }else{
            redirect('/album/login/'.$album_id);
        }
        $this->load->model('album_img_model');
        $album_img = $this->album_img_model->where(array('album_id'=>$album['id'],'id'=>$album_img_id))->find();
        if( $album_img ){
            $this->album_img_model->where(array('id'=>$album_img_id))->delete();
            return $this->show_message(true, '删除成功', '/album/album_img');
        }else{
            return ($this->show_message(FALSE, '非法进入', '/album/album_img'));
        }
    }

    public function logout($album_id='')
    {
        $this->session->unset_userdata(array(
            'album_id'       => '',
            'album_username' => '',
            'album_password' => '',
        ));

        $this->show_message(FALSE, '退出成功', '/album/login/'.$album_id);
    }

    private function show_message($success, $message, $redirect) {
        if ($this->input->is_ajax_request()) {
            $data = array(
                'success'	=> $success ? 1 : 0,
                'message'	=> strip_tags($message),
            );
            header('Content-type: application/json');
            echo json_encode($data);
        } else {
            $tpl_data = array(
                'message'	=> $message,
                'redirect'	=> $redirect,
            );
            $this->twig->display('show_message', $tpl_data);
        }
        exit;
    }

    /**
     * 上传到图片服务器,并返回图片相对路径
     */
    private function rest_upload($full_path,$upload_path='',$image_path='')
    {
        $this->load->library('rest', array(
            'server' => "http://".IMAGE_SERVER."/api",
            'app_key' => '5318162aac6f0086',
            'secret_key' => '0c28536510e0b0b429750f478222d549',
        ));

        $data = array(
            'img' => '@'.$full_path,
            'upload_path' => $upload_path,
            'img_name'  => $image_path
        );
        $result = $this->rest->post('upload/img', $data);
        @unlink($full_path);
        //$this->rest->debug();
        if(isset($result['error'])) {
            header('Content-type: application/json');
            echo json_encode(array('success' => 0, 'message' => $result['error']));
            exit;
        } else {
            return "http://".IMAGE_SERVER.$result['img'];
        }
    }

    private function img_exits($url)
    {
        $ch = curl_init();
        $timeout = 3;
        curl_setopt ($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 1);
        curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        $contents = curl_exec($ch);
        if (preg_match("/404/", $contents)){
            return true;
        }else{
            return false;
        }
    }

    //检查图片格式
    public function _check_image($image) {
        if ($image) {
            if ( ! preg_match('/[\/a-z0-9_]+\.(jpg|jpeg|gif|png)$/i', $image)) {
                $this->form_validation->set_message('_check_image', '图片地址格式错误');
                return FALSE;
            }
        }
        return TRUE;
    }
}