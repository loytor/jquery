<?php
/**
 * Created by JetBrains PhpStorm.
 * User: along
 * Date: 13-9-3
 * Time: 下午2:32
 * To change this template use File | Settings | File Templates.
 * @property Model_app_config $model_app_config
 * @property Model_invitation $model_invitation
 * @property Model_invitation $modelObj
 * @property Model_user $model_user
 */
class Invitation extends MY_Controller
{
	private $tplArr;
	private $tplType;
	private $previewPath;

	public function __construct()
	{
		parent::__construct();
		$this->load->config('tpl');
		$this->tplArr = $this->config->item('invitation_tpl');
		$this->tplType = $this->config->item('invitation_type');
		$this->previewPath = $this->config->item('preview_path');

		$this->load->model('model_invitation', 'modelObj');
		$this->load->model('model_app_config');
		$this->load->config('baidu');
	}

	public function index()
	{
		$this->load->model('model_user');
		$app_config = $this->model_app_config->get_row(array('type'=>'invitation', 'user_id'=>User::$user_id));

		$config = json_decode($app_config['config'], TRUE);

		if(!isset($config['image'])){
			$config['image'] = c_image_url('/assets/img/invitation.jpg');
		}

		//if(!isset($config['mp_name'])){
		//	$config['mp_name'] = '';
		//}
		if(!isset($config['case_id'])){
			$config['case_id'] = '';
		}
		$tpl_data['config'] = $config;

		$this->load->library('form_validation');
		$this->form_validation->set_rules('config[image]', '图片', 'trim');
		//$this->form_validation->set_rules('config[mp_name]', '公众号', 'trim|required');
		$this->form_validation->set_rules('config[case_id]', '案例ID', 'trim|callback_case_check');
		if ($this->form_validation->run()) {
			$conf = $this->input->post('config');
			if(isset($conf['case_id']) && $conf['case_id']){
				$conf['case_id'] = str_replace('，', ',', $conf['case_id']);
				$conf['case_id'] = str_replace(' ', '', $conf['case_id']);
			}
			$data_set['config'] = json_encode($conf);
			if($app_config){//更新
				$this->model_app_config->update(array('type'=>'invitation', 'user_id'=>User::$user_id), $data_set);
			}else{//添加
				$data_set['type'] = 'invitation';
				$data_set['user_id'] = User::$user_id;
				$this->model_app_config->add($data_set);
			}
			$this->show_message(TRUE, '配置保存成功', '/invitation');
		}else{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/invitation');
			}
		}

		//请柬列表
		$where_set = array('user_id' => User::$user_id);
		$this->load->library('pagination');
		$pagination_config = array(
			'base_url'		=> '/invitation/index/',
			'total_rows'	=> $this->modelObj->total_rows($where_set),
			'per_page'		=> 8,
			'uri_segment'	=> 3,
		);
		$this->pagination->initialize($pagination_config);
		$tpl_data['pagination'] = $this->pagination->create_links();

		$invitationList = $this->modelObj->get_all($where_set, $pagination_config['per_page'], intval($this->uri->segment($pagination_config['uri_segment'], 1)));
		$tpl_data['invitationList'] = $invitationList;
		$tpl_data['token'] =  $this->token;
		$tpl_data['cur_nav'] = 'marketing';
		$domain = $this->model_user->get_one(array('id' => User::$user_id), 'domain');
		$tpl_data['previewPath'] = 'http://' . $domain . '.bama555.com/';

		$this->twig->display('invitation/index',$tpl_data);
	}

	public function add()
	{
		if ($this->submitCheck()) {
			$this->modelObj->title = trim($this->input->post('title', true));
			$this->modelObj->content = htmlspecialchars($this->input->post('declarations'));
			$this->modelObj->cover_img = trim($this->input->post('cover_img', true));
			$this->modelObj->mpname = trim($this->input->post('mpname', true));
			$videoUrl = $this->input->post('video_url', true);
			$this->modelObj->video = json_encode(explode("\r\n", $videoUrl));
			$this->modelObj->photo = json_encode($this->input->post('photo'));
			$this->modelObj->tpl = trim($this->input->post('tpl', true));
			$this->modelObj->user_id = User::$user_id;
			$this->modelObj->inputtime = time();
			$this->modelObj->type = trim($this->input->post('type', true));
			$this->modelObj->enrollurl = trim($this->input->post('enrollurl', true));
			$this->modelObj->tpl  = trim($this->input->post('tpl', true));
			$address = (array)$this->input->post('address');

			$tmp = array();
            if($address){
                foreach ($address['title'] as $k => $v) {
                    $tmp[$k]['title'] = $v;
                    $tmp[$k]['date'] = $address['date'][$k];
                    $tmp[$k]['address'] = $address['address'][$k];
                    $tmp[$k]['lat'] = $address['lat'][$k];
                    $tmp[$k]['lng'] = $address['lng'][$k];
                    $tmp[$k]['tel'] = $address['tel'][$k];
                }
            }

			$this->modelObj->contacts = json_encode($tmp);
			if ($this->modelObj->add()) {
				$this->show_message(TRUE, '添加请柬成功', '/invitation/index');
			}
			else {
				$this->show_message(TRUE, '添加请柬失败', '/invitation/add');
			}
		}
		else {
			$tpl['token'] = $this->token;
			$tpl['ak'] = $this->config->item('baidu_token');
			$tpl['tpl'] = json_encode($this->tplArr);
			$tpl['type'] = $this->tplType;
			$tpl['previewPath'] = $this->previewPath;
			$this->twig->display('invitation/add', $tpl);
		}
	}


	public function delete($id='')
	{
		$invitation = $this->modelObj->get_row(array('id' => $id, 'user_id' => User::$user_id));
		if ( ! $invitation) {
			$this->show_message(FALSE, '找不到该请柬', '/invitation');
		}

		if($this->modelObj->delete(array('id' => $id))){
			$this->show_message(TRUE, '删除成功', '/invitation');
		}
		else
		{
			$this->show_message(false, '删除失败', '/invitation');
		}
	}

	public function case_check($str)
	{
		$str = str_replace('，', ',', $str);
		$arr = explode(',', $str);
		if(count($arr) > 3){
			$this->form_validation->set_message('case_check', '%s不能超过3个');
			return FALSE;
		}
		return TRUE;
	}

	public function edit()
	{
		$id = (int)$this->input->get_post('id');
		$where = array(
			'id' => $id,
			'user_id' => User::$user_id,
		);

		if ($this->submitCheck()) {
			$this->modelObj->title = trim($this->input->post('title', true));
			$this->modelObj->content = htmlspecialchars($this->input->post('declarations'));
			$this->modelObj->cover_img = trim($this->input->post('cover_img', true));
			$this->modelObj->mpname = trim($this->input->post('mpname', true));
			$videoUrl = $this->input->post('video_url', true);
			$this->modelObj->video = json_encode(explode("\r\n", $videoUrl));;
			$this->modelObj->photo = json_encode($this->input->post('photo'));
			$this->modelObj->tpl = trim($this->input->post('tpl', true));
			$this->modelObj->user_id = User::$user_id;
			$this->modelObj->inputtime = time();
			$this->modelObj->type = trim($this->input->post('type', true));
			$this->modelObj->enrollurl = trim($this->input->post('enrollurl', true));
			$this->modelObj->tpl  = trim($this->input->post('tpl', true));
			$address = (array)$this->input->post('address');

			$tmp = array();
			if (!empty($address['title'])) {
				foreach ($address['title'] as $k => $v) {
					$tmp[$k]['title'] = $v;
					$tmp[$k]['date'] = $address['date'][$k];
					$tmp[$k]['address'] = $address['address'][$k];;
					$tmp[$k]['lat'] = $address['lat'][$k];;
					$tmp[$k]['lng'] = $address['lng'][$k];;
					$tmp[$k]['tel'] = $address['tel'][$k];;
				}
			}
			$this->modelObj->contacts = json_encode($tmp);
			if ($this->modelObj->update($where)) {
				$this->show_message(TRUE, '修改请柬成功', '/invitation/index');
			}
			else {
				$this->show_message(TRUE, '修改请柬失败', '/invitation/edit?id='.$id);
			}
		}
		else {
			$tpl['token'] = $this->token;
			$tpl['ak'] = $this->config->item('baidu_token');
			$tpl['tpl'] = json_encode($this->tplArr);
			$tpl['type'] = $this->tplType;
			$tpl['previewPath'] = $this->previewPath;

			$row = $this->modelObj->get_row($where);
			$row['contacts'] = json_decode($row['contacts'], true);
			$row['photo'] = json_decode($row['photo'], true);
			$row['video'] = json_decode($row['video'], true);
			$row['video'] = implode("\r\n", $row['video']);
			$tpl['row'] = $row;
			$this->twig->display('invitation/edit', $tpl);
		}
	}
}