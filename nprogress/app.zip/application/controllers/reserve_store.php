<?php
/**
 * Created by JetBrains PhpStorm.
 * User: llj
 * Date: 13-9-14
 * Time: 下午5:19
 * To change this template use File | Settings | File Templates.
 * @property Model_reserve_store $model_reserve_store
 * @property Model_reserve_store_stuff $model_reserve_store_stuff
 * @property Model_app_config $model_app_config
 */
class Reserve_store extends MY_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('model_reserve_store');
		//$this->load->model('model_reserve_stuff');
		$this->load->model('model_reserve_store_stuff');
		$this->load->model('model_app_config');
		$this->load->config('reserve');
		$this->types_arr = $this->config->item('reserve_types');
	}

	public function index($type)
	{
		$this->has_reserve_auth($type);

		$name = $this->input->get_post('name');
		$address = $this->input->get_post('address');
		$tel = $this->input->get_post('tel');

		$tpl_data['name'] = $name ? $name : '';
		$tpl_data['address'] = $address ? $address : '';
		$tpl_data['tel'] = $tel ? $tel : '';

		$page = (int)$this->input->get('per_page');
		$page = $page ? $page : self::CUR_PAGE;
		$this->pageQueryString = true;

		$where = array('reserve_store.wid'=>User::$user_id, 'type'=>$this->types_arr[$type]['type']);
		//用于过滤查找
		$qs = array();
		if($name)
		{
			$where['name'] = 'like:'.$name;
			$qs[] = 'name='.$name;
		}
		if($address)
		{
			$where['address'] = 'like:'.$address;
			$qs[] = 'address='.$address;
		}
		if($tel)
		{
			$where['tel'] = 'like:'.$tel;
			$qs[] = 'tel='.$tel;
		}

		$queryStr = implode('&', $qs);
		$this->queryString = '?' . $queryStr;

		$list = $this->model_reserve_store->get_all_store($where, $this->pageSize, $page, 'reserve_store.sort', 'asc');
		foreach($list as &$row)
		{
			$row['image'] = json_decode($row['image'], TRUE);
		}

		$tpl_data['list'] = $list;

		//获取基本设置
		$config = $this->model_app_config->get_row(array('user_id'=>User::$user_id, 'type'=>'reserve_'.$type));
		$config = json_decode($config['config'], TRUE);
		$stuff_name  = $config && isset($config['stuff_name']) && $config['stuff_name'] ? $config['stuff_name'] :  $this->types_arr[$type]['stuff'];

		$tpl_data['type'] = $type;
		$tpl_data['type_info'] = $this->types_arr[$type];
		$tpl_data['stuff_name'] = $stuff_name;
		$tpl_data['per_page'] = $this->pageSize;
		$tpl_data['page'] = $page;
		$tpl_data['pagination'] = $this->pages($this->model_reserve_store->total_rows($where));
		$tpl_data['cur_nav'] = 'member_sys';
		$tpl_data['reserve_nav'] = 'store';
		$this->twig->display('reserve_store/index', $tpl_data);
	}

	/**
	 * 编辑门店
	 */
	public function edit($type, $id='')
	{
		$this->has_reserve_auth($type);

		$store = $this->model_reserve_store->get_store_row(array('reserve_store.id'=>$id, 'type'=>$this->types_arr[$type]['type'], 'reserve_store.wid'=>User::$user_id));
		if(!$store)
		{
			$this->show_message(FALSE, '该门店不存在', '/reserve_store/'.$type);
		}

		$this->form_validation->set_rules('business_mobile', '商家短信提醒手机号码', 'callback_bm_check');
        $this->form_validation->set_rules('business_email', '商家邮件提醒地址', 'valid_email');
		$this->form_validation->set_rules('reserve_tel', '预订电话', 'callback_rt_check');
		if($this->form_validation->run())
		{
			$data_set['business_mobile'] = $this->input->post('business_mobile');
            $data_set['business_email'] = $this->input->post('business_email');
			$data_set['instruction'] = htmlspecialchars($this->input->post('instruction'));
			$data_set['reserve_tel'] = $this->input->post('reserve_tel');
            $data_set['confirm_sms_on'] = $this->input->post('confirm_sms_on');
            $data_set['microhelper'] = $this->input->post('microhelper');
			$form_fields = $this->input->post('form_fields');
			if($form_fields)
			{
                foreach($form_fields as &$ff)
				{
					$ff['items'] = explode(',', str_replace('，',',',$ff['items']));
				}
				$data_set['form_fields'] = json_encode($form_fields);
			}

			if($this->model_reserve_store->update(array('id'=>$id, 'type'=>$this->types_arr[$type]['type'], 'wid'=>User::$user_id), $data_set))
			{
/*				$stuffs = $this->input->post('stuffs');
				//先删除所有该门店的reserve_store_stuff记录
				$this->model_reserve_store_stuff->delete(array('address_id'=>$store['address_id']));
				if($stuffs)
				{
					foreach($stuffs as $stuff_id)
					{
						$this->model_reserve_store_stuff->address_id = $store['address_id'];
						$this->model_reserve_store_stuff->stuff_id = $stuff_id;
						$this->model_reserve_store_stuff->add();
					}
				}*/
				$this->show_message(TRUE, '编辑门店成功', '/reserve_store/'.$type);
			}
			else
			{
				$this->show_message(FALSE, '编辑门店失败', '/reserve_store/edit/'.$type.'/'.$id);
			}
		}
		else
		{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/reserve_store/edit/'.$type.'/'.$id);
			}
		}

		$config = $this->model_app_config->get_row(array('user_id'=>User::$user_id, 'type'=>'reserve_form_'.$type));
		$collection = json_decode($config['config'], TRUE);
		$form_fields = array();
		if($collection)
		{
			foreach($collection as $item)
			{
				if(isset($item['store']) && $item['store'])
				{
					$item['items'] = implode(',', $item['items']);
					$form_fields[] = $item;
				}
			}
		}

		//$tpl_data['stuffs'] = $this->get_stuffs($type, $store['address_id']);
		$tpl_data['store'] = $store;
		$store_form_fields = isset($store['form_fields'])? json_decode($store['form_fields'], TRUE) : array();
		if($store_form_fields)
		{
			foreach($store_form_fields as &$sff)
			{
				$sff['items'] = implode(',', $sff['items']);
			}
		}

		$tpl_data['form_fields'] = $store_form_fields ? $store_form_fields : $form_fields;
		$tpl_data['type'] = $type;
		$tpl_data['type_info'] = $this->types_arr[$type];
		$tpl_data['cur_nav'] = 'member_sys';
		$tpl_data['reserve_nav'] = 'store';
		$this->twig->display('reserve_store/edit', $tpl_data);
	}

	public function setSort($type)
	{
		$this->has_reserve_auth($type);
		$storeid = $this->input->post('storeid');
		$sort = $this->input->post('sort');
		$sort = intval($sort);
		$dataSet = array('sort'=>$sort);
		$this->model_reserve_store->update(array('id'=>$storeid, 'type'=>$this->types_arr[$type]['type'], 'wid'=>User::$user_id), $dataSet);
	}

	public function bm_check($str)
	{
		if ($str&&!$this->valid_mobile($str))
		{
			$this->form_validation->set_message('bm_check', '%s不正确.');
			return FALSE;
		}
		else
		{
			return TRUE;
		}
	}

	public function rt_check($str)
	{
		if ($str&&!$this->valid_phone($str))
		{
			$this->form_validation->set_message('rt_check', '%s不正确.');
			return FALSE;
		}
		else
		{
			return TRUE;
		}
	}
}