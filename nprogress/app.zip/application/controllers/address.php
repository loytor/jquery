<?php
/**
 * Created by JetBrains PhpStorm.
 * User: llj
 * Date: 13-9-13
 * Time: 下午4:18
 * To change this template use File | Settings | File Templates.
 * @property Model_address $model_address
 * @property Model_app_config $model_app_config
 */
class Address extends MY_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('model_address');
		$this->load->model('model_app_config');
	}

	/**
	 *地址列表
	 */
	public function index()
	{
		$name = $this->input->get_post('name');
		$prov = $this->input->get_post('prov');
		$city= $this->input->get_post('city');
		$dist= $this->input->get_post('dist');
		$address = $this->input->get_post('address');
		$tel = $this->input->get_post('tel');

		$tpl_data['name'] = $name ? $name : '';
		$tpl_data['prov'] = $prov ? $prov : '';
		$tpl_data['city'] = $city ? $city : '';
		$tpl_data['dist'] = $dist ? $dist : '';
		$tpl_data['address'] = $address ? $address : '';
		$tpl_data['tel'] = $tel ? $tel : '';

		$page = (int)$this->input->get('per_page');
		$page = $page ? $page : self::CUR_PAGE;
		$this->pageQueryString = true;

		$where = array('wid'=>User::$user_id, 'status'=>0);
		//用于过滤查找
		$qs = array();
		if($name)
		{
			$where['name'] = 'like:'.$name;
			$qs[] = 'name='.$name;
		}
		if($prov)
		{
			$where['prov'] = 'like:'.$prov;
			$qs[] = 'prov='.$prov;
		}
		if($city)
		{
			$where['city'] = 'like:'.$city;
			$qs[] = 'city='.$city;
		}
		if($dist)
		{
			$where['dist'] = 'like:'.$dist;
			$qs[] = 'dist='.$dist;
		}
		if($address)
		{
			$where['address'] = 'like:'.$address;
			$qs[] = 'address='.$address;
		}
		if($tel)
		{
			$where['tel'] = 'like:'.$tel;
			$qs[] = 'tel='.$tel;
		}

		$queryStr = implode('&', $qs);
		$this->queryString = '?' . $queryStr;

		$list = $this->model_address->get_all($where, $this->pageSize, $page, 'rank asc,id desc', '');
		foreach($list as &$row)
		{
			$row['image'] = json_decode($row['image'], TRUE);
		}
		$tpl_data['list'] = $list;

		$tpl_data['per_page'] = $this->pageSize;
		$tpl_data['page'] = $page;
		$tpl_data['pagination'] = $this->pages($this->model_address->total_rows($where));

		$tpl_data['cur_nav'] = 'address';
		$tpl_data['address_nav'] = 'index';
		$this->twig->display('address/index', $tpl_data);
	}

	/**
	 * 添加地址
	 */
	public function add()
	{
        $printer_name = serialize($this->input->post('printer_name'));
        $printer_secret = serialize($this->input->post('printer_secret'));

		$this->form_validation->set_rules('name', '名称', 'trim|required|max_length[32]');
        $this->form_validation->set_rules('trading_pwd', '门店交易密码', 'trim|is_natural|min_length[4]|max_length[8]');
        $this->form_validation->set_rules('intro', '简介', 'trim|max_length[255]');
        $this->form_validation->set_rules('printer_name', '小票打印机名称', 'callback_printername_check['.$printer_name.']');
        $this->form_validation->set_rules('printer_secret', '小票打印机密钥', 'callback_printersecret_check['.$printer_secret.']');
        $this->form_validation->set_rules('rank', '排序', 'trim|numeric|intval');
		if($this->form_validation->run())
		{
			$this->model_address->wid = User::$user_id;
			$this->model_address->name = $this->form_validation->set_value('name');
			$this->model_address->icon = $this->input->post('icon');
			$this->model_address->image = json_encode($this->input->post('image'));
			$this->model_address->prov = $this->input->post('prov');
			$this->model_address->city = $this->input->post('city');
			$this->model_address->dist = $this->input->post('dist');
			$this->model_address->address = $this->input->post('address');
			$this->model_address->lat = $this->input->post('lat');
			$this->model_address->lng = $this->input->post('lng');
			$this->model_address->tel = implode(',', $this->input->post('tel'));
			$this->model_address->intro = $this->form_validation->set_value('intro');
			$this->model_address->desc = $this->input->post('desc');
            $this->model_address->trading_pwd = $this->form_validation->set_value('trading_pwd');
            $this->model_address->dayinji_type = intval($this->input->post('dayinji_type'));
            $this->model_address->printer_name = implode(',', $this->input->post('printer_name'));
            $this->model_address->printer_secret = implode(',', $this->input->post('printer_secret'));
            $this->model_address->rank = $this->form_validation->set_value('rank');            

			if($this->model_address->add(array(), true))
			{
				$this->show_message(TRUE, '添加地址成功', '/address');
			}
			else
			{
				$this->show_message(FALSE, '添加地址失败', '/address/add/');
			}
		}
		else
		{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/address/add');
			}
		}

		$tpl_data['token'] = $this->token;
		$tpl_data['cur_nav'] = 'address';
        $this->load->model('model_user');
        $tpl_data['user'] = $this->model_user->get_row(array('id'=>User::$user_id));
		$this->twig->display('address/add', $tpl_data);
	}

	/**
	 * @param $id
	 * 编辑地址
	 */
	public function edit($id)
	{
		$address = $this->model_address->get_row(array('id'=>$id, 'wid'=>User::$user_id));
		if(!$address)
		{
			$this->show_message(FALSE, '该地址不存在', '/address');
		}

		$address['image_arr'] = json_decode($address['image'], TRUE);
		$address['tel'] = explode(',', $address['tel']);
        $address['printer_name'] = explode(',', $address['printer_name']);
        $address['printer_secret'] = explode(',', $address['printer_secret']);
        $printer = array();
        foreach($address['printer_name'] as $k=>$v)
        {
            $printer[$k]['name'] = $v;
            $printer[$k]['secret'] = $address['printer_secret'][$k];
        }
        $address['printer'] = $printer;
		$tpl_data['address'] = $address;

        $printer_name = serialize($this->input->post('printer_name'));
        $printer_secret = serialize($this->input->post('printer_secret'));

		$this->form_validation->set_rules('name', '名称', 'trim|required|max_length[32]');
		$this->form_validation->set_rules('intro', '简介', 'trim|max_length[255]');
        $this->form_validation->set_rules('printer_name', '小票打印机名称', 'callback_printername_check['.$printer_name.']');
        $this->form_validation->set_rules('printer_secret', '小票打印机密钥', 'callback_printersecret_check['.$printer_secret.']');
        $this->form_validation->set_rules('rank', '排序', 'trim|numeric|intval');
		if($this->form_validation->run())
		{
			$data_set['name'] = $this->form_validation->set_value('name');
			$data_set['icon'] = $this->input->post('icon');
			$data_set['image'] = json_encode($this->input->post('image'));
			$data_set['prov'] = $this->input->post('prov');
			$data_set['city'] = $this->input->post('city');
			$data_set['dist'] = $this->input->post('dist');
			$data_set['address'] = $this->input->post('address');
			$data_set['lat'] = $this->input->post('lat');
			$data_set['lng'] = $this->input->post('lng');
			$data_set['tel'] = implode(',', $this->input->post('tel'));
			$data_set['intro'] = $this->form_validation->set_value('intro');
			$data_set['desc'] = $this->input->post('desc');
            $data_set['dayinji_type'] = intval($this->input->post('dayinji_type'));
            $data_set['printer_name'] = implode(',', $this->input->post('printer_name'));
            $data_set['printer_secret'] = implode(',', $this->input->post('printer_secret'));
            $data_set['rank'] = $this->form_validation->set_value('rank');

			if($this->model_address->update(array('id'=>$id, 'wid'=>User::$user_id), $data_set))
			{
				$this->show_message(TRUE, '编辑地址成功', '/address');
			}
			else
			{
				$this->show_message(FALSE, '编辑地址失败', '/address/edit/'.$id);
			}
		}
		else
		{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/address/edit/'.$id);
			}
		}

		$tpl_data['token'] = $this->token;
		$tpl_data['cur_nav'] = 'address';
        $this->load->model('model_user');
        $tpl_data['user'] = $this->model_user->get_row(array('id'=>User::$user_id));
		$this->twig->display('address/edit', $tpl_data);
	}

    public function printername_check($str, $printer_name) {
        $printer_name = unserialize($printer_name);
        if(count($printer_name) < 1) {
            $this->form_validation->set_message('printername_check', '%s至少需要1项');
            return FALSE;
        }else{
            $error = array();
            foreach($printer_name as $vs) {
                if($vs != '' && strlen($vs) >10 && !isset($error['name'])){
                    $error['name'] = '小票打印机名称';
                }
            }
            if(isset($error['name'])){
                $s = $error['name'];
                $this->form_validation->set_message('printername_check', $s.'最长不能超过10个字符');
                return FALSE;
            }
        }
        return true;
    }


    public function printersecret_check($str, $printer_secret) {
        $printer_secret = unserialize($printer_secret);
        if(count($printer_secret) < 1) {
            $this->form_validation->set_message('printersecret_check', '%s至少需要1项');
            return FALSE;
        }else{
            $error = array();
            foreach($printer_secret as $vs) {
                if($vs != '' && strlen($vs) >10 && !isset($error['name'])){
                    $error['name'] = '小票打印机密钥';;
                }
            }
            if(isset($error['name'])){
                $s = $error['name'];
                $this->form_validation->set_message('printersecret_check', $s.'最长不能超过10个字符');
                return FALSE;
            }
        }
        return true;
    }

	/**
	 * @param $id
	 * 删除地址
	 */
	public function delete($id)
	{
		$address = $this->model_address->get_row(array('id'=>$id, 'wid'=>User::$user_id));
		if(!$address)
		{
			$this->show_message(FALSE, '该地址不存在', '/address');
		}
		$data_set['status'] = -1;
		if($this->model_address->update(array('id'=>$id, 'wid'=>User::$user_id), $data_set))
		{
			$this->show_message(TRUE, '删除地址成功', '/address');
		}
		else
		{
			$this->show_message(FALSE, '删除地址失败', '/address');
		}
	}

	/**
	 * 地址管理基本设置
	 */
	public function setting()
	{
		$address_setting = $this->model_app_config->get_row(array('user_id'=>User::$user_id, 'type'=>'address'));

		$this->form_validation->set_rules('lbs', 'LBS地址回复个数', 'trim');
		if($this->form_validation->run())
		{
			$lbs = $this->input->post('lbs');
			$last_title = $this->input->post('last_title');
			$last_url = $this->input->post('last_url');
            $more_url = $this->input->post('more_url');

			$config['lbs'] = $lbs;
			$config['last_title'] = $last_title;
			$config['last_url'] = $last_url;
            $config['more_url'] = $more_url;

			$data_set['config'] = json_encode($config);
			if($address_setting)
			{
				if($this->model_app_config->update(array('user_id'=>User::$user_id, 'type'=>'address'), $data_set))
				{
					$this->show_message(TRUE, '设置成功', '/address/setting');
				}
				else
				{
					$this->show_message(FALSE, '设置失败', '/address/setting');
				}
			}
			else
			{
				$data_set['type'] = 'address';
				$data_set['user_id'] = User::$user_id;
				if($this->model_app_config->add($data_set))
				{
					$this->show_message(TRUE, '设置成功', '/address/setting');
				}
				else
				{
					$this->show_message(FALSE, '设置失败', '/address/setting');
				}
			}
		}
		else
		{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/address/setting');
			}
		}

		if(isset($address_setting['config']))
		{
			$address_config = json_decode($address_setting['config'], TRUE);
		}
		if(!isset($address_config['lbs']))
		{
			$address_config['lbs'] = 1;
		}
		if(!isset($address_config['last_title']))
		{
			$address_config['last_title'] = '点击进入微网站';
		}
		if(!isset($address_config['last_url']))
		{
			$domain = $this->session->userdata('domain');
			$address_config['last_url'] = "http://".$domain.".bama555.com";
		}
        if(!isset($address_config['more_url']))
        {
            $address_config['more_url'] = "";
        }
		$tpl_data['address_config'] = $address_config;
		$tpl_data['cur_nav'] = 'address';
		$tpl_data['address_nav'] = 'setting';
		$this->twig->display('address/setting', $tpl_data);
	}

    /**
     * 设置交易密码
     */
    public function set_pwd($id)
    {
        $address = $this->model_address->get_row(array('id'=>$id, 'wid'=>User::$user_id));
        if(!$address)
        {
            $this->show_message(FALSE, '该地址不存在', '/address/set_pwd/'.$id);
        }

        $tpl_data['address'] = $address;
        if($address['trading_pwd']) { //重置交易密码
            $this->form_validation->set_rules('cur_pass', '当前密码', 'trim|required|is_natural|min_length[4]|max_length[8]|callback_check_curpass['.$id.']');
            $this->form_validation->set_rules('password', '新密码', 'trim|required|is_natural|min_length[4]|max_length[8]|callback_check_pass');
            $this->form_validation->set_rules('conf_pass', '确认新密码', 'trim|required|is_natural|min_length[4]|max_length[8]|matches[password]');
        } else { //新设置交易密阿玛
            $this->form_validation->set_rules('password', '密码', 'trim|required|is_natural|min_length[4]|max_length[8]|callback_check_pass');
            $this->form_validation->set_rules('conf_pass', '确认新密码', 'trim|required|is_natural|min_length[4]|max_length[8]|matches[password]');
        }
        if($this->form_validation->run()) {
            $data_set['trading_pwd'] = md5($this->form_validation->set_value('password'));
            if($this->model_address->update(array('id'=>$id, 'wid'=>User::$user_id), $data_set))
            {
                $this->show_message(TRUE, '保存成功', '/address/set_pwd/'.$id);
            }
            else
            {
                $this->show_message(FALSE, '保存失败', '/address/set_pwd/'.$id);
            }
        } else {
            $errors = validation_errors();
            if ($errors) {
                $this->show_message(FALSE, $errors, '/address/set_pwd/'.$id);
                return FALSE;
            }
        }

        $this->twig->display('address/set_pwd', $tpl_data);
    }

    /**
     * @param $id
     * 找回交易密码
     */
    public function retrieve_pwd($id)
    {
        $address = $this->model_address->get_row(array('id'=>$id, 'wid'=>User::$user_id));
        if(!$address)
        {
            $this->show_message(FALSE, '该地址不存在', '/address/set_pwd/'.$id);
        }
        $this->load->model('model_user');
        $to_email = $this->model_user->get_one(array('id'=>User::$user_id), 'email');
        if(!$to_email)
        {
            $this->show_message(FALSE, '您还未设置邮箱，请联系代理商并提供您的邮箱进行设置', '/address/set_pwd/'.$id);
        }
        $this->load->config('email');
        $this->load->library('email');


        //$to_email = '306302160@qq.com';//'luisfigook@hotmail.com';
        //$to_email = 'congget@163.com';
        $pass = rand(100000, 999999);
        $from_email = $this->config->item('smtp_user');//'support@bama555.com';
        $from_name = 'support';
        $message = "您好：\r\n您的(".$address['name'].")交易密码已被重置为".$pass.",\r\n请赶快登录微网站后台重置您的新密码！";
        $this->email->from($from_email, $from_name);
        $this->email->to($to_email);
        $this->email->subject('找回('.$address['name'].')交易密码');
        $this->email->message($message);

        if($this->email->send() && $this->model_address->update(array('id'=>$id, 'wid'=>User::$user_id), array('trading_pwd'=>md5($pass))))
        {
            $this->show_message(TRUE, '请及时查看您的邮件（'.$to_email.'），并重置您的('.$address['name'].')新密码', '/address/set_pwd/'.$id);
        }
        else
        {
            $this->show_message(FALSE, '找回密码失败，请稍后重试', '/address/set_pwd/'.$id);
        }
    }

    //交易密码设置里检查当前密码是否正确
    public function check_curpass($pass, $id)
    {
        $address = $this->model_address->get_row(array('id'=>$id, 'wid'=>User::$user_id, 'trading_pwd'=>md5($pass)));
        if(!$address)
        {
            $this->form_validation->set_message('check_curpass', '当前密码不正确');
            return FALSE;
        }
        return TRUE;
    }

    /**
     * @param $pass
     * @param $id
     * @return bool
     * 判断交易密码在门店地址中是否重复
     */
    public function check_pass($pass)
    {
        $this->load->model('model_user');
        $user = $this->model_user->get_row(array('id'=>User::$user_id));
        if($user['trading_pwd'] == md5($pass)) {
            $this->form_validation->set_message('check_pass', '门店交易密码不能和商家交易密码重复');
            return FALSE;
        }else{
            $address_list = $this->model_address->get_all(array('wid'=>User::$user_id, 'status !='=>-1));
            foreach($address_list as $ad) {
                if(md5($pass) == $ad['trading_pwd']){
                    $this->form_validation->set_message('check_pass', '密码不能和其他门店重复');
                    return FALSE;
                }
            }
        }

        return TRUE;
    }
}