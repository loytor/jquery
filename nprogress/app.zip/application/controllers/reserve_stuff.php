<?php
/**
 * Created by JetBrains PhpStorm.
 * User: llj
 * Date: 13-9-11
 * Time: 下午3:52
 * To change this template use File | Settings | File Templates.
 * @property Model_reserve_store_stuff $model_reserve_store_stuff
 * @property Model_app_config $model_app_config
 * @property Model_reserve_store $model_reserve_store
 * @property Model_reserve_store_category $model_reserve_store_category
 * @property Model_reserve_stuff_category $model_reserve_stuff_category
 */
class Reserve_stuff extends MY_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('model_reserve_store_stuff');
		$this->load->model('model_reserve_store_category');
		$this->load->model('model_reserve_stuff_category');
		$this->load->model('model_reserve_store');
		$this->load->model('model_app_config');
		$this->load->config('reserve');
		$this->types_arr = $this->config->item('reserve_types');
	}

	//预订对象列表
	public function index($type)
	{
		$this->has_reserve_auth($type);

		$id = $this->input->get('id');
		$store = $this->model_reserve_store->get_store_row(array('reserve_store.id'=>$id, 'type'=>$this->types_arr[$type]['type'], 'reserve_store.wid'=>User::$user_id));
		if(!$store)
		{
			$this->show_message(FALSE, '该门店不存在', '/reserve_store/'.$type);
		}
		$tpl_data['store'] = $store;

		$name = $this->input->get_post('name');
		$store_price = $this->input->get_post('store_price');
		$reserve_price = $this->input->get_post('reserve_price');

		$tpl_data['name'] = $name ? $name : '';
		$tpl_data['store_price'] = $store_price ? $store_price : '';
		$tpl_data['reserve_price'] = $reserve_price ? $reserve_price : '';

		$page = (int)$this->input->get('per_page');
		$page = $page ? $page : self::CUR_PAGE;
		$this->pageQueryString = true;

		$where = array('address_id'=>$store['address_id'], 'wid'=>User::$user_id, 'type'=>$this->types_arr[$type]['type']);
		//用于过滤查找
		$qs = array();
		if($name)
		{
			$where['name'] = 'like:'.$name;
			$qs[] = 'name='.$name;
		}
		if($store_price)
		{
			$where['store_price'] = 'like:'.$store_price;
			$qs[] = 'store_price='.$store_price;
		}
		if($reserve_price)
		{
			$where['reserve_price'] = 'like:'.$reserve_price;
			$qs[] = 'reserve_price='.$reserve_price;
		}

		$queryStr = implode('&', $qs);
		$this->queryString = '?id='. $id . $queryStr;

		$list = $this->model_reserve_store_stuff->get_all($where, $this->pageSize, $page, 'sort', 'asc');
		if( $type=='room' || $type=='ktv' ){
    		foreach ( $list as $key=>$val ){
                if( $val['num']==-1 ){
                    $list[$key]['num'] = '不限';
                }else{
                    //查找订单
                    $has_num = $this->get_today_order($val['id']);
                    $list[$key]['num'] = $val['num'] - $has_num;
                }
            }
		}
		$tpl_data['list'] = $list;

		$tpl_data['stuff_name'] = $this->getStuffName($type);
		$tpl_data['type'] = $type;
		$tpl_data['type_info'] = $this->types_arr[$type];
		$tpl_data['per_page'] = $this->pageSize;
		$tpl_data['page'] = $page;
		$tpl_data['pagination'] = $this->pages($this->model_reserve_store_stuff->total_rows($where));
		$tpl_data['cur_nav'] = 'member_sys';
		$this->twig->display('reserve_stuff/index', $tpl_data);
	}

	private function get_today_order($stuff_id)
	{
	    $this->load->model('model_reserve_order_stuff');
	    return $this->model_reserve_order_stuff->get_today_order($stuff_id);
	}



	/**
	 * @param $type
	 * @param $store_id
	 * 添加门店预订对象
	 */
	public function add($type, $store_id)
	{
		$this->has_reserve_auth($type);

		$store = $this->model_reserve_store->get_store_row(array('reserve_store.id'=>$store_id, 'type'=>$this->types_arr[$type]['type'], 'reserve_store.wid'=>User::$user_id));
		if(!$store)
		{
			$this->show_message(FALSE, '该门店不存在', '/reserve_store/'.$type);
		}
		$tpl_data['store'] = $store;


		$stuff_prefix =$this->types_arr[$type]['stuff'];

		$this->form_validation->set_rules('name', $stuff_prefix.'名称', 'trim|required|max_length[32]');
		$this->form_validation->set_rules('sort', '排序', 'trim|is_natural');
		$this->form_validation->set_rules('num', '数量', 'trim');
		if($this->form_validation->run())
		{
			$this->model_reserve_store_stuff->address_id = $store['address_id'];
			$this->model_reserve_store_stuff->wid = User::$user_id;
			$this->model_reserve_store_stuff->type = $this->types_arr[$type]['type'];
			$this->model_reserve_store_stuff->name = $this->form_validation->set_value('name');
			$this->model_reserve_store_stuff->icon = $this->input->post('icon');
			$this->model_reserve_store_stuff->num  = $this->input->post('num')=='' ? -1 : $this->input->post('num');
            $this->model_reserve_store_stuff->max_time_limit = $this->input->post('max_time_limit');
			$this->model_reserve_store_stuff->desc = $this->input->post('desc');
			$this->model_reserve_store_stuff->store_price = $this->input->post('store_price');
			$this->model_reserve_store_stuff->reserve_price = number_format(floatval($this->input->post('reserve_price')), 2, '.', '');
			$this->model_reserve_store_stuff->enabled = $this->input->post('enabled');
			$this->model_reserve_store_stuff->sort = (int)$this->input->post('sort');
			$this->model_reserve_store_stuff->property = json_encode($this->input->post('property'));

            if( $this->model_reserve_store_stuff->reserve_price<0 ){
                $this->show_message(FALSE, '预定价格不能小于0', '');
            }

			$new_stuff_id = $this->model_reserve_store_stuff->add(array(), TRUE);
			if($new_stuff_id)
			{
				$categorys = $this->input->post('category');
				//添加到预订对象分类关联表
				if($categorys)
				{
					foreach($categorys as $cid)
					{
						$this->model_reserve_stuff_category->stuff_id = $new_stuff_id;
						$this->model_reserve_stuff_category->category_id = $cid;
						$this->model_reserve_stuff_category->add();
					}
				}
				$this->show_message(TRUE, '添加'.$stuff_prefix.'成功', '/reserve_stuff/'.$type.'?id='.$store_id);
			}
			else
			{
				$this->show_message(FALSE, '添加'.$stuff_prefix.'失败', '/reserve_stuff/add/'.$type.'/'.$store_id);
			}
		}
		else
		{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/reserve_stuff/add/'.$type.'/'.$store_id);
			}
		}

		$tpl_data['stuff_name'] = $this->getStuffName($type);
		$tpl_data['categorys'] = $this->get_categorys($type, $store_id);
		$tpl_data['extend_fields'] = $this->extend_fields($type);
		$tpl_data['type'] = $type;
		$tpl_data['type_info'] = $this->types_arr[$type];
		$tpl_data['token'] = $this->token;
		$tpl_data['cur_nav'] = 'member_sys';
		$this->twig->display('reserve_stuff/add', $tpl_data);
	}

	/**
	 * @param $type
	 * @param $store_id
	 * @param $id
	 * 编辑门店预订对象
	 */
	public function edit($type, $store_id, $id)
	{
		$this->has_reserve_auth($type);

		$store = $this->model_reserve_store->get_store_row(array('reserve_store.id'=>$store_id, 'type'=>$this->types_arr[$type]['type'], 'reserve_store.wid'=>User::$user_id));
		if(!$store)
		{
			$this->show_message(FALSE, '该门店不存在', '/reserve_store/'.$type);
		}
		$tpl_data['store'] = $store;

		$stuff_prefix =$this->types_arr[$type]['stuff'];

		$where = array('id'=>$id, 'address_id'=>$store['address_id'], 'type'=>$this->types_arr[$type]['type'], 'wid'=>User::$user_id);
		$stuff = $this->model_reserve_store_stuff->get_row($where);
		if(!$stuff)
		{
			$this->show_message(FALSE, '该'.$stuff_prefix.'不存在', '/reserve_stuff/'.$type.'?id='.$store_id);
		}
		$tpl_data['property'] = json_decode($stuff['property'], TRUE);

		$this->form_validation->set_rules('name', $stuff_prefix.'名称', 'trim|required|max_length[32]');
		$this->form_validation->set_rules('sort', '排序', 'trim|is_natural');
		$this->form_validation->set_rules('num', '数量', 'trim');
		if($this->form_validation->run())
		{
			$data_set['name'] = $this->form_validation->set_value('name');
			$data_set['icon'] = $this->input->post('icon');
			$data_set['num']  = $this->input->post('num')=='' ? -1 : $this->input->post('num');
            $data_set['max_time_limit'] = $this->input->post('max_time_limit');
			$data_set['desc'] = $this->input->post('desc');
			$data_set['store_price'] = $this->input->post('store_price');
			$data_set['reserve_price'] = number_format(floatval($this->input->post('reserve_price')), 2, '.', '');
			$data_set['enabled'] = $this->input->post('enabled');
			$data_set['sort'] = (int)$this->input->post('sort');
			$data_set['property'] = json_encode($this->input->post('property'));

            if( $data_set['reserve_price']<0 ){
                $this->show_message(FALSE, '预定价格不能小于0', '');
            }

			if($this->model_reserve_store_stuff->update($where, $data_set))
			{
				$categorys = $this->input->post('category');
				//删除预订该预订对象在关联表中的记录
				$this->model_reserve_stuff_category->delete(array('stuff_id'=>$id));
				//添加到预订对象分类关联表
                if($categorys){
                    foreach($categorys as $cid)
                    {
                        $this->model_reserve_stuff_category->stuff_id = $id;
                        $this->model_reserve_stuff_category->category_id = $cid;
                        $this->model_reserve_stuff_category->add();
                    }
                }

				$this->show_message(TRUE, '编辑'.$stuff_prefix.'成功', '/reserve_stuff/'.$type.'?id='.$store_id);
			}
			else
			{
				$this->show_message(FALSE, '编辑'.$stuff_prefix.'失败', '/reserve_stuff/edit/'.$type.'/'.$store_id.'/'.$id);
			}
		}
		else
		{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/reserve_stuff/edit/'.$type.'/'.$store_id.'/'.$id);
			}
		}

		$tpl_data['stuff_name'] = $this->getStuffName($type);
		$tpl_data['stuff'] = $stuff;
		$tpl_data['categorys'] = $this->get_categorys($type, $store_id, $id);
		$tpl_data['extend_fields'] = $this->extend_fields($type);
		$tpl_data['type'] = $type;
		$tpl_data['type_info'] = $this->types_arr[$type];
		$tpl_data['token'] = $this->token;
		$tpl_data['cur_nav'] = 'member_sys';
		$this->twig->display('reserve_stuff/edit', $tpl_data);
	}

	/**
	 * @param $type
	 * @param $store_id
	 * @param $id
	 * 删除门店预订对象
	 */
	public function delete($type, $store_id, $id)
	{
		$this->has_reserve_auth($type);

		$store = $this->model_reserve_store->get_store_row(array('reserve_store.id'=>$store_id, 'type'=>$this->types_arr[$type]['type'], 'reserve_store.wid'=>User::$user_id));
		if(!$store)
		{
			$this->show_message(FALSE, '该门店不存在', '/reserve_store/'.$type);
		}
		$tpl_data['store'] = $store;

		$stuff_prefix =$this->types_arr[$type]['stuff'];

		$where = array('id'=>$id, 'address_id'=>$store['address_id'], 'type'=>$this->types_arr[$type]['type'], 'wid'=>User::$user_id);
		$stuff = $this->model_reserve_store_stuff->get_row($where);
		if(!$stuff)
		{
			$this->show_message(FALSE, '该'.$stuff_prefix.'不存在', '/reserve_stuff/'.$type.'?id='.$store_id);
		}

		if($this->model_reserve_store_stuff->delete($where))
		{
			$this->show_message(TRUE, '删除'.$stuff_prefix.'成功', '/reserve_stuff/'.$type.'?id='.$store_id);
		}
		else
		{
			$this->show_message(FALSE, '删除'.$stuff_prefix.'失败', '/reserve_stuff/'.$type.'?id='.$store_id);
		}
	}

	//获取扩展字段
	private function extend_fields($type)
	{
		$config = $this->model_app_config->get_one(array('user_id'=>User::$user_id, 'type'=>'reserve_stuff_'.$type), 'config');
		$config = json_decode($config, TRUE);
		$extend_fields = $config['url'];
		if(!$extend_fields)
		{
			$default_config = $this->config->item($type.'_stuff');
			$extend_fields = isset($default_config['url']) ? $default_config['url'] : '';
		}
		return $extend_fields;
	}


	/**
	 * @param $type
	 * @param $store_id
	 * @return array
	 * 获取该门店分类
	 */
	private function get_categorys($type, $store_id, $stuff_id='')
	{
		$store = $this->model_reserve_store->get_store_row(array('reserve_store.id'=>$store_id, 'type'=>$this->types_arr[$type]['type'], 'reserve_store.wid'=>User::$user_id));
		if(!$store)
		{
			$this->show_message(FALSE, '该门店不存在', '/reserve_store/'.$type);
		}

		//获取所有该门店的分类
		$where = array('address_id'=>$store['address_id'], 'wid'=>User::$user_id, 'type'=>$this->types_arr[$type]['type'], 'status !='=>-1);
		$categorys = $this->model_reserve_store_category->get_all($where, '', '', 'sort', 'asc');

		$stuff_category_ids = array();
		if($stuff_id)
		{
			//获取该预订对象所属的分类
			$stuff_categorys = $this->model_reserve_stuff_category->get_all(array('stuff_id'=>$stuff_id), '', '');
			if($stuff_categorys)
			{
				foreach($stuff_categorys as $sc)
				{
					$stuff_category_ids[] = $sc['category_id'];
				}
			}
		}

		if($categorys)
		{
			foreach($categorys as &$cate)
			{
				if(in_array($cate['id'], $stuff_category_ids))
				{
					$cate['checked'] = 1;
				}
				else
				{
					$cate['checked'] = 0;
				}
			}
		}

		return $categorys ? $categorys : array();
	}

	private function getStuffName($type)
	{
		//获取基本设置
		$config = $this->model_app_config->get_row(array('user_id'=>User::$user_id, 'type'=>'reserve_'.$type));
		$config = json_decode($config['config'], TRUE);
		$stuff_name  = $config && isset($config['stuff_name']) && $config['stuff_name'] ? $config['stuff_name'] :  $this->types_arr[$type]['stuff'];
		return $stuff_name;
	}
}