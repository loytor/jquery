<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Created by JetBrains PhpStorm.
 * User: llj
 * Date: 13-8-20
 * Time: 下午1:46
 * To change this template use File | Settings | File Templates.
 * 会员卡系统
 * @property Model_account $model_account
 * @property Model_action_record $model_action_record
 * @property Model_app_config $model_app_config
 * @property Mongo_db $mongo_db
 */
class Member_sys extends MY_Controller
{
    protected $fields_table = 'account_fields';
    protected $field_value_table = 'account_field_value';

	public function __construct()
	{
		parent::__construct();
		$this->load->model('model_account');

		//获取用户权限
		$this->load->model('model_user_authority');
		$user_authority = $this->model_user_authority->get_row(array('user_id'=>User::$user_id));

		$authority = array();
		if($user_authority['authority'])
		{

			$this->config->load('authority');
			$confAuthority = (array)$this->config->item('authority');
			foreach($confAuthority as $key=>$ca){
				if($ca[2]==1 && $user_authority['authority'] & $ca[0]){
					$authority[$key] = $ca;
				}
			}
		}

		$this->authority = $authority;

	}

	public function index()
	{
		$wxid = $this->input->get_post('wxid');
		$mobile = $this->input->get_post('mobile');
		$name = $this->input->get_post('name');
		$from_time = $this->input->get_post('from_time');
		$to_time = $this->input->get_post('to_time');
		$invite_account_id = $this->input->get_post('invite_account_id');

		$tpl_data['wxid'] = $wxid ? $wxid : '';
		$tpl_data['mobile'] = $mobile ? $mobile : '';
		$tpl_data['name'] = $name ? $name : '';
		$tpl_data['from_time'] = $from_time ? $from_time : '';
		$tpl_data['to_time'] = $to_time ? $to_time : '';
		$tpl_data['invite_account_id'] = $invite_account_id ? $invite_account_id : '';

		$where = array('wid'=>User::$user_id);
		//用于筛选过滤
		$qs = array();
		if($wxid)
		{
			$where['wxid'] = "like:".$wxid;
			$qs[] = 'wxid='.$wxid;
		}
		if($name)
		{
			$where['name'] = "like:".$name;
			$qs[] = 'name='.$name;
		}
		if($mobile)
		{
			$where['mobile'] = "like:".$mobile;
			$qs[] = 'mobile='.$mobile;
		}
		if($from_time)
		{
			$where['dt_add >= '] = strtotime($from_time);
			$qs[] = 'from_time='.$from_time;
		}
		if($to_time)
		{
			$where['dt_add <= '] = strtotime($to_time);
			$qs[] = 'to_time='.$to_time;
		}

		//用于邀请人手机号筛选过滤
		if($invite_account_id)
		{
			$rows = $this->model_account->get_all(array('wid'=>User::$user_id, 'id'=>'like:'.$invite_account_id));
			if($rows){
				foreach($rows as $r)
				{
					$where['in:invite_account_id'][] = $r['id'];
				}
			}
			else
			{
				$where['1'] = 2;
			}
			$qs[] = 'invite_account_id='.$invite_account_id;
		}

		$page = $this->input->get('per_page');
		$page = $page ? $page : self::CUR_PAGE;
		$queryStr = implode('&', $qs);
		$this->queryString = '?' . $queryStr;
		$this->pageQueryString = true;

		$accounts = $this->model_account->get_all($where, $this->pageSize, $page, 'dt_add', 'DESC');
		foreach($accounts as &$account)
		{
			$account['wxid'] = substr($account['wxid'], 0, strlen($account['wxid'])-6).'******';
			$account['dt_add'] = date('Y-m-d H:i:s', $account['dt_add']);
		}

		$tpl_data['accounts'] = $accounts;
		$tpl_data['per_page'] = $this->pageSize;
		$tpl_data['page'] = $page;
		$tpl_data['pagination'] = $this->pages($this->model_account->total_rows($where));
		$tpl_data['authority'] = $this->authority;

		$tpl_data['cur_nav'] = 'member_sys';
		$this->twig->display('member_sys/index', $tpl_data);
	}

	//重置密码
	public function reset_pass($uid='')
	{
		$account = $this->model_account->get_row(array('id'=>$uid, 'wid'=>User::$user_id));
		if(!$account)
		{
			$this->show_message(FALSE, '该用户帐号不存在', '/member_sys');
		}

		$this->form_validation->set_rules('new_pass', '新密码', 'trim|required');
		$this->form_validation->set_rules('conf_pass', '确认新密码', 'trim|required|matches[new_pass]');
		if($this->form_validation->run())
		{
			$data_set['password'] = md5($this->form_validation->set_value('new_pass'));
			$data_set['dt_update'] = time();
			if($this->model_account->update(array('id'=>$uid), $data_set))
			{
				$this->show_message(TRUE, '重置密码成功', '/member_sys');
			}
			else
			{
				$this->show_message(TRUE, '重置密码失败', '/member_sys/reset_pass/'.$uid);
			}
		}
		else
		{
			$errors = validation_errors();
			if ($errors) {
				$this->show_message(FALSE, $errors, '/member_sys/reset_pass/'.$uid);
			}
		}

		$tpl_data['cur_nav'] = 'member_sys';
		$this->twig->display('member_sys/reset_pass', $tpl_data);
	}

	//解除微信绑定
	public function unbind($uid='')
	{
		$account = $this->model_account->get_row(array('id' => $uid, 'wid'=>User::$user_id));
		if (!$account) {
			$this->show_message(FALSE, '该用户帐号不存在', '/member_sys');
		}

		if($this->model_account->update(array('id' => $uid), array('wxid'=>''))){
			//添加帐号类解绑微信行为scope=0, type=5, sub_type=0
			$action_data = array();
			$action_data['scope'] = 0;
			$action_data['type'] = 5;
			$action_data['sub_type'] = 0;
			$action_data['uid'] = $uid;
			$this->action_record($action_data);

			$this->show_message(TRUE, '解除绑定成功', '/member_sys');
		}else{
			$this->show_message(FALSE, '解除绑定失败', '/member_sys');
		}
	}

	/**
	 * @param string $uid
	 * @param int $page
	 * 查看用户行为
	 */
	public function userlog($uid='', $page=0)
	{
		$account = $this->model_account->get_row(array('id'=>$uid, 'wid'=>User::$user_id));
		if(!$account)
		{
			$this->show_message(FALSE, '该用户帐号不存在', '/member_sys');
		}

		$tpl_data['uid'] = $uid;

		$this->load->config('action_record');
		$config_action_record = $this->config->item('action_record');
		$all_type_arr = $this->config->item('all_type');

		$action_type = $this->input->get_post('action_type');
		$value = $this->input->get_post('value');
		$memo = $this->input->get_post('memo');
		$from_time = $this->input->get_post('from_time');
		$to_time = $this->input->get_post('to_time');

		$tpl_data['action_type'] = $action_type ? $action_type : '';
		$tpl_data['value'] = $value ? $value : '';
		$tpl_data['memo'] = $memo ? $memo : '';
		$tpl_data['from_time'] = $from_time ? $from_time : '';
		$tpl_data['to_time'] = $to_time ? $to_time : '';

		$where = array('uid'=>$uid, 'wid'=>User::$user_id);
		$qs = array();
		if($action_type)
		{
			$action_type_arr = explode('_', $action_type);
			$where['scope'] = $action_type_arr[0];
			$where['type'] = $action_type_arr[1];
			$where['sub_type'] = $action_type_arr[2];
			$qs[] = 'action_type='.$action_type;
		}
		if($value)
		{
			$where['value'] = 'like:'.$value;
			$qs[] = 'value='.$value;
		}
		if($memo)
		{
			$where['memo'] = 'like:'.$memo;
			$qs[] = 'memo='.$memo;
		}
		if($from_time)
		{
			$where['action_time >= '] = strtotime($from_time);
			$qs[] = 'from_time='.$from_time;
		}
		if($to_time)
		{
			$where['action_time <= '] = strtotime($to_time);
			$qs[] = 'to_time='.$to_time;
		}

		$page = $this->input->get('per_page');
		$page = $page ? $page : self::CUR_PAGE;
		$queryStr = implode('&', $qs);
		$this->queryString = '/'.$uid.'?' . $queryStr;
		$this->pageQueryString = true;

		$this->load->model('model_action_record');
		$action_records = $this->model_action_record->get_all($where, $this->pageSize, $page, 'action_time', 'DESC');
		foreach($action_records as &$action_record)
		{
			$action_record['action_time'] = date('Y-m-d H:i:s', $action_record['action_time']);
			$action_record['action_type'] = $config_action_record[$action_record['scope']][$action_record['type']][$action_record['sub_type']];
		}
		$tpl_data['action_records'] = $action_records;
		$tpl_data['per_page'] = $this->pageSize;
		$tpl_data['page'] = $page;
		$tpl_data['pagination'] = $this->pages($this->model_action_record->total_rows($where));
		$tpl_data['account'] = $account;
		$tpl_data['all_type_arr'] = $all_type_arr;
		$tpl_data['cur_nav'] = 'member_sys';
		$this->twig->display('member_sys/userlog', $tpl_data);
	}

	/**
	 * 自定义设置
	 */
	public function settings()
	{
		$this->load->model('model_app_config');
		$forward_config = $this->model_app_config->get_row(array('type'=>'forward', 'user_id'=>User::$user_id));

		if(!empty($_POST))
		{
			if($forward_config){//更新
				$data_set['config'] = $this->input->post('forward');
				if($this->model_app_config->update(array('type'=>'forward', 'user_id'=>User::$user_id), $data_set))
				{
					$this->show_message(TRUE, '设置保存成功', '/member_sys/settings');
				}
			}else{//添加
				$data_set['type'] = 'forward';
				$data_set['user_id'] = User::$user_id;
				$data_set['config'] = $this->input->post('forward');
				if($this->model_app_config->add($data_set))
				{
					$this->show_message(TRUE, '设置保存成功', '/member_sys/settings');
				}
			}
		}
		if(!isset($forward_config['config']))
		{
			$forward_config['config'] = '';
		}
		$tpl_data['forward_config'] = $forward_config;
		$tpl_data['cur_nav'] = 'member_sys';
		$this->twig->display('member_sys/settings', $tpl_data);
	}

    /**
     * @param $id
     * 用户详细信息
     */
    public function detail($id)
    {
        $account = $this->model_account->get_row(array('id'=>$id, 'wid'=>User::$user_id));
        if(!$account)
        {
            $this->show_message(FALSE, '该用户帐号不存在', '/member_sys');
        }
        $account['wxid'] && $account['wxid'] = substr($account['wxid'], 0, strlen($account['wxid'])-6).'******';
        $account['dt_add'] && $account['dt_add'] = date('Y-m-d H:i:s', $account['dt_add']);

        $this->load->library('Mongo_db');
        $list = $this->mongo_db->where(array('wid'=>User::$user_id))->order_by(array('sort' => 'ASC'))->get($this->fields_table);
        $list = $list ? $list : array();
        foreach($list as &$field) {
            $fv = $this->mongo_db->where(array('wid'=>User::$user_id, 'uid'=>$id))->get_one($this->field_value_table);
            $value = isset($fv[(string)$field['_id']]) ? $fv[(string)$field['_id']] : '';
            $field['value'] = is_array($value) ? implode(', ', $value) : $value;
        }

        $tpl_data['list'] = $list;
        $tpl_data['account'] = $account;
        $tpl_data['cur_nav'] = 'member_sys';
        $this->twig->display('member_sys/detail', $tpl_data);
    }
}