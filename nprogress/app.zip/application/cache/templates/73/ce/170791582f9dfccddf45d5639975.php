<?php

/* marketing_vote/index.html */
class __TwigTemplate_73ce170791582f9dfccddf45d5639975 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'style' => array($this, 'block_style'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "
<form class=\"form-inline\">
\t<table class=\"table table-striped\">
\t\t<thead>
\t\t<tr>
\t\t\t<th colspan=\"5\" style=\"text-align: center;\">投票列表
\t\t\t\t<a class=\"btn btn-primary pull-right\" href=\"/marketing_vote/add\"><i class=\"icon-plus icon-white\"></i> 添加微信投票</a>
\t\t\t</th>
\t\t</tr>
\t\t<tr>
\t\t\t<th style=\"width:15%\">投票时间</th>
\t\t\t<th style=\"width:10%\">状态</th>
\t\t\t<th style=\"width:10%\">浏览次数</th>
\t\t\t<th style=\"width:10%\">参与人数</th>
\t\t\t<th style=\"width:20%\">操作</th>
\t\t</tr>
\t\t</thead>
\t\t<tbody>
\t\t";
        // line 22
        if ((!twig_test_empty((isset($context["vote_arr"]) ? $context["vote_arr"] : $this->getContext($context, "vote_arr"))))) {
            // line 23
            echo "\t\t";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["vote_arr"]) ? $context["vote_arr"] : $this->getContext($context, "vote_arr")));
            foreach ($context['_seq'] as $context["_key"] => $context["vote"]) {
                // line 24
                echo "\t\t<tr data-id=\"";
                echo $this->getAttribute((isset($context["vote"]) ? $context["vote"] : $this->getContext($context, "vote")), "id", array(), "array");
                echo "\">
\t\t\t<td>";
                // line 25
                echo twig_date_format_filter($this->env, $this->getAttribute((isset($context["vote"]) ? $context["vote"] : $this->getContext($context, "vote")), "dt_start", array(), "array"), "Y-m-d");
                echo "至";
                echo twig_date_format_filter($this->env, $this->getAttribute((isset($context["vote"]) ? $context["vote"] : $this->getContext($context, "vote")), "dt_end", array(), "array"), "Y-m-d");
                echo "</td>
\t\t\t<td class=\"status\" data-id=\"";
                // line 26
                echo $this->getAttribute((isset($context["vote"]) ? $context["vote"] : $this->getContext($context, "vote")), "id", array(), "array");
                echo "\">";
                echo $this->getAttribute((isset($context["vote"]) ? $context["vote"] : $this->getContext($context, "vote")), "status", array(), "array");
                echo "</td>
\t\t\t<td>";
                // line 27
                echo $this->getAttribute((isset($context["vote"]) ? $context["vote"] : $this->getContext($context, "vote")), "count_view", array(), "array");
                echo "</td>
\t\t\t<td>";
                // line 28
                echo $this->getAttribute((isset($context["vote"]) ? $context["vote"] : $this->getContext($context, "vote")), "count_people", array(), "array");
                echo "</td>
\t\t\t<td>
\t\t\t\t<a class=\"btn btn-small\" href=\"/marketing_vote/update/";
                // line 30
                echo $this->getAttribute((isset($context["vote"]) ? $context["vote"] : $this->getContext($context, "vote")), "id", array(), "array");
                echo "\"><i class=\"icon-edit\"></i> 编辑</a>
\t\t\t\t<a class=\"btn btn-small\" href=\"/marketing_vote_info/manager/";
                // line 31
                echo $this->getAttribute((isset($context["vote"]) ? $context["vote"] : $this->getContext($context, "vote")), "id", array(), "array");
                echo "\"><i class=\"icon-list\"></i> 投票统计</a>
\t\t\t\t";
                // line 32
                if (($this->getAttribute((isset($context["vote"]) ? $context["vote"] : $this->getContext($context, "vote")), "status", array(), "array") == "已开始")) {
                    // line 33
                    echo "\t\t\t\t<a class=\"btn btn-small btn-stop\" data-id=\"";
                    echo $this->getAttribute((isset($context["vote"]) ? $context["vote"] : $this->getContext($context, "vote")), "id", array(), "array");
                    echo "\"><i class=\"icon-list\"></i> 终止活动</a>
\t\t\t\t";
                } else {
                    // line 35
                    echo "\t\t\t\t<a class=\"btn btn-small btn-start\" data-id=\"";
                    echo $this->getAttribute((isset($context["vote"]) ? $context["vote"] : $this->getContext($context, "vote")), "id", array(), "array");
                    echo "\" href=\"/marketing_vote/update/";
                    echo $this->getAttribute((isset($context["vote"]) ? $context["vote"] : $this->getContext($context, "vote")), "id", array(), "array");
                    echo "#updatetime\"><i class=\"icon-list\"></i> 开始活动</a>
\t\t\t\t";
                }
                // line 37
                echo "\t\t\t\t<a class=\"btn btn-small btn-delete\" data-id=\"";
                echo $this->getAttribute((isset($context["vote"]) ? $context["vote"] : $this->getContext($context, "vote")), "id", array(), "array");
                echo "\"><i class=\"icon-trash\"></i> 删除</a>

\t\t\t</td>
\t\t</tr>
\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['vote'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 42
            echo "\t\t";
        } else {
            // line 43
            echo "\t\t<tr>
\t\t\t<td colspan=\"5\" style=\"text-align: center;\">尚无投票</td>
\t\t</tr>
\t\t";
        }
        // line 47
        echo "\t\t</tbody>
\t</table>
</form>
";
        // line 50
        echo (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination"));
        echo "

";
    }

    // line 54
    public function block_style($context, array $blocks = array())
    {
        // line 55
        echo "<style type=\"text/css\">
\tthead {
\t\tborder-top: 1px solid #ddd;
\t\tbackground-color: #eee;
\t}
</style>
";
    }

    // line 63
    public function block_script($context, array $blocks = array())
    {
        // line 64
        echo "<script type=\"text/javascript\">
\t\$(function() {
\t\t\$('td').on('click', 'a.btn-stop', function(){
\t\t\tvar marketing_id = \$(this).attr('data-id');
\t\t\twindow.location.href = '/marketing_vote/stop/'+marketing_id;
\t\t});

\t\t\$('.btn-delete').click(function(){
\t\t\tif(confirm(\"是否确定删除该投票？\")){
\t\t\t\tvar marketing_id = \$(this).attr('data-id');
\t\t\t\twindow.location.href = '/marketing_vote/delete/'+marketing_id;
\t\t\t}
\t\t});
\t});
</script>
";
    }

    public function getTemplateName()
    {
        return "marketing_vote/index.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  159 => 64,  156 => 63,  146 => 55,  143 => 54,  136 => 50,  131 => 47,  125 => 43,  122 => 42,  110 => 37,  102 => 35,  96 => 33,  94 => 32,  90 => 31,  86 => 30,  81 => 28,  77 => 27,  71 => 26,  65 => 25,  60 => 24,  55 => 23,  53 => 22,  33 => 4,  30 => 3,);
    }
}
