<?php

/* album/album_img.html */
class __TwigTemplate_736296ddd0ca5b19a771a848a2213521 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <title>相册</title>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <meta name=\"description\" content=\"\">

    <script src=\"/assets/js/jquery.min.js\"></script>
    <script src=\"/assets/js/jquery-broswer.js\"></script>
    <script src=\"/assets/js/bootstrap.min.js\"></script>
    <script src=\"/assets/js/holder.js\"></script>
    <link href=\"/assets/css/bootstrap.min.css\" rel=\"stylesheet\">
    <link href=\"/assets/css/bootstrap-responsive.min.css\" rel=\"stylesheet\">
    <link href=\"/assets/css/app.css\" rel=\"stylesheet\">

    <link href=\"/assets/css/uploadify.css\" rel=\"stylesheet\">
    <link href=\"/assets/css/uploadify.css\" rel=\"stylesheet\">
    <script src=\"/assets/js/jquery.uploadify.min.js\"></script>
    <link href=\"/assets/css/artDialog/default.css\" rel=\"stylesheet\">
    <script src=\"/assets/js/artDialog.min.js\"></script>
</head>
<body>
<style>
    .d-content{width: 100%;}
</style>
<script type=\"text/javascript\">
    \$(function(){
        \$(\".btn-delete\").click(function(){
            if (confirm(\"您确定删除该照片吗？\")) {
                var id = \$(this).attr('data-id');
                location.href = '/album/album_img_del/'+id;
            }
        });
        \$(\".btn-rotate\").click(function(){
            var id = \$(this).attr('data-id');
            \$.post( '/album/album_img_rotate/'+id, function(data){
                var res = \$.parseJSON(data);
                if( res.ret==0 ){
                    window.location.reload();
                }else{
                    alert(res.msg);
                }
            } );
        });
        function upload_file(id)
        {
            \$(id).uploadify({
                'fileObjName': 'image',
                'fileSizeLimit': '2MB',
                'fileTypeExts': '*.jpg;*.png',
                'multi': true,
                'removeTimeout': 0,
                'width': 90,
                'height': 25,
                'buttonText': '选择相片',
                'formData': {'token': '";
        // line 57
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
                'swf': '/assets/js/uploadify.swf',
                'uploader': '/image/upload_gd',
                'onFallback': function() {
                    alert('您的浏览器没有安装Flash插件');
                },
                'onUploadSuccess': function(file, data, response) {
                    if (response) {
                        var ret = \$.parseJSON(data);
                        if (ret) {
                            if (ret.success) {
                                var i = \$('.j-img-value').length;
                                if(i >= 20){
                                    alert('一次性最多可上传20张照片');return false;
                                }
                                var img_name = file.name;
                                var a=img_name.split('.');
                                a.splice(a.length-1,1);
                                var title='';
                                for(var i in a){
                                    if(i< a.length-1){
                                        title+=a[i]+'.';
                                    }else{
                                        title+=a[i];
                                    }
                                }
                                var item = '<div class=\"span2 image-item\" style=\"position:relative;\">';
                                item += '<img src=\"'+ret.image+'\" style=\"width:180px;height:120px\" class=\"img-polaroid\">';
                                item += '<input type=\"hidden\" class=\"j-img-value\" value=\"'+ret.image+'\" data-title=\"'+title+'\">';
                                item += '<a style=\"position:absolute; top:0; left:0;\" class=\"image-del\" title=\"删除\"><i class=\"icon-trash\"></i></a>';
                                item += '</div>';
                                \$('#images').append(item);
                            } else {
                                alert(ret.message);
                            }
                        }
                    }
                }
            });
        }

        \$(\".j_add_img\").click(function(){
            str = '<form class=\"form-horizontal\" action=\"\" method=\"get\">'
                + '<div class=\"control-group\">'
                + '<label class=\"control-label\" style=\"width:100px;\">相册图片</label>'
                + '<div class=\"controls\">'
                + '<input type=\"file\" id=\"uploader-image\">'
                + '<span class=\"help-inline\"><span class=\"label\">建议尺寸：640X1080，一次性最多可上传20张照片</span></span>'
                + '<div class=\"row\" id=\"images\"></div>'
                + '</div>'
                + '</div></form>'
            art.dialog({
                title:'上传相片',
                lock:true,
                padding:'10px 10px',
                width:'600px',
                content: str,
                okValue: '保存',
                ok: function () {
                    if( \$('.j-img-value').length>0 ){
                        var imgs = new Array();
                        \$('.j-img-value').each(function(i){
                            var datas={};
                            datas['img'] = \$(this).val();
                            datas['title'] = \$(this).attr('data-title');
                            imgs.push(datas);
                        });
                        var url = '/album/album_img_add/";
        // line 124
        echo (isset($context["album_id"]) ? $context["album_id"] : $this->getContext($context, "album_id"));
        echo "';
                        \$.ajax({
                            type: \"POST\",
                            url: url,
                            data: {photos:imgs},
                            cache: false,
                            success: function(data){
                                var res = \$.parseJSON(data);
                                if( res.ret==0 ){
                                    alert('上传成功');
                                    window.location.reload();
                                }else{
                                    alert(res.msg);
                                }
                            }
                        });
                        return false;
                    }
                },
                cancelValue:'关闭',
                cancel: true
            });
            upload_file('#uploader-image');

            \$('#images').on('click', '.image-del', function(){
                \$(this).parent('.image-item').remove();
                \$.each(\$('.image-item'), function(i, ele){
                    \$(\"input[name^='image'][name\$='[src]']\", this).attr('name', 'image['+i+'][src]');
                })
            });
        });
    });
</script>
<div class=\"main-left\">
    <ul class=\"app-lt-nav\">
        <li><a href=\"/album/index/";
        // line 159
        echo $this->getAttribute((isset($context["album"]) ? $context["album"] : $this->getContext($context, "album")), "id", array(), "array");
        echo "\">基本信息</a></li>
        <li class=\"active\"><a href=\"/album/album_img\">相册照片</a></li>
    </ul>
</div>
<div class=\"main-right\">
    <ul class=\"breadcrumb clearfix\">
        <li>相册照片</li>
        <li style=\"float: right;\"><input type=\"button\" value=\"添加相片\" class=\"btn btn-primary j_add_img\"></li>
    </ul>
    <form action=\"/album/album_img_edit/";
        // line 168
        echo (isset($context["album_id"]) ? $context["album_id"] : $this->getContext($context, "album_id"));
        echo "\" method=\"post\">
        <table class=\"table table-hover table-bordered\">
            <thead>
            <tr style=\"background-color:#EEEEEE;\">
                <th style=\"width:50px;\">#</th>
                <th style=\"width:260px;\">图片</th>
                <th>图片信息</th>
                <th>链接信息</th>
                <th>开启关注分享功能</th>
                <th>排序</th>
                <th>操作</th>
            </tr>
            </thead>
            <tbody>
            <tbody>
                ";
        // line 183
        if ((!twig_test_empty((isset($context["list"]) ? $context["list"] : $this->getContext($context, "list"))))) {
            // line 184
            echo "                ";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["list"]) ? $context["list"] : $this->getContext($context, "list")));
            foreach ($context['_seq'] as $context["key"] => $context["val"]) {
                // line 185
                echo "                <tr>
                    <td>";
                // line 186
                echo (((isset($context["offset"]) ? $context["offset"] : $this->getContext($context, "offset")) + (isset($context["key"]) ? $context["key"] : $this->getContext($context, "key"))) + 1);
                echo "</td>
                    <td>
                        <img src=\"";
                // line 188
                echo $this->getAttribute((isset($context["val"]) ? $context["val"] : $this->getContext($context, "val")), "img", array(), "array");
                echo "?t=";
                echo twig_random($this->env);
                echo "\" style=\"height: 120px;\">
                    </td>
                    <td>
                        <p><input name=\"img[";
                // line 191
                echo $this->getAttribute((isset($context["val"]) ? $context["val"] : $this->getContext($context, "val")), "id", array(), "array");
                echo "][title]\" type=\"text\" value=\"";
                echo $this->getAttribute((isset($context["val"]) ? $context["val"] : $this->getContext($context, "val")), "title", array(), "array");
                echo "\" placeholder=\"标题,20个字以内\"></p>
                        <textarea name=\"img[";
                // line 192
                echo $this->getAttribute((isset($context["val"]) ? $context["val"] : $this->getContext($context, "val")), "id", array(), "array");
                echo "][intro]\" placeholder=\"描述,200个字以内\" rows=\"5\" style=\"resize: none;margin-top: -15px;\" >";
                echo $this->getAttribute((isset($context["val"]) ? $context["val"] : $this->getContext($context, "val")), "intro", array(), "array");
                echo "</textarea>
                    </td>
                    <td>
                        <p><input name=\"img[";
                // line 195
                echo $this->getAttribute((isset($context["val"]) ? $context["val"] : $this->getContext($context, "val")), "id", array(), "array");
                echo "][extra]\" type=\"text\" value=\"";
                echo $this->getAttribute((isset($context["val"]) ? $context["val"] : $this->getContext($context, "val")), "extra", array(), "array");
                echo "\" placeholder=\"链接名称,8个字以内\"></p>
                        <p><input name=\"img[";
                // line 196
                echo $this->getAttribute((isset($context["val"]) ? $context["val"] : $this->getContext($context, "val")), "id", array(), "array");
                echo "][extra_url]\" type=\"text\" value=\"";
                echo $this->getAttribute((isset($context["val"]) ? $context["val"] : $this->getContext($context, "val")), "extra_url", array(), "array");
                echo "\" placeholder=\"链接地址\"></p>
                    </td>
                    <td>
                        <p><input name=\"img[";
                // line 199
                echo $this->getAttribute((isset($context["val"]) ? $context["val"] : $this->getContext($context, "val")), "id", array(), "array");
                echo "][focus_share_set]\" type=\"checkbox\" value=\"1\" ";
                echo ((($this->getAttribute((isset($context["val"]) ? $context["val"] : $this->getContext($context, "val")), "focus_share_set", array(), "array") == 1)) ? ("checked=\"checked\"") : (""));
                echo "></p>
                    </td>
                    <td>
                        <p><input name=\"img[";
                // line 202
                echo $this->getAttribute((isset($context["val"]) ? $context["val"] : $this->getContext($context, "val")), "id", array(), "array");
                echo "][listorder]\" type=\"text\" value=\"";
                echo $this->getAttribute((isset($context["val"]) ? $context["val"] : $this->getContext($context, "val")), "listorder", array(), "array");
                echo "\" style=\"width:80px;\"></p>
                    </td>
                    <td>
                        <a data-id=\"";
                // line 205
                echo $this->getAttribute((isset($context["val"]) ? $context["val"] : $this->getContext($context, "val")), "id", array(), "array");
                echo "\" class=\"btn btn-small btn-rotate\"><i class=\"icon-repeat\"></i> 旋转</a>
                        <a data-id=\"";
                // line 206
                echo $this->getAttribute((isset($context["val"]) ? $context["val"] : $this->getContext($context, "val")), "id", array(), "array");
                echo "\" class=\"btn btn-small btn-delete\"><i class=\"icon-trash\"></i> 删除</a>
                    </td>
                </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key'], $context['val'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 210
            echo "                ";
        } else {
            // line 211
            echo "                <tr><td colspan=\"5\" style=\"text-align: center;\">没有相关的相片</td></tr>
                ";
        }
        // line 213
        echo "
            </tbody>
        </table>
        <input type=\"submit\" class=\"btn btn-primary pull-left\" value=\"保存\">
    </form>
    ";
        // line 218
        echo (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination"));
        echo "
</div>
</body>
</html>";
    }

    public function getTemplateName()
    {
        return "album/album_img.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  310 => 218,  303 => 213,  299 => 211,  296 => 210,  286 => 206,  282 => 205,  274 => 202,  266 => 199,  258 => 196,  252 => 195,  244 => 192,  238 => 191,  230 => 188,  225 => 186,  222 => 185,  217 => 184,  215 => 183,  197 => 168,  185 => 159,  147 => 124,  77 => 57,  19 => 1,);
    }
}
