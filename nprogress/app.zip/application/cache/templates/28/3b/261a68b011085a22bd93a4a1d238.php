<?php

/* cate_banner/index.html */
class __TwigTemplate_283b261a68b011085a22bd93a4a1d238 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'style' => array($this, 'block_style'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "<ul class=\"breadcrumb clearfix\">
\t<li><a href=\"/cate_banner\">首页幻灯片</a></li>
\t<div class=\"pull-right\">
\t\t<a href=\"/cate_banner/add\" class=\"btn btn-primary\"><i class=\"icon-plus icon-white\"></i> 添加</a>
\t</div>
</ul>
";
        // line 10
        if ((!twig_test_empty((isset($context["cate_banner_arr"]) ? $context["cate_banner_arr"] : $this->getContext($context, "cate_banner_arr"))))) {
            // line 11
            echo "<form class=\"form-inline\">
\t<table class=\"table table-striped\">
\t\t<thead>
\t\t\t<tr>
\t\t\t\t<th style=\"width:60px\">排序</th>
\t\t\t\t<th style=\"width: 200px;\">图片</th>
\t\t\t\t<th>标题</th>
\t\t\t\t<th style=\"width: 300px;\">外链</th>
\t\t\t\t<th style=\"width: 150px;\">更新时间</th>
\t\t\t\t<th style=\"width: 200px;\"></th>
\t\t\t</tr>
\t\t</thead>
\t\t<tbody>
\t\t\t";
            // line 24
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["cate_banner_arr"]) ? $context["cate_banner_arr"] : $this->getContext($context, "cate_banner_arr")));
            foreach ($context['_seq'] as $context["_key"] => $context["cate_banner"]) {
                // line 25
                echo "\t\t\t<tr>
\t\t\t\t<td><input type=\"text\" value=\"";
                // line 26
                echo $this->getAttribute((isset($context["cate_banner"]) ? $context["cate_banner"] : $this->getContext($context, "cate_banner")), "rank", array(), "array");
                echo "\" autocomplete=\"off\" cate_banner_id=\"";
                echo $this->getAttribute((isset($context["cate_banner"]) ? $context["cate_banner"] : $this->getContext($context, "cate_banner")), "id", array(), "array");
                echo "\" class=\"input-rank\" style=\"width:30px\"></td>
\t\t\t\t<td>
\t\t\t\t\t<img style=\"width:250px;height:130px;\" src=\"";
                // line 28
                echo $this->getAttribute((isset($context["cate_banner"]) ? $context["cate_banner"] : $this->getContext($context, "cate_banner")), "image", array(), "array");
                echo "\" />
\t\t\t\t</td>
\t\t\t\t<td>
\t\t\t\t\t<strong>";
                // line 31
                echo $this->getAttribute((isset($context["cate_banner"]) ? $context["cate_banner"] : $this->getContext($context, "cate_banner")), "title", array(), "array");
                echo "</strong>
\t\t\t\t</td>
\t\t\t\t<td >
\t\t\t\t\t<strong class=\"muted\" style=\"width: 300px;overflow: hidden;display: inline-block;\t\">";
                // line 34
                echo $this->getAttribute((isset($context["cate_banner"]) ? $context["cate_banner"] : $this->getContext($context, "cate_banner")), "url", array(), "array");
                echo "</strong>
\t\t\t\t</td>
\t\t\t\t<td><strong class=\"muted\">";
                // line 36
                echo twig_date_format_filter($this->env, $this->getAttribute((isset($context["cate_banner"]) ? $context["cate_banner"] : $this->getContext($context, "cate_banner")), "dt_update", array(), "array"), "Y/m/d H:i");
                echo "</strong></td>
\t\t\t\t<td>
\t\t\t\t\t<a class=\"btn btn-small\" href=\"/cate_banner/update/";
                // line 38
                echo $this->getAttribute((isset($context["cate_banner"]) ? $context["cate_banner"] : $this->getContext($context, "cate_banner")), "id", array(), "array");
                echo "\"><i class=\"icon-edit\"></i> 编辑</a>
\t\t\t\t\t<a class=\"btn btn-small btn-delete\" data-id=\"";
                // line 39
                echo $this->getAttribute((isset($context["cate_banner"]) ? $context["cate_banner"] : $this->getContext($context, "cate_banner")), "id", array(), "array");
                echo "\"><i class=\"icon-trash\"></i> 删除</a>
\t\t\t\t</td>
\t\t\t</tr>
\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['cate_banner'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 43
            echo "\t\t</tbody>
\t</table>
</form>
";
            // line 46
            echo (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination"));
            echo "
";
        } else {
            // line 48
            echo "<div class=\"well well-large\"><h3><img src=\"/assets/img/no_content.png\"> 没有相关的广告 ......</h3></div>
";
        }
    }

    // line 52
    public function block_style($context, array $blocks = array())
    {
        // line 53
        echo "<style type=\"text/css\">
thead {
\tborder-top: 1px solid #ddd;
\tbackground-color: #eee;
}
</style>
";
    }

    // line 61
    public function block_script($context, array $blocks = array())
    {
        // line 62
        echo "<script type=\"text/javascript\">
\$('.input-rank').keyup(function(){
\tvar cate_banner_id = \$(this).attr('cate_banner_id');
\tvar rank = \$(this).val();
\t\$.post('/cate_banner/update_rank/'+cate_banner_id, {'rank':rank}, function(data) {
\t\tif (!data.success) {
\t\t\talert(data.message);
\t\t}
\t});
});

\$('.btn-delete').click(function(){
\tif(confirm(\"是否确定删除该广告？\")){
\t\tvar cate_banner_id = \$(this).attr('data-id');
\t\twindow.location.href = '/cate_banner/delete/'+cate_banner_id;
\t}
});
</script>
";
    }

    public function getTemplateName()
    {
        return "cate_banner/index.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  140 => 62,  137 => 61,  127 => 53,  124 => 52,  118 => 48,  113 => 46,  108 => 43,  98 => 39,  94 => 38,  89 => 36,  84 => 34,  78 => 31,  72 => 28,  65 => 26,  62 => 25,  58 => 24,  43 => 11,  41 => 10,  33 => 4,  30 => 3,);
    }
}
