<?php

/* setting/share.html */
class __TwigTemplate_c1fd98213a69ba6fb39f383c8e8f35c0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "<ul class=\"nav nav-tabs\" style=\"margin-bottom: 0;\">
    <li class=\"active\"><a href=\"#scope\" data-toggle=\"tab\">分享设置</a></li>
    <li><a href=\"#api\" data-toggle=\"tab\">高级接口</a></li>
</ul>
<form class=\"form-horizontal\" action=\"\" method=\"post\">
<div class=\"well tab-content\">

    <div class=\"tab-pane active\" id=\"scope\">
            <div class=\"control-group\">
                <label class=\"control-label\">分享按钮出现的范围</label>
                <div class=\"controls\">
                    <label class=\"checkbox inline\">
                        <input type=\"checkbox\" name=\"scope[]\" value=\"home\" ";
        // line 16
        if (($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "scope", array(), "array", true, true) && twig_in_filter("home", $this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "scope", array(), "array")))) {
            echo "checked";
        }
        echo "> 首页
                    </label>
                    <label class=\"checkbox inline\">
                        <input type=\"checkbox\" name=\"scope[]\" value=\"cate\" ";
        // line 19
        if (($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "scope", array(), "array", true, true) && twig_in_filter("cate", $this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "scope", array(), "array")))) {
            echo "checked";
        }
        echo "> 分类
                    </label>
                    <label class=\"checkbox inline\">
                        <input type=\"checkbox\" name=\"scope[]\" value=\"detail\" ";
        // line 22
        if (($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "scope", array(), "array", true, true) && twig_in_filter("detail", $this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "scope", array(), "array")))) {
            echo "checked";
        }
        echo "> 详细
                    </label>
                </div>
            </div>
            <div class=\"control-group\">
                <div class=\"controls\">
                    <button type=\"submit\" class=\"btn btn-primary\">确认保存</button>
                </div>
            </div>
    </div>
    <div class=\"tab-pane\" id=\"api\">
        <ul class=\"clearfix activity-instruction\">
            分享按钮显示设置(有开发能力公司使用)
        </ul>
                <div class=\"control-group\">
                    <label class=\"control-label\">分享成功通知地址</label>
                    <div class=\"controls\">
                        ";
        // line 39
        if ($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "sendurl", array(), "array", true, true)) {
            // line 40
            echo "                        <input type=\"text\" class=\"input-xxlarge\" name=\"sendurl\" value=\"";
            echo $this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "sendurl", array(), "array");
            echo "\">
                        ";
        } else {
            // line 42
            echo "                        <input type=\"text\" class=\"input-xxlarge\" name=\"sendurl\">
                        ";
        }
        // line 44
        echo "                        <span class=\"help-block\">
                            参数：from  (openid)<br/>
                            参数：url  (分享网址)<br/>
                            返回：{\"message\":\"\",\"success\":true|false}
                        </span>
                    </div>
                </div>
                <div class=\"control-group\">
                    <div class=\"controls\">
                        <button type=\"submit\" class=\"btn btn-primary\">确认保存</button>
                    </div>
                </div>

    </div>

</div>
</form>
";
    }

    public function getTemplateName()
    {
        return "setting/share.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  95 => 44,  91 => 42,  85 => 40,  83 => 39,  61 => 22,  53 => 19,  45 => 16,  31 => 4,  28 => 3,);
    }
}
