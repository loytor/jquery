<?php

/* cate/index.html */
class __TwigTemplate_53415c345d3dc28b62723e53fe1081bc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'style' => array($this, 'block_style'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "
<ul class=\"breadcrumb clearfix\">
    <h5 class=\"pull-left\" style=\"color:red;\">如果在编辑时想看微信中的实际显示效果，请在微信对话框中回复“首页”即可</h5>
    <div class=\"pull-right\">
        <a class=\"btn btn-primary\" href=\"/cate/add\"><i class=\"icon-plus icon-white\"></i> 添加栏目</a>
    </div>
</ul>

";
        // line 12
        if ((!twig_test_empty((isset($context["cate_arr"]) ? $context["cate_arr"] : $this->getContext($context, "cate_arr"))))) {
            // line 13
            echo "<form class=\"form-inline\">
    <table class=\"table tree table-striped table-condensed\">
        <thead>
            <tr>
                <th>排序</th>
                <th>栏目名称</th>
                <th style=\"width:60px\">文章数</th>
                <th style=\"width:550px\"></th>
            </tr>
        </thead>
        <tbody>

            ";
            // line 25
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["cate_arr"]) ? $context["cate_arr"] : $this->getContext($context, "cate_arr")));
            foreach ($context['_seq'] as $context["_key"] => $context["_cate"]) {
                // line 26
                echo "\t\t\t<tr class=\"treegrid-";
                echo $this->getAttribute((isset($context["_cate"]) ? $context["_cate"] : $this->getContext($context, "_cate")), "id", array(), "array");
                echo " ";
                if ($this->getAttribute((isset($context["_cate"]) ? $context["_cate"] : $this->getContext($context, "_cate")), "parent_id", array(), "array")) {
                    echo "treegrid-parent-";
                    echo $this->getAttribute((isset($context["_cate"]) ? $context["_cate"] : $this->getContext($context, "_cate")), "parent_id", array(), "array");
                }
                echo "\">
\t\t\t\t<td><input type=\"text\" value=\"";
                // line 27
                echo $this->getAttribute((isset($context["_cate"]) ? $context["_cate"] : $this->getContext($context, "_cate")), "rank", array(), "array");
                echo "\" autocomplete=\"off\" cate_id=\"";
                echo $this->getAttribute((isset($context["_cate"]) ? $context["_cate"] : $this->getContext($context, "_cate")), "id", array(), "array");
                echo "\" class=\"input-rank\" style=\"width:30px\"></td>
\t\t\t\t<td>
\t\t\t\t\t<a href=\"";
                // line 29
                echo $this->getAttribute((isset($context["_cate"]) ? $context["_cate"] : $this->getContext($context, "_cate")), "preview_url", array(), "array");
                echo "\" target=\"blank\"><strong>";
                echo $this->getAttribute((isset($context["_cate"]) ? $context["_cate"] : $this->getContext($context, "_cate")), "cate_name", array(), "array");
                echo "</strong></a>
\t\t\t\t\t";
                // line 30
                if ($this->getAttribute((isset($context["_cate"]) ? $context["_cate"] : $this->getContext($context, "_cate")), "url", array(), "array")) {
                    echo "<span class=\"label\"><i class=\"icon-share icon-white\"></i> 外部链接</span>";
                }
                // line 31
                echo "\t\t\t\t</td>
\t\t\t\t<td><span class=\"badge\">";
                // line 32
                echo $this->getAttribute((isset($context["_cate"]) ? $context["_cate"] : $this->getContext($context, "_cate")), "count_article", array(), "array");
                echo "</span></td>
\t\t\t\t<td>
\t\t\t\t\t<a class=\"btn btn-small\" href=\"";
                // line 34
                echo $this->getAttribute((isset($context["_cate"]) ? $context["_cate"] : $this->getContext($context, "_cate")), "preview_url", array(), "array");
                echo "\" target=\"blank\"><i class=\"icon-globe\"></i> 查看</a>
\t\t\t\t\t<a class=\"btn btn-small\" href=\"/article/add?cate_id=";
                // line 35
                echo $this->getAttribute((isset($context["_cate"]) ? $context["_cate"] : $this->getContext($context, "_cate")), "id", array(), "array");
                echo "\"><i class=\"icon-list\"></i> 创建文章</a>
\t\t\t\t\t<a class=\"btn btn-small\" href=\"/article/index/";
                // line 36
                echo $this->getAttribute((isset($context["_cate"]) ? $context["_cate"] : $this->getContext($context, "_cate")), "id", array(), "array");
                echo "\"><i class=\"icon-list\"></i> 文章</a>
\t\t\t\t\t<a class=\"btn btn-small btn-success\" href=\"/cate_lists/index/";
                // line 37
                echo $this->getAttribute((isset($context["_cate"]) ? $context["_cate"] : $this->getContext($context, "_cate")), "id", array(), "array");
                echo "\"><i class=\"icon-list icon-white\"></i> 内容管理</a>
\t\t\t\t\t<a class=\"btn btn-small\" href=\"/cate/update/";
                // line 38
                echo $this->getAttribute((isset($context["_cate"]) ? $context["_cate"] : $this->getContext($context, "_cate")), "id", array(), "array");
                echo "\"><i class=\"icon-edit\"></i> 编辑</a>
\t\t\t\t\t<a class=\"btn btn-small btn-delete\" data-id=\"";
                // line 39
                echo $this->getAttribute((isset($context["_cate"]) ? $context["_cate"] : $this->getContext($context, "_cate")), "id", array(), "array");
                echo "\"><i class=\"icon-trash\"></i> 删除</a>
\t\t\t\t\t<a class=\"btn btn-small\" href=\"/cate/add/";
                // line 40
                echo $this->getAttribute((isset($context["_cate"]) ? $context["_cate"] : $this->getContext($context, "_cate")), "id", array(), "array");
                echo "\"><i class=\"icon-plus\"></i> 添加子栏目</a>
\t\t\t\t</td>
\t\t\t</tr>
\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['_cate'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 44
            echo "<!--            <tr class=\"treegrid-1\">
\t            <td>Root node 1</td><td>Additional info</td>
            </tr>
            <tr class=\"treegrid-2 treegrid-parent-1\">
\t            <td>Node 1-1</td><td>Additional info</td>
            </tr>
            <tr class=\"treegrid-3 treegrid-parent-1\">
\t            <td>Node 1-2</td><td>Additional info</td>
            </tr>
            <tr class=\"treegrid-4 treegrid-parent-3\">
\t            <td>Node 1-2-1</td><td>Additional info</td>
            </tr>
            <tr class=\"treegrid-5\">
\t            <td>Root node 2</td><td>Additional info</td>
            </tr>
            <tr class=\"treegrid-6 treegrid-parent-5\">
\t            <td>Node 2-1</td><td>Additional info</td>
            </tr>
            <tr class=\"treegrid-7 treegrid-parent-5\">
\t            <td>Node 2-2</td><td>Additional info</td>
            </tr>
            <tr class=\"treegrid-8 treegrid-parent-7\">
\t            <td>Node 2-2-1</td><td>Additional info</td>
            </tr>-->
\t\t</tbody>
\t</table>
</form>
";
        } else {
            // line 72
            echo "<div class=\"well well-large\"><h3><img src=\"/assets/img/no_content.png\"> 没有栏目 ......</h3></div>
";
        }
        // line 74
        echo "<div id=\"guide_4\" class=\"modal hide fade\" tabindex=\"-1\">
\t<div class=\"modal-body\">
\t\t<img src=\"/assets/img/guide_4.jpg\">
\t</div>
\t<div class=\"modal-footer\">
\t\t<button class=\"btn\" data-dismiss=\"modal\" aria-hidden=\"true\">关闭</button>
\t</div>
</div>
<div id=\"guide_5\" class=\"modal hide fade\" tabindex=\"-1\">
\t<div class=\"modal-body\">
\t\t<img src=\"/assets/img/guide_5.jpg\">
\t</div>
\t<div class=\"modal-footer\">
\t\t<button class=\"btn\" data-dismiss=\"modal\" aria-hidden=\"true\">关闭</button>
\t</div>
</div>
";
    }

    // line 92
    public function block_style($context, array $blocks = array())
    {
        // line 93
        echo "<link rel=\"stylesheet\" href=\"/assets/css/jquery.treegrid.css\">
<style type=\"text/css\">
thead {
\tborder-top: 1px solid #ddd;
\tbackground-color: #eee;
}
p.desc {
\tfont-size: 12px;
}
</style>
";
    }

    // line 105
    public function block_script($context, array $blocks = array())
    {
        // line 106
        echo "<script type=\"text/javascript\" src=\"/assets/js/jquery.treegrid.js\"></script>
<script type=\"text/javascript\" src=\"/assets/js/jquery.treegrid.bootstrap2.js\"></script>
<script type=\"text/javascript\">
\$(function() {
\t\$('.input-rank').keyup(function(){
\t\tvar cate_id = \$(this).attr('cate_id');
\t\tvar rank = \$(this).val();
\t\t\$.post('/cate/update_rank/'+cate_id, {'rank':rank}, function(data) {
\t\t\tif (!data.success) {
\t\t\t\talert(data.message);
\t\t\t}
\t\t});
\t});
\t
\t\$('.btn-delete').click(function(){
\t\tif(confirm(\"是否确定删除该栏目？\")){
\t\t\tvar cate_id = \$(this).attr('data-id');\t\t\t
\t\t\twindow.location.href = '/cate/delete/'+cate_id;
\t\t}
\t});

\t\$('.tree').treegrid({
\t\texpanderExpandedClass: 'icon-minus-sign',
\t\texpanderCollapsedClass: 'icon-plus-sign',
        initialState: 'collapsed'
\t});
});
</script>
";
    }

    public function getTemplateName()
    {
        return "cate/index.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  206 => 106,  203 => 105,  189 => 93,  186 => 92,  166 => 74,  162 => 72,  132 => 44,  122 => 40,  118 => 39,  114 => 38,  110 => 37,  106 => 36,  102 => 35,  98 => 34,  93 => 32,  90 => 31,  86 => 30,  80 => 29,  73 => 27,  63 => 26,  59 => 25,  45 => 13,  43 => 12,  33 => 4,  30 => 3,);
    }
}
