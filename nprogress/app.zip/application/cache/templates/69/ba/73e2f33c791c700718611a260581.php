<?php

/* cate_banner/update.html */
class __TwigTemplate_69ba73e2f33c791c700718611a260581 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'style' => array($this, 'block_style'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "<ul class=\"breadcrumb clearfix\">
    <li><a href=\"/cate_banner\">首页幻灯片</a> <span class=\"divider\">/</span></li>
\t<li class=\"active\">编辑广告</li>
</ul>
<div class=\"well\">
\t<div class=\"row-fluid\">
\t\t<div class=\"span8\">
\t\t\t<form class=\"form-horizontal\" action=\"\" method=\"post\">
\t\t\t\t<div class=\"control-group\">
\t\t\t\t\t<label class=\"control-label\" for=\"input-title\">标题</label>
\t\t\t\t\t<div class=\"controls\">
\t\t\t\t\t\t<input type=\"text\" name=\"title\" id=\"input-title\" class=\"span4\" value=\"";
        // line 15
        echo $this->getAttribute((isset($context["cate_banner"]) ? $context["cate_banner"] : $this->getContext($context, "cate_banner")), "title", array(), "array");
        echo "\">
\t\t\t\t\t\t<span class=\"help-inline\"><span class=\"label\">建议10个汉字以内</span></span>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"control-group\">
\t\t\t\t\t<label class=\"control-label\" for=\"input-image\">广告图片</label>
\t\t\t\t\t<div class=\"controls\">
\t\t\t\t\t\t<span class=\"help-block\"><span class=\"label\">建议图片尺寸640 : 320</span></span>
\t\t\t\t\t\t<img src=\"";
        // line 23
        echo $this->getAttribute((isset($context["cate_banner"]) ? $context["cate_banner"] : $this->getContext($context, "cate_banner")), "image_preview", array(), "array");
        echo "\" class=\"img-polaroid\" id=\"image-banner-preview\">
                        <input type=\"button\" class=\"btn j_img_clear\" value=\"删除\" style=\"margin:0 0 5px 10px;\" />
\t\t\t\t\t\t<input type=\"hidden\" name=\"image\" id=\"input-image\" value=\"";
        // line 25
        echo $this->getAttribute((isset($context["cate_banner"]) ? $context["cate_banner"] : $this->getContext($context, "cate_banner")), "image", array(), "array");
        echo "\">
\t\t\t\t\t\t<input type=\"file\" id=\"uploader-image\">
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"control-group\" id=\"control_show_url\">
\t\t\t\t\t<div class=\"controls\">
\t\t\t\t\t\t<a href=\"#\" id=\"show_url\"><span class=\"label\"><i class=\"icon-share icon-white\"></i> 指向外部链接</span></a>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"control-group hide\" id=\"control_url\">
\t\t\t\t\t<label class=\"control-label\" for=\"input-url\">外部链接</label>
\t\t\t\t\t<div class=\"controls\">
\t\t\t\t\t\t<input type=\"text\" name=\"url\" id=\"input-url\" class=\"span4\" placeholder=\"http://\" value=\"";
        // line 37
        echo $this->getAttribute((isset($context["cate_banner"]) ? $context["cate_banner"] : $this->getContext($context, "cate_banner")), "url", array(), "array");
        echo "\">
\t\t\t\t\t</div>
\t\t\t\t</div>\t\t
\t\t\t\t<div class=\"control-group\">
\t\t\t\t\t<div class=\"controls\">
\t\t\t\t\t\t<button type=\"submit\" class=\"btn btn-primary\">确认保存</button>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</form>
\t\t</div>
\t\t<div class=\"span4\" style=\"float:right;\">
\t\t\t<h5>头部广告示意图</h5>
\t\t\t<img src=\"/assets/img/cate_banner.jpg\">
\t\t</div>
\t</div>
</div>
<div id=\"guide_1\" class=\"modal hide fade\" tabindex=\"-1\">
\t<div class=\"modal-body\">
\t\t<img src=\"/assets/img/guide_1.jpg\">
\t</div>
\t<div class=\"modal-footer\">
\t\t<button class=\"btn\" data-dismiss=\"modal\" aria-hidden=\"true\">关闭</button>
\t</div>
</div>
";
    }

    // line 63
    public function block_style($context, array $blocks = array())
    {
        // line 64
        echo "<link href=\"/assets/js/kindeditor/themes/default/default.css\" rel=\"stylesheet\">
<link href=\"/assets/css/uploadify.css\" rel=\"stylesheet\">
<style type=\"text/css\">
#image-preview {
\tmargin-bottom: 10px;
}
</style>
";
    }

    // line 73
    public function block_script($context, array $blocks = array())
    {
        // line 74
        echo "<script src=\"/assets/js/jquery.uploadify.min.js\"></script>
<script type=\"text/javascript\">
\$(function() {
\t//删除上传的图片
\t\$(document).on('click','.j_img_clear',function(){
\t\t\$(this).next('input').val('');
\t\t\$(this).prevAll('img').attr('src','/assets/img/no_image.png');
\t});
\t\$('#uploader-image').uploadify({
\t\t'fileObjName': 'image',
\t\t'fileSizeLimit': '2MB',
        'fileTypeExts': '*.gif; *.jpg; *.png',
\t\t'multi': false,
\t\t'removeTimeout': 0,
\t\t'width': 90,
\t\t'height': 25,
\t\t'buttonText': '选择图片',
\t\t'formData': {'token': '";
        // line 91
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
\t\t'swf': '/assets/js/uploadify.swf',
\t\t'uploader': '/image/upload',
\t\t'onFallback': function() {
\t\t\talert('您的浏览器没有安装Flash插件');
\t\t},
\t\t'onUploadSuccess': function(file, data, response) {
\t\t\tif (response) {
\t\t\t\tvar ret = \$.parseJSON(data);
\t\t\t\tif (ret) {
\t\t\t\t\tif (ret.success) {
\t\t\t\t\t\t\$('#input-image').val(ret.image);
\t\t\t\t\t\t\$('#image-banner-preview').attr('src', ret.image_middle);
\t\t\t\t\t} else {
\t\t\t\t\t\talert(ret.message);
\t\t\t\t\t}
\t\t\t\t}
\t\t\t}
\t\t}
\t});
\t\$('#show_url').click(function() {
\t\t\$('#control_url').removeClass('hide');
\t\t\$('#control_show_url').addClass('hide');
\t\treturn false;
\t});
});
</script>
";
    }

    public function getTemplateName()
    {
        return "cate_banner/update.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  142 => 91,  123 => 74,  120 => 73,  109 => 64,  106 => 63,  77 => 37,  62 => 25,  57 => 23,  46 => 15,  33 => 4,  30 => 3,);
    }
}
