<?php

/* mall/lists.html */
class __TwigTemplate_59873a9ef895a441d0bcbdb2bc3c48c9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "
<style>
.j_edit_totals_con{display:none;}
.j_edit_totals_btn{text-decoration:none;}
.j_edit_totals_btn:hover{text-decoration:none;}
</style>

<form action=\"/mall/lists\" method=\"post\">
\t<table class=\"table table-hover table-bordered\">
\t\t<thead>
\t\t<tr>
\t\t\t<th colspan=\"10\" style=\"text-align: center; font-size:16px;\">
\t\t\t\t商品列表
\t\t\t\t<a href=\"/mall/item_add\" class=\"btn btn-primary pull-right\"><i class=\"icon-plus icon-white\"></i> 添加商品</a>
\t\t\t</th>
\t\t</tr>
\t\t<tr style=\"background-color:#EEEEEE;\">
\t\t\t<th>#</th>
\t\t\t<th>商品图片</th>
\t\t\t<th>商品标题</th>
\t\t\t<th>原价</th>
\t\t\t<th>现价</th>
\t\t\t<th>库存</th>
\t\t\t<th>销量</th>
\t\t\t<th>分类</th>
\t\t\t<th>状态</th>
\t\t\t<th></th>
\t\t</tr>
\t\t</thead>
\t\t<tbody>
\t\t<tr>
\t\t\t<td>筛选</td>
\t\t\t<td></td>
\t\t\t<td><input name=\"title\" class=\"input-small\" type=\"text\" style=\"margin-bottom: 0;\" value=\"";
        // line 37
        echo (isset($context["title"]) ? $context["title"] : $this->getContext($context, "title"));
        echo "\"></td>
\t\t\t<td><input name=\"mprice\" class=\"input-mini\" type=\"text\" style=\"margin-bottom: 0;\" value=\"";
        // line 38
        echo (isset($context["mprice"]) ? $context["mprice"] : $this->getContext($context, "mprice"));
        echo "\"></td>
\t\t\t<td><input name=\"price\" class=\"input-mini\" type=\"text\" style=\"margin-bottom: 0;\" value=\"";
        // line 39
        echo (isset($context["price"]) ? $context["price"] : $this->getContext($context, "price"));
        echo "\"></td>
\t\t\t<td><input name=\"stock\" class=\"input-mini\" type=\"text\" style=\"margin-bottom: 0;\" value=\"";
        // line 40
        echo (isset($context["stock"]) ? $context["stock"] : $this->getContext($context, "stock"));
        echo "\"></td>
\t\t\t<td><input name=\"csale\" class=\"input-mini\" type=\"text\" style=\"margin-bottom: 0;\" value=\"";
        // line 41
        echo (isset($context["csale"]) ? $context["csale"] : $this->getContext($context, "csale"));
        echo "\"></td>
\t\t\t<td>
\t\t\t\t<select name=\"cate_id\" class=\"input-small\">
\t\t\t\t\t<option value=\"\">请选择</option>
\t\t\t\t\t";
        // line 45
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["cate_kv_list"]) ? $context["cate_kv_list"] : $this->getContext($context, "cate_kv_list")));
        foreach ($context['_seq'] as $context["k"] => $context["v"]) {
            // line 46
            echo "\t\t\t\t\t";
            if (((isset($context["cate_id"]) ? $context["cate_id"] : $this->getContext($context, "cate_id")) == (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k")))) {
                // line 47
                echo "\t\t\t\t\t<option value=\"";
                echo (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k"));
                echo "\" selected=\"selected\">";
                echo (isset($context["v"]) ? $context["v"] : $this->getContext($context, "v"));
                echo "</option>
\t\t\t\t\t";
            } else {
                // line 49
                echo "\t\t\t\t\t<option value=\"";
                echo (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k"));
                echo "\">";
                echo (isset($context["v"]) ? $context["v"] : $this->getContext($context, "v"));
                echo "</option>
\t\t\t\t\t";
            }
            // line 51
            echo "\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['k'], $context['v'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 52
        echo "\t\t\t\t</select>
\t\t\t</td>
\t\t\t<td>
\t\t\t\t<select name=\"status\" class=\"input-small\">
\t\t\t\t\t<option value=\"all\">请选择</option>
\t\t\t\t\t";
        // line 57
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["item_status_list"]) ? $context["item_status_list"] : $this->getContext($context, "item_status_list")));
        foreach ($context['_seq'] as $context["ik"] => $context["isl"]) {
            // line 58
            echo "\t\t\t\t\t";
            if (($this->getAttribute((isset($context["isl"]) ? $context["isl"] : $this->getContext($context, "isl")), "selected", array(), "array") == 1)) {
                // line 59
                echo "\t\t\t\t\t<option value=\"";
                echo (isset($context["ik"]) ? $context["ik"] : $this->getContext($context, "ik"));
                echo "\" selected=\"selected\">";
                echo $this->getAttribute((isset($context["isl"]) ? $context["isl"] : $this->getContext($context, "isl")), "name", array(), "array");
                echo "</option>
\t\t\t\t\t";
            } else {
                // line 61
                echo "\t\t\t\t\t<option value=\"";
                echo (isset($context["ik"]) ? $context["ik"] : $this->getContext($context, "ik"));
                echo "\">";
                echo $this->getAttribute((isset($context["isl"]) ? $context["isl"] : $this->getContext($context, "isl")), "name", array(), "array");
                echo "</option>
\t\t\t\t\t";
            }
            // line 63
            echo "\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['ik'], $context['isl'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 64
        echo "\t\t\t\t</select>
\t\t\t</td>
\t\t\t<td>
\t\t\t\t<button class=\"btn btn-primary\" type=\"submit\">查找</button>
\t\t\t</td>
\t\t</tr>
\t\t";
        // line 70
        if ((!twig_test_empty((isset($context["list"]) ? $context["list"] : $this->getContext($context, "list"))))) {
            // line 71
            echo "\t\t";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["list"]) ? $context["list"] : $this->getContext($context, "list")));
            foreach ($context['_seq'] as $context["key"] => $context["row"]) {
                // line 72
                echo "\t\t<tr>
\t\t\t<td>";
                // line 73
                echo ((((isset($context["per_page"]) ? $context["per_page"] : $this->getContext($context, "per_page")) * ((isset($context["page"]) ? $context["page"] : $this->getContext($context, "page")) - 1)) + (isset($context["key"]) ? $context["key"] : $this->getContext($context, "key"))) + 1);
                echo "</td>
\t\t\t<td>
\t\t\t\t";
                // line 75
                if ((!twig_test_empty($this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "img_arr", array(), "array")))) {
                    // line 76
                    echo "\t\t\t\t<img style=\"width:64px; height:64px\" src=\"";
                    echo $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "img_arr", array(), "array"), 0, array(), "array"), "src", array(), "array");
                    echo "\">
\t\t\t\t";
                }
                // line 78
                echo "\t\t\t</td>
\t\t\t<td>";
                // line 79
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "title", array(), "array");
                echo "</td>
\t\t\t<td>";
                // line 80
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "mprice", array(), "array");
                echo "元</td>
\t\t\t<td>";
                // line 81
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "price", array(), "array");
                echo "元</td>
\t\t\t<td>";
                // line 82
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "stock", array(), "array");
                echo "</td>
\t\t\t<td><div><a href=\"javascript:;\" class=\"j_edit_totals_btn\">显示</a><div class=\"j_edit_totals_con\"><input value=\"";
                // line 83
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "csale", array(), "array");
                echo "\" class=\"j_text_value\" style=\"width:80px;\" /><br /><input type=\"button\" item_id=\"";
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "id", array(), "array");
                echo "\" class=\"j_edit_csale btn btn-small\" value=\"修改\" /></div></div></td>
\t\t\t<td>";
                // line 84
                if (($this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "cate_id", array(), "array") != 0)) {
                    echo $this->getAttribute((isset($context["cate_kv_list"]) ? $context["cate_kv_list"] : $this->getContext($context, "cate_kv_list")), $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "cate_id", array(), "array"), array(), "array");
                }
                echo "</td>
\t\t\t<td>";
                // line 85
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "status_name", array(), "array");
                echo "</td>
\t\t\t<td>
\t\t\t\t<a class=\"btn btn-small\" href=\"/mall/item_edit/";
                // line 87
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "id", array(), "array");
                echo "\"><i class=\"icon-edit\"></i> 编辑</a>
\t\t\t\t<a data-id=\"";
                // line 88
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "id", array(), "array");
                echo "\" class=\"btn btn-small btn-delete\"><i class=\"icon-trash\"></i> 删除</a>
\t\t\t</td>
\t\t</tr>
\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 92
            echo "\t\t";
        } else {
            // line 93
            echo "\t\t<tr><td colspan=\"10\" style=\"text-align: center;\">尚无商品信息</td></tr>
\t\t";
        }
        // line 95
        echo "\t\t</tbody>
\t</table>
</form>
";
        // line 98
        echo (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination"));
        echo "
";
    }

    // line 101
    public function block_script($context, array $blocks = array())
    {
        // line 102
        echo "<script type=\"text/javascript\">
\t\$(function(){
\t\t\$('.j_edit_totals_btn').on('click',function(){
\t\t\tif( \$(this).next().hasClass('j_edit_totals_con') ){
\t\t\t\t\$(this).text() == '隐藏' ? \$(this).text('显示') : \$(this).text('隐藏');
\t\t\t\t\$(this).next().toggle();
\t\t\t}\t
\t\t});
\t\t
\t\t\$(\".btn-delete\").click(function(){
\t\t\tif (confirm(\"您确定删除该商品吗？\")) {
\t\t\t\tvar id = \$(this).attr('data-id');
\t\t\t\tlocation.href = '/mall/item_del/'+id;
\t\t\t}
\t\t});
\t\t
\t\t\$('.j_edit_csale').on('click',function(){
\t\t\titem_id = \$(this).attr('item_id');
\t\t\tvalue = \$(this).parent().find('.j_text_value').val();
\t\t\tif( isNaN(value) ){
\t\t\t\talert('请填写数字');
\t\t\t}else if( value<0 ){
\t\t\t\talert('销量不能小于0');\t
\t\t\t}
\t\t\t\$.getJSON('/mall/edit_csale?item_id='+item_id+'&value='+value,function(data){
\t\t\t\tif( data.success==-1 ){
\t\t\t\t\talert(data.msg);\t
\t\t\t\t}
\t\t\t\tif( data.success==1 ){
\t\t\t\t\twindow.location.reload();
\t\t\t\t}
\t\t\t});
\t\t});
\t});
</script>
";
    }

    public function getTemplateName()
    {
        return "mall/lists.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  257 => 102,  254 => 101,  248 => 98,  243 => 95,  239 => 93,  236 => 92,  226 => 88,  222 => 87,  217 => 85,  211 => 84,  205 => 83,  201 => 82,  197 => 81,  193 => 80,  189 => 79,  186 => 78,  180 => 76,  178 => 75,  173 => 73,  170 => 72,  165 => 71,  163 => 70,  155 => 64,  149 => 63,  141 => 61,  133 => 59,  130 => 58,  126 => 57,  119 => 52,  113 => 51,  105 => 49,  97 => 47,  94 => 46,  90 => 45,  83 => 41,  79 => 40,  75 => 39,  71 => 38,  67 => 37,  32 => 4,  29 => 3,);
    }
}
