<?php

/* business_card/index.html */
class __TwigTemplate_b1324f979cf2fd1a3d088357833e7741 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'style' => array($this, 'block_style'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "
<ul class=\"breadcrumb clearfix\">
    <li><a href=\"/business_card/index\">微名片设置</a> </li>
</ul>
<div class=\"well\">
\t<form class=\"form-horizontal\" action=\"\" method=\"post\">
\t\t
        <div class=\"control-group\">
\t\t\t<label class=\"control-label\"><span class=\"red\">* </span><b>默认单位</b></label>
\t\t\t<div class=\"controls\">
\t\t\t\t<select name=\"company_id\" style=\"width:150px;\">
                \t";
        // line 15
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["address_list"]) ? $context["address_list"] : $this->getContext($context, "address_list")));
        foreach ($context['_seq'] as $context["_key"] => $context["val"]) {
            // line 16
            echo "                    <option value=\"";
            echo $this->getAttribute((isset($context["val"]) ? $context["val"] : $this->getContext($context, "val")), "id");
            echo "\" ";
            if ($this->getAttribute((isset($context["bcard_config"]) ? $context["bcard_config"] : null), "company_id", array(), "any", true, true)) {
                if (($this->getAttribute((isset($context["bcard_config"]) ? $context["bcard_config"] : $this->getContext($context, "bcard_config")), "company_id") == $this->getAttribute((isset($context["val"]) ? $context["val"] : $this->getContext($context, "val")), "id"))) {
                    echo " selected=\"selected\"";
                }
            }
            echo ">";
            echo $this->getAttribute((isset($context["val"]) ? $context["val"] : $this->getContext($context, "val")), "name");
            echo "</option>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['val'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 18
        echo "                </select>
\t\t\t</div>
\t\t</div>

        <hr />

        <div class=\"control-group\">
            <label class=\"control-label\"><span class=\"red\">* </span><b>模版样式</b></label>
            <div class=\"controls\">
                <select name=\"bcard_tpl\" id=\"select_card\" style=\"width:130px;\">
                    ";
        // line 28
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["bcard_tpl"]) ? $context["bcard_tpl"] : $this->getContext($context, "bcard_tpl")));
        foreach ($context['_seq'] as $context["key"] => $context["tpl"]) {
            // line 29
            echo "                    <option value=\"";
            echo (isset($context["key"]) ? $context["key"] : $this->getContext($context, "key"));
            echo "\" ";
            if ($this->getAttribute((isset($context["bcard_config"]) ? $context["bcard_config"] : null), "tpl", array(), "any", true, true)) {
                if (($this->getAttribute((isset($context["bcard_config"]) ? $context["bcard_config"] : $this->getContext($context, "bcard_config")), "tpl") == (isset($context["key"]) ? $context["key"] : $this->getContext($context, "key")))) {
                    echo "selected=\"selected\"";
                }
            }
            echo ">";
            echo (isset($context["tpl"]) ? $context["tpl"] : $this->getContext($context, "tpl"));
            echo "</option>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['tpl'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 31
        echo "                </select>
            </div>
        </div>

        <div class=\"control-group\" style=\"position:relative;\"><div style=\"position:absolute; left:600px; top:50px; width:250px;\">微名片效果图<img id=\"show_mp\" src=\"/assets/img/20131204100042.jpg\" style=\"width:100%;\" /></div>
        \t<span class=\"tips\">注：不勾选则不显示；新选项如更换名称，请修改相应数据；取消勾选，名片中该信息隐藏但数据仍然保留</span>
\t\t\t<!--隐藏部分-->
            <input type=\"hidden\" name=\"m_config[name][1]\" value=\"m_address\" />
            <input type=\"hidden\" name=\"m_config[value][1]\" value=\"地址\" />
            
            <input type=\"hidden\" name=\"m_config[name][2]\" value=\"m_mobile\" />
            <input type=\"hidden\" name=\"m_config[value][2]\" value=\"手机\" />
            
            <input type=\"hidden\" name=\"m_config[name][10]\" value=\"m_tele\" />
            <input type=\"hidden\" name=\"m_config[value][10]\" value=\"电话\" />
            
            <input type=\"hidden\" name=\"m_config[name][3]\" value=\"m_department\" />
            <input type=\"hidden\" name=\"m_config[value][3]\" value=\"部门\" />
            
            <input type=\"hidden\" name=\"m_config[name][4]\" value=\"m_port\" />
            <input type=\"hidden\" name=\"m_config[value][4]\" value=\"职位\" />
            
            
            <label class=\"control-label\"><span class=\"red\">* </span><b>名片信息</b></label>
\t\t\t<div class=\"controls\">
            \t<div class=\"j_config_list\">
                    <label><input type=\"checkbox\" checked=\"checked\" disabled=\"disabled\"/>&nbsp;地址</label>
                    <br /><label><input type=\"checkbox\" checked=\"checked\" disabled=\"disabled\" />&nbsp;手机</label>
                    <br /><label><input type=\"checkbox\" checked=\"checked\" disabled=\"disabled\" />&nbsp;电话</label>
                    <br /><label><input type=\"checkbox\" checked=\"checked\" disabled=\"disabled\" />&nbsp;部门</label>
                    <br /><label><input type=\"checkbox\" checked=\"checked\" disabled=\"disabled\" />&nbsp;职位</label>
                    
                    
                    <br /><label><input type=\"checkbox\" name=\"m_config[name][5]\" ";
        // line 64
        if ($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "m_email", array(), "array", true, true)) {
            echo "checked=\"checked\"";
        }
        echo " value=\"m_email\" />&nbsp;邮箱</label><input type=\"hidden\" name=\"m_config[value][5]\" value=\"邮箱\" />
                    
                    <br /><label><input type=\"checkbox\" name=\"m_config[name][6]\" ";
        // line 66
        if ($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "m_weibo", array(), "array", true, true)) {
            echo "checked=\"checked\"";
        }
        echo " value=\"m_weibo\" />&nbsp;微博</label><input type=\"hidden\" name=\"m_config[value][6]\" value=\"微博\" />
                    
                    <br /><label><input type=\"checkbox\" name=\"m_config[name][7]\" ";
        // line 68
        if ($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "m_weixin", array(), "array", true, true)) {
            echo "checked=\"checked\"";
        }
        echo " value=\"m_weixin\" />&nbsp;微信</label><input type=\"hidden\" name=\"m_config[value][7]\" value=\"微信\" />
                    
                    <br /><label><input type=\"checkbox\" name=\"m_config[name][8]\" ";
        // line 70
        if ($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "m_QQ", array(), "array", true, true)) {
            echo "checked=\"checked\"";
        }
        echo " value=\"m_QQ\" />&nbsp;QQ</label><input type=\"hidden\" name=\"m_config[value][8]\" value=\"QQ\" />
                    
                    <br /><label><input type=\"checkbox\" name=\"m_config[name][9]\" ";
        // line 72
        if ($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "m_sign", array(), "array", true, true)) {
            echo "checked=\"checked\"";
        }
        echo " value=\"m_sign\" />&nbsp;个性签名</label><input type=\"hidden\" name=\"m_config[value][9]\" value=\"个性签名\" />
               \t\t<br /><label><input type=\"checkbox\" name=\"m_config[name][11]\" ";
        // line 73
        if ($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "m_fax", array(), "array", true, true)) {
            echo "checked=\"checked\"";
        }
        echo " value=\"m_fax\" />&nbsp;传真</label><input type=\"hidden\" name=\"m_config[value][11]\" value=\"传真\" />
                    
                    
                    ";
        // line 76
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["custom"]) ? $context["custom"] : $this->getContext($context, "custom")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["val"]) {
            // line 77
            echo "                    <br /><label><input type=\"checkbox\" class=\"m_custom\" name=\"m_custom[name][";
            echo $this->getAttribute((isset($context["loop"]) ? $context["loop"] : $this->getContext($context, "loop")), "index");
            echo "]\" ";
            if (($this->getAttribute((isset($context["val"]) ? $context["val"] : $this->getContext($context, "val")), "sele") == 1)) {
                echo "checked=\"checked\"";
            }
            echo " value=\"1\" /></label>&nbsp;<input type=\"text\" name=\"m_custom[value][";
            echo $this->getAttribute((isset($context["loop"]) ? $context["loop"] : $this->getContext($context, "loop")), "index");
            echo "]\" value=\"";
            echo $this->getAttribute((isset($context["val"]) ? $context["val"] : $this->getContext($context, "val")), "value");
            echo "\" style=\"width:100px;\" /><span class=\"tips\">请不要超过10个字</span>
                    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['val'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 79
        echo "                    
                </div>
                <br />
                <span ";
        // line 82
        if (((isset($context["last_num"]) ? $context["last_num"] : $this->getContext($context, "last_num")) == 0)) {
            echo "style=\"display:none;\"";
        }
        echo "><a href=\"javascript:;\" class=\"j_config_add\">添加新选项</a>（还能添加<span class=\"j_config_last_num\">";
        echo (isset($context["last_num"]) ? $context["last_num"] : $this->getContext($context, "last_num"));
        echo "</span>个）</span>
\t\t\t</div>
\t\t</div>
        
        <div class=\"control-group\">
\t\t\t<label class=\"control-label\"><span class=\"red\">* </span><b>背景</b></label>
\t\t\t<div class=\"controls\">
            \t<!--<span>推荐尺寸：720 X 360<br />建议比例：2:1</span><br />-->
                ";
        // line 90
        if (($this->getAttribute((isset($context["bcard_config"]) ? $context["bcard_config"] : null), "bg_img", array(), "any", true, true) && $this->getAttribute((isset($context["bcard_config"]) ? $context["bcard_config"] : $this->getContext($context, "bcard_config")), "bg_img"))) {
            // line 91
            echo "                <img src=\"";
            echo $this->getAttribute((isset($context["bcard_config"]) ? $context["bcard_config"] : $this->getContext($context, "bcard_config")), "bg_img");
            echo "\" style=\"width:320px;height:160px;margin:0 0 5px 0;\" class=\"img-polaroid\">
                <input type=\"button\" class=\"btn j_img_clear\" value=\"删除\"/>
                <input type=\"hidden\" class=\"img_value\" name=\"bg_img\" value=\"";
            // line 93
            echo $this->getAttribute((isset($context["bcard_config"]) ? $context["bcard_config"] : $this->getContext($context, "bcard_config")), "bg_img");
            echo "\">
                <div id=\"uploader-img\"></div>
                ";
        } else {
            // line 96
            echo "                <img src=\"http://c.bama555.com/assets/img/no_bcard_bg.jpg\" style=\"width:320px;height:160px;margin:0 0 5px 0;\" class=\"img-polaroid\">
                <input type=\"button\" class=\"btn j_img_clear\" value=\"删除\"/>
                <input type=\"hidden\" class=\"img_value\" name=\"bg_img\" value=\"http://c.bama555.com/assets/img/no_bcard_bg.jpg\">
                <div id=\"uploader-img\"></div>
                ";
        }
        // line 101
        echo "\t\t\t</div>
\t\t</div>
        
        <div class=\"control-group\">
\t\t\t<label class=\"control-label\"><b>背景链接地址</b></label>
\t\t\t<div class=\"controls\">
\t\t\t\t<input type=\"text\" name=\"behind_url\" placeholder=\"http://\" value=\"";
        // line 107
        if ($this->getAttribute((isset($context["bcard_config"]) ? $context["bcard_config"] : null), "behind_url", array(), "any", true, true)) {
            echo $this->getAttribute((isset($context["bcard_config"]) ? $context["bcard_config"] : $this->getContext($context, "bcard_config")), "behind_url");
        }
        echo "\">
                
\t\t\t</div>
\t\t</div>
\t\t
\t\t<div class=\"control-group\">
\t\t\t<div class=\"controls\">
\t\t\t\t<button type=\"submit\" class=\"btn btn-primary\">确认保存</button>
\t\t\t</div>
\t\t</div>
\t</form>
</div>


";
    }

    // line 123
    public function block_style($context, array $blocks = array())
    {
        // line 124
        echo "<link href=\"/assets/huploadify/Huploadify.css\" rel=\"stylesheet\">
<style type=\"text/css\">
    .tips{color:#999; margin-left:20px;}
    .controls label{display:inline;}
    .selected {border: 1px #ff0000 solid;}
    .uploadify-button{
        color: #333;
        background-color: #fff;
        border-color: #ccc;
        cursor:pointer;
        text-decoration:none;
        border-radius: 2px;
        margin-left: 0;
    }
    .uploadify-button:hover {
        background-color: #ccc;
        background-image: none;
        background-position: center bottom;
        cursor:pointer;
        text-decoration:none;
    }
</style>
";
    }

    // line 148
    public function block_script($context, array $blocks = array())
    {
        // line 149
        echo "<script src=\"/assets/js/lhgcalendar.min.js\"></script>
<script src=\"/assets/js/kindeditor/kindeditor-all-min.js\"></script>
<script src=\"/assets/js/kindeditor/lang/zh_CN.js\"></script>
<script src=\"/assets/huploadify/jquery.Huploadify.js\"></script>
<script type=\"text/javascript\">
\t\$(function() {
\t\t//删除图片
\t\t\$(document).on('click','.j_img_clear',function(){
\t\t\t\$(this).next('input').val('http://c.bama555.com/assets/img/no_bcard_bg.jpg');
\t\t\t\$(this).prevAll('img').attr('src','http://c.bama555.com/assets/img/no_bcard_bg.jpg');
\t\t});
\t\t
\t\t\$('.j_config_add').on('click',function(){
\t\t\tnum = \$('input[class=\"m_custom\"]').length;
\t\t\tif( num<3 ){
\t\t\t\thtml = '<br /><label><input type=\"checkbox\" class=\"m_custom\" name=\"m_custom[name]['+(num+1)+']\" value=\"1\" /></label>&nbsp;<input type=\"text\" name=\"m_custom[value]['+(num+1)+']\" value=\"\" style=\"width:100px;\" /><span class=\"tips\">请不要超过10个字</span>';
\t\t\t\t\$('.j_config_list').append(html);
\t\t\t\t\$('.j_config_last_num').html(3-num-1);
\t\t\t\t
\t\t\t\tif( num+1==3 ){
\t\t\t\t\t\$('.j_config_add').parent('span').hide();\t
\t\t\t\t}
\t\t\t}
\t\t});
\t\t
\t\t\$('#uploader-img').Huploadify({
            'fileObjName': 'image',
            'fileSizeLimit': 2048,
            'fileTypeExts': '*.gif; *.jpg; *.png',
            'multi': false,
            'auto':true,
            'showUploadedPercent':false,
            'removeTimeout': 0,
\t\t\t'buttonText': '选择背景',
\t\t\t'formData': {'token': '";
        // line 183
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
\t\t\t'uploader': '/image/upload_gd',
\t\t\t'onUploadSuccess': function(file, data) {
                var ret = \$.parseJSON(data);
                if (ret) {
                    if (ret.success) {
                        \$('#uploader-img').parent().find('.img_value').val(ret.image);
                        \$('#uploader-img').parent().find('img').attr('src', ret.image);
                    } else {
                        alert(ret.message);
                    }
                }
\t\t\t}
\t\t});


        //配置模板和图片地址
        var _tpl_image = {
            'default'  : '/assets/img/20131204100042.jpg',
            'default1' : 'http://image.bama555.com/data/201407/16/d51447307374c0fc33098307e3f95d0d_500_577.jpg',
            'default2' : 'http://image.bama555.com/data/201407/16/17d69d06a178c0c366a2d1db3176dabb_500_577.jpg',
            'default3' : 'http://image.bama555.com/data/201407/16/8a770594c8dafa808e3d3ab3eed5056b_500_577.jpg',
            'default4' : 'http://image.bama555.com/data/201407/16/df2a4157ed8f54086dcf15c106f1adf9_500_577.jpg',
            'default5' : 'http://image.bama555.com/data/201407/16/92470f83c6c17c6f8f920964ce86ac80_500_577.jpg'
        };
        //配置每个模板的默认图片
        var _tpl_default_image = {
            'default'  : '/assets/img/no_bcard_bg.jpg',
            'default1' : 'http://image.bama555.com/data/201407/16/5d0008c0574efd4da056553e24843b3d_640_430.jpg',
            'default2' : 'http://image.bama555.com/data/201407/16/5e0a06e2411219988955c2825d5223c6_640_1011.jpg',
            'default3' : 'http://image.bama555.com/data/201407/16/275c5ba0d6de8183cda95f1231a793df_640_1011.jpg',
            'default4' : 'http://image.bama555.com/data/201407/16/aa5837325bf1f940efbf2d3cc02a68bb_640_218.jpg',
            'default5' : 'http://image.bama555.com/data/201407/16/c233a242739be6a8198a256e26cbc74f_640_1010.jpg'
        };
        \$(\"#show_mp\").attr(\"src\", _tpl_image[\$(\"#select_card option:selected\").val()]);
        /*\$(\".img-polaroid\").attr(\"src\", _tpl_default_image[\$(\"#select_card option:selected\").val()])
        \$(\".img_value\").val(_tpl_default_image[\$(\"#select_card option:selected\").val()]);*/
\t\t\$(\"#select_card\").on(\"change\", function() {
            _val = \$(this).val();
            \$(\"#show_mp\").attr(\"src\", _tpl_image[_val]);
            \$(\".img-polaroid\").attr(\"src\", _tpl_default_image[_val])
            \$(\".img_value\").val(_tpl_default_image[_val]);
        })

\t});
</script>
";
    }

    public function getTemplateName()
    {
        return "business_card/index.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  357 => 183,  321 => 149,  318 => 148,  292 => 124,  289 => 123,  268 => 107,  260 => 101,  253 => 96,  247 => 93,  241 => 91,  239 => 90,  224 => 82,  219 => 79,  194 => 77,  177 => 76,  169 => 73,  163 => 72,  156 => 70,  149 => 68,  142 => 66,  135 => 64,  100 => 31,  83 => 29,  79 => 28,  67 => 18,  50 => 16,  46 => 15,  33 => 4,  30 => 3,);
    }
}
