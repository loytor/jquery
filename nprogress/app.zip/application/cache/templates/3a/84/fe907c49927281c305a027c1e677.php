<?php

/* assist/setting.html */
class __TwigTemplate_3a84fe907c49927281c305a027c1e677 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "<link href=\"/assets/css/custom_menu.css\" rel=\"stylesheet\" />
<link href=\"/assets/huploadify/Huploadify.css\" rel=\"stylesheet\">
<style type=\"text/css\" >
    .tips{color:#999; margin-left:20px;}
    .uploadify-button{
        color: #333;
        background-color: #fff;
        border-color: #ccc;
        cursor:pointer;
        text-decoration:none;
        border-radius: 2px;
        margin-left: 0;
    }
    .uploadify-button:hover {
        background-color: #ccc;
        background-image: none;
        background-position: center bottom;
        cursor:pointer;
        text-decoration:none;
    }
</style>
<script src=\"/assets/huploadify/jquery.Huploadify.js\"></script>

<ul class=\"breadcrumb clearfix\">
\t<div>
\t\t<a href=\"/assist/setting\" class=\"btn active\"><i class=\"icon-cog\"></i> 基本设置</a>
\t\t<a href=\"/assist\" class=\"btn\"><i class=\"icon-list\"></i> 辅助按钮列表</a>
\t</div>
</ul>

<div class=\"well\">
\t<form class=\"form-horizontal\" action=\"\" method=\"post\" enctype=\"multipart/form-data\">
\t\t<div class=\"control-group\">
            <label class=\"control-label\">类型：</label>
            <div class=\"controls\">
                <label class=\"radio inline\">
                    ";
        // line 40
        if ((($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "type", array(), "array", true, true) && ($this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "type", array(), "array") == 0)) || (!$this->getAttribute((isset($context["config"]) ? $context["config"] : null), "type", array(), "array", true, true)))) {
            // line 41
            echo "                    <input type=\"radio\" name=\"config[type]\" checked=\"checked\" value=\"0\"> 小转轮
                    ";
        } else {
            // line 43
            echo "                    <input type=\"radio\" name=\"config[type]\" value=\"0\"> 小转轮
                    ";
        }
        // line 45
        echo "                </label>
                <label class=\"radio inline\">
                    ";
        // line 47
        if (($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "type", array(), "array", true, true) && ($this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "type", array(), "array") == 1))) {
            // line 48
            echo "                    <input type=\"radio\" name=\"config[type]\" checked=\"checked\" value=\"1\"> 底部条
                    ";
        } else {
            // line 50
            echo "                    <input type=\"radio\" name=\"config[type]\" value=\"1\"> 底部条
                    ";
        }
        // line 52
        echo "                </label>
\t            <label class=\"radio inline\">
\t\t            ";
        // line 54
        if (($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "type", array(), "array", true, true) && ($this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "type", array(), "array") == 2))) {
            // line 55
            echo "\t\t            <input type=\"radio\" name=\"config[type]\" checked=\"checked\" value=\"2\"> 底部条(带HOME键)
\t\t            ";
        } else {
            // line 57
            echo "\t\t            <input type=\"radio\" name=\"config[type]\" value=\"2\"> 底部条(带HOME键)
\t\t            ";
        }
        // line 59
        echo "\t            </label>
                <label class=\"radio inline\">
                    ";
        // line 61
        if (($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "type", array(), "array", true, true) && ($this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "type", array(), "array") == 3))) {
            // line 62
            echo "                    <input type=\"radio\" name=\"config[type]\" checked=\"checked\" value=\"3\"> 自定义菜单
                    ";
        } else {
            // line 64
            echo "                    <input type=\"radio\" name=\"config[type]\" value=\"3\"> 自定义菜单
                    ";
        }
        // line 66
        echo "                </label>
                <!--新加带home的自定义菜单-->
                <label class=\"radio inline\">
                    ";
        // line 69
        if (($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "type", array(), "array", true, true) && ($this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "type", array(), "array") == 4))) {
            // line 70
            echo "                    <input type=\"radio\" name=\"config[type]\" checked=\"checked\" value=\"4\"> 自定义菜单(带HOME键)
                    ";
        } else {
            // line 72
            echo "                        <input type=\"radio\" name=\"config[type]\" value=\"4\"> 自定义菜单(带HOME键)
                    ";
        }
        // line 74
        echo "                </label>
            </div>
        </div>
        <div class=\"control-group\">
            <label class=\"control-label\">显示：</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<label class=\"radio inline\">
\t\t\t\t\t";
        // line 81
        if ((($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "display", array(), "array", true, true) && ($this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "display", array(), "array") == 0)) || (!$this->getAttribute((isset($context["config"]) ? $context["config"] : null), "display", array(), "array", true, true)))) {
            // line 82
            echo "\t\t\t\t\t<input type=\"radio\" name=\"config[display]\" checked=\"checked\" value=\"0\"> 不显示
\t\t\t\t\t";
        } else {
            // line 84
            echo "\t\t\t\t\t<input type=\"radio\" name=\"config[display]\" value=\"0\"> 不显示
\t\t\t\t\t";
        }
        // line 86
        echo "\t\t\t\t</label>
\t\t\t\t<label class=\"radio inline\">
\t\t\t\t\t";
        // line 88
        if (($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "display", array(), "array", true, true) && ($this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "display", array(), "array") == 1))) {
            // line 89
            echo "\t\t\t\t\t<input type=\"radio\" name=\"config[display]\" checked=\"checked\" value=\"1\"> 首页显示
\t\t\t\t\t";
        } else {
            // line 91
            echo "\t\t\t\t\t<input type=\"radio\" name=\"config[display]\" value=\"1\"> 首页显示
\t\t\t\t\t";
        }
        // line 93
        echo "\t\t\t\t</label>
                <label class=\"radio inline\">
                    ";
        // line 95
        if (($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "display", array(), "array", true, true) && ($this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "display", array(), "array") == 3))) {
            // line 96
            echo "                    <input type=\"radio\" name=\"config[display]\" checked=\"checked\" value=\"3\"> 内页显示
                    ";
        } else {
            // line 98
            echo "                    <input type=\"radio\" name=\"config[display]\" value=\"3\"> 内页显示
                    ";
        }
        // line 100
        echo "                </label>
\t\t\t\t<label class=\"radio inline\">
\t\t\t\t\t";
        // line 102
        if (($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "display", array(), "array", true, true) && ($this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "display", array(), "array") == 2))) {
            // line 103
            echo "\t\t\t\t\t<input type=\"radio\" name=\"config[display]\" checked=\"checked\" value=\"2\"> 整站显示
\t\t\t\t\t";
        } else {
            // line 105
            echo "\t\t\t\t\t<input type=\"radio\" name=\"config[display]\" value=\"2\"> 整站显示
\t\t\t\t\t";
        }
        // line 107
        echo "\t\t\t\t</label>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group ";
        // line 110
        if (($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "type", array(), "array", true, true) && ((($this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "type", array(), "array") == 1) || ($this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "type", array(), "array") == 2)) || ($this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "type", array(), "array") == 3)))) {
            echo "hide";
        }
        echo "\" id=\"J_position\">
\t\t\t<label class=\"control-label\">页面显示位置：</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<label class=\"radio inline\">
\t\t\t\t\t";
        // line 114
        if ((($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "position", array(), "array", true, true) && ($this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "position", array(), "array") == 0)) || (!$this->getAttribute((isset($context["config"]) ? $context["config"] : null), "position", array(), "array", true, true)))) {
            // line 115
            echo "\t\t\t\t\t<input type=\"radio\" name=\"config[position]\" checked=\"checked\" value=\"0\"> 左下
\t\t\t\t\t";
        } else {
            // line 117
            echo "\t\t\t\t\t<input type=\"radio\" name=\"config[position]\" value=\"0\"> 左下
\t\t\t\t\t";
        }
        // line 119
        echo "\t\t\t\t</label>
<!--\t\t\t\t<label class=\"radio inline\">
\t\t\t\t\t";
        // line 121
        if (($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "position", array(), "array", true, true) && ($this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "position", array(), "array") == 1))) {
            // line 122
            echo "\t\t\t\t\t<input type=\"radio\" name=\"config[position]\" checked=\"checked\" value=\"1\"> 居中
\t\t\t\t\t";
        } else {
            // line 124
            echo "\t\t\t\t\t<input type=\"radio\" name=\"config[position]\" value=\"1\"> 居中
\t\t\t\t\t";
        }
        // line 126
        echo "\t\t\t\t</label>-->
\t\t\t\t<label class=\"radio inline\">
\t\t\t\t\t";
        // line 128
        if (($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "position", array(), "array", true, true) && ($this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "position", array(), "array") == 2))) {
            // line 129
            echo "\t\t\t\t\t<input type=\"radio\" name=\"config[position]\" checked=\"checked\" value=\"2\"> 右下
\t\t\t\t\t";
        } else {
            // line 131
            echo "\t\t\t\t\t<input type=\"radio\" name=\"config[position]\" value=\"2\"> 右下
\t\t\t\t\t";
        }
        // line 133
        echo "\t\t\t\t</label>
\t\t\t</div>
\t\t</div>



        <div class=\"control-group ";
        // line 139
        if (($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "type", array(), "array", true, true) && ((($this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "type", array(), "array") == 0) || ($this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "type", array(), "array") == 1)) || ($this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "type", array(), "array") == 2)))) {
            echo "hide";
        }
        echo "\" id=\"J_menu\">
            <label class=\"control-label\">菜单数据：</label>
            <div class=\"controls\">

                <div class=\"alert alert-error\">
                    <p>提醒：<br/></p>

                    <p>1. 菜单数据以下面填写为准。</p>

                    <p>2. 菜单名称不能超过四个字符。</p>
                </div>

                <table class=\"table table-hover table-bordered table-menu\">
                    <thead>
                    <tr>
                        <th style=\"width:120px;\">顺序</th>
                        <th>菜单名称</th>
                        <th>链接</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    ";
        // line 161
        if (($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "menu", array(), "array", true, true) && (!twig_test_empty($this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "menu", array(), "array"))))) {
            // line 162
            echo "                    ";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "menu", array(), "array"));
            foreach ($context['_seq'] as $context["i"] => $context["_menu"]) {
                // line 163
                echo "                    <tr class=\"main\" main-index=\"";
                echo (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i"));
                echo "\">
                        <td><input name=\"config[menu][";
                // line 164
                echo (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i"));
                echo "][rank]\" class=\"input-mini rank\" type=\"text\" value=\"";
                if ($this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : null), "rank", array(), "array", true, true)) {
                    echo $this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : $this->getContext($context, "_menu")), "rank", array(), "array");
                }
                echo "\"></td>
                        <td><input name=\"config[menu][";
                // line 165
                echo (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i"));
                echo "][name]\" class=\"input-medium name\" type=\"text\" value=\"";
                if ($this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : null), "name", array(), "array", true, true)) {
                    echo $this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : $this->getContext($context, "_menu")), "name", array(), "array");
                }
                echo "\"><a class=\"btn btn-small btn-addsub\"><i class=\"icon-plus\"></i> 添加子菜单</a></td>
                        <td class=\"td-keyword\">
                            ";
                // line 167
                if ($this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : null), "link", array(), "array", true, true)) {
                    // line 168
                    echo "                            <input name=\"config[menu][";
                    echo (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i"));
                    echo "][keyword]\" class=\"input-medium keyword\" type=\"text\" value=\"";
                    if ($this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : null), "link", array(), "array", true, true)) {
                        echo $this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : $this->getContext($context, "_menu")), "link", array(), "array");
                    }
                    echo "\">
                            ";
                }
                // line 170
                echo "                        </td>
                        <td>
                            ";
                // line 172
                if ($this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : null), "link", array(), "array", true, true)) {
                    // line 173
                    echo "                            <input name=\"config[menu][";
                    echo (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i"));
                    echo "][key]\" class=\"key\" type=\"hidden\" value=\"";
                    if ($this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : null), "link", array(), "array", true, true)) {
                        echo $this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : $this->getContext($context, "_menu")), "link", array(), "array");
                    }
                    echo "\" >
                            ";
                }
                // line 175
                echo "                            <a class=\"btn btn-small btn-main-del\"><i class=\"icon-trash\"></i> 删除</a>
                        </td>
                    </tr>
                    ";
                // line 178
                if (($this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : null), "sub_menu", array(), "array", true, true) && (!twig_test_empty($this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : $this->getContext($context, "_menu")), "sub_menu", array(), "array"))))) {
                    // line 179
                    echo "                    ";
                    $context['_parent'] = (array) $context;
                    $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : $this->getContext($context, "_menu")), "sub_menu", array(), "array"));
                    foreach ($context['_seq'] as $context["k"] => $context["_submenu"]) {
                        // line 180
                        echo "                    <tr class=\"sub\" parent-index=\"";
                        echo (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i"));
                        echo "\">
                        <td><div class=\"sub-node\"><input name=\"config[menu][";
                        // line 181
                        echo (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i"));
                        echo "][sub_menu][";
                        echo (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k"));
                        echo "][rank]\" class=\"input-mini rank\" type=\"text\" value=\"";
                        if ($this->getAttribute((isset($context["_submenu"]) ? $context["_submenu"] : null), "rank", array(), "array", true, true)) {
                            echo $this->getAttribute((isset($context["_submenu"]) ? $context["_submenu"] : $this->getContext($context, "_submenu")), "rank", array(), "array");
                        }
                        echo "\"></div></td>
                        <td><div class=\"sub-node\"><input name=\"config[menu][";
                        // line 182
                        echo (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i"));
                        echo "][sub_menu][";
                        echo (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k"));
                        echo "][name]\" class=\"input-medium name\" type=\"text\" value=\"";
                        if ($this->getAttribute((isset($context["_submenu"]) ? $context["_submenu"] : null), "name", array(), "array", true, true)) {
                            echo $this->getAttribute((isset($context["_submenu"]) ? $context["_submenu"] : $this->getContext($context, "_submenu")), "name", array(), "array");
                        }
                        echo "\"></div></td>
                        <td class=\"td-keyword\">
                            ";
                        // line 184
                        if ($this->getAttribute((isset($context["_submenu"]) ? $context["_submenu"] : null), "link", array(), "array", true, true)) {
                            // line 185
                            echo "                            <input name=\"config[menu][";
                            echo (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i"));
                            echo "][sub_menu][";
                            echo (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k"));
                            echo "][keyword]\" class=\"input-medium keyword\" type=\"text\" value=\"";
                            if ($this->getAttribute((isset($context["_submenu"]) ? $context["_submenu"] : null), "link", array(), "array", true, true)) {
                                echo $this->getAttribute((isset($context["_submenu"]) ? $context["_submenu"] : $this->getContext($context, "_submenu")), "link", array(), "array");
                            }
                            echo "\">
                            ";
                        }
                        // line 187
                        echo "                        </td>
                        <td>
                            ";
                        // line 189
                        if ($this->getAttribute((isset($context["_submenu"]) ? $context["_submenu"] : null), "link", array(), "array", true, true)) {
                            // line 190
                            echo "                            <input name=\"config[menu][";
                            echo (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i"));
                            echo "][sub_menu][";
                            echo (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k"));
                            echo "][key]\" class=\"key\" type=\"hidden\" value=\"";
                            if ($this->getAttribute((isset($context["_submenu"]) ? $context["_submenu"] : null), "link", array(), "array", true, true)) {
                                echo $this->getAttribute((isset($context["_submenu"]) ? $context["_submenu"] : $this->getContext($context, "_submenu")), "link", array(), "array");
                            }
                            echo "\" >
                            ";
                        }
                        // line 192
                        echo "                            <a class=\"btn btn-small btn-sub-del\"><i class=\"icon-trash\"></i> 删除</a>
                        </td>
                    </tr>
                    ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['k'], $context['_submenu'], $context['_parent'], $context['loop']);
                    $context = array_merge($_parent, array_intersect_key($context, $_parent));
                    // line 196
                    echo "                    ";
                }
                // line 197
                echo "                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['i'], $context['_menu'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 198
            echo "                    ";
            if ((twig_length_filter($this->env, $this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "menu", array(), "array")) < 4)) {
                // line 199
                echo "                    <tr class=\"add-main\">
                        <td colspan=\"4\"><a class=\"btn btn-small btn-addmain\"><i class=\"icon-plus\"></i> 添加主菜单</a></td>
                    </tr>
                    ";
            } else {
                // line 203
                echo "                    <tr class=\"add-main\" style=\"display:none\">
                        <td colspan=\"4\"><a class=\"btn btn-small btn-addmain\"><i class=\"icon-plus\"></i> 添加主菜单</a></td>
                    </tr>
                    ";
            }
            // line 207
            echo "                    ";
        } else {
            // line 208
            echo "                    <tr class=\"add-main\">
                        <td colspan=\"4\"><a class=\"btn btn-small btn-addmain\"><i class=\"icon-plus\"></i> 添加主菜单</a></td>
                    </tr>
                    ";
        }
        // line 212
        echo "                    </tbody>
                </table>

            </div>
        </div>



        <div class=\"control-group ";
        // line 220
        if (($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "type", array(), "array", true, true) && ((($this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "type", array(), "array") == 0) || ($this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "type", array(), "array") == 1)) || ($this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "type", array(), "array") == 2)))) {
            echo "hide";
        }
        echo "\" id=\"J_menu_new\">
            <label class=\"control-label\">菜单数据：</label>
            <div class=\"controls\">

                <div class=\"alert alert-error\">
                    <p>提醒：<br/></p>

                    <p>1. 菜单数据以下面填写为准。</p>

                    <p>2. 菜单名称不能超过四个字符。</p>


                </div>

                <div>
                    <label>Home键图标：</label>
                    <input type=\"hidden\" name=\"config[pic]\" value=\"";
        // line 236
        if ($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "pic", array(), "array", true, true)) {
            echo $this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "pic", array(), "array");
        }
        echo "\">
                    <div id=\"uploader-img0\">

                        <input class=\"input-medium keyword\" name=\"config[url]\" type=\"text\" value=\"";
        // line 239
        if ($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "url", array(), "array", true, true)) {
            echo $this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "url", array(), "array");
        }
        echo "\">


                        ";
        // line 242
        if ($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "pic", array(), "array", true, true)) {
            // line 243
            echo "                        <img src=\"";
            echo $this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "pic", array(), "array");
            echo "\" class=\"img-polaroid\"  width=\"90px;\" heigth=\"90px;\" style=\"margin:0 0 5px 0;\">
                        ";
        } else {
            // line 245
            echo "                        <img src=\"/assets/img/no_image.png\" class=\"img-polaroid\" id=\"image-preview\"  style=\"margin:0 0 5px 0;\">
                        ";
        }
        // line 247
        echo "
                        <input type=\"button\" class=\"btn j_img_clear\" value=\"删除\" />
                        <input type=\"hidden\" name=\"img\" class=\"img_value\">
                    </div>
                </div>

                <table class=\"table table-hover table-bordered table-menu-home\">
                    <thead>
                    <tr>
                        <th style=\"width:120px;\">顺序</th>
                        <th>菜单名称</th>
                        <th>图标</th>
                        <th>链接</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody id=\"mycotent\">
                    ";
        // line 264
        if (($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "menu", array(), "array", true, true) && (!twig_test_empty($this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "menu", array(), "array"))))) {
            // line 265
            echo "                    ";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "menu", array(), "array"));
            foreach ($context['_seq'] as $context["i"] => $context["_menu"]) {
                // line 266
                echo "                        <tr class=\"main\" main-index=\"";
                echo (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i"));
                echo "\" data-main=\"";
                echo ((isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")) + 1);
                echo "\">
                            <td>
                                <input name=\"config[menu][";
                // line 268
                echo (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i"));
                echo "][rank]\" class=\"input-mini rank\" type=\"text\" value=\"";
                if ($this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : null), "rank", array(), "array", true, true)) {
                    echo $this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : $this->getContext($context, "_menu")), "rank", array(), "array");
                }
                echo "\">
                            </td>
                            <td class=\"append_module\" >
                                <input name=\"config[menu][";
                // line 271
                echo (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i"));
                echo "][name]\" class=\"input-medium name\" type=\"text\" value=\"";
                if ($this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : null), "name", array(), "array", true, true)) {
                    echo $this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : $this->getContext($context, "_menu")), "name", array(), "array");
                }
                echo "\">
                                <a class=\"btn btn-small btn-addsub\"><i class=\"icon-plus\"></i> 添加子菜单</a>
                            </td>
                            <td>
                                <div>
                                    <div id=\"uploader-img-";
                // line 276
                echo ((isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")) + 1);
                echo "\">
                                        <input type=\"hidden\" name=\"config[menu][";
                // line 277
                echo (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i"));
                echo "][pic]\" value=\"";
                if ($this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : null), "pic", array(), "array", true, true)) {
                    echo $this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : $this->getContext($context, "_menu")), "pic", array(), "array");
                }
                echo "\">
                                        <input type=\"hidden\" name=\"img\" class=\"img_value\" id=\"input-image";
                // line 278
                echo ((isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")) + 1);
                echo "\">

                                        ";
                // line 280
                if (($this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : null), "pic", array(), "array", true, true) && (!twig_test_empty($this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : $this->getContext($context, "_menu")), "pic", array(), "array"))))) {
                    // line 281
                    echo "                                        <img src=\"";
                    echo $this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : $this->getContext($context, "_menu")), "pic", array(), "array");
                    echo "\" class=\"img-polaroid\"  width=\"90px;\" heigth=\"90px;\" style=\"margin:0 0 5px 0;\">
                                        ";
                } else {
                    // line 283
                    echo "                                        <img src=\"/assets/img/no_image.png\" class=\"img-polaroid\" width=\"90px;\" height=\"90px;\"style=\"margin:0 0 5px 0;\">
                                        ";
                }
                // line 285
                echo "
                                        <input type=\"button\" class=\"btn j_img_clear\" value=\"删除\" />
                                        <!-- <input type=\"hidden\" name=\"img\" class=\"img_value\"> -->





                                    </div>
                                </div>
                            </td>
                            <td class=\"td-keyword\">
                                ";
                // line 297
                if ($this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : null), "link", array(), "array", true, true)) {
                    // line 298
                    echo "                                <input name=\"config[menu][";
                    echo (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i"));
                    echo "][keyword]\" class=\"input-medium keyword\" type=\"text\" value=\"";
                    if ($this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : null), "link", array(), "array", true, true)) {
                        echo $this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : $this->getContext($context, "_menu")), "link", array(), "array");
                    }
                    echo "\">
                                ";
                }
                // line 300
                echo "                            </td>
                            <td>
                                ";
                // line 302
                if ($this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : null), "link", array(), "array", true, true)) {
                    // line 303
                    echo "                                <input name=\"config[menu][";
                    echo (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i"));
                    echo "][key]\" class=\"key\" type=\"hidden\" value=\"";
                    if ($this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : null), "link", array(), "array", true, true)) {
                        echo $this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : $this->getContext($context, "_menu")), "link", array(), "array");
                    }
                    echo "\" >
                                ";
                }
                // line 305
                echo "                                <a class=\"btn btn-small btn-main-del\"><i class=\"icon-trash\"></i> 删除</a>
                            </td>
                        </tr>
                    ";
                // line 308
                if (($this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : null), "sub_menu", array(), "array", true, true) && (!twig_test_empty($this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : $this->getContext($context, "_menu")), "sub_menu", array(), "array"))))) {
                    // line 309
                    echo "                    ";
                    $context['_parent'] = (array) $context;
                    $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["_menu"]) ? $context["_menu"] : $this->getContext($context, "_menu")), "sub_menu", array(), "array"));
                    foreach ($context['_seq'] as $context["k"] => $context["_submenu"]) {
                        // line 310
                        echo "                        <tr class=\"sub\" parent-index=\"";
                        echo (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i"));
                        echo "\" data-main=\"";
                        echo ((isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")) + 1);
                        echo "-";
                        echo ((isset($context["k"]) ? $context["k"] : $this->getContext($context, "k")) + 1);
                        echo "\" >
                            <td>
                                <div class=\"sub-node\"><div>

                                </div>
                                    <input name=\"config[menu][";
                        // line 315
                        echo (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i"));
                        echo "][sub_menu][";
                        echo (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k"));
                        echo "][rank]\" class=\"input-mini rank\" type=\"text\" value=\"";
                        if ($this->getAttribute((isset($context["_submenu"]) ? $context["_submenu"] : null), "rank", array(), "array", true, true)) {
                            echo $this->getAttribute((isset($context["_submenu"]) ? $context["_submenu"] : $this->getContext($context, "_submenu")), "rank", array(), "array");
                        }
                        echo "\">
                                </div>
                            </td>
                            <td>
                                <div class=\"sub-node\">

                                    <input name=\"config[menu][";
                        // line 321
                        echo (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i"));
                        echo "][sub_menu][";
                        echo (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k"));
                        echo "][name]\" class=\"input-medium name\" type=\"text\" value=\"";
                        if ($this->getAttribute((isset($context["_submenu"]) ? $context["_submenu"] : null), "name", array(), "array", true, true)) {
                            echo $this->getAttribute((isset($context["_submenu"]) ? $context["_submenu"] : $this->getContext($context, "_submenu")), "name", array(), "array");
                        }
                        echo "\">
                                </div>
                            </td>
                            <td>
                                <div id=\"node-uploader-img-";
                        // line 325
                        echo ((isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")) + 1);
                        echo "-";
                        echo ((isset($context["k"]) ? $context["k"] : $this->getContext($context, "k")) + 1);
                        echo "\">
                                    <input type=\"hidden\" name=\"config[menu][";
                        // line 326
                        echo (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i"));
                        echo "][sub_menu][";
                        echo (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k"));
                        echo "][pic]\" value=\"";
                        if ($this->getAttribute((isset($context["_submenu"]) ? $context["_submenu"] : null), "pic", array(), "array", true, true)) {
                            echo $this->getAttribute((isset($context["_submenu"]) ? $context["_submenu"] : $this->getContext($context, "_submenu")), "pic", array(), "array");
                        }
                        echo "\">
                                    <input type=\"hidden\" name=\"img\" class=\"img_value\" id=\"input-image\">


                                    ";
                        // line 330
                        if (($this->getAttribute((isset($context["_submenu"]) ? $context["_submenu"] : null), "pic", array(), "array", true, true) && (!twig_test_empty($this->getAttribute((isset($context["_submenu"]) ? $context["_submenu"] : $this->getContext($context, "_submenu")), "pic", array(), "array"))))) {
                            // line 331
                            echo "                                    <img src=\"";
                            echo $this->getAttribute((isset($context["_submenu"]) ? $context["_submenu"] : $this->getContext($context, "_submenu")), "pic", array(), "array");
                            echo "\" class=\"img-polaroid\"  width=\"90px;\" heigth=\"90px;\" style=\"margin:0 0 5px 0;\">
                                    ";
                        } else {
                            // line 333
                            echo "                                    <img src=\"/assets/img/no_image.png\" class=\"img-polaroid\" width=\"90px;\" height=\"90px;\"style=\"margin:0 0 5px 0;\">
                                    ";
                        }
                        // line 335
                        echo "

                                    <input type=\"button\" class=\"btn j_img_clear\" value=\"删除\" />
                                    <!-- <input type=\"hidden\" name=\"img\" class=\"img_value\"> -->
                                </div>
                            </td>
                            <td class=\"td-keyword\">
                                ";
                        // line 342
                        if ($this->getAttribute((isset($context["_submenu"]) ? $context["_submenu"] : null), "link", array(), "array", true, true)) {
                            // line 343
                            echo "                                <input name=\"config[menu][";
                            echo (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i"));
                            echo "][sub_menu][";
                            echo (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k"));
                            echo "][keyword]\" class=\"input-medium keyword\" type=\"text\" value=\"";
                            if ($this->getAttribute((isset($context["_submenu"]) ? $context["_submenu"] : null), "link", array(), "array", true, true)) {
                                echo $this->getAttribute((isset($context["_submenu"]) ? $context["_submenu"] : $this->getContext($context, "_submenu")), "link", array(), "array");
                            }
                            echo "\">
                                ";
                        }
                        // line 345
                        echo "                            </td>
                            <td>
                                ";
                        // line 347
                        if ($this->getAttribute((isset($context["_submenu"]) ? $context["_submenu"] : null), "link", array(), "array", true, true)) {
                            // line 348
                            echo "                                <input name=\"config[menu][";
                            echo (isset($context["i"]) ? $context["i"] : $this->getContext($context, "i"));
                            echo "][sub_menu][";
                            echo (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k"));
                            echo "][key]\" class=\"key\" type=\"hidden\" value=\"";
                            if ($this->getAttribute((isset($context["_submenu"]) ? $context["_submenu"] : null), "link", array(), "array", true, true)) {
                                echo $this->getAttribute((isset($context["_submenu"]) ? $context["_submenu"] : $this->getContext($context, "_submenu")), "link", array(), "array");
                            }
                            echo "\" >
                                ";
                        }
                        // line 350
                        echo "                                <a class=\"btn btn-small btn-sub-del\"><i class=\"icon-trash\"></i> 删除</a>
                            </td>
                        </tr>
                    ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['k'], $context['_submenu'], $context['_parent'], $context['loop']);
                    $context = array_merge($_parent, array_intersect_key($context, $_parent));
                    // line 354
                    echo "                    ";
                }
                // line 355
                echo "                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['i'], $context['_menu'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 356
            echo "                    ";
            if ((twig_length_filter($this->env, $this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "menu", array(), "array")) < 4)) {
                // line 357
                echo "                    <tr class=\"add-main\">
                        <td colspan=\"4\"><a class=\"btn btn-small btn-addmain\"><i class=\"icon-plus\"></i> 添加主菜单</a></td>
                    </tr>
                    ";
            } else {
                // line 361
                echo "                    <tr class=\"add-main\" style=\"display:none\">
                        <td colspan=\"4\"><a class=\"btn btn-small btn-addmain\"><i class=\"icon-plus\"></i> 添加主菜单</a></td>
                    </tr>
                    ";
            }
            // line 365
            echo "                    ";
        } else {
            // line 366
            echo "                    <tr class=\"add-main\">
                        <td colspan=\"4\"><a class=\"btn btn-small btn-addmain\"><i class=\"icon-plus\"></i> 添加主菜单</a></td>
                    </tr>
                    ";
        }
        // line 370
        echo "                    </tbody>
                </table>

            </div>
        </div>


\t\t<div class=\"control-group\">
\t\t\t<div class=\"controls\">
\t\t\t\t<button type=\"submit\" class=\"btn btn-primary\" id=\"btn-save\">保存</button>
\t\t\t</div>
\t\t</div>
\t</form>
</div>
<script>
\$(function(){
    \$('input[name=\"config[type]\"]').on('click', function(){
        if (\$(this).val() == 0) {
            \$('#J_position').show();
        } else {
            \$('#J_position').hide();
        }
    });
});
</script>


<script type=\"text/javascript\">
    \$(function() {

        \$('#J_menu_new').hide();
        \$('#J_menu_new').insertAfter(\$('form'));

        var val=\$('input:radio[name=\"config[type]\"]:checked').val();
        if(val == 4){
            \$('#J_menu').hide();
            \$('#J_menu').insertAfter(\$('form'))

            \$('#J_menu_new').insertAfter(\$('#J_position'));
            \$('#J_menu_new').show();
        }else{
            \$('#J_menu_new').hide();
            \$('#J_menu_new').insertAfter(\$('form'))

        }
        //页面显示位置
        \$('input[name=\"config[type]\"]').on('click', function(){
            if (\$(this).val() == 0) {
                \$('#J_position').show();
            } else {
                \$('#J_position').hide();
            }
            if (\$(this).val() == 3) {
                \$('#J_menu').insertAfter(\$('#J_position'));
                \$('#J_menu').show();

                \$('#J_menu_new').hide();
                \$('#J_menu_new').insertAfter(\$('form'));
            }else if(\$(this).val() == 4){
                \$('#J_menu').hide();
                \$('#J_menu').insertAfter(\$('form'));
                \$('#J_menu_new').insertAfter(\$('#J_position'));
                \$('#J_menu_new').show();
            } else {
                \$('#J_menu').insertAfter(\$('#J_position'));
                \$('#J_menu').hide();
                \$('#J_menu_new').hide();
                \$('#J_menu_new').insertAfter(\$('form'));

            }
        });

        //删除图片
        \$(document).on('click','.j_img_clear',function(){
\t\t\t\$(this).parent().find('img').attr('src','/assets/img/no_image.png');
\t\t\t\$(this).parent().find('input[type=\"hidden\"]').val('');
            //\$(this).next('input').val('');
            //\$(this).prevAll('img').attr('src','/assets/img/no_image.png');
        });


        function upload_file(id,text,type)
        {
            \$(id).Huploadify({
                'fileObjName': 'image',
                'fileSizeLimit': 2048,
                'fileTypeExts': '*.gif; *.jpg; *.png',
                'multi': false,
                'auto':true,
                'showUploadedPercent':false,
                'removeTimeout': 0,
                'buttonText': text ? text : '添加图片',
                'formData': {'token': '";
        // line 462
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
                'uploader': '/image/upload_gd',
                'onUploadSuccess': function(file, data) {
                    var ret = \$.parseJSON(data);
                    if (ret) {
                        if (ret.success) {
                            \$(id).parent().find('input[type=\"hidden\"]').val(ret.image);
                            \$(id).parent().find('img').attr('src', ret.image);
                            \$(id).parent().find('.img_value').val(ret.image);
                        } else {
                            alert(ret.message);
                        }
                    }
                }
            });
        }

        //上传初始化
        \$(\"#mycotent tr\").each(function() {
            index = \$(this).attr('data-main');
            upload_file(\"#uploader-img-\" + index, '',index);
            upload_file(\"#sub-uploader-img-\" + index, '',index);
            upload_file(\"#node-uploader-img-\" + index, '',index);
        })



        upload_file('#uploader-img0','');
        \$('.table-menu').on('click', '.btn-addmain', function(){
            var i = \$('.table-menu tr').filter('.main').length;
            var item = '<tr class=\"main\" main-index=\"'+i+'\">';
            item += '<td><input name=\"config[menu]['+i+'][rank]\" class=\"input-mini rank\" type=\"text\"></td>';
            item += '<td><input name=\"config[menu]['+i+'][name]\" class=\"input-medium name\" type=\"text\"><a class=\"btn btn-small btn-addsub\"><i class=\"icon-plus\"></i> 添加子菜单</a></td>';
            item += '<td class=\"td-keyword\"><input name=\"config[menu]['+i+'][keyword]\" class=\"input-medium keyword\" type=\"text\"></td>';
            item += '<td><a class=\"btn btn-small btn-main-del\"><i class=\"icon-trash\"></i> 删除</a></td>';
            item += '</tr>';
            \$('.table-menu .add-main').before(item);
            upload_file('#uploader-img-' + i,'');
            //最多添加4个一级菜单
            if(i >= 3) {
                \$('.table-menu .add-main').hide();
            }else{
                \$('.table-menu .add-main').show();
            }
        });

        \$('.table-menu-home').on('click', '.btn-addmain', function(){
            var i = \$('.table-menu-home tr').filter('.main').length;
            var item = '<tr class=\"main\" main-index=\"'+i+'\">';
            item += '<td><input name=\"config[menu]['+i+'][rank]\" class=\"input-mini rank\" type=\"text\"></td>';
            item += '<td><input name=\"config[menu]['+i+'][name]\" class=\"input-medium name\" type=\"text\"><a class=\"btn btn-small btn-addsub\"><i class=\"icon-plus\"></i> 添加子菜单</a></td>';

            item += '<td>' +
                    '<div>' +
                    '<div id=\"uploader-img-' + i + 1 +'\">' +
                    '<input type=\"hidden\" name=\"config[menu][i][pic]\" value=\"\">' +
                    '<input type=\"hidden\" name=\"img\" class=\"img_value\" id=\"input-image-'+ i + '\">' +
                    '<img src=\"/assets/img/no_image.png\" class=\"img-polaroid\" width=\"90px;\" height=\"90px;\"style=\"margin:0 0 5px 0;\">' +
                    '<input type=\"button\" class=\"btn j_img_clear\" value=\"删除\" />' +
                    '<input type=\"hidden\" name=\"img\" class=\"img_value\">' +
                    '</div>' +
                    '</div>' +
                    '</td>';

            item += '<td class=\"td-keyword\"><input name=\"config[menu]['+i+'][keyword]\" class=\"input-medium keyword\" type=\"text\"></td>';
            item += '<td><a class=\"btn btn-small btn-main-del\"><i class=\"icon-trash\"></i> 删除</a></td>';
            item += '</tr>';
            \$('.table-menu-home .add-main').before(item);
            upload_file('#uploader-img-' + i + 1,'');

            //最多添加4个一级菜单
            if(i >= 3) {
                \$('.table-menu-home .add-main').hide();
            }else{
                \$('.table-menu-home .add-main').show();
            }
        });

        \$('.table-menu').on('click', '.btn-addsub', function(){
            var i = \$(this).parent().parent().attr('main-index');
            var j = \$('tr[parent-index=\"'+i+'\"]').length;
            var item = '<tr class=\"sub\" parent-index=\"'+i+'\">';
            item += '<td><div class=\"sub-node\"><input name=\"config[menu]['+i+'][sub_menu]['+j+'][rank]\" class=\"input-mini rank\" type=\"text\"></div></td>';
            item += '<td><div class=\"sub-node\"><input name=\"config[menu]['+i+'][sub_menu]['+j+'][name]\" class=\"input-medium name\" type=\"text\"></div></td>';
            item += '<td class=\"td-keyword\"><input name=\"config[menu]['+i+'][sub_menu]['+j+'][keyword]\" class=\"input-medium keyword\" type=\"text\"></td>';
            item += '<td><a class=\"btn btn-small btn-sub-del\"><i class=\"icon-trash\"></i> 删除</a></td>';
            item += '</tr>';

            //删除keyword输入框
            \$(this).parent().next().find('.keyword').remove();
            //删除隐藏的key值
            \$('tr[main-index=\"'+i+'\"] .key').remove();

            if(\$(this).parent().parent().nextUntil().filter(\".main\").length == 0){
                \$('.table-menu .add-main').before(item);
            }else{
                \$(this).parent().parent().nextUntil().filter(\".main\").first().before(item);
            }
            //最多添加6个二级菜单
            if(\$('tr[parent-index=\"'+i+'\"]').length >= 6){
                \$(this).hide();
            }else{
                \$(this).show();
            }
        });

        \$('.table-menu-home').on('click', '.btn-addsub', function(){
            var i = \$(this).parent().parent().attr('main-index');
            var j = \$('tr[parent-index=\"'+i+'\"]').length;
            var v = i|0+1;
            var k = j+1;
            var item = '<tr class=\"sub\" parent-index=\"'+i+'\">';
            item += '<td><div class=\"sub-node\"><input name=\"config[menu]['+i+'][sub_menu]['+j+'][rank]\" class=\"input-mini rank\" type=\"text\"></div></td>';
            item += '<td><div class=\"sub-node\"><input name=\"config[menu]['+i+'][sub_menu]['+j+'][name]\" class=\"input-medium name\" type=\"text\"></div></td>';

            item += '<td>' +
                    '<div>' +
                    '<div id=\"node-uploader-img-' + v + '-'+ k +'\">' +
                    '<input type=\"hidden\" name=\"config[menu]['+i+'][sub_menu]['+j+'][pic]\" value=\"\">' +
                    '<input type=\"hidden\" name=\"img\" class=\"img_value\" id=\"input-image\">' +
                    '<img src=\"/assets/img/no_image.png\" class=\"img-polaroid\" width=\"90px;\" height=\"90px;\"style=\"margin:0 0 5px 0;\">' +
                    '<input type=\"button\" class=\"btn j_img_clear\" value=\"删除\" />' +
                    '<input type=\"hidden\" name=\"img\" class=\"img_value\">' +
                    '</div>' +
                    '</div>' +
                    '</td>';

            item += '<td class=\"td-keyword\"><input name=\"config[menu]['+i+'][sub_menu]['+j+'][keyword]\" class=\"input-medium keyword\" type=\"text\"></td>';
            item += '<td><a class=\"btn btn-small btn-sub-del\"><i class=\"icon-trash\"></i> 删除</a></td>';
            item += '</tr>';

            //删除keyword输入框
            \$(this).parent().next().find('.keyword').remove();
            //删除隐藏的key值
            \$('tr[main-index=\"'+i+'\"] .key').remove();

            if(\$(this).parent().parent().nextUntil().filter(\".main\").length == 0){
                \$('.table-menu-home .add-main').before(item);
            }else{
                \$(this).parent().parent().nextUntil().filter(\".main\").first().before(item);
            }

            upload_file('#node-uploader-img-' + v +'-'+ k,'');

            //最多添加6个二级菜单
            if(\$('tr[parent-index=\"'+i+'\"]').length >= 6){
                \$(this).hide();
            }else{
                \$(this).show();
            }
        });


        \$('.table-menu').on('click', '.btn-addsub', function(){
            var i = \$(this).parent().parent().attr('main-index');
            var j = \$('tr[parent-index=\"'+i+'\"]').length;
            var item = '<tr class=\"sub\" parent-index=\"'+i+'\">';
            item += '<td><div class=\"sub-node\"><input name=\"config[menu]['+i+'][sub_menu]['+j+'][rank]\" class=\"input-mini rank\" type=\"text\"></div></td>';
            item += '<td><div class=\"sub-node\"><input name=\"config[menu]['+i+'][sub_menu]['+j+'][name]\" class=\"input-medium name\" type=\"text\"></div></td>';
            item += '<td class=\"td-keyword\"><input name=\"config[menu]['+i+'][sub_menu]['+j+'][keyword]\" class=\"input-medium keyword\" type=\"text\"></td>';
            item += '<td><a class=\"btn btn-small btn-sub-del\"><i class=\"icon-trash\"></i> 删除</a></td>';
            item += '</tr>';

            //删除keyword输入框
            \$(this).parent().next().find('.keyword').remove();
            //删除隐藏的key值
            \$('tr[main-index=\"'+i+'\"] .key').remove();

            if(\$(this).parent().parent().nextUntil().filter(\".main\").length == 0){
                \$('.table-menu .add-main').before(item);
            }else{
                \$(this).parent().parent().nextUntil().filter(\".main\").first().before(item);
            }
            //最多添加6个二级菜单
            if(\$('tr[parent-index=\"'+i+'\"]').length >= 6){
                \$(this).hide();
            }else{
                \$(this).show();
            }
        });

        \$('.table-menu').on('click', '.btn-main-del', function(){
            if(confirm(\"是否确定删除该自定义菜单？\")){
                var parent_index = \$(this).parent().parent().attr('main-index');
                //删除主菜单
                \$(this).parent().parent().remove();
                //删除子菜单
                \$('tr[parent-index=\"'+parent_index+'\"]').remove();
                //显示添加主菜单按钮
                \$('.table-menu .add-main').show();

                \$.each(\$('.table-menu .main'), function(i, ele){
                    \$(ele).attr('main-index', i);
                    \$(ele).find('.rank').attr(name, 'config[menu]['+i+'][rank]');
                    \$(ele).find('.name').attr(name, 'config[menu]['+i+'][name]');
                    \$(ele).find('.keyword').attr(name, 'config[menu]['+i+'][keyword]');
                    \$(ele).find('.key').attr(name, 'config[menu]['+i+'][key]');
                });
            }
        });

        \$('.table-menu').on('click', '.btn-sub-del', function(){
            if(confirm(\"是否确定删除该自定义菜单？\")){
                var parent_index = \$(this).parent().parent().attr('parent-index');
                if(\$('tr[parent-index=\"'+parent_index+'\"]').length == 1){
                    var keyword_input = '<input name=\"config[menu]['+parent_index+'][keyword]\" class=\"input-medium keyword\" type=\"text\">';
                    \$('tr[main-index=\"'+parent_index+'\"] .td-keyword').html(keyword_input);
                }
                \$(this).parent().parent().remove();

                \$.each(\$('tr[parent-index=\"'+parent_index+'\"]'), function(i, ele){
                    \$(ele).attr('parent-index', parent_index);
                    \$(ele).find('.rank').attr(name, 'config[menu]['+parent_index+'][sub_menu]['+i+'][rank]');
                    \$(ele).find('.name').attr(name, 'config[menu]['+parent_index+'][sub_menu]['+i+'][name]');
                    \$(ele).find('.keyword').attr(name, 'config[menu]['+parent_index+'][sub_menu]['+i+'][keyword]');
                    \$(ele).find('.key').attr(name, 'config[menu]['+parent_index+'][sub_menu]['+i+'][key]');
                });
            }
        });


        \$('.table-menu-home').on('click', '.btn-main-del', function(){
            if(confirm(\"是否确定删除该自定义菜单？\")){
                var parent_index = \$(this).parent().parent().attr('main-index');
                //删除主菜单
                \$(this).parent().parent().remove();
                //删除子菜单
                \$('tr[parent-index=\"'+parent_index+'\"]').remove();
                //显示添加主菜单按钮
                \$('.table-menu .add-main').show();

                \$.each(\$('.table-menu .main'), function(i, ele){
                    \$(ele).attr('main-index', i);
                    \$(ele).find('.rank').attr(name, 'config[menu]['+i+'][rank]');
                    \$(ele).find('.name').attr(name, 'config[menu]['+i+'][name]');
                    \$(ele).find('.keyword').attr(name, 'config[menu]['+i+'][keyword]');
                    \$(ele).find('.key').attr(name, 'config[menu]['+i+'][key]');
                });
            }
        });

        \$('.table-menu-home').on('click', '.btn-sub-del', function(){
            if(confirm(\"是否确定删除该自定义菜单？\")){
                var parent_index = \$(this).parent().parent().attr('parent-index');
                if(\$('tr[parent-index=\"'+parent_index+'\"]').length == 1){
                    var keyword_input = '<input name=\"config[menu]['+parent_index+'][keyword]\" class=\"input-medium keyword\" type=\"text\">';
                    \$('tr[main-index=\"'+parent_index+'\"] .td-keyword').html(keyword_input);
                }
                \$(this).parent().parent().remove();

                \$.each(\$('tr[parent-index=\"'+parent_index+'\"]'), function(i, ele){
                    \$(ele).attr('parent-index', parent_index);
                    \$(ele).find('.rank').attr(name, 'config[menu]['+parent_index+'][sub_menu]['+i+'][rank]');
                    \$(ele).find('.name').attr(name, 'config[menu]['+parent_index+'][sub_menu]['+i+'][name]');
                    \$(ele).find('.keyword').attr(name, 'config[menu]['+parent_index+'][sub_menu]['+i+'][keyword]');
                    \$(ele).find('.key').attr(name, 'config[menu]['+parent_index+'][sub_menu]['+i+'][key]');
                });
            }
        });



        /*\t\t\$('#btn-save').click(function(){
         if(\$('.table-menu .main').length <= 1 && confirm(\"是否确定删除该自定义菜单？\")){
         \$(\"form\").submit();
         }
         });*/
    });


    //****************限制输入字符数start
//    function check(event, len) {
//        var e = window.event || event;
//        //限制空格
//        var spaceKeys = [9, 13, 32];
//        for(var i = 0; i < spaceKeys.length; i++) {
//            if(spaceKeys[i] == e.keyCode) {
//                return false;
//            }
//        }
//
//        if(e.ctrlKey || e.altKey || e.shiftKey || isFunKey(e.keyCode)) {
//            return true;
//        }
//        var obj = e.srcElement || e.target;
//        if(getLength(obj.value) >= len) {
//            return false;
//        }
//        return true;
//    }
//
//    function change(obj, len) {
//        var txt = obj.value;
//        if(getLength(txt) <= len) {
//            return;
//        }
//        while(getLength(txt) > len) {
//            txt = txt.substring(0, txt.length - 1);
//        }
//        obj.value = txt;
//    }
//
//    function getLength(str) {
//        var len = 0;
//        for(var i = 0; i < str.length; i++) {
//            //if(str.charCodeAt(i) < 0x80) {
//                len++;
//            //}else{
//                //len += 2;
//            //}
//        }
//        return len;
//    }
//
//    function isFunKey(code) {
//        //  8 --> Backspace
//        // 35 --> End
//        // 36 --> Home
//        // 37 --> Left Arrow
//        // 39 --> Right Arrow
//        // 46 --> Delete
//        // 112~123 --> F1~F12
//        var funKeys = [8, 35, 36, 37, 39, 46];
//        for(var i = 112; i <= 123; i++) {
//            funKeys.push(i);
//        }
//        for(var i = 0; i < funKeys.length; i++) {
//            if(funKeys[i] == code) {
//                return true;
//            }
//        }
//        return false;
//    }
    //****************限制输入字符数end
</script>
";
    }

    public function getTemplateName()
    {
        return "assist/setting.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  900 => 462,  806 => 370,  800 => 366,  797 => 365,  791 => 361,  785 => 357,  782 => 356,  776 => 355,  773 => 354,  764 => 350,  752 => 348,  750 => 347,  746 => 345,  734 => 343,  732 => 342,  723 => 335,  719 => 333,  713 => 331,  711 => 330,  698 => 326,  692 => 325,  679 => 321,  664 => 315,  651 => 310,  646 => 309,  644 => 308,  639 => 305,  629 => 303,  627 => 302,  623 => 300,  613 => 298,  611 => 297,  597 => 285,  593 => 283,  587 => 281,  585 => 280,  580 => 278,  572 => 277,  568 => 276,  556 => 271,  546 => 268,  538 => 266,  533 => 265,  531 => 264,  512 => 247,  508 => 245,  502 => 243,  500 => 242,  492 => 239,  484 => 236,  463 => 220,  453 => 212,  447 => 208,  444 => 207,  438 => 203,  432 => 199,  429 => 198,  423 => 197,  420 => 196,  411 => 192,  399 => 190,  397 => 189,  393 => 187,  381 => 185,  379 => 184,  368 => 182,  358 => 181,  353 => 180,  348 => 179,  346 => 178,  341 => 175,  331 => 173,  329 => 172,  325 => 170,  315 => 168,  313 => 167,  304 => 165,  296 => 164,  291 => 163,  286 => 162,  284 => 161,  257 => 139,  249 => 133,  245 => 131,  241 => 129,  239 => 128,  235 => 126,  231 => 124,  227 => 122,  225 => 121,  221 => 119,  217 => 117,  213 => 115,  211 => 114,  202 => 110,  197 => 107,  193 => 105,  189 => 103,  187 => 102,  183 => 100,  179 => 98,  175 => 96,  173 => 95,  169 => 93,  165 => 91,  161 => 89,  159 => 88,  155 => 86,  151 => 84,  147 => 82,  145 => 81,  136 => 74,  132 => 72,  128 => 70,  126 => 69,  121 => 66,  117 => 64,  113 => 62,  111 => 61,  107 => 59,  103 => 57,  99 => 55,  97 => 54,  93 => 52,  89 => 50,  85 => 48,  83 => 47,  79 => 45,  75 => 43,  71 => 41,  69 => 40,  31 => 4,  28 => 3,);
    }
}
