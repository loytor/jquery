<?php

/* show_message.html */
class __TwigTemplate_f7e0172b89d50d6faaa9453a19978550 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
<meta charset=\"utf-8\">
<title>微信公众平台</title>
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
<meta name=\"description\" content=\"\">
<link href=\"/assets/css/bootstrap.min.css\" rel=\"stylesheet\">
<link href=\"/assets/css/bootstrap-responsive.min.css\" rel=\"stylesheet\">
<link href=\"/assets/css/app.css\" rel=\"stylesheet\">
<style type=\"text/css\">
.center {
\tmax-width: 600px;
\tmargin: 20px auto;
}
</style>
<!--[if lt IE 9]>
<script src=\"/assets/js/html5shiv.js\"></script>
<![endif]-->
</head>
<body>
<div class=\"container\">
\t<div class=\"hero-unit center\">
\t\t<h3>";
        // line 24
        echo (isset($context["message"]) ? $context["message"] : $this->getContext($context, "message"));
        echo "</h3>
\t\t<p><button type=\"button\" class=\"btn btn-primary\" id=\"button-continue\">点击继续</button></p>
\t</div>
</div>
<script src=\"/assets/js/jquery.min.js\"></script>
<script src=\"/assets/js/bootstrap.min.js\"></script>
<script type=\"text/javascript\">

function jump() {
var is_back = 0;
";
        // line 34
        if (array_key_exists("back", $context)) {
            // line 35
            echo "is_back = ";
            echo (isset($context["back"]) ? $context["back"] : $this->getContext($context, "back"));
            echo ";
";
        }
        // line 37
        echo "
if(is_back == 1){
\t\twindow.history.back();
\t}else{
\t\twindow.location.href = '";
        // line 41
        echo (isset($context["redirect"]) ? $context["redirect"] : $this->getContext($context, "redirect"));
        echo "';
\t}
}
\$(function() {
\tsetTimeout('jump()', 3000);
\t\$('#button-continue').click(function() {
\t\tjump();
\t});
});
</script>
</body>
</html>";
    }

    public function getTemplateName()
    {
        return "show_message.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  71 => 41,  65 => 37,  59 => 35,  57 => 34,  44 => 24,  19 => 1,);
    }
}
