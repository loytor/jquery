<?php

/* game/rotate/add.html */
class __TwigTemplate_f7ff3c91601aad9cfe50277c3b973d8f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'style' => array($this, 'block_style'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "
<ul class=\"clearfix activity-instruction\">
    欢乐大转盘是一种系统随机抽奖活动，发起人可以自定义中奖几率（可随时修改），控制每位参与者中奖机会，但发起人不可以自行人工抽奖，发起人可在中途结束活动
</ul>
<div class=\"well\">

<p style=\"text-align:left;\">
    <span style=\"font-family:微软雅黑;font-size:18px;font-weight:bold;font-style:normal;text-decoration:none;color:#333333;\">游戏信息：</span>
</p>
<form class=\"form-horizontal\" action=\"\" method=\"post\">
<div class=\"control-group\">
    <label class=\"control-label\" for=\"select-cate_id\">所属网站栏目</label>
    <div class=\"controls\">
        <select name=\"cate_id\" id=\"select-cate_id\" class=\"span2\">
            <option value=\"\">未归档</option>
            ";
        // line 19
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["cate_arr"]) ? $context["cate_arr"] : $this->getContext($context, "cate_arr")));
        foreach ($context['_seq'] as $context["_cate_id"] => $context["_cate"]) {
            // line 20
            echo "            <option value=\"";
            echo (isset($context["_cate_id"]) ? $context["_cate_id"] : $this->getContext($context, "_cate_id"));
            echo "\">";
            echo $this->getAttribute((isset($context["_cate"]) ? $context["_cate"] : $this->getContext($context, "_cate")), "cate_name", array(), "array");
            echo "</option>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_cate_id'], $context['_cate'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 22
        echo "        </select>
    </div>
</div>
<div class=\"control-group\">
    <label class=\"control-label\" for=\"input-title\">游戏标题</label>
    <div class=\"controls\">
        <input type=\"text\" name=\"title\" id=\"input-title\" class=\"span4\" />
        <span class=\"help-inline\"><span class=\"label\">建议10个汉字以内</span></span>
    </div>
</div>
<div class=\"control-group\">
    <label class=\"control-label\" for=\"input-desc\">游戏描述</label>
    <div class=\"controls\">
        <input type=\"text\" name=\"desc\" id=\"input-desc\" class=\"span4\" />
        <span class=\"help-inline\"><span class=\"label\">建议13个汉字以内</span></span>
    </div>
</div>
<div class=\"control-group\">
    <label class=\"control-label\" for=\"input-content\">游戏说明</label>
    <div class=\"controls\">
        <textarea class=\"span4\" id=\"input-content\" name=\"content\"></textarea>
    </div>
</div>
<div class=\"control-group\">
    <label class=\"control-label\" for=\"statdate\">游戏时间</label>
    <div class=\"controls\">
        <input type=\"text\" name=\"start_time\" placeholder=\"点击选择开始时间\" value=\"\" id=\"statdate\" />
        到
        <input type=\"text\" name=\"end_time\" placeholder=\"点击选择结束时间\" value=\"\" id=\"enddate\" />
    </div>
</div>
<p style=\"text-align:left;\">
    <span style=\"font-family:微软雅黑;font-size:18px;font-weight:bold;font-style:normal;text-decoration:none;color:#333333;\">奖项规则设置：(<span class=\"red\">三个奖项需全部填写完整</span>)</span>
</p>
<div class=\"control-group reward-item\" style=\"margin-bottom: 0\">
    <label class=\"control-label\">
        <span style=\"font-family:微软雅黑;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#333333;\">奖品设置：</span>
    </label>
    奖项一：
    <input type=\"text\" name=\"prize[0][name]\" placeholder=\"如 几等奖：奖品名称\" value=\"\" style=\"width:150px;\" />
    <span style=\"font-family:微软雅黑;font-size:14px;font-weight:bold;font-style:normal;text-decoration:none;color:#333333;\">中奖率：</span>
    <input type=\"text\" name=\"prize[0][rate]\" value=\"0.1\" style=\"width:30px;\" />
    <span style=\"font-family:微软雅黑;font-size:14px;font-weight:bold;font-style:normal;text-decoration:none;color:#333333;\">%</span>
    <span style=\"font-family:微软雅黑;font-size:14px;font-weight:bold;font-style:normal;text-decoration:none;color:#333333;\">奖品数量：</span>
    <input type=\"text\" name=\"prize[0][number]\" value=\"1\" style=\"width:30px;\" />
    <span style=\"font-family:微软雅黑;font-size:14px;font-weight:bold;font-style:normal;text-decoration:none;color:#333333;\">真实奖品数：</span>
    <input type=\"text\" name=\"prize[0][true_number]\" value=\"1\" style=\"width:30px;\" />
    <input type=\"hidden\" name=\"prize[0][pic]\" id=\"image-prize-hidden0\" value=\"\">
    <img src=\"\" class=\"img-polaroid\" id=\"image-preview0\" width=\"32\" style=\"display: none;\" />
    <div class=\"uploadBox\" data-id=\"0\" style=\"margin-left: 220px;\">
        <div id=\"upload-prize-image0\" class=\"upload-prize-image\"></div>
    </div>
</div>
<div class=\"control-group\" style=\"margin-bottom: 0\">
    <label class=\"control-label\">
        <span style=\"font-family:微软雅黑;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#333333;\"></span>
    </label>
    奖项二：
    <input type=\"text\" name=\"prize[1][name]\" placeholder=\"如 几等奖：奖品名称\" value=\"\" style=\"width:150px;\" />
    <span style=\"font-family:微软雅黑;font-size:14px;font-weight:bold;font-style:normal;text-decoration:none;color:#333333;\">中奖率：</span>
    <input type=\"text\" name=\"prize[1][rate]\" value=\"\" style=\"width:30px;\" />
    <span style=\"font-family:微软雅黑;font-size:14px;font-weight:bold;font-style:normal;text-decoration:none;color:#333333;\">%</span>

    <span style=\"font-family:微软雅黑;font-size:14px;font-weight:bold;font-style:normal;text-decoration:none;color:#333333;\">奖品数量：</span>
    <input type=\"text\" name=\"prize[1][number]\" value=\"\" style=\"width:30px;\" />
    <span style=\"font-family:微软雅黑;font-size:14px;font-weight:bold;font-style:normal;text-decoration:none;color:#333333;\">真实奖品数：</span>
    <input type=\"text\" name=\"prize[1][true_number]\" value=\"\" style=\"width:30px;\" />
    <input type=\"hidden\" name=\"prize[1][pic]\" id=\"image-prize-hidden1\" value=\"\">
    <img src=\"\" class=\"img-polaroid\" id=\"image-preview1\" width=\"32\" style=\"display: none;\" />
    <div class=\"uploadBox\" data-id=\"1\" style=\"margin-left: 220px;\">
        <div id=\"upload-prize-image1\" class=\"upload-prize-image\"></div>
    </div>

</div>
<div class=\"control-group\" style=\"margin-bottom: 0\">
    <label class=\"control-label\">
        <span style=\"font-family:微软雅黑;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#333333;\"></span>
    </label>
    奖项三：
    <input type=\"text\" name=\"prize[2][name]\" placeholder=\"如 几等奖：奖品名称\" value=\"\" style=\"width:150px;\" />
    <span style=\"font-family:微软雅黑;font-size:14px;font-weight:bold;font-style:normal;text-decoration:none;color:#333333;\">中奖率：</span>
    <input type=\"text\" name=\"prize[2][rate]\" value=\"\" style=\"width:30px;\" />
    <span style=\"font-family:微软雅黑;font-size:14px;font-weight:bold;font-style:normal;text-decoration:none;color:#333333;\">%</span>

    <span style=\"font-family:微软雅黑;font-size:14px;font-weight:bold;font-style:normal;text-decoration:none;color:#333333;\">奖品数量：</span>
    <input type=\"text\" name=\"prize[2][number]\" value=\"\" style=\"width:30px;\" />
    <span style=\"font-family:微软雅黑;font-size:14px;font-weight:bold;font-style:normal;text-decoration:none;color:#333333;\">真实奖品数：</span>
    <input type=\"text\" name=\"prize[2][true_number]\" value=\"\" style=\"width:30px;\" />
    <input type=\"hidden\" name=\"prize[2][pic]\" id=\"image-prize-hidden2\" value=\"\">
    <img src=\"\" class=\"img-polaroid\" id=\"image-preview2\" width=\"32\" style=\"display: none;\" />
    <div class=\"uploadBox\" data-id=\"2\" style=\"margin-left: 220px;\">
        <div id=\"upload-prize-image2\" class=\"upload-prize-image\"></div>
    </div>
</div>
<div class=\"control-group\">
    <label class=\"control-label\">
        <span style=\"font-family:微软雅黑;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#333333;\">规则设置：</span>
    </label>
    1.
    <input type=\"radio\" id=\"radio1\" checked=\"true\" name=\"rule\" value=\"1\" />
    活动期间每个用户ID限参与
    <input type=\"text\" name=\"rules[1][number]\" value=\"1\" style=\"width:30px;\" />
    次
    &nbsp;&nbsp;
    <input type=\"radio\" id=\"radio2\" name=\"rule\" value=\"2\" />
    活动期间每个用户ID，每
    <input type=\"text\" name=\"rules[2][day]\" value=\"\" style=\"width:30px;\" />
    天限参与
    <input type=\"text\" name=\"rules[2][number]\" value=\"\" style=\"width:30px;\" />次
    <br/><br/>
    <label class=\"control-label\">
        <span class=\"reward-font\"></span>
    </label>
    2.活动期间每个用户最多可中奖
    <input type=\"text\" name=\"lotterynum\" value=\"0\" style=\"width:30px;\" />
    次<span class=\"red\"> （0表示无限制）</span>
    <br/><br/>
    <label class=\"control-label\">
        <span class=\"reward-font\"></span>
    </label>
    3.同一奖品在
    <input type=\"text\" name=\"frozentime\" value=\"1\" style=\"width:30px;\" />
    分钟内禁止抽出<span class=\"red\"> （0表示无限制。例如设置成1分钟，则表示同一个奖品在1分钟内最多被抽中一次）</span>
</div>
<!--<div class=\"control-group\">
    <label class=\"control-label\">
        <span>奖励抽奖机会：</span>
    </label>
    <div class=\"controls\">
        <input type=\"text\" name=\"chance\" class=\"span4\" />
    </div>
</div>-->

<p style=\"text-align:left;\">
    <span style=\"font-family:微软雅黑;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000FF;\"><a id=\"toggle-settings\" style=\"cursor:pointer;text-decoration: none;\">展开高级设置 ↓</a></span>
</p>
<div id=\"advanced-settings\">
    <div class=\"control-group\">
        <label class=\"control-label\" style=\"width: 95px;\">
            <span style=\"font-family:微软雅黑;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#333333;\"></span>
        </label>
        <input type=\"checkbox\" checked value=\"1\" name=\"displaywinner\" />
        <span>在活动页面显示中奖名单&nbsp;</span>
        <input type=\"checkbox\" checked value=\"1\" name=\"showprizenum\" />
        <span>在活动页面显示奖品数量&nbsp;</span>
        <input type=\"checkbox\" checked value=\"1\" name=\"address_must\" />
        <span>中奖后联系地址必填&nbsp;</span>
    </div>
    <div class=\"control-group\">
        <label class=\"control-label\" for=\"input-start-image\">活动开始封面图片</label>
        <div class=\"controls\">
            <span class=\"help-block\"><span class=\"label\">建议图片尺寸320 : 160</span></span>
            <img src=\"";
        // line 174
        echo $this->getAttribute((isset($context["cover_img"]) ? $context["cover_img"] : $this->getContext($context, "cover_img")), "image_start", array(), "array");
        echo "\" class=\"img-polaroid\" id=\"image-start-preview\" />
            <span class=\"help-inline\"><a href=\"#guide_1\" data-toggle=\"modal\"><span class=\"badge badge-success\"><i class=\"icon-question-sign icon-white\"></i></span></a></span>
            <input type=\"hidden\" name=\"image_start\" id=\"input-start-image\" value=\"";
        // line 176
        echo $this->getAttribute((isset($context["cover_img"]) ? $context["cover_img"] : $this->getContext($context, "cover_img")), "image_start", array(), "array");
        echo "\" />
            <div id=\"uploader-start-image\"></div>
        </div>
    </div>
    <div class=\"control-group\">
        <label class=\"control-label\" for=\"input-end-image\">活动结束封面图片</label>
        <div class=\"controls\">
            <span class=\"help-block\"><span class=\"label\">建议图片尺寸320 : 160</span></span>
            <img src=\"";
        // line 184
        echo $this->getAttribute((isset($context["cover_img"]) ? $context["cover_img"] : $this->getContext($context, "cover_img")), "image_end", array(), "array");
        echo "\" class=\"img-polaroid\" id=\"image-end-preview\" />
            <span class=\"help-inline\"><a href=\"#guide_1\" data-toggle=\"modal\"><span class=\"badge badge-success\"><i class=\"icon-question-sign icon-white\"></i></span></a></span>
            <input type=\"hidden\" name=\"image_end\" id=\"input-end-image\" value=\"";
        // line 186
        echo $this->getAttribute((isset($context["cover_img"]) ? $context["cover_img"] : $this->getContext($context, "cover_img")), "image_end", array(), "array");
        echo "\" />
            <div id=\"uploader-end-image\"></div>
        </div>
    </div>
    <div class=\"control-group\">
        <label class=\"control-label\">
            <span style=\"font-family:微软雅黑;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#333333;\">中奖提示：</span>
        </label>
        <input type=\"text\" name=\"wintips\" class=\"span4\"  value=\"";
        // line 194
        echo $this->getAttribute((isset($context["tips"]) ? $context["tips"] : $this->getContext($context, "tips")), "wintips", array(), "array");
        echo "\" />
    </div>
    <div class=\"control-group\">
        <label class=\"control-label\">
            <span style=\"font-family:微软雅黑;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#333333;\">未中奖提示：</span>
        </label>
        <input type=\"text\" name=\"failtips\" class=\"span4\"  value=\"";
        // line 200
        echo $this->getAttribute((isset($context["tips"]) ? $context["tips"] : $this->getContext($context, "tips")), "failtips", array(), "array");
        echo "\" />
    </div>
    <div class=\"control-group\">
        <label class=\"control-label\">
            <span style=\"font-family:微软雅黑;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#333333;\">活动结束公告：</span>
        </label>
        <input type=\"text\" class=\"span4\" name=\"endtitle\" value=\"";
        // line 206
        echo $this->getAttribute((isset($context["tips"]) ? $context["tips"] : $this->getContext($context, "tips")), "endtitle", array(), "array");
        echo "\"  style=\"height: 65px;\" />
    </div>
    <div class=\"control-group\">
        <label class=\"control-label\">
            <span style=\"font-family:微软雅黑;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#333333;\">现场验证：</span>
        </label>
        <div style=\"float:left;\">
            <span> 开启现场验证功能</span> <span class=\"red\">（不填表示不开启! 本功能适合现场活动，可以让工作人员在现场给用户验证中奖结果，并现场发奖.）</span>
            <br><br>
            <span>现场验证密码：</span><input type=\"text\" value=\"\" name=\"validatecode\">
            <span class=\"label\">请输入英文或者数字，最多10个字</span>
        </div>
    </div>
</div>
<div class=\"control-group\">
    <div class=\"controls\">
        <button type=\"submit\" class=\"btn btn-primary\">确认保存</button>
    </div>
</div>
<input type=\"hidden\" name=\"type\" value=\"";
        // line 225
        echo $this->getAttribute((isset($context["game_type"]) ? $context["game_type"] : $this->getContext($context, "game_type")), "type", array(), "array");
        echo "\" />
</form>
</div>
<div id=\"guide_1\" class=\"modal hide fade\" tabindex=\"-1\">
    <div class=\"modal-body\">
        <img src=\"/assets/img/guide_1.jpg\" />
    </div>
    <div class=\"modal-footer\">
        <button class=\"btn\" data-dismiss=\"modal\" aria-hidden=\"true\">关闭</button>
    </div>
</div>

";
    }

    // line 239
    public function block_style($context, array $blocks = array())
    {
        // line 240
        echo "<link href=\"/assets/huploadify/Huploadify.css\" rel=\"stylesheet\">
<style type=\"text/css\" >
    .tips{color:#999; margin-left:20px;}
    .uploadify-button{
        color: #333;
        background-color: #fff;
        border-color: #ccc;
        cursor:pointer;
        text-decoration:none;
        border-radius: 2px;
        margin-left: 0;
    }
    .uploadify-button:hover {
        background-color: #ccc;
        background-image: none;
        background-position: center bottom;
        cursor:pointer;
        text-decoration:none;
    }
</style>
";
    }

    // line 262
    public function block_script($context, array $blocks = array())
    {
        // line 263
        echo "<script src=\"/assets/js/kindeditor/kindeditor-all-min.js\"></script>
<script src=\"/assets/js/kindeditor/lang/zh_CN.js\"></script>
<script type=\"text/javascript\">
    var editor;
    KindEditor.ready(function(K) {
        editor = K.create('textarea', {
            resizeType: 1,
            pasteType: 1,
            minWidth:490,
            cssPath: '/assets/css/bootstrap.min.css',
            items: ['undo', 'redo', '|', 'forecolor', 'hilitecolor', 'bold', 'italic', 'underline','strikethrough', 'removeformat', '|', 'justifyleft', 'justifycenter', 'justifyright', 'hr', '|', 'emoticons'],
            uploadJson: '/image/upload_for_editor',
            extraFileUploadParams: {'token': '";
        // line 275
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
            filePostName: 'image',
            formatUploadUrl: false
        });
    });
</script>
<script src=\"/assets/js/lhgcalendar.min.js\"></script>
<script src=\"/assets/huploadify/jquery.Huploadify.js\"></script>

<script type=\"text/javascript\">
    function hupload(obj)
    {
        \$(obj).Huploadify({
            'fileObjName': 'image',
            'fileSizeLimit': 2048,
            'fileTypeExts': '*.gif; *.jpg; *.png',
            'multi': false,
            'auto':true,
            'showUploadedPercent':false,
            'removeTimeout': 0,
            'buttonText': '选择图片',
            'formData': {'token': '";
        // line 296
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
            'uploader': '/image/upload_gd_prize',

            'onUploadSuccess': function(file, data) {
                var id = \$(obj).parents('.uploadBox').attr('data-id');
                var ret = \$.parseJSON(data);
                if (ret) {
                    if (ret.success) {
                        \$('#image-preview'+id).attr('src',ret.imagePreview).show();
                        \$('#image-prize-hidden'+id).val(ret.image);
                    } else {
                        alert(ret.message);
                    }
                }
            }
        });
    }
    \$(function() {
        \$('#statdate').calendar({format:'yyyy-MM-dd HH:mm:ss' });
        \$('#enddate').calendar({ format:'yyyy-MM-dd HH:mm:ss',minDate:'#statdate' });

        \$('#uploader-start-image').Huploadify({
            'fileObjName': 'image',
            'fileSizeLimit': 2048,
            'fileTypeExts': '*.gif; *.jpg; *.png',
            'multi': false,
            'auto':true,
            'showUploadedPercent':false,
            'removeTimeout': 0,
            'buttonText': '选择图片',
            'formData': {'token': '";
        // line 326
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
            'uploader': '/image/upload',
            'onUploadSuccess': function(file, data) {
                var ret = \$.parseJSON(data);
                if (ret) {
                    if (ret.success) {
                        \$('#input-start-image').val(ret.image);
                        \$('#image-start-preview').attr('src', ret.image_middle);
                    } else {
                        alert(ret.message);
                    }
                }
            }
        });

        \$('#uploader-end-image').Huploadify({
            'fileObjName': 'image',
            'fileSizeLimit': 2048,
            'fileTypeExts': '*.gif; *.jpg; *.png',
            'multi': false,
            'auto':true,
            'showUploadedPercent':false,
            'removeTimeout': 0,
            'buttonText': '选择图片',
            'formData': {'token': '";
        // line 350
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
            'uploader': '/image/upload',
            'onUploadSuccess': function(file, data) {
                var ret = \$.parseJSON(data);
                if (ret) {
                    if (ret.success) {
                        \$('#input-end-image').val(ret.image);
                        \$('#image-end-preview').attr('src', ret.image_middle);
                    } else {
                        alert(ret.message);
                    }
                }
            }
        });

        hupload('#upload-prize-image0');
        hupload('#upload-prize-image1');
        hupload('#upload-prize-image2');

        \$('#toggle-settings').click(function(){
            \$('#advanced-settings').slideToggle('fast', function(){
                if(\$(this).css('display') == 'none') {
                    \$('#toggle-settings').text('展开高级设置  ↓');
                }else{
                    \$('#toggle-settings').text('收起高级设置 ↑');
                }
            });
        });
    });
</script>
";
    }

    public function getTemplateName()
    {
        return "game/rotate/add.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  436 => 350,  409 => 326,  376 => 296,  352 => 275,  338 => 263,  335 => 262,  311 => 240,  308 => 239,  291 => 225,  269 => 206,  260 => 200,  251 => 194,  240 => 186,  235 => 184,  224 => 176,  219 => 174,  65 => 22,  54 => 20,  50 => 19,  33 => 4,  30 => 3,);
    }
}
