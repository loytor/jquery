<?php

/* reserve/setting.html */
class __TwigTemplate_d708833b6a1400a5f0005bd08c62b16d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'style' => array($this, 'block_style'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "
";
        // line 5
        $this->env->loadTemplate("/reserve/breadcrumb.html")->display($context);
        // line 6
        echo "
<div class=\"well\">
\t<form class=\"form-horizontal\" action=\"\" method=\"post\">
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">外链地址</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<span style=\"line-height:30px;\">";
        // line 12
        echo (isset($context["url"]) ? $context["url"] : $this->getContext($context, "url"));
        echo "</span>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\" >是否开启</label>
\t\t\t<div class=\"controls\">
\t\t\t\t";
        // line 18
        if (($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "is_open", array(), "array", true, true) && ($this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "is_open", array(), "array") == 0))) {
            // line 19
            echo "\t\t\t\t<label class=\"radio inline\">
\t\t\t\t\t<input type=\"radio\" name=\"is_open\" value=\"1\"> 开启
\t\t\t\t</label>
\t\t\t\t<label class=\"radio inline\">
\t\t\t\t\t<input type=\"radio\" name=\"is_open\" checked=\"checked\" value=\"0\"> 关闭
\t\t\t\t</label>
\t\t\t\t";
        } else {
            // line 26
            echo "\t\t\t\t<label class=\"radio inline\">
\t\t\t\t\t<input type=\"radio\" name=\"is_open\" checked=\"checked\" value=\"1\"> 开启
\t\t\t\t</label>
\t\t\t\t<label class=\"radio inline\">
\t\t\t\t\t<input type=\"radio\" name=\"is_open\" value=\"0\"> 关闭
\t\t\t\t</label>
\t\t\t\t";
        }
        // line 33
        echo "\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">所属网站栏目</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<select name=\"cate_id\" class=\"span2\">
\t\t\t\t\t<option value=\"\">未归档</option>
\t\t\t\t\t";
        // line 40
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["cate_arr"]) ? $context["cate_arr"] : $this->getContext($context, "cate_arr")));
        foreach ($context['_seq'] as $context["_cate_id"] => $context["_cate"]) {
            // line 41
            echo "\t\t\t\t\t";
            if (($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "cate_id", array(), "array", true, true) && ((isset($context["_cate_id"]) ? $context["_cate_id"] : $this->getContext($context, "_cate_id")) == $this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "cate_id", array(), "array")))) {
                // line 42
                echo "\t\t\t\t\t<option value=\"";
                echo (isset($context["_cate_id"]) ? $context["_cate_id"] : $this->getContext($context, "_cate_id"));
                echo "\" selected=\"selected\">";
                echo $this->getAttribute((isset($context["_cate"]) ? $context["_cate"] : $this->getContext($context, "_cate")), "cate_name", array(), "array");
                echo "</option>
\t\t\t\t\t";
            } else {
                // line 44
                echo "\t\t\t\t\t<option value=\"";
                echo (isset($context["_cate_id"]) ? $context["_cate_id"] : $this->getContext($context, "_cate_id"));
                echo "\">";
                echo $this->getAttribute((isset($context["_cate"]) ? $context["_cate"] : $this->getContext($context, "_cate")), "cate_name", array(), "array");
                echo "</option>
\t\t\t\t\t";
            }
            // line 46
            echo "\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_cate_id'], $context['_cate'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 47
        echo "\t\t\t\t</select>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">标题</label>
\t\t\t<div class=\"controls\">
\t\t\t\t";
        // line 53
        if ($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "name", array(), "array", true, true)) {
            // line 54
            echo "\t\t\t\t<input type=\"text\" name=\"name\" value=\"";
            echo $this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "name", array(), "array");
            echo "\">
\t\t\t\t";
        } else {
            // line 56
            echo "\t\t\t\t<input type=\"text\" name=\"name\">
\t\t\t\t";
        }
        // line 58
        echo "\t\t\t</div>
\t\t</div>

\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">标题图</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<span class=\"help-block\"><span class=\"label\">建议图片尺寸1:1</span></span>
\t\t\t\t";
        // line 65
        if ((!twig_test_empty($this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "icon", array(), "array")))) {
            // line 66
            echo "\t\t\t\t<img src=\"";
            echo $this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "icon", array(), "array");
            echo "\" style=\"width:64px;height:64px;margin:8px;background: none;\" class=\"img-polaroid icon-preview\">
\t\t\t\t";
        } else {
            // line 68
            echo "\t\t\t\t<img src=\"/assets/img/no_image.png\" style=\"width:64px;height:64px;margin:8px;background: none;\" class=\"img-polaroid icon-preview\">
\t\t\t\t";
        }
        // line 70
        echo "\t\t\t\t<input type=\"button\" class=\"btn j_img_clear\" value=\"清空\" style=\"margin:50px 0 5px 10px;position:absolute;\" />
\t\t\t\t<input type=\"hidden\" name=\"icon\" id=\"input-icon\" value=\"";
        // line 71
        echo $this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "icon", array(), "array");
        echo "\">
\t\t\t\t<div id=\"uploader-icon\"></div>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">提供预约预定服务的门店</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<table class=\"table\">
\t\t\t\t\t<tbody>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t<div id=\"store-box\" class=\"address-list\">
\t\t\t\t\t\t\t\t\t";
        // line 83
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["selected_address"]) ? $context["selected_address"] : $this->getContext($context, "selected_address")));
        foreach ($context['_seq'] as $context["key"] => $context["ad"]) {
            // line 84
            echo "\t\t\t\t\t\t\t\t\t\t<label index=\"";
            echo (isset($context["key"]) ? $context["key"] : $this->getContext($context, "key"));
            echo "\" class=\"checkbox\">
\t\t\t\t\t\t\t\t\t\t\t<input name=\"address[]\" type=\"checkbox\" value=\"";
            // line 85
            echo $this->getAttribute((isset($context["ad"]) ? $context["ad"] : $this->getContext($context, "ad")), "id", array(), "array");
            echo "\" checked=\"checked\">
\t\t\t\t\t\t\t\t\t\t\t";
            // line 86
            echo $this->getAttribute((isset($context["ad"]) ? $context["ad"] : $this->getContext($context, "ad")), "name", array(), "array");
            echo "
\t\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['ad'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 89
        echo "\t\t\t\t\t\t\t\t\t";
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["unselect_address"]) ? $context["unselect_address"] : $this->getContext($context, "unselect_address")));
        foreach ($context['_seq'] as $context["k"] => $context["un_ad"]) {
            // line 90
            echo "\t\t\t\t\t\t\t\t\t<label index=\"";
            echo (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k"));
            echo "\" class=\"checkbox\">
\t\t\t\t\t\t\t\t\t\t<input name=\"address[]\" type=\"checkbox\" value=\"";
            // line 91
            echo $this->getAttribute((isset($context["un_ad"]) ? $context["un_ad"] : $this->getContext($context, "un_ad")), "id", array(), "array");
            echo "\">
\t\t\t\t\t\t\t\t\t\t";
            // line 92
            echo $this->getAttribute((isset($context["un_ad"]) ? $context["un_ad"] : $this->getContext($context, "un_ad")), "name", array(), "array");
            echo "
\t\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['k'], $context['un_ad'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 95
        echo "\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t<label class=\"checkbox\">
\t\t\t\t\t\t\t\t\t<input id=\"cb-all\" type=\"checkbox\" value=\"\">
\t\t\t\t\t\t\t\t\t全选
\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t</tbody>
\t\t\t\t</table>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">预约预订对象类型名</label>
\t\t\t<div class=\"controls\">
\t\t\t\t";
        // line 113
        if (($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "stuff_name", array(), "array", true, true) && (!twig_test_empty($this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "stuff_name", array(), "array"))))) {
            // line 114
            echo "\t\t\t\t<input type=\"text\" name=\"stuff_name\" value=\"";
            echo $this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "stuff_name", array(), "array");
            echo "\">
\t\t\t\t";
        } else {
            // line 116
            echo "\t\t\t\t<input type=\"text\" name=\"stuff_name\" value=\"";
            echo $this->getAttribute((isset($context["type_info"]) ? $context["type_info"] : $this->getContext($context, "type_info")), "stuff", array(), "array");
            echo "\">
\t\t\t\t";
        }
        // line 118
        echo "                <span class=\"red\">根据需要修改，用来设置用户看到的预定预约项目的友好名称。如果为空，则使用系统默认的名称。</span>

            </div>
\t\t</div>
\t\t<div class=\"control-group\" id=\"control_tpl\">
\t\t\t<label class=\"control-label\" for=\"tpllist\">选择模版</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<select id=\"tpllist\" name=\"tpl\">
\t\t\t\t\t";
        // line 126
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["tpl_lists"]) ? $context["tpl_lists"] : $this->getContext($context, "tpl_lists")));
        foreach ($context['_seq'] as $context["_key"] => $context["tpl"]) {
            // line 127
            echo "\t\t\t\t\t";
            if ($this->getAttribute((isset($context["config"]) ? $context["config"] : null), "tpl", array(), "array", true, true)) {
                // line 128
                echo "\t\t\t\t\t<option value=\"";
                echo $this->getAttribute((isset($context["tpl"]) ? $context["tpl"] : $this->getContext($context, "tpl")), "template_id", array(), "array");
                echo "\" ";
                if (($this->getAttribute((isset($context["config"]) ? $context["config"] : $this->getContext($context, "config")), "tpl", array(), "array") == $this->getAttribute((isset($context["tpl"]) ? $context["tpl"] : $this->getContext($context, "tpl")), "template_id", array(), "array"))) {
                    echo "selected=\"selected\"";
                }
                echo " preview=\"";
                echo (isset($context["preview_path"]) ? $context["preview_path"] : $this->getContext($context, "preview_path"));
                echo "assets/types_pub/";
                echo (isset($context["type"]) ? $context["type"] : $this->getContext($context, "type"));
                echo "/";
                echo $this->getAttribute((isset($context["tpl"]) ? $context["tpl"] : $this->getContext($context, "tpl")), "template_id", array(), "array");
                echo "/preview.jpg\">";
                echo $this->getAttribute((isset($context["tpl"]) ? $context["tpl"] : $this->getContext($context, "tpl")), "title", array(), "array");
                echo "</option>
\t\t\t\t\t";
            } else {
                // line 130
                echo "\t\t\t\t\t<option value=\"";
                echo $this->getAttribute((isset($context["tpl"]) ? $context["tpl"] : $this->getContext($context, "tpl")), "template_id", array(), "array");
                echo "\" preview=\"";
                echo (isset($context["preview_path"]) ? $context["preview_path"] : $this->getContext($context, "preview_path"));
                echo "assets/types_pub/";
                echo (isset($context["type"]) ? $context["type"] : $this->getContext($context, "type"));
                echo "/";
                echo $this->getAttribute((isset($context["tpl"]) ? $context["tpl"] : $this->getContext($context, "tpl")), "template_id", array(), "array");
                echo "/preview.jpg\">";
                echo $this->getAttribute((isset($context["tpl"]) ? $context["tpl"] : $this->getContext($context, "tpl")), "title", array(), "array");
                echo "</option>
\t\t\t\t\t";
            }
            // line 132
            echo "\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tpl'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 133
        echo "\t\t\t\t</select>
\t\t\t</div>
\t\t\t<div class=\"controls\">
\t\t\t\t<img id=\"tpl_preview\" style=\"display: none;margin-top: 12px;\" width=\"220\">
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<div class=\"controls\">
\t\t\t\t<button type=\"submit\" class=\"btn btn-primary\">确认保存</button>
\t\t\t</div>
\t\t</div>
\t</form>
</div>
";
    }

    // line 148
    public function block_style($context, array $blocks = array())
    {
        // line 149
        echo "<link href=\"/assets/huploadify/Huploadify.css\" rel=\"stylesheet\">
<style type=\"text/css\" >
    .uploadify-button{
        color: #333;
        background-color: #fff;
        border-color: #ccc;
        cursor:pointer;
        text-decoration:none;
        border-radius: 2px;
        margin-left: 0;
    }
    .uploadify-button:hover {
        background-color: #ccc;
        background-image: none;
        background-position: center bottom;
        cursor:pointer;
        text-decoration:none;
    }
</style>
";
    }

    // line 170
    public function block_script($context, array $blocks = array())
    {
        // line 171
        echo "<script src=\"/assets/huploadify/jquery.Huploadify.js\"></script>
<script type=\"text/javascript\">
\t\$(function() {
        function upload_file(id,text,type){
            \$(id).Huploadify({
                'fileObjName': 'image',
                'fileSizeLimit': '2MB',
                'fileTypeExts': '*.gif; *.jpg; *.png',
                'multi': false,
                'auto':true,
                'showUploadedPercent':false,
                'removeTimeout': 0,
                'buttonText':'选择标题图',
                'formData': {'token': '";
        // line 184
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
                'swf': '/assets/js/uploadify.swf',
                'uploader': '/image/upload_gd',
                'onFallback': function() {
                    alert('您的浏览器没有安装Flash插件');
                },
                'onUploadSuccess': function(file, data) {
                    var ret = \$.parseJSON(data);
                    if (ret) {
                        if (ret.success) {
                            \$('#input-icon').val(ret.image);
                            \$('.icon-preview').attr('src', ret.image);
                        } else {
                            alert(ret.message);
                        }
                    }
                }
            });
        }
        upload_file('#uploader-icon','');

\t\t//全选
\t\t\$('#cb-all').click(function(){
\t\t\t\$('#store-box input[type=\"checkbox\"]').prop('checked', \$(this).prop('checked'))
\t\t});
\t});
</script>
";
    }

    public function getTemplateName()
    {
        return "reserve/setting.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  367 => 184,  352 => 171,  349 => 170,  326 => 149,  323 => 148,  306 => 133,  300 => 132,  286 => 130,  268 => 128,  265 => 127,  261 => 126,  251 => 118,  245 => 116,  239 => 114,  237 => 113,  217 => 95,  208 => 92,  204 => 91,  199 => 90,  194 => 89,  185 => 86,  181 => 85,  176 => 84,  172 => 83,  157 => 71,  154 => 70,  150 => 68,  144 => 66,  142 => 65,  133 => 58,  129 => 56,  123 => 54,  121 => 53,  113 => 47,  107 => 46,  99 => 44,  91 => 42,  88 => 41,  84 => 40,  75 => 33,  66 => 26,  57 => 19,  55 => 18,  46 => 12,  38 => 6,  36 => 5,  33 => 4,  30 => 3,);
    }
}
