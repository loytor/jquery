<?php

/* reserve/form.html */
class __TwigTemplate_c061a1e0b27b1a7fb79f30ca9bf3754f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'style' => array($this, 'block_style'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "
";
        // line 5
        $this->env->loadTemplate("/reserve/breadcrumb.html")->display($context);
        // line 6
        echo "<ul class=\"breadcrumb clearfix\">
<span class=\"red\">这里设置除系统默外的，需要用户填写的表单项目，用以收集用户更多信息。</span>
<a style=\"float: right;margin-bottom: 5px;\" id=\"btn-add\" class=\"btn btn-primary\" href=\"#field-modal\" data-toggle=\"modal\" ><i class=\"icon-plus icon-white\"></i>添加表单项</a>
</ul>
<form class=\"form-horizontal\" action=\"\" method=\"post\">
\t<table id=\"forms\" class=\"table table-hover table-bordered\">
\t\t<thead>
\t\t\t<tr>
\t\t\t\t<th style=\"vertical-align: middle;text-align: center;\">排序</th>
\t\t\t\t<th style=\"vertical-align: middle;text-align: center;\">名称</th>
\t\t\t\t<th style=\"vertical-align: middle;text-align: center;\">类型</th>
\t\t\t\t<th style=\"vertical-align: middle;text-align: center;\">是否必填</th>
\t\t\t\t<th style=\"vertical-align: middle;text-align: center;\">选项（以\",\"分隔）</th>
\t\t\t\t<th style=\"vertical-align: middle;text-align: center;\">是否需要门店<br>设置列表选项</th>
\t\t\t\t<th style=\"vertical-align: middle;text-align: center;\">
                    操作
\t\t\t\t</th>
\t\t\t</tr>
\t\t</thead>
\t\t<tbody>
\t\t\t";
        // line 26
        if ((!twig_test_empty((isset($context["collection"]) ? $context["collection"] : $this->getContext($context, "collection"))))) {
            // line 27
            echo "\t\t\t";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["collection"]) ? $context["collection"] : $this->getContext($context, "collection")));
            foreach ($context['_seq'] as $context["k"] => $context["item"]) {
                // line 28
                echo "\t\t\t<tr class=\"item-field latest-field\" index=\"";
                echo (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k"));
                echo "\">
\t\t\t\t<td><input name=\"collection[";
                // line 29
                echo (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k"));
                echo "][rank]\" class=\"input-small\" type=\"text\" value=\"";
                echo $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "rank", array(), "array");
                echo "\"></td>
\t\t\t\t<td><input name=\"collection[";
                // line 30
                echo (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k"));
                echo "][name]\" class=\"input-medium\" type=\"text\" value=\"";
                echo $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "name", array(), "array");
                echo "\"></td>
\t\t\t\t<td>
\t\t\t\t\t";
                // line 32
                echo $this->getAttribute($this->getAttribute((isset($context["reserve_form_config"]) ? $context["reserve_form_config"] : $this->getContext($context, "reserve_form_config")), $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "type", array(), "array"), array(), "array"), "type", array(), "array");
                echo "
\t\t\t\t\t<input name=\"collection[";
                // line 33
                echo (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k"));
                echo "][id]\" type=\"hidden\" value=\"";
                echo $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "id", array(), "array");
                echo "\">
\t\t\t\t\t<input name=\"collection[";
                // line 34
                echo (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k"));
                echo "][type]\" type=\"hidden\" value=\"";
                echo $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "type", array(), "array");
                echo "\">
\t\t\t\t</td>
\t\t\t\t<td>
\t\t\t\t\t";
                // line 37
                if (($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "required", array(), "array") == 1)) {
                    // line 38
                    echo "\t\t\t\t\t<input name=\"collection[";
                    echo (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k"));
                    echo "][required]\" type=\"checkbox\" value=\"1\" checked=\"checked\">
\t\t\t\t\t";
                } else {
                    // line 40
                    echo "\t\t\t\t\t<input name=\"collection[";
                    echo (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k"));
                    echo "][required]\" type=\"checkbox\" value=\"1\">
\t\t\t\t\t";
                }
                // line 42
                echo "\t\t\t\t</td>
\t\t\t\t<td class=\"td-items\">
\t\t\t\t\t";
                // line 44
                if (($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "type", array(), "array") == 1)) {
                    // line 45
                    echo "\t\t\t\t\t<input name=\"collection[";
                    echo (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k"));
                    echo "][items]\" class=\"input-xlarge\" type=\"text\" value=\"";
                    echo $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "items", array(), "array");
                    echo "\">
\t\t\t\t\t";
                }
                // line 47
                echo "\t\t\t\t</td>
\t\t\t\t<td class=\"td-store\">
\t\t\t\t\t";
                // line 49
                if (($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "type", array(), "array") == 1)) {
                    // line 50
                    echo "\t\t\t\t\t";
                    if (($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "required", array(), "array") == 1)) {
                        // line 51
                        echo "\t\t\t\t\t<input name=\"collection[";
                        echo (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k"));
                        echo "][store]\" type=\"checkbox\" value=\"1\" checked=\"checked\">
\t\t\t\t\t";
                    } else {
                        // line 53
                        echo "\t\t\t\t\t<input name=\"collection[";
                        echo (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k"));
                        echo "][store]\" type=\"checkbox\" value=\"1\">
\t\t\t\t\t";
                    }
                    // line 55
                    echo "\t\t\t\t\t";
                }
                // line 56
                echo "\t\t\t\t</td>
\t\t\t\t<td>
\t\t\t\t\t<!--<a class=\"add-field btn btn-small\">添加</a>-->
\t\t\t\t\t<a class=\"del-field btn btn-small\">删除</a>
\t\t\t\t</td>
\t\t\t</tr>
\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['k'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 63
            echo "\t\t\t";
        } else {
            // line 64
            echo "\t\t\t<tr>
\t\t\t\t<td id=\"no-field\" colspan=\"7\" style=\"text-align: center;\">
\t\t\t\t\t尚未设置自定义表单项
\t\t\t\t</td>
\t\t\t</tr>
\t\t\t";
        }
        // line 70
        echo "\t\t</tbody>
\t\t<tfoot>
\t\t<tr>
\t\t\t<td colspan=\"7\">
\t\t\t\t<button type=\"submit\" class=\"btn btn-primary\">保存</button>
\t\t\t</td>
\t\t</tr>
\t\t</tfoot>
\t</table>
</form>
<div id=\"field-modal\" index=\"-1\" class=\"modal hide fade\" role=\"dialog\">
\t<div class=\"modal-header\">
\t\t<button type=\"button\" class=\"close\" data-dismiss=\"modal\">×</button>
\t\t<h3>选择类型</h3>
\t</div>
\t<div class=\"modal-body\" style=\"max-height:200px;\">
\t\t";
        // line 86
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["reserve_form_config"]) ? $context["reserve_form_config"] : $this->getContext($context, "reserve_form_config")));
        foreach ($context['_seq'] as $context["k"] => $context["rfc"]) {
            // line 87
            echo "\t\t";
            if ($this->getAttribute((isset($context["rfc"]) ? $context["rfc"] : null), "fields", array(), "array", true, true)) {
                // line 88
                echo "\t\t\t";
                if ((twig_length_filter($this->env, $this->getAttribute((isset($context["rfc"]) ? $context["rfc"] : $this->getContext($context, "rfc")), "fields", array(), "array")) > 0)) {
                    // line 89
                    echo "\t\t\t<label class=\"radio\">
\t\t\t\t";
                    // line 90
                    if (((isset($context["k"]) ? $context["k"] : $this->getContext($context, "k")) == 0)) {
                        // line 91
                        echo "\t\t\t\t<input type=\"radio\" name=\"type\" fd-type=\"";
                        echo (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k"));
                        echo "\" fd-name=\"";
                        echo $this->getAttribute((isset($context["rfc"]) ? $context["rfc"] : $this->getContext($context, "rfc")), "type", array(), "array");
                        echo "\" value=\"";
                        echo $this->getAttribute($this->getAttribute((isset($context["rfc"]) ? $context["rfc"] : $this->getContext($context, "rfc")), "fields", array(), "array"), 0, array(), "array");
                        echo "\" checked=\"checked\"> ";
                        echo $this->getAttribute((isset($context["rfc"]) ? $context["rfc"] : $this->getContext($context, "rfc")), "type", array(), "array");
                        echo "
\t\t\t\t";
                    } else {
                        // line 93
                        echo "\t\t\t\t<input type=\"radio\" name=\"type\" fd-type=\"";
                        echo (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k"));
                        echo "\" fd-name=\"";
                        echo $this->getAttribute((isset($context["rfc"]) ? $context["rfc"] : $this->getContext($context, "rfc")), "type", array(), "array");
                        echo "\" value=\"";
                        echo $this->getAttribute($this->getAttribute((isset($context["rfc"]) ? $context["rfc"] : $this->getContext($context, "rfc")), "fields", array(), "array"), 0, array(), "array");
                        echo "\"> ";
                        echo $this->getAttribute((isset($context["rfc"]) ? $context["rfc"] : $this->getContext($context, "rfc")), "type", array(), "array");
                        echo "
\t\t\t\t";
                    }
                    // line 95
                    echo "\t\t\t\t<span>(剩余数量：";
                    echo twig_length_filter($this->env, $this->getAttribute((isset($context["rfc"]) ? $context["rfc"] : $this->getContext($context, "rfc")), "fields", array(), "array"));
                    echo ")</span>
\t\t\t</label>
\t\t\t";
                }
                // line 98
                echo "\t\t";
            }
            // line 99
            echo "\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['k'], $context['rfc'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 100
        echo "\t</div>
\t<div class=\"modal-footer\">
\t\t<button class=\"confirm-type\" data-dismiss=\"modal\">确定</button>
\t</div>
</div>
";
    }

    // line 107
    public function block_style($context, array $blocks = array())
    {
        // line 108
        echo "<style type=\"text/css\">
\t.table
\t{
\t\tbackground: #FFFFFF;
\t}
</style>
";
    }

    // line 116
    public function block_script($context, array $blocks = array())
    {
        // line 117
        echo "<script type=\"text/javascript\">
\t\$(function() {
\t\tvar form_config_arr = ";
        // line 119
        echo (isset($context["reserve_form_config_arr"]) ? $context["reserve_form_config_arr"] : $this->getContext($context, "reserve_form_config_arr"));
        echo ";

\t\t\$('.confirm-type').click(function(){
\t\t\tif(\$('#field-modal input[name=\"type\"]').length == 0)
\t\t\t{
\t\t\t\treturn;
\t\t\t}

\t\t\tvar selectItem = \$('#field-modal input[name=\"type\"]:checked');
            if(selectItem.length==0){
                alert('请选择项目数据类型！');
                return false;
            }
\t\t\tvar fieldId = selectItem.val();
\t\t\tvar fieldType = selectItem.attr('fd-type');
\t\t\tvar fieldName = selectItem.attr('fd-name');

\t\t\tvar i = \$('.item-field').length;

\t\t\tvar tdItems = '';
\t\t\tvar tdStore = '';
\t\t\tif(fieldType == 1)
\t\t\t{
\t\t\t\ttdItems = '<input name=\"collection['+i+'][items]\" class=\"input-xlarge\" type=\"text\">';
\t\t\t\ttdStore = '<input name=\"collection['+i+'][store]\" type=\"checkbox\" value=\"1\">';
\t\t\t}

\t\t\tvar item =  '<tr class=\"item-field latest-field\" index=\"'+i+'\">' +
\t\t\t\t\t'<td><input name=\"collection['+i+'][rank]\" class=\"input-small\" type=\"text\"></td>' +
\t\t\t\t\t'<td><input name=\"collection['+i+'][name]\" class=\"input-medium\" type=\"text\"></td>' +
\t\t\t\t\t'<td>' + fieldName +
\t\t\t\t\t'<input name=\"collection['+i+'][id]\" type=\"hidden\" value=\"'+fieldId+'\">' +
\t\t\t\t\t'<input name=\"collection['+i+'][type]\" type=\"hidden\" value=\"'+fieldType+'\">' +
\t\t\t\t\t'</td>' +
\t\t\t\t\t'<td><input name=\"collection['+i+'][required]\" type=\"checkbox\" value=\"1\"></td>' +
\t\t\t\t\t'<td class=\"td-items\">'+tdItems+'</td>' +
\t\t\t\t\t'<td class=\"td-store\">'+tdStore+'</td>' +
\t\t\t\t\t'<td>' +
\t\t\t\t\t'<!--<a class=\"add-field btn btn-small\">添加</a>-->' +
\t\t\t\t\t'<a class=\"del-field btn btn-small\">删除</a>' +
\t\t\t\t\t'</td>' +
\t\t\t\t\t'</tr>';
\t\t\t\$('#no-field').remove();
\t\t\t//\$('#btn-add').hide();
\t\t\t\$('#forms tfoot').show();
\t\t\t\$('#forms tbody').append(item);

\t\t\tdelFieldType(fieldType);
\t\t});

/*\t\t\$('#forms').on('click', '.add-field', function(){
\t\t\t\$('#field-modal input[name=\"type\"]').first().prop('checked', true);
\t\t\t\$('#field-modal').attr('index', \$(this).parent().parent().attr('index'));
\t\t\t\$('#field-modal').modal('show');
\t\t});*/

\t\t\$('#forms').on('click', '.del-field', function(){
\t\t\tif(confirm(\"是否删除该字段？\"))
\t\t\t{
\t\t\t\tvar index = \$(this).parent().parent().attr('index');

\t\t\t\t//更新该行后的TR的index
\t\t\t\t\$.each(\$('.item-field'), function(i, ele){
\t\t\t\t\tif(i > index)
\t\t\t\t\t{
\t\t\t\t\t\tvar newIndex = i-1;
\t\t\t\t\t\t\$(ele).attr('index', newIndex);
\t\t\t\t\t\t\$(ele).find('input[name*=\"rank\"]').attr('name', 'collection['+newIndex+'][rank]');
\t\t\t\t\t\t\$(ele).find('input[name*=\"name\"]').attr('name', 'collection['+newIndex+'][name]');
\t\t\t\t\t\t\$(ele).find('input[name*=\"id\"]').attr('name', 'collection['+newIndex+'][id]');
\t\t\t\t\t\t\$(ele).find('input[name*=\"type\"]').attr('name', 'collection['+newIndex+'][type]');
\t\t\t\t\t\t\$(ele).find('input[name*=\"required\"]').attr('name', 'collection['+newIndex+'][required]');
\t\t\t\t\t\t\$(ele).find('input[name*=\"items\"]').attr('name', 'collection['+newIndex+'][items]');
\t\t\t\t\t\t\$(ele).find('input[name*=\"store\"]').attr('name', 'collection['+newIndex+'][store]');
\t\t\t\t\t}
\t\t\t\t});

\t\t\t\t//添加配置数组中的字段
\t\t\t\tvar addField = \$(this).parent().parent().find('input[name*=\"id\"]').val();
\t\t\t\tvar type = \$(this).parent().parent().find('input[name*=\"type\"]').val();
\t\t\t\taddFieldType(type, addField);

\t\t\t\t//删除该行
\t\t\t\t\$(this).parent().parent().remove();

\t\t\t\t//如果全部删除,显示尚无字段,显示添加字段按钮
\t\t\t\tif(\$('.item-field').length == 0)
\t\t\t\t{
\t\t\t\t\tvar noFieldItem = '<tr>' +
\t\t\t\t\t\t\t'<td id=\"no-field\" colspan=\"7\" style=\"text-align: center;\">尚未设置自定义表单项</td>' +
\t\t\t\t\t\t\t'</tr>';
\t\t\t\t\t\$('#forms tbody').append(noFieldItem);
\t\t\t\t\t\$('#btn-add').show();
\t\t\t\t\t//\$('#forms tfoot').hide();
\t\t\t\t}
\t\t\t}
\t\t});

\t\tfunction addFieldType(type, field)
\t\t{
\t\t\tif(!\$.isEmptyObject(form_config_arr[type]['fields']))
\t\t\t{
\t\t\t\tform_config_arr[type][\"fields\"].unshift(field);
\t\t\t\tupdateFieldTypes();
\t\t\t}
\t\t}

\t\tfunction delFieldType(type)
\t\t{
\t\t\tif(!\$.isEmptyObject(form_config_arr[type]['fields']))
\t\t\t{
\t\t\t\tform_config_arr[type][\"fields\"].shift();
\t\t\t\tupdateFieldTypes();
\t\t\t}
\t\t}

\t\tfunction updateFieldTypes()
\t\t{
\t\t\tvar radioItem = '';
\t\t\t\$.each(form_config_arr, function(i, ele){
\t\t\t\tif(form_config_arr)
\t\t\t\t{
\t\t\t\t\tif(!\$.isEmptyObject(ele.fields) && ele.fields.length > 0)
\t\t\t\t\t{
\t\t\t\t\t\tradioItem += '<label class=\"radio\">';
\t\t\t\t\t\tradioItem += '<input type=\"radio\" name=\"type\" fd-type=\"'+i+'\" fd-name=\"'+ele.type+'\" value=\"'+ele.fields[0]+'\"> '+ele.type;
\t\t\t\t\t\tradioItem += '<span>(剩余数量：'+ele.fields.length+')</span>';
\t\t\t\t\t\tradioItem += '</label>';
\t\t\t\t\t}
\t\t\t\t}
\t\t\t});
\t\t\tif(radioItem != '')
\t\t\t{
\t\t\t\t\$('#field-modal .modal-body').html(radioItem);
\t\t\t}
\t\t\telse
\t\t\t{
\t\t\t\tradioItem += '您不能再添加字段了！';
\t\t\t\t\$('#field-modal .modal-body').html(radioItem);
\t\t\t}
\t\t}
\t});
</script>
";
    }

    public function getTemplateName()
    {
        return "reserve/form.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  280 => 119,  276 => 117,  273 => 116,  263 => 108,  260 => 107,  251 => 100,  245 => 99,  242 => 98,  235 => 95,  223 => 93,  211 => 91,  209 => 90,  206 => 89,  203 => 88,  200 => 87,  196 => 86,  178 => 70,  170 => 64,  167 => 63,  155 => 56,  152 => 55,  146 => 53,  140 => 51,  137 => 50,  135 => 49,  131 => 47,  123 => 45,  121 => 44,  117 => 42,  111 => 40,  105 => 38,  103 => 37,  95 => 34,  89 => 33,  85 => 32,  78 => 30,  72 => 29,  67 => 28,  62 => 27,  60 => 26,  38 => 6,  36 => 5,  33 => 4,  30 => 3,);
    }
}
