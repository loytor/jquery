<?php

/* setting/tools.html */
class __TwigTemplate_93b50a36ee8cbfbf550eebccf4c425a7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "
\t<table class=\"table table-hover table-striped\">

\t\t<tbody>

\t\t<tr>
\t\t\t<td><strong>实用小工具</strong></td>
\t\t\t<td></td>
\t\t</tr>

\t\t<tr>
\t\t\t<td>1. 天气预报：</td>
\t\t\t<td><a href=\"http://m.tianqi.com/\" target=\"_blank\">http://m.tianqi.com</a></td>
\t\t</tr>
\t\t<tr>
\t\t\t<td>2. 列车时刻查询：</td>
\t\t\t<td><a href=\"http://m.tieyou.com/\" target=\"_blank\">http://m.tieyou.com</a> </td>
\t\t</tr>
\t\t<tr>
\t\t\t<td>3. 影讯查询：</td>
\t\t\t<td><a href=\"http://m.mtime.cn/\" target=\"_blank\">http://m.mtime.cn</a> </td>
\t\t</tr>
\t\t<tr>
\t\t\t<td>4. 公交查询：</td>
\t\t\t<td><a href=\"http://m.8684.cn/\" target=\"_blank\">http://m.8684.cn</a> </td>
\t\t</tr>
\t\t<tr>
\t\t\t<td>5. 快递查询：</td>
\t\t\t<td><a href=\"http://m.46644.com/tool/express/?tpltype=weixin\" target=\"_blank\">http://m.46644.com/tool/express/?tpltype=weixin</a> </td>
\t\t</tr>
\t\t<tr>
\t\t\t<td>6. 彩票查询：</td>
\t\t\t<td><a href=\"http://m.46644.com/tool/caipiao/?tpltype=weixin\" target=\"_blank\">http://m.46644.com/tool/caipiao/?tpltype=weixin</a> </td>
\t\t</tr>
\t\t<tr>
\t\t\t<td>7. 周公解梦：</td>
\t\t\t<td><a href=\"http://www.aqioo.cn/dream\" target=\"_blank\"> http://www.aqioo.cn/dream</a> </td>
\t\t</tr>
\t\t<tr>
\t\t\t<td>8. 星座测试：</td>
\t\t\t<td><a href=\"http://infoapp.3g.qq.com/g/s?g_f=22207&aid=astro#home\" target=\"_blank\"> http://infoapp.3g.qq.com/g/s?g_f=22207&aid=astro#home</a> </td>
\t\t</tr>
\t\t<tr>
\t\t\t<td>9. 姓名八字查询：</td>
\t\t\t<td><a href=\"http://dp.sina.cn/dpool/astro/ast_guide/guide.php?g_type=5&vt=4\" target=\"_blank\">http://dp.sina.cn/dpool/astro/ast_guide/guide.php?g_type=5&vt=4</a> </td>
\t\t</tr>
\t\t<tr>
\t\t\t<td>10. 下厨房 （菜谱大全）：</td>
\t\t\t<td><a href=\"http://m.xiachufang.com/\" target=\"_blank\">http://m.xiachufang.com</a> </td>
\t\t</tr>
\t\t<tr>
\t\t\t<td>11. 万年历：</td>
\t\t\t<td><a href=\"http://m.46644.com/tool/calendar/?tpltype=weixin\" target=\"_blank\">http://m.46644.com/tool/calendar/?tpltype=weixin</a> </td>
\t\t</tr>
\t\t<tr>
\t\t\t<td>12. 电话归属地查询：</td>
\t\t\t<td><a href=\"http://m.46644.com/tool/shouji/?tpltype=weixin\" target=\"_blank\">http://m.46644.com/tool/shouji/?tpltype=weixin</a> </td>
\t\t</tr>
<!--\t\t<tr>
\t\t\t<td>13. 违章查询：</td>
\t\t\t<td><a href=\"http://tools.iask.cn/iask/tools/clwg_index.php?vt=2\" target=\"_blank\">http://tools.iask.cn/iask/tools/clwg_index.php?vt=2</a> </td>
\t\t</tr>-->
\t\t<tr>
\t\t\t<td>13. 车辆保险计算器：</td>
\t\t\t<td><a href=\"http://car.m.yiche.com/qichebaoxianjisuan/\" target=\"_blank\">http://car.m.yiche.com/qichebaoxianjisuan/</a> </td>
\t\t</tr>
\t\t<tr>
\t\t\t<td>14. 贷款购车计算器：</td>
\t\t\t<td><a href=\"http://car.m.yiche.com/qichedaikuanjisuanqi/\" target=\"_blank\">http://car.m.yiche.com/qichedaikuanjisuanqi/</a> </td>
\t\t</tr>
\t\t<tr>
\t\t\t<td>15. 全款购车计算器：</td>
\t\t\t<td><a href=\" http://car.m.yiche.com/gouchejisuanqi/\" target=\"_blank\"> http://car.m.yiche.com/gouchejisuanqi/</a> </td>
\t\t</tr>
\t\t<tr>
\t\t\t<td>16. 房贷计算器：</td>
\t\t\t<td><a href=\" http://m.leju.com/touch/tools/house_loan.html\" target=\"_blank\"> http://m.leju.com/touch/tools/house_loan.html</a> </td>
\t\t</tr>
\t\t<tr>
\t\t\t<td></td>
\t\t\t<td></td>
\t\t</tr>

\t\t<tr>
\t\t\t<td><strong>轻松小游戏</strong></td>
\t\t\t<td></td>
\t\t</tr>

\t\t<tr>
\t\t\t<td>大家来找茬</td>
\t\t\t<td>http://resource.duopao.com/duopao/games/small_games/weixingame/sameclick/sameclick.htm</td>
\t\t</tr>
\t\t<tr>
\t\t\t<td>梦幻农场连连看</td>
\t\t\t<td>http://resource.duopao.com/duopao/games/small_games/weixingame/DreamFarmLink/DreamFarmLink.htm</td>
\t\t</tr>
\t\t<tr>
\t\t\t<td>小怪物吃饼干</td>
\t\t\t<td>http://resource.duopao.com/duopao/games/small_games/weixingame/bouffecookie/bouffecookie.htm</td>
\t\t</tr>

\t\t<tr>
\t\t\t<td>神秘方块</td>
\t\t\t<td>http://resource.duopao.com/duopao/games/small_games/weixingame/unitem/Unitem.htm</td>
\t\t</tr>

\t\t</tbody>
\t</table>

";
    }

    public function getTemplateName()
    {
        return "setting/tools.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 4,  28 => 3,);
    }
}
