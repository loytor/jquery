<?php

/* cate_banner/add.html */
class __TwigTemplate_9599b807d2a1348a3b96796be3e1a7e1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'style' => array($this, 'block_style'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "<ul class=\"breadcrumb clearfix\">
    <li><a href=\"/cate_banner\">首页幻灯片</a> <span class=\"divider\">/</span></li>
\t<li class=\"active\">添加广告</li>
</ul>
<div class=\"well\">
\t<div class=\"row-fluid\">
\t\t<div class=\"span8\">
\t\t\t<form class=\"form-horizontal\" action=\"\" method=\"post\">
\t\t\t\t<div class=\"control-group\">
\t\t\t\t\t<label class=\"control-label\" for=\"input-title\">标题</label>
\t\t\t\t\t<div class=\"controls\">
\t\t\t\t\t\t<input type=\"text\" name=\"title\" id=\"input-title\" class=\"span4\">
\t\t\t\t\t\t<span class=\"help-inline\"><span class=\"label\">建议10个汉字以内</span></span>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"control-group\">
\t\t\t\t\t<label class=\"control-label\" for=\"input-image\">广告图片</label>
\t\t\t\t\t<div class=\"controls\">
\t\t\t\t\t\t<span class=\"help-block\"><span class=\"label\">建议图片尺寸640 : 320</span></span>
\t\t\t\t\t\t<img src=\"/assets/img/no_image.png\" class=\"img-polaroid\" id=\"image-banner-preview\">
                        <input type=\"button\" class=\"btn j_img_clear\" value=\"删除\" style=\"margin:0 0 5px 10px;\" />
\t\t\t\t\t\t<input type=\"hidden\" name=\"image\" class=\"img_value\" id=\"input-image\">
\t\t\t\t\t\t<div id=\"uploader-img\"></div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"control-group\" id=\"control_show_url\">
\t\t\t\t\t<div class=\"controls\">
\t\t\t\t\t\t<a href=\"#\" id=\"show_url\"><span class=\"label\"><i class=\"icon-share icon-white\"></i> 指向外部链接</span></a>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"control-group hide\" id=\"control_url\">
\t\t\t\t\t<label class=\"control-label\" for=\"input-url\">外部链接</label>
\t\t\t\t\t<div class=\"controls\">
\t\t\t\t\t\t<input type=\"text\" name=\"url\" id=\"input-url\" class=\"span4\" placeholder=\"http://\">
\t\t\t\t\t</div>
\t\t\t\t</div>\t\t
\t\t\t\t<div class=\"control-group\">
\t\t\t\t\t<div class=\"controls\">
\t\t\t\t\t\t<button type=\"submit\" class=\"btn btn-primary\">确认保存</button>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</form>
\t\t</div>
\t\t<div class=\"span4\" style=\"float:right;\">
\t\t\t<h5>头部广告示意图</h5>
\t\t\t<img src=\"/assets/img/cate_banner.jpg\">
\t\t</div>
\t</div>
</div>
<div id=\"guide_1\" class=\"modal hide fade\" tabindex=\"-1\">
\t<div class=\"modal-body\">
\t\t<img src=\"/assets/img/guide_1.jpg\">
\t</div>
\t<div class=\"modal-footer\">
\t\t<button class=\"btn\" data-dismiss=\"modal\" aria-hidden=\"true\">关闭</button>
\t</div>
</div>
";
    }

    // line 63
    public function block_style($context, array $blocks = array())
    {
        // line 64
        echo "<link href=\"/assets/huploadify/Huploadify.css\" rel=\"stylesheet\">
<style type=\"text/css\" >
    .uploadify-button{
        color: #333;
        background-color: #fff;
        border-color: #ccc;
        cursor:pointer;
        text-decoration:none;
        border-radius: 2px;
        margin-left: 0;
    }
    .uploadify-button:hover {
        background-color: #ccc;
        background-image: none;
        background-position: center bottom;
        cursor:pointer;
        text-decoration:none;
    }
</style>
";
    }

    // line 85
    public function block_script($context, array $blocks = array())
    {
        // line 86
        echo "<script src=\"/assets/huploadify/jquery.Huploadify.js\"></script>
<script type=\"text/javascript\">
    \$(function() {
        function upload_file(id,text,type){
            \$(id).Huploadify({
                'fileObjName': 'image',
                'fileSizeLimit': 2048,
                'fileTypeExts': '*.gif; *.jpg; *.png',
                'multi': false,
                'auto':true,
                'showUploadedPercent':false,
                'removeTimeout': 0,
                'buttonText': text ? text : '选择图片',
                'formData': {'token': '";
        // line 99
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
                'swf': '/assets/js/uploadify.swf',
                'uploader': '/image/upload_gd',
                'onFallback': function() {
                    alert('您的浏览器没有安装Flash插件');
                },
                'onUploadSuccess': function(file, data) {
                    var ret = \$.parseJSON(data);
                    if (ret) {
                        if (ret.success) {
                            \$(id).parent().find('.img_value').val(ret.image);
                            \$(id).parent().find('img').attr('src', ret.image);
                        } else {
                            alert(ret.message);
                        }
                    }
                }
            });
        }
        upload_file('#uploader-img','');

        //删除图片
        \$(document).on('click','.j_img_clear',function(){
            \$(this).next('input').val('');
            \$(this).prevAll('img').attr('src','/assets/img/no_image.png');
        });

        //指向外部链接
        \$('#show_url').click(function() {
            \$('#control_url').removeClass('hide');
            \$('#control_show_url').addClass('hide');
            return false;
        });

    });
</script>
";
    }

    public function getTemplateName()
    {
        return "cate_banner/add.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 99,  123 => 86,  120 => 85,  97 => 64,  94 => 63,  33 => 4,  30 => 3,);
    }
}
