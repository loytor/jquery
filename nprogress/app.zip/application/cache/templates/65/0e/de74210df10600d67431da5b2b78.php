<?php

/* effect/index.html */
class __TwigTemplate_650ede74210df10600d67431da5b2b78 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'style' => array($this, 'block_style'),
            'main' => array($this, 'block_main'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_style($context, array $blocks = array())
    {
        // line 4
        echo "<link href=\"/assets/css/uploadify.css\" rel=\"stylesheet\">
<style>
    .form-horizontal .control-label{ width: 90px;}
    .form-horizontal .controls { margin-left: 110px;}
</style>
";
    }

    // line 11
    public function block_main($context, array $blocks = array())
    {
        // line 12
        echo "
    <ul class=\"nav nav-tabs\" style=\"margin-bottom: 0;\">
        <!--<li class=\"active\"><a href=\"#welcome\" data-toggle=\"tab\">网站欢迎页</a></li>-->
        <li class=\"active\"><a href=\"#loading\" data-toggle=\"tab\">加载特效</a></li>
        <li><a href=\"#bgmusic\" data-toggle=\"tab\">背景音乐</a></li>
        <li><a href=\"#milieu\"  data-toggle=\"tab\">环境</a></li>
    </ul>

    <div class=\"well tab-content\">
        <!--
        <div class=\"tab-pane active\" id=\"welcome\">
            <form class=\"form-horizontal\" method=\"post\">
                <div class=\"control-group\">
                    <label class=\"control-label\">状态</label>
                    <div class=\"controls\">
                        <label class=\"radio inline\">
                            <input type=\"radio\" name=\"enabled\" value=\"1\" ";
        // line 28
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "welcome", array(), "array", false, true), "config", array(), "array", false, true), "enabled", array(), "array", true, true) && ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "welcome", array(), "array"), "config", array(), "array"), "enabled", array(), "array") == 1))) {
            echo "checked";
        }
        echo ">开启
                        </label>
                        <label class=\"radio inline\">
                            <input type=\"radio\" name=\"enabled\" value=\"0\" ";
        // line 31
        if (((!$this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "welcome", array(), "array", false, true), "config", array(), "array", false, true), "enabled", array(), "array", true, true)) || ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "welcome", array(), "array"), "config", array(), "array"), "enabled", array(), "array") == 0))) {
            echo "checked";
        }
        echo ">关闭
                        </label>
                    </div>
                </div>
                <div class=\"control-group\">
                    <label class=\"control-label\">图标</label>
                    <div class=\"controls\">
                        ";
        // line 38
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "welcome", array(), "array", false, true), "config", array(), "array", false, true), "img", array(), "array", true, true) && (!twig_test_empty($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "welcome", array(), "array"), "config", array(), "array"), "img", array(), "array"))))) {
            // line 39
            echo "                        <img src=\"";
            echo $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "welcome", array(), "array"), "config", array(), "array"), "img", array(), "array");
            echo "\" class=\"img-polaroid\" id=\"welcome-preview\">
                        ";
        } else {
            // line 41
            echo "                        <img src=\"/assets/img/no_image.png\" class=\"img-polaroid\" id=\"welcome-preview\">
                        ";
        }
        // line 43
        echo "                        <input type=\"hidden\" name=\"welcome_img\" id=\"input-welcome\" value=\"";
        if ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "welcome", array(), "array", false, true), "config", array(), "array", false, true), "img", array(), "array", true, true)) {
            echo $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "welcome", array(), "array"), "config", array(), "array"), "img", array(), "array");
        } else {
        }
        echo "\">
                        <input type=\"file\" id=\"uploader-welcome\">
                    </div>
                </div>
                <div class=\"control-group\">
                    <div class=\"controls\">
                        <input type=\"hidden\" name=\"type\" value=\"welcome\">
                        <button type=\"submit\" class=\"btn btn-primary\">确认保存</button>
                    </div>
                </div>
            </form>
        </div>
        -->
        <div class=\"tab-pane active\" id=\"loading\">
            <form class=\"form-horizontal\" method=\"post\">
                <div class=\"control-group\">
                    <label class=\"control-label\">状态</label>
                    <div class=\"controls\">
                        <label class=\"radio inline\">
                            <input type=\"radio\" name=\"enabled\" value=\"1\" ";
        // line 62
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "loading", array(), "array", false, true), "config", array(), "array", false, true), "enabled", array(), "array", true, true) && ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "loading", array(), "array"), "config", array(), "array"), "enabled", array(), "array") == 1))) {
            echo "checked";
        }
        echo ">开启
                        </label>
                        <label class=\"radio inline\">
                            <input type=\"radio\" name=\"enabled\" value=\"0\" ";
        // line 65
        if (((!$this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "loading", array(), "array", false, true), "config", array(), "array", false, true), "enabled", array(), "array", true, true)) || ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "loading", array(), "array"), "config", array(), "array"), "enabled", array(), "array") == 0))) {
            echo "checked";
        }
        echo ">关闭
                        </label>
                    </div>
                </div>
                <div class=\"control-group\">
                    <label class=\"control-label\">范围</label>
                    <div class=\"controls\">
                        <label class=\"checkbox inline\">
                            <input type=\"checkbox\" name=\"scope[]\" value=\"home\" ";
        // line 73
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "loading", array(), "array", false, true), "config", array(), "array", false, true), "scope", array(), "array", true, true) && twig_in_filter("home", $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "loading", array(), "array"), "config", array(), "array"), "scope", array(), "array")))) {
            echo "checked";
        }
        echo "> 首页
                        </label>
                        <label class=\"checkbox inline\">
                            <input type=\"checkbox\" name=\"scope[]\" value=\"cate\" ";
        // line 76
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "loading", array(), "array", false, true), "config", array(), "array", false, true), "scope", array(), "array", true, true) && twig_in_filter("cate", $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "loading", array(), "array"), "config", array(), "array"), "scope", array(), "array")))) {
            echo "checked";
        }
        echo "> 分类
                        </label>
                        <label class=\"checkbox inline\">
                            <input type=\"checkbox\" name=\"scope[]\" value=\"detail\" ";
        // line 79
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "loading", array(), "array", false, true), "config", array(), "array", false, true), "scope", array(), "array", true, true) && twig_in_filter("detail", $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "loading", array(), "array"), "config", array(), "array"), "scope", array(), "array")))) {
            echo "checked";
        }
        echo "> 详细
                        </label>
                    </div>
                </div>
                <div class=\"control-group\">
                    <label class=\"control-label\">类型</label>
                    <div class=\"controls\">
                        <label class=\"radio\">
                            <input type=\"radio\" name=\"loading_type\" value=\"h\" ";
        // line 87
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "loading", array(), "array", false, true), "config", array(), "array", false, true), "type", array(), "array", true, true) && ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "loading", array(), "array"), "config", array(), "array"), "type", array(), "array") == "h"))) {
            echo "checked";
        }
        echo "> 默认(水平)
                        </label>
                        <label class=\"radio\">
                            <input type=\"radio\" name=\"loading_type\" value=\"w\" ";
        // line 90
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "loading", array(), "array", false, true), "config", array(), "array", false, true), "type", array(), "array", true, true) && ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "loading", array(), "array"), "config", array(), "array"), "type", array(), "array") == "w"))) {
            echo "checked";
        }
        echo "> 垂直
                        </label>
                    </div>
                </div>
                <div class=\"control-group\">
                    <label class=\"control-label\">效果</label>
                    <div class=\"controls\">
<!--                        <label class=\"radio inline\">
                            <input type=\"radio\" name=\"show_type\" value=\"color\" ";
        // line 98
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "loading", array(), "array", false, true), "config", array(), "array", false, true), "show_type", array(), "array", true, true) && ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "loading", array(), "array"), "config", array(), "array"), "show_type", array(), "array") == "color"))) {
            echo "checked";
        }
        echo "> 颜色
                        </label>-->
                        <label class=\"radio inline\">
                            <input type=\"radio\" name=\"show_type\" value=\"bgimg\" checked> 背景
                        </label>
                        <div>
<!--                            <div class=\"";
        // line 104
        if (((!$this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "loading", array(), "array", false, true), "config", array(), "array", false, true), "show_type", array(), "array", true, true)) || ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "loading", array(), "array"), "config", array(), "array"), "show_type", array(), "array") == "bgimg"))) {
            echo "hide";
        }
        echo "\" id=\"U_color\">
                                <span id=\"J_title\" style=\"color: ";
        // line 105
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "loading", array(), "array", false, true), "config", array(), "array", false, true), "show_type", array(), "array", true, true) && ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "loading", array(), "array"), "config", array(), "array"), "show_type", array(), "array") == "color"))) {
            echo $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "loading", array(), "array"), "config", array(), "array"), "value", array(), "array");
        }
        echo ";\">点击选择颜色</span>
                                <input type=\"hidden\" value=\"";
        // line 106
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "loading", array(), "array", false, true), "config", array(), "array", false, true), "show_type", array(), "array", true, true) && ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "loading", array(), "array"), "config", array(), "array"), "show_type", array(), "array") == "color"))) {
            echo $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "loading", array(), "array"), "config", array(), "array"), "value", array(), "array");
        }
        echo "\" name=\"color\" id=\"J_color\">
                                <a href=\"javascript:;\" class=\"color_picker_btn\"><img class=\"J_color_picker\" data-it=\"J_title\" data-ic=\"J_color\" src=\"/assets/img/color.png\"></a>
                            </div>-->
                            <div class=\"";
        // line 109
        if (((!$this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "loading", array(), "array", false, true), "config", array(), "array", false, true), "show_type", array(), "array", true, true)) || ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "loading", array(), "array"), "config", array(), "array"), "show_type", array(), "array") == "color"))) {
            echo "hide";
        }
        echo "\" id=\"U_bgimg\">
                                ";
        // line 110
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "loading", array(), "array", false, true), "config", array(), "array", false, true), "show_type", array(), "array", true, true) && ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "loading", array(), "array"), "config", array(), "array"), "show_type", array(), "array") == "bgimg"))) {
            // line 111
            echo "                                <img src=\"";
            echo $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "loading", array(), "array"), "config", array(), "array"), "value", array(), "array");
            echo "\" class=\"img-polaroid\" id=\"bgimg-preview\">
                                ";
        } else {
            // line 113
            echo "                                <img src=\"/assets/img/no_image.png\" class=\"img-polaroid\" id=\"bgimg-preview\">
                                ";
        }
        // line 115
        echo "                                <input type=\"hidden\" name=\"bgimg\" id=\"input-bgimg\" value=\"";
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "loading", array(), "array", false, true), "config", array(), "array", false, true), "show_type", array(), "array", true, true) && ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "loading", array(), "array"), "config", array(), "array"), "show_type", array(), "array") == "bgimg"))) {
            echo $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "loading", array(), "array"), "config", array(), "array"), "value", array(), "array");
        }
        echo "\">
                                <input type=\"file\" id=\"uploader-bgimg\">
                            </div>
                        </div>
                    </div>
                </div>
                <div class=\"control-group\">
                    <div class=\"controls\">
                        <input type=\"hidden\" name=\"type\" value=\"loading\">
                        <button type=\"submit\" class=\"btn btn-primary\">确认保存</button>
                    </div>
                </div>
            </form>
        </div>
        <div class=\"tab-pane\" id=\"bgmusic\">
            <form class=\"form-horizontal\" method=\"post\">
                <div class=\"control-group\">
                    <label class=\"control-label\">状态</label>
                    <div class=\"controls\">
                        <label class=\"radio inline\">
                            <input type=\"radio\" name=\"enabled\" value=\"1\" ";
        // line 135
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "bgmusic", array(), "array", false, true), "config", array(), "array", false, true), "enabled", array(), "array", true, true) && ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "bgmusic", array(), "array"), "config", array(), "array"), "enabled", array(), "array") == 1))) {
            echo "checked";
        }
        echo ">开启
                        </label>
                        <label class=\"radio inline\">
                            <input type=\"radio\" name=\"enabled\" value=\"0\" ";
        // line 138
        if (((!$this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "bgmusic", array(), "array", false, true), "config", array(), "array", false, true), "enabled", array(), "array", true, true)) || ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "bgmusic", array(), "array"), "config", array(), "array"), "enabled", array(), "array") == 0))) {
            echo "checked";
        }
        echo ">关闭
                        </label>
                    </div>
                </div>
                <div class=\"control-group\">
                    <label class=\"control-label\">范围</label>
                    <div class=\"controls\">
                        <label class=\"checkbox inline\">
                            <input type=\"checkbox\" name=\"scope[]\" value=\"home\" ";
        // line 146
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "bgmusic", array(), "array", false, true), "config", array(), "array", false, true), "scope", array(), "array", true, true) && twig_in_filter("home", $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "bgmusic", array(), "array"), "config", array(), "array"), "scope", array(), "array")))) {
            echo "checked";
        }
        echo "> 首页
                        </label>
                        <label class=\"checkbox inline\">
                            <input type=\"checkbox\" name=\"scope[]\" value=\"cate\" ";
        // line 149
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "bgmusic", array(), "array", false, true), "config", array(), "array", false, true), "scope", array(), "array", true, true) && twig_in_filter("cate", $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "bgmusic", array(), "array"), "config", array(), "array"), "scope", array(), "array")))) {
            echo "checked";
        }
        echo "> 分类
                        </label>
                        <label class=\"checkbox inline\">
                            <input type=\"checkbox\" name=\"scope[]\" value=\"detail\" ";
        // line 152
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "bgmusic", array(), "array", false, true), "config", array(), "array", false, true), "scope", array(), "array", true, true) && twig_in_filter("detail", $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "bgmusic", array(), "array"), "config", array(), "array"), "scope", array(), "array")))) {
            echo "checked";
        }
        echo "> 详细
                        </label>
                    </div>
                </div>
                <div class=\"control-group\">
                    <label class=\"control-label\">音频文件</label>
                    <div class=\"controls\">
                        <input type=\"text\" name=\"musicurl\" class=\"span4\" value=\"";
        // line 159
        if ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "bgmusic", array(), "array", false, true), "config", array(), "array", false, true), "file", array(), "array", true, true)) {
            echo $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "bgmusic", array(), "array"), "config", array(), "array"), "file", array(), "array");
        }
        echo "\">
                        <input type=\"file\" id=\"uploader-music\">
                    </div>
                </div>
                <div class=\"control-group\">
                    <div class=\"controls\">
                        <input type=\"hidden\" name=\"type\" value=\"bgmusic\">
                        <button type=\"submit\" class=\"btn btn-primary\">确认保存</button>
                    </div>
                </div>
            </form>
        </div>
        <div class=\"tab-pane\" id=\"milieu\">
            <form class=\"form-horizontal\" method=\"post\">
                <div class=\"control-group\">
                    <label class=\"control-label\">状态</label>
                    <div class=\"controls\">
                        <label class=\"radio inline\">
                            <input type=\"radio\" name=\"enabled\" value=\"1\" ";
        // line 177
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "milieu", array(), "array", false, true), "config", array(), "array", false, true), "enabled", array(), "array", true, true) && ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "milieu", array(), "array"), "config", array(), "array"), "enabled", array(), "array") == 1))) {
            echo "checked";
        }
        echo ">开启
                        </label>
                        <label class=\"radio inline\">
                            <input type=\"radio\" name=\"enabled\" value=\"0\" ";
        // line 180
        if (((!$this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "milieu", array(), "array", false, true), "config", array(), "array", false, true), "enabled", array(), "array", true, true)) || ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "milieu", array(), "array"), "config", array(), "array"), "enabled", array(), "array") == 0))) {
            echo "checked";
        }
        echo ">关闭
                        </label>
                    </div>
                </div>
                <div class=\"control-group\">
                    <label class=\"control-label\">范围</label>
                    <div class=\"controls\">
                        <label class=\"checkbox inline\">
                            <input type=\"checkbox\" name=\"scope[]\" value=\"home\" ";
        // line 188
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "milieu", array(), "array", false, true), "config", array(), "array", false, true), "scope", array(), "array", true, true) && twig_in_filter("home", $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "milieu", array(), "array"), "config", array(), "array"), "scope", array(), "array")))) {
            echo "checked";
        }
        echo "> 首页
                        </label>
                        <label class=\"checkbox inline\">
                            <input type=\"checkbox\" name=\"scope[]\" value=\"cate\" ";
        // line 191
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "milieu", array(), "array", false, true), "config", array(), "array", false, true), "scope", array(), "array", true, true) && twig_in_filter("cate", $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "milieu", array(), "array"), "config", array(), "array"), "scope", array(), "array")))) {
            echo "checked";
        }
        echo "> 分类
                        </label>
                        <label class=\"checkbox inline\">
                            <input type=\"checkbox\" name=\"scope[]\" value=\"detail\" ";
        // line 194
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "milieu", array(), "array", false, true), "config", array(), "array", false, true), "scope", array(), "array", true, true) && twig_in_filter("detail", $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "milieu", array(), "array"), "config", array(), "array"), "scope", array(), "array")))) {
            echo "checked";
        }
        echo "> 详细
                        </label>
                    </div>
                </div>
                <div class=\"control-group\">
                    <label class=\"control-label\">效果</label>
                    <div class=\"controls\">
                        <label class=\"radio\">
                            <input type=\"radio\" name=\"milieu_type\" value=\"snow\" ";
        // line 202
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "milieu", array(), "array", false, true), "config", array(), "array", false, true), "type", array(), "array", true, true) && ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "milieu", array(), "array"), "config", array(), "array"), "type", array(), "array") == "snow"))) {
            echo "checked";
        }
        echo "> 下雪
                        </label>
                        <label class=\"radio\">
                            <input type=\"radio\" name=\"milieu_type\" value=\"rain\" ";
        // line 205
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "milieu", array(), "array", false, true), "config", array(), "array", false, true), "type", array(), "array", true, true) && ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "milieu", array(), "array"), "config", array(), "array"), "type", array(), "array") == "rain"))) {
            echo "checked";
        }
        echo "> 下雨
                        </label>
                        <label class=\"radio\">
                            <input type=\"radio\" name=\"milieu_type\" value=\"star\" ";
        // line 208
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "milieu", array(), "array", false, true), "config", array(), "array", false, true), "type", array(), "array", true, true) && ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "milieu", array(), "array"), "config", array(), "array"), "type", array(), "array") == "star"))) {
            echo "checked";
        }
        echo "> 星星
                        </label>
\t                    <label class=\"radio\">
\t\t                    <input type=\"radio\" name=\"milieu_type\" value=\"rose\" ";
        // line 211
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "milieu", array(), "array", false, true), "config", array(), "array", false, true), "type", array(), "array", true, true) && ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "milieu", array(), "array"), "config", array(), "array"), "type", array(), "array") == "rose"))) {
            echo "checked";
        }
        echo "> 玫瑰花
\t                    </label>
\t                    <label class=\"radio\">
\t\t                    <input type=\"radio\" name=\"milieu_type\" value=\"orange\" ";
        // line 214
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : null), "milieu", array(), "array", false, true), "config", array(), "array", false, true), "type", array(), "array", true, true) && ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["site_effect"]) ? $context["site_effect"] : $this->getContext($context, "site_effect")), "milieu", array(), "array"), "config", array(), "array"), "type", array(), "array") == "orange"))) {
            echo "checked";
        }
        echo "> 桔子
\t                    </label>
                    </div>
                </div>
                <div class=\"control-group\">
                    <div class=\"controls\">
                        <input type=\"hidden\" name=\"type\" value=\"milieu\">
                        <button type=\"submit\" class=\"btn btn-primary\">确认保存</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

";
    }

    // line 230
    public function block_script($context, array $blocks = array())
    {
        // line 231
        echo "<script src=\"/assets/js/jquery.uploadify.min.js\"></script>
<script src=\"/assets/js/colorpicker.js\"></script>
<script type=\"text/javascript\">
    \$('input[name=\"show_type\"]').on('click', function(){
        var show_type = \$(this).val();
        console.log(show_type);
        \$('#U_'+show_type).siblings().hide();
        \$('#U_'+show_type).show();
    });
    \$('.J_color_picker').colorpicker();
    \$(function() {
        \$('#uploader-welcome').uploadify({
            'fileObjName': 'image',
            'fileSizeLimit': '2MB',
            'fileTypeExts': '*.gif; *.jpg; *.png',
            'multi': false,
            'removeTimeout': 0,
            'width': 90,
            'height': 25,
            'buttonText': '上传图片',
            'formData': {'token': '";
        // line 251
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
            'swf': '/assets/js/uploadify.swf',
            'uploader': '/image/upload_effect',
            'onFallback': function() {
                alert('您的浏览器没有安装Flash插件');
            },
            'onUploadSuccess': function(file, data, response) {
                if (response) {
                    var ret = \$.parseJSON(data);
                    if (ret) {
                        if (ret.success) {
                            \$('#input-welcome').val(ret.image);
                            \$('#welcome-preview').attr('src', ret.image);
                        } else {
                            alert(ret.message);
                        }
                    }
                }
            }
        });

        \$('#uploader-bgimg').uploadify({
            'fileObjName': 'image',
            'fileSizeLimit': '2MB',
            'fileTypeExts': '*.gif; *.jpg; *.png',
            'multi': false,
            'removeTimeout': 0,
            'width': 90,
            'height': 25,
            'buttonText': '上传图片',
            'formData': {'token': '";
        // line 281
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
            'swf': '/assets/js/uploadify.swf',
            'uploader': '/image/upload_effect',
            'onFallback': function() {
                alert('您的浏览器没有安装Flash插件');
            },
            'onUploadSuccess': function(file, data, response) {
                if (response) {
                    var ret = \$.parseJSON(data);
                    if (ret) {
                        if (ret.success) {
                            \$('#input-bgimg').val(ret.image);
                            \$('#bgimg-preview').attr('src', ret.image);
                        } else {
                            alert(ret.message);
                        }
                    }
                }
            }
        });

        \$('#uploader-music').uploadify({
            'fileObjName': 'userfile',
            'fileSizeLimit': '2MB',
            'fileTypeExts': '*.mp3',
            'multi': false,
            'removeTimeout': 0,
            'width': 90,
            'height': 25,
            'buttonText': '上传音频',
            'formData': {'token': '";
        // line 311
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
            'swf': '/assets/js/uploadify.swf',
            'uploader': '/effect/upload_music',
            'onFallback': function() {
                alert('您的浏览器没有安装Flash插件');
            },
            'onUploadSuccess': function(file, data, response) {
                if (response) {

                    var ret = \$.parseJSON(data);
                    if(ret.success == 1)
                    {
                        \$('input[name=musicurl]').val(ret.mp3);
                        //\$('input[name=HQmusicurl]').val(ret.mp3);
                    }
                    else
                    {
                        alert(ret.message);return false;
                    }
                }
            }
        });
    });

</script>
";
    }

    public function getTemplateName()
    {
        return "effect/index.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  533 => 311,  500 => 281,  467 => 251,  445 => 231,  442 => 230,  421 => 214,  413 => 211,  405 => 208,  397 => 205,  389 => 202,  376 => 194,  368 => 191,  360 => 188,  347 => 180,  339 => 177,  316 => 159,  304 => 152,  296 => 149,  288 => 146,  275 => 138,  267 => 135,  241 => 115,  237 => 113,  231 => 111,  229 => 110,  223 => 109,  215 => 106,  209 => 105,  203 => 104,  192 => 98,  179 => 90,  171 => 87,  158 => 79,  150 => 76,  142 => 73,  129 => 65,  121 => 62,  95 => 43,  91 => 41,  85 => 39,  83 => 38,  71 => 31,  63 => 28,  45 => 12,  42 => 11,  33 => 4,  30 => 3,);
    }
}
