<?php

/* mall/cate_add.html */
class __TwigTemplate_e0a2efcb25afbc255a6fe089061074af extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'style' => array($this, 'block_style'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "<ul class=\"breadcrumb clearfix\">
    <li><a href=\"/mall/cate\">商品分类</a> <span class=\"divider\">/</span></li>
    <li class=\"active\">";
        // line 6
        echo (isset($context["type_info"]) ? $context["type_info"] : $this->getContext($context, "type_info"));
        echo "</li>
</ul>
<div class=\"well\">
\t<form class=\"form-horizontal\" action=\"\" method=\"post\">
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">分类名称</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<input type=\"text\" name=\"name\" value=\"\">
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">分类描述</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<textarea type=\"text\" name=\"desc\"></textarea>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">分类图片</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<img src=\"/assets/img/no_image.png\" style=\"width:150px;height:150px\" class=\"img-polaroid\" id=\"img-preview\">
\t\t\t\t<input type=\"button\" class=\"btn j_img_clear\" value=\"清空\" style=\"margin:0 0 5px 10px;\" />
\t\t\t\t<input type=\"hidden\" name=\"img\" id=\"input-img\">
\t\t\t\t<input type=\"file\" id=\"uploader-img\">
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">排序</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<input type=\"text\" name=\"rank\" class=\"input-small\" value=\"999\">
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<div class=\"controls\">
\t\t\t\t<button type=\"submit\" class=\"btn btn-primary\">确认保存</button>
\t\t\t</div>
\t\t</div>
\t</form>
</div>
";
    }

    // line 46
    public function block_style($context, array $blocks = array())
    {
        // line 47
        echo "<link href=\"/assets/css/uploadify.css\" rel=\"stylesheet\">
<style type=\"text/css\">
</style>
";
    }

    // line 52
    public function block_script($context, array $blocks = array())
    {
        // line 53
        echo "<script src=\"/assets/js/lhgcalendar.min.js\"></script>
<script src=\"/assets/js/kindeditor/kindeditor-all-min.js\"></script>
<script src=\"/assets/js/kindeditor/lang/zh_CN.js\"></script>
<script src=\"/assets/js/jquery.uploadify.min.js\"></script>
<script type=\"text/javascript\">
\t\$(function() {
\t\tvar editor;
\t\tKindEditor.ready(function(K) {
\t\t\teditor = K.create('textarea[name=\"desc\"]', {
\t\t\t\tresizeType: 1,
\t\t\t\tpasteType: 1,
\t\t\t\tminWidth:430,
\t\t\t\tnewlineTag:'br',
\t\t\t\titems: ['undo', 'redo', '|', 'forecolor', 'hilitecolor', 'bold', 'italic', 'underline','strikethrough', 'removeformat', '|', 'justifyleft', 'justifycenter', 'justifyright', 'insertorderedlist', 'insertunorderedlist', 'hr']
\t\t\t});
\t\t});

\t\t\$('#uploader-img').uploadify({
\t\t\t'fileObjName': 'image',
\t\t\t'fileSizeLimit': '2MB',
\t\t\t'fileTypeExts': '*.gif; *.jpg; *.png',
\t\t\t'multi': false,
\t\t\t'removeTimeout': 0,
\t\t\t'width': 90,
\t\t\t'height': 25,
\t\t\t'buttonText': '选择图片',
\t\t\t'formData': {'token': '";
        // line 79
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
\t\t\t'swf': '/assets/js/uploadify.swf',
\t\t\t'uploader': '/image/upload_gd',
\t\t\t'onFallback': function() {
\t\t\t\talert('您的浏览器没有安装Flash插件');
\t\t\t},
\t\t\t'onUploadSuccess': function(file, data, response) {
\t\t\t\tif (response) {
\t\t\t\t\tvar ret = \$.parseJSON(data);
\t\t\t\t\tif (ret) {
\t\t\t\t\t\tif (ret.success) {
\t\t\t\t\t\t\t\$('#input-img').val(ret.image);
\t\t\t\t\t\t\t\$('#img-preview').attr('src', ret.image);
\t\t\t\t\t\t} else {
\t\t\t\t\t\t\talert(ret.message);
\t\t\t\t\t\t}
\t\t\t\t\t}
\t\t\t\t}
\t\t\t}
\t\t});
\t});
</script>
";
    }

    public function getTemplateName()
    {
        return "mall/cate_add.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  121 => 79,  93 => 53,  90 => 52,  83 => 47,  80 => 46,  37 => 6,  33 => 4,  30 => 3,);
    }
}
