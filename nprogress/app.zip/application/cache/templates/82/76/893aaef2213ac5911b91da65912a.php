<?php

/* album/login.html */
class __TwigTemplate_8276893aaef2213ac5911b91da65912a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
<meta charset=\"utf-8\">
<title>相册</title>
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
<meta name=\"description\" content=\"\">
<script src=\"/assets/js/jquery.min.js\"></script>
<script src=\"/assets/js/bootstrap.min.js\"></script>
<link href=\"/assets/css/bootstrap.min.css\" rel=\"stylesheet\">
<link href=\"/assets/css/bootstrap-responsive.min.css\" rel=\"stylesheet\">
<link href=\"/assets/css/app.css\" rel=\"stylesheet\">
<style type=\"text/css\">
body {
\tbackground-color: #f5f5f5;
}
.container {
\tmargin: 0 auto;
\tmax-width: 1000px;
}
.form-login {
\tmax-width: 350px;
\tpadding: 20px 30px;
\tmargin: 20px auto;
\tbackground-color: #fff;
\tborder: 1px solid #e5e5e5;
}
.form-login h2 {
\tmargin-bottom: 20px;
}
</style>
<!--[if lt IE 9]>
<script src=\"/assets/js/html5shiv.js\"></script>
<![endif]-->
</head>
<body>
<div class=\"container\">
\t<form class=\"form-login\" action=\"\" method=\"post\">
\t\t<h3 style=\"text-align:center\">相册</h3>
\t\t<input type=\"text\" name=\"username\" class=\"input-block-level\" placeholder=\"填写用户名\">
\t\t<input type=\"password\" name=\"password\" class=\"input-block-level\" placeholder=\"填写密码\">
\t\t<button type=\"submit\" class=\"btn btn-large btn-primary btn-block\">登录</button>
\t</form>
</div>
</body>
</html>";
    }

    public function getTemplateName()
    {
        return "album/login.html";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
