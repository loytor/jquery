<?php

/* cate/update.html */
class __TwigTemplate_a90469c2e2890cf8e644d488aa279e96 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'style' => array($this, 'block_style'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "<ul class=\"breadcrumb clearfix\">
\t<li><a href=\"/cate\">栏目管理</a> <span class=\"divider\">/</span></li>
\t<li class=\"active\">修改栏目</li>
</ul>
<div class=\"well\">
\t<form class=\"form-horizontal\" action=\"\" method=\"post\">
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">上级栏目</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<select name=\"parent_id\" class=\"input-medium\">
\t\t\t\t\t<option value=\"0\">顶级栏目</option>
\t\t\t\t\t";
        // line 15
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["cate_arr"]) ? $context["cate_arr"] : $this->getContext($context, "cate_arr")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 16
            echo "\t\t\t\t\t\t";
            if (($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "id", array(), "array") == $this->getAttribute((isset($context["cate"]) ? $context["cate"] : $this->getContext($context, "cate")), "parent_id", array(), "array"))) {
                // line 17
                echo "\t\t\t\t\t\t<option value=\"";
                echo $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "id", array(), "array");
                echo "\" selected>";
                echo $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "text", array(), "array");
                echo "</option>
\t\t\t\t\t\t";
            } else {
                // line 19
                echo "\t\t\t\t\t\t<option value=\"";
                echo $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "id", array(), "array");
                echo "\">";
                echo $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "text", array(), "array");
                echo "</option>
\t\t\t\t\t\t";
            }
            // line 21
            echo "\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 22
        echo "\t\t\t\t</select>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\" for=\"input-cate_name\">栏目名称</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<input type=\"text\" name=\"cate_name\" id=\"input-cate_name\" value=\"";
        // line 28
        echo $this->getAttribute((isset($context["cate"]) ? $context["cate"] : $this->getContext($context, "cate")), "cate_name", array(), "array");
        echo "\" style=\"width:200px\">
\t\t\t\t<span class=\"help-inline\"><span class=\"label\">建议10个汉字以内</span></span>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\" for=\"input-description\">栏目描述</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<input type=\"text\" name=\"description\" id=\"input-description\" value=\"";
        // line 35
        echo $this->getAttribute((isset($context["cate"]) ? $context["cate"] : $this->getContext($context, "cate")), "description", array(), "array");
        echo "\" style=\"width:250px\">
\t\t\t\t<span class=\"help-inline\"><span class=\"label\">建议13个汉字以内</span></span>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\" for=\"input-image\">栏目图片</label>
\t\t\t<div class=\"controls\">
\t\t\t\t";
        // line 42
        if ($this->getAttribute((isset($context["cate"]) ? $context["cate"] : $this->getContext($context, "cate")), "image", array(), "array")) {
            // line 43
            echo "\t\t\t\t\t";
            if ((isset($context["is_sys_icon"]) ? $context["is_sys_icon"] : $this->getContext($context, "is_sys_icon"))) {
                // line 44
                echo "\t\t\t\t\t<img src=\"";
                echo $this->getAttribute((isset($context["cate"]) ? $context["cate"] : $this->getContext($context, "cate")), "image", array(), "array");
                echo "\" class=\"img-polaroid\" id=\"image-preview\">
\t\t\t\t\t";
            } else {
                // line 46
                echo "\t\t\t\t\t<img src=\"";
                echo image_url($this->getAttribute((isset($context["cate"]) ? $context["cate"] : $this->getContext($context, "cate")), "image", array(), "array"), 80, 80);
                echo "\" class=\"img-polaroid\" id=\"image-preview\">
\t\t\t\t\t";
            }
            // line 48
            echo "\t\t\t\t";
        } else {
            // line 49
            echo "\t\t\t\t<img src=\"/assets/img/no_image.png\" class=\"img-polaroid\" id=\"image-preview\">
\t\t\t\t";
        }
        // line 51
        echo "                <input type=\"button\" class=\"btn j_img_clear\" value=\"删除\" style=\"margin:0 0 5px 10px;\" />
\t\t\t\t<input type=\"hidden\" name=\"image\" id=\"input-image\" value=\"";
        // line 52
        echo image_url($this->getAttribute((isset($context["cate"]) ? $context["cate"] : $this->getContext($context, "cate")), "image", array(), "array"));
        echo "\">
\t\t\t\t<div id=\"uploader-image\"></div>
\t\t\t\t<a class=\"btn btn-success\" onclick=\"show_icons_sys()\">选择系统图标</a>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group";
        // line 57
        if ($this->getAttribute((isset($context["cate"]) ? $context["cate"] : $this->getContext($context, "cate")), "url", array(), "array")) {
            echo " hide";
        }
        echo "\" id=\"control_show_url\">
\t\t\t<div class=\"controls\">
\t\t\t\t<a href=\"#\" id=\"show_url\"><span class=\"label\"><i class=\"icon-share icon-white\"></i> 指向外部链接</span></a>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group";
        // line 62
        if (twig_test_empty($this->getAttribute((isset($context["cate"]) ? $context["cate"] : $this->getContext($context, "cate")), "url", array(), "array"))) {
            echo " hide";
        }
        echo "\" id=\"control_url\">
\t\t\t<label class=\"control-label\" for=\"input-url\">外部链接</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<input type=\"text\" name=\"url\" id=\"input-url\" value=\"";
        // line 65
        echo $this->getAttribute((isset($context["cate"]) ? $context["cate"] : $this->getContext($context, "cate")), "url", array(), "array");
        echo "\" class=\"span4\" placeholder=\"http://\">
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\" id=\"control_url\">
\t\t\t<label class=\"control-label\" for=\"input-description\">是否在首页显示</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<label for=\"display-yes\" style=\"display:inline-block;\">是</label><input id=\"display-yes\" type=\"radio\" ";
        // line 71
        if (($this->getAttribute((isset($context["cate"]) ? $context["cate"] : $this->getContext($context, "cate")), "display", array(), "array") == 0)) {
            echo "checked=\"checked\"";
        }
        echo " name=\"display\" value=\"0\" />
\t\t\t\t<label for=\"display-no\" style=\"display:inline-block;\">否</label><input id=\"display-no\" type=\"radio\" ";
        // line 72
        if (($this->getAttribute((isset($context["cate"]) ? $context["cate"] : $this->getContext($context, "cate")), "display", array(), "array") == 1)) {
            echo "checked=\"checked\"";
        }
        echo " name=\"display\" value=\"1\" />
\t\t\t</div>
\t\t</div>
        
        <div class=\"control-group\">
\t\t\t<label class=\"control-label\" for=\"input-image\">可查看权限</label>
            <div class=\"controls\">
                <select name=\"level_type\" style=\"width:120px;\" class=\"j_level_type\" >
                <option value=\"0\" ";
        // line 80
        if (("0" == $this->getAttribute((isset($context["cate"]) ? $context["cate"] : $this->getContext($context, "cate")), "level_type", array(), "array"))) {
            echo "selected=\"selected\"";
        }
        echo " >匿名用户</option>
                <option value=\"1\" ";
        // line 81
        if (("1" == $this->getAttribute((isset($context["cate"]) ? $context["cate"] : $this->getContext($context, "cate")), "level_type", array(), "array"))) {
            echo "selected=\"selected\"";
        }
        echo " >关注用户</option>
                ";
        // line 82
        if ((isset($context["level"]) ? $context["level"] : $this->getContext($context, "level"))) {
            echo "<option value=\"2\" ";
            if (("2" == $this->getAttribute((isset($context["cate"]) ? $context["cate"] : $this->getContext($context, "cate")), "level_type", array(), "array"))) {
                echo "selected=\"selected\"";
            }
            echo " >会员卡用户</option>";
        }
        // line 83
        echo "                </select>
        \t</div>
\t\t</div>
        
        <div class=\"control-group j_level\" ";
        // line 87
        if (("2" != $this->getAttribute((isset($context["cate"]) ? $context["cate"] : $this->getContext($context, "cate")), "level_type", array(), "array"))) {
            echo "style=\"display:none;\"";
        }
        echo " >
\t\t\t<label class=\"control-label\" for=\"input-image\">可查看权限</label>
            <div class=\"controls\">
                <select name=\"level\" style=\"width:120px;\" >
                ";
        // line 91
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["level"]) ? $context["level"] : $this->getContext($context, "level")));
        foreach ($context['_seq'] as $context["lev"] => $context["val"]) {
            // line 92
            echo "                <option value=\"";
            echo (isset($context["lev"]) ? $context["lev"] : $this->getContext($context, "lev"));
            echo "\" ";
            if (((isset($context["lev"]) ? $context["lev"] : $this->getContext($context, "lev")) == $this->getAttribute((isset($context["cate"]) ? $context["cate"] : $this->getContext($context, "cate")), "level", array(), "array"))) {
                echo "selected=\"selected\"";
            }
            echo ">";
            echo (isset($context["val"]) ? $context["val"] : $this->getContext($context, "val"));
            echo "</option>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['lev'], $context['val'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 94
        echo "                </select>
        \t</div>
\t\t</div>
        
\t\t<div class=\"control-group\" id=\"control_tpl\">
\t\t\t<label class=\"control-label\" for=\"tpllist\">栏目模版</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<select id=\"tpllist\" name=\"tpl\" autocomplete=\"off\">
\t\t\t\t\t<option value=\"\" ";
        // line 102
        if (twig_test_empty($this->getAttribute((isset($context["cate"]) ? $context["cate"] : $this->getContext($context, "cate")), "tpl", array(), "array"))) {
            echo "selected";
        }
        echo " preview=\"";
        echo (isset($context["preview_path"]) ? $context["preview_path"] : $this->getContext($context, "preview_path"));
        echo "assets/types_pub/cate/";
        echo $this->getAttribute((isset($context["global_tpl"]) ? $context["global_tpl"] : $this->getContext($context, "global_tpl")), "template_id", array(), "array");
        echo "/preview.jpg\">使用全局设置</option>
\t\t\t\t\t";
        // line 103
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["tpl_lists"]) ? $context["tpl_lists"] : $this->getContext($context, "tpl_lists")));
        foreach ($context['_seq'] as $context["_key"] => $context["tpl"]) {
            // line 104
            echo "\t\t\t\t\t<option value=\"";
            echo $this->getAttribute((isset($context["tpl"]) ? $context["tpl"] : $this->getContext($context, "tpl")), "template_id", array(), "array");
            echo "\" ";
            if (($this->getAttribute((isset($context["cate"]) ? $context["cate"] : $this->getContext($context, "cate")), "tpl", array(), "array") == $this->getAttribute((isset($context["tpl"]) ? $context["tpl"] : $this->getContext($context, "tpl")), "template_id", array(), "array"))) {
                echo "selected";
            }
            echo " preview=\"";
            echo (isset($context["preview_path"]) ? $context["preview_path"] : $this->getContext($context, "preview_path"));
            echo "assets/types_pub/cate/";
            echo $this->getAttribute((isset($context["tpl"]) ? $context["tpl"] : $this->getContext($context, "tpl")), "template_id", array(), "array");
            echo "/preview.jpg\">";
            echo $this->getAttribute((isset($context["tpl"]) ? $context["tpl"] : $this->getContext($context, "tpl")), "title", array(), "array");
            echo "</option>
\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tpl'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 106
        echo "\t\t\t\t</select>
\t\t\t</div>
\t\t\t<div class=\"controls\">
\t\t\t\t<img id=\"tpl_preview\" style=\"display: none;margin-top: 12px;\" width=\"220\" src=\"/assets/img/template/list/default.jpg\">
\t\t\t</div>
\t\t</div>
\t\t
\t\t<div class=\"control-group\">
            <label class=\"control-label\" for=\"input-image\">自定义背景图片</label>
            ";
        // line 115
        if ($this->getAttribute((isset($context["cate"]) ? $context["cate"] : $this->getContext($context, "cate")), "background_image", array(), "array")) {
            // line 116
            echo "            <div class=\"controls\">
                <img src=\"";
            // line 117
            echo $this->getAttribute((isset($context["cate"]) ? $context["cate"] : $this->getContext($context, "cate")), "background_image", array(), "array");
            echo "\" style=\"width:80px;height:160px;\" class=\"img-polaroid\" id=\"image-preview-background-image\">
                <input type=\"button\" class=\"btn j_img_clear\" value=\"清空\" style=\"margin:0 0 5px 10px;\" />
                <input type=\"hidden\" name=\"background_image\" id=\"input-image-background-image\" value=\"";
            // line 119
            echo $this->getAttribute((isset($context["cate"]) ? $context["cate"] : $this->getContext($context, "cate")), "background_image", array(), "array");
            echo "\">
                <div id=\"uploader-image-background-image\"></div>
            </div>
            ";
        } else {
            // line 123
            echo "            <div class=\"controls\">
                <img src=\"/assets/img/no_image.png\" style=\"width:80px;height:160px;\" class=\"img-polaroid\" id=\"image-preview-background-image\">
                <input type=\"button\" class=\"btn j_img_clear\" value=\"清空\" style=\"margin:0 0 5px 10px;\" />
                <input type=\"hidden\" name=\"background_image\" id=\"input-image-background-image\">
                <div id=\"uploader-image-background-image\"></div>
            </div>
            ";
        }
        // line 130
        echo "        </div>
\t\t
\t\t<div class=\"control-group\">
\t\t\t<div class=\"controls\">
\t\t\t\t<button type=\"submit\" class=\"btn btn-primary\">确认保存</button>
\t\t\t</div>
\t\t</div>
\t</form>
</div>
";
    }

    // line 141
    public function block_style($context, array $blocks = array())
    {
        // line 142
        echo "<link href=\"/assets/huploadify/Huploadify.css\" rel=\"stylesheet\">
<link href=\"/assets/css/icons_sys.css\" rel=\"stylesheet\">
<style type=\"text/css\">
#image-preview {
\tmargin: 10px 0;
\tbackground-color: #bababa;
}
.uploadify-button{
    color: #333;
    background-color: #fff;
    border-color: #ccc;
    cursor:pointer;
    text-decoration:none;
    border-radius: 2px;
    margin-left: 0;
}
.uploadify-button:hover {
    background-color: #ccc;
    background-image: none;
    background-position: center bottom;
    cursor:pointer;
    text-decoration:none;
}
</style>
";
    }

    // line 168
    public function block_script($context, array $blocks = array())
    {
        // line 169
        echo "<script src=\"/assets/huploadify/jquery.Huploadify.js\"></script>
<script src=\"/assets/js/icons_sys.js\"></script>
<script type=\"text/javascript\">
\$(function() {
\t//清空上传的图片
\t\$(document).on('click','.j_img_clear',function(){
\t\t\$(this).next('input').val('');
\t\t\$(this).prevAll('img').attr('src','/assets/img/no_image.png');
\t});

    \$('#uploader-image').Huploadify({
        'fileObjName': 'image',
        'fileSizeLimit': 2048,
        'fileTypeExts': '*.gif; *.jpg; *.png',
        'multi': false,
        'auto':true,
        'showUploadedPercent':false,
        'removeTimeout': 0,
        'buttonText': '上传图片',
        'formData': {'token': '";
        // line 188
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
        'uploader': '/image/upload',
        'onUploadSuccess': function(file, data) {
            var ret = \$.parseJSON(data);
            if (ret) {
                if (ret.success) {
                    \$('#input-image').val(ret.image);
                    \$('#image-preview').attr('src', ret.image_preview);
                } else {
                    alert(ret.message);
                }
            }
        }
    });

    \$('#uploader-image-background-image').Huploadify({
        'fileObjName': 'image',
        'fileSizeLimit': 2048,
        'fileTypeExts': '*.gif; *.jpg; *.png',
        'multi': false,
        'auto':true,
        'showUploadedPercent':false,
        'removeTimeout': 0,
        'buttonText': '上传图片',
        'formData': {'token': '";
        // line 212
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
        'uploader': '/image/upload',
        'onUploadSuccess': function(file, data) {
            var ret = \$.parseJSON(data);
            if (ret) {
                if (ret.success) {
                    \$('#input-image-background-image').val(ret.image);
                    \$('#image-preview-background-image').attr('src', ret.image_preview);
                } else {
                    alert(ret.message);
                }
            }
        }
    });
\t
\t\$('.j_level_type').on('change',function(){
\t\tvar level_type = \$(this).val();
\t\tif(level_type==2){
\t\t\t\$('.j_level').show();
\t\t}else{
\t\t\t\$('.j_level').hide();\t
\t\t}\t
\t});
\t
\t\$('#show_url').click(function() {
\t\t\$('#control_url').removeClass('hide');
\t\t\$('#control_show_url').addClass('hide');
\t\treturn false;
\t});\t
});

function show_icons_sys(){
\twindow.SysIconDialog.showDialog(function (id, url, type_id) {//id=图标id，也许需要   url=图标路径  type_id=所在分组id
\t\t\$('#input-image').val(url);
\t\t\$('#image-preview').attr('src', url);
\t});
}

(function (window, \$, undefined) {
\tvar \$selected = \$('#tpllist').change(function (a, b) {
\t\t\$('#tpl_preview').attr('src', \$(this).find('option:selected').attr('preview'));
\t}).find('option:selected');
\tvar \$tpl_preview = \$('#tpl_preview').attr('src',\$selected.attr('preview')).fadeIn ();
})(window, jQuery, undefined);
</script>
";
    }

    public function getTemplateName()
    {
        return "cate/update.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  413 => 212,  386 => 188,  365 => 169,  362 => 168,  334 => 142,  331 => 141,  318 => 130,  309 => 123,  302 => 119,  297 => 117,  294 => 116,  292 => 115,  281 => 106,  262 => 104,  258 => 103,  248 => 102,  238 => 94,  223 => 92,  219 => 91,  210 => 87,  204 => 83,  196 => 82,  190 => 81,  184 => 80,  171 => 72,  165 => 71,  156 => 65,  148 => 62,  138 => 57,  130 => 52,  127 => 51,  123 => 49,  120 => 48,  114 => 46,  108 => 44,  105 => 43,  103 => 42,  93 => 35,  83 => 28,  75 => 22,  69 => 21,  61 => 19,  53 => 17,  50 => 16,  46 => 15,  33 => 4,  30 => 3,);
    }
}
