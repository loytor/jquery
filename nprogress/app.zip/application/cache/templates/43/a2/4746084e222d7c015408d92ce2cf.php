<?php

/* game/index.html */
class __TwigTemplate_43a24746084e222d7c015408d92ce2cf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "
<form action=\"\" method=\"post\">
<table class=\"table table-hover table-bordered\">
\t<thead>
\t\t<tr>
\t\t\t<th colspan=\"8\" style=\" font-size:15px;\">
\t\t\t\t";
        // line 10
        echo (isset($context["curtitle"]) ? $context["curtitle"] : $this->getContext($context, "curtitle"));
        echo "
\t\t\t\t<a class=\"btn btn-primary pull-right\" href=\"/game/add/?type=";
        // line 11
        echo (isset($context["type"]) ? $context["type"] : $this->getContext($context, "type"));
        echo "\"><i class=\"icon-plus icon-white\"></i> 添加</a>
\t\t\t</th>

\t\t</tr>
\t\t<tr style=\"background-color:#EEEEEE;\">
\t\t\t<th style=\"width: 300px;\">游戏标题</th>
\t\t\t<th style=\"width: 300px;\">游戏链接</th>
\t\t\t<th>归档栏目</th>
\t\t\t<th>开始时间</th>
\t\t\t<th>结束时间</th>
\t\t\t<th>浏览次数</th>
\t\t\t<th>参与人数</th>
\t\t\t<th></th>
\t\t</tr>
\t</thead>
\t<tbody>
\t<!--
\t\t<tr>
\t\t\t<td>筛选</td>
\t\t\t<td><input name=\"mobile\" class=\"input-small\" type=\"text\" style=\"margin-bottom: 0;\" value=\"\"></td>
\t\t\t<td></td>
\t\t\t<td></td>
\t\t\t<td></td>
\t\t\t<td></td>
\t\t\t<td></td>
\t\t\t<td><button class=\"btn btn-primary\" type=\"submit\">查找</button></td>
\t\t</tr>
\t\t-->
\t\t";
        // line 39
        if ((!twig_test_empty((isset($context["gamelist"]) ? $context["gamelist"] : $this->getContext($context, "gamelist"))))) {
            // line 40
            echo "\t\t";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["gamelist"]) ? $context["gamelist"] : $this->getContext($context, "gamelist")));
            foreach ($context['_seq'] as $context["key"] => $context["_list"]) {
                // line 41
                echo "\t\t<tr>
\t\t\t<td>";
                // line 42
                echo $this->getAttribute((isset($context["_list"]) ? $context["_list"] : $this->getContext($context, "_list")), "title", array(), "array");
                echo $this->getAttribute((isset($context["_list"]) ? $context["_list"] : $this->getContext($context, "_list")), "status", array(), "array");
                echo "</td>
\t\t\t<td>";
                // line 43
                echo (isset($context["viewurl"]) ? $context["viewurl"] : $this->getContext($context, "viewurl"));
                echo "game/?id=";
                echo $this->getAttribute((isset($context["_list"]) ? $context["_list"] : $this->getContext($context, "_list")), "id", array(), "array");
                echo "</td>
\t\t\t";
                // line 44
                if (((!twig_test_empty($this->getAttribute((isset($context["_list"]) ? $context["_list"] : $this->getContext($context, "_list")), "cate_id", array(), "array"))) && $this->getAttribute($this->getAttribute((isset($context["catelist"]) ? $context["catelist"] : null), $this->getAttribute((isset($context["_list"]) ? $context["_list"] : $this->getContext($context, "_list")), "cate_id", array(), "array"), array(), "array", false, true), "cate_name", array(), "array", true, true))) {
                    // line 45
                    echo "\t\t\t<td>";
                    echo $this->getAttribute($this->getAttribute((isset($context["catelist"]) ? $context["catelist"] : $this->getContext($context, "catelist")), $this->getAttribute((isset($context["_list"]) ? $context["_list"] : $this->getContext($context, "_list")), "cate_id", array(), "array"), array(), "array"), "cate_name", array(), "array");
                    echo "</td>
\t\t\t";
                } else {
                    // line 47
                    echo "\t\t\t<td>未绑定</td>
\t\t\t";
                }
                // line 49
                echo "\t\t\t<td>";
                echo twig_date_format_filter($this->env, $this->getAttribute((isset($context["_list"]) ? $context["_list"] : $this->getContext($context, "_list")), "start_time", array(), "array"), "Y-m-d H:i");
                echo "</td>
\t\t\t<td>";
                // line 50
                echo twig_date_format_filter($this->env, $this->getAttribute((isset($context["_list"]) ? $context["_list"] : $this->getContext($context, "_list")), "end_time", array(), "array"), "Y-m-d H:i");
                echo "</td>
\t\t\t<td>";
                // line 51
                echo $this->getAttribute((isset($context["_list"]) ? $context["_list"] : $this->getContext($context, "_list")), "views", array(), "array");
                echo "</td>
\t\t\t<td>";
                // line 52
                echo $this->getAttribute((isset($context["_list"]) ? $context["_list"] : $this->getContext($context, "_list")), "joins", array(), "array");
                echo "</td>
\t\t\t<td>
\t\t\t\t<a class=\"btn btn-small\" href=\"/game/edit/?type=";
                // line 54
                echo $this->getAttribute((isset($context["_list"]) ? $context["_list"] : $this->getContext($context, "_list")), "type", array(), "array");
                echo "&id=";
                echo $this->getAttribute((isset($context["_list"]) ? $context["_list"] : $this->getContext($context, "_list")), "id", array(), "array");
                echo "\"><i class=\"icon-edit\"></i> 编辑</a>
\t\t\t\t<a class=\"btn btn-small\" href=\"/game/slate/?type=";
                // line 55
                echo $this->getAttribute((isset($context["_list"]) ? $context["_list"] : $this->getContext($context, "_list")), "type", array(), "array");
                echo "&id=";
                echo $this->getAttribute((isset($context["_list"]) ? $context["_list"] : $this->getContext($context, "_list")), "id", array(), "array");
                echo "\"><i class=\"icon-edit\"></i> 内定</a>
\t\t\t\t<a class=\"btn btn-small\" href=\"/game/record/?type=";
                // line 56
                echo $this->getAttribute((isset($context["_list"]) ? $context["_list"] : $this->getContext($context, "_list")), "type", array(), "array");
                echo "&id=";
                echo $this->getAttribute((isset($context["_list"]) ? $context["_list"] : $this->getContext($context, "_list")), "id", array(), "array");
                echo "\"><i class=\"icon-eye-open\"></i> 统计</a>
\t\t\t\t<a class=\"btn btn-small btn-delete\" data-id=\"";
                // line 57
                echo $this->getAttribute((isset($context["_list"]) ? $context["_list"] : $this->getContext($context, "_list")), "id", array(), "array");
                echo "\"><i class=\"icon-trash\"></i> 删除</a>
\t\t\t</td>
\t\t</tr>
\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key'], $context['_list'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 61
            echo "\t\t";
        } else {
            // line 62
            echo "\t\t<tr><td colspan=\"8\" style=\"text-align: center;\">您还没有创建游戏</td></tr>
\t\t";
        }
        // line 64
        echo "\t</tbody>
</table>
</form>

";
        // line 68
        echo (isset($context["pages"]) ? $context["pages"] : $this->getContext($context, "pages"));
        echo "
";
    }

    // line 71
    public function block_script($context, array $blocks = array())
    {
        // line 72
        echo "<script src=\"/assets/js/lhgcalendar.min.js\"></script>
<script type=\"text/javascript\">
\t\$(function() {
\t\t\$('#from-time').calendar({format:'yyyy-MM-dd HH:mm:ss' });
\t\t\$('#to-time').calendar({ format:'yyyy-MM-dd HH:mm:ss',minDate:'#from-time' });

\t\t//删除提示
\t\t\$('.btn-delete').bind('click',function(){
\t\t\tif(confirm(\"确定要删除该游戏吗？\")){
\t\t\t\tvar id = \$(this).attr('data-id');
\t\t\t\twindow.location.href = '/game/delete/?id='+id;
\t\t\t}
\t\t});
\t});
</script>
";
    }

    public function getTemplateName()
    {
        return "game/index.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  176 => 72,  173 => 71,  167 => 68,  161 => 64,  157 => 62,  154 => 61,  144 => 57,  138 => 56,  132 => 55,  126 => 54,  121 => 52,  117 => 51,  113 => 50,  108 => 49,  104 => 47,  98 => 45,  96 => 44,  90 => 43,  85 => 42,  82 => 41,  77 => 40,  75 => 39,  44 => 11,  40 => 10,  32 => 4,  29 => 3,);
    }
}
