<?php

/* tpl/customRes.html */
class __TwigTemplate_43771c2764fa8708ac002e4e28112851 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'style' => array($this, 'block_style'),
            'script' => array($this, 'block_script'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_style($context, array $blocks = array())
    {
        // line 4
        echo "<link href=\"/assets/css/uploadify.css\" rel=\"stylesheet\">
";
    }

    // line 6
    public function block_script($context, array $blocks = array())
    {
        // line 7
        echo "
<script src=\"/assets/js/jquery.uploadify.min.js\"></script>
<script type=\"text/javascript\">
\$(function(){
\t\$('#uploader-image').uploadify({
\t\t'fileObjName': 'image',
\t\t'fileSizeLimit': '2MB',
\t\t'fileTypeExts': '*.gif; *.jpg; *.png',
\t\t'multi': false,
\t\t'removeTimeout': 0,
\t\t'width': 90,
\t\t'height': 25,
\t\t'buttonText': '上传图片',
\t\t'formData': {'token': '";
        // line 20
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
\t\t'swf': '/assets/js/uploadify.swf',
\t\t'uploader': '/image/upload_res',
\t\t'onFallback': function() {
\t\t\talert('您的浏览器没有安装Flash插件');
\t\t},
\t\t'onUploadSuccess': function(file, data, response) {
\t\t\tif (response) {
\t\t\t\tvar ret = \$.parseJSON(data);
\t\t\t\tif (ret) {
\t\t\t\t\tif (ret.success) {
\t\t\t\t\t\t\$('#input-image').val(ret.image);
\t\t\t\t\t\t\$('#image-preview').attr('src', ret.image);
\t\t\t\t\t} else {
\t\t\t\t\t\talert(ret.message);
\t\t\t\t\t}
\t\t\t\t}
\t\t\t}
\t\t}
\t});

\t\$('.btn-delete').click(function(){
\t\tif(confirm(\"是否确定删除该资源？\")){
\t\t\tvar res_id = \$(this).attr('data-id');
\t\t\twindow.location.href = '/custom_res/delete/'+res_id;
\t\t}
\t});
})
</script>
";
    }

    // line 50
    public function block_main($context, array $blocks = array())
    {
        // line 51
        echo "<ul class=\"breadcrumb clearfix\">
\t<li><a href=\"/tpl\">模版选择</a> <span class=\"divider\">/</span></li>
\t<li class=\"active\">模版资源</li>

    <li class=\"pull-right\">

        <a href=\"javascript:history.go(-1)\" class=\"btn\"><i class=\"icon-arrow-left\"></i> 返回</a>
    </li>
</ul>
<form class=\"form-horizontal\" action=\"/custom_res/save\" method=\"post\">
\t<div class=\"control-group\">
\t\t<label class=\"control-label\" for=\"input-image\">资源图片</label>
\t\t<div class=\"controls\">
\t\t\t<img src=\"/assets/img/no_image.png\" class=\"img-polaroid\" id=\"image-preview\">
            <input type=\"button\" class=\"btn j_img_clear\" value=\"删除\" style=\"margin:0 0 5px 10px;\" />
\t\t\t<input type=\"hidden\" name=\"res\" id=\"input-image\">
\t\t\t<input type=\"file\" id=\"uploader-image\">
\t\t</div>
\t</div>
\t<div class=\"control-group\">
\t\t<div class=\"controls\">
\t\t\t<button id=\"save-btn\" type=\"submit\" class=\"btn btn-primary\">确认保存</button>
\t\t</div>
\t</div>
</form>
";
        // line 76
        if ((!twig_test_empty((isset($context["res_arr"]) ? $context["res_arr"] : $this->getContext($context, "res_arr"))))) {
            // line 77
            echo "<table class=\"table table-striped\">
\t<thead>
\t<tr>
\t\t<th>#</th>
\t\t<th>图片</th>
\t\t<th>资源路径</th>
\t\t<th>操作</th>
\t</tr>
\t</thead>
\t<tbody>
\t";
            // line 87
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["res_arr"]) ? $context["res_arr"] : $this->getContext($context, "res_arr")));
            foreach ($context['_seq'] as $context["key"] => $context["_res"]) {
                // line 88
                echo "\t<tr>
\t\t<td>";
                // line 89
                echo (((((isset($context["page"]) ? $context["page"] : $this->getContext($context, "page")) - 1) * (isset($context["page_size"]) ? $context["page_size"] : $this->getContext($context, "page_size"))) + (isset($context["key"]) ? $context["key"] : $this->getContext($context, "key"))) + 1);
                echo "</td>
\t\t<td><img style=\"width:100px;\" src=\"";
                // line 90
                echo $this->getAttribute((isset($context["_res"]) ? $context["_res"] : $this->getContext($context, "_res")), "res", array(), "array");
                echo "\"></td>
\t\t<td>";
                // line 91
                echo $this->getAttribute((isset($context["_res"]) ? $context["_res"] : $this->getContext($context, "_res")), "res", array(), "array");
                echo "</td>
\t\t<td>
\t\t\t<a class=\"btn btn-small btn-delete\" data-id=\"";
                // line 93
                echo $this->getAttribute((isset($context["_res"]) ? $context["_res"] : $this->getContext($context, "_res")), "id", array(), "array");
                echo "\"><i class=\"icon-trash\"></i> 删除</a>
\t\t</td>
\t</tr>
\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key'], $context['_res'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 97
            echo "\t</tbody>
</table>
";
            // line 99
            echo (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination"));
            echo "
";
        } else {
            // line 101
            echo "<div class=\"well well-large\"><h3><img src=\"/assets/img/no_content.png\"> 没有资源 ......</h3></div>
";
        }
    }

    public function getTemplateName()
    {
        return "tpl/customRes.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  173 => 101,  168 => 99,  164 => 97,  154 => 93,  149 => 91,  145 => 90,  141 => 89,  138 => 88,  134 => 87,  122 => 77,  120 => 76,  93 => 51,  90 => 50,  56 => 20,  41 => 7,  38 => 6,  33 => 4,  30 => 3,);
    }
}
