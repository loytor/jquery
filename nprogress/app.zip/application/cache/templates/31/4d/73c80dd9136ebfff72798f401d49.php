<?php

/* game/default/add.html */
class __TwigTemplate_314d73c80dd9136ebfff72798f401d49 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'style' => array($this, 'block_style'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "
<ul class=\"clearfix activity-instruction\">
\t";
        // line 6
        echo $this->getAttribute((isset($context["game_type"]) ? $context["game_type"] : $this->getContext($context, "game_type")), "title", array(), "array");
        echo "是一种系统随机抽奖活动，发起人可以自定义中奖几率（可随时修改），控制每位参与者中奖机会，但发起人不可以自行人工抽奖，发起人可在中途结束活动
</ul>
<div class=\"well\">
\t<p style=\"text-align:left;\">
\t\t<span style=\"font-family:微软雅黑;font-size:18px;font-weight:bold;font-style:normal;text-decoration:none;color:#333333;\">活动信息：</span>
\t</p>

\t<form class=\"form-horizontal\" action=\"\" method=\"post\">
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\" for=\"select-cate_id\">所属网站栏目</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<select name=\"cate_id\" id=\"select-cate_id\" class=\"span2\">
\t\t\t\t\t<option value=\"\">未归档</option>
\t\t\t\t\t";
        // line 19
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["cate_arr"]) ? $context["cate_arr"] : $this->getContext($context, "cate_arr")));
        foreach ($context['_seq'] as $context["_cate_id"] => $context["_cate"]) {
            // line 20
            echo "\t\t\t\t\t<option value=\"";
            echo (isset($context["_cate_id"]) ? $context["_cate_id"] : $this->getContext($context, "_cate_id"));
            echo "\">";
            echo $this->getAttribute((isset($context["_cate"]) ? $context["_cate"] : $this->getContext($context, "_cate")), "cate_name", array(), "array");
            echo "</option>
\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_cate_id'], $context['_cate'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 22
        echo "\t\t\t\t</select>
\t\t\t</div>
\t\t</div>

\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\" for=\"input-title\">活动标题</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<input type=\"text\" name=\"title\" id=\"input-title\" class=\"span4\" />
\t\t\t\t<span class=\"help-inline\"><span class=\"label\">建议10个汉字以内</span></span>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\" for=\"input-desc\">活动描述</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<input type=\"text\" name=\"desc\" id=\"input-desc\" class=\"span4\" />
\t\t\t\t<span class=\"help-inline\"><span class=\"label\">建议13个汉字以内</span></span>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\" for=\"input-content\">活动说明</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<textarea class=\"span4\" id=\"input-content\" name=\"content\"></textarea>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">活动时间</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<input type=\"text\" name=\"start_time\" placeholder=\"点击选择开始时间\" value=\"\" id=\"statdate\" />
\t\t\t\t到
\t\t\t\t<input type=\"text\" name=\"end_time\" placeholder=\"点击选择结束时间\" value=\"\" id=\"enddate\" />
\t\t\t</div>
\t\t</div>
\t\t<p style=\"text-align:left;\">
\t\t\t<span style=\"font-family:微软雅黑;font-size:18px;font-weight:bold;font-style:normal;text-decoration:none;color:#333333;\">奖项规则设置：</span>
\t\t\t<span class=\"reward-font\" style=\"color: red;\">（最多可添加 ";
        // line 56
        echo $this->getAttribute((isset($context["game_type"]) ? $context["game_type"] : $this->getContext($context, "game_type")), "prizenum", array(), "array");
        echo " 项奖品）</span>
\t\t</p>
\t\t<div id=\"reward-settings\">
\t\t\t<div class=\"control-group reward-item\" style=\"margin-bottom: 0\">
\t\t\t\t<label class=\"control-label\">
\t\t\t\t\t<span>奖品设置：</span>
\t\t\t\t</label>
\t\t\t\t<span class=\"reward-font reward-name\">奖项一：</span>
\t\t\t\t<input type=\"text\" name=\"prize[0][name]\" placeholder=\"如 几等奖：奖品名称\" value=\"\" style=\"width:150px;\" />
\t\t\t\t<span class=\"reward-font\">中奖率：</span>
\t\t\t\t<input type=\"text\" name=\"prize[0][rate]\" value=\"0.1\" style=\"width:30px;\" />
\t\t\t\t<span class=\"reward-font\">%</span>
\t\t\t\t<span class=\"reward-font\">奖品数量：</span>
\t\t\t\t<input type=\"text\" name=\"prize[0][number]\" value=\"1\" style=\"width:30px;\" />
\t\t\t\t<span style=\"font-family:微软雅黑;font-size:14px;font-weight:bold;font-style:normal;text-decoration:none;color:#333333;\">真实奖品数：</span>
\t\t\t\t<input type=\"text\" name=\"prize[0][true_number]\" value=\"\" style=\"width:30px;\" />
\t\t\t\t<input type=\"hidden\" name=\"prize[0][pic]\" id=\"image-prize-hidden0\" value=\"\">
\t\t\t\t<img src=\"\" class=\"img-polaroid\" id=\"image-preview0\" width=\"32\" style=\"display: none;\" />
\t\t\t\t<div class=\"uploadBox\" data-id=\"0\" style=\"margin-left: 220px;\">
                    <div id=\"upload-prize-image0\" class=\"upload-prize-image\"></div>
                </div>
\t\t\t</div>
\t\t\t
\t\t</div>
\t\t<div class=\"control-group\" id='add-reward-div'>
\t\t\t<label class=\"control-label\">
\t\t\t</label>
\t\t\t<a id=\"add-reward\" href=\"javascript:void(0);\">添加奖项</a>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">
\t\t\t\t<span style=\"font-family:微软雅黑;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#333333;\">规则设置：</span>
\t\t\t</label>
\t\t\t1.
\t\t\t<input type=\"radio\" id=\"radio1\" checked=\"true\" name=\"rule\" value=\"1\" />
\t\t\t<label style=\"display: inline;\" for=\"radio1\">活动期间每个用户ID限参与
\t\t\t\t<input type=\"text\" name=\"rules[1][number]\" value=\"1\" style=\"width:30px;\" />
\t\t\t\t次</label>
\t\t\t&nbsp;&nbsp;
\t\t\t<input type=\"radio\" id=\"radio2\" name=\"rule\" value=\"2\" />
\t\t\t<label style=\"display: inline;\" for=\"radio2\">活动期间每个用户ID，每
\t\t\t\t<input type=\"text\" name=\"rules[2][day]\" value=\"\" style=\"width:30px;\" />
\t\t\t\t天限参与
\t\t\t\t<input type=\"text\" name=\"rules[2][number]\" value=\"\" style=\"width:30px;\" />次</label>
\t\t\t<br/><br/>
\t\t\t<label class=\"control-label\">
\t\t\t\t<span class=\"reward-font\"></span>
\t\t\t</label>
\t\t\t2.活动期间每个用户最多可中奖
\t\t\t<input type=\"text\" name=\"lotterynum\" value=\"0\" style=\"width:30px;\" />
\t\t\t次<span class=\"red\"> （0表示无限制）</span>
\t\t\t<br/><br/>
\t\t\t<label class=\"control-label\">
\t\t\t\t<span class=\"reward-font\"></span>
\t\t\t</label>
\t\t\t3.同一奖品在
\t\t\t<input type=\"text\" name=\"frozentime\" value=\"1\" style=\"width:30px;\" />
\t\t\t分钟内禁止抽出<span class=\"red\"> （0表示无限制。例如设置成1分钟，则表示同一个奖品在1分钟内最多被抽中一次）</span>
\t\t</div>
\t\t<p style=\"text-align:left;\">
\t\t\t<span style=\"font-family:微软雅黑;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000FF;\"><a id=\"toggle-settings\" style=\"cursor:pointer;text-decoration: none;\">收起高级设置 ↑</a></span>
\t\t</p>
\t\t<div id=\"advanced-settings\">
\t\t\t<div class=\"control-group\">
\t\t\t\t<label class=\"control-label\" style=\"width: 95px;\">
\t\t\t\t\t<span style=\"font-family:微软雅黑;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#333333;\"></span>
\t\t\t\t</label>
\t\t\t\t<input type=\"checkbox\" checked value=\"1\" name=\"displaywinner\" />
\t\t\t\t<span>在活动页面显示中奖名单&nbsp;</span>
\t\t\t\t
\t\t\t\t<input type=\"checkbox\" checked value=\"1\" name=\"showprizenum\" />
\t\t\t\t<span>在活动页面显示奖品数量&nbsp;</span>

                <input type=\"checkbox\" checked value=\"1\" name=\"address_must\" />
                <span>中奖后联系地址必填&nbsp;</span>

\t\t\t</div>
\t\t\t<div class=\"control-group\">
\t\t\t\t<label class=\"control-label\" for=\"input-start-image\">活动开始封面图片</label>
\t\t\t\t<div class=\"controls\">
\t\t\t\t\t<span class=\"help-block\"><span class=\"label\">建议图片尺寸320 : 160</span></span>
\t\t\t\t\t<img src=\"";
        // line 137
        echo $this->getAttribute((isset($context["cover_img"]) ? $context["cover_img"] : $this->getContext($context, "cover_img")), "image_start", array(), "array");
        echo "\" class=\"img-polaroid\" id=\"image-start-preview\" />
\t\t\t\t\t<span class=\"help-inline\"><a href=\"#guide_1\" data-toggle=\"modal\"><span class=\"badge badge-success\"><i class=\"icon-question-sign icon-white\"></i></span></a></span>
\t\t\t\t\t<input type=\"hidden\" name=\"image_start\" id=\"input-start-image\" value=\"";
        // line 139
        echo $this->getAttribute((isset($context["cover_img"]) ? $context["cover_img"] : $this->getContext($context, "cover_img")), "image_start", array(), "array");
        echo "\" />
\t\t\t\t\t<div id=\"uploader-start-image\"></div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div class=\"control-group\">
\t\t\t\t<label class=\"control-label\" for=\"input-end-image\">活动结束封面图片</label>
\t\t\t\t<div class=\"controls\">
\t\t\t\t\t<span class=\"help-block\"><span class=\"label\">建议图片尺寸320 : 160</span></span>
\t\t\t\t\t<img src=\"";
        // line 147
        echo $this->getAttribute((isset($context["cover_img"]) ? $context["cover_img"] : $this->getContext($context, "cover_img")), "image_end", array(), "array");
        echo "\" class=\"img-polaroid\" id=\"image-end-preview\" />
\t\t\t\t\t<span class=\"help-inline\"><a href=\"#guide_1\" data-toggle=\"modal\"><span class=\"badge badge-success\"><i class=\"icon-question-sign icon-white\"></i></span></a></span>
\t\t\t\t\t<input type=\"hidden\" name=\"image_end\" id=\"input-end-image\" value=\"";
        // line 149
        echo $this->getAttribute((isset($context["cover_img"]) ? $context["cover_img"] : $this->getContext($context, "cover_img")), "image_end", array(), "array");
        echo "\" />
\t\t\t\t\t<div id=\"uploader-end-image\"></div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div class=\"control-group\">
\t\t\t\t<label class=\"control-label\">
\t\t\t\t\t<span style=\"font-family:微软雅黑;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#333333;\">中奖提示：</span>
\t\t\t\t</label>
\t\t\t\t<input type=\"text\" name=\"wintips\" class=\"span4\"  value=\"";
        // line 157
        echo $this->getAttribute((isset($context["tips"]) ? $context["tips"] : $this->getContext($context, "tips")), "wintips", array(), "array");
        echo "\" />
\t\t\t</div>
\t\t\t<div class=\"control-group\">
\t\t\t\t<label class=\"control-label\">
\t\t\t\t\t<span style=\"font-family:微软雅黑;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#333333;\">未中奖提示：</span>
\t\t\t\t</label>
\t\t\t\t<input type=\"text\" name=\"failtips\" class=\"span4\"  value=\"";
        // line 163
        echo $this->getAttribute((isset($context["tips"]) ? $context["tips"] : $this->getContext($context, "tips")), "failtips", array(), "array");
        echo "\" />
\t\t\t</div>
\t\t\t<div class=\"control-group\">
\t\t\t\t<label class=\"control-label\">
\t\t\t\t\t<span style=\"font-family:微软雅黑;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#333333;\">活动结束公告：</span>
\t\t\t\t</label>
\t\t\t\t<input type=\"text\" class=\"span4\" name=\"endtitle\" value=\"";
        // line 169
        echo $this->getAttribute((isset($context["tips"]) ? $context["tips"] : $this->getContext($context, "tips")), "endtitle", array(), "array");
        echo "\"  style=\"height: 65px;\" />
\t\t\t</div>
\t\t\t<div class=\"control-group\">
\t\t\t\t<label class=\"control-label\">
\t\t\t\t\t<span style=\"font-family:微软雅黑;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#333333;\">现场验证：</span>
\t\t\t\t</label>
\t\t\t\t<div style=\"float:left;\">
\t\t\t\t\t<span> 开启现场验证功能</span> <span class=\"red\">（不填表示不开启! 本功能适合现场活动，可以让工作人员在现场给用户验证中奖结果，并现场发奖.）</span>
\t\t\t\t\t<br><br>
\t\t\t\t\t<span>现场验证密码：</span><input type=\"text\" value=\"\" name=\"validatecode\">
\t\t\t\t\t<span class=\"label\">请输入英文或者数字，最多10个字</span>
\t\t\t\t</div>
\t\t\t</div>

\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<div class=\"controls\">
\t\t\t\t<button type=\"submit\" class=\"btn btn-primary\">确认保存</button>
\t\t\t</div>
\t\t</div>
\t\t<input type=\"hidden\" name=\"type\" value=\"1\" />
\t</form>
</div>

<div id=\"guide_1\" class=\"modal hide fade\" tabindex=\"-1\">
\t<div class=\"modal-body\">
\t\t<img src=\"/assets/img/guide_1.jpg\" />
\t</div>
\t<div class=\"modal-footer\">
\t\t<button class=\"btn\" data-dismiss=\"modal\" aria-hidden=\"true\">关闭</button>
\t</div>
</div>

";
    }

    // line 204
    public function block_style($context, array $blocks = array())
    {
        // line 205
        echo "<link href=\"/assets/huploadify/Huploadify.css\" rel=\"stylesheet\">
<style type=\"text/css\" >
    .tips{color:#999; margin-left:20px;}
    .uploadify-button{
        color: #333;
        background-color: #fff;
        border-color: #ccc;
        cursor:pointer;
        text-decoration:none;
        border-radius: 2px;
        margin-left: 0;
    }
    .uploadify-button:hover {
        background-color: #ccc;
        background-image: none;
        background-position: center bottom;
        cursor:pointer;
        text-decoration:none;
    }
    .reward-font{
        font-family:\"微软雅黑\";
        font-size:14px;
        font-weight:bold;
        font-style:normal;
        text-decoration:none;
        color:#333333;
    }
</style>
";
    }

    // line 234
    public function block_script($context, array $blocks = array())
    {
        // line 235
        echo "<script src=\"/assets/js/kindeditor/kindeditor-all-min.js\"></script>
<script src=\"/assets/js/kindeditor/lang/zh_CN.js\"></script>
<script src=\"/assets/js/lhgcalendar.min.js\"></script>
<script src=\"/assets/huploadify/jquery.Huploadify.js\"></script>
<script type=\"text/javascript\">
\tvar editor;
\tKindEditor.ready(function(K) {
\t\teditor = K.create('textarea', {
\t\t\tresizeType: 1,
\t\t\tpasteType: 1,
\t\t\tminWidth:490,
\t\t\tcssPath: '/assets/css/bootstrap.min.css',
\t\t\titems: ['undo', 'redo', '|', 'forecolor', 'hilitecolor', 'bold', 'italic', 'underline','strikethrough', 'removeformat', '|', 'justifyleft', 'justifycenter', 'justifyright', 'hr', '|', 'emoticons'],
\t\t\tuploadJson: '/image/upload_for_editor',
\t\t\textraFileUploadParams: {'token': '";
        // line 249
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
\t\t\tfilePostName: 'image',
\t\t\tformatUploadUrl: false
\t\t});
\t});

    function hupload(obj)
    {
        \$(obj).Huploadify({
            'fileObjName': 'image',
            'fileSizeLimit': 2048,
            'fileTypeExts': '*.gif; *.jpg; *.png',
            'multi': false,
            'auto':true,
            'showUploadedPercent':false,
            'removeTimeout': 0,
            'buttonText': '选择图片',
            'formData': {'token': '";
        // line 266
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
            'uploader': '/image/upload_gd_prize',
            'onUploadSuccess': function(file, data) {
                var id = \$(obj).parents('.uploadBox').attr('data-id');
                var ret = \$.parseJSON(data);
                if (ret) {
                    if (ret.success) {
                        \$('#image-preview'+id).attr('src',ret.imagePreview).show();
                        \$('#image-prize-hidden'+id).val(ret.image);
                    } else {
                        alert(ret.message);
                    }
                }
            }
        });
    }

\t\$(function() {
\t\t\$('#statdate').calendar({format:'yyyy-MM-dd HH:mm:ss' });
\t\t\$('#enddate').calendar({ format:'yyyy-MM-dd HH:mm:ss',minDate:'#statdate' });

\t\t\$('#uploader-start-image').Huploadify({
            'fileObjName': 'image',
            'fileSizeLimit': 2048,
            'fileTypeExts': '*.gif; *.jpg; *.png',
            'multi': false,
            'auto':true,
            'showUploadedPercent':false,
            'removeTimeout': 0,
\t\t\t'buttonText': '选择图片',
\t\t\t'formData': {'token': '";
        // line 296
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
\t\t\t'uploader': '/image/upload',
\t\t\t'onUploadSuccess': function(file, data) {
                var ret = \$.parseJSON(data);
                if (ret) {
                    if (ret.success) {
                        \$('#input-start-image').val(ret.image);
                        \$('#image-start-preview').attr('src', ret.image_middle);
                    } else {
                        alert(ret.message);
                    }
                }
\t\t\t}
\t\t});

\t\t\$('#uploader-end-image').Huploadify({
            'fileObjName': 'image',
            'fileSizeLimit': 2048,
            'fileTypeExts': '*.gif; *.jpg; *.png',
            'multi': false,
            'auto':true,
            'showUploadedPercent':false,
            'removeTimeout': 0,
\t\t\t'buttonText': '选择图片',
\t\t\t'formData': {'token': '";
        // line 320
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
\t\t\t'uploader': '/image/upload',
\t\t\t'onUploadSuccess': function(file, data) {
                var ret = \$.parseJSON(data);
                if (ret) {
                    if (ret.success) {
                        \$('#input-end-image').val(ret.image);
                        \$('#image-end-preview').attr('src', ret.image_middle);
                    } else {
                        alert(ret.message);
                    }
                }
\t\t\t}
\t\t});
        hupload('#upload-prize-image0');

\t\t\$('#toggle-settings').click(function(){
\t\t\t\$('#advanced-settings').slideToggle('fast', function(){
\t\t\t\tif(\$(this).css('display') == 'none') {
\t\t\t\t\t\$('#toggle-settings').text('展开高级设置  ↓');
\t\t\t\t}else{
\t\t\t\t\t\$('#toggle-settings').text('收起高级设置 ↑');
\t\t\t\t}
\t\t\t});
\t\t});

\t\tvar rewards = new Array();
\t\trewards[2] = \"奖项二\";
\t\trewards[3] = \"奖项三\";
\t\trewards[4] = \"奖项四\";
\t\trewards[5] = \"奖项五\";
\t\trewards[6] = \"奖项六\";
\t\trewards[7] = \"奖项七\";
\t\trewards[8] = \"奖项八\";
\t\trewards[9] = \"奖项九\";
\t\trewards[10] = \"奖项十\";

\t\tvar prizeNum = ";
        // line 357
        echo $this->getAttribute((isset($context["game_type"]) ? $context["game_type"] : $this->getContext($context, "game_type")), "prizenum", array(), "array");
        echo ";

\t\t\$('#add-reward-div').on('click', 'a#add-reward', function(){
\t\t\tvar count = \$('#reward-settings').children().length;
\t\t\tvar key = count + 1;
\t\t\tvar reward_name = rewards[key];
\t\t\tvar item = '<div class=\"control-group reward-item\">'+
\t\t\t\t\t'<label class=\"control-label\">'+
\t\t\t\t\t'<span></span>'+
\t\t\t\t\t'</label>'+
\t\t\t\t\t'<span class=\"reward-font reward-name\" data-type=\"'+key+'\">'+reward_name+'：</span> '+
\t\t\t\t\t'<input type=\"text\" name=\"prize['+count+'][name]\" placeholder=\"如 几等奖：奖品名称\" value=\"\" style=\"width:150px;\" /> '+
\t\t\t\t\t'<span class=\"reward-font\">中奖率：</span> '+
\t\t\t\t\t'<input type=\"text\" name=\"prize['+count+'][rate]\" value=\"\" style=\"width:30px;\" /> '+
\t\t\t\t\t'<span class=\"reward-font\">%</span> '+
\t\t\t\t\t'<span class=\"reward-font\">奖品数量：</span> '+
\t\t\t\t\t'<input type=\"text\" name=\"prize['+count+'][number]\" value=\"\" style=\"width:30px;\" /> '+
\t\t\t\t\t'<span style=\"font-family:微软雅黑;font-size:14px;font-weight:bold;font-style:normal;text-decoration:none;color:#333333;\">真实奖品数：</span>'+
\t\t\t\t\t'<input type=\"text\" style=\"width:30px;\" value=\"\" name=\"prize['+count+'][true_number]\">'+
\t\t\t\t\t'<input type=\"hidden\" name=\"prize['+count+'][pic]\" id=\"image-prize-hidden'+key+'\" value=\"\">'+
\t\t\t\t\t'<img src=\"\" class=\"img-polaroid\" id=\"image-preview'+key+'\" width=\"32\" style=\"display: none;\" />'+
\t\t\t\t\t'<a class=\"del-reward\" href=\"javascript:void(0)\">删除</a>'+
\t\t\t\t\t'<div class=\"uploadBox\" data-id=\"'+key+'\" style=\"margin-left: 220px;\"><div id=\"upload-prize-image'+key+'\" class=\"upload-prize-image\"></div></div>'+
\t\t\t\t\t'</div>';
\t\t\t\$('#reward-settings').append(item);
\t\t\tif(key >= prizeNum){
\t\t\t\t\$(this).remove();
\t\t\t}
            var h = \$(\"body\").height();
            window.parent.\$(\"#iframemain\").height(h);
            hupload('#upload-prize-image'+key);
\t\t})

\t\t\$('#reward-settings').on('click', 'a.del-reward', function(){
\t\t\t//后面的奖项减一
\t\t\t\$(this).parents('.reward-item').nextAll().each(function(i, ele){
\t\t\t\tvar type = \$(ele).find('.reward-name').attr('data-type');
\t\t\t\tvar new_type = type - 1;
\t\t\t\t\$(ele).find('.reward-name').attr('data-type', new_type);
\t\t\t\t\$(ele).find('.reward-name').html(rewards[new_type]+rewards[new_type]+'：');
\t\t\t\t\$(ele).find('input[name=\"reward['+new_type+'][name]\"]').attr('name', 'reward['+(new_type-1)+'][name]');
\t\t\t\t\$(ele).find('input[name=\"reward['+new_type+'][rate]\"]').attr('name', 'reward['+(new_type-1)+'][rate]');
\t\t\t\t\$(ele).find('input[name=\"reward['+new_type+'][number]\"]').attr('name', 'reward['+(new_type-1)+'][number]');
                \$(ele).find('input[name=\"prize['+new_type+'][true_number]\"]').attr('name', 'prize['+(new_type-1)+'][true_number]');
                \$(ele).find('input[name=\"prize['+new_type+'][pic]\"]').attr('name', 'prize['+(new_type-1)+'][pic]').attr('id','image-prize-hidden'+(new_type-1));
                \$(ele).find('.img-polaroid').attr('id', 'image-preview'+(new_type-1));
                \$(ele).find('.uploadBox').attr('data-id', (new_type-1));
                \$(ele).find('.upload-prize-image').attr('id', 'upload-prize-image'+(new_type-1));
\t\t\t});
\t\t\t//删除当前奖项
\t\t\t\$(this).parents('.reward-item').remove();
\t\t\tif(\$('#add-reward').length == 0){
\t\t\t\t\$('#add-reward-div').append('<a id=\"add-reward\" href=\"javascript:void(0);\">添加奖项</a>');
\t\t\t}
\t\t})
\t});
</script>
";
    }

    public function getTemplateName()
    {
        return "game/default/add.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  450 => 357,  410 => 320,  383 => 296,  350 => 266,  330 => 249,  314 => 235,  311 => 234,  279 => 205,  276 => 204,  238 => 169,  229 => 163,  220 => 157,  209 => 149,  204 => 147,  193 => 139,  188 => 137,  104 => 56,  68 => 22,  57 => 20,  53 => 19,  37 => 6,  33 => 4,  30 => 3,);
    }
}
