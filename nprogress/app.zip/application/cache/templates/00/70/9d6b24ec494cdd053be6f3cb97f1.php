<?php

/* /reserve/breadcrumb.html */
class __TwigTemplate_00709d6b24ec494cdd053be6f3cb97f1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<ul class=\"breadcrumb clearfix\">
\t<div>
        <span style=\"float:right;\"> <a href=\"/help/?type=";
        // line 3
        echo (isset($context["type"]) ? $context["type"] : $this->getContext($context, "type"));
        echo "\"><img src=\"/assets/img/vodhelp.png\"></a></span>
\t</div>
</ul>";
    }

    public function getTemplateName()
    {
        return "/reserve/breadcrumb.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  23 => 3,  19 => 1,  363 => 180,  349 => 168,  346 => 167,  326 => 149,  323 => 148,  306 => 133,  300 => 132,  286 => 130,  268 => 128,  265 => 127,  261 => 126,  251 => 118,  245 => 116,  239 => 114,  237 => 113,  217 => 95,  208 => 92,  204 => 91,  199 => 90,  194 => 89,  185 => 86,  181 => 85,  176 => 84,  172 => 83,  157 => 71,  154 => 70,  150 => 68,  144 => 66,  142 => 65,  133 => 58,  129 => 56,  123 => 54,  121 => 53,  113 => 47,  107 => 46,  99 => 44,  91 => 42,  88 => 41,  84 => 40,  75 => 33,  66 => 26,  57 => 19,  55 => 18,  46 => 12,  38 => 6,  36 => 5,  33 => 4,  30 => 3,);
    }
}
