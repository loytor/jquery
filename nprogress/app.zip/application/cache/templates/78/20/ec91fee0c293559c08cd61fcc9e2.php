<?php

/* address/add.html */
class __TwigTemplate_7820ec91fee0c293559c08cd61fcc9e2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'style' => array($this, 'block_style'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "<ul class=\"breadcrumb clearfix\">
\t<li><a href=\"/address\">地址管理</a> <span class=\"divider\">/</span></li>
\t<li class=\"active\">添加地址</li>
</ul>
<div class=\"well\">
\t<form class=\"form-horizontal\" action=\"\" method=\"post\">
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\" for=\"input-name\">名称</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<input type=\"text\" name=\"name\" id=\"input-name\">
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">标题图</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<span class=\"help-block\"><span class=\"label\">建议图片尺寸1:1</span></span>
\t\t\t\t<img src=\"/assets/img/no_image.png\" style=\"width:64px;height:64px;margin:8px;background: none;\" class=\"img-polaroid icon-preview\">
                <input type=\"button\" class=\"btn j_img_clear\" value=\"删除\" style=\"margin:50px 0 5px 10px;position:absolute;\" />
                <input type=\"hidden\" name=\"icon\" id=\"input-icon\">
\t\t\t\t<input type=\"file\" id=\"uploader-icon\">
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">图片</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<input type=\"file\" id=\"uploader-image\">
\t\t\t\t<div class=\"row\" id=\"images\">
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">地区</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<div id=\"area\">
\t\t\t\t\t<select name=\"prov\" class=\"prov input-medium\"></select>
\t\t\t\t\t<select name=\"city\" class=\"city input-medium\" style=\"display:none\"></select>
\t\t\t\t\t<select name=\"dist\" class=\"dist input-medium\" style=\"display:none\"></select>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\" for=\"input-address\">地址</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<input type=\"text\" name=\"address\" class=\"weiba-control-address\" id=\"input-address\" weiba-map-city=\"杭州\">
\t\t\t\t<input type=\"hidden\" name=\"lat\">
\t\t\t\t<input type=\"hidden\" name=\"lng\">
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">联系电话</label>
\t\t\t<div id=\"tel-list\" class=\"controls\">
\t\t\t\t<div style=\"margin-bottom: 10px;\">
\t\t\t\t\t<input type=\"text\" name=\"tel[]\" placeholder=\"例如：订餐电话：0571-88888888\">
\t\t\t\t\t<a class=\"add-tel\" title=\"添加\" href=\"javascript:void(0);\"><i class=\"icon-plus\"></i></a>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">简介</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<span class=\"label\">建议50字以内</span><br>
\t\t\t\t<textarea name=\"intro\" rows=\"3\" style=\"resize:none;\"></textarea>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">描述</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<textarea name=\"desc\"></textarea>
\t\t\t</div>
\t\t</div>
        <div class=\"control-group\">
            <label class=\"control-label\">打印机类型</label>
            <div class=\"controls\">
                <select name=\"dayinji_type\" style=\"width:120px;\">
                    <option value=\"1\">类型1</option>
                    <option value=\"2\">类型2</option>
                </select>
            </div>
        </div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">小票打印机</label>
\t\t\t<div class=\"controls\" id=\"printer-list\">
                <div style=\"margin-bottom: 10px;\">
                    <input type=\"text\" name=\"printer_name[]\" class=\"input-medium\" placeholder=\"打印机名称\">
                    <input type=\"password\" name=\"printer_secret[]\" class=\"input-medium\" placeholder=\"打印机密钥\">
                    <a class=\"add-printer\" title=\"添加\" href=\"javascript:void(0);\"><i class=\"icon-plus\"></i></a>
                </div>
\t\t\t</div>
            <span class=\"controls label\">请正确填写打印机背面的数字</span>
\t\t</div>
        <div class=\"control-group\">
            <label class=\"control-label\"><b>排序</b></label>
            <div class=\"controls\">
                <input type=\"text\" name=\"rank\" value=\"\" class=\"input-mini\"  onkeydown=\"return GetInput()\" placeholder=\"255\"/>
            </div>
        </div>
        <div class=\"control-group\">
\t\t\t<div class=\"controls\">
\t\t\t\t<button type=\"button\" class=\"btn btn-primary btn-submit\">确认保存</button>
\t\t\t</div>
\t\t</div>
\t\t
\t</form>
</div>
";
    }

    // line 110
    public function block_style($context, array $blocks = array())
    {
        // line 111
        echo "<link href=\"/assets/css/uploadify.css\" rel=\"stylesheet\">
<style type=\"text/css\">
\t.image-item {
\t\tmargin-bottom: 10px;
\t}
\t.image-del {
\t\tposition: relative;
\t\tbackground:#FFFFFF;
\t\ttop: -150px;
\t\tleft: 155px;
\t}
</style>
";
    }

    // line 125
    public function block_script($context, array $blocks = array())
    {
        // line 126
        echo "<script src=\"/assets/js/kindeditor/kindeditor-all-min.js\"></script>
<script src=\"/assets/js/kindeditor/lang/zh_CN.js\"></script>
<script src=\"/assets/js/jquery.uploadify.min.js\"></script>
<script src=\"/assets/public/js/jquery.cityselect.js\"></script>
";
        // line 130
        if (($this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "country") == "中国")) {
            // line 131
            echo "<script src=\"/assets/public/js/weiba.map.js\"></script>
";
        } else {
            // line 133
            echo "<script src=\"/assets/public/js/weiba.map.foreign.js\"></script>
";
        }
        // line 135
        echo "<script type=\"text/javascript\">
\t\$(function() {
\t\t//清空上传的图片
\t\t\$(document).on('click','.j_img_clear',function(){
\t\t\t\$(this).next('input').val('');
\t\t\t\$(this).prevAll('img').attr('src','/assets/img/no_image.png');
\t\t});
\t\t
\t\tvar editor;
\t\tKindEditor.ready(function(K) {
\t\t\teditor = K.create('textarea[name=\"desc\"]', {
\t\t\t\tresizeType: 1,
\t\t\t\tpasteType: 1,
\t\t\t\tminWidth:430,
\t\t\t\tnewlineTag:'br',
\t\t\t\titems: ['undo', 'redo', '|', 'forecolor', 'hilitecolor', 'bold', 'italic', 'underline','strikethrough', 'removeformat', '|', 'justifyleft', 'justifycenter', 'justifyright', 'insertorderedlist', 'insertunorderedlist', 'hr', '|', 'image', 'multiimage'],
\t\t\t\tuploadJson: '/image/upload_for_editor',
\t\t\t\textraFileUploadParams: {'token': '";
        // line 152
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
\t\t\t\tfilePostName: 'image',
\t\t\t\tformatUploadUrl: false
\t\t\t});
\t\t});

\t\t\$('#uploader-icon').uploadify({
\t\t\t'fileObjName': 'image',
\t\t\t'fileSizeLimit': '2MB',
\t\t\t'fileTypeExts': '*.gif; *.jpg; *.png',
\t\t\t'multi': false,
\t\t\t'removeTimeout': 0,
\t\t\t'width': 90,
\t\t\t'height': 25,
\t\t\t'buttonText': '选择标题图',
\t\t\t'formData': {'token': '";
        // line 167
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
\t\t\t'swf': '/assets/js/uploadify.swf',
\t\t\t'uploader': '/image/upload_gd',
\t\t\t'onFallback': function() {
\t\t\t\talert('您的浏览器没有安装Flash插件');
\t\t\t},
\t\t\t'onUploadSuccess': function(file, data, response) {
\t\t\t\tif (response) {
\t\t\t\t\tvar ret = \$.parseJSON(data);
\t\t\t\t\tif (ret) {
\t\t\t\t\t\tif (ret.success) {
\t\t\t\t\t\t\t\$('#input-icon').val(ret.image);
\t\t\t\t\t\t\t\$('.icon-preview').attr('src', ret.image);
\t\t\t\t\t\t} else {
\t\t\t\t\t\t\talert(ret.message);
\t\t\t\t\t\t}
\t\t\t\t\t}
\t\t\t\t}
\t\t\t}
\t\t});

\t\t\$('#uploader-image').uploadify({
\t\t\t'fileObjName': 'image',
\t\t\t'fileSizeLimit': '2MB',
\t\t\t'fileTypeExts': '*.gif; *.jpg; *.png',
\t\t\t'multi': true,
\t\t\t'removeTimeout': 0,
\t\t\t'width': 90,
\t\t\t'height': 25,
\t\t\t'buttonText': '添加图片',
\t\t\t'formData': {'token': '";
        // line 197
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
\t\t\t'swf': '/assets/js/uploadify.swf',
\t\t\t'uploader': '/image/upload_gd',
\t\t\t'onFallback': function() {
\t\t\t\talert('您的浏览器没有安装Flash插件');
\t\t\t},
\t\t\t'onUploadSuccess': function(file, data, response) {
\t\t\t\tif (response) {
\t\t\t\t\tvar ret = \$.parseJSON(data);
\t\t\t\t\tif (ret) {
\t\t\t\t\t\tif (ret.success) {
\t\t\t\t\t\t\tvar i = \$('.image-item').length;
\t\t\t\t\t\t\tvar item = '<div class=\"span2 image-item\">';
\t\t\t\t\t\t\titem += '<img src=\"'+ret.image+'\" style=\"width:180px;height:120px\" class=\"img-polaroid\">';
\t\t\t\t\t\t\titem += '<input type=\"hidden\" name=\"image['+i+'][src]\" value=\"'+ret.image+'\">';
\t\t\t\t\t\t\titem += '<input type=\"text\" name=\"image['+i+'][title]\" style=\"width:165px;\" placeholder=\"标题\">';
\t\t\t\t\t\t\titem += '<a class=\"image-del\" title=\"删除\"><i class=\"icon-trash\"></i></a>';
\t\t\t\t\t\t\titem += '</div>';
\t\t\t\t\t\t\t\$('#images').append(item);
\t\t\t\t\t\t} else {
\t\t\t\t\t\t\talert(ret.message);
\t\t\t\t\t\t}
\t\t\t\t\t}
\t\t\t\t}
\t\t\t}
\t\t});

\t\t\$('#images').on('click', '.image-del', function(){
\t\t\t\$(this).parent('.image-item').remove();
\t\t\t\$.each(\$('.image-item'), function(i, ele){
\t\t\t\t\$(\"input[name^='image'][name\$='[src]']\", this).attr('name', 'image['+i+'][src]');
\t\t\t\t\$(\"input[name^='image'][name\$='[title]']\", this).attr('name', 'image['+i+'][title]');
\t\t\t})
\t\t});

\t\t\$('#area').citySelect({prov:\"浙江\", city:\"杭州\", dist:\"西湖区\"});

\t\t//添加联系电话
\t\t\$('#tel-list').on('click', '.add-tel', function(){
\t\t\tvar item = '<div style=\"margin-bottom: 10px;\">';
\t\t\t\titem +=\t'<input type=\"text\" name=\"tel[]\" placeholder=\"例如：订餐电话：0571-88888888\">';
\t\t\t\titem += ' <a class=\"del-tel\" title=\"删除\" href=\"javascript:void(0);\"><i class=\"icon-minus\"></i></a>';
\t\t\t\titem += ' <a class=\"add-tel\" title=\"添加\" href=\"javascript:void(0);\"><i class=\"icon-plus\"></i></a>';
\t\t\t\titem += '</div>';
\t\t\t\$(this).parent().after(item);
\t\t});

\t\t//删除联系电话
\t\t\$('#tel-list').on('click', '.del-tel', function(){
\t\t\t\$(this).parent().remove();
\t\t});

        //添加小票打印机
        \$('#printer-list').on('click','.add-printer',function(){
            var item = '<div style=\"margin-bottom: 10px;\">';
            item +=\t'<input type=\"text\" name=\"printer_name[]\" class=\"input-medium\" placeholder=\"打印机名称\">'
            item +=\t'<input type=\"password\" name=\"printer_secret[]\" class=\"input-medium\" placeholder=\"打印机密钥\">';
            item += ' <a class=\"del-printer\" title=\"删除\" href=\"javascript:void(0);\"><i class=\"icon-minus\"></i></a>';
            item += ' <a class=\"add-printer\" title=\"添加\" href=\"javascript:void(0);\"><i class=\"icon-plus\"></i></a>';
            item += '</div>';
            \$(this).parent().after(item);
        });
        //删除小票打印机
        \$('#printer-list').on('click', '.del-printer', function(){
            \$(this).parent().remove();
        });

\t\t\$('#area').on('change', 'select[name=\"city\"]', function(){
\t\t\t\$('.weiba-control-address').attr('weiba-map-city', \$(this).val());
\t\t});


\t\t\$('.btn-submit').click(function(){
\t\t\tvar lat = \$('.weiba-control-address').attr('weiba-map-lat');
\t\t\tvar lng = \$('.weiba-control-address').attr('weiba-map-lng');
\t\t\t\$('input[name=\"lat\"]').val(lat);
\t\t\t\$('input[name=\"lng\"]').val(lng);
\t\t\teditor.sync();
\t\t\t\$('form').submit();
\t\t});
\t});
</script>
";
    }

    public function getTemplateName()
    {
        return "address/add.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  249 => 197,  216 => 167,  198 => 152,  179 => 135,  175 => 133,  171 => 131,  169 => 130,  163 => 126,  160 => 125,  144 => 111,  141 => 110,  33 => 4,  30 => 3,);
    }
}
