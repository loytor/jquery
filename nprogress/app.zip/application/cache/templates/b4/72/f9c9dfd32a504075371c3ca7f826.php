<?php

/* album/edit.html */
class __TwigTemplate_b472f9c9dfd32a504075371c3ca7f826 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <title>相册</title>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <meta name=\"description\" content=\"\">
    <script src=\"/assets/js/jquery.min.js\"></script>
    <script src=\"/assets/js/jquery-broswer.js\"></script>
    <script src=\"/assets/js/bootstrap.min.js\"></script>
    <script src=\"/assets/js/holder.js\"></script>
    <link href=\"/assets/css/bootstrap.min.css\" rel=\"stylesheet\">
    <link href=\"/assets/css/bootstrap-responsive.min.css\" rel=\"stylesheet\">
    <link href=\"/assets/css/app.css\" rel=\"stylesheet\">


</head>
<body>
<link href=\"/assets/huploadify/Huploadify.css\" rel=\"stylesheet\">
<script src=\"/assets/huploadify/jquery.Huploadify.js\"></script>

<script>
    if(jQuery.myBrowser.engine.type == 'ie'){
        //document.writeln('<div class=\"navbar-inner\" style=\"background-image:linear-gradient(to bottom, #FFFFFF, #F2F2F2);background-color:#fff;\"><div class=\"container\"><div class=\"masthead\"><p style=\"line-height: 40px; margin-top: 10px;color: #FF0000;font-weight:bold;font-family: Microsoft YaHei;font-size: 16px;\"><img src=\"/assets/img/notice.jpg\" border=\"0\" />&nbsp;您当前使用的是IE浏览器，与本平台不兼容，为了获得更好体验，强烈建议你下载  <a href=\"http://pan.baidu.com/share/link?shareid=3079622517&uk=2805324896&third=15\"><img src=\"/assets/img/chome.jpg\" />猎浏览器</a><或者 <a href=\"http://pan.baidu.com/share/link?shareid=3081254514&uk=2805324896&third=15\"><img src=\"/assets/img/360.jpg\" />360急速浏览器</a>/p> </div> </div></div>');
        document.writeln('<div class=\"navbar-inner\" style=\"background-image:linear-gradient(to bottom, #FFFFFF, #F2F2F2);background-color:#fff;\"><div class=\"container\"><div class=\"masthead\"><p style=\"line-height: 40px; margin-top: 10px;color: #FF0000;font-weight:bold;font-family: Microsoft YaHei;font-size: 16px;\"><img src=\"/assets/img/notice.jpg\" border=\"0\" />&nbsp;您当前使用的是IE浏览器，与本平台不兼容，为了获得更好体验，强烈建议你下载  <a href=\"http://dl.liebao.cn/kb/KSbrowser_3.6.20.4527_r5.exe\"><img src=\"/assets/img/liebao_inco.png\" />猎豹浏览器</a></p> </div> </div></div>');
    }
</script>

<script type=\"text/javascript\">
    \$(function() {
        \$(\"#j_music\").Huploadify({
            'fileObjName': 'userfile',
            'fileSizeLimit': 2048,
            'fileTypeExts': '*.mp3',
            'multi': false,
            'auto':true,
            'showUploadedPercent':false,
            'removeTimeout': 0,
            'buttonText': '选择MP3',
            'formData': {'token': '";
        // line 40
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
            'uploader': '/audio/upload',
            'onFallback': function() {
                alert('您的浏览器没有安装Flash插件');
            },
            'onUploadSuccess': function(file, data) {
                var ret = \$.parseJSON(data);
                if (ret) {
                    if (ret.success) {
                        \$('#j_music').parent().find('.j_mp3').val(ret.mp3);
                    } else {
                        alert(ret.message);
                    }
                }
            }
        });

        \$(\"input[name='music_is_sys']\").on('change',function(){
            if(\$(this).prop(\"checked\")==true){
                \$(\".music_sys\").show();
                \$(\".music_custom\").hide();
            }else{
                \$(\".music_sys\").hide();
                \$(\".music_custom\").show();
            }
        });

        function upload_file(id,text){
            \$(id).Huploadify({
                'fileObjName': 'image',
                'fileSizeLimit': 2048,
                'fileTypeExts': '*.gif; *.jpg; *.png',
                'multi': false,
                'auto':true,
                'showUploadedPercent':false,
                'removeTimeout': 0,
                'buttonText': text ? text : '选择图片',
                'formData': {'token': '";
        // line 77
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
                'swf': '/assets/js/uploadify.swf',
                'uploader': '/image/upload_gd',
                'onFallback': function() {
                    alert('您的浏览器没有安装Flash插件');
                },
                'onUploadSuccess': function(file, data) {
                        var ret = \$.parseJSON(data);
                        if (ret) {
                            if (ret.success) {
                                \$(id).parent().find('.img_value').val(ret.image);
                                \$(id).parent().find('img').attr('src', ret.image);
                            } else {
                                alert(ret.message);
                            }
                        }
                }
            });
        }
        upload_file('#uploader-img','');

        //删除图片
        \$(document).on('click','.j_clear',function(){
            \$(this).next('input').val('');
            \$(this).prevAll('img').attr('src','/assets/img/no_image.png');
        });


        \$('#album_tpl').change(function(){
            \$(\"#album_tpl\").val()=='shu' ? \$('#shu_tip').show() : \$('#shu_tip').hide();
        });
    });
</script>

<style type=\"text/css\">
    .photo-item {
        margin-bottom: 10px;
    }
    .photo-del {
        position: relative;
        background:#FFFFFF;
        top: -122px;
        left: 155px;
    }


    .uploadify-button{
        color: #333;
        background-color: #fff;
        border-color: #ccc;
        cursor:pointer;
        text-decoration:none;
        border-radius: 2px;
        margin-left: 0;
    }
    .uploadify-button:hover {
        background-color: #ccc;
        background-image: none;
        background-position: center bottom;
        cursor:pointer;
        text-decoration:none;
    }
</style>
<div class=\"main-left\">
    <ul class=\"app-lt-nav\">
        <li class=\"active\"><a href=\"/album/index/";
        // line 142
        echo $this->getAttribute((isset($context["album"]) ? $context["album"] : $this->getContext($context, "album")), "id", array(), "array");
        echo "\">基本信息</a></li>
        <li><a href=\"/album/album_img\">相册照片</a></li>
    </ul>
</div>
<div class=\"main-right\">
\t<div class=\"well\">
\t\t<form class=\"form-horizontal\" action=\"\" method=\"post\">
\t\t\t<div class=\"control-group\">
\t\t\t\t<label class=\"control-label\" for=\"input-token\">用户名</label>
\t\t\t\t<div class=\"controls\">
\t\t\t\t\t<label style=\"margin-top:5px;\">";
        // line 152
        echo $this->getAttribute((isset($context["album"]) ? $context["album"] : $this->getContext($context, "album")), "username", array(), "array");
        echo "  <a href=\"/album/logout/";
        echo $this->getAttribute((isset($context["album"]) ? $context["album"] : $this->getContext($context, "album")), "id", array(), "array");
        echo "\"> [退出] </a></label>
\t\t\t\t</div>
\t\t\t</div>
            <div class=\"control-group\">
                <label class=\"control-label\">被浏览次数</label>
                <div class=\"controls\">
                    ";
        // line 158
        echo $this->getAttribute((isset($context["album"]) ? $context["album"] : $this->getContext($context, "album")), "visitors", array(), "array");
        echo "
                </div>
            </div>
\t\t\t<div class=\"control-group\">
\t\t\t\t<label class=\"control-label\" for=\"input-token\">密码</label>
\t\t\t\t<div class=\"controls\">
\t\t\t\t\t<input type=\"text\" name=\"password\" id=\"input-token\" value=\"";
        // line 164
        echo $this->getAttribute((isset($context["album"]) ? $context["album"] : $this->getContext($context, "album")), "password", array(), "array");
        echo "\">
\t\t\t\t\t<span class=\"help-inline\"><span class=\"label\">最多6位</span></span>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div class=\"control-group\">
\t\t\t\t<label class=\"control-label\">相册名称</label>
\t\t\t\t<div class=\"controls\">
\t\t\t\t\t<input type=\"text\" name=\"title\"  value=\"";
        // line 171
        echo $this->getAttribute((isset($context["album"]) ? $context["album"] : $this->getContext($context, "album")), "title", array(), "array");
        echo "\">
\t\t\t\t</div>
\t\t\t</div>

            <div class=\"control-group\">
                <label class=\"control-label\"><span class=\"red\">*&nbsp;</span>背景音乐</label>

                <div class=\"controls j_sys\">
                    <label><input type=\"checkbox\" name=\"music_is_sys\" ";
        // line 179
        if ($this->getAttribute((isset($context["album"]) ? $context["album"] : $this->getContext($context, "album")), "music_is_sys", array(), "array")) {
            echo "checked";
        }
        echo " >&nbsp;系统音乐</label>
                    <div class=\"music_sys\" style=\"margin-top:10px;";
        // line 180
        if ($this->getAttribute((isset($context["album"]) ? $context["album"] : $this->getContext($context, "album")), "music_is_sys", array(), "array")) {
        } else {
            echo "display:none;";
        }
        echo "\">
                        <select name=\"music_sys\" style=\"width:220px;\">
                            <option value=\"\" ";
        // line 182
        if (twig_test_empty($this->getAttribute((isset($context["album"]) ? $context["album"] : $this->getContext($context, "album")), "music", array(), "array"))) {
            echo "selected=\"selected\"";
        }
        echo ">无背景音乐</option>
                            ";
        // line 183
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["music_arr"]) ? $context["music_arr"] : $this->getContext($context, "music_arr")));
        foreach ($context['_seq'] as $context["_key"] => $context["_music"]) {
            // line 184
            echo "                            <option value=\"";
            echo $this->getAttribute((isset($context["_music"]) ? $context["_music"] : $this->getContext($context, "_music")), "url", array(), "array");
            echo "\" ";
            if (($this->getAttribute((isset($context["album"]) ? $context["album"] : $this->getContext($context, "album")), "music", array(), "array") == $this->getAttribute((isset($context["_music"]) ? $context["_music"] : $this->getContext($context, "_music")), "url", array(), "array"))) {
                echo "selected=\"selected\"";
            }
            echo ">";
            echo $this->getAttribute((isset($context["_music"]) ? $context["_music"] : $this->getContext($context, "_music")), "name", array(), "array");
            echo "</option>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['_music'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 186
        echo "                        </select>
                    </div>
                    <div class=\"music_custom\" style=\"";
        // line 188
        if ($this->getAttribute((isset($context["album"]) ? $context["album"] : $this->getContext($context, "album")), "music_is_sys", array(), "array")) {
            echo "display:none;";
        }
        echo "margin-top: 10px;\">
                        <input type=\"text\" class=\"j_mp3\" name=\"music\" value=\"";
        // line 189
        if ($this->getAttribute((isset($context["album"]) ? $context["album"] : $this->getContext($context, "album")), "music_is_sys", array(), "array")) {
        } else {
            echo $this->getAttribute((isset($context["album"]) ? $context["album"] : $this->getContext($context, "album")), "music", array(), "array");
        }
        echo "\" style=\"width:200px;margin-bottom: 10px;\" placeholder=\"请上传mp3音乐\">
                        <span style=\"color:#999;\">2M以内的MP3</span><br />
                        <div id=\"j_music\"></div>
                    </div>
                </div>
            </div>

            <div class=\"control-group\">
                <label class=\"control-label\">选择模版：</label>
                <div class=\"controls\">
                    <select name=\"tpl\" class=\"form-control\" style=\"width:130px;\" id=\"album_tpl\">
                        ";
        // line 200
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["album_tpl"]) ? $context["album_tpl"] : $this->getContext($context, "album_tpl")));
        foreach ($context['_seq'] as $context["key"] => $context["tpl"]) {
            // line 201
            echo "                        <option value=\"";
            echo (isset($context["key"]) ? $context["key"] : $this->getContext($context, "key"));
            echo "\" ";
            if (($this->getAttribute((isset($context["album"]) ? $context["album"] : $this->getContext($context, "album")), "tpl", array(), "array") == (isset($context["key"]) ? $context["key"] : $this->getContext($context, "key")))) {
                echo "selected=\"selected\"";
            }
            echo ">";
            echo (isset($context["tpl"]) ? $context["tpl"] : $this->getContext($context, "tpl"));
            echo "</option>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['tpl'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 203
        echo "                    </select>
                    <span style=\"color:#942a25; ";
        // line 204
        echo ((($this->getAttribute((isset($context["album"]) ? $context["album"] : $this->getContext($context, "album")), "tpl", array(), "array") == "shu")) ? ("display:block") : ("display:none"));
        echo "\" id=\"shu_tip\">相册第一张照片为相册封面，刮开50%即可进入相册</span>
                </div>
            </div>

            <div class=\"control-group\">
                <label class=\"control-label\">分享标题：</label>
                <div class=\"controls\">
                    <input type=\"text\" name=\"share_title\" value=\"";
        // line 211
        echo $this->getAttribute((isset($context["album"]) ? $context["album"] : $this->getContext($context, "album")), "share_title", array(), "array");
        echo "\" >
                </div>
            </div>
            <div class=\"control-group\">
                <label class=\"control-label\">分享图标：</label>


                <div class=\"controls\">
                    <span style=\"color:#999;\">建议比例：1:1</span><br />
                    ";
        // line 220
        if ($this->getAttribute((isset($context["album"]) ? $context["album"] : $this->getContext($context, "album")), "share_img", array(), "array")) {
            // line 221
            echo "                    <img src=\"";
            echo $this->getAttribute((isset($context["album"]) ? $context["album"] : $this->getContext($context, "album")), "share_img", array(), "array");
            echo "\" style=\"width:80px;height:80px;margin:0 0 5px 0;\" class=\"img-polaroid\">
                    <input type=\"button\" class=\"btn j_clear\" value=\"删除\"/>
                    <input type=\"hidden\" class=\"img_value\" name=\"share_img\" value=\"";
            // line 223
            echo $this->getAttribute((isset($context["album"]) ? $context["album"] : $this->getContext($context, "album")), "share_img", array(), "array");
            echo "\">
                    <div id=\"uploader-img\"></div>
                    ";
        } else {
            // line 226
            echo "                    <img src=\"/assets/img/no_image.png\" style=\"width:80px;height:80px;margin:0 0 5px 0;\" class=\"img-polaroid\">
                    <input type=\"button\" class=\"btn j_clear\" value=\"删除\"/>
                    <input type=\"hidden\" class=\"img_value\" name=\"share_img\" value=\"\">
                    <div id=\"uploader-img\"></div>
                    ";
        }
        // line 231
        echo "                </div>

            <div class=\"control-group\">
                <label class=\"control-label\">分享描述</label>
                <div class=\"controls\">
                    <textarea name=\"share_intro\" style=\"width:300px;height:80px;resize:none;\">";
        // line 236
        echo $this->getAttribute((isset($context["album"]) ? $context["album"] : $this->getContext($context, "album")), "share_intro", array(), "array");
        echo "</textarea>
                </div>
            </div>

\t\t\t<div class=\"control-group\">
\t\t\t\t<div class=\"controls\">
\t\t\t\t\t<button type=\"submit\" class=\"btn btn-primary\">确认保存</button>
\t\t\t\t</div>
\t\t\t</div>
\t\t</form>
\t</div>

</div>";
    }

    public function getTemplateName()
    {
        return "album/edit.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  360 => 236,  353 => 231,  346 => 226,  340 => 223,  334 => 221,  332 => 220,  320 => 211,  310 => 204,  307 => 203,  292 => 201,  288 => 200,  271 => 189,  265 => 188,  261 => 186,  246 => 184,  242 => 183,  236 => 182,  228 => 180,  222 => 179,  211 => 171,  201 => 164,  192 => 158,  181 => 152,  168 => 142,  100 => 77,  60 => 40,  19 => 1,);
    }
}
