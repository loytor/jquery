<?php

/* assist/index.html */
class __TwigTemplate_86d510d84ecd244e2d2b6341b49e3ee9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'style' => array($this, 'block_style'),
            'main' => array($this, 'block_main'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_style($context, array $blocks = array())
    {
        // line 4
        echo "<style>

</style>
";
    }

    // line 9
    public function block_main($context, array $blocks = array())
    {
        // line 10
        echo "
<ul class=\"breadcrumb clearfix\">
    <a href=\"/assist/setting\" class=\"btn\"><i class=\"icon-cog\"></i> 基本设置</a>
    <a href=\"/assist\" class=\"btn active\"><i class=\"icon-list\"></i> 辅助按钮列表</a>
    <a href=\"/assist/add\" class=\"btn btn-primary pull-right\"><i class=\"icon-plus icon-white\"></i> 添加辅助按钮</a>
</ul>

<form action=\"\" method=\"post\">
\t<table class=\"table table-hover table-bordered\">
\t\t<thead>
\t\t<tr style=\"background-color:#EEEEEE;\">
\t\t\t<th>#</th>
\t\t\t<th>图标</th>
\t\t\t<th>标题</th>
\t\t\t<th>类型</th>
\t\t\t<th>内容</th>
\t\t\t<th>排序</th>
\t\t\t<th>操作</th>
\t\t</tr>
\t\t</thead>
\t\t<tbody>
\t\t<tr>
\t\t\t<td>筛选</td>
\t\t\t<td></td>
\t\t\t<td><input name=\"title\" class=\"input-small\" type=\"text\" style=\"margin-bottom: 0;\" value=\"";
        // line 34
        echo (isset($context["title"]) ? $context["title"] : $this->getContext($context, "title"));
        echo "\"></td>
\t\t\t<td>
\t\t\t\t<select name=\"type\" class=\"input-small\">
\t\t\t\t\t<option value=\"-1\">所有</option>
\t\t\t\t\t";
        // line 38
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["types"]) ? $context["types"] : $this->getContext($context, "types")));
        foreach ($context['_seq'] as $context["k"] => $context["t"]) {
            // line 39
            echo "\t\t\t\t\t";
            if (((isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")) == (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k")))) {
                // line 40
                echo "\t\t\t\t\t<option value=\"";
                echo (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k"));
                echo "\" selected=\"selected\">";
                echo (isset($context["t"]) ? $context["t"] : $this->getContext($context, "t"));
                echo "</option>
\t\t\t\t\t";
            } else {
                // line 42
                echo "\t\t\t\t\t<option value=\"";
                echo (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k"));
                echo "\">";
                echo (isset($context["t"]) ? $context["t"] : $this->getContext($context, "t"));
                echo "</option>
\t\t\t\t\t";
            }
            // line 44
            echo "\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['k'], $context['t'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 45
        echo "\t\t\t\t</select>
\t\t\t</td>
\t\t\t<td>
\t\t\t\t<input name=\"content\" class=\"input-medium\" type=\"text\" style=\"margin-bottom: 0;\" value=\"";
        // line 48
        echo (isset($context["content"]) ? $context["content"] : $this->getContext($context, "content"));
        echo "\">
\t\t\t</td>
\t\t\t<td>
\t\t\t\t<input name=\"rank\" class=\"input-small\" type=\"text\" style=\"margin-bottom: 0;\" value=\"";
        // line 51
        echo (isset($context["rank"]) ? $context["rank"] : $this->getContext($context, "rank"));
        echo "\">
\t\t\t</td>
\t\t\t<td>
\t\t\t\t<button class=\"btn btn-primary\" type=\"submit\">查找</button>
\t\t\t</td>
\t\t</tr>
\t\t";
        // line 57
        if ((!twig_test_empty((isset($context["list"]) ? $context["list"] : $this->getContext($context, "list"))))) {
            // line 58
            echo "\t\t";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["list"]) ? $context["list"] : $this->getContext($context, "list")));
            foreach ($context['_seq'] as $context["key"] => $context["row"]) {
                // line 59
                echo "\t\t<tr>
\t\t\t<td>";
                // line 60
                echo ((((isset($context["per_page"]) ? $context["per_page"] : $this->getContext($context, "per_page")) * ((isset($context["page"]) ? $context["page"] : $this->getContext($context, "page")) - 1)) + (isset($context["key"]) ? $context["key"] : $this->getContext($context, "key"))) + 1);
                echo "</td>
\t\t\t<td>
\t\t\t\t";
                // line 62
                if ((!twig_test_empty($this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "icon", array(), "array")))) {
                    // line 63
                    echo "\t\t\t\t<img style=\"width:64px; height:64px; background:#bababa\" src=\"";
                    echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "icon", array(), "array");
                    echo "\">
\t\t\t\t";
                }
                // line 65
                echo "\t\t\t</td>
\t\t\t<td>";
                // line 66
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "title", array(), "array");
                echo "</td>
\t\t\t<td>";
                // line 67
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "type_name", array(), "array");
                echo "</td>
\t\t\t<td style=\"width: 200px;word-wrap:break-word;word-break:break-all;\">";
                // line 68
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "content", array(), "array");
                echo "</td>
\t\t\t<td>";
                // line 69
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "rank", array(), "array");
                echo "</td>
\t\t\t<td>
\t\t\t\t<a class=\"btn btn-small\" href=\"/assist/edit/";
                // line 71
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "id", array(), "array");
                echo "\"><i class=\"icon-edit\"></i> 编辑</a>
\t\t\t\t<a data-id=\"";
                // line 72
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "id", array(), "array");
                echo "\" class=\"btn btn-small btn-delete\"><i class=\"icon-trash\"></i> 删除</a>
\t\t\t</td>
\t\t</tr>
\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 76
            echo "\t\t";
        } else {
            // line 77
            echo "\t\t<tr><td colspan=\"7\" style=\"text-align: center;\">尚无辅助按钮</td></tr>
\t\t";
        }
        // line 79
        echo "\t\t</tbody>
\t</table>
</form>
";
        // line 82
        echo (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination"));
        echo "
";
    }

    // line 85
    public function block_script($context, array $blocks = array())
    {
        // line 86
        echo "<script type=\"text/javascript\">
\t\$('.btn-delete').click(function(){
\t\tif(confirm(\"是否确定删除该联系我们？\")){
\t\t\tvar assist_id = \$(this).attr('data-id');
\t\t\twindow.location.href = '/assist/delete/' + assist_id;
\t\t}
\t});
</script>
";
    }

    public function getTemplateName()
    {
        return "assist/index.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  203 => 86,  200 => 85,  194 => 82,  189 => 79,  185 => 77,  182 => 76,  172 => 72,  168 => 71,  163 => 69,  159 => 68,  155 => 67,  151 => 66,  148 => 65,  142 => 63,  140 => 62,  135 => 60,  132 => 59,  127 => 58,  125 => 57,  116 => 51,  110 => 48,  105 => 45,  99 => 44,  91 => 42,  83 => 40,  80 => 39,  76 => 38,  69 => 34,  43 => 10,  40 => 9,  33 => 4,  30 => 3,);
    }
}
