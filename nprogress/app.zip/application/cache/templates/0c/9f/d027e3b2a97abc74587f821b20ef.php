<?php

/* article/index.html */
class __TwigTemplate_0c9fd027e3b2a97abc74587f821b20ef extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'style' => array($this, 'block_style'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "<ul class=\"breadcrumb clearfix\">
\t";
        // line 5
        if (array_key_exists("cate", $context)) {
            // line 6
            echo "\t<li><a href=\"/cate\">微信网站管理</a> <span class=\"divider\">/</span></li>
\t<li class=\"active\">";
            // line 7
            echo $this->getAttribute((isset($context["cate"]) ? $context["cate"] : $this->getContext($context, "cate")), "cate_name", array(), "array");
            echo "</li>
\t";
        }
        // line 9
        echo "\t<div class=\"pull-right\">
\t\t<div class=\"btn-group\">
\t\t\t<a class=\"btn btn-primary\" href=\"/article/add";
        // line 11
        if (array_key_exists("cate", $context)) {
            echo "/";
            echo $this->getAttribute((isset($context["cate"]) ? $context["cate"] : $this->getContext($context, "cate")), "id", array(), "array");
        }
        echo "\"><i class=\"icon-plus icon-white\"></i>添加文章</a>
\t\t</div>
\t</div>
</ul>

<form class=\"form-inline\">
\t<table class=\"table table-striped\">
\t\t<thead>
\t\t\t<tr>
\t\t\t\t<th style=\"width:60px\">选择</th>
\t\t\t\t<th style=\"width:120px\">所属栏目</th>
\t\t\t\t<th>文章标题</th>
\t\t\t\t<th>更新时间</th>
\t\t\t\t<th style=\"width:60px\">浏览次数</th>
\t\t\t\t<th style=\"width:200px\"></th>
\t\t\t</tr>
\t\t</thead>
\t\t<tbody>
\t\t\t<tr>
\t\t\t\t<td><input type=\"checkbox\" name=\"check_all\" value=\"0\" /> 全选</td>
\t\t\t\t<td>
\t\t\t\t\t<select name=\"cate_id\" class=\"input-small\" style=\"margin-bottom: 0;\">
\t\t\t\t\t\t<option value=\"_\">所有</option>
\t\t\t\t\t\t<option value=\"\">未归档</option>
\t\t\t\t\t\t";
        // line 35
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["cate_arr"]) ? $context["cate_arr"] : $this->getContext($context, "cate_arr")));
        foreach ($context['_seq'] as $context["ck"] => $context["c"]) {
            // line 36
            echo "\t\t\t\t\t\t";
            if (((isset($context["cate_id"]) ? $context["cate_id"] : $this->getContext($context, "cate_id")) == (isset($context["ck"]) ? $context["ck"] : $this->getContext($context, "ck")))) {
                // line 37
                echo "\t\t\t\t\t\t<option value=\"";
                echo (isset($context["ck"]) ? $context["ck"] : $this->getContext($context, "ck"));
                echo "\" selected=\"selected\">";
                echo $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cate_name", array(), "array");
                echo "</option>
\t\t\t\t\t\t";
            } else {
                // line 39
                echo "\t\t\t\t\t\t<option value=\"";
                echo (isset($context["ck"]) ? $context["ck"] : $this->getContext($context, "ck"));
                echo "\">";
                echo $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cate_name", array(), "array");
                echo "</option>
\t\t\t\t\t\t";
            }
            // line 41
            echo "\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['ck'], $context['c'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 42
        echo "\t\t\t\t\t</select>
\t\t\t\t</td>
\t\t\t\t<td><input name=\"title\" class=\"input-medium\" style=\"margin-bottom: 0;\" value=\"";
        // line 44
        echo (isset($context["title"]) ? $context["title"] : $this->getContext($context, "title"));
        echo "\"></td>
\t\t\t\t<td><input name=\"from_time\" id=\"from-time\" value=\"";
        // line 45
        echo (isset($context["from_time"]) ? $context["from_time"] : $this->getContext($context, "from_time"));
        echo "\" class=\"input-medium\"  style=\"margin-bottom: 0;\" type=\"datetime\"> 至 <input name=\"to_time\" id=\"to-time\" value=\"";
        echo (isset($context["to_time"]) ? $context["to_time"] : $this->getContext($context, "to_time"));
        echo "\" class=\"input-medium\" style=\"margin-bottom: 0;\" type=\"datetime\"></td>
\t\t\t\t<td>
\t\t\t\t\t<input name=\"count_view\" class=\"input-mini\" type=\"text\" style=\"margin-bottom: 0;\" value=\"";
        // line 47
        echo (isset($context["count_view"]) ? $context["count_view"] : $this->getContext($context, "count_view"));
        echo "\">
\t\t\t\t</td>
\t\t\t\t<td><button class=\"btn btn-primary\" type=\"submit\">查找</button></td>
\t\t\t</tr>
\t\t\t";
        // line 51
        if ((!twig_test_empty((isset($context["article_arr"]) ? $context["article_arr"] : $this->getContext($context, "article_arr"))))) {
            // line 52
            echo "\t\t\t";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["article_arr"]) ? $context["article_arr"] : $this->getContext($context, "article_arr")));
            foreach ($context['_seq'] as $context["_key"] => $context["_article"]) {
                // line 53
                echo "\t\t\t<tr>
\t\t\t\t<td><input type=\"checkbox\" value=\"";
                // line 54
                echo $this->getAttribute((isset($context["_article"]) ? $context["_article"] : $this->getContext($context, "_article")), "id", array(), "array");
                echo "\" class=\"input_check\" /></td>
\t\t\t\t<!--<td><input type=\"text\" value=\"";
                // line 55
                echo $this->getAttribute((isset($context["_article"]) ? $context["_article"] : $this->getContext($context, "_article")), "rank", array(), "array");
                echo "\" article_id=\"";
                echo $this->getAttribute((isset($context["_article"]) ? $context["_article"] : $this->getContext($context, "_article")), "id", array(), "array");
                echo "\" class=\"input-rank\" style=\"width:30px\"></td>-->
\t\t\t\t<td>
\t\t\t\t\t";
                // line 57
                if ($this->getAttribute((isset($context["_article"]) ? $context["_article"] : $this->getContext($context, "_article")), "cate_name", array(), "array")) {
                    // line 58
                    echo "\t\t\t\t\t<span class=\"label label-info\">";
                    echo $this->getAttribute((isset($context["_article"]) ? $context["_article"] : $this->getContext($context, "_article")), "cate_name", array(), "array");
                    echo "</span>
\t\t\t\t\t";
                } else {
                    // line 60
                    echo "\t\t\t\t\t<span class=\"label\">未归档</span>
\t\t\t\t\t";
                }
                // line 62
                echo "\t\t\t\t</td>
\t\t\t\t<td>
\t\t\t\t\t<a href=\"";
                // line 64
                echo $this->getAttribute((isset($context["_article"]) ? $context["_article"] : $this->getContext($context, "_article")), "preview_url", array(), "array");
                echo "\" target=\"blank\"><strong>";
                echo $this->getAttribute((isset($context["_article"]) ? $context["_article"] : $this->getContext($context, "_article")), "title", array(), "array");
                echo "</strong></a> 
\t\t\t\t\t";
                // line 65
                if ($this->getAttribute((isset($context["_article"]) ? $context["_article"] : $this->getContext($context, "_article")), "url", array(), "array")) {
                    echo "<span class=\"label\"><i class=\"icon-share icon-white\"></i> 外部链接</span>";
                }
                echo " 
\t\t\t\t\t";
                // line 66
                if (($this->getAttribute((isset($context["_article"]) ? $context["_article"] : null), "is_top", array(), "array", true, true) && ($this->getAttribute((isset($context["_article"]) ? $context["_article"] : $this->getContext($context, "_article")), "is_top", array(), "array") == 1))) {
                    echo "<span class=\"label label-success\">已置顶</span>";
                }
                // line 67
                echo "\t\t\t\t</td>
\t\t\t\t<td><strong class=\"muted\">";
                // line 68
                echo twig_date_format_filter($this->env, $this->getAttribute((isset($context["_article"]) ? $context["_article"] : $this->getContext($context, "_article")), "dt_update", array(), "array"), "Y/m/d H:i");
                echo "</strong></td>
\t\t\t\t<td><span class=\"badge\">";
                // line 69
                echo $this->getAttribute((isset($context["_article"]) ? $context["_article"] : $this->getContext($context, "_article")), "count_view", array(), "array");
                echo "</span></td>
\t\t\t\t<td>
\t\t\t\t\t<a class=\"btn btn-small\" href=\"";
                // line 71
                echo $this->getAttribute((isset($context["_article"]) ? $context["_article"] : $this->getContext($context, "_article")), "preview_url", array(), "array");
                echo "\" target=\"blank\"><i class=\"icon-globe\"></i>查看</a>
                    
                    <a class=\"btn btn-small\" href=\"/article/update/";
                // line 73
                echo $this->getAttribute((isset($context["_article"]) ? $context["_article"] : $this->getContext($context, "_article")), "id", array(), "array");
                echo "\"><i class=\"icon-edit\"></i>编辑</a>
\t\t\t\t\t<a class=\"btn btn-small btn-delete\" data-id=\"";
                // line 74
                echo $this->getAttribute((isset($context["_article"]) ? $context["_article"] : $this->getContext($context, "_article")), "id", array(), "array");
                echo "\"><i class=\"icon-trash\"></i>删除</a>
\t\t\t\t</td>
\t\t\t</tr>
\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['_article'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 78
            echo "\t\t\t";
        } else {
            // line 79
            echo "\t\t\t<tr><td colspan=\"5\" style=\"text-align: center;\">没有相关的文章</td></tr>
\t\t\t";
        }
        // line 81
        echo "\t\t</tbody>
\t</table>
\t<div class=\"\">
        <input type=\"button\" id=\"add_gd\" class=\"btn btn-primary\" value=\"添加归档\" /> 至
        <select id=\"select_gd\" name=\"cate_gd\" class=\"input-small\">
            <option value=\"_\">未归档</option>
            ";
        // line 87
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["cate_arr"]) ? $context["cate_arr"] : $this->getContext($context, "cate_arr")));
        foreach ($context['_seq'] as $context["ck"] => $context["c"]) {
            // line 88
            echo "            ";
            if (((isset($context["cate_id"]) ? $context["cate_id"] : $this->getContext($context, "cate_id")) == (isset($context["ck"]) ? $context["ck"] : $this->getContext($context, "ck")))) {
                // line 89
                echo "            <option value=\"";
                echo (isset($context["ck"]) ? $context["ck"] : $this->getContext($context, "ck"));
                echo "\" selected=\"selected\">";
                echo $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cate_name", array(), "array");
                echo "</option>
            ";
            } else {
                // line 91
                echo "            <option value=\"";
                echo (isset($context["ck"]) ? $context["ck"] : $this->getContext($context, "ck"));
                echo "\">";
                echo $this->getAttribute((isset($context["c"]) ? $context["c"] : $this->getContext($context, "c")), "cate_name", array(), "array");
                echo "</option>
            ";
            }
            // line 93
            echo "            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['ck'], $context['c'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 94
        echo "\t\t</select>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type=\"button\" id=\"btn_del\" class=\"btn btn-primary\" value=\"删除\" />
    </div>
</form>
";
        // line 99
        echo (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination"));
        echo "
";
    }

    // line 102
    public function block_style($context, array $blocks = array())
    {
        // line 103
        echo "<style type=\"text/css\">
thead {
\tborder-top: 1px solid #ddd;
\tbackground-color: #eee;
}
</style>
";
    }

    // line 111
    public function block_script($context, array $blocks = array())
    {
        // line 112
        echo "<script src=\"/assets/js/lhgcalendar.min.js\"></script>
<script type=\"text/javascript\">
\$(function() {
\t\$('#add_gd').click(function(){
\t\tvar select_gd=\$('#select_gd option:selected').val();
\t\tvar arr=[];
\t\t\$(\".input_check:checked\").each(function(){
\t\t\t \tarr.push(\$(this).val());
\t\t\t });

        if(!arr || arr=='')
        {
            alert('请先选择数据！');return false;
        }

        //if (confirm(\"请谨慎删除！删除评论后，该评论下的所有回复也将删除，且不可恢复！确定要删除吗？\")) {
            \$.post(
                    '/article/batch_cat',
                    {ids:arr, cat_id:select_gd},
                    function(data){
                        var ret = \$.parseJSON(data);
                        if(ret && ret.ret){
                            alert(ret.msg);
                        }else{
                            window.location.reload();
                        }
                    }
            )
        //}
\t\t})

    //批量删除
    \$('#btn_del').click(function(){
        var arr=[];
        \$(\".input_check:checked\").each(function(){
            arr.push(\$(this).val());
        });

        if(!arr || arr=='')
        {
            alert('请先选择数据！');return false;
        }

        if (confirm(\"请谨慎删除！删除后不可恢复！确定要删除吗？\")) {
            \$.post(
                    '/article/batch_del',
                    {ids:arr},
                    function(data){
                        var ret = \$.parseJSON(data);
                        if(ret && ret.ret){
                            alert(ret.msg);
                        }else{
                            window.location.reload();
                        }
                    }
            )
        }
    })
\t
\t\$(\"input[name='check_all']\").click(function(){
\t\tif( \$(this).val()==0)
\t\t{
\t\t\t \$(this).val(1);
\t\t\t \$(\".input_check\").each(function(){
\t\t\t \tthis.checked = true;
\t\t\t });  
\t\t}
\t\t else {
\t\t\t  \$(this).val(0);
           \t\t \$(\".input_check\").each(function(){
\t\t\t \tthis.checked = false;
\t\t\t });
            }
\t\t})
\t\$('.input-rank').keyup(function(){
\t\tvar article_id = \$(this).attr('article_id');
\t\tvar rank = \$(this).val();
\t\t\$.post('/article/update_rank/'+article_id, {'rank':rank}, function(data) {
\t\t\tif (!data.success) {
\t\t\t\talert(data.message);
\t\t\t}
\t\t});
\t});
\t
\t\$('.btn-delete').click(function(){
\t\tif(confirm(\"是否确定删除该文章？\")){
\t\t\tvar article_id = \$(this).attr('data-id');\t\t\t
\t\t\twindow.location.href = '/article/delete/'+article_id;
\t\t}
\t});

\t\$('#from-time').calendar({format:'yyyy-MM-dd HH:mm:ss' });
\t\$('#to-time').calendar({ format:'yyyy-MM-dd HH:mm:ss',minDate:'#from-time' });
});
</script>
";
    }

    public function getTemplateName()
    {
        return "article/index.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  288 => 112,  285 => 111,  275 => 103,  272 => 102,  266 => 99,  259 => 94,  253 => 93,  245 => 91,  237 => 89,  234 => 88,  230 => 87,  222 => 81,  218 => 79,  215 => 78,  205 => 74,  201 => 73,  196 => 71,  191 => 69,  187 => 68,  184 => 67,  180 => 66,  174 => 65,  168 => 64,  164 => 62,  160 => 60,  154 => 58,  152 => 57,  145 => 55,  141 => 54,  138 => 53,  133 => 52,  131 => 51,  124 => 47,  117 => 45,  113 => 44,  109 => 42,  103 => 41,  95 => 39,  87 => 37,  84 => 36,  80 => 35,  50 => 11,  46 => 9,  41 => 7,  38 => 6,  36 => 5,  33 => 4,  30 => 3,);
    }
}
