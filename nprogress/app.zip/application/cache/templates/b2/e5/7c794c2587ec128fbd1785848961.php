<?php

/* address/index.html */
class __TwigTemplate_b2e57c794c2587ec128fbd1785848961 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "
<form action=\"\" method=\"post\">
\t<table class=\"table table-hover table-bordered\">
\t\t<thead>
\t\t<tr>
\t\t\t<th colspan=\"10\" style=\"text-align: center; font-size:16px;\">
\t\t\t\t地址列表
\t\t\t\t<a href=\"/address/add\" class=\"btn btn-primary pull-right\"><i class=\"icon-plus icon-white\"></i> 添加地址</a>
\t\t\t</th>
\t\t</tr>
\t\t<tr style=\"background-color:#EEEEEE;\">
\t\t\t<th>#</th>
\t\t\t<th>图片</th>
\t\t\t<th style=\"width:15%\">名称</th>
\t\t\t<th>省</th>
\t\t\t<th>市</th>
\t\t\t<th>区</th>
\t\t\t<th style=\"width:20%;word-break:break-all;word-wrap:break-word;\">地址</th>
\t\t\t<th style=\"width:15%\">联系电话</th>
            <th style=\"width:45px;\">排序值</th>
\t\t\t<th style=\"width:10%\"></th>
\t\t</tr>
\t\t</thead>
\t\t<tbody>
\t\t<tr>
\t\t\t<td>筛选</td>
\t\t\t<td></td>
\t\t\t<td><input name=\"name\" class=\"input-small\" type=\"text\" style=\"margin-bottom: 0;\" value=\"";
        // line 31
        echo (isset($context["name"]) ? $context["name"] : $this->getContext($context, "name"));
        echo "\"></td>
\t\t\t<td><input name=\"prov\" class=\"input-mini\" type=\"text\" style=\"margin-bottom: 0;\" value=\"";
        // line 32
        echo (isset($context["prov"]) ? $context["prov"] : $this->getContext($context, "prov"));
        echo "\"></td>
\t\t\t<td><input name=\"city\" class=\"input-mini\" type=\"text\" style=\"margin-bottom: 0;\" value=\"";
        // line 33
        echo (isset($context["city"]) ? $context["city"] : $this->getContext($context, "city"));
        echo "\"></td>
\t\t\t<td><input name=\"dist\" class=\"input-mini\" type=\"text\" style=\"margin-bottom: 0;\" value=\"";
        // line 34
        echo (isset($context["dist"]) ? $context["dist"] : $this->getContext($context, "dist"));
        echo "\"></td>
\t\t\t<td><input name=\"address\" class=\"input-small\" type=\"text\" style=\"margin-bottom: 0;\" value=\"";
        // line 35
        echo (isset($context["address"]) ? $context["address"] : $this->getContext($context, "address"));
        echo "\"></td>
\t\t\t<td><input name=\"tel\" class=\"input-small\" type=\"text\" style=\"margin-bottom: 0;\" value=\"";
        // line 36
        echo (isset($context["tel"]) ? $context["tel"] : $this->getContext($context, "tel"));
        echo "\"></td>
            <td></td>
\t\t\t<td>
\t\t\t\t<button class=\"btn btn-primary\" type=\"submit\">查找</button>
\t\t\t</td>
\t\t</tr>
\t\t";
        // line 42
        if ((!twig_test_empty((isset($context["list"]) ? $context["list"] : $this->getContext($context, "list"))))) {
            // line 43
            echo "\t\t";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["list"]) ? $context["list"] : $this->getContext($context, "list")));
            foreach ($context['_seq'] as $context["key"] => $context["row"]) {
                // line 44
                echo "\t\t<tr>
\t\t\t<td>";
                // line 45
                echo ((((isset($context["per_page"]) ? $context["per_page"] : $this->getContext($context, "per_page")) * ((isset($context["page"]) ? $context["page"] : $this->getContext($context, "page")) - 1)) + (isset($context["key"]) ? $context["key"] : $this->getContext($context, "key"))) + 1);
                echo "</td>
\t\t\t<td>
\t\t\t\t";
                // line 47
                if ((!twig_test_empty($this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "icon", array(), "array")))) {
                    // line 48
                    echo "\t\t\t\t<img style=\"width:64px; height:64px\" src=\"";
                    echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "icon", array(), "array");
                    echo "\">
\t\t\t\t";
                }
                // line 50
                echo "\t\t\t</td>
\t\t\t<td>";
                // line 51
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "name", array(), "array");
                echo "</td>
\t\t\t<td>";
                // line 52
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "prov", array(), "array");
                echo "</td>
\t\t\t<td>";
                // line 53
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "city", array(), "array");
                echo "</td>
\t\t\t<td>";
                // line 54
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "dist", array(), "array");
                echo "</td>
\t\t\t<td style=\"width:20%;word-break:break-all;word-wrap:break-word;\">";
                // line 55
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "address", array(), "array");
                echo "</td>
\t\t\t<td>";
                // line 56
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "tel", array(), "array");
                echo "</td>
            <td>";
                // line 57
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "rank", array(), "array");
                echo "</td>
\t\t\t<td>
\t\t\t\t<a class=\"btn btn-small\" href=\"/address/edit/";
                // line 59
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "id", array(), "array");
                echo "\"><i class=\"icon-edit\"></i> 编辑</a>
\t\t\t\t<a data-id=\"";
                // line 60
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "id", array(), "array");
                echo "\" class=\"btn btn-small btn-delete\"><i class=\"icon-trash\"></i> 删除</a>
\t\t\t\t<a class=\"btn btn-small\" href=\"/address/set_pwd/";
                // line 61
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "id", array(), "array");
                echo "\"><i class=\"icon-edit\"></i> 设置交易密码</a>
\t\t\t</td>
\t\t</tr>
\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 65
            echo "\t\t";
        } else {
            // line 66
            echo "\t\t<tr><td colspan=\"9\" style=\"text-align: center;\">尚无地址</td></tr>
\t\t";
        }
        // line 68
        echo "\t\t</tbody>
\t</table>
</form>
";
        // line 71
        echo (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination"));
        echo "
";
    }

    // line 74
    public function block_script($context, array $blocks = array())
    {
        // line 75
        echo "<script type=\"text/javascript\">
\t\$('.btn-delete').click(function(){
\t\tif(confirm(\"是否确定删除该地址？\")){
\t\t\tvar address_id = \$(this).attr('data-id');
\t\t\twindow.location.href = '/address/delete/'+address_id;
\t\t}
\t});
</script>
";
    }

    public function getTemplateName()
    {
        return "address/index.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  184 => 75,  181 => 74,  175 => 71,  170 => 68,  166 => 66,  163 => 65,  153 => 61,  149 => 60,  145 => 59,  140 => 57,  136 => 56,  132 => 55,  128 => 54,  124 => 53,  120 => 52,  116 => 51,  113 => 50,  107 => 48,  105 => 47,  100 => 45,  97 => 44,  92 => 43,  90 => 42,  81 => 36,  77 => 35,  73 => 34,  69 => 33,  65 => 32,  61 => 31,  32 => 4,  29 => 3,);
    }
}
