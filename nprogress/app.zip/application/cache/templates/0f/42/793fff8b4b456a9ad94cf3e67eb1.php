<?php

/* layout_main.html */
class __TwigTemplate_0f42793fff8b4b456a9ad94cf3e67eb1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'style' => array($this, 'block_style'),
            'main' => array($this, 'block_main'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
<meta charset=\"utf-8\">
<title>微信公众平台</title>
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
<meta name=\"description\" content=\"\">
<script src=\"/assets/js/jquery.min.js\"></script>
<link href=\"/assets/css/bootstrap.min.css\" rel=\"stylesheet\">
<link href=\"/assets/css/bootstrap-responsive.min.css\" rel=\"stylesheet\">
<link href=\"/assets/css/app.css?v=2.0\" rel=\"stylesheet\">
<style type=\"text/css\">
.container {
\tmargin: 0 auto;
}
.footer {
\theight: 40px;
\tline-height: 40px;
\tpadding-right: 20px;
\tpadding-left: 20px;
\tbackground-color: #1b1b1b;
\tbackground-image: -moz-linear-gradient(top, #222222, #111111);
\tbackground-image: -webkit-gradient(linear, 0 0, 0 100%, from(#222222), to(#111111));
\tbackground-image: -webkit-linear-gradient(top, #222222, #111111);
\tbackground-image: -o-linear-gradient(top, #222222, #111111);
\tbackground-image: linear-gradient(to bottom, #222222, #111111);
\tbackground-repeat: repeat-x;
\tborder-color: #252525;
\tfilter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff222222', endColorstr='#ff111111', GradientType=0);
\tcolor: #999;
\tfont-size: 12px;
\ttext-align: center;
}
.top-right {
\theight: 60px;
\tline-height: 60px;
\tfont-size: 12px;
}
</style>
";
        // line 40
        $this->displayBlock('style', $context, $blocks);
        // line 41
        echo "<!--[if lt IE 9]>
<script src=\"/assets/js/html5shiv.js\"></script>
<![endif]-->

<script src=\"/assets/js/jquery-broswer.js\"></script>
</head>
<body>
<script>
if(jQuery.myBrowser.engine.type == 'ie'){
    //document.writeln('<div class=\"navbar-inner\" style=\"background-image:linear-gradient(to bottom, #FFFFFF, #F2F2F2);background-color:#fff;\"><div class=\"container\"><div class=\"masthead\"><p style=\"line-height: 40px; margin-top: 10px;color: #FF0000;font-weight:bold;font-family: Microsoft YaHei;font-size: 16px;\"><img src=\"/assets/img/notice.jpg\" border=\"0\" />&nbsp;您当前使用的是IE浏览器，与本平台不兼容，为了获得更好体验，强烈建议你下载  <a href=\"http://pan.baidu.com/share/link?shareid=3079622517&uk=2805324896&third=15\"><img src=\"/assets/img/chome.jpg\" />猎浏览器</a><或者 <a href=\"http://pan.baidu.com/share/link?shareid=3081254514&uk=2805324896&third=15\"><img src=\"/assets/img/360.jpg\" />360急速浏览器</a>/p> </div> </div></div>');
    document.writeln('<div class=\"navbar-inner\" style=\"background-image:linear-gradient(to bottom, #FFFFFF, #F2F2F2);background-color:#fff;\"><div class=\"container\"><div class=\"masthead\"><p style=\"line-height: 40px; margin-top: 10px;color: #FF0000;font-weight:bold;font-family: Microsoft YaHei;font-size: 16px;\"><img src=\"/assets/img/notice.jpg\" border=\"0\" />&nbsp;您当前使用的是IE浏览器，与本平台不兼容，为了获得更好体验，强烈建议你下载  <a href=\"http://dl.liebao.cn/kb/KSbrowser_3.6.20.4527_r5.exe\"><img src=\"/assets/img/liebao_inco.png\" />猎豹浏览器</a></p> </div> </div></div>'); 
}
</script>

";
        // line 55
        if ((left_nav() != "")) {
            // line 56
            echo left_nav();
            echo "
<div class=\"main-right\">
";
        }
        // line 59
        echo "
";
        // line 60
        $this->displayBlock('main', $context, $blocks);
        // line 61
        echo "
";
        // line 62
        if ((left_nav() != "")) {
            // line 63
            echo "</div>
";
        }
        // line 65
        echo "<script src=\"/assets/js/bootstrap.min.js\"></script>
<script src=\"/assets/js/holder.js\"></script>
";
        // line 67
        $this->displayBlock('script', $context, $blocks);
        // line 68
        echo "</body>
</html>";
    }

    // line 40
    public function block_style($context, array $blocks = array())
    {
    }

    // line 60
    public function block_main($context, array $blocks = array())
    {
    }

    // line 67
    public function block_script($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "layout_main.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  124 => 67,  119 => 60,  109 => 68,  107 => 67,  103 => 65,  99 => 63,  97 => 62,  94 => 61,  92 => 60,  89 => 59,  83 => 56,  81 => 55,  65 => 41,  22 => 1,  206 => 106,  203 => 105,  189 => 93,  186 => 92,  166 => 74,  162 => 72,  132 => 44,  122 => 40,  118 => 39,  114 => 40,  110 => 37,  106 => 36,  102 => 35,  98 => 34,  93 => 32,  90 => 31,  86 => 30,  80 => 29,  73 => 27,  63 => 40,  59 => 25,  45 => 13,  43 => 12,  33 => 4,  30 => 3,);
    }
}
