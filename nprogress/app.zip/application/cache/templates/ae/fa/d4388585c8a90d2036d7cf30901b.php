<?php

/* marketing_vote/add.html */
class __TwigTemplate_aefad4388585c8a90d2036d7cf30901b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'style' => array($this, 'block_style'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "
<ul class=\"breadcrumb clearfix\">
\t<li><a href=\"/marketing_vote\">微信投票</a> <span class=\"divider\">/</span></li>
\t<li class=\"active\">创建微信投票</li>
\t<span style=\"float:right;\"> <a href=\"/help/?type=vote\"><img src=\"/assets/img/vodhelp.png\"></a></span>
</ul>
<ul class=\"clearfix activity-instruction\">
\t微信投票相关介绍
</ul>
<div class=\"well\">    
    <p style=\"text-align:left;\">
        <span class=\"activity-info\">活动信息：</span>
    </p>    
\t<form class=\"form-horizontal\" action=\"\" method=\"post\" enctype=\"multipart/form-data\">
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\" for=\"input-instruction\">投票活动说明</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<textarea class=\"span4\" id=\"input-instruction\" name=\"instruction\"></textarea>
\t\t\t\t<p>限200字以内</p>
\t\t\t</div>
\t\t</div>
\t\t
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">投票活动时间</label>
\t\t\t<div class=\"controls\">
\t\t\t\t";
        // line 29
        if ($this->getAttribute((isset($context["errors"]) ? $context["errors"] : null), "dt_start", array(), "array", true, true)) {
            // line 30
            echo "\t\t\t\t";
            echo $this->getAttribute((isset($context["errors"]) ? $context["errors"] : $this->getContext($context, "errors")), "dt_start", array(), "array");
            echo "
\t\t\t\t";
        }
        // line 32
        echo "\t\t\t\t<input type=\"text\" name=\"dt_start\" placeholder=\"点击选择开始时间\" value=\"\" id=\"statdate\" />
           \t\t 到
            \t<input type=\"text\" name=\"dt_end\" placeholder=\"点击选择结束时间\" value=\"\" id=\"enddate\" />\t
\t\t\t</div>
\t\t</div>
\t\t
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">设置投票项目</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<table cellpadding=\"5px\" id=\"vote-settings\">
\t\t\t\t\t<thead>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<th>回复选项</th>
\t\t\t\t\t\t\t<th class=\"text-left\">对应投票内容</th>
\t\t\t\t\t\t\t<th></th>
\t\t\t\t\t\t</tr>
\t\t\t\t\t</thead>
\t\t\t\t\t<tbody>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t<input type=\"text\" name=\"vote_setting[0][choice]\" placeholder=\"A\" style=\"width:50px; text-align:center;\" />
\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t<input type=\"text\" name=\"vote_setting[0][content]\" placeholder=\"输入投票内容...\" maxlength=\"20\"/>
\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t<td><a href=\"javascript:void(0)\" class=\"del-item\">删除</a></td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t<input type=\"text\" name=\"vote_setting[1][choice]\" placeholder=\"B\" style=\"width:50px; text-align:center;\" />
\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t<input type=\"text\" name=\"vote_setting[1][content]\" placeholder=\"输入投票内容...\" maxlength=\"20\"/>
\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t<td><a href=\"javascript:void(0)\" class=\"del-item\">删除</a></td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t</tbody>
\t\t\t\t\t<tfoot>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td><a href=\"javascript:void(0)\" id=\"add-item\">增加一项</a></td>
\t\t\t\t\t\t\t<td>（至少2项，每项最多20字。）</td>
\t\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t\t<tr><td colspan=\"3\"><span class=\"label label-important\">由于微信限制了回复的消息内容长度不超过2048字节, 所以请勿填写过多选项!</span></td></tr>
\t\t\t\t\t</tfoot>
\t\t\t\t</table>
\t\t\t</div>
\t\t</div>
         <div class=\"control-group\">
\t\t\t<div class=\"controls\">
\t\t\t\t<input type=\"file\" name=\"userfile\" id=\"uploader-start-xls\" />

\t\t\t\t<span class=\"red\">支持excel批量导入（<a data-toggle=\"modal\" href=\"#guide_5\">点击查看表格格式</a>）</span>
\t\t\t\t
\t\t\t</div>
\t\t </div>
        
        <div class=\"control-group\">
\t\t\t<label class=\"control-label\">单选/多选</label>
\t\t\t<div class=\"controls\">\t\t\t
\t\t\t\t<input type=\"radio\" name=\"choice[type]\" checked=\"checked\" value=\"0\" /> 单选
\t\t\t\t&nbsp;&nbsp;
\t\t\t\t<input type=\"radio\" name=\"choice[type]\" value=\"1\" /> 多选 : 最多可选 <input type=\"text\" name=\"choice[number]\" style=\"width:40px; text-align:center;\" value=\"2\" /> 项
\t\t\t</div>
\t\t</div>
        <div class=\"control-group\">
\t\t\t<label class=\"control-label\">投票结果</label>
\t\t\t<div class=\"controls\">\t\t\t
\t\t\t\t<input type=\"checkbox\" id=\"display\" name=\"display\" checked=\"checked\" value=\"1\" style=\"float:left\" /><label for=\"display\" style=\"float:left;padding-left:5px\">投票前可见</label>
\t\t\t</div>
\t\t</div>
        
\t\t<div class=\"control-group\">        
            <label class=\"control-label\">规则设置</label>
            <div class=\"controls\">
\t            活动期间每个用户ID，每
\t            <input type=\"text\" name=\"rule\" value=\"1\" style=\"width:30px;\" />
\t            <div id=\"single-box\" style=\"display: inline-block;\">
\t\t            天限参与<input type=\"text\" name=\"rule_jnum\" value=\"1\" style=\"width:30px;\" >次
\t            </div>
\t            <div id=\"multi-box\" style=\"display: none;\">
\t\t            天限参与1次
\t            </div>
            </div>
\t\t</div>
\t\t
\t\t<div class=\"control-group\">
\t\t\t<div class=\"controls\">
\t\t\t\t<button type=\"submit\" class=\"btn btn-primary\">确认保存</button>
\t\t\t</div>
\t\t</div>
\t</form>
</div>


<div id=\"guide_5\" class=\"modal hide fade\" tabindex=\"-1\">
\t<div class=\"modal-body\">
\t\t<img src=\"/assets/img/xls.png\">
\t</div>
\t<div class=\"modal-footer\">
\t\t<button class=\"btn\" data-dismiss=\"modal\" aria-hidden=\"true\">关闭</button>
\t</div>
</div>

";
    }

    // line 138
    public function block_style($context, array $blocks = array())
    {
        // line 139
        echo "<link href=\"/assets/css/uploadify.css\" rel=\"stylesheet\" />
";
    }

    // line 142
    public function block_script($context, array $blocks = array())
    {
        // line 143
        echo "<script src=\"/assets/js/lhgcalendar.min.js\"></script>
<script src=\"/assets/js/jquery.uploadify.min.js\"></script>

<script type=\"text/javascript\">
\$(function() {
    \$('#statdate').calendar({format:'yyyy-MM-dd HH:mm:ss' });
    \$('#enddate').calendar({ format:'yyyy-MM-dd HH:mm:ss',minDate:'#statdate' });
    
    \$('#add-item').click(function(){
    \tvar i = \$('#vote-settings tbody').children('tr').length;
    \tvar item = \"<tr>\";
    \t\titem +=\t\"<td><input type='text' name='vote_setting[\"+i+\"][choice]' style='width:50px; text-align:center;' /></td>\";
    \t\titem += \"<td><input type='text' name='vote_setting[\"+i+\"][content]' placeholder='输入投票内容...' maxlength='20'/></td>\";
\t\t\titem += \"<td><a href='javascript:void(0)' class='del-item'>删除</a></td>\";
\t\t\titem += \"</tr>\";
\t\t
\t\t\$('#vote-settings tbody').append(item);
    });
    
    \$('#vote-settings').on('click', 'a.del-item', function(){
    \tif(\$('#vote-settings tbody').children('tr').length <= 2){
    \t\talert('至少需要2项.');
    \t\treturn;
    \t}
     \t\$(this).parent('td').parent('tr').remove();
    });
    
    //批量导入
    \$('#uploader-start-xls').uploadify({
\t\t'fileObjName': 'userfile',
\t\t'fileSizeLimit': '2MB',
        'fileTypeExts': '*.xls; *.xlsx',
\t\t'multi': false,
\t\t'removeTimeout': 0,
\t\t'width': 90,
\t\t'height': 25,
\t\t'buttonText': '批量导入',
\t\t'formData': {'token': '";
        // line 180
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
\t\t'swf': '/assets/js/uploadify.swf',
\t\t'uploader': '/xls/marketing_vote',
\t\t'onFallback': function() {
\t\t\talert('您的浏览器没有安装Flash插件');
\t\t},
\t\t'onUploadSuccess': function(file, data, response) {
\t\t\tif (response) {
\t\t\t\tvar ret = \$.parseJSON(data);
\t\t\t\tif (ret) {
\t\t\t\t\tif (ret.success) {
                        var votehtml = '';
                        \$.each(ret.data, function(i, item){        
                          votehtml += '<tr><td><input type=\"text\" style=\"width:50px; text-align:center;\" value=\"'+ item['0'] +'\" name=\"vote_setting['+i+'][choice]\"></td><td><input type=\"text\" maxlength=\"20\" value=\"'+ item['1'] +'\" name=\"vote_setting['+i+'][content]\"></td><td><a class=\"del-item\" href=\"javascript:void(0)\">删除</a></td></tr>';
                    \t});
                        \$('#vote-settings tbody').html('').html(votehtml);
\t\t\t\t\t} else {
\t\t\t\t\t\talert(ret.message);
\t\t\t\t\t}
\t\t\t\t}
                
\t\t\t}
\t\t}
\t});

\t\$('input[name=\"choice[type]\"]').change(function(){
\t\tvar val = \$(this).val();
\t\tif(val == 0) {
\t\t\t\$('#single-box').css('display', 'inline-block');
\t\t\t\$('#multi-box').hide();
\t\t} else {
\t\t\t\$('#multi-box').css('display', 'inline-block');
\t\t\t\$('#single-box').hide();
\t\t}
\t});
});
</script>
";
    }

    public function getTemplateName()
    {
        return "marketing_vote/add.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  226 => 180,  187 => 143,  184 => 142,  179 => 139,  176 => 138,  68 => 32,  62 => 30,  60 => 29,  33 => 4,  30 => 3,);
    }
}
