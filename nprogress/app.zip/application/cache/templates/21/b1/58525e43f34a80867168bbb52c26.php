<?php

/* article/update.html */
class __TwigTemplate_21b158525e43f34a80867168bbb52c26 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'style' => array($this, 'block_style'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "<ul class=\"breadcrumb clearfix\">
\t<li><a href=\"/article\">图文素材管理</a> <span class=\"divider\">/</span></li>
\t<li class=\"active\">修改文章</li>
</ul>
<div class=\"well\">
\t<form class=\"form-horizontal\" action=\"\" method=\"post\">
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\" for=\"select-cate_id\">所属网站栏目</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<select name=\"cate_id\" id=\"select-cate_id\" class=\"span2\">
\t\t\t\t\t<option value=\"\">未归档</option>
\t\t\t\t\t";
        // line 15
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["cate_arr"]) ? $context["cate_arr"] : $this->getContext($context, "cate_arr")));
        foreach ($context['_seq'] as $context["_cate_id"] => $context["_cate"]) {
            // line 16
            echo "\t\t\t\t\t<option value=\"";
            echo (isset($context["_cate_id"]) ? $context["_cate_id"] : $this->getContext($context, "_cate_id"));
            echo "\"";
            if (((isset($context["_cate_id"]) ? $context["_cate_id"] : $this->getContext($context, "_cate_id")) == $this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "cate_id", array(), "array"))) {
                echo " selected=\"selected\"";
            }
            echo ">";
            echo $this->getAttribute((isset($context["_cate"]) ? $context["_cate"] : $this->getContext($context, "_cate")), "cate_name", array(), "array");
            echo "</option>
\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_cate_id'], $context['_cate'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 18
        echo "\t\t\t\t</select>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\" for=\"input-title\">标题</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<input type=\"text\" name=\"title\" id=\"input-title\" value=\"";
        // line 24
        echo $this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "title", array(), "array");
        echo "\" class=\"span4\">
\t\t\t\t<span class=\"help-inline\"><span class=\"label\">建议10个汉字以内</span></span>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\" for=\"input-description\">描述</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<input type=\"text\" name=\"description\" id=\"input-description\" value=\"";
        // line 31
        echo $this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "description", array(), "array");
        echo "\" class=\"span4\">
\t\t\t\t<span class=\"help-inline\"><span class=\"label\">建议13个汉字以内</span></span>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\" for=\"textarea-content\">内容</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<textarea rows=\"2\" name=\"content\" id=\"textarea-content\" style=\"width:600px;height:300px;\">";
        // line 38
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "content", array(), "array"));
        echo "</textarea>
\t\t\t</div>
\t\t\t<div class=\"controls alert alert-error\" style=\"width:600px;\">
\t\t\t建议：文章中的最佳图片宽度为480px 高度不限
            <br />
            为保证手机在非WIFI环境下顺畅浏览网页，建议图片总量不超过5张
\t\t\t</div>\t\t\t
\t\t</div>
\t\t<div class=\"control-group";
        // line 46
        if ($this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "url", array(), "array")) {
            echo " hide";
        }
        echo "\" id=\"control_show_url\">
\t\t\t<div class=\"controls\">
\t\t\t\t<a href=\"#\" id=\"show_url\"><span class=\"label\"><i class=\"icon-share icon-white\"></i> 指向外部链接</span></a>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group";
        // line 51
        if (twig_test_empty($this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "url", array(), "array"))) {
            echo " hide";
        }
        echo "\" id=\"control_url\">
\t\t\t<label class=\"control-label\" for=\"input-url\">外部链接</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<input type=\"text\" name=\"url\" id=\"input-url\" value=\"";
        // line 54
        echo $this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "url", array(), "array");
        echo "\" class=\"span4\" placeholder=\"http://\">
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\" for=\"input-image\">封面图片</label>
\t\t\t<div class=\"controls\">
\t\t\t\t";
        // line 60
        if ($this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "image", array(), "array")) {
            // line 61
            echo "\t\t\t\t<img src=\"";
            echo image_url($this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "image", array(), "array"), 80, 80);
            echo "\" class=\"img-polaroid\" id=\"image-preview\">
\t\t\t\t";
        } else {
            // line 63
            echo "\t\t\t\t<img src=\"/assets/img/no_image.png\" class=\"img-polaroid\" id=\"image-preview\">
\t\t\t\t";
        }
        // line 65
        echo "                <input type=\"button\" class=\"btn j_img_clear\" value=\"删除\" style=\"margin:0 0 5px 10px;\" />
\t\t\t\t<input type=\"hidden\" name=\"image\" id=\"input-image\" value=\"";
        // line 66
        echo image_url($this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "image", array(), "array"));
        echo "\">
\t\t\t\t<span class=\"help-inline\"><a href=\"#guide_1\" data-toggle=\"modal\"><span class=\"badge badge-success\"><i class=\"icon-question-sign icon-white\"></i></span></a></span>
                <div id=\"uploader-image\"></div>
\t\t\t\t<a class=\"btn btn-success\" onclick=\"show_icons_sys()\">选择系统图标</a>
\t\t\t\t<label class=\"checkbox\">
\t\t\t\t\t<input type=\"checkbox\" name=\"is_image_sic\" value=\"1\"";
        // line 71
        if ($this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "is_image_sic", array(), "array")) {
            echo " checked=\"checked\"";
        }
        echo "> <span class=\"label\">图片在内容中显示</span>
\t\t\t\t</label>
\t\t\t</div>
\t\t</div>
        <!--
\t\t<div class=\"control-group\">
\t\t\t<div class=\"controls\">
\t\t\t\t<label class=\"checkbox\">
\t\t\t\t\t<input type=\"checkbox\" name=\"is_top\" value=\"1\"";
        // line 79
        if ($this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "is_top", array(), "array")) {
            echo " checked=\"checked\"";
        }
        echo "> <span class=\"label\">是否将文章设为置顶</span>
\t\t\t\t\t<span class=\"help-inline\"><a href=\"#guide_6\" data-toggle=\"modal\"><span class=\"badge badge-success\"><i class=\"icon-question-sign icon-white\"></i></span></a></span>
\t\t\t\t</label>
\t\t\t</div>
\t\t</div>-->

\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\" for=\"input-image\">点赞设置</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<label class=\"checkbox inline\">
\t\t\t\t\t<input type=\"radio\" name=\"is_upvote\" value=\"1\"";
        // line 89
        if ($this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "is_upvote", array(), "array")) {
            echo " checked=\"checked\"";
        }
        echo "> 是
\t\t\t\t</label>
\t\t\t\t<label class=\"checkbox inline\">
\t\t\t\t\t<input type=\"radio\" name=\"is_upvote\" value=\"0\"";
        // line 92
        if (($this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "is_upvote", array(), "array") == 0)) {
            echo " checked=\"checked\"";
        }
        echo "> 否
\t\t\t\t</label>
\t\t\t\t<span class=\"label\">此处设置仅支持点赞的文章模板，否则选择无效！</span>
\t\t\t</div>
\t\t</div>

        <div class=\"control-group\">
\t\t\t<label class=\"control-label\" for=\"input-image\">可查看权限</label>
            <div class=\"controls\">
                <select name=\"level_type\" style=\"width:120px;\" class=\"j_level_type\" >
                <option value=\"0\" ";
        // line 102
        if (("0" == $this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "level_type", array(), "array"))) {
            echo "selected=\"selected\"";
        }
        echo " >匿名用户</option>
                <option value=\"1\" ";
        // line 103
        if (("1" == $this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "level_type", array(), "array"))) {
            echo "selected=\"selected\"";
        }
        echo " >关注用户</option>
                ";
        // line 104
        if ((isset($context["level"]) ? $context["level"] : $this->getContext($context, "level"))) {
            echo "<option value=\"2\" ";
            if (("2" == $this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "level_type", array(), "array"))) {
                echo "selected=\"selected\"";
            }
            echo " >会员卡用户</option>";
        }
        // line 105
        echo "                </select>
        \t</div>
\t\t</div>

        <div class=\"control-group j_level\" ";
        // line 109
        if (("2" != $this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "level_type", array(), "array"))) {
            echo "style=\"display:none;\"";
        }
        echo " >
\t\t\t<label class=\"control-label\" for=\"input-image\">会员卡等级</label>
            <div class=\"controls\">
                <select name=\"level\" style=\"width:120px;\" >
                ";
        // line 113
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["level"]) ? $context["level"] : $this->getContext($context, "level")));
        foreach ($context['_seq'] as $context["lev"] => $context["val"]) {
            // line 114
            echo "                <option value=\"";
            echo (isset($context["lev"]) ? $context["lev"] : $this->getContext($context, "lev"));
            echo "\" ";
            if (((isset($context["lev"]) ? $context["lev"] : $this->getContext($context, "lev")) == $this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "level", array(), "array"))) {
                echo "selected=\"selected\"";
            }
            echo ">";
            echo (isset($context["val"]) ? $context["val"] : $this->getContext($context, "val"));
            echo "</option>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['lev'], $context['val'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 116
        echo "                </select>
        \t</div>
\t\t</div>
        
\t\t<div class=\"control-group\" id=\"control_tpl\">
\t\t\t<label class=\"control-label\" for=\"tpllist\">文章模版</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<select id=\"tpllist\" name=\"tpl\" autocomplete=\"off\">
\t\t\t\t\t<option value=\"\" ";
        // line 124
        if (twig_test_empty($this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "tpl", array(), "array"))) {
            echo "selected";
        }
        echo " preview=\"";
        echo (isset($context["preview_path"]) ? $context["preview_path"] : $this->getContext($context, "preview_path"));
        echo "assets/types_pub/detail/";
        echo $this->getAttribute((isset($context["global_tpl"]) ? $context["global_tpl"] : $this->getContext($context, "global_tpl")), "template_id", array(), "array");
        echo "/preview.jpg\">使用全局设置</option>
\t\t\t\t\t";
        // line 125
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["tpl_lists"]) ? $context["tpl_lists"] : $this->getContext($context, "tpl_lists")));
        foreach ($context['_seq'] as $context["_key"] => $context["tpl"]) {
            // line 126
            echo "\t\t\t\t\t<option value=\"";
            echo $this->getAttribute((isset($context["tpl"]) ? $context["tpl"] : $this->getContext($context, "tpl")), "template_id", array(), "array");
            echo "\" ";
            if (($this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "tpl", array(), "array") == $this->getAttribute((isset($context["tpl"]) ? $context["tpl"] : $this->getContext($context, "tpl")), "template_id", array(), "array"))) {
                echo "selected";
            }
            echo " preview=\"";
            echo (isset($context["preview_path"]) ? $context["preview_path"] : $this->getContext($context, "preview_path"));
            echo "assets/types_pub/detail/";
            echo $this->getAttribute((isset($context["tpl"]) ? $context["tpl"] : $this->getContext($context, "tpl")), "template_id", array(), "array");
            echo "/preview.jpg\">";
            echo $this->getAttribute((isset($context["tpl"]) ? $context["tpl"] : $this->getContext($context, "tpl")), "title", array(), "array");
            echo "</option>
\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tpl'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 128
        echo "\t\t\t\t</select>
\t\t\t</div>
\t\t\t<div class=\"controls\">
\t\t\t\t<img id=\"tpl_preview\" style=\"display: none;margin-top: 12px;\" width=\"220\" src=\"/assets/img/template/list/default.jpg\">
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<div class=\"controls\">
\t\t\t\t<button type=\"submit\" class=\"btn btn-primary\">确认保存</button>
\t\t\t</div>
\t\t</div>
\t</form>
</div>
<div id=\"guide_1\" class=\"modal hide fade\" tabindex=\"-1\">
\t<div class=\"modal-body\">
\t\t<img src=\"/assets/img/guide_1.jpg\">
\t</div>
\t<div class=\"modal-footer\">
\t\t<button class=\"btn\" data-dismiss=\"modal\" aria-hidden=\"true\">关闭</button>
\t</div>
</div>
<div id=\"guide_6\" class=\"modal hide fade\" tabindex=\"-1\">
\t<div class=\"modal-body\">
\t\t<img src=\"/assets/img/guide_6.jpg\">
\t</div>
\t<div class=\"modal-footer\">
\t\t<button class=\"btn\" data-dismiss=\"modal\" aria-hidden=\"true\">关闭</button>
\t</div>
</div>
";
    }

    // line 159
    public function block_style($context, array $blocks = array())
    {
        // line 160
        echo "<link href=\"/assets/js/kindeditor/themes/default/default.css\" rel=\"stylesheet\">
<link href=\"/assets/huploadify/Huploadify.css\" rel=\"stylesheet\">
<link href=\"/assets/css/icons_sys.css\" rel=\"stylesheet\">
<style type=\"text/css\">
\t#image-preview {
\t\tmargin-bottom: 10px;
\t\tbackground-color: #bababa;
\t}
    .uploadify-button{
        color: #333;
        background-color: #fff;
        border-color: #ccc;
        cursor:pointer;
        text-decoration:none;
        border-radius: 2px;
        margin-left: 0;
    }
    .uploadify-button:hover {
        background-color: #ccc;
        background-image: none;
        background-position: center bottom;
        cursor:pointer;
        text-decoration:none;
    }
</style>
";
    }

    // line 187
    public function block_script($context, array $blocks = array())
    {
        // line 188
        echo "<script src=\"/assets/js/kindeditor/kindeditor-all-min.js\"></script>
<script src=\"/assets/js/kindeditor/lang/zh_CN.js\"></script>
<script type=\"text/javascript\">
var editor;
KindEditor.ready(function(K) {
\teditor = K.create('textarea', {
\t\tresizeType: 1,
\t\tcssPath: '/assets/css/bootstrap.min.css',
\t\titems: ['source', '|', 'undo', 'redo', '|', 'fontname', 'fontsize','wordpaste', '|', 'forecolor', 'hilitecolor', 'bold', 'italic', 'underline', 'removeformat', '|', 'justifyleft', 'justifycenter', 'justifyright','hr', 'insertorderedlist', 'insertunorderedlist', '|','table', 'emoticons', 'image','multiimage', 'link', 'baidumap'],
\t\tuploadJson: '/image/upload_for_editor',
\t\textraFileUploadParams: {'token': '";
        // line 198
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
\t\tfilePostName: 'image',
\t\tformatUploadUrl: false
\t});
});
</script>
<script src=\"/assets/huploadify/jquery.Huploadify.js\"></script>
<script src=\"/assets/js/icons_sys.js\"></script>
<script type=\"text/javascript\">
\$(function() {
\t//清空上传的图片
\t\$(document).on('click','.j_img_clear',function(){
\t\t\$(this).next('input').val('');
\t\t\$(this).prevAll('img').attr('src','/assets/img/no_image.png');
\t});
\t
\t\$('.j_level_type').on('change',function(){
\t\tvar level_type = \$(this).val();
\t\tif(level_type==2){
\t\t\t\$('.j_level').show();
\t\t}else{
\t\t\t\$('.j_level').hide();\t
\t\t}\t
\t});

    \$('#uploader-image').Huploadify({
        'fileObjName': 'image',
        'fileSizeLimit': 2048,
        'fileTypeExts': '*.gif; *.jpg; *.png',
        'multi': false,
        'auto':true,
        'showUploadedPercent':false,
        'removeTimeout': 0,
        'buttonText': '选择图片',
        'formData': {'token': '";
        // line 232
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
        'uploader': '/image/upload',
        'onUploadSuccess': function(file, data) {
            var ret = \$.parseJSON(data);
            if (ret) {
                if (ret.success) {
                    \$('#input-image').val(ret.image);
                    \$('#image-preview').attr('src', ret.image_preview);
                } else {
                    alert(ret.message);
                }
            }
        }
    });

\t\$('#show_url').click(function() {
\t\t\$('#control_url').removeClass('hide');
\t\t\$('#control_show_url').addClass('hide');
\t\treturn false;
\t});
});

function show_icons_sys(){
\twindow.SysIconDialog.showDialog(function (id, url, type_id) {//id=图标id，也许需要   url=图标路径  type_id=所在分组id
\t\t\$('#input-image').val(url);
\t\t\$('#image-preview').attr('src', url);
\t});
}

(function (window, \$, undefined) {
\tvar \$selected = \$('#tpllist').change(function (a, b) {
\t\t\$('#tpl_preview').attr('src', \$(this).find('option:selected').attr('preview'));
\t}).find('option:selected');
\tvar \$tpl_preview = \$('#tpl_preview').attr('src',\$selected.attr('preview')).fadeIn ();
})(window, jQuery, undefined);
</script>
";
    }

    public function getTemplateName()
    {
        return "article/update.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  419 => 232,  382 => 198,  370 => 188,  367 => 187,  338 => 160,  335 => 159,  302 => 128,  283 => 126,  279 => 125,  269 => 124,  259 => 116,  244 => 114,  240 => 113,  231 => 109,  225 => 105,  217 => 104,  211 => 103,  205 => 102,  190 => 92,  182 => 89,  167 => 79,  154 => 71,  146 => 66,  143 => 65,  139 => 63,  133 => 61,  131 => 60,  122 => 54,  114 => 51,  104 => 46,  93 => 38,  83 => 31,  73 => 24,  65 => 18,  50 => 16,  46 => 15,  33 => 4,  30 => 3,);
    }
}
