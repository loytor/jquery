<?php

/* mall/setting.html */
class __TwigTemplate_0b43236d906921b0d9b2265e4b9a3de2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'style' => array($this, 'block_style'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "
<div class=\"well\">
\t<form class=\"form-horizontal\" action=\"\" method=\"post\">
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">外链地址</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<span style=\"line-height:30px;\">";
        // line 10
        echo (isset($context["url"]) ? $context["url"] : $this->getContext($context, "url"));
        echo "</span>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\" >是否开启</label>
\t\t\t<div class=\"controls\">
                <label class=\"radio inline\">
                    <input type=\"radio\" name=\"status\" ";
        // line 17
        if (($this->getAttribute((isset($context["mall"]) ? $context["mall"] : $this->getContext($context, "mall")), "status", array(), "array") == 1)) {
            echo "checked=\"checked\"";
        }
        echo " value=\"1\"> 开启
                </label>
                <label class=\"radio inline\">
                    <input type=\"radio\" name=\"status\" ";
        // line 20
        if (($this->getAttribute((isset($context["mall"]) ? $context["mall"] : $this->getContext($context, "mall")), "status", array(), "array") == 0)) {
            echo "checked=\"checked\"";
        }
        echo " value=\"0\"> 关闭
                </label>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">所属网站栏目</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<select name=\"cate_id\" class=\"span2\">
\t\t\t\t\t<option value=\"\">未归档</option>
\t\t\t\t\t";
        // line 29
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["cate_arr"]) ? $context["cate_arr"] : $this->getContext($context, "cate_arr")));
        foreach ($context['_seq'] as $context["_cate_id"] => $context["_cate"]) {
            // line 30
            echo "\t\t\t\t\t";
            if (((isset($context["_cate_id"]) ? $context["_cate_id"] : $this->getContext($context, "_cate_id")) == $this->getAttribute((isset($context["mall"]) ? $context["mall"] : $this->getContext($context, "mall")), "cate_id", array(), "array"))) {
                // line 31
                echo "\t\t\t\t\t<option value=\"";
                echo (isset($context["_cate_id"]) ? $context["_cate_id"] : $this->getContext($context, "_cate_id"));
                echo "\" selected=\"selected\">";
                echo $this->getAttribute((isset($context["_cate"]) ? $context["_cate"] : $this->getContext($context, "_cate")), "cate_name", array(), "array");
                echo "</option>
\t\t\t\t\t";
            } else {
                // line 33
                echo "\t\t\t\t\t<option value=\"";
                echo (isset($context["_cate_id"]) ? $context["_cate_id"] : $this->getContext($context, "_cate_id"));
                echo "\">";
                echo $this->getAttribute((isset($context["_cate"]) ? $context["_cate"] : $this->getContext($context, "_cate")), "cate_name", array(), "array");
                echo "</option>
\t\t\t\t\t";
            }
            // line 35
            echo "\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_cate_id'], $context['_cate'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 36
        echo "\t\t\t\t</select>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">商城标题</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<input type=\"text\" name=\"title\" value=\"";
        // line 42
        echo $this->getAttribute((isset($context["mall"]) ? $context["mall"] : $this->getContext($context, "mall")), "title", array(), "array");
        echo "\">
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">商城标题图</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<span class=\"help-block\"><span class=\"label\">建议图片尺寸1:1</span></span>
\t\t\t\t";
        // line 49
        if ((!twig_test_empty($this->getAttribute((isset($context["mall"]) ? $context["mall"] : $this->getContext($context, "mall")), "icon", array(), "array")))) {
            // line 50
            echo "\t\t\t\t<img src=\"";
            echo $this->getAttribute((isset($context["mall"]) ? $context["mall"] : $this->getContext($context, "mall")), "icon", array(), "array");
            echo "\" style=\"width:64px;height:64px;margin:8px;background: none;\" class=\"img-polaroid icon-preview\">
\t\t\t\t";
        } else {
            // line 52
            echo "\t\t\t\t<img src=\"/assets/img/no_image.png\" style=\"width:64px;height:64px;margin:8px;background: none;\" class=\"img-polaroid icon-preview\">
\t\t\t\t";
        }
        // line 54
        echo "\t\t\t\t<input type=\"button\" class=\"btn j_img_clear\" value=\"清空\" style=\"margin:50px 0 5px 10px;position:absolute;\" />
\t\t\t\t<input type=\"hidden\" name=\"icon\" id=\"input-icon\" value=\"";
        // line 55
        echo $this->getAttribute((isset($context["mall"]) ? $context["mall"] : $this->getContext($context, "mall")), "icon", array(), "array");
        echo "\">
\t\t\t\t<input type=\"file\" id=\"uploader-icon\">
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">商城简介</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<textarea type=\"text\" name=\"desc\">";
        // line 62
        echo $this->getAttribute((isset($context["mall"]) ? $context["mall"] : $this->getContext($context, "mall")), "desc", array(), "array");
        echo "</textarea>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">门店选择</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<table class=\"table\">
\t\t\t\t\t<tbody>
\t\t\t\t\t<tr>
\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t<div id=\"store-box\" class=\"address-list\">
\t\t\t\t\t\t\t\t";
        // line 73
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["selected_address"]) ? $context["selected_address"] : $this->getContext($context, "selected_address")));
        foreach ($context['_seq'] as $context["key"] => $context["adr"]) {
            // line 74
            echo "\t\t\t\t\t\t\t\t<label index=\"";
            echo (isset($context["key"]) ? $context["key"] : $this->getContext($context, "key"));
            echo "\" class=\"checkbox\">
\t\t\t\t\t\t\t\t\t<input name=\"adr_ids[]\" type=\"checkbox\" value=\"";
            // line 75
            echo $this->getAttribute((isset($context["adr"]) ? $context["adr"] : $this->getContext($context, "adr")), "id", array(), "array");
            echo "\" checked=\"checked\">
\t\t\t\t\t\t\t\t\t";
            // line 76
            echo $this->getAttribute((isset($context["adr"]) ? $context["adr"] : $this->getContext($context, "adr")), "name", array(), "array");
            echo "
\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['adr'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 79
        echo "\t\t\t\t\t\t\t\t";
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["unselect_address"]) ? $context["unselect_address"] : $this->getContext($context, "unselect_address")));
        foreach ($context['_seq'] as $context["k"] => $context["un_adr"]) {
            // line 80
            echo "\t\t\t\t\t\t\t\t<label index=\"";
            echo (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k"));
            echo "\" class=\"checkbox\">
\t\t\t\t\t\t\t\t\t<input name=\"adr_ids[]\" type=\"checkbox\" value=\"";
            // line 81
            echo $this->getAttribute((isset($context["un_adr"]) ? $context["un_adr"] : $this->getContext($context, "un_adr")), "id", array(), "array");
            echo "\">
\t\t\t\t\t\t\t\t\t";
            // line 82
            echo $this->getAttribute((isset($context["un_adr"]) ? $context["un_adr"] : $this->getContext($context, "un_adr")), "name", array(), "array");
            echo "
\t\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['k'], $context['un_adr'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 85
        echo "\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</td>
\t\t\t\t\t</tr>
\t\t\t\t\t<tr>
\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t<label class=\"checkbox\">
\t\t\t\t\t\t\t\t<input id=\"cb-all\" type=\"checkbox\" value=\"\">
\t\t\t\t\t\t\t\t全选
\t\t\t\t\t\t\t</label>
\t\t\t\t\t\t</td>
\t\t\t\t\t</tr>
\t\t\t\t\t</tbody>
\t\t\t\t</table>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">配送方式选择</label>
\t\t\t<div class=\"controls\">
\t\t\t\t";
        // line 103
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["ship_method"]) ? $context["ship_method"] : $this->getContext($context, "ship_method")));
        foreach ($context['_seq'] as $context["sk"] => $context["sm"]) {
            // line 104
            echo "\t\t\t\t<label class=\"checkbox inline\">
\t\t\t\t\t";
            // line 105
            if (($this->getAttribute((isset($context["mall"]) ? $context["mall"] : null), "ship_method", array(), "array", true, true) && twig_in_filter((isset($context["sk"]) ? $context["sk"] : $this->getContext($context, "sk")), $this->getAttribute((isset($context["mall"]) ? $context["mall"] : $this->getContext($context, "mall")), "ship_method", array(), "array")))) {
                // line 106
                echo "\t\t\t\t\t<input name=\"ship_method[]\" type=\"checkbox\" checked value=\"";
                echo (isset($context["sk"]) ? $context["sk"] : $this->getContext($context, "sk"));
                echo "\">
\t\t\t\t\t";
            } else {
                // line 108
                echo "\t\t\t\t\t<input name=\"ship_method[]\" type=\"checkbox\" value=\"";
                echo (isset($context["sk"]) ? $context["sk"] : $this->getContext($context, "sk"));
                echo "\">
\t\t\t\t\t";
            }
            // line 110
            echo "                    ";
            echo (isset($context["sm"]) ? $context["sm"] : $this->getContext($context, "sm"));
            echo "
\t\t\t\t</label>
\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['sk'], $context['sm'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 113
        echo "\t\t\t</div>
\t\t</div>

        <div class=\"control-group\">
            <label class=\"control-label\">请选择模板</label>
            <div class=\"controls\">
                <select name=\"theme\">
                    ";
        // line 120
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["mall_tpl"]) ? $context["mall_tpl"] : $this->getContext($context, "mall_tpl")));
        foreach ($context['_seq'] as $context["tk"] => $context["tv"]) {
            // line 121
            echo "                    <option value=\"";
            echo (isset($context["tk"]) ? $context["tk"] : $this->getContext($context, "tk"));
            echo "\" ";
            if (($this->getAttribute((isset($context["mall"]) ? $context["mall"] : $this->getContext($context, "mall")), "tpl", array(), "array") == (isset($context["tk"]) ? $context["tk"] : $this->getContext($context, "tk")))) {
                echo "selected";
            }
            echo ">";
            echo (isset($context["tv"]) ? $context["tv"] : $this->getContext($context, "tv"));
            echo "</option>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['tk'], $context['tv'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 123
        echo "                </select>
            </div>
        </div>

\t\t<div class=\"control-group\">
\t\t\t<div class=\"controls\">
\t\t\t\t<button type=\"submit\" class=\"btn btn-primary\">确认保存</button>
\t\t\t</div>
\t\t</div>
\t</form>
</div>
";
    }

    // line 136
    public function block_style($context, array $blocks = array())
    {
        // line 137
        echo "<link href=\"/assets/css/uploadify.css\" rel=\"stylesheet\">
<style type=\"text/css\">
\t.table td
\t{
\t\tborder: none;
\t}
\t.address-list
\t{
\t\tbackground-color: #FFFFFF;
\t\tborder: 2px solid #000000;
\t\tborder-radius: 6px 6px 6px 6px;
\t\tpadding: 10px;
\t\theight: 200px;
\t\toverflow-y: auto;
\t}
</style>
";
    }

    // line 155
    public function block_script($context, array $blocks = array())
    {
        // line 156
        echo "<script src=\"/assets/js/jquery.uploadify.min.js\"></script>
<script src=\"/assets/js/kindeditor/kindeditor-all-min.js\"></script>
<script src=\"/assets/js/kindeditor/lang/zh_CN.js\"></script>
<script type=\"text/javascript\">
\t\$(function() {
\t\tvar editor;
\t\tKindEditor.ready(function(K) {
\t\t\teditor = K.create('textarea[name=\"desc\"]', {
\t\t\t\tresizeType: 1,
\t\t\t\tpasteType: 1,
\t\t\t\tminWidth:430,
\t\t\t\tnewlineTag:'br',
\t\t\t\titems: ['undo', 'redo', '|', 'forecolor', 'hilitecolor', 'bold', 'italic', 'underline','strikethrough', 'removeformat', '|', 'justifyleft', 'justifycenter', 'justifyright', 'insertorderedlist', 'insertunorderedlist', 'hr']
\t\t\t});
\t\t});

\t\t\$('#uploader-icon').uploadify({
\t\t\t'fileObjName': 'image',
\t\t\t'fileSizeLimit': '2MB',
\t\t\t'fileTypeExts': '*.gif; *.jpg; *.png',
\t\t\t'multi': false,
\t\t\t'removeTimeout': 0,
\t\t\t'width': 90,
\t\t\t'height': 25,
\t\t\t'buttonText': '选择标题图',
\t\t\t'formData': {'token': '";
        // line 181
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
\t\t\t'swf': '/assets/js/uploadify.swf',
\t\t\t'uploader': '/image/upload_gd',
\t\t\t'onFallback': function() {
\t\t\t\talert('您的浏览器没有安装Flash插件');
\t\t\t},
\t\t\t'onUploadSuccess': function(file, data, response) {
\t\t\t\tif (response) {
\t\t\t\t\tvar ret = \$.parseJSON(data);
\t\t\t\t\tif (ret) {
\t\t\t\t\t\tif (ret.success) {
\t\t\t\t\t\t\t\$('#input-icon').val(ret.image);
\t\t\t\t\t\t\t\$('.icon-preview').attr('src', ret.image);
\t\t\t\t\t\t} else {
\t\t\t\t\t\t\talert(ret.message);
\t\t\t\t\t\t}
\t\t\t\t\t}
\t\t\t\t}
\t\t\t}
\t\t});

\t\t//全选
\t\t\$('#cb-all').click(function(){
\t\t\t\$('#store-box input[type=\"checkbox\"]').prop('checked', \$(this).prop('checked'))
\t\t});
\t});
</script>
";
    }

    public function getTemplateName()
    {
        return "mall/setting.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  351 => 181,  324 => 156,  321 => 155,  301 => 137,  298 => 136,  283 => 123,  268 => 121,  264 => 120,  255 => 113,  245 => 110,  239 => 108,  233 => 106,  231 => 105,  228 => 104,  224 => 103,  204 => 85,  195 => 82,  191 => 81,  186 => 80,  181 => 79,  172 => 76,  168 => 75,  163 => 74,  159 => 73,  145 => 62,  135 => 55,  132 => 54,  128 => 52,  122 => 50,  120 => 49,  110 => 42,  102 => 36,  96 => 35,  88 => 33,  80 => 31,  77 => 30,  73 => 29,  59 => 20,  51 => 17,  41 => 10,  33 => 4,  30 => 3,);
    }
}
