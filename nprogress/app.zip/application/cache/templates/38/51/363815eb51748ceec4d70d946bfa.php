<?php

/* custom/style.html */
class __TwigTemplate_3851363815eb51748ceec4d70d946bfa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>

<head>
\t<meta charset=\"utf-8\" />

\t<script type=\"text/javascript\" src=\"/assets/jshint/js/moo-clientcide-1.3.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/jshint/js/codemirror.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/jshint/js/javascript.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/jshint/js/css.js\"></script>

\t<script type=\"text/javascript\" src=\"/assets/jshint/js/LayoutCM.js\"></script>
\t<script type=\"text/javascript\" src=\"/assets/jshint/js/Actions.js\"></script>

\t<script type=\"text/javascript\" src=\"/assets/jshint/js/EditorCM.js\"></script>

\t<link href=\"/assets/css/bootstrap.min.css\" rel=\"stylesheet\">
\t<link href=\"/assets/css/bootstrap-responsive.min.css\" rel=\"stylesheet\">
    <link href=\"/assets/css/app.css?v=2.0\" rel=\"stylesheet\">

\t<link rel=\"stylesheet\" type=\"text/css\" href=\"/assets/jshint/css/codemirror.css\" />
\t<link rel=\"stylesheet\" type=\"text/css\" href=\"/assets/jshint/css/screen.css\"/>
\t<link rel=\"stylesheet\" type=\"text/css\" href=\"/assets/css/template-admin.css\"/>
\t<!--[if lte IE 7]>
\t<script src=\"/assets/jshint/js/lte-ie7.js\"></script>
\t<![endif]-->


\t<script type='text/javascript'>
\t\tvar codemirrorpath = \"\",
\t\t\t\tpanel_css = 'css',
\t\t\t\tcssTxt;

\t\tLayout.skin = \"\";// \"light\"
\t\twindow.addEvent('domready', function() {
\t\t\tcssTxt = new MooShellEditor.CSS(document.id('id_code_css'), {
\t\t\t\tlanguage: panel_css
\t\t\t}); // add user defined parameters
\t\t\tLayout.render();
\t\t\tdocument.getElementById('submit_btn_diy_css').onclick = function(){
\t\t\t\tvar diycss = cssTxt.editor.getValue();
\t\t\t\tdocument.getElementById('id_code_css').value = diycss;
\t\t\t\tdocument.getElementById('diycssform').submit();
\t\t\t}

\t\t});

\t</script>
\t<title>自定义样式</title>
\t<style type=\"text/css\">
\t\t.diy-ta{
\t\t\t\theight: 350px;
\t\t}
\t\t.container {
\t\t\tmargin: 0 auto;
\t\t}
\t\t.footer {
\t\t\theight: 40px;
\t\t\tline-height: 40px;
\t\t\tpadding-right: 20px;
\t\t\tpadding-left: 20px;
\t\t\tbackground-color: #1b1b1b;
\t\t\tbackground-image: -moz-linear-gradient(top, #222222, #111111);
\t\t\tbackground-image: -webkit-gradient(linear, 0 0, 0 100%, from(#222222), to(#111111));
\t\t\tbackground-image: -webkit-linear-gradient(top, #222222, #111111);
\t\t\tbackground-image: -o-linear-gradient(top, #222222, #111111);
\t\t\tbackground-image: linear-gradient(to bottom, #222222, #111111);
\t\t\tbackground-repeat: repeat-x;
\t\t\tborder-color: #252525;
\t\t\tfilter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff222222', endColorstr='#ff111111', GradientType=0);
\t\t\tcolor: #999;
\t\t\tfont-size: 12px;
\t\t\ttext-align: center;
\t\t}
\t\t.top-right {
\t\t\theight: 60px;
\t\t\tline-height: 60px;
\t\t\tfont-size: 12px;
\t\t}
\t\t.toolbar-item{
\t\t\twidth:100px;
\t\t}
\t</style>
</head>
<body>

";
        // line 87
        echo left_nav();
        echo "
<div class=\"main-right\">

    <ul class=\"breadcrumb clearfix\" style=\"line-height: 30px;\">

        <li><a href=\"/cate\">微网站</a> <span class=\"divider\">/</span></li>
        <li class=\"active\">自定义样式</li>

        <li class=\"pull-right\">
            设计人员工具：
            <a href=\"/custom_res\" class=\"btn\"><i class=\"icon-picture\"></i> 模版资源</a>
        </li>
    </ul>

<div style=\"width: 80%;\">

\t<div id=\"target-tpls\">
\t\t<div class=\"toolbar\">
\t\t\t";
        // line 105
        if (((isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")) == 0)) {
            // line 106
            echo "\t\t\t<div class=\"toolbar-item highlight\"><a href=\"/custom/style/\"> 微网站</a></div>
\t\t\t";
        } else {
            // line 108
            echo "\t\t\t<div class=\"toolbar-item\"><a href=\"/custom/style/\"> 微网站</a></div>
\t\t\t";
        }
        // line 110
        echo "\t\t\t";
        if (((isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")) == 1)) {
            // line 111
            echo "\t\t\t<div class=\"toolbar-item highlight\"><a href=\"/custom/style/?type=1\">会员卡</a></div>
\t\t\t";
        } else {
            // line 113
            echo "\t\t\t<div class=\"toolbar-item\"><a href=\"/custom/style/?type=1\">会员卡</a></div>
\t\t\t";
        }
        // line 115
        echo "\t\t\t";
        if (((isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")) == 2)) {
            // line 116
            echo "\t\t\t<div class=\"toolbar-item highlight\"><a href=\"/custom/style/?type=2\">预订预约</a></div>
\t\t\t";
        } else {
            // line 118
            echo "\t\t\t<div class=\"toolbar-item\"><a href=\"/custom/style/?type=2\">预订预约</a></div>
\t\t\t";
        }
        // line 120
        echo "            ";
        if (((isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")) == 5)) {
            // line 121
            echo "\t\t\t<div class=\"toolbar-item highlight\"><a href=\"/custom/style/?type=5\">微商城</a></div>
\t\t\t";
        } else {
            // line 123
            echo "\t\t\t<div class=\"toolbar-item\"><a href=\"/custom/style/?type=5\">微商城</a></div>
\t\t\t";
        }
        // line 125
        echo "            ";
        if (((isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")) == 10)) {
            // line 126
            echo "\t\t\t<div class=\"toolbar-item highlight\"><a href=\"/custom/style/?type=10\">微闯关</a></div>
\t\t\t";
        } else {
            // line 128
            echo "\t\t\t<div class=\"toolbar-item\"><a href=\"/custom/style/?type=10\">微闯关</a></div>
\t\t\t";
        }
        // line 130
        echo "            ";
        if (((isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")) == 7)) {
            // line 131
            echo "\t\t\t<div class=\"toolbar-item highlight\"><a href=\"/custom/style/?type=7\">微游戏</a></div>
\t\t\t";
        } else {
            // line 133
            echo "\t\t\t<div class=\"toolbar-item\"><a href=\"/custom/style/?type=7\">微游戏</a></div>
\t\t\t";
        }
        // line 135
        echo "            <!--";
        if (((isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")) == 4)) {
            // line 136
            echo "\t\t\t<div class=\"toolbar-item highlight\"><a href=\"/custom/style/?type=4\">微喜帖</a></div>
\t\t\t";
        } else {
            // line 138
            echo "\t\t\t<div class=\"toolbar-item\"><a href=\"/custom/style/?type=4\">微喜帖</a></div>
\t\t\t";
        }
        // line 139
        echo "-->
            ";
        // line 140
        if (((isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")) == 3)) {
            // line 141
            echo "\t\t\t<div class=\"toolbar-item highlight\"><a href=\"/custom/style/?type=3\">微团购</a></div>
\t\t\t";
        } else {
            // line 143
            echo "\t\t\t<div class=\"toolbar-item\"><a href=\"/custom/style/?type=3\">微团购</a></div>
\t\t\t";
        }
        // line 145
        echo "\t\t\t";
        if (((isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")) == 16)) {
            // line 146
            echo "\t\t\t<div class=\"toolbar-item highlight\"><a href=\"/custom/style/?type=16\">请柬</a></div>
\t\t\t";
        } else {
            // line 148
            echo "\t\t\t<div class=\"toolbar-item\"><a href=\"/custom/style/?type=16\">请柬</a></div>
\t\t\t";
        }
        // line 150
        echo "\t\t\t";
        if (((isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")) == 17)) {
            // line 151
            echo "\t\t\t<div class=\"toolbar-item highlight\"><a href=\"/custom/style/?type=17\">相册</a></div>
\t\t\t";
        } else {
            // line 153
            echo "\t\t\t<div class=\"toolbar-item\"><a href=\"/custom/style/?type=17\">相册</a></div>
\t\t\t";
        }
        // line 155
        echo "\t\t\t<!--<div class=\"toolbar-item detail\"></div>-->
\t\t</div>
\t\t<div class=\"template-box\">
\t\t\t<form method=\"post\" action=\"/custom/ajax_save_style\" id=\"diycssform\">
\t\t\t\t<div id=\"content\">
\t\t\t\t\t<fieldset class='column left' style=\"display:none;\">
\t\t\t\t\t\t<div class='window top' ></div>
\t\t\t\t\t</fieldset>
\t\t\t\t\t<fieldset class='column'>
\t\t\t\t\t\t<div class='window top' id=\"panel_css\" data-panel_type=\"css\">
\t\t\t\t\t\t\t<textarea id=\"id_code_css\" name=\"diyCss\" class=\"diy-ta\">";
        // line 165
        if ($this->getAttribute((isset($context["diycss"]) ? $context["diycss"] : null), "css", array(), "array", true, true)) {
            echo $this->getAttribute((isset($context["diycss"]) ? $context["diycss"] : $this->getContext($context, "diycss")), "css", array(), "array");
        }
        echo "</textarea>
\t\t\t\t\t\t\t<input type=\"hidden\" name=\"csstype\" value=\"";
        // line 166
        echo (isset($context["type"]) ? $context["type"] : $this->getContext($context, "type"));
        echo "\">
\t\t\t\t\t\t\t<span class='window_label'>CSS</span>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class='handler handler_horizontal'></div>
\t\t\t\t\t</fieldset>
\t\t\t\t</div>
\t\t\t\t<button type=\"button\" class=\"btn btn-primary\" id=\"submit_btn_diy_css\" ><i class=\"icon-edit icon-white\"></i> 确认保存</button>
\t\t\t</form>

\t\t</div>
\t</div>

</div>
</div>
</body>
</html>
";
    }

    public function getTemplateName()
    {
        return "custom/style.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  257 => 166,  251 => 165,  239 => 155,  235 => 153,  231 => 151,  228 => 150,  224 => 148,  220 => 146,  217 => 145,  213 => 143,  209 => 141,  207 => 140,  204 => 139,  200 => 138,  196 => 136,  193 => 135,  189 => 133,  185 => 131,  182 => 130,  178 => 128,  174 => 126,  171 => 125,  167 => 123,  163 => 121,  160 => 120,  156 => 118,  152 => 116,  149 => 115,  145 => 113,  141 => 111,  138 => 110,  134 => 108,  130 => 106,  128 => 105,  107 => 87,  19 => 1,);
    }
}
