<?php

/* custom/home.html */
class __TwigTemplate_715573601e065f84ee81988d300a5a8e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <title>自定义首页</title>
    <script type=\"text/javascript\" src=\"/assets/codemirror/codemirror.js\"></script>
    <link href=\"/assets/css/bootstrap.min.css\" rel=\"stylesheet\">
    <link href=\"/assets/css/bootstrap-responsive.min.css\" rel=\"stylesheet\">
    <link href=\"/assets/css/app.css?v=2.0\" rel=\"stylesheet\">
    <script type=\"text/javascript\" src=\"/assets/js/jquery.min.js\" charset=\"utf-8\" ></script>
</head>
<body>

";
        // line 13
        echo left_nav();
        echo "
<div class=\"main-right\">
    <div>
        <ul class=\"breadcrumb clearfix\" style=\"line-height: 30px;\">

            <li><a href=\"/cate\">微网站</a> <span class=\"divider\">/</span></li>
            <li class=\"active\">自定义首页</li>

            <li class=\"pull-right\">
                设计人员工具：
                <a href=\"/custom_res\" class=\"btn\"><i class=\"icon-picture\"></i> 模版资源</a>
            </li>
        </ul>

        <div class=\"template-box\">
            <form method=\"post\" action=\"\">
                <div class=\"control-group\" style=\"position: relative\">
                    <div class=\"controls\">
                        <div style=\"border: 1px solid #c0C0C0; padding: 8px;width: 70%;\">
                        <textarea rows=\"2\" name=\"content\" id=\"code\" style=\"width:98%;height:320px;\">";
        // line 32
        echo $this->getAttribute((isset($context["page"]) ? $context["page"] : $this->getContext($context, "page")), "content", array(), "array");
        echo "</textarea>
                        </div>
                    </div>

                    ";
        // line 36
        if ($this->getAttribute((isset($context["page"]) ? $context["page"] : $this->getContext($context, "page")), "content", array(), "array")) {
            // line 37
            echo "                    <div style=\"position: absolute; right:32px; top: 0px;width: 19%\">
                        <div style=\"text-align:center\"><a href=\"";
            // line 38
            echo (isset($context["preview"]) ? $context["preview"] : $this->getContext($context, "preview"));
            echo "\" target=\"_blank\"> <img src=\"/custom/qrcode\" width=\"100%\"></a></div>
                        <div class=\"controls alert\">
                            扫描或点击二维码，可查看效果
                            <br/><br/>
                            <b>温馨提示：只有发布过后才能正常使用自定义首页模板</b>
                        </div>
                    </div>
                    ";
        }
        // line 46
        echo "                </div>
                <button type=\"submit\" class=\"btn btn-primary\">确认保存</button>&nbsp;&nbsp;&nbsp;&nbsp;
                <button type=\"button\" class=\"btn btn-primary btn btn-success\" id=\"submit_pub_btn\" ><i class=\"icon-edit icon-white\"></i> 发布</button>
                <span class=\"alert-danger J-msg-notice\"></span>
            </form>
        </div>
    </div>
</div>

<script type=\"text/javascript\">
    var editor = CodeMirror.fromTextArea('code', {
        height: \"350px\",
        parserfile: \"http://www.bama555.com/assets/codemirror/parsexml.js\",
        stylesheet: \"http://www.bama555.com/assets/codemirror/xmlcolors.css\",
        path: \"js/\",
        continuousScanning: 500,
        lineWrapping: true,
        lineNumbers: true
    });

    \$(function() {
        \$('.main-right').on('click','#submit_pub_btn',function(){
            var self = \$(this);
            self.attr('disabled',true).html('正在发布，请稍后...');
            \$.getJSON('/custom/ajax_pub_home','',function(data){
                \$('.J-msg-notice').html(data.msg);
                self.attr('disabled',false).html('<i class=\"icon-edit icon-white\"></i> 发布');
            });

        });
    });

</script>
</body>
</html>
";
    }

    public function getTemplateName()
    {
        return "custom/home.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 46,  67 => 38,  64 => 37,  62 => 36,  55 => 32,  33 => 13,  19 => 1,);
    }
}
