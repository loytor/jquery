<?php

/* assist/add.html */
class __TwigTemplate_415453cb40f5d2d6c06402d667ee9a7e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'style' => array($this, 'block_style'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "<ul class=\"breadcrumb clearfix\">
    <a href=\"/assist/setting\" class=\"btn\"><i class=\"icon-cog\"></i> 基本设置</a>
    <a href=\"/assist\" class=\"btn\"><i class=\"icon-list\"></i> 辅助按钮列表</a>
    <a href=\"/assist/add\" class=\"btn btn-primary pull-right\"><i class=\"icon-plus icon-white\"></i> 添加辅助按钮</a>
</ul>
<div class=\"well\">
\t<form class=\"form-horizontal\" action=\"\" method=\"post\">
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\" for=\"input-title\">标题</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<input type=\"text\" name=\"title\" id=\"input-title\">
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">图标</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<span class=\"help-block\"><span class=\"label\">推荐尺寸：64×64</span></span>
\t\t\t\t<img src=\"/assets/img/no_image.png\" class=\"img-polaroid\" id=\"icon-preview\">
\t\t\t\t<input type=\"hidden\" name=\"icon\" id=\"input-icon\">
\t\t\t\t<div id=\"uploader-icon\"></div>
\t\t\t\t<a class=\"btn btn-success\" onclick=\"show_icons_sys()\">选择系统图标</a>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">类型</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<select name=\"type\" id=\"select-type\">
\t\t\t\t\t";
        // line 31
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["types"]) ? $context["types"] : $this->getContext($context, "types")));
        foreach ($context['_seq'] as $context["k"] => $context["t"]) {
            // line 32
            echo "\t\t\t\t\t<option value=\"";
            echo (isset($context["k"]) ? $context["k"] : $this->getContext($context, "k"));
            echo "\">";
            echo (isset($context["t"]) ? $context["t"] : $this->getContext($context, "t"));
            echo "</option>
\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['k'], $context['t'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 34
        echo "\t\t\t\t</select>
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\" id=\"content-label\">电话</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<input type=\"text\" name=\"content\">
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\" for=\"input-rank\">排序</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<input type=\"text\" name=\"rank\" id=\"input-rank\">
\t\t\t</div>
\t\t</div>
\t\t<div class=\"control-group\">
\t\t\t<div class=\"controls\">
\t\t\t\t<button type=\"submit\" class=\"btn btn-primary\">确认保存</button>
\t\t\t</div>
\t\t</div>
\t</form>
</div>
";
    }

    // line 58
    public function block_style($context, array $blocks = array())
    {
        // line 59
        echo "<link href=\"/assets/huploadify/Huploadify.css\" rel=\"stylesheet\">
<link href=\"/assets/css/icons_sys.css\" rel=\"stylesheet\">
<style type=\"text/css\">
\t.table td
\t{
\t\tbackground-color: #FFFFFF;
\t}
\t#icon-preview {
\t\tmargin: 10px 0;
\t\tbackground-color: #bababa;
\t}
    .uploadify-button{
        color: #333;
        background-color: #fff;
        border-color: #ccc;
        cursor:pointer;
        text-decoration:none;
        border-radius: 2px;
        margin-left: 0;
    }
    .uploadify-button:hover {
        background-color: #ccc;
        background-image: none;
        background-position: center bottom;
        cursor:pointer;
        text-decoration:none;
    }
</style>
";
    }

    // line 89
    public function block_script($context, array $blocks = array())
    {
        // line 90
        echo "<script src=\"/assets/huploadify/jquery.Huploadify.js\"></script>
<script src=\"/assets/js/icons_sys.js\"></script>
<script type=\"text/javascript\">
\$(function() {
\t\$('#uploader-icon').Huploadify({
        'fileObjName': 'image',
        'fileSizeLimit': 2048,
        'fileTypeExts': '*.gif; *.jpg; *.png',
        'multi': false,
        'auto':true,
        'showUploadedPercent':false,
        'removeTimeout': 0,
\t\t'buttonText': '上传图片',
\t\t'formData': {'token': '";
        // line 103
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
\t\t'uploader': '/image/upload_assist',
\t\t'onUploadSuccess': function(file, data) {
            var ret = \$.parseJSON(data);
            if (ret) {
                if (ret.success) {
                    \$('#input-icon').val(ret.image);
                    \$('#icon-preview').attr('src', ret.image);
                } else {
                    alert(ret.message);
                }
            }
\t\t}
\t});

\t\$('#select-type').change(function(){
\t\tvar label = \$(this).find(\"option:selected\").text();
\t\t\$('#content-label').html(label);
\t\tif(label == '外链')
\t\t{
\t\t\t\$('input[name=\"content\"]').attr('placeholder', 'http://');
\t\t}
\t\telse
\t\t{
\t\t\t\$('input[name=\"content\"]').removeAttr('placeholder');
\t\t}
\t});
});

function show_icons_sys(){
\twindow.SysIconDialog.showDialog(function (id, url, type_id) {//id=图标id，也许需要   url=图标路径  type_id=所在分组id
\t\t\$('#input-icon').val(url);
\t\t\$('#icon-preview').attr('src', url);
\t});
}
</script>
";
    }

    public function getTemplateName()
    {
        return "assist/add.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  156 => 103,  141 => 90,  138 => 89,  106 => 59,  103 => 58,  77 => 34,  66 => 32,  62 => 31,  33 => 4,  30 => 3,);
    }
}
