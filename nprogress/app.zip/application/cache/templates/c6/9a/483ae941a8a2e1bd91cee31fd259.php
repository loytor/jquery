<?php

/* mall/cate.html */
class __TwigTemplate_c69a483ae941a8a2e1bd91cee31fd259 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "
\t<table class=\"table table-hover table-bordered\">
\t\t<thead>
\t\t<tr>
\t\t\t<th colspan=\"6\" style=\"text-align: center; font-size:16px;\">
\t\t\t\t商品分类
\t\t\t\t<a class=\"btn btn-primary pull-right\" href=\"/mall/cate_add\"><i class=\"icon-plus icon-white\"></i> 添加分类</a>
\t\t\t</th>
\t\t</tr>
\t\t<tr style=\"background-color:#EEEEEE;\">
\t\t\t<th>#</th>
\t\t\t<th>分类图片</th>
\t\t\t<th>分类名称</th>
\t\t\t<th></th>
\t\t</tr>
\t\t</thead>
\t\t<tbody>
\t\t";
        // line 21
        if ((!twig_test_empty((isset($context["list"]) ? $context["list"] : $this->getContext($context, "list"))))) {
            // line 22
            echo "\t\t";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["list"]) ? $context["list"] : $this->getContext($context, "list")));
            foreach ($context['_seq'] as $context["key"] => $context["row"]) {
                // line 23
                echo "\t\t<tr>
\t\t\t<td>";
                // line 24
                echo ((((isset($context["per_page"]) ? $context["per_page"] : $this->getContext($context, "per_page")) * ((isset($context["page"]) ? $context["page"] : $this->getContext($context, "page")) - 1)) + (isset($context["key"]) ? $context["key"] : $this->getContext($context, "key"))) + 1);
                echo "</td>
\t\t\t<td>
\t\t\t\t";
                // line 26
                if ((!twig_test_empty($this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "img", array(), "array")))) {
                    // line 27
                    echo "\t\t\t\t<img style=\"width:64px; height:64px\" src=\"";
                    echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "img", array(), "array");
                    echo "\">
\t\t\t\t";
                }
                // line 29
                echo "\t\t\t</td>
\t\t\t<td>";
                // line 30
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "name", array(), "array");
                echo "</td>
\t\t\t<td>
\t\t\t\t<a class=\"btn btn-small\" href=\"/mall/cate_edit/";
                // line 32
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "id", array(), "array");
                echo "\"><i class=\"icon-edit\"></i> 编辑</a>
\t\t\t\t<a data-id=\"";
                // line 33
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "id", array(), "array");
                echo "\" class=\"btn btn-small btn-delete\"><i class=\"icon-trash\"></i> 删除</a>
\t\t\t</td>
\t\t</tr>
\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 37
            echo "\t\t";
        } else {
            // line 38
            echo "\t\t<tr><td colspan=\"6\" style=\"text-align: center;\">尚无分类</td></tr>
\t\t";
        }
        // line 40
        echo "\t\t</tbody>
\t</table>
</form>
";
        // line 43
        echo (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination"));
        echo "
";
    }

    // line 46
    public function block_script($context, array $blocks = array())
    {
        // line 47
        echo "<script type=\"text/javascript\">
\$(function(){
\t\$(\".btn-delete\").click(function(){
\t\tif (confirm(\"删除分类会对该分类下的商品产生影响,您确定删除该分类吗？\")) {
\t\t\tvar id = \$(this).attr('data-id');
\t\t\tlocation.href = '/mall/cate_del/'+id;
\t\t}
\t});
});
</script>
";
    }

    public function getTemplateName()
    {
        return "mall/cate.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 47,  114 => 46,  108 => 43,  103 => 40,  99 => 38,  96 => 37,  86 => 33,  82 => 32,  77 => 30,  74 => 29,  68 => 27,  66 => 26,  61 => 24,  58 => 23,  53 => 22,  51 => 21,  32 => 4,  29 => 3,);
    }
}
