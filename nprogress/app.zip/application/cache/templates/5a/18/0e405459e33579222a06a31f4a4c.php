<?php

/* marketing_vote/update.html */
class __TwigTemplate_5a180e405459e33579222a06a31f4a4c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'style' => array($this, 'block_style'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "
<ul class=\"breadcrumb clearfix\">
\t<li><a href=\"/marketing_vote\">微信投票</a> <span class=\"divider\">/</span></li>
\t<li class=\"active\">编辑微信投票</li>
</ul>
<ul class=\"clearfix activity-instruction\">
\t微信投票相关介绍
</ul>
<div class=\"well\">    
    <p style=\"text-align:left;\">
        <span class=\"activity-info\">活动信息：</span>
    </p>    
\t<form class=\"form-horizontal\" action=\"\" method=\"post\">
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\" for=\"input-instruction\">投票活动说明</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<textarea class=\"span4\" id=\"input-instruction\" name=\"instruction\">";
        // line 20
        echo $this->getAttribute((isset($context["marketing"]) ? $context["marketing"] : $this->getContext($context, "marketing")), "instruction", array(), "array");
        echo "</textarea>
\t\t\t\t<p>限200字以内</p>
\t\t\t</div>
\t\t</div>
\t\t<a id=\"updatetime\"></a>
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">投票活动时间</label>
\t\t\t<div class=\"controls\">
\t\t\t\t";
        // line 28
        if ($this->getAttribute((isset($context["errors"]) ? $context["errors"] : null), "dt_start", array(), "array", true, true)) {
            // line 29
            echo "\t\t\t\t";
            echo $this->getAttribute((isset($context["errors"]) ? $context["errors"] : $this->getContext($context, "errors")), "dt_start", array(), "array");
            echo "
\t\t\t\t";
        }
        // line 31
        echo "\t\t\t\t<input type=\"text\" name=\"dt_start\" placeholder=\"点击选择开始时间\" value=\"";
        echo $this->getAttribute((isset($context["marketing"]) ? $context["marketing"] : $this->getContext($context, "marketing")), "dt_start", array(), "array");
        echo "\" id=\"statdate\" />
           \t\t 到
            \t<input type=\"text\" name=\"dt_end\" placeholder=\"点击选择结束时间\" value=\"";
        // line 33
        echo $this->getAttribute((isset($context["marketing"]) ? $context["marketing"] : $this->getContext($context, "marketing")), "dt_end", array(), "array");
        echo "\" id=\"enddate\" />\t
\t\t\t</div>
\t\t</div>
\t\t
\t\t<div class=\"control-group\">
\t\t\t<label class=\"control-label\">设置投票项目</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<table cellpadding=\"5px\" id=\"vote-settings\">
\t\t\t\t\t<thead>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<th>回复选项</th>
\t\t\t\t\t\t\t<th class=\"text-left\">对应投票内容</th>
\t\t\t\t\t\t\t<th></th>
\t\t\t\t\t\t</tr>
\t\t\t\t\t</thead>
\t\t\t\t\t<tbody>
\t\t\t\t\t\t";
        // line 49
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["marketing"]) ? $context["marketing"] : $this->getContext($context, "marketing")), "vote_setting", array(), "array"));
        foreach ($context['_seq'] as $context["key"] => $context["_vote_setting_item"]) {
            // line 50
            echo "\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t<input type=\"text\" name=\"vote_setting[";
            // line 52
            echo (isset($context["key"]) ? $context["key"] : $this->getContext($context, "key"));
            echo "][choice]\" value=\"";
            echo $this->getAttribute((isset($context["_vote_setting_item"]) ? $context["_vote_setting_item"] : $this->getContext($context, "_vote_setting_item")), "choice", array(), "array");
            echo "\" disabled=\"disabled\" style=\"width:50px; text-align:center;\" />
\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t<input type=\"text\" name=\"vote_setting[";
            // line 55
            echo (isset($context["key"]) ? $context["key"] : $this->getContext($context, "key"));
            echo "][content]\" value=\"";
            echo $this->getAttribute((isset($context["_vote_setting_item"]) ? $context["_vote_setting_item"] : $this->getContext($context, "_vote_setting_item")), "content", array(), "array");
            echo "\" maxlength=\"20\"/>
\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['_vote_setting_item'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 60
        echo "\t\t\t\t\t</tbody>
\t\t\t\t\t<tfoot>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<td><a href=\"javascript:void(0)\" id=\"add-item\">增加一项</a></td>
\t\t\t\t\t\t\t<td>（至少2项，每项最多20字。）</td>
\t\t\t\t\t\t\t<td></td>
\t\t\t\t\t\t</tr>
\t\t\t\t\t\t<tr><td colspan=\"3\"><span class=\"label label-important\">由于微信限制了回复的消息内容长度不超过2048字节, 所以请勿填写过多选项!</span></td></tr>
\t\t\t\t\t</tfoot>
\t\t\t\t</table>
\t\t\t</div>
\t\t</div>
        
        <div class=\"control-group\">
\t\t\t<div class=\"controls\">
\t\t\t\t<input type=\"file\" name=\"userfile\" id=\"uploader-start-xls\" />
\t\t\t\t<span class=\"red\">支持excel批量导入（<a data-toggle=\"modal\" href=\"#guide_5\">点击查看表格格式</a>）</span>
\t\t\t</div>
\t\t </div>
         
        <div class=\"control-group\">
\t\t\t<label class=\"control-label\">单选/多选</label>
\t\t\t<div class=\"controls\">\t\t\t
\t\t\t\t<input type=\"radio\" name=\"choice[type]\" ";
        // line 83
        if (($this->getAttribute($this->getAttribute((isset($context["marketing"]) ? $context["marketing"] : $this->getContext($context, "marketing")), "choice", array(), "array"), "type", array(), "array") == 0)) {
            echo "checked=\"checked\"";
        }
        echo " value=\"0\" /> 单选
\t\t\t\t&nbsp;&nbsp;\t\t
\t\t\t\t<input type=\"radio\" name=\"choice[type]\" ";
        // line 85
        if (($this->getAttribute($this->getAttribute((isset($context["marketing"]) ? $context["marketing"] : $this->getContext($context, "marketing")), "choice", array(), "array"), "type", array(), "array") == 1)) {
            echo "checked=\"checked\"";
        }
        echo " value=\"1\" /> 多选 : 最多可选 <input type=\"text\" name=\"choice[number]\" style=\"width:40px; text-align:center;\" value=\"";
        echo $this->getAttribute($this->getAttribute((isset($context["marketing"]) ? $context["marketing"] : $this->getContext($context, "marketing")), "choice", array(), "array"), "number", array(), "array");
        echo "\" /> 项
\t\t\t</div>
\t\t</div>
        <div class=\"control-group\">
\t\t\t<label class=\"control-label\">投票结果</label>
\t\t\t<div class=\"controls\">
\t\t\t\t<input type=\"checkbox\" id=\"display\" name=\"display\" ";
        // line 91
        if (($this->getAttribute((isset($context["marketing"]) ? $context["marketing"] : $this->getContext($context, "marketing")), "display", array(), "array") == 1)) {
            echo "checked=\"checked\"";
        }
        echo " value=\"1\" style=\"float:left\" /><label for=\"display\" style=\"float:left;padding-left:5px\">投票前可见</label>
\t\t\t</div>
\t\t</div>
        
\t\t<div class=\"control-group\">
            <label class=\"control-label\">规则设置</label>
            <div class=\"controls\">
\t            活动期间每个用户ID，每
\t            <input type=\"text\" name=\"rule\" value=\"";
        // line 99
        echo $this->getAttribute((isset($context["marketing"]) ? $context["marketing"] : $this->getContext($context, "marketing")), "rule", array(), "array");
        echo "\" style=\"width:30px;\" />
                <div id=\"single-box\" ";
        // line 100
        if (($this->getAttribute($this->getAttribute((isset($context["marketing"]) ? $context["marketing"] : $this->getContext($context, "marketing")), "choice", array(), "array"), "type", array(), "array") == 1)) {
            echo "style=\"display:none;\"";
        } else {
            echo "style=\"display:inline-block;\"";
        }
        echo " >
\t            天限参与<input type=\"text\" name=\"rule_jnum\" value=\"";
        // line 101
        echo $this->getAttribute((isset($context["marketing"]) ? $context["marketing"] : $this->getContext($context, "marketing")), "rule_jnum", array(), "array");
        echo "\" style=\"width:30px;\" >次
                </div>
\t            <div id=\"multi-box\" ";
        // line 103
        if (($this->getAttribute($this->getAttribute((isset($context["marketing"]) ? $context["marketing"] : $this->getContext($context, "marketing")), "choice", array(), "array"), "type", array(), "array") == 0)) {
            echo "style=\"display:none;\"";
        } else {
            echo "style=\"display:inline-block;\"";
        }
        echo ">
\t            天限参与1次
\t            </div>
            </div>
\t\t</div>
\t\t
\t\t<div class=\"control-group\">
\t\t\t<div class=\"controls\">
\t\t\t\t<button type=\"submit\" class=\"btn btn-primary\">确认保存</button>
\t\t\t</div>
\t\t</div>
\t</form>
</div>

<div id=\"guide_5\" class=\"modal hide fade\" tabindex=\"-1\">
\t<div class=\"modal-body\">
\t\t<img src=\"/assets/img/xls.png\">
\t</div>
\t<div class=\"modal-footer\">
\t\t<button class=\"btn\" data-dismiss=\"modal\" aria-hidden=\"true\">关闭</button>
\t</div>
</div>

";
    }

    // line 128
    public function block_style($context, array $blocks = array())
    {
        // line 129
        echo "<link href=\"/assets/css/uploadify.css\" rel=\"stylesheet\" />
";
    }

    // line 132
    public function block_script($context, array $blocks = array())
    {
        // line 133
        echo "<script src=\"/assets/js/lhgcalendar.min.js\"></script>
<script src=\"/assets/js/jquery.uploadify.min.js\"></script>

<script type=\"text/javascript\">
\$(function() {
    \$('#statdate').calendar({format:'yyyy-MM-dd HH:mm:ss' });
    \$('#enddate').calendar({ format:'yyyy-MM-dd HH:mm:ss',minDate:'#statdate' });
    
    \$('#add-item').click(function(){
    \tvar i = \$('#vote-settings tbody').children('tr').length;
    \tvar item = \"<tr>\";
    \t\titem +=\t\"<td><input type='text' name='vote_setting[\"+i+\"][choice]' style='width:50px; text-align:center;' /></td>\";
    \t\titem += \"<td><input type='text' name='vote_setting[\"+i+\"][content]' placeholder='输入投票内容...' maxlength='20'/></td>\";
\t\t\titem += \"<td><a href='javascript:void(0)' class='del-item'>删除</a></td>\";
\t\t\titem += \"</tr>\";
\t\t
\t\t\$('#vote-settings tbody').append(item);
    });
    
    \$('#vote-settings').on('click', 'a.del-item', function(){
    \tif(\$('#vote-settings tbody').children('tr').length <= 2){
    \t\talert('至少需要2项.');
    \t\treturn;
    \t}
     \t\$(this).parent('td').parent('tr').remove();
    });
    
    //批量导入
    \$('#uploader-start-xls').uploadify({
\t\t'fileObjName': 'userfile',
\t\t'fileSizeLimit': '2MB',
        'fileTypeExts': '*.xls; *.xlsx',
\t\t'multi': false,
\t\t'removeTimeout': 0,
\t\t'width': 90,
\t\t'height': 25,
\t\t'buttonText': '批量导入',
\t\t'formData': {'token': '";
        // line 170
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
\t\t'swf': '/assets/js/uploadify.swf',
\t\t'uploader': '/xls/upload',
\t\t'onFallback': function() {
\t\t\talert('您的浏览器没有安装Flash插件');
\t\t},
\t\t'onUploadSuccess': function(file, data, response) {
\t\t\tif (response) {
\t\t\t\tvar ret = \$.parseJSON(data);
\t\t\t\tif (ret) {
\t\t\t\t\tif (ret.success) {
                        var votehtml = '';
                        var trlength = \$('#vote-settings tbody').children('tr').length;
                        \$.each(ret.data, function(i, item){        
                          votehtml += '<tr><td><input type=\"text\" style=\"width:50px; text-align:center;\" value=\"'+ item['0'] +'\" name=\"vote_setting['+trlength+'][choice]\"></td><td><input type=\"text\" maxlength=\"20\" value=\"'+ item['1'] +'\" name=\"vote_setting['+trlength+'][content]\"></td><td><a class=\"del-item\" href=\"javascript:void(0)\">删除</a></td></tr>';
                          trlength++;
                    \t});
                        
                        \$('#vote-settings tbody').append(votehtml);
\t\t\t\t\t} else {
\t\t\t\t\t\talert(ret.message);
\t\t\t\t\t}
\t\t\t\t}
                
\t\t\t}
\t\t}
\t});

\t\$('input[name=\"choice[type]\"]').change(function(){
\t\tvar val = \$(this).val();
\t\tif(val == 0) {
\t\t\t\$('#single-box').css('display', 'inline-block');
\t\t\t\$('#multi-box').hide();
\t\t} else {
\t\t\t\$('#multi-box').css('display', 'inline-block');
\t\t\t\$('#single-box').hide();
\t\t}
\t});
});
</script>
";
    }

    public function getTemplateName()
    {
        return "marketing_vote/update.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  281 => 170,  242 => 133,  239 => 132,  234 => 129,  231 => 128,  199 => 103,  194 => 101,  186 => 100,  182 => 99,  169 => 91,  156 => 85,  149 => 83,  124 => 60,  111 => 55,  103 => 52,  99 => 50,  95 => 49,  76 => 33,  70 => 31,  64 => 29,  62 => 28,  51 => 20,  33 => 4,  30 => 3,);
    }
}
