<?php

/* cate/add.html */
class __TwigTemplate_39ddc3ce3cc5c4c98e34f6c5efea8ae9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'style' => array($this, 'block_style'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "<ul class=\"breadcrumb clearfix\">
\t<li><a href=\"/cate\">栏目管理</a> <span class=\"divider\">/</span></li>
\t<li class=\"active\">添加栏目</li>
</ul>
<div class=\"well\">
\t<div class=\"row-fluid\">
\t\t<div class=\"span8\">
\t\t\t<form class=\"form-horizontal\" action=\"\" method=\"post\">
\t\t\t\t";
        // line 12
        if ((!twig_test_empty((isset($context["parent_cate"]) ? $context["parent_cate"] : $this->getContext($context, "parent_cate"))))) {
            // line 13
            echo "\t\t\t\t<div class=\"control-group\">
\t\t\t\t\t<label class=\"control-label\">上级栏目</label>
\t\t\t\t\t<label style=\"text-align: left;margin-left: 20px;\" class=\"control-label\">";
            // line 15
            echo $this->getAttribute((isset($context["parent_cate"]) ? $context["parent_cate"] : $this->getContext($context, "parent_cate")), "cate_name", array(), "array");
            echo "</label>
\t\t\t\t</div>
\t\t\t\t";
        } else {
            // line 18
            echo "\t\t\t\t<div class=\"control-group\">
\t\t\t\t\t<label class=\"control-label\">上级栏目</label>
\t\t\t\t\t<div class=\"controls\">
\t\t\t\t\t\t<select name=\"parent_id\" class=\"input-medium\">
\t\t\t\t\t\t\t<option value=\"0\">顶级栏目</option>
\t\t\t\t\t\t\t";
            // line 23
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["cate_arr"]) ? $context["cate_arr"] : $this->getContext($context, "cate_arr")));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 24
                echo "\t\t\t\t\t\t\t<option value=\"";
                echo $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "id", array(), "array");
                echo "\">";
                echo $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "text", array(), "array");
                echo "</option>
\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 26
            echo "\t\t\t\t\t\t</select>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t";
        }
        // line 30
        echo "\t\t\t\t<div class=\"control-group\">
\t\t\t\t\t<label class=\"control-label\" for=\"input-cate_name\">栏目名称</label>
\t\t\t\t\t<div class=\"controls\">
\t\t\t\t\t\t<input type=\"text\" name=\"cate_name\" id=\"input-cate_name\" style=\"width:200px\">
\t\t\t\t\t\t<span class=\"help-inline\"><span class=\"label\">建议10个汉字以内</span></span>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"control-group\">
\t\t\t\t\t<label class=\"control-label\" for=\"input-description\">栏目描述</label>
\t\t\t\t\t<div class=\"controls\">
\t\t\t\t\t\t<input type=\"text\" name=\"description\" id=\"input-description\" style=\"width:250px\">
\t\t\t\t\t\t<span class=\"help-inline\"><span class=\"label\">建议13个汉字以内</span></span>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"control-group\">
\t\t\t\t\t<label class=\"control-label\" for=\"input-image\">栏目图片</label>
\t\t\t\t\t<div class=\"controls\">
\t\t\t\t\t\t<img src=\"/assets/img/no_image.png\" class=\"img-polaroid\" id=\"image-preview\">
                        <input type=\"button\" class=\"btn j_img_clear\" value=\"清空\" style=\"margin:0 0 5px 10px;\" />
\t\t\t\t\t\t<input type=\"hidden\" name=\"image\" id=\"input-image\">
\t\t\t\t\t\t<div id=\"uploader-image\"></div>
\t\t\t\t\t\t<a class=\"btn btn-success\" onclick=\"show_icons_sys()\">选择系统图标</a>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"control-group\" id=\"control_show_url\">
\t\t\t\t\t<div class=\"controls\">
\t\t\t\t\t\t<a href=\"#\" id=\"show_url\"><span class=\"label\"><i class=\"icon-share icon-white\"></i> 指向外部链接</span></a>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"control-group hide\" id=\"control_url\">
\t\t\t\t\t<label class=\"control-label\" for=\"input-url\">外部链接</label>
\t\t\t\t\t<div class=\"controls\">
\t\t\t\t\t\t<input type=\"text\" name=\"url\" id=\"input-url\" class=\"span4\" placeholder=\"http://\">
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"control-group\">
\t\t\t\t\t<label class=\"control-label\" for=\"input-description\">是否在首页显示</label>
\t\t\t\t\t<div class=\"controls\">
\t\t\t\t\t\t<label for=\"display-yes\" style=\"display:inline-block;\">是</label><input id=\"display-yes\" type=\"radio\" checked=\"checked\" name=\"display\" value=\"0\" />
\t\t\t\t\t\t<label for=\"display-no\" style=\"display:inline-block;\">否</label><input id=\"display-no\" type=\"radio\" name=\"display\" value=\"1\" />
\t\t\t\t\t</div>
\t\t\t\t</div>
                
                <div class=\"control-group\">
                    <label class=\"control-label\" for=\"input-image\">查看权限</label>
                    <div class=\"controls\">
                        <select name=\"level_type\" style=\"width:120px;\" class=\"j_level_type\" >
                        <option value=\"0\">匿名用户</option>
                        <option value=\"1\">关注用户</option>
                        ";
        // line 79
        if ((isset($context["level"]) ? $context["level"] : $this->getContext($context, "level"))) {
            echo "<option value=\"2\">会员卡用户</option>";
        }
        // line 80
        echo "                        </select>
                    </div>
                </div>
                <div class=\"control-group j_level\" style=\"display:none;\">
                    <label class=\"control-label\" for=\"input-image\">会员卡等级</label>
                    <div class=\"controls\">
                        <select name=\"level\" style=\"width:120px;\" >
                        ";
        // line 87
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["level"]) ? $context["level"] : $this->getContext($context, "level")));
        foreach ($context['_seq'] as $context["lev"] => $context["val"]) {
            // line 88
            echo "                        ";
            if (((isset($context["lev"]) ? $context["lev"] : $this->getContext($context, "lev")) == 0)) {
                // line 89
                echo "                        <option value=\"";
                echo (isset($context["lev"]) ? $context["lev"] : $this->getContext($context, "lev"));
                echo "\" selected=\"selected\">";
                echo (isset($context["val"]) ? $context["val"] : $this->getContext($context, "val"));
                echo "</option>
                        ";
            } else {
                // line 91
                echo "                        <option value=\"";
                echo (isset($context["lev"]) ? $context["lev"] : $this->getContext($context, "lev"));
                echo "\">";
                echo (isset($context["val"]) ? $context["val"] : $this->getContext($context, "val"));
                echo "</option>
                        ";
            }
            // line 93
            echo "                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['lev'], $context['val'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 94
        echo "                        </select>
                    </div>
                </div>
                
\t\t\t\t<div class=\"control-group\" id=\"control_tpl\">
\t\t\t\t\t<label class=\"control-label\" for=\"tpllist\">栏目模版</label>
\t\t\t\t\t<div class=\"controls\">
\t\t\t\t\t\t<select id=\"tpllist\" name=\"tpl\" autocomplete=\"off\">
\t\t\t\t\t\t\t<option value=\"\" selected preview=\"";
        // line 102
        echo (isset($context["preview_path"]) ? $context["preview_path"] : $this->getContext($context, "preview_path"));
        echo "assets/types_pub/cate/";
        echo $this->getAttribute((isset($context["global_tpl"]) ? $context["global_tpl"] : $this->getContext($context, "global_tpl")), "template_id", array(), "array");
        echo "/preview.jpg\">使用全局设置</option>
\t\t\t\t\t\t\t";
        // line 103
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["tpl_lists"]) ? $context["tpl_lists"] : $this->getContext($context, "tpl_lists")));
        foreach ($context['_seq'] as $context["_key"] => $context["tpl"]) {
            // line 104
            echo "\t\t\t\t\t\t\t<option value=\"";
            echo $this->getAttribute((isset($context["tpl"]) ? $context["tpl"] : $this->getContext($context, "tpl")), "template_id", array(), "array");
            echo "\" preview=\"";
            echo (isset($context["preview_path"]) ? $context["preview_path"] : $this->getContext($context, "preview_path"));
            echo "assets/types_pub/cate/";
            echo $this->getAttribute((isset($context["tpl"]) ? $context["tpl"] : $this->getContext($context, "tpl")), "template_id", array(), "array");
            echo "/preview.jpg\">";
            echo $this->getAttribute((isset($context["tpl"]) ? $context["tpl"] : $this->getContext($context, "tpl")), "title", array(), "array");
            echo "</option>
\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tpl'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 106
        echo "\t\t\t\t\t\t</select>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"controls\">
\t\t\t\t\t\t<img id=\"tpl_preview\" style=\"display: none;margin-top: 12px;\" width=\"220\" src=\"/assets/img/template/list/default.jpg\">
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t
\t\t\t\t<div class=\"control-group\">
                    <label class=\"control-label\" for=\"input-image\">自定义背景图片</label>
                    <div class=\"controls\">
                        <img src=\"/assets/img/no_image.png\" style=\"width:80px;height:160px;\" class=\"img-polaroid\" id=\"image-preview-background-image\">
                        <input type=\"button\" class=\"btn j_img_clear\" value=\"清空\" style=\"margin:0 0 5px 10px;\" />
                        <input type=\"hidden\" name=\"background_image\" id=\"input-image-background-image\">
                        <div id=\"uploader-image-background-image\"></div>
                    </div>
                </div>
\t\t\t\t
\t\t\t\t<div class=\"control-group\">
\t\t\t\t\t<div class=\"controls\">
\t\t\t\t\t\t<button type=\"submit\" class=\"btn btn-primary\">确认保存</button>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</form>
\t\t</div>
\t\t<div class=\"span4\">
\t\t\t<h5>图例说明：</h5>
\t\t\t<img src=\"/assets/img/guide_2.jpg\">
\t\t</div>
\t</div>
</div>
";
    }

    // line 138
    public function block_style($context, array $blocks = array())
    {
        // line 139
        echo "<link href=\"/assets/huploadify/Huploadify.css\" rel=\"stylesheet\">
<link href=\"/assets/css/icons_sys.css\" rel=\"stylesheet\">
<style type=\"text/css\">
#image-preview {
\tmargin: 10px 0;
\tbackground-color: #bababa;
}
.uploadify-button{
    color: #333;
    background-color: #fff;
    border-color: #ccc;
    cursor:pointer;
    text-decoration:none;
    border-radius: 2px;
    margin-left: 0;
}
.uploadify-button:hover {
    background-color: #ccc;
    background-image: none;
    background-position: center bottom;
    cursor:pointer;
    text-decoration:none;
}
</style>
";
    }

    // line 165
    public function block_script($context, array $blocks = array())
    {
        // line 166
        echo "<script src=\"/assets/huploadify/jquery.Huploadify.js\"></script>
<script src=\"/assets/js/icons_sys.js\"></script>
<script type=\"text/javascript\">
\$(function() {
\t//删除上传的图片
\t\$(document).on('click','.j_img_clear',function(){
\t\t\$(this).next('input').val('');
\t\t\$(this).prevAll('img').attr('src','/assets/img/no_image.png');
\t});
\t\$('#uploader-image').Huploadify({
        'fileObjName': 'image',
        'fileSizeLimit': 2048,
        'fileTypeExts': '*.gif; *.jpg; *.png',
        'multi': false,
        'auto':true,
        'showUploadedPercent':false,
        'removeTimeout': 0,
\t\t'buttonText': '上传图片',
\t\t'formData': {'token': '";
        // line 184
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
\t\t'uploader': '/image/upload',
\t\t'onUploadSuccess': function(file, data) {
            var ret = \$.parseJSON(data);
            if (ret) {
                if (ret.success) {
                    \$('#input-image').val(ret.image);
                    \$('#image-preview').attr('src', ret.image_preview);
                } else {
                    alert(ret.message);
                }
            }
\t\t}
\t});

\t\$('#uploader-image-background-image').Huploadify({
        'fileObjName': 'image',
        'fileSizeLimit': 2048,
        'fileTypeExts': '*.gif; *.jpg; *.png',
        'multi': false,
        'auto':true,
        'showUploadedPercent':false,
        'removeTimeout': 0,
        'buttonText': '上传图片',
        'formData': {'token': '";
        // line 208
        echo (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token"));
        echo "'},
        'uploader': '/image/upload',
        'onUploadSuccess': function(file, data) {
            var ret = \$.parseJSON(data);
            if (ret) {
                if (ret.success) {
                    \$('#input-image-background-image').val(ret.image);
                    \$('#image-preview-background-image').attr('src', ret.image_preview);
                } else {
                    alert(ret.message);
                }
            }
        }
    });
\t
\t\$('.j_level_type').on('change',function(){
\t\tvar level_type = \$(this).val();
\t\tif(level_type==2){
\t\t\t\$('.j_level').show();
\t\t}else{
\t\t\t\$('.j_level').hide();\t
\t\t}\t
\t});
\t
\t\$('#show_url').click(function() {
\t\t\$('#control_url').removeClass('hide');
\t\t\$('#control_show_url').addClass('hide');
\t\treturn false;
\t});
});

function show_icons_sys(){
\twindow.SysIconDialog.showDialog(function (id, url, type_id) {//id=图标id，也许需要   url=图标路径  type_id=所在分组id
\t\t\$('#input-image').val(url);
\t\t\$('#image-preview').attr('src', url);
\t});
}

(function (window, \$, undefined) {
\tvar \$selected = \$('#tpllist').change(function (a, b) {
\t\t\$('#tpl_preview').attr('src', \$(this).find('option:selected').attr('preview'));
\t}).find('option:selected');
\tvar \$tpl_preview = \$('#tpl_preview').attr('src',\$selected.attr('preview')).fadeIn ();
})(window, jQuery, undefined);
</script>
";
    }

    public function getTemplateName()
    {
        return "cate/add.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  326 => 208,  299 => 184,  279 => 166,  276 => 165,  248 => 139,  245 => 138,  211 => 106,  196 => 104,  192 => 103,  186 => 102,  176 => 94,  170 => 93,  162 => 91,  154 => 89,  151 => 88,  147 => 87,  138 => 80,  134 => 79,  83 => 30,  77 => 26,  66 => 24,  62 => 23,  55 => 18,  49 => 15,  45 => 13,  43 => 12,  33 => 4,  30 => 3,);
    }
}
