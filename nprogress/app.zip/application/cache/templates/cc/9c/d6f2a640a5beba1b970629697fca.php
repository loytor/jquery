<?php

/* auth/password.html */
class __TwigTemplate_cc9cd6f2a640a5beba1b970629697fca extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "<div class=\"well well-large\">
    <form method=\"post\" action=\"\" class=\"form-horizontal\">
        <div class=\"control-group\">
            <label for=\"input-username\" class=\"control-label\">用户名</label>
            <div class=\"controls\">
                <strong>";
        // line 9
        echo logged_username();
        echo "</strong>
            </div>
        </div>
        <div class=\"control-group\">
            <label for=\"input-password\" class=\"control-label\">原密码</label>
            <div class=\"controls\">
                <input type=\"password\" class=\"span2\" name=\"old_password\" id=\"input-old-password\"/>
            </div>
        </div>
        <div class=\"control-group\">
            <label for=\"input-password\" class=\"control-label\">新密码</label>
            <div class=\"controls\">
                <input type=\"password\" class=\"span2\" name=\"password\" id=\"input-password\" />
                <div id=\"chkResult\" style=\"display: inline;color: #ff6600;\"></div>
            </div>
        </div>
        <div class=\"control-group\">
            <label for=\"input-re_password\" class=\"control-label\">重复密码</label>
            <div class=\"controls\">
                <input type=\"password\" class=\"span2\" name=\"re_password\" id=\"input-re_password\" />
                <div id=\"chkResult2\" style=\"display: inline;color: #ff6600;\"></div>
            </div>
        </div>
        <div class=\"control-group\">
            <div class=\"controls\">
                <input class=\"btn btn-primary\" type=\"submit\" value=\"保 存\">
            </div>
        </div>
    </form>
</div>

<script type=\"text/javascript\">
    \$(function(){
        \$('#input-password').on('keyup blur',function(){
            var t= \$(this).val();
            var Bobj=document.getElementById(\"chkResult\");
            if(t.length<6 ){
                Bobj.innerHTML=\"密码至少6位，必须包括字母和数字\";
                return;
            }
            if( !t.match(/[a-z]/ig) ){
                Bobj.innerHTML=\"密码至少6位，必须包括字母和数字\";
                return;
            }
            if( !t.match(/[0-9]/ig) ){
                Bobj.innerHTML=\"密码至少6位，必须包括字母和数字\";
                return;
            }
            Bobj.innerHTML=\"\";
            return;
        });
        \$('#input-re_password').on('keyup',function(){
            var pass = \$('#input-password').val();
            var repass = \$(this).val();
            if( pass!=repass ){
                \$('#chkResult2').html('重复密码跟新密码不一致');
                return;
            }
            \$('#chkResult2').html('');
            return;
        });
    });
</script>
";
    }

    public function getTemplateName()
    {
        return "auth/password.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 9,  31 => 4,  28 => 3,);
    }
}
