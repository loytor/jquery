<?php

/* reserve_store/index.html */
class __TwigTemplate_8f38db422680b5652dfe1b416bc61996 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'main' => array($this, 'block_main'),
            'script' => array($this, 'block_script'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        // line 4
        echo "
";
        // line 5
        $this->env->loadTemplate("/reserve/breadcrumb.html")->display($context);
        // line 6
        echo "
<form action=\"/reserve_store/";
        // line 7
        echo (isset($context["type"]) ? $context["type"] : $this->getContext($context, "type"));
        echo "\" method=\"post\">
\t<table class=\"table table-hover table-bordered\">
\t\t<thead>
\t\t<tr style=\"background-color:#EEEEEE;\">
\t\t\t<th>排序</th>
\t\t\t<th>图片</th>
\t\t\t<th>门店名称</th>
\t\t\t<th>地址</th>
\t\t\t<th>预约预定电话</th>
\t\t\t<th></th>
\t\t</tr>
\t\t</thead>
\t\t<tbody>
\t\t<tr>
\t\t\t<td></td>
\t\t\t<td></td>
\t\t\t<td><input name=\"name\" class=\"input-medium\" type=\"text\" style=\"margin-bottom: 0;\" value=\"";
        // line 23
        echo (isset($context["name"]) ? $context["name"] : $this->getContext($context, "name"));
        echo "\"></td>
\t\t\t<td><input name=\"address\" class=\"input-medium\" type=\"text\" style=\"margin-bottom: 0;\" value=\"";
        // line 24
        echo (isset($context["address"]) ? $context["address"] : $this->getContext($context, "address"));
        echo "\"></td>
\t\t\t<td><input name=\"tel\" class=\"input-medium\" type=\"text\" style=\"margin-bottom: 0;\" value=\"";
        // line 25
        echo (isset($context["tel"]) ? $context["tel"] : $this->getContext($context, "tel"));
        echo "\"></td>
\t\t\t<td>
\t\t\t\t<button class=\"btn btn-primary\" type=\"submit\">查找</button>
\t\t\t</td>
\t\t</tr>
\t\t";
        // line 30
        if ((!twig_test_empty((isset($context["list"]) ? $context["list"] : $this->getContext($context, "list"))))) {
            // line 31
            echo "\t\t";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["list"]) ? $context["list"] : $this->getContext($context, "list")));
            foreach ($context['_seq'] as $context["key"] => $context["row"]) {
                // line 32
                echo "\t\t<tr>
\t\t\t<td><input type=\"text\" class=\"input-mini J-store-sort\" value=\"";
                // line 33
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "sort", array(), "array");
                echo "\" data-type=\"";
                echo (isset($context["type"]) ? $context["type"] : $this->getContext($context, "type"));
                echo "\" data-storeid=\"";
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "id", array(), "array");
                echo "\"></td>
\t\t\t<td><img style=\"width:64px; height:64px\" src=\"";
                // line 34
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "icon", array(), "array");
                echo "\"></td>
\t\t\t<td>";
                // line 35
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "name", array(), "array");
                echo "</td>
\t\t\t<td>";
                // line 36
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "address", array(), "array");
                echo "</td>
\t\t\t<td>";
                // line 37
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "reserve_tel", array(), "array");
                echo "</td>
\t\t\t<td>
\t\t\t\t<a class=\"btn btn-small\" href=\"/reserve_order/";
                // line 39
                echo (isset($context["type"]) ? $context["type"] : $this->getContext($context, "type"));
                echo "?id=";
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "id", array(), "array");
                echo "\"><i class=\"icon-list\"></i> 订单列表</a>
\t\t\t\t<a class=\"btn btn-small\" href=\"/reserve_store/edit/";
                // line 40
                echo (isset($context["type"]) ? $context["type"] : $this->getContext($context, "type"));
                echo "/";
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "id", array(), "array");
                echo "\"><i class=\"icon-edit\"></i> 编辑</a>
\t\t\t\t<a class=\"btn btn-small\" href=\"/reserve_category/";
                // line 41
                echo (isset($context["type"]) ? $context["type"] : $this->getContext($context, "type"));
                echo "?id=";
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "id", array(), "array");
                echo "\"><i class=\"icon-list\"></i> 分类</a>
\t\t\t\t<a class=\"btn btn-small\" href=\"/reserve_stuff/";
                // line 42
                echo (isset($context["type"]) ? $context["type"] : $this->getContext($context, "type"));
                echo "?id=";
                echo $this->getAttribute((isset($context["row"]) ? $context["row"] : $this->getContext($context, "row")), "id", array(), "array");
                echo "\"><i class=\"icon-list\"></i> ";
                echo (isset($context["stuff_name"]) ? $context["stuff_name"] : $this->getContext($context, "stuff_name"));
                echo "</a>
\t\t\t</td>
\t\t</tr>
\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_merge($_parent, array_intersect_key($context, $_parent));
            // line 46
            echo "\t\t";
        } else {
            // line 47
            echo "\t\t<tr><td colspan=\"6\" style=\"text-align: center;\">尚无门店,请到基本设置中选择门店</td></tr>
\t\t";
        }
        // line 49
        echo "\t\t</tbody>
\t</table>
</form>
";
        // line 52
        echo (isset($context["pagination"]) ? $context["pagination"] : $this->getContext($context, "pagination"));
        echo "
";
    }

    // line 56
    public function block_script($context, array $blocks = array())
    {
        // line 57
        echo "<script type=\"text/javascript\">
\t\$(function() {
\t\t\$('.J-store-sort').keyup(function(){
\t\t\tvar storeid = \$(this).attr('data-storeid');
\t\t\tvar sort = parseInt(\$(this).val());
\t\t\tvar type = \$(this).attr('data-type');
\t\t\tif(sort >=0 )
\t\t\t{
\t\t\t\t\$.post('/reserve_store/setSort/'+type, {'sort':sort,'storeid':storeid}, function(data) {
\t\t\t\t\t
\t\t\t\t});
\t\t\t}
\t\t\t
\t\t});
\t});
</script>
";
    }

    public function getTemplateName()
    {
        return "reserve_store/index.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  163 => 57,  160 => 56,  154 => 52,  149 => 49,  145 => 47,  142 => 46,  128 => 42,  122 => 41,  116 => 40,  110 => 39,  105 => 37,  101 => 36,  97 => 35,  93 => 34,  85 => 33,  82 => 32,  77 => 31,  75 => 30,  67 => 25,  63 => 24,  59 => 23,  40 => 7,  37 => 6,  35 => 5,  32 => 4,  29 => 3,);
    }
}
