<?php

/* tpl/index.html */
class __TwigTemplate_23f716b6592ec36bf7b6e3b3983f8e72 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("layout_main.html");

        $this->blocks = array(
            'style' => array($this, 'block_style'),
            'script' => array($this, 'block_script'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout_main.html";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_style($context, array $blocks = array())
    {
        // line 4
        echo "<link href=\"/assets/css/template-admin.css\" rel=\"stylesheet\" />
";
    }

    // line 6
    public function block_script($context, array $blocks = array())
    {
        // line 7
        echo "<script type=\"text/javascript\">
    \$(function () {
        \$('.toolbar').on('click', '.toolbar-item', function () {
            var \$this = \$(this);
            if (\$this.hasClass('index')) {
                \$('#target-tpls').removeClass('target-index target-list target-detail').addClass('target-index');
            } else if (\$this.hasClass('list')) {
                \$('#target-tpls').removeClass('target-index target-list target-detail').addClass('target-list');
            } else if (\$this.hasClass('detail')) {
                \$('#target-tpls').removeClass('target-index target-list target-detail').addClass('target-detail');
            }
        });

        //首页模版选择逻辑
        var \$indexBox = \$('.template-box-item.index').on('click', '.template', function () {
            var \$this = \$(this);
            if (!\$this.hasClass('selected')) {
                if (window.confirm('你确定要选择模版：' + \$this.attr('title') + '?')) {
                    var tid = \$this.attr('template-id');//获得模版id
                    //ajax提交，保存结果
                    submit_selected_tpl(tid, 'cate_tpl');
\t\t\t\t\t\t
                    //成功的话，更新UI
                    \$('.selected', \$indexBox).removeClass('selected').children('.select-flg').appendTo(\$this.addClass('selected'));
                }
            }
        });

        //列表页模版选择逻辑
        var \$listBox = \$('.template-box-item.list').on('click', '.template', function () {
            var \$this = \$(this);
            if (!\$this.hasClass('selected')) {
                if (window.confirm('你确定要选择模版：' + \$this.attr('title') + '?')) {
                    var tid = \$this.attr('template-id');//获得模版id
                    //ajax提交，保存结果
                    submit_selected_tpl(tid, 'list_tpl');

                    //成功的话，更新UI
                    \$('.selected', \$listBox).removeClass('selected').children('.select-flg').appendTo(\$this.addClass('selected'));
                }
            }
        });

        //列表页模版选择逻辑
        var \$detailBox = \$('.template-box-item.detail').on('click', '.template', function () {
            var \$this = \$(this);
            if (!\$this.hasClass('selected')) {
                if (window.confirm('你确定要选择模版：' + \$this.attr('title') + '?')) {
                    var tid = \$this.attr('template-id');//获得模版id
                    //ajax提交，保存结果
                    submit_selected_tpl(tid, 'detail_tpl');

                    //成功的话，更新UI
                    \$('.selected', \$detailBox).removeClass('selected').children('.select-flg').appendTo(\$this.addClass('selected'));
                }
            }
        });

        function submit_selected_tpl(tid, type){
        \t\$.post(
        \t\t'/tpl/selected',
        \t\t{tid: tid, type: type},
        \t\tfunction(data){
        \t\t\talert(data.msg);
        \t\t}
        \t)
        }
    });
    
</script>
";
    }

    // line 78
    public function block_main($context, array $blocks = array())
    {
        // line 79
        echo "
<div id=\"target-tpls\" class=\"target-index\">
\t<div class=\"toolbar\">
\t    <div class=\"toolbar-item index\">首页模版(第一级)</div>
\t    <div class=\"toolbar-item list\">文章列表页模版(第二级)</div>
\t    <div class=\"toolbar-item detail\">详情页模版(第三级)</div>
\t</div>
\t<div class=\"template-box\">
    <div class=\"template-box-item index\">

        ";
        // line 89
        if (array_key_exists("diy_tpl", $context)) {
            // line 90
            echo "        <div class=\"template ";
            if (($this->getAttribute((isset($context["selected_tpl"]) ? $context["selected_tpl"] : $this->getContext($context, "selected_tpl")), "cate_tpl", array(), "array") == "diy")) {
                echo "selected";
            }
            echo "\" template-id=\"diy\" title=\"模版名：自定义首页\">
            <img width=\"220\" height=\"330\" src=\"/assets/img/template/cate/diy_preview.jpg\" >
            <span>自定义首页</span>
            ";
            // line 93
            if (($this->getAttribute((isset($context["selected_tpl"]) ? $context["selected_tpl"] : $this->getContext($context, "selected_tpl")), "cate_tpl", array(), "array") == "diy")) {
                // line 94
                echo "            <div class=\"select-flg\"></div>
            ";
            }
            // line 96
            echo "        </div>
        ";
        }
        // line 98
        echo "    \t<!--首页模版列表-->
    \t";
        // line 99
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["cate_tpl_arr"]) ? $context["cate_tpl_arr"] : $this->getContext($context, "cate_tpl_arr")));
        foreach ($context['_seq'] as $context["_key"] => $context["cate_tpl"]) {
            // line 100
            echo "        <div class=\"template ";
            if (($this->getAttribute((isset($context["selected_tpl"]) ? $context["selected_tpl"] : $this->getContext($context, "selected_tpl")), "cate_tpl", array(), "array") == $this->getAttribute((isset($context["cate_tpl"]) ? $context["cate_tpl"] : $this->getContext($context, "cate_tpl")), "template_id", array(), "array"))) {
                echo "selected";
            }
            echo "\" template-id=\"";
            echo $this->getAttribute((isset($context["cate_tpl"]) ? $context["cate_tpl"] : $this->getContext($context, "cate_tpl")), "template_id", array(), "array");
            echo "\" title=\"模版名：";
            echo $this->getAttribute((isset($context["cate_tpl"]) ? $context["cate_tpl"] : $this->getContext($context, "cate_tpl")), "title", array(), "array");
            echo "\">
            <img width=\"220\" height=\"330\" src=\"";
            // line 101
            echo (isset($context["preview_path"]) ? $context["preview_path"] : $this->getContext($context, "preview_path"));
            echo "assets/types_pub/home/";
            echo $this->getAttribute((isset($context["cate_tpl"]) ? $context["cate_tpl"] : $this->getContext($context, "cate_tpl")), "template_id", array(), "array");
            echo "/preview.jpg\" >
            <span>";
            // line 102
            echo $this->getAttribute((isset($context["cate_tpl"]) ? $context["cate_tpl"] : $this->getContext($context, "cate_tpl")), "title", array(), "array");
            echo "</span>
            ";
            // line 103
            if (($this->getAttribute((isset($context["selected_tpl"]) ? $context["selected_tpl"] : $this->getContext($context, "selected_tpl")), "cate_tpl", array(), "array") == $this->getAttribute((isset($context["cate_tpl"]) ? $context["cate_tpl"] : $this->getContext($context, "cate_tpl")), "template_id", array(), "array"))) {
                // line 104
                echo "            <div class=\"select-flg\"></div>
            ";
            }
            // line 106
            echo "        </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['cate_tpl'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 108
        echo "    </div>

    <!--列表页模版列表-->
    <div class=\"template-box-item list\">
    \t";
        // line 112
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["list_tpl_arr"]) ? $context["list_tpl_arr"] : $this->getContext($context, "list_tpl_arr")));
        foreach ($context['_seq'] as $context["_key"] => $context["list_tpl"]) {
            // line 113
            echo "        <div class=\"template ";
            if (($this->getAttribute((isset($context["selected_tpl"]) ? $context["selected_tpl"] : $this->getContext($context, "selected_tpl")), "list_tpl", array(), "array") == $this->getAttribute((isset($context["list_tpl"]) ? $context["list_tpl"] : $this->getContext($context, "list_tpl")), "template_id", array(), "array"))) {
                echo "selected";
            }
            echo "\" template-id=\"";
            echo $this->getAttribute((isset($context["list_tpl"]) ? $context["list_tpl"] : $this->getContext($context, "list_tpl")), "template_id", array(), "array");
            echo "\" title=\"模版名：";
            echo $this->getAttribute((isset($context["list_tpl"]) ? $context["list_tpl"] : $this->getContext($context, "list_tpl")), "title", array(), "array");
            echo "\">
            <img width=\"220\" height=\"330\" src=\"";
            // line 114
            echo (isset($context["preview_path"]) ? $context["preview_path"] : $this->getContext($context, "preview_path"));
            echo "assets/types_pub/cate/";
            echo $this->getAttribute((isset($context["list_tpl"]) ? $context["list_tpl"] : $this->getContext($context, "list_tpl")), "template_id", array(), "array");
            echo "/preview.jpg\" >
            <span>";
            // line 115
            echo $this->getAttribute((isset($context["list_tpl"]) ? $context["list_tpl"] : $this->getContext($context, "list_tpl")), "title", array(), "array");
            echo "</span>
            ";
            // line 116
            if (($this->getAttribute((isset($context["selected_tpl"]) ? $context["selected_tpl"] : $this->getContext($context, "selected_tpl")), "list_tpl", array(), "array") == $this->getAttribute((isset($context["list_tpl"]) ? $context["list_tpl"] : $this->getContext($context, "list_tpl")), "template_id", array(), "array"))) {
                // line 117
                echo "            <div class=\"select-flg\"></div>
            ";
            }
            // line 119
            echo "        </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['list_tpl'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 121
        echo "    </div>

    <!--详细信息页模版列表-->
    <div class=\"template-box-item detail\">
    \t";
        // line 125
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["detail_tpl_arr"]) ? $context["detail_tpl_arr"] : $this->getContext($context, "detail_tpl_arr")));
        foreach ($context['_seq'] as $context["_key"] => $context["detail_tpl"]) {
            // line 126
            echo "        <div class=\"template ";
            if (($this->getAttribute((isset($context["selected_tpl"]) ? $context["selected_tpl"] : $this->getContext($context, "selected_tpl")), "detail_tpl", array(), "array") == $this->getAttribute((isset($context["detail_tpl"]) ? $context["detail_tpl"] : $this->getContext($context, "detail_tpl")), "template_id", array(), "array"))) {
                echo "selected";
            }
            echo "\" template-id=\"";
            echo $this->getAttribute((isset($context["detail_tpl"]) ? $context["detail_tpl"] : $this->getContext($context, "detail_tpl")), "template_id", array(), "array");
            echo "\" title=\"模版名：";
            echo $this->getAttribute((isset($context["detail_tpl"]) ? $context["detail_tpl"] : $this->getContext($context, "detail_tpl")), "title", array(), "array");
            echo "\">
            <img width=\"220\" height=\"330\" src=\"";
            // line 127
            echo (isset($context["preview_path"]) ? $context["preview_path"] : $this->getContext($context, "preview_path"));
            echo "assets/types_pub/detail/";
            echo $this->getAttribute((isset($context["detail_tpl"]) ? $context["detail_tpl"] : $this->getContext($context, "detail_tpl")), "template_id", array(), "array");
            echo "/preview.jpg\" >
            <span>";
            // line 128
            echo $this->getAttribute((isset($context["detail_tpl"]) ? $context["detail_tpl"] : $this->getContext($context, "detail_tpl")), "title", array(), "array");
            echo "</span>
            ";
            // line 129
            if (($this->getAttribute((isset($context["selected_tpl"]) ? $context["selected_tpl"] : $this->getContext($context, "selected_tpl")), "detail_tpl", array(), "array") == $this->getAttribute((isset($context["detail_tpl"]) ? $context["detail_tpl"] : $this->getContext($context, "detail_tpl")), "template_id", array(), "array"))) {
                // line 130
                echo "            <div class=\"select-flg\"></div>
            ";
            }
            // line 132
            echo "        </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['detail_tpl'], $context['_parent'], $context['loop']);
        $context = array_merge($_parent, array_intersect_key($context, $_parent));
        // line 134
        echo "    </div>
</div>
</div>
";
    }

    public function getTemplateName()
    {
        return "tpl/index.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  280 => 134,  273 => 132,  269 => 130,  267 => 129,  263 => 128,  257 => 127,  246 => 126,  242 => 125,  236 => 121,  229 => 119,  225 => 117,  223 => 116,  219 => 115,  213 => 114,  202 => 113,  198 => 112,  192 => 108,  185 => 106,  181 => 104,  179 => 103,  175 => 102,  169 => 101,  158 => 100,  154 => 99,  151 => 98,  147 => 96,  143 => 94,  141 => 93,  132 => 90,  130 => 89,  118 => 79,  115 => 78,  41 => 7,  38 => 6,  33 => 4,  30 => 3,);
    }
}
