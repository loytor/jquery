<?php
/**
 * Created by PhpStorm.
 * User: llj
 * Date: 13-12-25
 * Time: 上午9:52
 */
include_once(APPPATH.'libraries/Appcall.php');
class Home extends Appcall
{
    public static $controller = 'cate';
    public static $method = 'index';

    public function get_name()
    {
        return '微网站-首页';
    }

    public function get_list($params)
    {
        return array();
    }

    public function get_count($params)
    {
        return 0;
    }

    public function get_info()
    {
        return '/home';
    }
}