<?php
/**
 * Created by PhpStorm.
 * User: llj
 * Date: 13-12-23
 * Time: 下午5:05
 */
include_once(APPPATH.'libraries/Appcall.php');
class Emigrated extends Appcall
{
    public static $controller = 'emigrated';
    public static $method = 'index';

    public function get_name()
    {
        $title = $this->get_app_title(self::$controller, self::$method);
        return $title ? $title : '答题闯关';
    }

    public function get_list($params)
    {
        $this->load->model('emigrated_model');
        $where = array();
        $where['wid'] = $this->site_info['id'];
        $where['is_delete'] = 0;
        $like = array();
        isset($params['keyword']) && $params['keyword'] && $like['title'] = $params['keyword'];
        $per_page = isset($params['per_page']) ? $params['per_page'] : '';
        $offset = isset($params['offset']) ? $params['offset'] : '';
        $list = $this->emigrated_model->where($where)->like($like)->order_by('add_time', 'desc')->limit($per_page, $offset)->find_all();
        $list = $list ? $list : array();
        return $list;
    }

    public function get_count($params)
    {
        $this->load->model('emigrated_model');
        $where = array();
        $where['wid'] = $this->site_info['id'];
        $where['is_delete'] = 0;
        $like = array();
        isset($params['keyword']) && $params['keyword'] && $like['title'] = $params['keyword'];
        return $this->emigrated_model->where($where)->like($like)->count();
    }

    public function get_info()
    {
        return '/emigrated';
    }
}