<?php
/**
 * Created by PhpStorm.
 * User: llj
 * Date: 13-12-23
 * Time: 下午4:32
 */
include_once(APPPATH.'libraries/Appcall.php');
class Vipcard extends Appcall
{
    public static $controller = 'vipcard';
    public static $method = 'index';

    public function get_name()
    {
        $title = $this->get_app_title(self::$controller, self::$method);
        return $title ? $title : '微会员（旧）';
    }

    public function get_list($params)
    {
        $this->load->model('vipcard_model');
        $vipcard = $this->vipcard_model->where(array('user_id'=>$this->site_info['id']))->find();
        $vipcard = $vipcard ? $vipcard : array();
        return $vipcard;
    }

    public function get_count($params)
    {
        return 1;
    }

    public function get_info()
    {
        $this->load->model('vipcard_model');
        $vipcard = $this->vipcard_model->where(array('user_id'=>$this->site_info['id']))->find();
        if($vipcard){
            return '/vipcard/view/'.$vipcard['id'];
        } else {
            return '';
        }
    }
}