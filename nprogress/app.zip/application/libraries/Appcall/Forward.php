<?php
/**
 * Created by PhpStorm.
 * User: llj
 * Date: 13-12-28
 * Time: 上午10:22
 */
include_once(APPPATH.'libraries/Appcall.php');
class Forward extends Appcall
{
    public static $controller = 'c/forward';
    public static $method = 'index';

    public function get_name()
    {
        $title = $this->get_app_title(self::$controller, self::$method);
        return $title ? $title : '转发有礼';
    }

    public function get_list($params)
    {
        $this->load->model('forward_model');
        $where = array();
        $where['site_id'] = $this->site_info['id'];
        $where['status'] = 0;
        $like = array();
        isset($params['keyword']) && $params['keyword'] && $like['title'] = $params['keyword'];
        $per_page = isset($params['per_page']) ? $params['per_page'] : '';
        $offset = isset($params['offset']) ? $params['offset'] : '';
        $list = $this->forward_model->where($where)->like($like)->limit($per_page, $offset)->find_all();
        $list = $list ? $list : array();
        $this->db->last_query();
        return $list;
    }

    public function get_count($params)
    {
        $this->load->model('forward_model');
        $where = array();
        $where['site_id'] = $this->site_info['id'];
        $where['status'] = 0;
        $like = array();
        isset($params['keyword']) && $params['keyword'] && $like['title'] = $params['keyword'];
        return $this->forward_model->where($where)->like($like)->count();
    }

    public function get_info()
    {
        return '/turn';
    }
}