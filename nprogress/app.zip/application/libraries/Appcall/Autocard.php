<?php
/**
 * Created by PhpStorm.
 * User: llj
 * Date: 13-12-24
 * Time: 上午9:51
 */
include_once(APPPATH.'libraries/Appcall.php');
class Autocard extends Appcall
{
    public static $controller = 'autocard';
    public static $method = 'index';

    public function get_name()
    {
        $title = $this->get_app_title(self::$controller, self::$method);
        return $title ? $title : '微汽车-车主关怀';
    }

    public function get_list($params)
    {
        return array();
    }

    public function get_count($params)
    {
        return 1;
    }

    public function get_info()
    {
        return '/autocard';
    }
}