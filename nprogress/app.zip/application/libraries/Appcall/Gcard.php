<?php
/**
 * Created by PhpStorm.
 * User: llj
 * Date: 13-12-23
 * Time: 下午4:32
 */
include_once(APPPATH.'libraries/Appcall.php');
class Gcard extends Appcall
{
    public static $controller = 'c/gcard';
    public static $method = 'index';

    public function get_name()
    {
        $title = $this->get_app_title(self::$controller, self::$method);
        return $title ? $title : '微贺卡';
    }

    public function get_list($params)
    {
        $this->load->model('gcard_config_model');
        $gcard_config = $this->gcard_config_model->where(array('site_id'=>$this->site_info['id']))->find();
        $gcard_config = $gcard_config ? $gcard_config : array();
        return $gcard_config;
    }

    public function get_count($params)
    {
        return 1;
    }

    public function get_info()
    {
        return '/gcard';
    }
}