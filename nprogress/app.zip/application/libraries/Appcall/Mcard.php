<?php
/**
 * Created by PhpStorm.
 * User: llj
 * Date: 13-12-23
 * Time: 下午3:48
 */
include_once(APPPATH.'libraries/Appcall.php');
class Mcard extends Appcall
{
    public static $controller = 'c/mcard';
    public static $method = 'index';

    public function get_name()
    {
        $title = $this->get_app_title(self::$controller, self::$method);
        return $title ? $title : '微会员';
    }

    public function get_list($params)
    {
        $this->load->model('mcard_model');
        $mcard = $this->mcard_model->where(array('site_id'=>$this->site_info['id']))->find();
        $mcard = $mcard ? $mcard : array();
        return $mcard;
    }

    public function get_count($params)
    {
        return 1;
    }

    public function get_info()
    {
        return '/vip';
    }
}