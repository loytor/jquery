<?php
/**
 * Created by PhpStorm.
 * User: llj
 * Date: 13-12-23
 * Time: 下午4:54
 */
include_once(APPPATH.'libraries/Appcall.php');
class Waimai extends Appcall
{
    public static $controller = 'c/waimai';
    public static $method = 'index';

    public function get_name()
    {
        $title = $this->get_app_title(self::$controller, self::$method);
        return $title ? $title : '微外卖';
    }

    public function get_list($params)
    {
        $this->load->model('waimai_model');
        $waimai = $this->waimai_model->where(array('site_id'=>$this->site_info['id']))->find();
        $waimai = $waimai ? $waimai : array();
        return $waimai;
    }

    public function get_count($params)
    {
        return 1;
    }

    public function get_info()
    {
        return '/takeaway';
    }
}