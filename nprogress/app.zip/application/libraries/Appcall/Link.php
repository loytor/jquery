<?php
/**
 * Created by PhpStorm.
 * User: 111
 * Date: 13-12-21
 * Time: 下午3:48
 */
include_once(APPPATH.'libraries/Appcall.php');
class Link extends Appcall
{
    public function get_name()
    {
        return '链接';
    }

    public function get_list($params)
    {
        return array();
    }

    public function get_count($params)
    {
        return 0;
    }

    public function get_info()
    {
        return '';
    }
}