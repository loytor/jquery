<?php
/**
 * Created by PhpStorm.
 * User: 111
 * Date: 13-12-19
 * Time: 下午3:41
 */
include_once(APPPATH.'libraries/Appcall.php');
class Game extends Appcall
{
    public static $controller = 'game';
    public static $method = 'index';

    public function get_name()
    {
        $title = $this->get_app_title(self::$controller, self::$method);
        return $title ? $title : '微游戏';
    }

    public function get_list($params)
    {
        $this->load->model('game_model');
        $where = array();
        $where['wid'] = $this->site_info['id'];
        $where['is_deleted'] = 0;
        isset($params['gtype']) && $params['gtype'] && $where['type'] = $params['gtype'];
        $like = array();
        isset($params['keyword']) && $params['keyword'] && $like['title'] = $params['keyword'];
        $per_page = isset($params['per_page']) ? $params['per_page'] : '';
        $offset = isset($params['offset']) ? $params['offset'] : '';
        $list = $this->game_model->where($where)->like($like)->limit($per_page, $offset)->find_all();
        $list = $list ? $list : array();
        $this->db->last_query();
        return $list;
    }

    public function get_count($params)
    {
        $this->load->model('game_model');
        $where = array();
        $where['wid'] = $this->site_info['id'];
        $where['is_deleted'] = 0;
        isset($params['gtype']) && $params['gtype'] && $where['type'] = $params['gtype'];
        $like = array();
        isset($params['keyword']) && $params['keyword'] && $like['title'] = $params['keyword'];
        return $this->game_model->where($where)->like($like)->count();
    }

    public function get_filter_list()
    {
        return array(
            1 => '大转盘',
            2 => '水果达人',
            3 => '刮刮乐',
            4 => '砸金蛋',
            5 => '摇一摇',
            6 => '幸运卡牌'
        );
    }

    public function get_info()
    {
        return '/game';
    }
}