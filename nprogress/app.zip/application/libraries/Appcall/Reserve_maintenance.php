<?php
/**
 * Created by PhpStorm.
 * User: llj
 * Date: 13-12-23
 * Time: 下午7:47
 */
include_once(APPPATH.'libraries/Appcall.php');
class Reserve_maintenance extends Appcall
{
    public static $controller = 'reserve';
    public static $method = 'maintenance';

    public function get_name()
    {
        $title = $this->get_app_title(self::$controller, self::$method);
        return $title ? $title : '微汽车-保养';
    }

    public function get_list($params)
    {
        $this->load->model('app_config_model');
        $con = array();
        $config = $this->app_config_model->where(array('user_id'=>$this->site_info['id'], 'type'=>self::$controller.'_'.self::$method))->find();
        if($config && $config['config']){
            $con = json_decode($config['config'], TRUE);
        }
        return $con;
    }

    public function get_count($params)
    {
        return 1;
    }

    public function get_info()
    {
        return '/reserve/maintenance';
    }
}