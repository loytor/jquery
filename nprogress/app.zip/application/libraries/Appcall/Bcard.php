<?php
/**
 * Created by PhpStorm.
 * User: llj
 * Date: 13-12-23
 * Time: 下午4:40
 */
include_once(APPPATH.'libraries/Appcall.php');
class Bcard extends Appcall
{
    public static $controller = 'business_card';
    public static $method = 'index';

    public function get_name()
    {
        $title = $this->get_app_title(self::$controller, self::$method);
        return $title ? $title : '微名片';
    }

    public function get_list($params)
    {
        $this->load->model('bcard_model');
        $where = array();
        $where['wid'] = $this->site_info['id'];
        $like = array();
        isset($params['keyword']) && $params['keyword'] && $like['name'] = $params['keyword'];
        $per_page = isset($params['per_page']) ? $params['per_page'] : '';
        $offset = isset($params['offset']) ? $params['offset'] : '';
        $list = $this->bcard_model->where($where)->like($like)->limit($per_page, $offset)->find_all();
        $list = $list ? $list : array();
        $this->db->last_query();
        return $list;
    }

    public function get_count($params)
    {
        $this->load->model('bcard_model');
        $where = array();
        $where['wid'] = $this->site_info['id'];
        $like = array();
        isset($params['keyword']) && $params['keyword'] && $like['name'] = $params['keyword'];
        return $this->bcard_model->where($where)->like($like)->count();
    }

    public function get_info()
    {
        return '/business_card';
    }
}