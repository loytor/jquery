<?php
/**
 * Created by PhpStorm.
 * User: 111
 * Date: 13-12-23
 * Time: 下午7:36
 */
include_once(APPPATH.'libraries/Appcall.php');
class Groupon extends Appcall
{
    public static $controller = 'groupon';
    public static $method = 'index';

    public function get_name()
    {
        $title = $this->get_app_title(self::$controller, self::$method);
        return $title ? $title : '微团购';
    }

    public function get_list($params)
    {
        $this->load->model('app_config_model');
        $con = array();
        $config = $this->app_config_model->where(array('user_id'=>$this->site_info['id'], 'type'=>'groupon'))->find();
        if($config && $config['config']){
            $con = json_decode($config['config'], TRUE);
        }
        return $con;
    }

    public function get_count($params)
    {
        return 1;
    }

    public function get_info()
    {
        return '/groupon';
    }
}