<?php
/**
 * Created by PhpStorm.
 * User: llj
 * Date: 13-12-18
 * Time: 下午10:59
 */
include_once(APPPATH.'libraries/Appcall.php');
class Cate extends Appcall
{
    public static $controller = 'cate';
    public static $method = 'index';

    public function get_name()
    {
        return '微网站-栏目';
    }

    public function get_list($params)
    {
        $this->load->model('cate_model');
        $where = array();
        $where['user_id'] = $this->site_info['id'];
        $like = array();
        isset($params['keyword']) && $params['keyword'] && $like['cate_name'] = $params['keyword'];
        $per_page = isset($params['per_page']) ? $params['per_page'] : '';
        $offset = isset($params['offset']) ? $params['offset'] : '';
        $list = $this->cate_model->where($where)->like($like)->limit($per_page, $offset)->find_all();
        $list = $list ? $list : array();
        return $list;
    }

    public function get_count($params)
    {
        $this->load->model('cate_model');
        $where = array();
        $where['user_id'] = $this->site_info['id'];
        $like = array();
        isset($params['keyword']) && $params['keyword'] && $like['cate_name'] = $params['keyword'];
        return $this->cate_model->where($where)->like($like)->count();
    }

    public function get_info()
    {
        return '/cate';
    }
}