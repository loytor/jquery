<?php
/**
 * Created by PhpStorm.
 * User: llj
 * Date: 13-12-23
 * Time: 下午3:20
 */
include_once(APPPATH.'libraries/Appcall.php');
class Mall extends Appcall
{
    public static $controller = 'mall';
    public static $method = 'index';

    public function get_name()
    {
        $title = $this->get_app_title(self::$controller, self::$method);
        return $title ? $title : '微商城';
    }

    public function get_list($params)
    {
        $this->load->model('mall_model');
        $mall = $this->mall_model->where(array('wid'=>$this->site_info['id']))->find();
        $mall = $mall ? $mall : array();
        return $mall;
    }

    public function get_count($params)
    {
        return 1;
    }

    public function get_info()
    {
        return '/mall';
    }
}