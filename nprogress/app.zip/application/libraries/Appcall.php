<?php
/**
 * Created by PhpStorm.
 * User: llj
 * Date: 13-12-18
 * Time: 下午11:18
 */
class Appcall
{
    public $site_info;

    public function __construct()
    {
        $this->load->model('app_model');
        $this->load->model('user_model');
        $this->site_info = $this->user_model->find($this->session->userdata('user_id'));
    }

    public function __get($key)
    {
        $CI =& get_instance();
        return $CI->$key;
    }

    public function get_app_title($controller, $method)
    {
        $app = $this->app_model->where(array('module'=>$controller, 'method'=>$method, 'status'=>0))->find();
        return $app && isset($app['name']) ? $app['name'] : '';
    }
}