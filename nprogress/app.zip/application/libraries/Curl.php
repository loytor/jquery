<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Curl {

	private $ch;
	private $options = array();
	private $headers = array();
	private $cookie_file = '';
	private $output_header = FALSE;
	private $user_agents = array(
		'ie'		=> 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)',
		'firefox'	=> 'Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20110814 Firefox/6.0',
		'opera'		=> 'Opera/9.80 (Windows NT 6.1; U; en-US) Presto/2.9.181 Version/12.00',
		'chrome'	=> 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.2 (KHTML, like Gecko) Chrome/15.0.872.0 Safari/535.2',
		'bot'		=> 'Googlebot/2.1 (+http://www.google.com/bot.html)',
	);
	private $user_agent = '';
	private $effective_url = '';

	public function set_option($code, $value) {
		if (is_string($code) && ! is_numeric($code)) {
			$code = constant('CURLOPT_' . strtoupper($code));
		}
		$this->options[$code] = $value;
		return $this;
	}

	public function set_header($header, $content = NULL) {
		$this->headers[$header] = $content;
		return $this;
	}

	public function set_headers($headers = array()) {
		$this->headers = $headers;
		return $this;
	}

	public function set_cookie_file($filename) {
		$this->cookie_file = $filename;
		return $this;
	}

	public function set_user_agent($user_agent) {
		if (isset($this->user_agents[$user_agent])) {
			$this->user_agent = $this->user_agents[$user_agent];
		} else {
			$this->user_agent = $user_agent;
		}
		return $this;
	}

	public function set_referer($referer) {
		$this->options[CURLOPT_REFERER] = $referer;
		return $this;
	}

	public function output_header($boolean = TRUE) {
		$this->output_header = $boolean;
		return $this;
	}

	public function get($url, $options = array()) {
		$this->ch = curl_init();
		$this->options = array();
		$this->set_option(CURLOPT_URL, $url);
		$this->set_option(CURLOPT_HTTPGET, TRUE);
		$this->set_option(CURLOPT_POST, FALSE);
		foreach ($options as $option_code => $option_value) {
			$this->set_option($option_code, $option_value);
		}
		$this->set_header('Expect:');
		return $this->execute();
	}

	public function post($url, $params, $options = array()) {
		$this->ch = curl_init();
		$this->options = array();
		$this->set_option(CURLOPT_URL, $url);
		$this->set_option(CURLOPT_HTTPGET, FALSE);
		$this->set_option(CURLOPT_POST, TRUE);
		if (is_array($params)) {
			$this->set_option(CURLOPT_POSTFIELDS, http_build_query($params));
		} else {
			$this->set_option(CURLOPT_POSTFIELDS, $params);
		}
		foreach ($options as $option_code => $option_value) {
			$this->set_option($option_code, $option_value);
		}
		$this->set_header('Expect:');
		return $this->execute();
	}

	public function upload($url, $params, $file_params, $options = array()) {
		set_time_limit(0);
		$this->ch = curl_init();
		$this->options = array();
		$this->set_option(CURLOPT_URL, $url);
		$this->set_option(CURLOPT_HTTPGET, FALSE);
		$this->set_option(CURLOPT_POST, TRUE);
		foreach($file_params as $key => $val) {
			$params[$key] = '@'.$val;
		}
		$this->set_option(CURLOPT_POSTFIELDS, $params);
		foreach ($options as $option_code => $option_value) {
			$this->set_option($option_code, $option_value);
		}
		$this->set_header('Expect:');
		return $this->execute();
	}

	public function content_length($url) {
		$this->ch = curl_init();
		$this->options = array();
		$this->set_option(CURLOPT_URL, $url);
		$this->set_option(CURLOPT_NOBODY, TRUE);
		$this->set_option(CURLOPT_HEADER, FALSE);
		$this->set_option(CURLOPT_RETURNTRANSFER, FALSE);
		$this->curl_set_options();
		curl_exec($this->ch);
		$content_length = curl_getinfo($this->ch, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
		curl_close($this->ch);
		return $content_length ? $content_length : FALSE;
	}

	public function effective_url() {
		return $this->effective_url;
	}

	private function curl_set_options() {
		if ( ! isset($this->options[CURLOPT_TIMEOUT])) {
			$this->options[CURLOPT_TIMEOUT] = 30;
		}
		if ( ! isset($this->options[CURLOPT_CONNECTTIMEOUT])) {
			$this->options[CURLOPT_CONNECTTIMEOUT] = 10;
		}
		if ( ! isset($this->options[CURLOPT_RETURNTRANSFER])) {
			$this->options[CURLOPT_RETURNTRANSFER] = TRUE;
		}
		if ( ! isset($this->options[CURLOPT_FAILONERROR])) {
			$this->options[CURLOPT_FAILONERROR] = TRUE;
		}
		if ( ! isset($this->options[CURLOPT_SSL_VERIFYPEER])) {
			$this->options[CURLOPT_SSL_VERIFYPEER] = FALSE;
			$this->options[CURLOPT_SSL_VERIFYHOST] = FALSE;
		}
		if ( ! isset($this->options[CURLOPT_FOLLOWLOCATION])) {
			$this->options[CURLOPT_FOLLOWLOCATION] = TRUE;
			$this->options[CURLOPT_MAXREDIRS] = 5;
		}
		if ( ! empty($this->user_agent)) {
			$this->options[CURLOPT_USERAGENT] = $this->user_agent;
		} else {
			$this->options[CURLOPT_USERAGENT] = $this->user_agents['chrome'];
		}
		if ($this->output_header) {
			$this->options[CURLOPT_HEADER] = TRUE;
		}
		if ($this->cookie_file) {
			$this->options[CURLOPT_COOKIEFILE] = $this->cookie_file;
			$this->options[CURLOPT_COOKIEJAR] = $this->cookie_file;
		}
		if ($this->effective_url) {
			$this->options[CURLOPT_REFERER] = $this->effective_url;
		}
		if ( ! empty($this->headers)) {
			$header_arr = array();
			foreach ($this->headers as $header => $content) {
				$header_arr[] = $content ? $header . ': ' . $content : $header;
			}
			$this->options[CURLOPT_HTTPHEADER] = $header_arr;
		}
		curl_setopt_array($this->ch, $this->options);
	}

	private function execute() {
		$this->curl_set_options();
		$response = curl_exec($this->ch);
		if ($response === FALSE) {
			log_message('error', curl_error($this->ch));
			curl_close($this->ch);
			return FALSE;
		} else {
			$this->effective_url = curl_getinfo($this->ch, CURLINFO_EFFECTIVE_URL);
			curl_close($this->ch);
			return $response;
		}
	}

}