<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Acl {

	const ALLOW = TRUE;
	const DENY = FALSE;

	private $_rules = array(
		'access'	=> self::DENY,		
		'roles'		=> array()
	);
	private $_resources = array();
	
	public function add_role($role_id) {
		$this->_rules['roles'][$role_id] = array(
			'access'	=> self::DENY,
			'resources'	=> array()
		);
	}

	public function add_resource($resource_id) {
		$this->_resources[] = $resource_id;
		foreach ($this->_rules['roles'] as &$_role) {
			$_role['resources'][$resource_id] = array(
				'access'		=> self::DENY,
				'privileges'	=> array()
			);
		}
		unset($_role);
	}

	public function allow($role_id = NULL, $resource_id = NULL, $privilege_id = NULL) {
		$this->_set_rule(self::ALLOW, $role_id, $resource_id, $privilege_id);
	}

	public function deny($role_id = NULL, $resource_id = NULL, $privilege_id = NULL) {
		$this->_set_rule(self::DENY, $role_id, $resource_id, $privilege_id);
	}
	
	public function is_allowed($role_id = NULL, $resource_id = NULL, $privilege_id = NULL) {
		$role_id = isset($this->_rules['roles'][$role_id]) ? $role_id : NULL;
		$resource_id = in_array($resource_id, $this->_resources) ? $resource_id : NULL;
		if ($role_id === NULL) {
			return $this->_rules['access'] === self::ALLOW;
		} else {
			if ($resource_id === NULL) {
				return $this->_rules['roles'][$role_id]['access'] === self::ALLOW;
			} else {
				if (isset($this->_rules['roles'][$role_id]['resources'][$resource_id]['privileges'][$privilege_id])) {
					return $this->_rules['roles'][$role_id]['resources'][$resource_id]['privileges'][$privilege_id] === self::ALLOW;
				} else {
					return $this->_rules['roles'][$role_id]['resources'][$resource_id]['access'] === self::ALLOW;
				}
			}			
		}
	}

	private function _set_rule($rule, $role_id = NULL, $resource_id = NULL, $privilege_id = NULL) {
		if ($role_id === NULL && $resource_id === NULL) {
			$this->_rules['access'] = $rule;
			foreach ($this->_rules['roles'] as &$_role) {
				$_role['access'] = $rule;
				foreach ($_role['resources'] as &$_resource) {
					$_resource['access'] = $rule;
				}
			}
			unset($_role);
			unset($_resource);
		} else {
			$_roles = array();
			$_resources = array();
			$_privileges = array();
			if ($role_id === NULL) {
				$_roles = array_keys($this->_rules['roles']);
			} else {
				if (isset($this->_rules['roles'][$role_id])) {
					$_roles[] = $role_id;
					if ($resource_id === NULL) {
						$this->_rules['roles'][$role_id]['access'] = $rule;
					}
				}
			}
			if ($resource_id === NULL) {
				$_resources = $this->_resources;
			} else {
				if (in_array($resource_id, $this->_resources)) {
					$_resources[] = $resource_id;
				}
			}
			if (is_array($privilege_id)) {
				$_privileges = $privilege_id;
			} else {
				$_privileges[] = $privilege_id;
			}
			foreach ($_roles as $_role_id) {
				foreach ($_resources as $_resource_id) {
					$_resource = &$this->_rules['roles'][$_role_id]['resources'][$_resource_id];
					if ($privilege_id === NULL) {
						$_resource['access'] = $rule;
						foreach ($_resource['privileges'] as &$_privilege) {
							$_privilege = $rule;
						}
						unset($_privilege);
					} else {
						foreach ($_privileges as $_privilege_id) {	
							$_resource['privileges'][$_privilege_id] = $rule;
						}
					}
					unset($_resource);
				}
			}
		}
	}
}