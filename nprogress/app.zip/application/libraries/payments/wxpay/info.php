<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: andery
 * Date: 13-10-29
 * Time: 下午4:21
 */

return array(
    'code'      => 'wxpay',
    'name'      => '微信支付',
    'desc'      => '微信支付',
    'online' => '1',
    'website'   => '',
    'config'    => array(
        'app_id'       => array(
            'text'  => 'AppID',
            'type'  => 'text',
        ),
        'app_secret'   => array(
            'text'  => 'AppSecret',
            'type'  => 'text',
        ),
        'pay_sign_key' => array(
            'text'  => 'PaySignKey',
            'type'  => 'text',
        ),
        'partner_id' => array(
            'text' => '商户号(PartnerID)',
            'type' => 'text',
        ),
        'partner_key' => array(
            'text' => '初始密钥(PartnerKey)',
            'type' => 'text'
        )
    ),
);