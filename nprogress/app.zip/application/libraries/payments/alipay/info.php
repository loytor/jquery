<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: andery
 * Date: 13-10-29
 * Time: 下午4:21
 */

return array(
    'code'      => 'alipay',
    'name'      => '支付宝',
    'desc'      => '支付宝网站(www.alipay.com) 是国内先进的网上支付平台',
    'online' => '1',
    'website'   => 'http://www.alipay.com',
    'config'    => array(
        'email'   => array(        //账号
            'text'  => '支付宝账号',
            'desc'  => '输入您在支付宝的账号',
            'type'  => 'text',
        ),
        'key'       => array(        //密钥
            'text'  => '交易安全校验码',
            'desc'  => '免费签约支付宝，获取校验码和ID',
            'type'  => 'text',
        ),
        'partner'   => array(        //合作者身份ID
            'text'  => '合作者身份ID',
            'type'  => 'text',
        )
    ),
);