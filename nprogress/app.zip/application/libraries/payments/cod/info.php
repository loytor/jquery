<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: andery
 * Date: 13-10-29
 * Time: 下午4:21
 */

return array(
    'code'      => 'cod',
    'name'      => '货到付款',
    'desc'      => '货到付款',
    'online' => '0',
    'website'   => 'http://www.weiba66.com',
    'config'    => array(),
);