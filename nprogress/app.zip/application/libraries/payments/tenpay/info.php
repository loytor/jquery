<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: andery
 * Date: 13-10-29
 * Time: 下午4:21
 */

return array(
    'code'      => 'tenpay',
    'name'      => '财付通',
    'desc'      => '财付通',
    'online' => '1',
    'website'   => '',
    'config'    => array(
        'partner_id' => array(
            'text' => '商户号(PartnerID)',
            'type' => 'text',
        ),
        'partner_key' => array(
            'text' => '初始密钥(PartnerKey)',
            'type' => 'text'
        )
    ),
);