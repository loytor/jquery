<?php defined('BASEPATH') OR exit('No direct script access allowed');

if ( ! function_exists('image_resize')) {
	function image_resize($image_path, $width, $height, $crop = FALSE) {
		$file_name = basename($image_path);
		$file_ext = strrchr($file_name, '.');
		$size_marker = '_'.$width.($height ? ('_'.$height) : '');
		$dest_image_path = str_replace($file_name, '', $image_path).substr($file_name, 0, -strlen($file_ext)).$size_marker.$file_ext;
		if (file_exists($dest_image_path)) {
			return FALSE;
		}
		
		$im = new Imagick();
		try {
			$im->readImage($image_path);
		} catch (Exception $e) {
			$im->clear();
			$im->destroy();
			return FALSE;
		}
		$source_w = $im->getImageWidth();
		$source_h = $im->getImageHeight();
		if (($source_w < $width) AND ($source_h < $height OR $height == 0)) {
			$im->clear();
			$im->destroy();
			copy($image_path, $dest_image_path);
			return array('full_path' => $dest_image_path, 'width' => $source_w, 'height' => $source_h);
		}
		$format = strtolower($im->getImageFormat());
		if ($format == 'gif') {
			$im = $im->coalesceImages();
			foreach ($im as $_f_im) {  
				if ($crop) {
					$_f_im->cropThumbnailImage($width, $height);
				} else {
					$_f_im->resizeImage($width, $height, Imagick::FILTER_CATROM, 1);
				}
			}
			$im->optimizeImageLayers();
			$im->writeImages($dest_image_path, TRUE);
			$im->clear();
			$im->destroy();
			if ( ! $crop) {
				$height = round($width * $source_h / $source_w);
			}
			return array('full_path' => $dest_image_path, 'width' => $width, 'height' => $height);
		} else if ($format == 'jpg' OR $format == 'jpeg') {
			$im->setImageFormat('jpeg');
			if ($crop) {
				$im->cropThumbnailImage($width, $height);
			} else {
				$im->resizeImage($width, $height, Imagick::FILTER_CATROM, 1);
			}
			$im->setImageCompression(Imagick::COMPRESSION_JPEG);
			$cq = $im->getImageCompressionQuality() * 0.8;
			if ($cq == 0) $cq = 80;
			$im->setImageCompressionQuality($cq);
			$im->stripImage();
			$im->writeImage($dest_image_path);
			$im->clear();
			$im->destroy();
			if ( ! $crop) {
				$height = round($width * $source_h / $source_w);
			}
			return array('full_path' => $dest_image_path, 'width' => $width, 'height' => $height);
		} else if ($format == 'png') {
			$im->setImageFormat('png');
			if ($crop) {
				$im->cropThumbnailImage($width, $height);
			} else {
				$im->resizeImage($width, $height, Imagick::FILTER_CATROM, 1);
			}
			$im->stripImage();
			$im->writeImage($dest_image_path);
			$im->clear();
			$im->destroy();
			if ( ! $crop) {
				$height = round($width * $source_h / $source_w);
			}
			return array('full_path' => $dest_image_path, 'width' => $width, 'height' => $height);
		} else {
			$im->clear();
			$im->destroy();
			return FALSE;
		}
	}
}

if ( ! function_exists('image_resize_small')) {
	function image_resize_small($image_path, $width, $height, $crop = FALSE) {
		$file_name = basename($image_path);
		$file_ext = strrchr($file_name, '.');
		$size_marker = '_'.$width.($height ? ('_'.$height) : '');
		$dest_image_path = str_replace($file_name, '', $image_path).substr($file_name, 0, -strlen($file_ext)).$size_marker.$file_ext;
		if (file_exists($dest_image_path)) {
			return FALSE;
		}

		$im = new Imagick();
		try {
			$im->readImage($image_path);
		} catch (Exception $e) {
			$im->clear();
			$im->destroy();
			return FALSE;
		}
		$source_w = $im->getImageWidth();
		$source_h = $im->getImageHeight();
		if($source_w <= $source_h){
			$width = $height = $source_h;
		}else{
			$width = $height = $source_w;
		}
// 		if (($source_w < $width) AND ($source_h < $height OR $height == 0)) {
// 			$im->clear();
// 			$im->destroy();
// 			copy($image_path, $dest_image_path);
// 			return array('full_path' => $dest_image_path, 'width' => $source_w, 'height' => $source_h);
// 		}
		$format = strtolower($im->getImageFormat());
		if ($format == 'gif') {
			$im = $im->coalesceImages();
			foreach ($im as $_f_im) {
				if ($crop) {
					$_f_im->cropThumbnailImage($width, $height);
				} else {
					$_f_im->resizeImage($width, $height, Imagick::FILTER_CATROM, 1);
				}
			}
			$im->optimizeImageLayers();
			$im->writeImages($dest_image_path, TRUE);
			$im->clear();
			$im->destroy();
			if ( ! $crop) {
				$height = round($width * $source_h / $source_w);
			}
			return array('full_path' => $dest_image_path, 'width' => $width, 'height' => $height);
		} else if ($format == 'jpg' OR $format == 'jpeg') {
			$im->setImageFormat('jpeg');
			if ($crop) {
				$im->cropThumbnailImage($width, $height);
			} else {
				$im->resizeImage($width, $height, Imagick::FILTER_CATROM, 1);
			}
			$im->setImageCompression(Imagick::COMPRESSION_JPEG);
			$cq = $im->getImageCompressionQuality() * 0.8;
			if ($cq == 0) $cq = 80;
			$im->setImageCompressionQuality($cq);
			$im->stripImage();
			$im->writeImage($dest_image_path);
			$im->clear();
			$im->destroy();
			if ( ! $crop) {
				$height = round($width * $source_h / $source_w);
			}
			return array('full_path' => $dest_image_path, 'width' => $width, 'height' => $height);
		} else if ($format == 'png') {
			$im->setImageFormat('png');
			if ($crop) {
				$im->cropThumbnailImage($width, $height);
			} else {
				$im->resizeImage($width, $height, Imagick::FILTER_CATROM, 1);
			}
			$im->stripImage();
			$im->writeImage($dest_image_path);
			$im->clear();
			$im->destroy();
			if ( ! $crop) {
				$height = round($width * $source_h / $source_w);
			}
			return array('full_path' => $dest_image_path, 'width' => $width, 'height' => $height);
		} else {
			$im->clear();
			$im->destroy();
			return FALSE;
		}
	}
}