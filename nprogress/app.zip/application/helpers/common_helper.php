<?php defined('BASEPATH') OR exit('No direct script access allowed');

if ( ! function_exists('left_nav')) {
    function left_nav() {
        $CI =& get_instance();
        $CI->load->config('app_nav');

        $class = $CI->router->fetch_class();
        $method = $CI->router->fetch_method();

        switch ($class) {
            case 'reserve':
            case 'reserve_order':
            case 'reserve_store':
            case 'reserve_category':
            case 'reserve_stuff':
            case 'reserve_form' :
                $type = $CI->uri->rsegment(3);
                $tpl_data['nav_list'] = array(
                    'reserve/'.$type => array('/reserve/'.$type,'基本配置'),
                    'reserve_store/'.$type => array('/reserve_store/'.$type,'门店列表'),
                    'reserve_form/'.$type => array('/reserve_form/'.$type,'自定义预定表单项'),
                );
                $tpl_data['nav_curr'] = $class . '/' . $type;
                break;
            case 'game':
                $type = $CI->input->get('type');
                $tpl_data['nav_list'] = array(
                    '1' => array('/game/index?type=1','大转盘'),
                    '2' => array('/game/index?type=2','水果达人'),
                    '3' => array('/game/index?type=3','刮刮乐'),
                    '4' => array('/game/index?type=4','砸金蛋'),
                    '5' => array('/game/index?type=5','摇一摇'),
                    '6' => array('/game/index?type=6','幸运卡牌'),
                    'c/shoot' => array('/c/shoot','点球大战'),
                    'setting' => array('/game/setting','接口设置')
                );

                if($method == 'setting')
                {
                    $tpl_data['nav_curr'] = $method;
                }
                else
                {
                    $tpl_data['nav_curr'] = $type ? $type : 1;
                }
                break;
            case 'robot':
                $tpl_data['nav_list'] = array(
                    'c/reply/index' => array('/c/reply/index','关键词回复管理'),
                    'c/welcome/index' => array('/c/welcome/index','关注时欢迎信息'),
                    'robot/index' => array('/robo/index','机器人')
                );
                $tpl_data['nav_curr'] = 'robot/index';
                break;
            default:
                $curr_key = $class . '/' . $method;
                $nav_list = $CI->config->item('left_nav');
                $show_list = array();
                foreach ($nav_list as $key => $val) {
                    if (array_key_exists($curr_key, $val)) {
                        foreach ($nav_list[$key] as $_key => $_val) {
                            if ($_val['display'] == 1) {
                                //(strpos($_key, 'field_manager') !== FALSE) && $_key = 'c/'.$_key;

                                $show_list[$_key] = array('/'.$_key,$_val['text']);
                            }
                        }
                        break;
                    }
                }

                if (!$show_list) {
                    return '';
                }
                $tpl_data['nav_list'] = $show_list;
                $tpl_data['nav_curr'] = $curr_key;
                break;
        }
        return $CI->load->view('left_nav', $tpl_data, TRUE);
    }
}

if ( ! function_exists('logged_user_id')) {
    function logged_user_id() {
        $CI =& get_instance();
        $user_id = $CI->session->userdata('user_id');
        return $user_id ? $user_id : FALSE;
    }
}

if ( ! function_exists('logged_username')) {
    function logged_username() {
        $CI =& get_instance();
        return $CI->session->userdata('username');
    }
}

if ( ! function_exists('logged_company')) {
    function logged_company() {
        $CI =& get_instance();
        return $CI->session->userdata('company');
    }
}

if ( ! function_exists('account_expire')) {
    function account_expire() {
        $CI =& get_instance();
        return $CI->session->userdata('expire');
    }
}

if ( ! function_exists('redirect_return')) {
    function redirect_return($redirect_url, $current_url = '') {
        $CI =& get_instance();
        if ($current_url == '') {
            $current_url = current_url();
        }
        $CI->session->set_userdata('redirect_url', $current_url);
        redirect($redirect_url);
    }
}

if ( ! function_exists('auto_redirect')) {
    function auto_redirect($default_redirect_url = '/', $only_return = FALSE) {
        $CI =& get_instance();
        $redirect_url = $CI->session->userdata('redirect_url');
        if ($redirect_url) {
            $CI->session->unset_userdata('redirect_url');
        } else {
            $redirect_url = $default_redirect_url;
        }
        if ($only_return) {
            return $redirect_url;
        } else {
            redirect($redirect_url);
        }
    }
}

if ( ! function_exists('new_id')) {
    function new_id() {
        return uniqid().sprintf("%03s", mt_rand(0, 100));
    }
}

if ( ! function_exists('cut')) {
    function cut($str, $len, $more = '...') {
        if (mb_strlen($str, 'UTF-8') > $len) {
            return mb_substr($str, 0, $len, 'UTF-8') . $more;
        } else {
            return $str;
        }
    }
}

if ( ! function_exists('full_url')) {
    function full_url($url, $domain) {
        if (stripos($url, 'http://') === FALSE) {
            $url = 'http://'.$domain.BASE_DOMAIN.'/'.ltrim($url, '/');
        }
        return $url;
    }
}

if ( ! function_exists('image_url')) {
    function image_url($image, $width = 0, $height = 0) {
        if ($image) {
            if ($width > 0) {
                $file_ext = strrchr(basename($image), '.');
                $size_marker = '_'.$width.($height ? ('_'.$height) : '');
                $image = substr($image, 0, -strlen($file_ext)).$size_marker.$file_ext;
            }
            if (stripos($image, 'http://') === FALSE) {
                $image = full_url($image, 'image');
            }
        }
        return $image;
    }
}

//根据相对路径读取图片服务器路径
if ( ! function_exists('image_full_url')) {
    function image_full_url($image) {
        if (stripos($image, 'http://') === FALSE) {
            $image = full_url('data/'.$image, 'image');
        }
        return $image;
    }
}

if ( ! function_exists('c_image_url')) {
    function c_image_url($image, $width = 0, $height = 0) {
        if ($image) {
            if ($width > 0) {
                $file_ext = strrchr(basename($image), '.');
                $size_marker = '_'.$width.($height ? ('_'.$height) : '');
                $image = substr($image, 0, -strlen($file_ext)).$size_marker.$file_ext;
            }
            if (stripos($image, 'http://') === FALSE) {
                $image = full_url($image, 'c');
            }
        }
        return $image;
    }
}


/**
+----------------------------------------------------------
 * 字符串截取，支持中文和其他编码
+----------------------------------------------------------
 * @param string $source 需要转换的字符串
 * @param string $start 开始位置
 * @param string $length 截取长度
 * @param string $charset 编码格式
 * @param string $suffix 截断显示字符后缀
+----------------------------------------------------------
 * @return string
+----------------------------------------------------------
 */
if ( ! function_exists('xs_substr')) {
    function xs_substr($source, $start=0, $length, $charset="utf-8", $suffix="")
    {
        if(function_exists("mb_substr"))        //采用PHP自带的mb_substr截取字符串
        {
            $string = mb_substr($source, $start, $length, $charset).$suffix;
        }
        elseif(function_exists('iconv_substr')) //采用PHP自带的iconv_substr截取字符串
        {
            $string = iconv_substr($source,$start,$length,$charset).$suffix;
        }
        else
        {
            $pattern['utf-8']   = "/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|[\xe0-\xef][\x80-\xbf]{2}|[\xf0-\xff][\x80-\xbf]{3}/";
            $pattern['gb2312'] = "/[\x01-\x7f]|[\xb0-\xf7][\xa0-\xfe]/";
            $pattern['gbk']    = "/[\x01-\x7f]|[\x81-\xfe][\x40-\xfe]/";
            $pattern['big5']   = "/[\x01-\x7f]|[\x81-\xfe]([\x40-\x7e]|\xa1-\xfe])/";
            preg_match_all($pattern[$charset], $source, $match);
            $slice = join("",array_slice($match[0], $start, $length));

            $string = $slice.$suffix;
        }
        return $string;
    }
}


/**
+----------------------------------------------------------
 * 随机生成一个6位数
+----------------------------------------------------------
 * @return string
+----------------------------------------------------------
 */
if ( ! function_exists('rand_uniqid')) {
    function rand_uniqid()
    {
        $in = time();
        $to_num = false;
        $passKey = rand(0,str_shuffle($in));
        $pad_up = 6;
        $index = "ABCDEFGHIJKLMNOPQRSTUVWXYZ23456789";
        $indexLen = strlen($index);
        if ($passKey !== null) {
            // Although this function's purpose is to just make the
            // ID short - and not so much secure,
            // you can optionally supply a password to make it harder
            // to calculate the corresponding numeric ID

            for ($n = 0; $n<$indexLen; $n++) {
                $i[] = substr( $index,$n ,1);
            }

            $passhash = hash('sha256',$passKey);
            $passhash = (strlen($passhash) < strlen($index))
                ? hash('sha512',$passKey)
                : $passhash;

            for ($n=0; $n < $indexLen; $n++) {
                $p[] =  substr($passhash, $n ,1);
            }

            array_multisort($p,  SORT_DESC, $i);
            $index = implode($i);
        }

        if ($to_num) {
            // Digital number  <<--  alphabet letter code
            $in  = strrev($in);
            $out = 0;
            $len = strlen($in) - 1;
            for ($t = 0; $t <= $len; $t++) {
                $bcpow = bcpow($indexLen, $len - $t);
                $out   = $out + strpos($index, substr($in, $t, 1)) * $bcpow;
            }

            if (is_numeric($pad_up)) {
                $pad_up--;
                if ($pad_up > 0) {
                    $out -= pow($indexLen, $pad_up);
                }
            }
            $out = sprintf('%F', $out);
            $out = substr($out, 0, strpos($out, '.'));
        } else {
            // Digital number  -->>  alphabet letter code
            if (is_numeric($pad_up)) {
                $pad_up--;
                if ($pad_up > 0) {
                    $in += pow($indexLen, $pad_up);
                }
            }

            $out = "";
            $floorLog = floor(log($in, $indexLen));
            for ($t = $floorLog; $t >= 0; $t--) {
                $bcp = bcpow($indexLen, $t);
                $a   = floor($in / $bcp) % $indexLen;
                $out = $out . substr($index, $a, 1);
                $in  = $in - ($a * $bcp);
            }
            $out = strrev($out); // reverse
        }
        return $out;
    }
}

/**
 * 验证电话号码（包括手机号码）
 */
if ( ! function_exists('valid_phone')) {
    function valid_phone($phoneNumber)
    {
        if (!preg_match("/^(13[0-9]{1}[0-9]{8}$|147[0-9]{8}$|15[0-9]{1}[0-9]{8}$|18[0-9]{1}[0-9]{8})|((\d{7,8})|(\d{4}|\d{3})-(\d{7,8})|(\d{4}|\d{3})-(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1})|(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1}))$/", $phoneNumber))
        {
            $ret = false;
        }
        else
        {
            $ret = true;
        }
        return $ret;
    }
}

/**
 * 验证手机号码
 */
if ( ! function_exists('valid_mobile')) {
    function valid_mobile($mobileNumber)
    {
        if (!preg_match("/^13[0-9]{1}[0-9]{8}$|147[0-9]{8}$|15[0-9]{1}[0-9]{8}$|18[0-9]{1}[0-9]{8}$/", $mobileNumber))
        {
            $ret = false;
        }
        else
        {
            $ret = true;
        }
        return $ret;
    }
}


//获取某目录下所有文件、目录名（不包括子目录下文件、目录名）
if ( ! function_exists('get_dir_files')) {
    function get_dir_files($dir, $ext=1)
    {
        $files = array();
        $handler = opendir($dir);
        while (($filename = readdir($handler)) !== false) {//务必使用!==，防止目录下出现类似文件名“0”等情况
            if ($filename != "." && $filename != "..") {
                $files[] = $ext ? $filename : basename($filename, '.'.pathinfo($filename)['extension']);
            }
        }
        closedir($handler);
        return $files;
    }
}


/**
 *
 * @author Qianc
 * @date 2014-7-23
 * @description 排序二维数组
 */
if ( ! function_exists('array_sort')) {
    function array_sort($arr, $keys, $type='asc'){
        $keysvalue = $new_array = array();
        foreach ($arr as $k=>$v){
            $keysvalue[$k] = $v[$keys];
        }
        if($type == 'asc'){
            asort($keysvalue);
        }else{
            arsort($keysvalue);
        }
        reset($keysvalue);
        foreach ($keysvalue as $k=>$v){
            $new_array[$k] = $arr[$k];
        }
        return $new_array;
    }
}

/**
 *
 * @author Qianc
 * @date 2014-7-21
 * @description 过滤原始私钥
 */
if ( ! function_exists('private_key_clean')) {
    function private_key_clean($private_key) {
        $begin = "-----BEGIN PRIVATE KEY-----";
        $end = "-----END PRIVATE KEY-----";

        $private_key = preg_replace("/".$begin."/", "", $private_key);
        $private_key = preg_replace("/".$end."/", '', $private_key);
        $private_key = preg_replace("//s", "", $private_key);
        $private_key = preg_replace('/\r|\n/', "", $private_key);

        return $private_key;
    }
}

/**
 *
 * @author Qianc
 * @date 2014-7-21
 * @description 过滤原始公钥
 */
if ( ! function_exists('public_key_clean')) {
    function public_key_clean($public_key) {
        $begin = "-----BEGIN PUBLIC KEY-----";
        $end = "-----END PUBLIC KEY-----";

        $public_key = preg_replace("/".$begin."/", "", $public_key);
        $public_key= preg_replace("/".$end."/", '', $public_key);
        $public_key = preg_replace("//s", "", $public_key);
        $public_key = preg_replace('/\r|\n/', "", $public_key);

        return $public_key;
    }
}


/**
 *
 * @author Qianc
 * @date 2014-7-15
 * @description 打印变量
 */
if ( ! function_exists('dump')) {
    function dump($var, $output = null) {
        if($output == null){
            echo "<pre>";
            print_r($var);
            echo "</pre>";
        }elseif($output == 'firephp'){
            FB::info($var);
        }
    }
}

if (!function_exists('wb_http_get')) {
    function wb_http_get($url)
    {
        $oCurl = curl_init();
        if (stripos($url, "https://") !== FALSE) {
            curl_setopt($oCurl, CURLOPT_SSL_VERIFYPEER, FALSE);
            curl_setopt($oCurl, CURLOPT_SSL_VERIFYHOST, FALSE);
        }
        curl_setopt($oCurl, CURLOPT_URL, $url);
        curl_setopt($oCurl, CURLOPT_RETURNTRANSFER, 1);
        $sContent = curl_exec($oCurl);
        $aStatus = curl_getinfo($oCurl);
        curl_close($oCurl);
        if (intval($aStatus["http_code"]) == 200) {
            return $sContent;
        } else {
            return false;
        }
    }
}