<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * CodeIgniter
 *
 * An open source application development framework for PHP 5.2.4 or newer
 *
 * NOTICE OF LICENSE
 *
 * Licensed under the Academic Free License version 3.0
 *
 * This source file is subject to the Academic Free License (AFL 3.0) that is
 * bundled with this package in the files license_afl.txt / license_afl.rst.
 * It is also available through the world wide web at this URL:
 * http://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to obtain it
 * through the world wide web, please send an email to
 * licensing@ellislab.com so we can send you a copy immediately.
 *
 * @package		CodeIgniter
 * @author		EllisLab Dev Team
 * @copyright	Copyright (c) 2008 - 2013, EllisLab, Inc. (http://ellislab.com/)
 * @license		http://opensource.org/licenses/AFL-3.0 Academic Free License (AFL 3.0)
 * @link		http://codeigniter.com
 * @since		Version 1.0
 * @filesource
 */

/*
| -------------------------------------------------------------------
| SMILEYS
| -------------------------------------------------------------------
| This file contains an array of smileys for use with the emoticon helper.
| Individual images can be used to replace multiple simileys.  For example:
| :-) and :) use the same image replacement.
|
| Please see user guide for more info:
| http://codeigniter.com/user_guide/helpers/smiley_helper.html
|
*/

$config['normal_field_types'] = array(
    'gender' => '性别',
    'age' => '年龄',
    'birthday' => '生日',
    'height' => '身高',
    'weight' => '体重',
    'blood' => '血型',
    'marry' => '婚姻状况',
    'constellation' => '星座',
    'zodiac' => '生肖',
    'edu' => '学历',
    'profession' => '职业',
    'zip' => '邮编',
    'email' => '邮箱'
);

$config['custom_field_types'] = array(
    'text' => '单行文本',
    'textarea' => '多行文本',
    'radio' => '单选按钮',
    'checkbox' => '复选框',
    'dropdown' => '下拉框',
    'number' => '数字',
    'datetime' => '日期和时间'
);

/* End of file smileys.php */
/* Location: ./application/config/smileys.php */