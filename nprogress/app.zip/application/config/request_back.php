<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Administrator
 * Date: 13-7-11
 * Time: 下午2:19
 * To change this template use File | Settings | File Templates.
 */

$config['request'] = array(
	'/ktv/index' => array(
		true, //是否需要登录
	),
	'/ktv/md_add' => array(
		true, //是否需要登录
	),
	'/ktv/md_del' => array(
		true,
	),
	'/ktv/room_add' => array(
		true,
	),
	'/ktv/room_del' => array(
		true,
	),
	'/ktv/room_copy' => array(
		true,
	),
	'/ktv/hot_index' => array(
		true,
	),
	'/ktv/hot_add' => array(
		true, //是否需要登录
		true, //是否加密toke,如果不填写，默认为false(不加密token)
	),
	'/ktv/ajax' => array(
		true,
	),
	'/diy_style/index' => array(
		true,
	),
	'/diy_style/ajax' => array(
		true,
	),
	'/custom_res/index' => array(
		true,
	),
	'/custom_res/save' => array(
		true,
	),
	'/custom_res/delete' => array(
		true,
	),
	'/robot/index' => array(
		true,
	),
	'/caipiao/index' => array(
		true,
	),
	'/caipiao/settings' => array(
		true,
	),
	'/menu/index' => array(
		true,
	),
	'/member_sys/index' => array(
		true,
	),
	'/member_sys/reset_pass' => array(
		true,
	),
	'/member_sys/unbind' => array(
		true,
	),
	'/member_sys/userlog' => array(
		true,
	),
	'/member_sys/settings' => array(
		true,
	),
	'/member_card/index' => array(
		true,
	),
	'/member_card/setting' => array(
		true,
	),
	'/member_card/setpwd' => array(
		true,
	),
	'/member_card/creditrule' => array(
		true,
	),
	'/member_card/addmoney' => array(
		true,
	),
	'/member_card/addcardcredit' => array(
		true,
	),
	'/member_card/forwardrule' => array(
		true,
	),
	'/member_card/consumerecord' => array(
		true,
	),
	'/member_card/creditrecord' => array(
		true,
	),
	'/member_card/consumereport' => array(
		true,
	),
	'/member_card/ticketreport' => array(
		true,
	),
	'/member_card/export' => array(
		true,
	),
	'/member_card/report_export' => array(
		true,
	),
	'/member_card/retrieve' => array(
		true,
	),
	'/member_ticket/index' => array(
		true,
	),
	'/member_ticket/add' => array(
		true,
		true, //是否加密toke,如果不填写，默认为false(不加密token)
	),
	'/member_ticket/delete' => array(
		true,
	),
	'/member_ticket/edit' => array(
		true,
		true,
	),
	'/member_ticket/listall' => array(
		true,
	),
	'/invitation/index' => array(
		true,
		true,
	),
	'/invitation/add' => array(
		true,
		true,
	),
	'/invitation/edit' => array(
		true,
		true,
	),
	'/invitation/delete' => array(
		true,
	),
	'/game/index'   =>  array(
		true,
	),
	'/game/add'   =>  array(
		true,
		true,
	),
	'/game/edit'   =>  array(
		true,
		true,
	),
	'/reserve/room' => array(
		true
	),
	'/reserve/ktv' => array(
		true
	),
	'/reserve/drive' => array(
		true
	),
	'/reserve/restaurant' => array(
		true
	),
	'/reserve/book' => array(
		true
	),
	'/reserve/cosmetician' => array(
		true
	),
	'/reserve/maintenance' => array(
		true
	),
	'/reserve/course' => array(
		true
	),
	'/reserve/table' => array(
		true
	),
	'/reserve_form/room' => array(
		true
	),
	'/reserve_form/ktv' => array(
		true
	),
	'/reserve_form/drive' => array(
		true
	),
	'/reserve_form/restaurant' => array(
		true
	),
	'/reserve_form/book' => array(
		true
	),
	'/reserve_form/cosmetician' => array(
		true
	),
	'/reserve_form/maintenance' => array(
		true
	),
	'/reserve_form/course' => array(
		true
	),
	'/reserve_form/table' => array(
		true
	),
	'/reserve_store/room' => array(
		true
	),
	'/reserve_store/ktv' => array(
		true
	),
	'/reserve_store/drive' => array(
		true
	),
	'/reserve_store/restaurant' => array(
		true
	),
	'/reserve_store/book' => array(
		true
	),
	'/reserve_store/cosmetician' => array(
		true
	),
	'/reserve_store/maintenance' => array(
		true
	),
	'/reserve_store/course' => array(
		true
	),
	'/reserve_store/table' => array(
		true
	),
	'/reserve_store/edit' => array(
		true
	),
	'/reserve_category/room' => array(
		true
	),
	'/reserve_category/ktv' => array(
		true
	),
	'/reserve_category/drive' => array(
		true
	),
	'/reserve_category/restaurant' => array(
		true
	),
	'/reserve_category/book' => array(
		true
	),
	'/reserve_category/cosmetician' => array(
		true
	),
	'/reserve_category/maintenance' => array(
		true
	),
	'/reserve_category/course' => array(
		true
	),
	'/reserve_category/table' => array(
		true
	),
	'/reserve_category/add' => array(
		true,
		true
	),
	'/reserve_category/edit' => array(
		true,
		true
	),
	'/reserve_category/delete' => array(
		true
	),
	'/reserve_stuff/room' => array(
		true
	),
	'/reserve_stuff/ktv' => array(
		true
	),
	'/reserve_stuff/drive' => array(
		true
	),
	'/reserve_stuff/restaurant' => array(
		true
	),
	'/reserve_stuff/book' => array(
		true
	),
	'/reserve_stuff/cosmetician' => array(
		true
	),
	'/reserve_stuff/maintenance' => array(
		true
	),
	'/reserve_stuff/course' => array(
		true
	),
	'/reserve_stuff/table' => array(
		true
	),
	'/reserve_stuff/add' => array(
		true,
		true
	),
	'/reserve_stuff/edit' => array(
		true,
		true
	),
	'/reserve_stuff/delete' => array(
		true
	),
	'/reserve_order/room' => array(
		true
	),
	'/reserve_order/ktv' => array(
		true
	),
	'/reserve_order/drive' => array(
		true
	),
	'/reserve_order/restaurant' => array(
		true
	),
	'/reserve_order/book' => array(
		true
	),
	'/reserve_order/cosmetician' => array(
		true
	),
	'/reserve_order/maintenance' => array(
		true
	),
	'/reserve_order/course' => array(
		true
	),
	'/reserve_order/table' => array(
		true
	),
	'/reserve_order/detail' => array(
		true
	),
	'/reserve_order/confirm' => array(
		true
	),
	'/reserve_order/cancel' => array(
		true
	),
	'/reserve_order/delete' => array(
		true
	),
	//汽车保养卡
	'/autocard/index' => array(
		true,
	),
	'/autocard/show' => array(
	    true,
	),
	'/autocard/edit' => array(
	    true,
	),
	'/autocard/show_vehicle' => array(
	    true,
	),
	'/autocard/edit_vehicle' => array(
	    true,
	),
	'/autocard/add_vehicle' => array(
	    true,
	),
	'/autocard/delete_vehicle' => array(
	    true,
	),
	'/autocard/show_vehicle_cate' => array(
	    true,
	),
	'/autocard/edit_vehicle_cate' => array(
	    true,
	),
	'/autocard/add_vehicle_cate' => array(
	    true,
	),
	'/autocard/delete_vehicle_cate' => array(
	    true,
	),
	'/autocard/add_account' => array(
	    true,
	),
	'/autocard/edit_account' => array(
	    true,
	),
	'/autocard/delete_account' => array(
	    true,
	),
	'/autocard/ajax_get_id' => array(
	    true,
	),
	'/game/record'   =>  array(
		true,
	),
	'/game/export'  => array(
		true,
	),
	'/game/delete'  => array(
		true,
	),
	'/game/slate'   => array(
		true,
	),
	'/game/search_x'   => array(
		true,
	),
	//地址管理
	'/address/index' => array(
		true,
	),
	'/address/add' => array(
		true,
		true,
	),
	'/address/edit' => array(
		true,
		true,
	),
	'/address/delete' => array(
		true,
	),
	'/address/setting' => array(
		true,
	),
	'/groupon/index' => array(true),
	'/groupon/lists' => array(true),
	'/groupon/add' => array(true, true),
	'/groupon/edit' => array(true, true),
	'/groupon/del' => array(true),
	'/groupon/up' => array(true),
	'/groupon/down' => array(true),
	'/groupon/store' => array(true),
	'/groupon/store_edit' => array(true),
	'/groupon/category' => array(true),
	'/groupon/category_add' => array(true),
	'/groupon/category_del' => array(true),
	'/groupon/order' => array(true),
	'/groupon/use_token' => array(true),
	//互动营销工具-->投票
	'/vote/index' => array(true),
	'/vote/add_paper' => array(true),
	'/vote/edit_paper' => array(true),
	'/vote/delete_paper' => array(true),
	'/vote/edit_release' => array(true),
	'/vote/edit_collection' => array(true),
	'/vote/vote_collection_data' => array(true),
	
	'/vote/question' => array(true),
    '/vote/add_question' => array(true),
    '/vote/edit_question' => array(true),
    '/vote/delete_question' => array(true),
	'/vote/statistics' => array(true),
	'/vote/vote_user' => array(true),
	'/vote/vote_all_user' => array(true),
	
	//答题闯关
	'/emigrated/index' => array(true),
	'/emigrated/add' => array(true),
	'/emigrated/update' => array(true),
	'/emigrated/delete' => array(true),
	'/emigrated/set_status' => array(true),
	'/emigrated_day/index' => array(true),
	'/emigrated_day/update' => array(true),
	'/emigrated_day/edit' => array(true),
	'/emigrated_day/delete' => array(true),
	
	'/exam/index' => array(true),
	'/exam/add' => array(true),
	'/exam/update' => array(true),
	'/exam/delete' => array(true),

	//联系我们
	'/contact/index' => array(
		true,
	),
	'/contact/add' => array(
		true,
		true,
	),
	'/contact/edit' => array(
		true,
		true,
	),
	'/contact/delete' => array(
		true,
	),
	'/contact/filter' => array(
		true,
	),
	'/assist/index' => array(
		true,
	),
	'/assist/setting' => array(
		true,
	),
	'/assist/add' => array(
		true,
		true
	),
	'/assist/edit' => array(
		true,
		true
	),
	'/assist/delete' => array(
		true
	),
);