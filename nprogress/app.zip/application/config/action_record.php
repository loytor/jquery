<?php
/**
 * Created by JetBrains PhpStorm.
 * User: llj
 * Date: 13-8-28
 * Time: 下午4:50
 * To change this template use File | Settings | File Templates.
 * 会员系统用户操作行为配置文件
 */

$config['action_record'] = array();
//帐号类
$config['action_record'][0][0][0] = '注册（帐号）';
$config['action_record'][0][1][0] = '重置密码（帐号）';
$config['action_record'][0][2][0] = '登录（帐号）';
$config['action_record'][0][3][0] = '登出（帐号）';
$config['action_record'][0][4][0] = '绑定微信（帐号）';
$config['action_record'][0][5][0] = '解绑微信（帐号）';
$config['action_record'][0][6][0] = '领取会员卡（帐号）';
//消费类
$config['action_record'][1][0][0] = '充值（消费）';
$config['action_record'][1][0][1] = '商家扣款（消费）';
$config['action_record'][1][0][2] = '现金消费（消费）';
$config['action_record'][1][1][0] = '付费（消费）';
$config['action_record'][1][2][0] = '使用代金券（消费）';
$config['action_record'][1][3][0] = '兑换优惠券（消费）';
$config['action_record'][1][4][0] = '使用优惠券（消费）';
$config['action_record'][1][5][0] = '商城（冻结消费）';
$config['action_record'][1][6][0] = '商城（扣除消费）';
$config['action_record'][1][7][0] = '商城（送还消费）';
//积分类
$config['action_record'][2][0][0] = '商家增加（积分）';
$config['action_record'][2][0][1] = '转发增加（积分）';
$config['action_record'][2][0][2] = '消费增加（积分）';
$config['action_record'][2][0][3] = '问卷增加（积分）';
$config['action_record'][2][0][4] = '闯关增加（积分）';
$config['action_record'][2][0][5] = '会员卡完善信息增加（积分）';
$config['action_record'][2][0][6] = '会员卡开卡增加（积分）';
$config['action_record'][2][0][7] = '商家充值赠送（积分）';
$config['action_record'][2][0][8] = '在线充值赠送（积分）';
$config['action_record'][2][0][9] = '现金消费赠送（积分）';
$config['action_record'][2][1][0] = '换券减少（积分）';
$config['action_record'][2][1][1] = '商家减少（积分）';
$config['action_record'][2][1][2] = '换优惠券减少（积分）';
$config['action_record'][2][1][3] = '商家清零 (积分) ';
$config['action_record'][2][1][4] = '商城消耗 (冻结积分) ';
$config['action_record'][2][1][5] = '商城消耗 (扣除积分) ';
$config['action_record'][2][1][6] = '商城消耗 (送还积分) ';


//所有类型列表
$config['all_type']['0_0_0'] = '注册（帐号）';
$config['all_type']['0_1_0'] = '重置密码（帐号）';
$config['all_type']['0_2_0'] = '登录（帐号）';
$config['all_type']['0_3_0'] = '登出（帐号）';
$config['all_type']['0_4_0'] = '绑定微信（帐号）';
$config['all_type']['0_5_0'] = '解绑微信（帐号）';
$config['all_type']['0_6_0'] = '领取会员卡（帐号）';
$config['all_type']['1_0_0'] = '充值（消费）';
$config['all_type']['1_0_1'] = '商家扣款（消费）';
$config['all_type']['1_0_2'] = '现金消费（消费）';
$config['all_type']['1_1_0'] = '付费（消费）';
$config['all_type']['1_2_0'] = '使用代金券（消费）';
$config['all_type']['1_5_0'] = '商城（消费）';
$config['all_type']['2_0_0'] = '商家增加（积分）';
$config['all_type']['2_0_1'] = '转发增加（积分）';
$config['all_type']['2_0_2'] = '消费增加（积分）';
$config['all_type']['2_0_3'] = '问卷增加（积分）';
$config['all_type']['2_0_4'] = '闯关增加（积分）';
$config['all_type']['2_0_5'] = '会员卡完善信息增加（积分）';
$config['all_type']['2_0_6'] = '会员卡开卡增加（积分）';
$config['all_type']['2_0_7'] = '商家充值赠送（积分）';
$config['all_type']['2_0_8'] = '在线充值赠送（积分）';
$config['all_type']['2_0_9'] = '现金消费赠送（积分）';
$config['all_type']['2_1_0'] = '换券减少（积分）';
$config['all_type']['2_1_1'] = '商家减少（积分）';
$config['all_type']['2_1_2'] = '换优惠券减少（积分）';
$config['all_type']['2_1_3'] = '商家清零 (积分) ';
$config['all_type']['2_1_4'] = '商城消耗 (积分) ';
//帐号类型列表
$config['action_type']['0_0'] = '注册（帐号）';
$config['action_type']['1_0'] = '重置密码（帐号）';
$config['action_type']['2_0'] = '登录（帐号）';
$config['action_type']['3_0'] = '登出（帐号）';
$config['action_type']['4_0'] = '绑定微信（帐号）';
$config['action_type']['5_0'] = '解绑微信（帐号）';
$config['action_type']['6_0'] = '领取会员卡（帐号）';
//消费类型列表
$config['consume_type']['0_0'] = '充值（消费）';
$config['consume_type']['0_1'] = '商家扣款（消费）';
$config['consume_type']['0_2'] = '现金消费（消费）';
$config['consume_type']['1_0'] = '付费（消费）';
$config['consume_type']['2_0'] = '使用代金券（消费）';
$config['consume_type']['3_0'] = '兑换优惠券（消费）';
$config['consume_type']['4_0'] = '使用优惠券（消费）';
$config['consume_type']['5_0'] = '商家（消费）';
//积分类型列表
$config['credit_type']['0_0'] = '商家增加（积分）';
$config['credit_type']['0_1'] = '转发增加（积分）';
$config['credit_type']['0_2'] = '消费增加（积分）';
$config['credit_type']['0_3'] = '问卷增加（积分）';
$config['credit_type']['0_4'] = '闯关增加（积分）';
$config['credit_type']['0_5'] = '会员卡完善信息增加（积分）';
$config['credit_type']['0_6'] = '会员卡开卡增加（积分）';
$config['credit_type']['0_7'] = '商家充值赠送（积分）';
$config['credit_type']['0_8'] = '在线充值赠送（积分）';
$config['credit_type']['0_9'] = '现金消费赠送（积分）';
$config['credit_type']['1_0'] = '换券减少（积分）';
$config['credit_type']['1_1'] = '商家减少（积分）';
$config['credit_type']['1_2'] = '换优惠券减少（积分）';
$config['credit_type']['1_3'] = '商家清零 (积分) ';
$config['credit_type']['1_4'] = '商城消耗 (积分) ';


