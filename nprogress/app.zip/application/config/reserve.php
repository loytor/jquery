<?php
/**
 * Created by JetBrains PhpStorm.
 * User: llj
 * Date: 13-9-10
 * Time: 下午2:16
 * To change this template use File | Settings | File Templates.
 */

//酒店预订特殊字段配置
/*$config['room_store'] = array(
	'url' => '/reserve/extend_room.html',
	'property' => array('num'=>'连锁店号')
);*/
/*$config['room_category'] = array(
	'url' => '/reserve_category/extend_room.html',
	'property' => array('count'=>'数量')
);
$config['room_stuff'] = array(
	'url' => '/reserve_stuff/extend_room.html',
	'property' => array('price'=>'价格')
);*/
$config['room_order'] = array(
	'property' => array(
		'out_time' => "退房时间",
		'memo' => "备注",
	)
);


//KTV包房预订特殊字段设置
/*$config['ktv_store'] = array(
	'url' => '/reserve/extend_ktv.html',
	'property' => array('num'=>'ktv店号')
);*/
$config['ktv_stuff'] = array(
	'url' => '/reserve_stuff/extend_ktv.html',
	'property' => array(
		'size'=>'容纳人数',
		'consume'=>'最低消费'
	)
);
$config['ktv_order'] = array(
	'property' => array(
		'num'=>'人数',
	)
);

//预约试驾特殊字段设置
$config['drive_stuff'] = array(
	//'url' => '/reserve_stuff/extend_drive.html',
/*	'property' => array(
		'displacement'=>'排量',
		'transmission'=>'变速器'
	)*/
);
$config['drive_order'] = array(
	'property' => array(
		'sex'=>'性别',
		'buy_time'=>'购车时间',
		'drive_age'=>'驾龄'
	)
);

//餐厅订餐特殊字段设置
$config['restaurant_order'] = array(
	'property' => array(
		'destination'=>'送餐地址',
		'memo'=>'备注',
	)
);

//图书预订特殊字段设置
$config['book_order'] = array(
	'property' => array(
		'destination'=>'送货地址',
		'memo'=>'备注信息',
	)
);

//美容预约特殊字段设置
$config['cosmetician_order'] = array(
	'property' => array(
		'memo'=>'备注信息',
	)
);

//汽车保养预约特殊字段设置
$config['maintenance_order'] = array(
	'property' => array(
		//'model' => '车型',
		'license' => '车牌号',
		'memo'=>'备注信息',
	)
);

//课程预约特殊字段设置
$config['course_order'] = array(
);

//课程预约特殊字段设置
$config['table_order'] = array(
);

//微挂号预约特殊字段设置
$config['register_order'] = array(
    'property' => array(
        'sex'=>'性别',
        'age'=>'年龄',
        'memo'=>'备注信息',
    )
);

//类型
$config['reserve_types'] = array(
	'room' => array('type'=>0, 'title'=>'酒店订房', 'stuff'=>'房间', 'order_time'=>'入住时间'),
	'ktv' => array('type'=>1, 'title'=>'KTV预订', 'stuff'=>'包房', 'order_time'=>'到达时间'),
	'drive' => array('type'=>2, 'title'=>'4S店预约试驾', 'stuff'=>'车型', 'order_time'=>'试驾时间'),
	'restaurant' => array('type'=>3, 'title'=>'外卖预订', 'stuff'=>'菜品', 'order_time'=>'订餐时间'),
	'book' => array('type'=>4, 'title'=>'图书预订', 'stuff'=>'图书', 'order_time'=>'订单时间'),
	'cosmetician' => array('type'=>5, 'title'=>'美容预约', 'stuff'=>'服务项目', 'order_time'=>'订单时间'),
	'maintenance' => array('type'=>6, 'title'=>'汽车保养预约', 'stuff'=>'服务项目', 'order_time'=>'预约时间'),
	'course' => array('type'=>7, 'title'=>'课程预约', 'stuff'=>'课程', 'order_time'=>'订单时间'),
	'table' => array('type'=>8, 'title'=>'餐厅预订（堂食版）', 'stuff'=>'餐桌包厢', 'order_time'=>'就餐时间'),
    'register' => array('type'=>9, 'title'=>'微挂号', 'stuff'=>'医生', 'order_time'=>'就诊时间'),
);

$config['key2type'] = array(
	'0' => 'room',
	'1' => 'ktv',
	'2' => 'drive',
	'3' => 'restaurant',
	'4' => 'book',
	'5' => 'cosmetician',
	'6' => 'maintenance',
	'7' => 'course',
	'8' => 'table',
    '9' => 'register'
);

//商家订单操作状态设置
$config['order_status'] = array(
	-2 => '删除',
	-1  => '取消',
	0  => '未处理',
	1  => '已确认',
);

//商家订单操作状态设置
$config['order_user_status'] = array(
	-2 => '删除',
	-1  => '取消',
	0  => '待处理',
	1  => '已处理',
);

//预订表单自定义字段
$config['reserve_form'] = array(
	0 => array('type'=>'文本', 'fields'=>array('custom4', 'custom5', 'custom6')), //文本
	1 => array('type'=>'列表', 'fields'=>array('custom13', 'custom14', 'custom15')), //列表
	2 => array('type'=>'日期', 'fields'=>array('custom7', 'custom8', 'custom9')), //日期
	3 => array('type'=>'日期时间', 'fields'=>array('custom16', 'custom17', 'custom18')), //日期时间
	4 => array('type'=>'性别', 'fields'=>array('gender')),
	5 => array('type'=>'年龄', 'fields'=>array('age')),
	6 => array('type'=>'生日', 'fields'=>array('birthday')),
	7 => array('type'=>'身高', 'fields'=>array('height')),
	8 => array('type'=>'体重', 'fields'=>array('weight')),
	9 => array('type'=>'婚姻状况', 'fields'=>array('marry')),
	10 => array('type'=>'血型', 'fields'=>array('blood')),
	11 => array('type'=>'星座', 'fields'=>array('constellation')),
	12 => array('type'=>'生肖', 'fields'=>array('zodiac')),
	13 => array('type'=>'学历', 'fields'=>array('edu')),
	14 => array('type'=>'职业', 'fields'=>array('profession')),
	15 => array('type'=>'邮编', 'fields'=>array('zip')),
	16 => array('type'=>'邮箱', 'fields'=>array('email')),
);