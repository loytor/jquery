<?php
$config['baidu_token'] = 'D5894ef9e6eb52db5afab2366bbbef58';