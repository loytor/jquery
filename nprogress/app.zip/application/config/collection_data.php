<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 用户扩展信息配置
 * @var unknown_type
 */
$config['collection_data'] = array(
    'gender'         => array('保密','男','女'),
    'marry'          => array('保密','已婚','未婚'),//婚姻状况
    'blood'          => array('A','B','AB','O'),
    'constellation'  => array('白羊座','金牛座','双子座','巨蟹座','狮子座','处女座','天秤座','天蝎座','射手座','魔羯座','水瓶座','双鱼座'),//星座
    'zodiac'         => array('鼠','牛','虎','兔','龙','蛇','马','羊','猴','鸡','狗','猪'),//生肖
    'edu'            => array('小学及以下','初中','高中','中专','大专','本科','研究生','博士及以上'),//学历
    'profession'     => array('在校学生','固定工作者','自由职业者','待业/无业/失业','退休','其他'),//职业
);