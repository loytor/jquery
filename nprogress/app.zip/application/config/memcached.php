<?php
/**
 * Created by PhpStorm.
 * User: andery
 * Date: 14-4-3
 * Time: 下午9:34
 */
$config['memcached'] = array(
/*    'hostname' => '10.66.11.161',
    'port'     => 1026,
    'weight'   => 1*/
    'hostname' => 'localhost',
    'port'     => 11211,
	'weight'   => 1
);