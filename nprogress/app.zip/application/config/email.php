<?php
$config['protocol'] = 'smtp';
/*$config['smtp_host'] = 'smtp.exmail.qq.com';
$config['smtp_user'] = 'support@bama555.com';
$config['smtp_pass'] = 'weiba66';
$config['smtp_port'] = '465';*/
$config['crlf'] = "\r\n";
$config['newline'] = "\r\n";
$config['smtp_host'] = 'smtp.163.com';
$config['smtp_user'] = 'bama555service@163.com';
$config['smtp_pass'] = 'weiba66';