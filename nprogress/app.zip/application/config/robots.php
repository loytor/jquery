<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * CodeIgniter
 *
 * An open source application development framework for PHP 5.2.4 or newer
 *
 * NOTICE OF LICENSE
 *
 * Licensed under the Academic Free License version 3.0
 *
 * This source file is subject to the Academic Free License (AFL 3.0) that is
 * bundled with this package in the files license_afl.txt / license_afl.rst.
 * It is also available through the world wide web at this URL:
 * http://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to obtain it
 * through the world wide web, please send an email to
 * licensing@ellislab.com so we can send you a copy immediately.
 *
 * @package		CodeIgniter
 * @author		EllisLab Dev Team
 * @copyright	Copyright (c) 2008 - 2013, EllisLab, Inc. (http://ellislab.com/)
 * @license		http://opensource.org/licenses/AFL-3.0 Academic Free License (AFL 3.0)
 * @link		http://codeigniter.com
 * @since		Version 1.0
 * @filesource
 */

/*
| -------------------------------------------------------------------
| SMILEYS
| -------------------------------------------------------------------
| This file contains an array of smileys for use with the emoticon helper.
| Individual images can be used to replace multiple simileys.  For example:
| :-) and :) use the same image replacement.
|
| Please see user guide for more info:
| http://codeigniter.com/user_guide/helpers/smiley_helper.html
|
*/

$config['robots'] = array(
	array('天气预报','查询例子:杭州天气 , 或直接输入区号 0571'),
	array('人品计算器','人品+姓名：例如：人品 张艺谋'),
	array('手机归属地查询','直接输入自己的手机号即可 例如：13888888888'),
	array('身份证查询','自己输入身份证号即可：例如：422202198500000000'),
	/*
	array('百科','百科（bk）+要查询的词:例如:百科毛泽东 bk 美国'),
	array('糗事','输入糗事或者任意字母:例如：糗事'),
	array('笑话','输入任何数字：0-9或者笑话或者对应笑脸表情'),
	array('陪聊纯洁版,绕口令,车牌归属','包含 绕口令数据 和 车牌归属地数据 ：查询方法 绕口令 和 闽D'),
	array('成语字典','例子：成语 半死不活'),
	array('谜语','输入谜语 即可 查谜语答案 输入：答案谜语编号 ：例如谜语 232'),
	array('百度问答','输入的问题超过5个字自动触发'),
	array('健康指数计算器','用法：（身高为cm 体重单位为公斤）例如:身高 173 体重 56 或输入:高 173 重 56 '),
	*/
	array('今日彩票','输入：体彩 彩票名称 例如 彩票 双色球[大乐透 七星彩 排列3 排列5 体彩22选5 胜负彩14场 任选9场 4场进球 6场半全场 老11选5 11选5 新11选5 双色球'),
	//array('号码吉凶','输入吉凶 + 号码 例如：吉凶 9987992920'),

	array('快递查询','公司名称+快递+单号:例如：顺风快递 203344128822'),
	array('公交搜索','城市+公交+车次 例如：杭州公交194路'),
	array('列车查询','用法：输入：火车 车次 或 火车 站点 站点；例如：火车 D111 火车杭州到南昌'),
	/*
	array('语音播报天气','开启天气者 默认使用语音方式播报'),
	array('陪聊','陪聊库 每天10万速度扩充'),
	array('翻译','英文你好 法文我爱你 德文我爱你 对着公众号发送翻译 可以查看更多支持的语音'),
	array('成语接龙','输入正确的成语即可 例如：一帆风顺'),
	array('诗歌接龙','输入诗词的任意一句 会读出下一句 例如:人生得意须尽欢'),
	array('诗歌赏析','名称查询：古诗 送孟浩然 名称作者查询 ： 古诗 将进酒 李白'),
	array('藏头藏尾诗','输入 藏头诗或cts 我爱你 或藏尾诗或cws例如：cws 我爱你'),
	array('电影检索','电影：电影名称 例如：电影 功夫熊猫'),
	array('股票查询','股票+股票代号或名称或拼音缩写 股票二字可以用gp 缩写'),
	*/
	array('解梦','用法：输入：梦见发财 ;梦见xx'),
	//array('网络音乐搜索','用户：音乐+歌名歌手均可 例如：音乐美丽神话 音乐周传雄'),
	//array('英语4-6级(2012-12月)','查询例子:cet 姓名 352011122102013'),
	
);

/* End of file smileys.php */
/* Location: ./application/config/smileys.php */