<?php
/**
 * Created by JetBrains PhpStorm.
 * User: llj
 * Date: 13-11-4
 * Time: 上午11:35
 * To change this template use File | Settings | File Templates.
 */
$config['left_nav'] = array(
/*    'reply/index' => array(
        'reply/index' => array('text' => '自动回复管理', 'display' => 1),
        'reply/add' => array('text' => '添加关键词回复', 'display' => 0),
        'reply/update' => array('text' => '编辑关键词回复','display' => 0),
        'setting/welcome' => array('text' => '关注时欢迎信息', 'display' => 1),
        'reply/setting' => array('text' => '设置默认回复', 'display' => 1),
        'robot/index' => array('text' => '机器人', 'display' => 1),
        'reply/cate' => array('text' => '栏目回复', 'display' => 1),
        'reply/music' => array('text' => '语音回复', 'display' => 1),
    ),*/
    'reply/index' => array(
        'reply/index' => array('text' => '微信', 'display' => 1),
        //'reply/alipay_index' => array('text' => '支付宝', 'display' => 1),
        //'reply/alipay_welcome' => array('text' => '支付宝关注时欢迎信息', 'display' => 0),
        //'reply/add_alipay' => array('text' => '增加支付宝关键词回复', 'display' => 0),
        //'reply/edit_alipay' => array('text' => '编辑支付宝关键词回复', 'display' => 0),
        'reply/add' => array('text' => '添加关键词回复', 'display' => 0),
        'reply/edit' => array('text' => '编辑','display' => 0),
        //'reply/alipay_imgtext' => array('text' => '新增项', 'display' => 0),
        //'reply/alipay_imgtext_edit' => array('text' => '编辑', 'display' => 0),
        'welcome/index' => array('text' => '关注时欢迎信息', 'display' => 0),
        'welcome/add' => array('text' => '新增项', 'display' => 0),
        'welcome/edit' => array('text' => '编辑', 'display' => 0),
        'reply/robot' => array('text' => '机器人', 'display' => 0)
    ),
    //自定义菜单
    'menu/index' => array(
        'menu/index' => array('text' => '微信菜单', 'display' => 1),
        'menu/alipay_index' => array('text' => '支付宝菜单', 'display' => 1)
    ),
	//微网站
	'cate/index' => array(
		'cate/index' => array('text' => '栏目管理', 'display' => 1),
        'cate/add' => array('text' => '添加栏目', 'display' => 0),
        'cate/update' => array('text' => '编辑栏目', 'display' => 0),
        'cate_lists/index' => array('text' => '内容管理', 'display' => 0),
		'article/index' => array('text' => '图文素材管理', 'display' => 1),
        'article/add' => array('text' => '图文素材管理', 'display' => 0),
        'article/update' => array('text' => '编辑图文素材', 'display' => 0),
        'article_contact/add' => array('text' => '图文素材管理', 'display' => 0),
		'cate_banner/index' => array('text' => '首页顶部广告', 'display' => 1),
        'cate_banner/add' => array('text' => '添加广告', 'display' => 0),
        'cate_banner/update' => array('text' => '编辑广告', 'display' => 0),
        'assist/index' => array('text' => '辅助按钮', 'display' => 1),
        'assist/setting' => array('text' => '辅助设置', 'display' => 0),
        'assist/add' => array('text' => '添加辅助按钮', 'display' => 0),
        'assist/edit' => array('text' => '编辑辅助按钮', 'display' => 0),
		'tpl/index' => array('text' => '模版选择', 'display' => 1),
		'custom_res/index' => array('text' => '模板资源', 'display' => 0),
        'custom/style' => array('text' => '自定义样式', 'display' => 1),
        'custom/home' => array('text' => '自定义首页', 'display' => 1),
        'effect/index' => array('text' => '网站特效', 'display' => 1),
        'setting/share' => array('text' => '分享设置', 'display' => 1),
        'setting/tools' => array('text' => '实用小工具', 'display' => 1),
        'setting/clearcache'=>array('text'=>'清理缓存','display'=>1),
	),
	//会员卡
	'member_card/index' => array(
        'member_card/setting' => array('text' => '会员卡设置', 'display' => 1),
        'member_card/index' => array('text' => '领取列表', 'display' => 1),
        'member_card/addmoney' => array('text' => '充值', 'display' => 0),
        'member_card/addcardcredit' => array('text' => '增加积分', 'display' => 0),
        'member_card/consumerecord' => array('text' => '消费记录', 'display' => 0),
        'member_card/creditrecord' => array('text' => '积分记录', 'display' => 0),
        'member_card/setpwd' => array('text' => '交易密码重置', 'display' => 1),
        'member_card/creditrule' => array('text' => '消费积分规则', 'display' => 1),
        'member_card/forwardrule' => array('text' => '转发积分规则', 'display' => 1),
/*        'member_ticket/index' => array('text' => '代金券', 'display' => 1),
        'member_ticket/add' => array('text' => '添加代金券', 'display' => 0),
        'member_ticket/edit' => array('text' => '编辑代金券', 'display' => 0),
        'member_ticket/listall' => array('text' => '领取列表', 'display' => 0),*/
        'member_card/consumereport' => array('text' => '消费报表', 'display' => 1),
        //'member_card/ticketreport' => array('text' => '代金券报表', 'display' => 1),
	),
	//4S车主关怀系统
	'autocard/index' => array(
        'autocard/show' => array('text' => '基本设置', 'display' => 1),
        'autocard/index' => array('text' => '客户列表', 'display' => 1),
        'autocard/show_vehicle_cate' => array('text' => '车系列表', 'display' => 1),
        'autocard/show_vehicle' => array('text' => '车型列表', 'display' => 1),
        'autocard/edit_account' => array('text' => '编辑客户', 'display' => 0),
        'autocard/edit_vehicle_cate' => array('text' => '编辑车系', 'display' => 0),
        'autocard/edit_vehicle' => array('text' => '编辑车型', 'display' => 0),
	),
	//团购
	'groupon/index' => array(
		'groupon/index' => array('text' => '基本配置', 'display' => 1),
		'groupon/category' => array('text' => '团购分类', 'display' => 1),
		'groupon/category_add' => array('text' => '添加分类', 'display' => 0),
		'groupon/lists' => array('text' => '团购列表', 'display' => 1),
		'groupon/add' => array('text' => '添加团购', 'display' => 0),
		'groupon/edit' => array('text' => '编辑团购', 'display' => 0),
		'groupon/order' => array('text' => '订单列表', 'display' => 1),
		'groupon/use_token' => array('text' => '使用', 'display' => 0),
	),
	//微商城
	'mall/index' => array(
        'mall/index' => array('text' => '基本配置', 'display' => 1),
        'mall/cate' => array('text' => '商品分类', 'display' => 1),
        'mall/cate_add' => array('text' => '添加分类', 'display' => 0),
        'mall/cate_edit' => array('text' => '编辑分类', 'display' => 0),
        'mall/lists' => array('text' => '商品列表', 'display' => 1),
        'mall/item_add' => array('text' => '添加商品', 'display' => 0),
        'mall/item_edit' => array('text' => '编辑商品', 'display' => 0),
        'mall/order' => array('text' => '订单列表', 'display' => 1),
        'mall/order_view' => array('text' => '查看订单', 'display' => 0),
        'mall/statistics' => array('text' => '数据统计', 'display' => 1),
        //'mall/payment' => array('text' => '支付方式', 'display' => 1),
        //'mall/payment_config' => array('text' => '配置支付', 'display' => 0),
        //'mall/payment_install' => array('text' => '安装支付', 'display' => 0),
		//'mall/payment_log' => array('text' => '支付记录', 'display' => 1),
	),
	//联系信息管理
	'address/index' => array(
		'address/index' => array('text' => '地址管理', 'display' => 1),
		'address/setting' => array('text' => '基本配置', 'display' => 1),
		'address/add' => array('text' => '添加地址', 'display' => 0),
		'address/edit' => array('text' => '编辑地址', 'display' => 0),
        'address/set_pwd' => array('text' => '设置交易密码', 'display' => 0),
		'contact/index' => array('text' => '联系我们', 'display' => 1),
		'contact/add' => array('text' => '添加联系我们', 'display' => 0),
		'contact/edit' => array('text' => '编辑联系我们', 'display' => 0),
	),

    //对接信息
    'butt/index' => array(
        'setting/index' => array('text' => '基本信息', 'display' => 1),
        'butt/index' => array('text' => '微信信息', 'display' => 1),
        //'c/basic_setting/alipay_info' => array('text'=>'支付宝服务窗','display'=>1),
        //'butt/alipay' => array('text' => '支付宝信息', 'display' => 1),
    ),
    'marketing/index' => array(
        'marketing/index' => array('text' => '游戏列表', 'display' => 1),
        //'marketing_rotate/add' => array('text' => '欢乐大转盘', 'display' => 1),
	    'marketing_rotate/update' => array('text' => '编辑欢乐大转盘', 'display' => 0),
        //'marketing_scratch/add' => array('text' => '刮刮乐', 'display' => 1),
	    'marketing_scratch/update' => array('text' => '编辑刮刮乐', 'display' => 0),
        //'marketing_fruit/add' => array('text' => '水果达人', 'display' => 1),
	    'marketing_fruit/update' => array('text' => '编辑水果达人', 'display' => 0),
	    'marketing_lottery_sncode/manager' => array('text' => '中奖管理', 'display' => 0),
	    'marketing_fruit_sncode/manager' => array('text' => '中奖管理', 'display' => 0),
    ),
    'live/index' => array(
        'live/index' => array('text' => '直播列表', 'display' => 1),
        'live/add' => array('text' => '创建直播', 'display' => 1),
        'live/edit' => array('text' => '修改直播', 'display' => 0)
    ),
	'comments/index' => array(
		'comments/index' => array('text' => '微留言列表', 'display' => 1),
		'comments/add' => array('text' => '添加留言', 'display' => 1),
        'comments/edit' => array('text' => '编辑留言', 'display' => 0),
        'comments/replylist' => array('text' => '回复列表', 'display' => 0),
        'comments/replyview' => array('text' => '回复详情', 'display' => 0),
	),
    'member_sys/index' => array(
        //'member_sys/index' => array('text' => '会员列表', 'display' => 1),
        //'member_sys/reset_pass' => array('text' => '重置密码', 'display' => 0),
        //'member_sys/userlog' => array('text' => '查看行为', 'display' => 0),
        //'member_sys/detail' => array('text' => '查看', 'display' => 0),


        'member/index' => array('text' => '粉丝列表', 'display' => 1),
        'member/set_pwd' => array('text' => '设置交易密码', 'display' => 1),
        'member/money_toggle' => array('text' => '金额调节', 'display' => 0),
        'member/credit_toggle' => array('text' => '积分调节', 'display' => 0),
        'member/cash' => array('text' => '现金消费', 'display' => 0),
        'member/detail' => array('text' => '增加积分', 'display' => 0),
        'member/reset_pass' => array('text' => '修改密码', 'display' => 0),
        'member/log' => array('text' => '日志', 'display' => 0),
        'member/credit_clear' => array('text' => '积分清零', 'display' => 0),
        'member/batch_credit_clear' => array('text' => '批量积分清零', 'display' => 0),
        'money/index' => array('text' => '钱包设置', 'display' => 1),
        'money/record' => array('text' => '消费记录', 'display' => 1),
        'credit/index' => array('text' => '积分设置', 'display' => 1),
        'credit_reason/index' => array('text' => '积分原因设置', 'display' => 1),
        'credit_reason/add' => array('text' => '添加', 'display' => 0),
        'credit_reason/edit' => array('text' => '编辑', 'display' => 0),
        'credit/record' => array('text' => '积分记录', 'display' => 1),
        'field_manager/index' => array('text' => '信息字段管理', 'display' => 1),
        'field_manager/add' => array('text' => '添加字段', 'display' => 0),
        'field_manager/edit' => array('text' => '编辑字段', 'display' => 0)
    ),
	'business_card/index' => array(
        'business_card/index' => array('text' => '微名片设置', 'display' => 1),
        'business_card/bcard_list' => array('text' => '微名片管理', 'display' => 1),
        'business_card/add' => array('text' => '添加微名片', 'display' => 0),
        'business_card/update' => array('text' => '修改 微名片管理', 'display' => 0),
    ),
    'mcard/index' => array(
        'mcard/index' => array('text' => '会员卡设置', 'display' => 1),
        'mcard_level/index' => array('text' => '会员卡等级', 'display' => 1),
        'mcard_level/add' => array('text' => '添加等级', 'display' => 0),
        'mcard_level/edit' => array('text' => '编辑等级', 'display' => 0),
        'mcard_level/editcard' => array('text' => '编辑卡片', 'display' => 0),
        'mcard_priv/group_index' => array('text' => '特权分组', 'display' => 0),
        'mcard_priv/group_add' => array('text' => '添加分组', 'display' => 0),
        'mcard_priv/group_update' => array('text' => '编辑分组', 'display' => 0),
        'mcard_priv/index' => array('text' => '会员卡特权', 'display' => 1),
        'mcard_priv/add' => array('text' => '添加特权', 'display' => 0),
        'mcard_priv/update' => array('text' => '修改特权', 'display' => 0),
		'mcard_activity/index' => array('text' => '会员卡活动', 'display' => 1),
	    'mcard_activity/add' => array('text' => '添加活动', 'display' => 0),
	    'mcard_activity/update' => array('text' => '修改活动', 'display' => 0),
        'mcard/member' => array('text' => '会员卡用户', 'display' => 1),
        'mcard/import' => array('text' => '会员卡导入', 'display' => 1),
        'mcard/bind_setting' => array('text' => '会员卡绑定', 'display' => 1),
        'mcard/statistics' => array('text' => '会员卡统计', 'display' => 1),
        'mcard/inter_set' => array('text' => '接口设置', 'display' => 1),
	),
    //微外卖
    '/waimai/index' => array(
        'waimai/index' => array('text'=>'外卖设置','display'=>1),
        'dishes/index' => array('text'=>'菜品库管理','display'=>1),
        'dishes/cate' => array('text'=>'分类管理','display'=>0),
        'dishes/cate_add' => array('text'=>'添加分类','display'=>0),
        'dishes/cate_edit' => array('text'=>'编辑分类','display'=>0),
        'dishes/cate_del' => array('text'=>'删除分类','display'=>0),
        'dishes/add' => array('text'=>'添加菜品','display'=>0),
        'dishes/edit' => array('text'=>'编辑菜品','display'=>0),
        'waimai_store/index' => array('text'=>'门店管理','display'=>1),
        'waimai_store/edit' => array('text'=>'门店编辑','display'=>0),
	    'waimai_store/config_address' => array('text'=>'添加门店','display'=>0),
	    'waimai_store/add_store' => array('text'=>'添加门店','display'=>0),
		'waimai_store/dishes' => array('text'=>'菜品管理','display'=>0),
        'waimai_store/get_dishes' => array('text'=>'选择菜品','display'=>0),
        'waimai_store/edit_dishes' => array('text'=>'编辑菜品','display'=>0),
	    'waimai_store/tags' => array('text'=>'门店标签','display'=>0),
	    'waimai_store/add_tag' => array('text'=>'添加标签','display'=>0),
	    'waimai_store/edit_tag' => array('text'=>'编辑标签','display'=>0),
        'waimai_store/order_detail' => array('text'=>'订单详情','display'=>0),
        'waimai_store/order_list' => array('text'=>'订单列表','display'=>0),
        'waimai/tongji' => array('text'=>'外卖统计','display'=>1),
        'waimai/store_tongji' => array('text'=>'外卖统计','display'=>0),
    ),
    //微外卖2.0
    '/waimai2/index' => array(
        'waimai2/index' => array('text'=>'外卖设置','display'=>1),
        'dishes2/index' => array('text'=>'菜品库管理','display'=>1),
        'dishes2/cate' => array('text'=>'分类管理','display'=>0),
        'dishes2/cate_add' => array('text'=>'添加分类','display'=>0),
        'dishes2/cate_edit' => array('text'=>'编辑分类','display'=>0),
        'dishes2/cate_del' => array('text'=>'删除分类','display'=>0),
        'dishes2/add' => array('text'=>'添加菜品','display'=>0),
        'dishes2/edit' => array('text'=>'编辑菜品','display'=>0),
        'waimai_store2/index' => array('text'=>'门店管理','display'=>1),
        'waimai_store2/edit' => array('text'=>'门店编辑','display'=>0),
        'waimai_store2/config_address' => array('text'=>'添加门店','display'=>0),
        'waimai_store2/add_store' => array('text'=>'添加门店','display'=>0),
        'waimai_store2/dishes' => array('text'=>'菜品管理','display'=>0),
        'waimai_store2/get_dishes' => array('text'=>'选择菜品','display'=>0),
        'waimai_store2/edit_dishes' => array('text'=>'编辑菜品','display'=>0),
        'waimai_store2/tags' => array('text'=>'门店标签','display'=>0),
        'waimai_store2/add_tag' => array('text'=>'添加标签','display'=>0),
        'waimai_store2/edit_tag' => array('text'=>'编辑标签','display'=>0),
        'waimai_store2/order_detail' => array('text'=>'订单详情','display'=>0),
        'waimai_store2/order_list' => array('text'=>'订单列表','display'=>0),
        'waimai2/tongji' => array('text'=>'外卖统计','display'=>1),
        'waimai2/store_tongji' => array('text'=>'外卖统计','display'=>0),
    ),
    /*菜品库
    'dishes/index' => array(
        'dishes/index' => array('text'=>'菜品库管理','display'=>1),
        'dishes/cate' => array('text'=>'分类管理','display'=>1),
        'dishes/cate_add' => array('text'=>'添加分类','display'=>0),
        'dishes/cate_edit' => array('text'=>'编辑分类','display'=>0),
        'dishes/cate_del' => array('text'=>'删除分类','display'=>0),
        'dishes/add' => array('text'=>'添加菜品','display'=>1),
        'dishes/edit' => array('text'=>'编辑菜品','display'=>0),
    ),
    */
    //优惠券
    '/marketing_coupon/index' => array(
        'marketing_coupon/index' => array('text' => '优惠券', 'display' => 1),
        'marketing_coupon/add' => array('text' => '添加优惠券', 'display' => 0),
        'marketing_coupon/update' => array('text' => '编辑', 'display' => 0),
        'member_ticket/index' => array('text' => '代金券', 'display' => 1),
        'member_ticket/add' => array('text' => '添加代金券', 'display' => 0),
        'member_ticket/edit' => array('text' => '编辑代金券', 'display' => 0),
        'member_ticket/listall' => array('text' => '领取列表', 'display' => 0),
        'member_card/ticketreport' => array('text' => '代金券报表', 'display' => 1),
    ),
    //支付管理
    'wbpay/index' => array(
        //'payment/index' => array('text' => '支付方式', 'display' => 0),
        //'payment/config' => array('text' => '配置', 'display' => 0),
        //'payment/install' => array('text' => '安装', 'display' => 0),
        //'payment/uninstall' => array('text' => '卸载', 'display' => 0),
        //'payment/log' => array('text' => '支付记录(旧)', 'display' => 1),
        'wbpay/index' => array('text'=>'支付中心','display'=>1),
        'wbpay/open' => array('text'=>'开通商户','display'=>0),
        'wbpay/config_partner' => array('text'=>'修改商户信息','display'=>0),
        'wbpay/config_partner' => array('text'=>'修改商户信息','display'=>0),
        'wbpay/config_pay' => array('text'=>'安装/修改支付方式','display'=>0),
        'wbpay/uninstall_pay' => array('text'=>'卸载支付方式','display'=>0),
    	'wbpay/log' => array('text'=>'支付中心记录','display'=>1),
        'payment/log' => array('text' => '支付记录(旧)', 'display' => 1)
    ),
    //微贺卡
    'gcard/index' => array(
        'gcard/index' => array('text' => '贺卡设置', 'display' => 1),
        'gcard/types' => array('text' => '贺卡类型列表', 'display' => 1),
        'gcard/statistics' => array('text' => '贺卡统计', 'display' => 1)
    ),
    
    //优惠券
    'coupon/index' => array(
        'coupon/index' => array('text' => '基本设置', 'display' => 1),
        'coupon/quan_list' => array('text' => '优惠券管理', 'display' => 1),
        'coupon/quan_add' => array('text' => '添加优惠券', 'display' => 0),
        'coupon/quan_edit' => array('text' => '修改优惠券', 'display' => 0),
        'coupon/quan_delete' => array('text' => '删除优惠券', 'display' => 0),
        'coupon/statistics' => array('text' => '统计报表', 'display' => 1),
        'coupon/receive_coupon' => array('text' => '领取记录', 'display' => 0),
        'coupon/use_statistics' => array('text' => '使用记录', 'display' => 0),
        'coupon/statistics1' => array('text' => '使用统计', 'display' => 0),
        'coupon/quan_history' => array('text' => '单券历史', 'display' => 0)
    ),

    //推广
    /*'tuiguang/index' => array(
        'tuiguang/index' => array('text' => '微商联盟', 'display' => 1),
        'tuiguang/lists' => array('text' => '活动列表', 'display' => 1),
        'tuiguang/detail' => array('text' => '活动详细', 'display' => 0),
        'tuiguang/apply' => array('text' => '申请', 'display' => 0),
        'tuiguang/my' => array('text' => '申请列表', 'display' => 1),
        'tuiguang/orders' => array('text' => '中奖列表', 'display' => 0),
        'tuiguang/launch' => array('text' => '发起活动', 'display' => 1),
        'lbs/index' => array('text'=>'LBS微商圈','display'=>1)
    ),*/
    
    //转发有礼
    'forward/index' => array(
        'forward/index' => array('text' => '转发活动列表', 'display' => 1),
        'forward/add' => array('text' => '添加转发有礼活动', 'display' => 1),
        'forward/edit' => array('text' => '添加转发有礼活动', 'display' => 0),
        'forward/rank' => array('text' => '转发排名', 'display' => 0),
        'forward/statistics' => array('text' => '转发统计', 'display' => 0),
        'forward/export' => array('text' => '导出', 'display' => 0),
        'forward/is_ban' => array('text' => '已封杀', 'display' => 0),
    ),

    //微现场
    'scene/index' => array(
        'scene/index' => array('text' => '微现场列表', 'display' => 1),
        'scene/add' => array('text' => '添加微现场', 'display' => 0),
        'scene/edit' => array('text' => '编辑微现场', 'display' => 0),
        'scene/statistics' => array('text' => '人数统计', 'display' => 0),
        'scene/wall' => array('text' => '微上墙', 'display' => 1),
        'scene/lottery' => array('text' => '幸运大抽奖', 'display' => 1),
        'scene/shake' => array('text' => '摇一摇', 'display' => 1),
        'scene/pairup' => array('text' => '对对碰', 'display' => 1),
        'scene/vote' => array('text' => '投票', 'display' => 1),
    ),
    
    //微配送
    '/peisong/index' => array(
        'peisong/index' => array('text'=>'配送设置','display'=>1),
        'shangpin/index' => array('text'=>'商品库管理','display'=>1),
        'shangpin/cate' => array('text'=>'分类管理','display'=>0),
        'shangpin/cate_add' => array('text'=>'添加分类','display'=>0),
        'shangpin/cate_edit' => array('text'=>'编辑分类','display'=>0),
        'shangpin/cate_del' => array('text'=>'删除分类','display'=>0),
        'shangpin/add' => array('text'=>'添加商品','display'=>0),
        'shangpin/edit' => array('text'=>'编辑商品','display'=>0),
        'peisong_store/index' => array('text'=>'门店管理','display'=>1),
        'peisong_store/edit' => array('text'=>'门店编辑','display'=>0),
        'peisong_store/config_address' => array('text'=>'添加门店','display'=>0),
        'peisong_store/add_store' => array('text'=>'添加门店','display'=>0),
        'peisong_store/shangpin' => array('text'=>'商品管理','display'=>0),
        'peisong_store/get_shangpin' => array('text'=>'选择商品','display'=>0),
        'peisong_store/edit_shangpin' => array('text'=>'编辑商品','display'=>0),
        'peisong_store/tags' => array('text'=>'门店标签','display'=>0),
        'peisong_store/add_tag' => array('text'=>'添加标签','display'=>0),
        'peisong_store/edit_tag' => array('text'=>'编辑标签','display'=>0),
        'peisong_store/order_detail' => array('text'=>'订单详情','display'=>0),
        'peisong_store/order_list' => array('text'=>'订单列表','display'=>0),
        'peisong/tongji' => array('text'=>'配送统计','display'=>1),
        'peisong/store_tongji' => array('text'=>'配送统计','display'=>0),
    ),

    //硬件设置
    'hardware/index' => array(
        'hardware/index' => array('text' => '小票打印机设置', 'display' => 1)
    ),
    /*//渠道管理
    'qudao/index' => array(
        'qudao/index' => array('text'=>'渠道管理','display'=>1),
        'qudao/cate' => array('text'=>'分组管理','display'=>1),
        'qudao/cate_add' => array('text'=>'添加分组','display'=>0),
        'qudao/cate_edit' => array('text'=>'编辑分组','display'=>0),
        'qudao/cate_del' => array('text'=>'删除分组','display'=>0),
        'qudao/add' => array('text'=>'添加渠道','display'=>0),
        'qudao/edit' => array('text'=>'编辑渠道','display'=>0),
        'qudao/keyword' => array('text'=>'渠道关键字','display'=>0),
        'qudao/online' => array('text'=>'上线','display'=>0),
        'qudao/offline' => array('text'=>'下线','display'=>0),
        'qudao/delete' => array('text'=>'删除','display'=>0),
        'qudao/account' => array('text'=>'渠道用户','display'=>1),
    ),*/
    //渠道管理
    'qudao/index' => array(
        'qudao_cate/index' => array('text'=>'渠道分组','display'=>1),
        'qudao_zhibiao/index' => array('text'=>'渠道指标','display'=>1),
        'qudao/index' => array('text'=>'渠道管理','display'=>1),
        'qudao/account' => array('text'=>'渠道用户','display'=>1),
        'qudao/statistics' => array('text'=>'渠道统计','display'=>1),
        'qudao/add' => array('text'=>'添加渠道','display'=>0),
        'qudao/edit' => array('text'=>'编辑渠道','display'=>0),
        'qudao/keyword' => array('text'=>'渠道关键字','display'=>0),
        'qudao/mobile_keyword' => array('text'=>'手机管理关键字','display'=>0),
        'qudao/online' => array('text'=>'上线','display'=>0),
        'qudao/offline' => array('text'=>'下线','display'=>0),
        'qudao/delete' => array('text'=>'删除','display'=>0),
        'qudao_cate/add' => array('text'=>'添加分组','display'=>0),
        'qudao_cate/edit' => array('text'=>'编辑分组','display'=>0),
        'qudao_cate/delete' => array('text'=>'删除分组','display'=>0),
        'qudao_zhibiao/add' => array('text'=>'添加指标','display'=>0),
        'qudao_zhibiao/edit' => array('text'=>'编辑指标','display'=>0),
        'qudao_zhibiao/delete' => array('text'=>'删除指标','display'=>0),
        'qudao_cate/base_info' => array('text'=>'数据统计','display'=>0),
        'qudao_cate/details' => array('text'=>'详细信息','display'=>0),
        'qudao/base_info' => array('text'=>'数据统计','display'=>0),
        'qudao/details' => array('text'=>'详细信息','display'=>0)
    ),
    //微相册
    'album/index' => array(
        'album/set' => array('text'=>'业务设置','display'=>1),
        'album/index' => array('text'=>'相册列表','display'=>1),
        'album/add' => array('text'=>'添加相册','display'=>0),
        'album/edit' => array('text'=>'编辑相册','display'=>0),
        'album/album_img' => array('text'=>'相册照片','display'=>0)
    ),
	//打印机设置
    'printer/index' => array(
        'printer/index' => array('text'=>'管理打印机','display'=>1),
        'printer/set' => array('text'=>'设置打印机','display'=>1),
        'printer/add' => array('text'=>'添加打印机','display'=>0),
        'printer/edit' => array('text'=>'管理打印机','display'=>0),
        'printer/consumeCode' => array('text'=>'消费码','display'=>0),
        'printer/addcode' => array('text'=>'生成消费码','display'=>0),
        'printer/order' => array('text'=>'消费记录','display'=>0),
    ),
	//新打印机
	'printer/rtwo' => array(
		'printer/rtwo' => array('text'=>'设置打印机','display'=>1)
	),
	
	'enroll/index' => array(
        'enroll/index' => array('text'=>'报名列表','display'=>1),
        'enroll/fields' => array('text'=>'报名内容列表','display'=>0),
        'enroll/fieldAdd' => array('text'=>'添加报名内容','display'=>0),
        'enroll/fieldEdit' => array('text'=>'编辑报名内容','display'=>0),
        'enroll/sta' => array('text'=>'报名统计','display'=>0),
        'enroll/staView' => array('text'=>'查看报名详情','display'=>0),
        'enroll/add' => array('text'=>'添加报名','display'=>0),
        'enroll/edit' => array('text'=>'编辑报名','display'=>0),
    ),
    'checkin/index' => array(
        'checkin/index' => array('text'=>'签到列表','display'=>1),
        'checkin/add' => array('text'=>'添加签到','display'=>0),
    	'checkin/edit' => array('text'=>'编辑签到','display'=>0),
    	'checkin/duihuan' => array('text'=>'兑换设置','display'=>0),
        'checkin/ex_list' => array('text'=>'兑换人员列表','display'=>0),
        'checkin/youxi' => array('text'=>'游戏设置','display'=>0),
    	'checkin/statis' => array('text'=>'数据统计','display'=>0),
    	'checkin/exinfo' => array('text'=>'兑换添加','display'=>0),
    	'checkin/yx_add' => array('text'=>'兑换添加','display'=>0),
    	'checkin/dh_edit' => array('text'=>'兑换添加','display'=>0),
    	'checkin/dh_add' => array('text'=>'兑换添加','display'=>0),
    	'checkin/yx_edit' => array('text'=>'兑换添加','display'=>0),
    	'checkin/record' => array('text'=>'兑换添加','display'=>0),
    ),
    'advert/index' => array(
        'advert/index' => array('text'=>'广告列表','display'=>1),
        'advert/add' => array('text'=>'广告添加','display'=>0),
        'advert/edit' => array('text'=>'广告编辑','display'=>0),
        'advert/app' => array('text'=>'微测试','display'=>0),
        'advert/app_add' => array('text'=>'添加广告','display'=>0),
        'advert/app/ceshi' => array('text'=>'微测试','display'=>1),
        'advert/app/checkin' => array('text'=>'微签到','display'=>1),
    ),
    //多客服
    'c_service/index' => array(
        'c_service/index' => array('text'=>'基本设置','display'=>1),
        'c_service/faq' => array('text'=>'使用说明','display'=>1),
        'c_service/plugin' => array('text'=>'插件管理','display'=>1),
        'c_service/down' => array('text'=>'PC客户端下载','display'=>1),
        'c_service/wxhelper' => array('text'=>'微信客户端','display'=>1),
    ),
    //微测试
    'ceshi/index' => array(
        'ceshi/index' => array('text'=>'测试列表','display'=>1),
        'ceshi/add' => array('text'=>'添加新测试','display'=>1),
        'ceshi/edit' => array('text'=>'编辑测试','display'=>0),
        'ceshi/options' => array('text'=>'设置选项','display'=>0),
        'ceshi/tongji' => array('text'=>'统计','display'=>0),
        'ceshi/op_add' => array('text'=>'添加选项','display'=>0),
        'ceshi/op_edit' => array('text'=>'编辑选项','display'=>0),
    ),
    //微点菜
    '/diancai/index' => array(
        'diancai/index' => array('text'=>'点菜设置','display'=>1),
        'diancai_fshangpin/index' => array('text'=>'菜品库管理','display'=>1),
        'diancai_fshangpin/cate' => array('text'=>'分类管理','display'=>0),
        'diancai_fshangpin/cate_add' => array('text'=>'添加分类','display'=>0),
        'diancai_fshangpin/cate_edit' => array('text'=>'编辑分类','display'=>0),
        'diancai_fshangpin/cate_del' => array('text'=>'删除分类','display'=>0),
        'diancai_fshangpin/add' => array('text'=>'添加菜品','display'=>0),
        'diancai_fshangpin/edit' => array('text'=>'编辑菜品','display'=>0),
        'diancai_store/index' => array('text'=>'门店管理','display'=>1),
        'diancai_store/edit' => array('text'=>'门店编辑','display'=>0),
        'diancai_store/config_address' => array('text'=>'添加门店','display'=>0),
        'diancai_store/add_store' => array('text'=>'添加门店','display'=>0),
        'diancai_store/shangpin' => array('text'=>'菜品管理','display'=>0),
        'diancai_store/get_shangpin' => array('text'=>'选择菜品','display'=>0),
        'diancai_store/edit_shangpin' => array('text'=>'编辑菜品','display'=>0),
        'diancai_store/tags' => array('text'=>'门店标签','display'=>0),
        'diancai_store/add_tag' => array('text'=>'添加标签','display'=>0),
        'diancai_store/edit_tag' => array('text'=>'编辑标签','display'=>0),
        'diancai_desk/index' => array('text'=>'餐台管理','display'=>0),
        'diancai_desk/add' => array('text'=>'添加餐台','display'=>0),
        'diancai_desk/edit' => array('text'=>'编辑餐台','display'=>0),
        'diancai_steer/index' => array('text'=>'智能推荐','display'=>0),
        'diancai_steer/add' => array('text'=>'添加推荐','display'=>0),
        'diancai_steer/edit' => array('text'=>'编辑推荐','display'=>0),
        'diancai_store/order_detail' => array('text'=>'订单详情','display'=>0),
        'diancai_store/order_list' => array('text'=>'订单列表','display'=>0),
        'diancai/tongji' => array('text'=>'点菜统计','display'=>1),
        'diancai/store_tongji' => array('text'=>'点菜统计','display'=>0),
    ),
    //点球大战
    'shoot/index' => array(
        'shoot/index' => array('text'=>'游戏设置','display'=>1),
        'shoot/score' => array('text'=>'数据统计','display'=>1),
    ),
    //射门
    'shooting/index' => array(
        'shooting/index' => array('text'=>'游戏列表','display'=>1),
        'shooting/set' => array('text'=>'新增（编辑）','display'=>1),
        'shooting/record'=>array('text'=>'数据统计','display'=>0)
    ),
    //七夕
    'lover/index' => array(
        'lover/index' => array('text'=>'游戏列表','display'=>1),
        'lover/set' => array('text'=>'新增（编辑）','display'=>1),
        'lover/record'=>array('text'=>'数据统计','display'=>0)
    ),
    //微竞猜
    'quiz/index' => array(
        'quiz/index' => array('text'=>'竞猜列表','display'=>1),
        'quiz/set' => array('text'=>'新增(编辑)','display'=>1),
        'quiz/op_list' => array('text'=>'选项列表','display'=>0),
        'quiz/opAdd' => array('text'=>'添加新竞猜','display'=>0),
        'quiz/opEdit' => array('text'=>'编辑竞猜','display'=>0),
        'quiz/opSta'=>array('text'=>'统计','display'=>0),
        'quiz/opExport'=>array('text'=>'结彩结果导出','display'=>0),
        'quiz/setResult'=>array('text'=>'公布结果','display'=>0),
        'quiz/bangdan' => array('text'=>'榜单','display'=>0)
    ),
    //微喜帖
    'wedding/index' => array(
        'wedding/index' => array('text'=>'喜帖配置','display'=>1),
        'wedding/weddings' => array('text'=>'喜帖列表','display'=>1),
        'wedding/add' => array('text'=>'添加喜帖','display'=>0),
        'wedding/edit' => array('text'=>'编辑喜帖','display'=>0),
        'wedding/yewudan_edit' => array('text'=>'喜帖业务单','display'=>0),
        'wedding/benison' => array('text'=>'祝福墙','display'=>0),
        'wedding/joinbless' => array('text'=>'赴宴统计','display'=>0),
    ),
    //微政务
    'chief/index'=>array(
        'chief/index' => array('text'=>'政务列表','display'=>1),
        'chief/add' => array('text'=>'添加政务','display'=>0),
        'chief/edit' => array('text'=>'编辑政务','display'=>0),
        'chief_message/index' => array('text'=>'留言列表','display'=>0),
        'chief_message/detail' => array('text'=>'留言详情','display'=>0),
        'ip_black/index' => array('text'=>'封禁记录','display'=>1),
    ),

    //冰桶挑战赛
    'als/index' => array(
    'als/index' => array('text'=>'挑战列表','display'=>1),
    'als/add' => array('text'=>'添加挑战','display'=>0),
    'als/edit' => array('text'=>'编辑挑战','display'=>0),
    'als/statistics' => array('text'=>'挑战统计','display'=>0)
    ),

    //微商联盟
    'tuiguang/index' => array(
        'tuiguang/index' => array('text' => '微商联盟', 'display' => 1),
        'business_union/index' => array('text'=>'活动列表','display'=>1),
        'business_union/joinMe' => array('text'=>'我参与的','display'=>0),
        'business_union/sponsorMe' => array('text'=>'我发起的','display'=>0),
        //'business_union/edit' => array('text'=>'编辑挑战','display'=>0),
        //'als/statistics' => array('text'=>'挑战统计','display'=>0)

        'business_union/add_activity' => array('text'=>'添加活动','display'=>1),
        'business_union/edit_activity' => array('text'=>'编辑活动','display'=>0),
        'business_union/delete_activity' => array('text'=>'删除活动','display'=>0),
        'business_union/detail_activity' => array('text'=>'活动详情','display'=>0),

        'business_union/prize_list' => array('text'=>'奖品列表','display'=>0),
        'business_union/add_activity_prize' => array('text'=>'添加奖品','display'=>0),
        'business_union/edit_activity_prize' => array('text'=>'添加奖品','display'=>0),
        'business_union/delete_activity_prize' => array('text'=>'删除奖品','display'=>0),

        'business_union/apply_activity' => array('text'=>'申请活动','display'=>0),
        'business_union/apply_activity_edit' => array('text'=>'修改申请信息','display'=>0),
        'business_union/apply_info' => array('text'=>'查看申请信息','display'=>0),
        'business_union/applyList' => array('text'=>'待审核商家列表','display'=>0),
        'business_union/material' => array('text'=>'素材管理','display'=>0),
        'business_union/stat' => array('text'=>'数据统计','display'=>0),
        //'tuiguang/index' => array('text' => '微商联盟', 'display' => 1),
        'lbs/index' => array('text'=>'LBS微商圈','display'=>1)
    ),

    'mooncake/index' => array(
        'mooncake/index'=>array('text'=>'游戏列表','display'=>1),
        'mooncake/add'=>array('text'=>'添加游戏','display'=>0),
        'mooncake/edit'=>array('text'=>'编辑游戏','display'=>0),
        'mooncake/rank'=>array('text'=>'排行榜','display'=>0)
    ),

    //基本设置
    'basic_setting' => array(
        'basic_setting/index' => array('text'=>'基本信息','display'=>1),
        'basic_setting/wx_info' => array('text'=>'微信信息','display'=>1),
        'basic_setting/alipay_info' => array('text'=>'支付宝服务窗','display'=>1),
    ),

	//数钱游戏
    'money_game/index' => array(
        'money_game/index' => array('text'=>'游戏列表','display'=>1),
        'money_game/set' => array('text'=>'新增（编辑）','display'=>1),
        'money_game/record'=>array('text'=>'数据统计','display'=>0)
    ),

    //微排号
    'lineup/index' => array(
        'lineup/lineups_list' => array('text' => '排号管理', 'display' => 1),
        'lineup/lineup_counts' => array('text' => '排号统计', 'display' => 1),
        'lineup/setting' => array('text' => '排号设置', 'display' => 1),
    ),

    //全民经纪人
    'national_brokers/index' => array(
        'national_brokers/index' => array('text' => '客户', 'display' => 1),
        'national_brokers/brokers' => array('text' => '经纪人', 'display' => 1),
        'national_brokers/broker_other' => array('text' => '经纪人', 'display' => 0),
        'national_brokers/product' => array('text' => '产品', 'display' => 1),
        'national_brokers/add_product' => array('text' => '产品', 'display' => 0),
        'national_brokers/customer_setting' => array('text' => '设置', 'display' => 1),
        'national_brokers/events_setting' => array('text' => '设置', 'display' => 0),
        'national_brokers/broker_setting' => array('text' => '设置', 'display' => 0),
        'national_brokers/withdraw' => array('text' => '设置', 'display' => 0),
        'national_brokers/reg_setting' => array('text' => '设置', 'display' => 0),
        'national_brokers/share_setting' => array('text' => '设置', 'display' => 0),
        'national_brokers/style_setting' => array('text' => '设置', 'display' => 0),
    ),

    //新版图文投票
    'photoVote/index' => array(
        'photoVote/index' => array( 'text'=>'图文投票', 'display'=>1 ),
        'photoVote/add_vote' => array( 'text'=>'添加投票', 'display'=>0 ),
        'photoVote/edit_vote' => array( 'text'=>'编辑投票', 'display'=>0 ),
        'photoVote/option_set' => array( 'text'=>'选项列表', 'display'=>0 ),
        'photoVote/add_option' => array( 'text'=>'添加选项', 'display'=>0 ),
        'photoVote/edit_option' => array( 'text'=>'修改选项', 'display'=>0 ),
        'photoVote_apply/index' => array( 'text'=>'选项申请', 'display'=>0 ),
        'photoVote_apply/detail' => array( 'text'=>'查看申请', 'display'=>0 ),

    )
);