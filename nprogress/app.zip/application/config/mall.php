<?php
/**
 * Created by JetBrains PhpStorm.
 * User: llj
 * Date: 13-10-30
 * Time: 下午1:52
 * To change this template use File | Settings | File Templates.
 */
$config['order_status'] = array(
	0 => '未付款',
	1 => '已付款/到店自提',
	2 => '已付款/送货上门',
	3 => '当面付款/到店自提',
	4 => '当面付款/送货上门',
	5 => '已发货',
	6 => '已收货',
	7 => '已取消'
);

$config['order_status_list'] = array(
	'0' => '未付款',
	'1,2,3,4' => '未处理',
	'1' => '---- 已付款/到店自提',
	'2' => '---- 已付款/送货上门',
	'3' => '---- 当面付款/到店自提',
	'4' => '---- 当面付款/送货上门',
	'5' => '已发货',
	'6' => '已收货',
	'7' => '已取消'
);

//配送方式
$config['ship_method'] = array(
	0 => '送货上门',
	1 => '到店自提'
);

//送货上门的方式
$config['delivery_method'] = array(
	0 => '门店配送',
	1 => '快递配送'
);