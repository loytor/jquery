<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['allow_origin'] = array(
	'me.com',
);