<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * CodeIgniter
 *
 * An open source application development framework for PHP 5.2.4 or newer
 *
 * NOTICE OF LICENSE
 *
 * Licensed under the Academic Free License version 3.0
 *
 * This source file is subject to the Academic Free License (AFL 3.0) that is
 * bundled with this package in the files license_afl.txt / license_afl.rst.
 * It is also available through the world wide web at this URL:
 * http://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to obtain it
 * through the world wide web, please send an email to
 * licensing@ellislab.com so we can send you a copy immediately.
 *
 * @package		CodeIgniter
 * @author		EllisLab Dev Team
 * @copyright	Copyright (c) 2008 - 2013, EllisLab, Inc. (http://ellislab.com/)
 * @license		http://opensource.org/licenses/AFL-3.0 Academic Free License (AFL 3.0)
 * @link		http://codeigniter.com
 * @since		Version 1.0
 * @filesource
 */

/*
| -------------------------------------------------------------------
| SMILEYS
| -------------------------------------------------------------------
| This file contains an array of smileys for use with the emoticon helper.
| Individual images can be used to replace multiple simileys.  For example:
| :-) and :) use the same image replacement.
|
| Please see user guide for more info:
| http://codeigniter.com/user_guide/helpers/smiley_helper.html
|
*/

$config['music'] = array(
	'0' => array('name'=>'今天你要嫁给我', 'url'=>'/assets/wedding/music/1.mp3'),
	'1' => array('name'=>'婚礼进行曲', 'url'=>'/assets/wedding/music/2.mp3'),
	'2' => array('name'=>'恋爱', 'url'=>'/assets/wedding/music/3.mp3'),
	'3' => array('name'=>'柔美的', 'url'=>'/assets/wedding/music/4.mp3'),
	'4' => array('name'=>'我爱你', 'url'=>'/assets/wedding/music/5.mp3'),	
	'5' => array('name'=>'I Wanna Be With You', 'url'=>'/assets/wedding/music/6.mp3'),
	'6' => array('name'=>'Nothing’S Gonna Change My Love For You', 'url'=>'/assets/wedding/music/7.mp3'),
	'7' => array('name'=>'爱是喜欢你(何洁)', 'url'=>'/assets/wedding/music/8.mp3'),
	'8' => array('name'=>'明天我要嫁给你了(周华健)', 'url'=>'/assets/wedding/music/9.mp3'),
	'9' => array('name'=>'最重要的决定(范玮琪)','url'=>'/assets/wedding/music/10.mp3'),
	'10' => array('name'=>'I Love You','url'=>'/assets/wedding/music/11.mp3'),
	'11' => array('name'=>'Wake Up Call','url'=>'/assets/wedding/music/12.mp3'),
	'12' => array('name'=>'Could This Be Love','url'=>'/assets/wedding/music/13.mp3'),
	'13' => array('name'=>'Today Was A Fairytale','url'=>'/assets/wedding/music/14.mp3'),
	'14' => array('name'=>'给你们(张宇)','url'=>'/assets/wedding/music/15.mp3'),
);

/* End of file smileys.php */
/* Location: ./application/config/smileys.php */