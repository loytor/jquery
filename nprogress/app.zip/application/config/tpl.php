<?php
//首页模板
$config['cate_tpl_arr'] = array(
    'yuandian811'=>array('template_id'=>'yuandian811', 'title'=>'圆点8-11（定制）'),
    'dz_729'=>array('template_id'=>'dz_729', 'title'=>'dz_729'),
    'yuanxing7-11'=>array('template_id'=>'yuanxing7-11', 'title'=>'圆7-11'),
    'keji7_11'=>array('template_id'=>'keji7_11', 'title'=>'科技7-11'),
	'shenghuo6_26'=>array('template_id'=>'shenghuo6_26', 'title'=>'生活'),
	'xuexiao6_26'=>array('template_id'=>'xuexiao6_26', 'title'=>'学校'),
	'zhengwu6_26'=>array('template_id'=>'zhengwu6_26', 'title'=>'政务'),
	's605'=>array('template_id'=>'s605', 'title'=>'科技605'),
    'KTV6_16'=>array('template_id'=>'KTV6_16', 'title'=>'KTV6-16'),
    'canyin6_16'=>array('template_id'=>'canyin6_16', 'title'=>'餐饮6-16'),
    'keji6_16'=>array('template_id'=>'keji6_16', 'title'=>'科技6-16'),
    'dichan6_18_1'=>array('template_id'=>'dichan6_18_1', 'title'=>'地产6-18-1'),
    'dichan6_18_2'=>array('template_id'=>'dichan6_18_2', 'title'=>'地产6-18-2'),
    'dichan6_18_3'=>array('template_id'=>'dichan6_18_3', 'title'=>'地产6-18-3'),
    'moban6_7'=>array('template_id'=>'moban6_7', 'title'=>'模板6-7'),
    'moban6_7six'=>array('template_id'=>'moban6_7six', 'title'=>'模板6-7六边形'),
    'hunsha01'=>array('template_id'=>'hunsha01', 'title'=>'婚纱01'),
    'taodiandian'=>array('template_id'=>'taodiandian', 'title'=>'仿淘点点'),
    'yingxiao'=>array('template_id'=>'yingxiao', 'title'=>'移动营销'),
    'saiche'=>array('template_id'=>'saiche', 'title'=>'赛车'),
    'simeidingzhi'=>array('template_id'=>'simeidingzhi', 'title'=>'思美（思美定制）'),
    'lvyou4'=>array('template_id'=>'lvyou4', 'title'=>'旅游4'),
    'jb'=>array('template_id'=>'jb', 'title'=>'酒品'),
    'zb'=>array('template_id'=>'zb', 'title'=>'珠宝'),
    'zw'=>array('template_id'=>'zw', 'title'=>'政务'),
    'yg'=>array('template_id'=>'yg', 'title'=>'婚购'),
    'd0415_1'=>array('template_id'=>'d0415_1', 'title'=>'美发'),
    'd0415_2'=>array('template_id'=>'d0415_2', 'title'=>'方块内圆'),
    'd411_2'=>array('template_id'=>'d411_2', 'title'=>'411定制2'),
    'd411_3'=>array('template_id'=>'d411_3', 'title'=>'411定制3'),
    'd410_1'=>array('template_id'=>'d410_1', 'title'=>'410定制1'),
    'd410_2'=>array('template_id'=>'d410_2', 'title'=>'410定制2'),
    'lvyou2'=>array('template_id'=>'lvyou2', 'title'=>'旅游2'),
    'lvyou3'=>array('template_id'=>'lvyou3', 'title'=>'旅游3'),
    'cake'=>array('template_id'=>'cake', 'title'=>'蛋糕'),
	'default' => array('template_id'=>'default', 'title'=>'默认模版'),
	't1' => array('template_id'=>'t1', 'title'=>'模版1'),
	't2' => array('template_id'=>'t2', 'title'=>'模版2'),
	't3' => array('template_id'=>'t3', 'title'=>'模版3'),
	't4' => array('template_id'=>'t4', 'title'=>'模版4'),
	't5' => array('template_id'=>'t5', 'title'=>'模版5'),
	't6' => array('template_id'=>'t6', 'title'=>'模版6'),
	't7' => array('template_id'=>'t7', 'title'=>'模版7'),
	't7_1' => array('template_id'=>'t7_1', 'title'=>'模版7_分享按钮'),
	't8' => array('template_id'=>'t8', 'title'=>'模版8'),
	'logitech_index' => array('template_id'=>'logitech_index', 'title'=>'IT(首页)模版'),
	'lvyou' => array('template_id'=>'lvyou', 'title'=>'旅游模版'),
    'hunsha' => array('template_id'=>'hunsha', 'title'=>'婚纱模版'),
    'win8_1' => array('template_id'=>'win8_1', 'title'=>'win8系列1'),
    'guaguo' => array('template_id'=>'guaguo', 'title'=>'瓜果'),
    'zixun' => array('template_id'=>'zixun', 'title'=>'咨询'),
    'zixun2' => array('template_id'=>'zixun2', 'title'=>'咨询2'),
	'zixun3' => array('template_id'=>'zixun3', 'title'=>'咨询3'),
    'car' => array('template_id'=>'car', 'title'=>'汽车4S'),
    'putao' => array('template_id'=>'putao', 'title'=>'葡萄'),
    'hongdian' => array('template_id'=>'hongdian', 'title'=>'红点'),
    'jiaoyu' => array('template_id'=>'jiaoyu', 'title'=>'教育'),
    'spa' => array('template_id'=>'spa', 'title'=>'SPA'),
    'kafei' => array('template_id'=>'kafei', 'title'=>'咖啡'),
    'xiehui' => array('template_id'=>'xiehui', 'title'=>'协会'),
    'dianshang_1' => array('template_id'=>'dianshang_1', 'title'=>'电商系列1'),
    'shujia' => array('template_id'=>'shujia', 'title'=>'书架'),
    'dichan' => array('template_id'=>'dichan', 'title'=>'地产系列1'),
    'jianzhu' => array('template_id'=>'jianzhu', 'title'=>'建筑'),
    'jiudian' => array('template_id'=>'jiudian', 'title'=>'酒店'),
    'keji' => array('template_id'=>'keji', 'title'=>'科技'),
    'meirong' => array('template_id'=>'meirong', 'title'=>'美容'),
    'sheji' => array('template_id'=>'sheji', 'title'=>'设计'),
    'wohangzhou' => array('template_id'=>'wohangzhou', 'title'=>'win8系列2'),
    'shuijing' => array('template_id'=>'shuijing', 'title'=>'水晶'),
    'dichan2' => array('template_id'=>'dichan2', 'title'=>'地产系列2'),
    'tianlan' => array('template_id'=>'tianlan', 'title'=>'天蓝'),
    'imagebutton' => array('template_id'=>'imagebutton', 'title'=>'图片按钮'),
    'sheying' => array('template_id'=>'sheying', 'title'=>'摄影'),
    'sheying2' => array('template_id'=>'sheying2', 'title'=>'摄影2'),
    'bmw' => array('template_id'=>'bmw', 'title'=>'汽车4S系列2（宝马定制）'),
    'S4_1' => array('template_id'=>'S4_1', 'title'=>'汽车4S系列3'),
    's4_2' => array('template_id'=>'s4_2', 'title'=>'汽车4S系列4'),
    'shuimo' => array('template_id'=>'shuimo', 'title'=>'水墨系列'),
    'zhiqiu' => array('template_id'=>'zhiqiu', 'title'=>'科技2'),
    'zhiqiu2' => array('template_id'=>'zhiqiu2', 'title'=>'科技3'),
    'pubu' => array('template_id'=>'pubu', 'title'=>'瀑布'),
	'ktv' => array('template_id'=>'ktv', 'title'=>'ktv'),
    'zhongying' => array('template_id'=>'zhongying', 'title'=>'中影'),
    'coffee' => array('template_id'=>'coffee', 'title'=>'仙境咖啡'),
    'tuwen' => array('template_id'=>'tuwen', 'title'=>'图文'),
	'xuehua' => array('template_id'=>'xuehua', 'title'=>'雪花'),
    'huore' => array('template_id'=>'huore', 'title'=>'火热'),
    'fangzhen' => array('template_id'=>'fangzhen', 'title'=>'方正'),
    'spa2' => array('template_id'=>'spa2', 'title'=>'SPA2'),
    'whitecenter' => array('template_id'=>'whitecenter', 'title'=>'模版10'),
    'zhongying2' => array('template_id'=>'zhongying2', 'title'=>'中影2'),
    'jiningdingzhi001' => array('template_id'=>'jiningdingzhi001', 'title'=>'模版11（定制）'),
    'hospital' => array('template_id'=>'hospital','title'=>'医院(定制)'),
    'tuan' => array('template_id'=>'tuan','title'=>'团'),
    'square' => array('template_id'=>'square','title'=>'大方块'),
    'coffee2' => array('template_id'=>'coffee2','title'=>'两岸咖啡'),
    'photo' => array('template_id'=>'photo','title'=>'相册'),
    'moban011' => array('template_id'=>'moban011','title'=>'模板12（定制）'),
    'wohangzhou1' => array('template_id'=>'wohangzhou1','title'=>'模板13（定制）'),
    'xuehua2' => array('template_id'=>'xuehua2','title'=>'雪花2'),
    'weix' => array('template_id'=>'weix','title'=>'微x信'),
    'yuanquan' => array('template_id'=>'yuanquan','title'=>'圆圈'),
    'shuimo2' => array('template_id'=>'shuimo2','title'=>'水墨2')
);
//文章列表模板
$config['list_tpl_arr'] = array(
    'dianzan'=>array('template_id'=>'dianzan', 'title'=>'点赞'),
    'tuwen7-11'=>array('template_id'=>'tuwen7-11', 'title'=>'图文模板7-11'),
    'moban6_4_02'=>array('template_id'=>'moban6_4_02', 'title'=>'模板6-4-02'),
    'moban6_4_01'=>array('template_id'=>'moban6_4_01', 'title'=>'模板6-4-01'),
    'new2'=>array('template_id'=>'new2', 'title'=>'模版16'),
    'new1'=>array('template_id'=>'new1', 'title'=>'模版15'),
    'lvyou4'=>array('template_id'=>'lvyou4', 'title'=>'旅游4'),
    'imglist'=>array('template_id'=>'imglist', 'title'=>'图片列表'),
    'd411_1'=>array('template_id'=>'d411_1', 'title'=>'411定制1'),
	'default' => array('template_id'=>'default', 'title'=>'默认模版'),
	't1' => array('template_id'=>'t1', 'title'=>'模版1'),
    'logitech_product_list_2' =>array('template_id'=>'logitech_product_list_2', 'title'=>'IT2(列表)模版'),
    'pubu' =>array('template_id'=>'pubu', 'title'=>'瀑布流系列1'),
	'douya' =>array('template_id'=>'douya', 'title'=>'豆芽'),
    'xiehui' => array('template_id'=>'xiehui', 'title'=>'协会'),
    'shujia' => array('template_id'=>'shujia', 'title'=>'书架'),
    'dianshang_1' => array('template_id'=>'dianshang_1', 'title'=>'电商系列1'),
    'photo' => array('template_id'=>'photo', 'title'=>'照片展示'),
    'logitech_product_list_3' => array('template_id'=>'logitech_product_list_3', 'title'=>'IT3(列表)模版'),
    'zhiqiu1' => array('template_id'=>'zhiqiu1', 'title'=>'照片展示2'),
    'zhiqiu2' => array('template_id'=>'zhiqiu2', 'title'=>'照片展示3'),
    'zhiqiu3' => array('template_id'=>'zhiqiu3', 'title'=>'凤凰'),
    'zhiqiu4' => array('template_id'=>'zhiqiu4', 'title'=>'图标列表'),
    'zhiqiu1_new' => array('template_id'=>'zhiqiu1_new', 'title'=>'图标列表2(定制)'),
    'zhiqiu2_new' => array('template_id'=>'zhiqiu2_new', 'title'=>'照片展示3(定制)'),
    'zhiqiu3_new' => array('template_id'=>'zhiqiu3_new', 'title'=>'凤凰(定制)'),
    'zhiqiu4_new' => array('template_id'=>'zhiqiu4_new', 'title'=>'图标列表(定制)'),
    'zhiqiu5_new' => array('template_id'=>'zhiqiu5_new', 'title'=>'科技(定制)'),
    'lishi' => array('template_id'=>'lishi', 'title'=>'历史'),
	'wedding' => array('template_id'=>'wedding', 'title'=>'婚礼照片'),
    'whitecenter' => array('template_id'=>'whitecenter', 'title'=>'模版10'),
    'chongqing01' => array('template_id'=>'chongqing01', 'title'=>'模版11（定制）'),
    'chongqing02' => array('template_id'=>'chongqing02', 'title'=>'模版12（定制）'),
    'chongqing03' => array('template_id'=>'chongqing03', 'title'=>'模版13（定制）'),
    'moban001' => array('template_id'=>'moban001', 'title'=>'模版14（定制）'),
    'photo2' => array('template_id'=>'photo2', 'title'=>'相册模板2'),
    'jixie1' => array('template_id'=>'jixie1', 'title'=>'工具1'),
    'jixie2' => array('template_id'=>'jixie2', 'title'=>'工具2'),
    'xiaoshouwangluo' => array('template_id'=>'xiaoshouwangluo', 'title'=>'销售网络（定制）')

);
//详情页模板
$config['detail_tpl_arr'] = array(
    'dianzan' => array('template_id'=>'dianzan', 'title'=>'点赞'),
    'coffee' => array('template_id'=>'coffee', 'title'=>'咖啡'),
    'topbig' => array('template_id'=>'topbig', 'title'=>'顶部大图'),
	'default' => array('template_id'=>'default', 'title'=>'默认模版'),
    'logitech_product_detail' => array('template_id'=>'logitech_product_detail', 'title'=>'IT(详情)模版'),
    'photo' => array('template_id'=>'photo', 'title'=>'照片展示'),
	'default_zhiqiu' => array('template_id'=>'default_zhiqiu', 'title'=>'默认模版(定制)'),
    'photo_zhiqiu' => array('template_id'=>'photo_zhiqiu', 'title'=>'照片展示(定制)'),
    'dianshang_1' => array('template_id'=>'dianshang_1', 'title'=>'电商系列1'),
    'photo_only' => array('template_id'=>'photo_only', 'title'=>'照片展示-全图'),
    'zhengfu' => array('template_id'=>'zhengfu', 'title'=>'政府终端页')
);
//联系我们模版
$config['contact_tpl_arr'] = array(
	'default' => array('template_id'=>'default', 'title'=>'默认模版'),
    'default1' => array('template_id'=>'default1', 'title'=>'默认模版1'),
    'default2' => array('template_id'=>'default2', 'title'=>'默认模版(可筛选)')
);

$config['reserve_tpl_arr'] = array(
	'room'=> array(
		'default' => array('template_id'=>'default', 'title'=>'默认模版'),
	),
	'ktv'=> array(
		'default' => array('template_id'=>'default', 'title'=>'默认模版'),
	),
	'drive'=> array(
		'default' => array('template_id'=>'default', 'title'=>'默认模版'),
	),
	'restaurant'=> array(
		'default' => array('template_id'=>'default', 'title'=>'默认模版'),
	),
	'book'=> array(
		'default' => array('template_id'=>'default', 'title'=>'默认模版'),
	),
	'cosmetician'=> array(
		'default' => array('template_id'=>'default', 'title'=>'默认模版'),
	),
	'maintenance'=> array(
		'default' => array('template_id'=>'default', 'title'=>'默认模版'),
	),
	'course'=> array(
		'default' => array('template_id'=>'default', 'title'=>'默认模版'),
	),
	'table'=> array(
		'default' => array('template_id'=>'default', 'title'=>'默认模版'),
	),
    'register'=> array(
        'default' => array('template_id'=>'default', 'title'=>'默认模版'),
    ),
);

//图片预览域名路径
$config['preview_path'] = 'http://web.bama555.com/';

//请柬模板
$config['invitation_tpl'] = array(
	'normal' => array(
		'default' => array('template_id'=>'default', 'title'=>'默认模版(不能更换封面)'),
        'default1' => array('template_id'=>'default1', 'title'=>'默认模版(定制)')
	),
    'birthday' => array(
        'default' => array('template_id'=>'default', 'title'=>'通用生日'),
        'manyue' => array('template_id'=>'manyue', 'title'=>'满月')
    )
);

//请柬分类
$config['invitation_type'] = array(
    'normal' => '通用请柬',
	'birthday' => '生日请柬'
);

//投票模版
$config['vote_tpl'] = array(
    'survey' => array(
        'default' => array('template_id'=>'default', 'title'=>'一页一题'),
        'default1' => array('template_id'=>'default1', 'title'=>'整页显示')
    ),
    'exam' => array(
        'default' => array('template_id'=>'default', 'title'=>'一页一题'),
        'default1' => array('template_id'=>'default1', 'title'=>'整页显示')
    )
);

//投票模版
$config['vote_type'] = array(
    'survey' => '调查模式',
    'exam' => '答题模式'
);

//商城模板
$config['mall_tpl'] = array(
    'default' => '默认模板',
    'default1' => '模板一',
    'default2' => '模板二'
);

//微名片模版
$config['bcard_tpl'] = array(
    'default' => '默认样式',
	'default1' => '秋意浓',
	'default2' => '炫彩风',
	'default3' => '梦幻风',
	'default4' => '蒲公英',
	'default5' => '烟雨江南'
);

//外卖模版
$config['waimai_tpl'] = array(
    'default' => '外卖模板',
    'default1' => '配送模版'
);
//配送模版
$config['peisong_tpl'] = array(
    'default' => '配送模板'
);
//点菜模版
$config['diancai_tpl'] = array(
    'default' => '默认模板'
);
//微报名模版
$config['enroll_tpl'] = array(
    'default' => '默认模板',
    'default1' => '文章模版'
);
//新微喜帖模版
$config['wedding_tpl'] = array(
    'default1' => '中国风',
    'default' => '小清新',
    'book' => 'TIME杂志',
    'book1' => '知音杂志',
    'guizu' => '贵族',
    'qixi' => '七夕',
    'langman' => '浪漫'
);
//相册模版
//相册模版
$config['album_tpl'] = array(
    'default1' => '全屏列表',
    'default' => '白边框列表',
    'heng' => '左右切换',
    'shu' => '上下切换(推荐)',
    'shu_wu' => '上下切换(无涂抹效果)',
    'default2' => '左右切换+返回按钮',
    'pubu' => '瀑布流'
);