<?php
/**
 * Created by JetBrains PhpStorm.
 * User: llj
 * Date: 13-9-10
 * Time: 下午2:16
 * To change this template use File | Settings | File Templates.
 */

//酒店预订特殊字段配置
/*$config['room_store'] = array(
	'url' => '/reserve/extend_room.html',
	'property' => array('num'=>'连锁店号')
);*/
/*$config['room_category'] = array(
	'url' => '/reserve_category/extend_room.html',
	'property' => array('count'=>'数量')
);
$config['room_stuff'] = array(
	'url' => '/reserve_stuff/extend_room.html',
	'property' => array('price'=>'价格')
);*/
$config['room_order'] = array(
	'property' => array(
		'out_time' => "退房时间",
		'memo' => "备注",
	)
);


//KTV包房预订特殊字段设置
/*$config['ktv_store'] = array(
	'url' => '/reserve/extend_ktv.html',
	'property' => array('num'=>'ktv店号')
);*/
$config['ktv_stuff'] = array(
	'url' => '/reserve_stuff/extend_ktv.html',
	'property' => array(
		'size'=>'容纳人数',
		'consume'=>'最低消费'
	)
);
$config['ktv_order'] = array(
	'property' => array(
		'num'=>'人数',
	)
);

//预约试驾特殊字段设置
$config['drive_stuff'] = array(
	'url' => '/reserve_stuff/extend_drive.html',
/*	'property' => array(
		'displacement'=>'排量',
		'transmission'=>'变速器'
	)*/
);
$config['drive_order'] = array(
	'property' => array(
		'sex'=>'性别',
		'buy_time'=>'购车时间',
		'drive_age'=>'驾龄'
	)
);

//类型
$config['reserve_types'] = array(
	'room' => array('type'=>0, 'title'=>'酒店订房', 'stuff'=>'房间', 'order_time'=>'入住时间'),
	'ktv' => array('type'=>1, 'title'=>'KTV预订', 'stuff'=>'包房', 'order_time'=>'到达时间'),
	'drive' => array('type'=>2, 'title'=>'4S店预约试驾', 'stuff'=>'车型', 'order_time'=>'试驾时间'),
	'restaurant' => array('type'=>3, 'title'=>'餐厅订餐', 'stuff'=>'菜品', 'order_time'=>'订餐时间')
);

//商家订单操作状态设置
$config['order_status'] = array(
	-2 => '删除',
	-1  => '取消',
	0  => '未处理',
	1  => '已确认',
);

//商家订单操作状态设置
$config['order_user_status'] = array(
	-2 => '删除',
	-1  => '取消',
	0  => '待处理',
	1  => '已处理',

);