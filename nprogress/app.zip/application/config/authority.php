<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * CodeIgniter
 *
 * An open source application development framework for PHP 5.2.4 or newer
 *
 * NOTICE OF LICENSE
 *
 * Licensed under the Academic Free License version 3.0
 *
 * This source file is subject to the Academic Free License (AFL 3.0) that is
 * bundled with this package in the files license_afl.txt / license_afl.rst.
 * It is also available through the world wide web at this URL:
 * http://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to obtain it
 * through the world wide web, please send an email to
 * licensing@ellislab.com so we can send you a copy immediately.
 *
 * @package		CodeIgniter
 * @author		EllisLab Dev Team
 * @copyright	Copyright (c) 2008 - 2013, EllisLab, Inc. (http://ellislab.com/)
 * @license		http://opensource.org/licenses/AFL-3.0 Academic Free License (AFL 3.0)
 * @link		http://codeigniter.com
 * @since		Version 1.0
 * @filesource
 */

/*
| -------------------------------------------------------------------
| SMILEYS
| -------------------------------------------------------------------
| This file contains an array of smileys for use with the emoticon helper.
| Individual images can be used to replace multiple simileys.  For example:
| :-) and :) use the same image replacement.
|
| Please see user guide for more info:
| http://codeigniter.com/user_guide/helpers/smiley_helper.html
|
*/

$config['authority'] = array(

	'wedding_invitation'		=>	array(1, '微信喜帖', 0),
	'caipiao'                   =>  array(2, '彩票', 0),
	'member_card'               =>  array(4, '会员卡', 1),
	'invitation'                =>  array(8, '请柬', 0),
	//'game'                      =>  array(16, '互动游戏', 1),
	'autocard'                  =>  array(32, '4S车主关怀系统', 1),
	'reserve/room'              =>  array(64, '酒店订房', 1),
	'reserve/ktv'               =>  array(128, 'KTV预订', 1),
	'reserve/drive'             =>  array(256, '预约试驾', 1),
	'reserve/restaurant'        =>  array(512, '外卖预订', 1),
	'groupon'                   =>  array(1024, '团购', 1),
	'reserve/book'              =>  array(2048, '图书预订', 1),
	'reserve/cosmetician'       =>  array(4096, '美容预约', 1),
	'reserve/maintenance'       =>  array(8192, '汽车保养预约', 1),
	'reserve/course'            =>  array(16384, '课程预约', 1),
	'reserve/table'             =>  array(32768, '餐厅预订（堂食版）', 1),
	'mall'                      =>  array(65536, '微店铺', 1),
);

/* End of file smileys.php */
/* Location: ./application/config/smileys.php */