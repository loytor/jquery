<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['payments'] = array(
    0 => 'alipay',
    1 => 'cod',
    2 => 'wxpay',
    3 => 'tenpay'
);